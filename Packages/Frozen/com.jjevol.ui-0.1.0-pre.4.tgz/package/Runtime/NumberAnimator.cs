using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

namespace jjevol.UI
{
    /// <summary>
    /// 숫자가 변하는 과정을 애니메이션으로 보여주는 레이블 클래스입니다.
    /// </summary>
    public class NumberAnimator : MonoBehaviour
    {
        public const string LOC_COLLECTION = "ui";

        public enum PrintType
        {
            Normal,     // 일반 숫자
            Number,     // 천 단위 콤마 (N0)
            Percentage  // 퍼센트 (P1)
        }

        public enum PlayMode
        {
            Auto,   // 값이 바뀌면 즉시 시작
            Manual  // Play()를 직접 호출해야 시작
        }

        [Header("UI Components")]
        [SerializeField] private TextMeshProUGUI _label;
        [SerializeField] private ContentSizeFitter _sizeFitter;

        [Header("Animation Settings")]
        public float AnimationDuration = 0.7f;
        public bool UseUnscaledTime = true;
        public PlayMode CurrentPlayMode = PlayMode.Auto;
        public float PlaySpeed = 1.0f;

        [Header("Formatting Settings")]
        public PrintType CurrentPrintType = PrintType.Normal;
        [Tooltip("Abbreviate with the number profile. When that profile is Full, a built-in one for the language is used.")]
        public bool UseSymbolic = false;
        public bool HideIfZero = false;
        public string FrontString = string.Empty;
        public string BackString = string.Empty;
        public bool IsBackStringLocalizationKey = false;

        [SerializeField] private string _customStringFormat = string.Empty;
        [Tooltip("Use _numberFormat below instead of the game-wide UIRuntimeOptions.NumberFormat.")]
        [SerializeField] private bool _overrideNumberFormat;
        [SerializeField] private NumberFormatProfile _numberFormat = new NumberFormatProfile();

        // State variables
        private decimal _startValue = 0;
        private decimal _currentValue = 0;
        private decimal _targetValue = 0;
        private float _animationTimer = 0.0f;
        private bool _isAnimating = false;
        private Action _onCompleteCallback = null;

        public decimal CurrentValue => _currentValue;
        public decimal TargetValue => _targetValue;
        public bool IsAnimating => _isAnimating;
        // This animator's own number profile, or null when it follows UIRuntimeOptions.NumberFormat.
        public NumberFormatProfile NumberFormatOverride => _overrideNumberFormat ? _numberFormat : null;
        public void SetNumberFormat(NumberFormatProfile profile)
        {
            _overrideNumberFormat = profile != null; _numberFormat = profile?.Copy() ?? new NumberFormatProfile();
            UpdateVisuals();
        }

        private void Awake()
        {
            if (_label == null) _label = GetComponent<TextMeshProUGUI>();
            if (_sizeFitter == null) _sizeFitter = GetComponent<ContentSizeFitter>();
        }

        private void Update()
        {
            if (!_isAnimating) return;

            UpdateAnimation();
        }

        private void UpdateAnimation()
        {
            float deltaTime = UseUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
            _animationTimer += deltaTime * PlaySpeed;

            float progress = Mathf.Clamp01(_animationTimer / AnimationDuration);

            // 선형 보간 계산 (decimal 지원)
            _currentValue = _startValue + (decimal.Floor((_targetValue - _startValue) * (decimal)progress));

            if (progress >= 1.0f)
            {
                _currentValue = _targetValue;
                _isAnimating = false;
                FinishAnimation();
            }

            UpdateVisuals();
        }

        /// <summary>
        /// 애니메이션 없이 값을 즉시 설정합니다.
        /// </summary>
        public void SetValueImmediate(decimal value)
        {
            _targetValue = value;
            _currentValue = value;
            _startValue = value;
            _isAnimating = false;

            UpdateVisuals();
        }

        /// <summary>
        /// 목표값까지 애니메이션을 시작합니다.
        /// </summary>
        public void AnimateTo(decimal targetValue, Action onComplete = null)
        {
            // 값이 같으면 즉시 종료 처리
            if (_currentValue == targetValue)
            {
                _targetValue = targetValue;
                UpdateVisuals();
                onComplete?.Invoke();
                return;
            }

            _startValue = _currentValue;
            _targetValue = targetValue;
            _animationTimer = 0f;
            _onCompleteCallback = onComplete;

            if (CurrentPlayMode == PlayMode.Auto)
            {
                _isAnimating = true;
            }
        }

        public void Play() => _isAnimating = true;
        public void Stop() => _isAnimating = false;

        public void ResetToZero()
        {
            _startValue = 0;
            _currentValue = 0;
            _targetValue = 0;
            _isAnimating = false;
            UpdateVisuals();
        }

        private void FinishAnimation()
        {
            var callback = _onCompleteCallback;
            _onCompleteCallback = null;
            callback?.Invoke();
        }

        /// <summary>
        /// 텍스트 레이블의 내용을 현재 값에 맞게 갱신합니다.
        /// </summary>
        public void UpdateVisuals()
        {
            if (_label == null) return;

            if (HideIfZero && _currentValue == 0)
            {
                _label.text = string.Empty;
                return;
            }

            string formattedNumber = GetFormattedNumberString();

            // 최종 문자열 조합
            string finalResult = string.IsNullOrEmpty(_customStringFormat)
                ? $"{FrontString}{formattedNumber}{GetSuffix()}"
                : $"{FrontString}{string.Format(_customStringFormat, formattedNumber)}{GetSuffix()}";

            _label.text = finalResult;

            if (_sizeFitter != null)
            {
                _sizeFitter.enabled = false;
                _sizeFitter.enabled = true; // Layout Rebuild 유도
            }
        }

        private string GetFormattedNumberString()
        {
            if (CurrentPrintType == PrintType.Percentage) return _currentValue.ToString("P1", UIRuntimeOptions.DisplayCulture);
            if (CurrentPrintType == PrintType.Normal && !UseSymbolic && !_overrideNumberFormat) return _currentValue.ToString(UIRuntimeOptions.DisplayCulture);

            NumberFormatProfile profile = NumberFormatOverride ?? UIRuntimeOptions.CurrentNumberFormat;
            if (UseSymbolic && profile.Notation != NumberNotation.Abbreviated) profile = NumberFormatProfile.CreateAbbreviatedFor(UIRuntimeOptions.CurrentLanguage);
            return NumberFormat.Format(_currentValue, profile, UIRuntimeOptions.DisplayCulture);
        }

        private string GetSuffix()
        {
            if (string.IsNullOrEmpty(BackString)) return string.Empty;

            return IsBackStringLocalizationKey
                ? UIRuntimeOptions.GetLocalizedString(LOC_COLLECTION, BackString)
                : BackString;
        }

        public void SetCustomFormat(string format) => _customStringFormat = format;
    }
}
