# JJEvol Localization Runtime / TMP

`com.jjevol.localization@0.1.0-pre.3`은 기존 사용자 LocalizationManager·LocalizeTmpTextEvent의 선택형 개발 후보입니다. Google Sheets/CSV 제작 Editor와 언어 설정 Popup은 포함하지 않습니다. SDK·번역·게임 Prefab·폰트 원본은 UPM에 포함하지 않습니다.

## 설치

- 검증 기준: Unity 6000.3.9f1, Unity Localization 1.5.12, Addressables 4.0.1, uGUI/TMP 2.0.0.
- `com.jjevol.resources.addressables@0.1.0-pre.3`이 PersistentSingleton을 소유합니다. 해당 패키지의 UniTask peer 설치 계약도 필요합니다. 검증 Host는 UniTask 2.5.10, Git commit `f213ff497e4ff462a77319cf677cf20cc0860ca9`를 manifest에 명시했습니다.
- STEP20 기본 13개 고정 패키지를 새 Host에 설치한 뒤 이 패키지만 개발 `file:`로 연결했습니다. 새 tarball·Snapshot은 발행하지 않았습니다. 원본 모바일 코드와 중복 설치하지 마세요.
- Production assembly는 `JJEvol.Localization.Runtime` 하나입니다. Tests/Editor와 Tests/Runtime은 별도 test assembly이며 제작 도구가 아닙니다.
- 게임에서 Unity LocalizationSettings·Locale·String/AssetTable·폰트를 준비합니다. 원래 `Localization` StringTable label과 `appInfo/LanguageDisplayName`, ko/en fallback 의미를 유지합니다.

## 폰트

이 패키지는 Locale별 폰트·Material 교체 컴포넌트를 제공하지 않습니다. 게임이 기본 폰트 하나에 폴백 체인을 구성해 언어별 글자를 표시합니다.

- **uGUI/TMP:** 기본 Font Asset의 Fallback Font Assets 또는 TMP Settings의 폴백 목록에 언어별 폰트를 순서대로 등록합니다.
- **UI Toolkit:** Panel Text Settings의 폴백 목록에 등록합니다.
- **한계:** 폴백은 앞쪽 폰트부터 글자를 찾습니다. 한중일 한자처럼 같은 문자의 글꼴이 언어마다 달라야 하면 폴백 순서만으로는 구분되지 않습니다. 이 경우 게임이 Unity Localization의 Asset Table로 해당 화면의 폰트를 지정합니다.

## 게임 연결

`LocalizationRuntimeOptions.ReadLanguage`는 저장 언어를 읽고, `SaveLanguage`는 동기적으로 원자 저장하거나 변경 전에 예외를 던져야 합니다. LocalSaveSession.CommitMutation 같은 기존 저장 계약을 소비자가 연결합니다. 저장 hook이 없으면 원본 Context 부재와 같이 Locale만 바꾸며 저장 성공을 주장하지 않습니다. `InvalidateLocalizedContentCaches`는 소비 게임의 Mail/Notice 정책입니다.

```csharp
// save는 소비 게임이 소유한 LocalSaveSession입니다. payload 필드도 게임이 정합니다.
LocalizationRuntimeOptions.ReadLanguage = () => (string)save.Snapshot.Payload["language"];
LocalizationRuntimeOptions.SaveLanguage = code => {
    var payload = save.Snapshot.Payload;
    payload["language"] = code;
    save.CommitMutation(save.StateRevision, new LocalSaveSnapshot(payload));
};
await LocalizationManager.Instance.InitLocalization();
await LocalizationManager.Instance.SetLanguage("en", isSave: true);
```

순서는 저장 → SDK SelectedLocale 지정 → 실제 변경 시 게임 cache 무효화 → LocalizationEvent입니다. 저장 예외 시 Locale·cache·이벤트를 바꾸지 않습니다. 소비자가 저장 후 예외를 던지거나 별도의 비동기 저장을 시작하는 경우까지 Framework가 rollback하지는 못합니다. cache hook/listener 예외는 이미 저장·Locale 변경 이후이며 원본처럼 전파됩니다.

## 이벤트 / Table / UI

기존 `LocalizationEvent`, `LocalizationEventTypes`, `EventType`, 생성자와 `Trigger`를 유지합니다. 새 `LocalizationEvent.Published`는 실제 C# 알림입니다. 같은 Locale을 명시적으로 다시 설정해도 원본처럼 호출당 이벤트가 발생하며, 중복 Init만 하나의 초기화 작업을 공유합니다.

기존 MM listener는 자동 통지되지 않습니다. MM SDK를 사용하는 소비 assembly가 다음 bridge를 등록하고 종료 시 해제해야 합니다. SDK를 설치하지 않은 Core에는 MM 의존성이 없습니다.

```csharp
// 별도의 MM 사용 소비 assembly에서만 컴파일합니다.
void ForwardToMM(LocalizationEvent value) => MoreMountains.Tools.MMEventManager.TriggerEvent(value);
// 시작: LocalizationEvent.Published += ForwardToMM;
// 종료: LocalizationEvent.Published -= ForwardToMM;
```

UI 소비자는 Published에서 기존 `UIRuntimeOptions.NotifyLocaleChanged()`를 호출하고 Localize/Culture/Language를 연결합니다. Table 소비자는 기존 `ITableLocalization`을 구현합니다. `StringDatabase.GetTable(...).GetEntry(key)`의 실제 entry 존재 여부로 missing은 null, 존재하는 빈 번역은 empty를 반환해야 합니다. 공개 GetLoc의 debug/fallback 문자열과 key를 비교해서 존재 여부를 추정하지 마세요. Table/UI assembly는 Runtime의 강제 의존성이 아닙니다.

## 수명

- 중복 Init은 공유 작업입니다. 실패 이후 재시도할 수 있고, Destroy·content reset은 이전 초기화 세대를 취소합니다. 초기화보다 늦게 요청한 명시 Locale을 초기값이 덮어쓰지 않습니다.
- 추가 `InitLocalization(CancellationToken)`은 해당 호출자의 대기만 취소합니다. 공유 초기화와 SDK cache는 Manager 소유입니다. 이미 취소된 token은 초기화를 시작하지 않습니다.
- UniTask await의 취소 계약은 OperationCanceledException입니다. 검증된 UniTask 2.5.10의 AsTask는 비동기 취소를 Faulted/OCE로 표현할 수 있으므로 Task.IsCanceled만 검사하지 마세요.
- Manager가 획득한 locations/임시 StringTable handle은 finally에서 반환합니다. LocalizationSettings 초기화 및 StringDatabase cache handle은 SDK 소유이므로 별도로 Release하지 않습니다.
- Localization 1.5.12는 내부 preload 실패에도 상위 작업을 Succeeded로 완료할 수 있습니다. Manager는 SDK PreloadBehavior에 따라 `Preload`/`Locale-*` label로 지정된 AssetTable의 실제 PreloadOperation도 확인합니다. 검증용 locations/임시 AssetTable handle만 반환하고 SDK·table 소유 operation은 Release하지 않습니다. lazy table의 preload 정책을 바꾸지 않습니다. SDK 버전 변경 시 이 label·동작 보완을 재검토해야 합니다.
- Manager Destroy는 자신의 대기를 취소하고 임시 handle을 반환합니다. 앱 공용 LocalizationSettings cache까지 자동 파괴하지 않습니다. SDK cache 정리는 소비자가 조율한 `PrepareForContentUpdateAsync`의 Dispose/ResetState 경로입니다. 다른 Locale 소비자가 사용 중인 상태에서 무단 호출하지 마세요.
- content update는 게임이 소비를 멈춘 뒤 Prepare를 기다리고, 실제 콘텐츠 갱신 후 ReloadLocalization을 기다리는 순서입니다. 이 패키지는 Catalog 배포·Managed Addressables Sync를 실행하지 않습니다.
- `LocalizeTmpTextEvent`의 OnEnable은 ResourceManager 완료 콜백 안에서 실행될 수 있습니다(await한 로드 직후 Prefab을 생성하는 경우). 이때 동기 대기는 `Reentering the Update method` 예외를 냅니다. 그래서 Play Mode에서 첫 초기화가 끝나기 전의 `RefreshText`는 텍스트를 그대로 두고, 콜백 밖에서 초기화를 기다린 뒤 갱신합니다. 초기화가 끝난 뒤에는 기존처럼 같은 프레임에 갱신합니다. 다음 경로는 여전히 SDK 동기 대기를 쓰므로 Addressables 콜백 안에서는 호출하거나 활성화하지 마세요: 공개 동기 API(`GetResolvedText`, `GetRuntimeResolvedText`, `LocalizationManager.GetLoc`), Label로 미리 불러오지 않은 Table의 첫 조회, Locale 변경 직후 SDK preload가 끝나기 전의 활성화.
- Text의 updateText=false·해결 모드·편집 preview 정책은 원본 그대로 유지합니다. 제품 폰트와 화면 시각 품질은 소비 게임 검증 대상입니다.

원본 MonoBehaviour Script GUID와 직렬화 필드는 유지하지만 assembly identity는 Assembly-CSharp에서 JJEvol.Localization.Runtime으로 바뀝니다. assembly-qualified reflection/직접 asmdef 참조는 소비 코드에서 조정해야 합니다. 모바일 Host의 자동 전환은 수행하지 않았습니다.
