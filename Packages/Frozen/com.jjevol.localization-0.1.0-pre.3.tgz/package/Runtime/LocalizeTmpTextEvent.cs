using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.Localization.Tables;

[ExecuteAlways]
[DisallowMultipleComponent]
[RequireComponent(typeof(TextMeshProUGUI))]
public class LocalizeTmpTextEvent : MonoBehaviour
{
    public enum TextResolveMode
    {
        StringReference,
        ManualKey,
        StringReferenceThenManualKey
    }

    [Header("Text Localization")]
    [SerializeField] private bool updateText = false;
    [SerializeField] private TextResolveMode resolveMode = TextResolveMode.StringReferenceThenManualKey;

    [Header("String Reference")]
    [SerializeField] private LocalizedString m_StringReference = new LocalizedString();

    [Header("Manual Key")]
    [SerializeField] private string tableCollection = string.Empty;
    [SerializeField] private string entryKey = string.Empty;

    [Header("Options")]
    [SerializeField] private bool showDebugKeyWhenMissing = true;
    [SerializeField] private bool previewInEditMode = true;
    [SerializeField] private bool previewManualKeyInEditMode = false;

    private TextMeshProUGUI _tmp;
    private Coroutine _deferredRefresh;
    private static bool IsLocalizationReady()
    {
        return LocalizationSettings.HasSettings && LocalizationSettings.SelectedLocale != null;
    }

    // First initialization, as opposed to the short preload after a Locale change on an initialized app.
    private static bool IsColdStarting()
    {
        return Application.isPlaying
            && LocalizationSettings.HasSettings
            && !LocalizationSettings.InitializationOperation.IsDone
            && !(jjevol.LocalizationManager.HasInstance && jjevol.LocalizationManager.Instance.IsInitialized);
    }
    public bool PreviewManualKeyInEditMode => previewManualKeyInEditMode;

    public TextMeshProUGUI TargetText => GetTargetText();
    public bool UpdateText => updateText;
    public TextResolveMode ResolveMode => resolveMode;
    public string TableCollection => tableCollection;
    public string EntryKey => entryKey;

    public bool HasStringReference
    {
        get
        {
            if (m_StringReference == null)
                return false;

            return !m_StringReference.IsEmpty;
        }
    }

    public bool HasManualKey =>
        !string.IsNullOrWhiteSpace(tableCollection)
        && !string.IsNullOrWhiteSpace(entryKey);

    private void Reset()
    {
        _tmp = GetComponent<TextMeshProUGUI>();

        updateText = false;
        resolveMode = TextResolveMode.StringReferenceThenManualKey;
        tableCollection = string.Empty;
        entryKey = string.Empty;
    }

    private void Awake()
    {
        CacheComponents();
    }

    private void OnEnable()
    {
        CacheComponents();

        LocalizationSettings.SelectedLocaleChanged += OnSelectedLocaleChanged;

        RefreshText();
    }

    private void OnDisable()
    {
        LocalizationSettings.SelectedLocaleChanged -= OnSelectedLocaleChanged;

        if (_deferredRefresh != null)
        {
            StopCoroutine(_deferredRefresh);
            _deferredRefresh = null;
        }
    }

    private void DeferRefresh()
    {
        // OnEnable refreshes a component that is inactive now, so nothing is lost by skipping it here.
        if (_deferredRefresh == null && isActiveAndEnabled)
            _deferredRefresh = StartCoroutine(RefreshOutsideResourceCallback());
    }

    private IEnumerator RefreshOutsideResourceCallback()
    {
        do yield return null;
        while (IsColdStarting());

        _deferredRefresh = null;
        ApplyResolvedText();
    }

    private void OnValidate()
    {
        CacheComponents();

        if (!Application.isPlaying && previewInEditMode)
            RefreshText();
    }

    private void OnSelectedLocaleChanged(Locale locale)
    {
        RefreshText();
    }

    private void CacheComponents()
    {
        if (_tmp == null)
            _tmp = GetComponent<TextMeshProUGUI>();
    }

    private TextMeshProUGUI GetTargetText()
    {
        if (_tmp == null)
            _tmp = GetComponent<TextMeshProUGUI>();

        return _tmp;
    }

    [ContextMenu("Refresh Text")]
    public void RefreshText()
    {
        if (!updateText)
            return;

        if (!Application.isPlaying && !previewInEditMode)
            return;

        // OnEnable can run inside a ResourceManager callback, for example a prefab instantiated after an awaited load.
        // A synchronous SDK wait there throws "Reentering the Update method", so before initialization wait outside it.
        if (IsColdStarting())
        {
            DeferRefresh();
            return;
        }

        ApplyResolvedText();
    }

    private void ApplyResolvedText()
    {
        CacheComponents();

        if (_tmp == null)
            return;

        _tmp.text = GetResolvedText();
        _tmp.SetVerticesDirty();
        _tmp.SetLayoutDirty();
    }

    public string GetResolvedText()
    {
        bool allowManualKey = Application.isPlaying || previewManualKeyInEditMode;
        return GetResolvedText(allowManualKey);
    }

    public string GetRuntimeResolvedText()
    {
        return GetResolvedText(true);
    }

    private string GetResolvedText(bool allowManualKey)
    {
        if (!updateText)
            return GetCurrentText();

        if (!IsLocalizationReady())
            return GetCurrentText();

        switch (resolveMode)
        {
            case TextResolveMode.StringReference:
                if (TryResolveStringReference(out string stringReferenceOnlyText))
                    return stringReferenceOnlyText;
                break;

            case TextResolveMode.ManualKey:
                if (!allowManualKey)
                    return GetCurrentText();

                if (TryResolveManualKey(out string manualOnlyText))
                    return manualOnlyText;
                break;

            case TextResolveMode.StringReferenceThenManualKey:
                if (TryResolveStringReference(out string stringReferenceText))
                    return stringReferenceText;

                if (!allowManualKey && HasManualKey)
                    return GetCurrentText();

                if (allowManualKey && TryResolveManualKey(out string manualText))
                    return manualText;
                break;
        }

        if (!showDebugKeyWhenMissing)
            return string.Empty;

        return BuildDebugKey(GetDebugCollection(), GetDebugKey());
    }

    private string GetCurrentText()
    {
        TextMeshProUGUI tmp = GetTargetText();
        return tmp != null ? tmp.text : string.Empty;
    }

    public void SetUpdateText(bool value, bool refresh = true)
    {
        updateText = value;

        if (refresh)
            RefreshText();
    }

    public void SetResolveMode(TextResolveMode mode, bool refresh = true)
    {
        resolveMode = mode;

        if (refresh)
            RefreshText();
    }

    public void SetManualReference(string collection, string key, bool refresh = true)
    {
        tableCollection = collection;
        entryKey = key;

        if (refresh)
            RefreshText();
    }

    public void SetManualReferenceByObjectName(bool refresh = true)
    {
        if (string.IsNullOrEmpty(tableCollection))
            tableCollection = "ui";

        entryKey = gameObject.name;

        if (refresh)
            RefreshText();
    }

    private bool TryResolveStringReference(out string text)
    {
        text = string.Empty;

        if (!HasStringReference)
            return false;

        Locale locale = LocalizationSettings.SelectedLocale;
        if (locale == null)
            return false;

        try
        {
            var result = LocalizationSettings.StringDatabase.GetTableEntry(
            m_StringReference.TableReference,
            m_StringReference.TableEntryReference,
            locale);

            StringTableEntry entry = result.Entry;

            if (entry == null)
                return false;

            string value = entry.LocalizedValue;

            if (string.IsNullOrEmpty(value))
                return false;

            text = value;
            return true;
        }
        catch (Exception e)
        {
            Debug.LogWarning($"[LocalizeTmpTextEvent] StringReference resolve failed. object:{name}, error:{e.Message}");
            return false;
        }
    }

    private bool TryResolveManualKey(out string text)
    {
        text = string.Empty;

        string collection = tableCollection?.Trim();
        string key = entryKey?.Trim();

        if (string.IsNullOrEmpty(collection) || string.IsNullOrEmpty(key))
            return false;

        if (!LocalizationSettings.HasSettings)
            return false;

        string value = jjevol.LocalizationManager.GetLoc(collection, key, false);

        if (string.IsNullOrEmpty(value))
            return false;

        text = value;
        return true;
    }

    private string GetDebugCollection()
    {
        if (!string.IsNullOrEmpty(tableCollection))
            return tableCollection.Trim();

        if (HasStringReference)
        {
            string value = m_StringReference.TableReference.ToString();

            if (!string.IsNullOrEmpty(value))
                return value;
        }

        return "<LOCALIZE_EMPTY>";
    }

    private string GetDebugKey()
    {
        if (!string.IsNullOrEmpty(entryKey))
            return entryKey.Trim();

        if (HasStringReference)
        {
            string value = m_StringReference.TableEntryReference.ToString();

            if (!string.IsNullOrEmpty(value))
                return value;
        }

        return gameObject != null ? gameObject.name : "<KEY>";
    }

    private string BuildDebugKey(string collection, string key)
    {
        if (string.IsNullOrEmpty(collection))
            collection = "<LOCALIZE_EMPTY>";

        if (string.IsNullOrEmpty(key))
            key = gameObject != null ? gameObject.name : "<KEY>";

        return $"{collection}/{key}";
    }
}
