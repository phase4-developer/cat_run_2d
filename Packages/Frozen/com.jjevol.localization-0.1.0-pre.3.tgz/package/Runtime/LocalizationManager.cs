using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using Cysharp.Threading.Tasks;
/* 제거 using MoreMountains.Tools; -- consumer bridge owns MM SDK */
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.Localization.Tables;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace jjevol
{
    public enum LocalizationEventTypes
    {
        ChangeLanguage
    }
    public struct LocalizationEvent
    {
        public LocalizationEventTypes EventType;

        /// <param name="eventType">Event type.</param>
        public LocalizationEvent(LocalizationEventTypes eventType)
        {
            EventType = eventType;
        }

        //추가
        public static event System.Action<LocalizationEvent> Published;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetSubscribers() => Published = null;
        //추가 종료
        static LocalizationEvent e;
        public static void Trigger(LocalizationEventTypes eventType)
        {
            e.EventType = eventType;

            //수정
            Published?.Invoke(e);
            //수정 종료
        }
    }

    public class LocalizationManager : PersistentSingleton<LocalizationManager>
    {
        private bool _isInitialized = false;
        private string _reloadLanguageCode = string.Empty;

        //추가
        private readonly CancellationTokenSource _lifetime = new CancellationTokenSource();
        private CancellationTokenSource _initializationCancellation;
        private System.Threading.Tasks.Task _initializationTask;
        private int _generation;
        private int _languageRequestVersion;
        private bool _destroyed;

        private void ThrowIfStale(int generation, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            if (_destroyed || generation != _generation)
                throw new System.OperationCanceledException();
        }
        //추가 종료

        // 테이블 로드 여부를 확인하는 프로퍼티
        public bool IsInitialized => _isInitialized;

        // 테이블을 찾기 위한 Addressables 레이블 (에디터에서 설정한 값과 일치해야 함)
        private const string TABLE_LABEL = "Localization";
        private const string LANGUAGE_DISPLAY_NAME_TABLE = "appInfo";
        private const string LANGUAGE_DISPLAY_NAME_KEY = "LanguageDisplayName";

        public const string DefaultLanguageCode = "ko";
        public const string FallbackLanguageCode = "en";

        public string ToLanguageCode(SystemLanguage sysLang)
        {
            return GetLanguageCode(sysLang);
        }

        public static string GetLanguageCode(SystemLanguage sysLang)
        {
            Locale locale = GetAvailableLocale(sysLang);
            if (locale != null)
                return locale.Identifier.Code;

            string code = new LocaleIdentifier(sysLang).Code;
            return string.IsNullOrEmpty(code) ? FallbackLanguageCode : code;
        }

        public static string GetLanguageDisplayName(string localeCode)
        {
            localeCode = NormalizeLanguageCode(localeCode);

            string displayName = GetLocByLocale(LANGUAGE_DISPLAY_NAME_TABLE, LANGUAGE_DISPLAY_NAME_KEY, localeCode, false);
            if (!string.IsNullOrEmpty(displayName))
                return displayName;

            if (LocalizationSettings.HasSettings && LocalizationSettings.AvailableLocales != null)
            {
                Locale locale = LocalizationSettings.AvailableLocales.GetLocale(localeCode);
                if (locale != null)
                    return locale.LocaleName;
            }

            return localeCode;
        }

        public static string GetCurrentLanguageCode()
        {
            if (LocalizationSettings.SelectedLocale != null)
                return LocalizationSettings.SelectedLocale.Identifier.Code;

            //수정
            if (LocalizationRuntimeOptions.ReadLanguage != null)
                return NormalizeLanguageCode(LocalizationRuntimeOptions.ReadLanguage());
            //수정 종료

            return DefaultLanguageCode;
        }

        private static Locale GetAvailableLocale(SystemLanguage systemLanguage)
        {
            if (!LocalizationSettings.HasSettings || LocalizationSettings.AvailableLocales == null)
                return null;

            Locale locale = LocalizationSettings.AvailableLocales.GetLocale(new LocaleIdentifier(systemLanguage));
            if (locale != null)
                return locale;

            CultureInfo systemCulture = new LocaleIdentifier(systemLanguage).CultureInfo;
            if (systemCulture == null)
                return null;

            foreach (Locale availableLocale in LocalizationSettings.AvailableLocales.Locales)
            {
                CultureInfo availableCulture = availableLocale?.Identifier.CultureInfo;

                while (availableCulture != null && availableCulture != CultureInfo.InvariantCulture)
                {
                    if (availableCulture.Equals(systemCulture))
                        return availableLocale;

                    availableCulture = availableCulture.Parent;
                }
            }

            return null;
        }

        public static string NormalizeLanguageCode(string localeCode)
        {
            if (string.IsNullOrEmpty(localeCode))
                return DefaultLanguageCode;

            return localeCode;
        }

        protected override void OnDestroy()
        {
            //추가
            _destroyed = true;
            _isInitialized = false;
            _generation++;
            _languageRequestVersion++;
            _initializationCancellation?.Cancel();
            _lifetime.Cancel();
            _lifetime.Dispose();
            //추가 종료
            base.OnDestroy();
        }

        private async UniTask SetupInitialLanguage()
        {
            string savedLanguage = !string.IsNullOrEmpty(_reloadLanguageCode)
                ? _reloadLanguageCode
                //수정
                : LocalizationRuntimeOptions.ReadLanguage?.Invoke() ?? string.Empty;
                //수정 종료

            if (string.IsNullOrEmpty(savedLanguage))
            {
                // 시스템 언어로 자동 설정
                await SetLanguage(Application.systemLanguage, false);
            }
            else
            {
                // 저장된 코드로 설정
                await SetLanguage(savedLanguage, false);
            }

            _reloadLanguageCode = string.Empty;
        }

        /// <summary>
        /// Addressables 레이블을 이용해 프로젝트 내의 모든 StringTable을 자동으로 찾아 로드합니다.
        /// </summary>
        //수정
        private async UniTask PreloadTablesByLabel(int generation, CancellationToken cancellationToken)
        //수정 종료
        {
            var locationsHandle = Addressables.LoadResourceLocationsAsync(TABLE_LABEL, typeof(StringTable));

            try
            {
                //수정
                var locations = await locationsHandle.ToUniTask(cancellationToken: cancellationToken, autoReleaseWhenCanceled: false);
                ThrowIfStale(generation, cancellationToken);
                //수정 종료

                if (locations.Count == 0)
                {
                    Debug.LogWarning($"[Localization] '{TABLE_LABEL}' 레이블이 지정된 테이블이 없습니다.");
                    return;
                }

                int loadedCount = 0;
                foreach (var location in locations)
                {
                    var assetHandle = Addressables.LoadAssetAsync<StringTable>(location);
                    try
                    {
                        //수정
                        var table = await assetHandle.ToUniTask(cancellationToken: cancellationToken, autoReleaseWhenCanceled: false);
                        ThrowIfStale(generation, cancellationToken);
                        //수정 종료
                        if (table == null) throw new System.InvalidOperationException("Localization table asset is missing: " + location.PrimaryKey);
                        var locale = LocalizationSettings.AvailableLocales.GetLocale(table.LocaleIdentifier);
                        if (locale == null) throw new System.InvalidOperationException("Localization locale is missing: " + table.LocaleIdentifier);
                        //수정
                        var cached = await LocalizationSettings.StringDatabase.GetTableAsync(table.SharedData.TableCollectionName, locale)
                            .ToUniTask(cancellationToken: cancellationToken, autoReleaseWhenCanceled: false);
                        ThrowIfStale(generation, cancellationToken);
                        //수정 종료
                        if (cached == null) throw new System.InvalidOperationException("Localization table could not be preloaded: " + table.SharedData.TableCollectionName);
                        loadedCount++;
                    }
                    finally { if (assetHandle.IsValid()) Addressables.Release(assetHandle); }
                }

                Debug.Log($"[Localization] {loadedCount}개의 테이블 자동 프리로드 완료.");
            }
            finally
            {
                if (locationsHandle.IsValid())
                    Addressables.Release(locationsHandle);
            }
        }

        //수정
        public UniTask InitLocalization()
        {
            if (_destroyed) return UniTask.FromCanceled(new CancellationToken(true));
            if (_isInitialized) return UniTask.CompletedTask;
            if (_initializationTask == null || _initializationTask.IsCompleted)
            {
                var cancellation = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token);
                _initializationCancellation = cancellation;
                _initializationTask = InitializeOnceAsync(_generation, _languageRequestVersion, cancellation).AsTask();
            }
            return _initializationTask.AsUniTask();
        }
        //수정 종료

        //추가
        /// <summary>Cancel this caller's wait; the Manager still owns shared initialization.</summary>
        public UniTask InitLocalization(CancellationToken cancellationToken) => cancellationToken.IsCancellationRequested
            ? UniTask.FromCanceled(cancellationToken)
            : InitLocalization().AttachExternalCancellation(cancellationToken);

        private async UniTask InitializeOnceAsync(int generation, int languageVersion, CancellationTokenSource cancellation)
        {
            CancellationToken token = cancellation.Token;
            try
            {
                await InitializeCoreAsync(generation, languageVersion, token);
            }
            finally
            {
                if (ReferenceEquals(_initializationCancellation, cancellation)) _initializationCancellation = null;
                cancellation.Dispose();
            }
        }
        private async UniTask InitializeCoreAsync(int generation, int languageVersion, CancellationToken token)
        {
        //추가 종료

            var initOp = LocalizationSettings.InitializationOperation;
            //수정
            await initOp.ToUniTask(cancellationToken: token, autoReleaseWhenCanceled: false);
            ThrowIfStale(generation, token);
            //수정 종료

            if (initOp.Status == AsyncOperationStatus.Failed)
            {
                Debug.LogError("[Localization] 시스템 초기화 실패. Addressables 빌드 상태를 확인하세요.");
                return;
            }

            // Addressables 완료 콜백을 빠져나온 뒤 Locale 변경을 시작해 ResourceManager 재진입을 방지합니다.
            //수정
            await UniTask.NextFrame(cancellationToken: token);
            ThrowIfStale(generation, token);
            //수정 종료

            // 2. 언어 설정 (저장된 데이터 또는 시스템 언어)
            //수정
            if (languageVersion == _languageRequestVersion) await SetupInitialLanguage();
            ThrowIfStale(generation, token);
            //수정 종료

            //추가
            await VerifyConfiguredAssetPreloads(generation, token);
            //추가 종료

            // 3. 모든 테이블 자동 프리로드 (수동 리스트 제거)
            //수정
            await PreloadTablesByLabel(generation, token);
            //수정 종료

            // 마지막 Addressables 완료 콜백을 빠져나온 뒤 초기화 완료 상태를 공개합니다.
            //수정
            await UniTask.NextFrame(cancellationToken: token);
            ThrowIfStale(generation, token);
            //수정 종료
            _isInitialized = true;
        }

        //추가
        // Localization 1.5.12 PreloadDatabaseOperation completes successfully even when child asset preload fails.
        // Verify only SDK-configured preload tables; do not turn lazy tables into eagerly loaded tables.
        private async UniTask VerifyConfiguredAssetPreloads(int generation, CancellationToken token)
        {
            var behavior = LocalizationSettings.PreloadBehavior;
            if (behavior == PreloadBehavior.NoPreloading) return;
            var locales = new HashSet<Locale>();
            if (behavior == PreloadBehavior.PreloadAllLocales)
            {
                foreach (var locale in LocalizationSettings.AvailableLocales.Locales) if (locale != null) locales.Add(locale);
            }
            else if (LocalizationSettings.SelectedLocale != null)
            {
                locales.Add(LocalizationSettings.SelectedLocale);
                if (behavior == PreloadBehavior.PreloadSelectedLocaleAndFallbacks)
                {
                    var pending = new Stack<Locale>(locales);
                    while (pending.Count > 0)
                        foreach (var fallback in pending.Pop().GetFallbacks())
                            if (fallback != null && locales.Add(fallback)) pending.Push(fallback);
                }
            }
            foreach (var locale in locales)
            {
                // These are the actual SDK 1.5.12 AddressHelper/LocalizationSettings catalog labels.
                var locations = Addressables.LoadResourceLocationsAsync(new[] { "Locale-" + locale.Identifier.Code, "Preload" },
                    Addressables.MergeMode.Intersection, typeof(AssetTable));
                try
                {
                    var found = await locations.ToUniTask(cancellationToken: token, autoReleaseWhenCanceled: false);
                    ThrowIfStale(generation, token);
                    foreach (var location in found)
                    {
                        var asset = Addressables.LoadAssetAsync<AssetTable>(location);
                        try
                        {
                            var table = await asset.ToUniTask(cancellationToken: token, autoReleaseWhenCanceled: false);
                            ThrowIfStale(generation, token);
                            if (table == null) throw new System.InvalidOperationException("SDK preload AssetTable is missing: " + location.PrimaryKey);
                            await table.PreloadOperation.ToUniTask(cancellationToken: token, autoReleaseWhenCanceled: false);
                            ThrowIfStale(generation, token);
                        }
                        finally { if (asset.IsValid()) Addressables.Release(asset); }
                    }
                }
                finally { if (locations.IsValid()) Addressables.Release(locations); }
            }
        }
        //추가 종료

        public async UniTask PrepareForContentUpdateAsync(CancellationToken cancellationToken)
        {
            //추가
            cancellationToken.ThrowIfCancellationRequested();
            if (_destroyed) throw new System.OperationCanceledException();
            //추가 종료
            _reloadLanguageCode = GetCurrentLanguageCode();

            //추가
            _generation++;
            _languageRequestVersion++;
            _isInitialized = false;
            var pending = _initializationTask;
            _initializationCancellation?.Cancel();
            _initializationTask = null;
            if (pending != null && !pending.IsCompleted)
            {
                try { await pending.AsUniTask(); }
                catch (System.OperationCanceledException) { }
            }
            //추가 종료

            if (LocalizationSettings.HasSettings)
            {
                // Catalog 세대 전환 전에 Localization이 보유한 Addressables handle과 캐시를 모두 해제합니다.
                LocalizationSettings settings = LocalizationSettings.Instance;
                ((System.IDisposable)settings).Dispose();
                settings.ResetState();
            }

            _isInitialized = false;

            await Resources.UnloadUnusedAssets().ToUniTask(cancellationToken: cancellationToken);
        }

        public async UniTask ReloadLocalization()
        {
            await InitLocalization();
        }

        public static string GetLoc(string collection, string key, bool returnDebugKey = true)
        {
            if (string.IsNullOrEmpty(key)) return string.Empty;

            if (!LocalizationSettings.HasSettings || string.IsNullOrEmpty(collection))
                return key;

            var entry = LocalizationSettings.StringDatabase.GetTableEntry(collection, key);

            if (entry.Entry != null)
            {
                string value = entry.Entry.LocalizedValue;

                if (!string.IsNullOrEmpty(value))
                    return value;
            }

            return returnDebugKey ? $"{collection}/{key}" : string.Empty;
        }

        public static string GetLocByLocale(string collection, string key, string localeCode, bool returnDebugKey = true)
        {
            if (string.IsNullOrEmpty(key)) return string.Empty;

            if (!LocalizationSettings.HasSettings || string.IsNullOrEmpty(collection))
                return returnDebugKey ? key : string.Empty;

            Locale locale = LocalizationSettings.AvailableLocales.GetLocale(localeCode);

            if (locale == null)
                locale = LocalizationSettings.AvailableLocales.GetLocale("en");

            var entry = LocalizationSettings.StringDatabase.GetTableEntry(collection, key, locale);

            if (entry.Entry != null)
            {
                string value = entry.Entry.LocalizedValue;

                if (!string.IsNullOrEmpty(value))
                    return value;
            }

            return returnDebugKey ? $"{collection}/{key}" : string.Empty;
        }

        public static string GetEnglishLoc(string collection, string key, bool returnDebugKey = true)
        {
            return GetLocByLocale(collection, key, "en", returnDebugKey);
        }

        public async UniTask SetLanguage(SystemLanguage systemLanguage, bool isSave = true)
        {
            await SetLanguage(ToLanguageCode(systemLanguage), isSave);
        }

        public async UniTask SetLanguage(string localeCode, bool isSave = true)
        {
            //추가
            if (_destroyed) throw new System.OperationCanceledException();
            int generation = _generation;
            int version = ++_languageRequestVersion;
            CancellationToken token = _lifetime.Token;
            //추가 종료
            if (!LocalizationSettings.InitializationOperation.IsDone)
            {
                //수정
                await LocalizationSettings.InitializationOperation.ToUniTask(cancellationToken: token, autoReleaseWhenCanceled: false);
                await UniTask.NextFrame(cancellationToken: token);
                //수정 종료
            }

            //추가
            ThrowIfStale(generation, token);
            if (version != _languageRequestVersion) throw new System.OperationCanceledException();
            //추가 종료

            localeCode = NormalizeLanguageCode(localeCode);

            Locale locale = LocalizationSettings.AvailableLocales.GetLocale(localeCode);

            if (locale == null)
                locale = LocalizationSettings.AvailableLocales.GetLocale(FallbackLanguageCode);

            if (locale == null)
                locale = LocalizationSettings.AvailableLocales.GetLocale(DefaultLanguageCode);

            ApplyLocale(locale, isSave);
        }

        private void ApplyLocale(Locale locale, bool isSave)
        {
            if (locale == null) return;

            string previousLocaleCode = LocalizationSettings.SelectedLocale?.Identifier.Code;
            string nextLocaleCode = locale.Identifier.Code;
            bool languageChanged = !string.Equals(previousLocaleCode, nextLocaleCode, System.StringComparison.OrdinalIgnoreCase);

            //수정
            if (isSave) LocalizationRuntimeOptions.SaveLanguage?.Invoke(nextLocaleCode);
            //수정 종료

            LocalizationSettings.SelectedLocale = locale;

            if (languageChanged)
                InvalidateLocalizedContentCaches();

            LocalizationEvent.Trigger(LocalizationEventTypes.ChangeLanguage);
        }

        private static void InvalidateLocalizedContentCaches()
        {
            //수정
            LocalizationRuntimeOptions.InvalidateLocalizedContentCaches?.Invoke();
            //수정 종료
        }
    }
}
