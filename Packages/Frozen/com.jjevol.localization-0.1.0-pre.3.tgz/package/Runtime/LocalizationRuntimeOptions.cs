using System;
using UnityEngine;

namespace jjevol
{
    //추가
    /// <summary>Consumer-owned language persistence and localized server-cache policy.</summary>
    public static class LocalizationRuntimeOptions
    {
        public static Func<string> ReadLanguage { get; set; }
        /// <summary>Must commit synchronously or throw before changing persisted state.</summary>
        public static Action<string> SaveLanguage { get; set; }
        public static Action InvalidateLocalizedContentCaches { get; set; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void Reset()
        {
            ReadLanguage = null;
            SaveLanguage = null;
            InvalidateLocalizedContentCaches = null;
        }
    }
    //추가 종료
}
