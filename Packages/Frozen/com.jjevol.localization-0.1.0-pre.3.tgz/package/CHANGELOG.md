# Changelog

## 0.1.0-pre.3 - 2026-11-08

- Removed `LocalizeTmpStyleEvent`. Per-locale font and material swapping is replaced by a font fallback chain that the game configures. See the README font section.
- Any Prefab that still carries the component (script GUID `4253a8bfbcb95b34fb5eb9b8940e93ec`) shows a missing script. No Prefab or Scene in the mobile baseline, the Steam library or the consumer game projects checked uses it.
- Test fixtures no longer create per-locale TMP font and material assets. A Host with an existing `Assets/Step23Fixture` must regenerate it.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.2 - 2026-11-06

- `RefreshText` waits outside ResourceManager callbacks before first initialization.

Unity tests for this candidate are NOT_RUN.
