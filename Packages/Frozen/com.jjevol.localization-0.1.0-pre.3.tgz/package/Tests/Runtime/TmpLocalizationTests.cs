//추가
using System.Collections;
using System.Reflection;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.AddressableAssets;
using UnityEngine.Localization.Settings;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace jjevol.Step23.Tests
{
    public sealed class TmpLocalizationTests : LocalizationTestFixture
    {
        private GameObject MakeText()
        {
            var prefab = Resources.Load<GameObject>("FixtureText"); Assert.NotNull(prefab);
            var go = Object.Instantiate(prefab); go.name = "FixtureText"; Objects.Add(go);
            return go;
        }
        private GameObject MakeManualText(string initialText)
        {
            var go = MakeText(); go.SetActive(false);
            var local = go.GetComponent<LocalizeTmpTextEvent>(); local.SetResolveMode(LocalizeTmpTextEvent.TextResolveMode.ManualKey, false);
            local.SetManualReference("step23", "hello", false); local.SetUpdateText(true, false);
            local.TargetText.text = initialText;
            return go;
        }
        // Runs in a real completion callback. A synchronous SDK wait in OnEnable fails with "Reentering the Update method",
        // which Unity logs as an exception and the test framework reports as a failure.
        private static IEnumerator ActivateInsideResourceCallback(GameObject go)
        {
            var operation = Addressables.ResourceManager.CreateCompletedOperation("step23", null);
            bool done = false;
            operation.Completed += _ => { go.SetActive(true); done = true; };
            float deadline = Time.realtimeSinceStartup + 5f;
            while (!done && Time.realtimeSinceStartup < deadline) yield return null;
            Assert.IsTrue(done, "Completion callback did not run");
            Addressables.Release(operation);
        }
        [UnityTest] public IEnumerator EnableInsideResourceCallbackBeforeInitializationRefreshesAfterward()
        {
            var go = MakeManualText("prefab text"); var text = go.GetComponent<TextMeshProUGUI>();
            yield return Await(Manager.PrepareForContentUpdateAsync(default)); Assert.IsFalse(Manager.IsInitialized);
            yield return ActivateInsideResourceCallback(go);
            yield return Await(Manager.ReloadLocalization()); yield return null; yield return null;
            Assert.AreEqual("EN fixture", text.text);
        }
        [UnityTest] public IEnumerator DisableDuringColdStartDropsTheDeferredRefresh()
        {
            var go = MakeManualText("prefab text"); var text = go.GetComponent<TextMeshProUGUI>();
            yield return Await(Manager.PrepareForContentUpdateAsync(default));
            go.SetActive(true); go.SetActive(false);
            yield return Await(Manager.ReloadLocalization()); yield return null; yield return null;
            Assert.AreEqual("prefab text", text.text, "A disabled component must not resolve text");
            go.SetActive(true); yield return null; yield return null;
            Assert.AreEqual("EN fixture", text.text);
        }
        [UnityTest] public IEnumerator ExplicitRefreshDuringColdStartIsDeferredToo()
        {
            var go = MakeManualText("prefab text"); var text = go.GetComponent<TextMeshProUGUI>();
            yield return Await(Manager.PrepareForContentUpdateAsync(default));
            go.SetActive(true); text.text = "prefab text"; go.GetComponent<LocalizeTmpTextEvent>().RefreshText();
            yield return Await(Manager.ReloadLocalization()); yield return null; yield return null;
            Assert.AreEqual("EN fixture", text.text);
        }
        [UnityTest] public IEnumerator EnableAfterInitializationStillResolvesInTheSameFrame()
        {
            var go = MakeManualText("prefab text"); go.SetActive(true);
            Assert.AreEqual("EN fixture", go.GetComponent<TextMeshProUGUI>().text);
            yield return null;
        }
        [UnityTest] public IEnumerator ManualModesRefreshAndUpdateTextFalse()
        {
            var go = MakeText(); var text = go.GetComponent<TextMeshProUGUI>(); var local = go.GetComponent<LocalizeTmpTextEvent>();
            text.text = "unchanged"; go.SetActive(true);
            local.SetManualReference("step23", "hello"); local.SetResolveMode(LocalizeTmpTextEvent.TextResolveMode.ManualKey);
            Assert.AreEqual("unchanged", text.text); Assert.AreEqual("unchanged", local.GetRuntimeResolvedText());
            local.SetUpdateText(true); Assert.AreEqual("EN fixture", text.text);
            yield return Await(Manager.SetLanguage("ko", false)); yield return null;
            Assert.AreEqual("KO fixture", text.text);
            local.SetUpdateText(false); yield return Await(Manager.SetLanguage("en", false)); yield return null;
            Assert.AreEqual("KO fixture", text.text);
            local.SetUpdateText(true, false); local.RefreshText(); Assert.AreEqual("EN fixture", text.text);
        }
        [UnityTest] public IEnumerator StringReferenceAndFallbackAndObjectName()
        {
            var go = MakeText(); var local = go.GetComponent<LocalizeTmpTextEvent>();
            typeof(LocalizeTmpTextEvent).GetField("m_StringReference", BindingFlags.NonPublic | BindingFlags.Instance)
                .SetValue(local, new LocalizedString("step23", "hello"));
            local.SetUpdateText(true, false); local.SetResolveMode(LocalizeTmpTextEvent.TextResolveMode.StringReference, false); go.SetActive(true);
            Assert.IsTrue(local.HasStringReference); Assert.AreEqual("EN fixture", local.TargetText.text);
            local.SetResolveMode(LocalizeTmpTextEvent.TextResolveMode.StringReferenceThenManualKey);
            local.SetManualReference("step23", "FixtureText"); Assert.AreEqual("EN fixture", local.TargetText.text);
            typeof(LocalizeTmpTextEvent).GetField("m_StringReference", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(local, new LocalizedString());
            local.SetManualReferenceByObjectName(); Assert.AreEqual("FixtureText", local.EntryKey); Assert.AreEqual("EN object", local.TargetText.text);
            local.SetManualReference("step23", "missing"); Assert.AreEqual("step23/missing", local.TargetText.text);
            yield return null;
        }
        [UnityTest] public IEnumerator DisableDestroyAndTwentyPrefabReusesDoNotReceiveOldLocale()
        {
            for (int i = 0; i < 20; i++)
            {
                var go = MakeText(); var local = go.GetComponent<LocalizeTmpTextEvent>();
                local.SetManualReference("step23", "hello", false); local.SetResolveMode(LocalizeTmpTextEvent.TextResolveMode.ManualKey, false); local.SetUpdateText(true, false);
                go.SetActive(true); yield return null;
                go.SetActive(false); string prior = local.TargetText.text;
                yield return Await(Manager.SetLanguage(i % 2 == 0 ? "ko" : "en", false)); yield return null;
                Assert.AreEqual(prior, local.TargetText.text, "Disabled text must not follow Locale changes");
                go.SetActive(true); yield return null;
                Assert.AreEqual(LocalizationManager.GetLoc("step23", "hello"), local.TargetText.text);
                Object.Destroy(go); yield return null;
            }
            LogAssert.NoUnexpectedReceived();
        }
        [UnityTest] public IEnumerator RapidLocaleSwitchAndSceneUnloadReleaseConsumers()
        {
            var scene = SceneManager.CreateScene("Step23Transient"); var go = MakeText(); SceneManager.MoveGameObjectToScene(go, scene);
            var local = go.GetComponent<LocalizeTmpTextEvent>(); local.SetManualReference("step23", "hello", false); local.SetUpdateText(true, false);
            go.SetActive(true);
            for (int i = 0; i < 8; i++) yield return Await(Manager.SetLanguage(i % 2 == 0 ? "ko" : "en", false));
            float deadline = Time.realtimeSinceStartup + 5f;
            while (Time.realtimeSinceStartup < deadline && local.TargetText.text != "EN fixture") yield return null;
            Assert.AreEqual("EN fixture", local.TargetText.text);
            yield return SceneManager.UnloadSceneAsync(scene); yield return null;
            Assert.IsTrue(go == null); Assert.IsTrue(Manager != null); Assert.IsTrue(Manager.IsInitialized);
            yield return Await(Manager.SetLanguage("ko", false)); LogAssert.NoUnexpectedReceived();
        }
    }
}
//추가 종료
