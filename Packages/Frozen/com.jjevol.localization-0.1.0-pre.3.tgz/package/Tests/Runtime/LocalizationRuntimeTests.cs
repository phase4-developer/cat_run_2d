//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Step23.Tests
{
    [PrebuildSetup("jjevol.Step23.Tests.Editor.FixturePrebuild")]
    public abstract class LocalizationTestFixture
    {
        protected readonly List<GameObject> Objects = new List<GameObject>();
        protected LocalizationManager Manager;
        protected string Saved;
        protected static IEnumerator Await(UniTask operation)
        {
            var task = operation.AsTask();
            while (!task.IsCompleted) yield return null;
            task.GetAwaiter().GetResult();
        }
        [UnitySetUp] public IEnumerator SetUp()
        {
            Saved = "en";
            LocalizationRuntimeOptions.ReadLanguage = () => Saved;
            LocalizationRuntimeOptions.SaveLanguage = code => Saved = code;
            LocalizationRuntimeOptions.InvalidateLocalizedContentCaches = null;
            Manager = new GameObject("Step23 Localization").AddComponent<LocalizationManager>();
            Objects.Add(Manager.gameObject);
            yield return Await(Manager.InitLocalization());
        }
        [UnityTearDown] public IEnumerator TearDown()
        {
            foreach (var go in Objects) if (go) Object.Destroy(go);
            Objects.Clear();
            yield return null; yield return null;
            LocalizationRuntimeOptions.ReadLanguage = null; LocalizationRuntimeOptions.SaveLanguage = null;
            LocalizationRuntimeOptions.InvalidateLocalizedContentCaches = null;
        }
    }
    public class LocalizationRuntimeTests : LocalizationTestFixture
    {
        [UnityTest] public IEnumerator InitialAndRepeatedInitialization()
        {
            Assert.IsTrue(Manager.IsInitialized); Assert.AreEqual("en", LocalizationManager.GetCurrentLanguageCode());
            yield return Await(Manager.InitLocalization()); Assert.IsTrue(Manager.IsInitialized);
            CollectionAssert.AreEquivalent(new[] { "en", "ko" }, LocalizationSettings.AvailableLocales.Locales.ConvertAll(l => l.Identifier.Code));
        }
        [UnityTest] public IEnumerator NativeSdkStringLookupAndFallbackBranches()
        {
            Assert.AreEqual("EN fixture", LocalizationManager.GetLoc("step23", "hello"));
            Assert.AreEqual("KO fixture", LocalizationManager.GetLocByLocale("step23", "hello", "ko"));
            Assert.AreEqual("EN fixture", LocalizationManager.GetEnglishLoc("step23", "hello"));
            Assert.AreEqual("", LocalizationManager.GetLoc("step23", ""));
            Assert.AreEqual("step23/missing", LocalizationManager.GetLoc("step23", "missing"));
            Assert.AreEqual("", LocalizationManager.GetLoc("step23", "missing", false));
            Assert.AreEqual("step23/empty", LocalizationManager.GetLoc("step23", "empty"));
            Assert.AreEqual("", LocalizationManager.GetLoc("step23", "empty", false));
            Assert.AreEqual("key", LocalizationManager.GetLoc("", "key", false));
            Assert.AreEqual("", LocalizationManager.GetLocByLocale("", "key", "en", false));
            Assert.AreEqual("EN fixture", LocalizationManager.GetLocByLocale("step23", "hello", "zz-ZZ"));
            yield return null;
        }
        [UnityTest] public IEnumerator SystemLanguageAndCodeAndDisplayName()
        {
            Assert.AreEqual("ko", LocalizationManager.GetLanguageCode(SystemLanguage.Korean));
            Assert.AreEqual("ko", LocalizationManager.NormalizeLanguageCode(null));
            Assert.AreEqual("Fixture Korean", LocalizationManager.GetLanguageDisplayName("ko"));
            yield return Await(Manager.SetLanguage(SystemLanguage.Korean));
            Assert.AreEqual("ko", Saved); Assert.AreEqual("KO fixture", LocalizationManager.GetLoc("step23", "hello"));
            yield return Await(Manager.SetLanguage("not-supported", false));
            Assert.AreEqual("en", LocalizationManager.GetCurrentLanguageCode()); Assert.AreEqual("ko", Saved);
        }
        [UnityTest] public IEnumerator SaveThenLocaleThenCacheThenEventAndSaveFailure()
        {
            var order = new List<string>(); int events = 0;
            LocalizationRuntimeOptions.SaveLanguage = code => { order.Add("save"); Assert.AreEqual("en", LocalizationManager.GetCurrentLanguageCode()); Saved = code; };
            LocalizationRuntimeOptions.InvalidateLocalizedContentCaches = () => { order.Add("cache"); Assert.AreEqual("ko", LocalizationManager.GetCurrentLanguageCode()); };
            Action<LocalizationEvent> listener = e => { events++; order.Add("event"); Assert.AreEqual(LocalizationEventTypes.ChangeLanguage, e.EventType); };
            LocalizationEvent.Published += listener;
            try
            {
                yield return Await(Manager.SetLanguage("ko"));
                CollectionAssert.AreEqual(new[] { "save", "cache", "event" }, order); Assert.AreEqual(1, events);
                LocalizationRuntimeOptions.SaveLanguage = code => throw new InvalidOperationException("fixture save failure");
                var task = Manager.SetLanguage("en").AsTask(); while (!task.IsCompleted) yield return null;
                Assert.IsTrue(task.IsFaulted); Assert.AreEqual("ko", Saved); Assert.AreEqual("ko", LocalizationManager.GetCurrentLanguageCode()); Assert.AreEqual(1, events);
            }
            finally { LocalizationEvent.Published -= listener; }
        }
        [UnityTest] public IEnumerator ExplicitSameLocaleRetainsOriginalPerCallEventMeaning()
        {
            int events = 0, caches = 0;
            Action<LocalizationEvent> handler = e => events++;
            LocalizationEvent.Published += handler;
            LocalizationRuntimeOptions.InvalidateLocalizedContentCaches = () => caches++;
            try { yield return Await(Manager.SetLanguage("en", false)); Assert.AreEqual(1, events); Assert.AreEqual(0, caches); }
            finally { LocalizationEvent.Published -= handler; }
        }
        [UnityTest] public IEnumerator InitializationFailureRemainsFalseAndCanRetry()
        {
            Object.DestroyImmediate(Manager.gameObject);
            Manager = new GameObject("retry").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
            LocalizationRuntimeOptions.ReadLanguage = () => throw new InvalidOperationException("fixture options unavailable");
            var task = Manager.InitLocalization().AsTask(); while (!task.IsCompleted) yield return null;
            Assert.IsTrue(task.IsFaulted); Assert.IsFalse(Manager.IsInitialized);
            LocalizationRuntimeOptions.ReadLanguage = () => "en";
            yield return Await(Manager.InitLocalization()); Assert.IsTrue(Manager.IsInitialized);
        }
        [UnityTest] public IEnumerator ConcurrentInitializationPublishesOnce()
        {
            Object.DestroyImmediate(Manager.gameObject);
            Manager = new GameObject("concurrent").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
            int events = 0; Action<LocalizationEvent> listener = e => events++;
            LocalizationEvent.Published += listener;
            try
            {
                var one = Manager.InitLocalization().AsTask(); var two = Manager.InitLocalization().AsTask();
                while (!one.IsCompleted || !two.IsCompleted) yield return null;
                one.GetAwaiter().GetResult(); two.GetAwaiter().GetResult();
                Assert.AreEqual(1, events, "Concurrent initialization must share one initialization transaction");
            }
            finally { LocalizationEvent.Published -= listener; }
        }
        [UnityTest] public IEnumerator DestroyedInitializerCannotPublishSuccess()
        {
            Object.DestroyImmediate(Manager.gameObject);
            Manager = new GameObject("destroy while loading").AddComponent<LocalizationManager>();
            var old = Manager; var task = old.InitLocalization().AsTask();
            Object.DestroyImmediate(old.gameObject);
            while (!task.IsCompleted) yield return null;
            if (task.IsFaulted) Assert.IsInstanceOf<OperationCanceledException>(task.Exception.InnerException);
            Assert.IsFalse(old.IsInitialized, "A destroyed initializer must not publish successful initialization");
            Manager = new GameObject("replacement").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
            yield return Await(Manager.InitLocalization()); Assert.IsTrue(Manager.IsInitialized);
        }
        [UnityTest] public IEnumerator RepeatedContentResetReloadRestoresLocale()
        {
            yield return Await(Manager.SetLanguage("ko"));
            for (int i = 0; i < 3; i++)
            {
                yield return Await(Manager.PrepareForContentUpdateAsync(default)); Assert.IsFalse(Manager.IsInitialized);
                yield return Await(Manager.ReloadLocalization()); Assert.IsTrue(Manager.IsInitialized);
                Assert.AreEqual("KO fixture", LocalizationManager.GetLoc("step23", "hello"));
            }
        }
        [UnityTest] public IEnumerator NewExplicitLocaleIsNotOverwrittenByOlderInitialization()
        {
            Object.DestroyImmediate(Manager.gameObject);
            Manager = new GameObject("locale race").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
            var initialization = Manager.InitLocalization().AsTask();
            yield return Await(Manager.SetLanguage("ko", false));
            while (!initialization.IsCompleted) yield return null;
            initialization.GetAwaiter().GetResult();
            Assert.AreEqual("ko", LocalizationManager.GetCurrentLanguageCode(), "Older initialization must not overwrite a newer explicit locale request");
        }
        [UnityTest] public IEnumerator MissingCollectionRetainsUserFacingFallbackWithExpectedSdkFailure()
        {
            var prior = UnityEngine.ResourceManagement.ResourceManager.ExceptionHandler;
            var errors = new List<Exception>();
            UnityEngine.ResourceManagement.ResourceManager.ExceptionHandler = (handle, error) =>
            {
                if (error.ToString().Contains("step23-no-such-collection")) errors.Add(error);
                else prior?.Invoke(handle, error);
            };
            try
            {
                Assert.AreEqual("step23-no-such-collection/hello", LocalizationManager.GetLoc("step23-no-such-collection", "hello"));
                Assert.AreEqual("", LocalizationManager.GetLoc("step23-no-such-collection", "hello", false));
                Assert.IsTrue(errors.Count > 0, "A genuinely absent SDK collection must use the failed lookup path");
                yield return null;
            }
            finally { UnityEngine.ResourceManagement.ResourceManager.ExceptionHandler = prior; }
        }
    }
}
//추가 종료
