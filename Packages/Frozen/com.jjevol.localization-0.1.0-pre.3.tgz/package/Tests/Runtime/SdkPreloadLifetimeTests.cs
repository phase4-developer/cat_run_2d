//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.Localization.Tables;
using UnityEngine.Localization.Settings;
using UnityEngine.ResourceManagement;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Step23.Tests
{
    // Test-only delay/failure injection around an actual native SDK asset load, never a substitute StringTable.
    internal sealed class NativePreloadGate : ResourceProviderBase, IResourceLocator, IDisposable
    {
        private readonly List<IResourceLocator> _originals;
        private readonly IResourceLocation _native;
        private readonly IResourceLocation _wrapped;
        private ProvideHandle _provide;
        private AsyncOperationHandle<StringTable> _nativeHandle;
        private bool _provided, _open, _completed;
        public bool Failure;
        public bool PreloadForSdk;
        public IResourceLocation SdkFailureLocation;
        public int Acquired, Released;
        public readonly List<string> Requested = new List<string>();
        public string LocatorId => "STEP23 native preload delay";
        public IEnumerable<object> Keys => _originals.SelectMany(x => x.Keys);
        public IEnumerable<IResourceLocation> AllLocations => _originals.SelectMany(x => x.AllLocations).Concat(new[] { _wrapped });
        public bool HasPending => _provided && !_completed;
        public override string ProviderId { get; } = "Step23NativeGate-" + Guid.NewGuid().ToString("N");

        public NativePreloadGate(IResourceLocation native)
        {
            _native = native;
            _originals = Addressables.ResourceLocators.ToList();
            _wrapped = new ResourceLocationBase(ProviderId, ProviderId, ProviderId, typeof(StringTable));
            foreach (var locator in _originals) Addressables.RemoveResourceLocator(locator);
            Addressables.AddResourceLocator(this);
            Addressables.ResourceManager.ResourceProviders.Add(this);
        }
        public bool Locate(object key, Type type, out IList<IResourceLocation> locations)
        {
            Requested.Add(key + ":" + type?.Name);
            // SDK 1.5.12 intersects its "Preload" and "Locale-en" StringTable labels.
            if (PreloadForSdk && (Equals(key, "Preload") || Equals(key, "Locale-en")) && type == typeof(AssetTable))
            { locations = new List<IResourceLocation> { SdkFailureLocation }; return true; }
            if (Equals(key, "Localization") && (type == null || type == typeof(StringTable)))
            { locations = new List<IResourceLocation> { _wrapped }; return true; }
            foreach (var locator in _originals) if (locator.Locate(key, type, out locations)) return true;
            locations = null; return false;
        }
        public override void Provide(ProvideHandle handle)
        {
            _provide = handle; _provided = true;
            _nativeHandle = Addressables.LoadAssetAsync<StringTable>(_native); Acquired++;
            _nativeHandle.Completed += _ => TryComplete();
            TryComplete();
        }
        public void Open() { _open = true; TryComplete(); }
        private void TryComplete()
        {
            if (!_open || !_provided || _completed || !_nativeHandle.IsDone) return;
            _completed = true;
            if (Failure)
            {
                // A failed custom provider must return its own nested acquisition; SDK Release is only for successful provision.
                if (_nativeHandle.IsValid()) { Addressables.Release(_nativeHandle); Released++; }
                _provide.Complete<StringTable>(null, false, new InvalidOperationException("STEP23 expected native preload gate failure"));
            }
            else _provide.Complete(_nativeHandle.Result, _nativeHandle.Status == AsyncOperationStatus.Succeeded, _nativeHandle.OperationException);
        }
        public override void Release(IResourceLocation location, object asset)
        {
            if (_nativeHandle.IsValid()) { Addressables.Release(_nativeHandle); Released++; }
        }
        public void Dispose()
        {
            Open();
            Addressables.RemoveResourceLocator(this);
            foreach (var locator in _originals) Addressables.AddResourceLocator(locator);
            Addressables.ResourceManager.ResourceProviders.Remove(this);
        }
    }
    public sealed class SdkPreloadLifetimeTests : LocalizationTestFixture
    {
        private static IEnumerator Pending(NativePreloadGate gate)
        {
            float end = Time.realtimeSinceStartup + 5;
            while (!gate.HasPending && Time.realtimeSinceStartup < end) yield return null;
            Assert.IsTrue(gate.HasPending, "The real SDK provider must actually be pending");
        }
        [UnityTest] public IEnumerator DestroyDuringNativePreloadRejectsLateCompletionAndReturnsHandle()
        {
            var locations = Addressables.LoadResourceLocationsAsync("Localization", typeof(StringTable)); yield return locations;
            var native = locations.Result[0]; Addressables.Release(locations);
            Object.DestroyImmediate(Manager.gameObject);
            using (var gate = new NativePreloadGate(native))
            {
                Manager = new GameObject("native delayed init").AddComponent<LocalizationManager>();
                var old = Manager; var pending = old.InitLocalization().AsTask(); yield return Pending(gate);
                Object.DestroyImmediate(old.gameObject);
                while (!pending.IsCompleted) yield return null;
                // UniTask 2.5.10 AsTask reports asynchronous OCE as Faulted; assert the API's actual cancellation exception.
                Assert.Catch<OperationCanceledException>(() => pending.GetAwaiter().GetResult()); Assert.IsFalse(old.IsInitialized);
                Manager = new GameObject("replacement during native callback").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
                Saved = "ko"; yield return Await(Manager.SetLanguage("ko", false));
                gate.Open();
                float end = Time.realtimeSinceStartup + 5;
                while (gate.Released < gate.Acquired && Time.realtimeSinceStartup < end) yield return null;
                Assert.AreEqual(1, gate.Acquired); Assert.AreEqual(gate.Acquired, gate.Released);
                Assert.AreEqual("ko", LocalizationManager.GetCurrentLanguageCode()); Assert.IsFalse(old.IsInitialized);
            }
            yield return Await(Manager.InitLocalization()); Assert.AreEqual("KO fixture", LocalizationManager.GetLoc("step23", "hello"));
        }
        [UnityTest] public IEnumerator FailedNativePreloadDoesNotInitializeAndCanRetry()
        {
            var locations = Addressables.LoadResourceLocationsAsync("Localization", typeof(StringTable)); yield return locations;
            var native = locations.Result[0]; Addressables.Release(locations);
            Object.DestroyImmediate(Manager.gameObject);
            var errors = new List<Exception>(); var previous = ResourceManager.ExceptionHandler;
            ResourceManager.ExceptionHandler = (handle, error) => errors.Add(error);
            try
            {
                using (var gate = new NativePreloadGate(native) { Failure = true })
                {
                    Manager = new GameObject("native failure").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
                    var pending = Manager.InitLocalization().AsTask(); yield return Pending(gate); gate.Open();
                    while (!pending.IsCompleted) yield return null;
                    Assert.IsTrue(pending.IsFaulted, "status=" + pending.Status + ",initialized=" + Manager.IsInitialized + ",sdk=" + LocalizationSettings.InitializationOperation.Status + ",errors=" + string.Join(" | ", errors.Select(e => e.ToString()))); Assert.IsFalse(Manager.IsInitialized);
                    Assert.IsTrue(errors.Any(e => e.ToString().Contains("STEP23 expected native preload gate failure")));
                    Assert.AreEqual(1, gate.Acquired); Assert.AreEqual(1, gate.Released);
                }
                yield return Await(Manager.InitLocalization()); Assert.IsTrue(Manager.IsInitialized);
                Assert.IsTrue(errors.All(e => e.ToString().Contains("STEP23 expected native preload gate failure")), "No unrelated SDK errors may be hidden");
            }
            finally { ResourceManager.ExceptionHandler = previous; }
        }
        [UnityTest] public IEnumerator CallerCancellationDoesNotReleaseAnotherCallersSharedInitialization()
        {
            Object.DestroyImmediate(Manager.gameObject);
            Manager = new GameObject("shared waiter cancellation").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
            using (var cancellation = new CancellationTokenSource())
            {
                var first = Manager.InitLocalization(cancellation.Token).AsTask(); var other = Manager.InitLocalization().AsTask(); cancellation.Cancel();
                while (!first.IsCompleted || !other.IsCompleted) yield return null;
                Assert.Catch<OperationCanceledException>(() => first.GetAwaiter().GetResult()); other.GetAwaiter().GetResult(); Assert.IsTrue(Manager.IsInitialized);
            }
        }
        [UnityTest] public IEnumerator TwentySdkResetReloadsKeepLookupsAndOwnedPreloadBalanced()
        {
            var locations = Addressables.LoadResourceLocationsAsync("Localization", typeof(StringTable)); yield return locations;
            var native = locations.Result[0]; Addressables.Release(locations);
            for (int i = 0; i < 20; i++)
            {
                yield return Await(Manager.SetLanguage(i % 2 == 0 ? "ko" : "en", false));
                string expected = LocalizationManager.GetCurrentLanguageCode();
                yield return Await(Manager.PrepareForContentUpdateAsync(default)); Assert.IsFalse(Manager.IsInitialized);
                using (var gate = new NativePreloadGate(native))
                {
                    var pending = Manager.ReloadLocalization().AsTask(); yield return Pending(gate); gate.Open();
                    while (!pending.IsCompleted) yield return null;
                    pending.GetAwaiter().GetResult(); Assert.IsTrue(Manager.IsInitialized);
                    Assert.AreEqual(1, gate.Acquired); Assert.AreEqual(1, gate.Released, "Every owned native preload must be returned");
                }
                Assert.AreEqual(expected, LocalizationManager.GetCurrentLanguageCode());
                Assert.AreEqual(expected == "ko" ? "KO fixture" : "EN fixture", LocalizationManager.GetLoc("step23", "hello"));
            }
        }
        [UnityTest] public IEnumerator ContentResetDuringPreloadAndImmediateReinitializeUseNewSdkGeneration()
        {
            var locations = Addressables.LoadResourceLocationsAsync("Localization", typeof(StringTable)); yield return locations;
            var native = locations.Result[0]; Addressables.Release(locations);
            Object.DestroyImmediate(Manager.gameObject);
            using (var gate = new NativePreloadGate(native))
            {
                Manager = new GameObject("reset race").AddComponent<LocalizationManager>(); Objects.Add(Manager.gameObject);
                var old = Manager.InitLocalization().AsTask(); yield return Pending(gate);
                var reset = Manager.PrepareForContentUpdateAsync(default).AsTask();
                var fresh = Manager.InitLocalization().AsTask();
                while (!reset.IsCompleted) yield return null;
                reset.GetAwaiter().GetResult(); gate.Open();
                while (!old.IsCompleted || !fresh.IsCompleted) yield return null;
                Assert.Catch<OperationCanceledException>(() => old.GetAwaiter().GetResult());
                fresh.GetAwaiter().GetResult(); Assert.IsTrue(Manager.IsInitialized);
                Assert.AreEqual("EN fixture", LocalizationManager.GetLoc("step23", "hello"));
                Assert.AreEqual(gate.Acquired, gate.Released);
            }
        }
        [UnityTest] public IEnumerator ActualSdkInitializationFailureStaysUninitializedAndRetriesAfterReset()
        {
            var locations = Addressables.LoadResourceLocationsAsync("Localization", typeof(StringTable)); yield return locations;
            var native = locations.Result[0]; Addressables.Release(locations);
            var brokenLocations = Addressables.LoadResourceLocationsAsync("Step23/BrokenSdkTable/en", typeof(AssetTable)); yield return brokenLocations;
            Assert.AreEqual(1, brokenLocations.Result.Count); var broken = brokenLocations.Result[0]; Addressables.Release(brokenLocations);
            yield return Await(Manager.PrepareForContentUpdateAsync(default));
            var errors = new List<Exception>(); var previous = ResourceManager.ExceptionHandler;
            ResourceManager.ExceptionHandler = (handle, error) => errors.Add(error);
            try
            {
                using (var missing = new NativePreloadGate(native) { PreloadForSdk = true, SdkFailureLocation = broken })
                {
                    LocalizationSettings.PreloadBehavior = PreloadBehavior.PreloadSelectedLocale;
                    ((IDisposable)LocalizationSettings.Instance).Dispose();
                    LocalizationSettings.Instance.ResetState();
                    missing.Open();
                    var pending = Manager.InitLocalization().AsTask();
                    float deadline = Time.realtimeSinceStartup + 10;
                    while (!pending.IsCompleted && Time.realtimeSinceStartup < deadline) yield return null;
                    Assert.IsTrue(pending.IsCompleted, "SDK initialization failure must terminate its awaiter");
                    Assert.IsTrue(pending.IsFaulted, "status=" + pending.Status + ",initialized=" + Manager.IsInitialized + ",sdk=" + LocalizationSettings.InitializationOperation.Status + ",errors=" + string.Join(" | ", errors.Select(e => e.ToString())) + ",keys=" + string.Join(",", missing.Requested)); Assert.IsFalse(Manager.IsInitialized);
                    // Preserve the observed SDK bug as evidence; the Manager must reject the actual failed child preload.
                    Assert.AreEqual(AsyncOperationStatus.Succeeded, LocalizationSettings.InitializationOperation.Status, string.Join(",", missing.Requested));
                    Assert.IsTrue(errors.Any(e => e.ToString().Contains("00000000000000000000000000000023")));
                }
                yield return Await(Manager.PrepareForContentUpdateAsync(default));
                yield return Await(Manager.ReloadLocalization()); Assert.IsTrue(Manager.IsInitialized);
                Assert.AreEqual("EN fixture", LocalizationManager.GetLoc("step23", "hello"));
                Assert.IsTrue(errors.All(e => e.ToString().Contains("00000000000000000000000000000023")), "No unrelated SDK errors may be hidden");
            }
            finally { ResourceManager.ExceptionHandler = previous; }
        }
        [UnityTest] public IEnumerator PreCancelledResetDoesNotDisposeInitializedSdk()
        {
            using (var cancellation = new CancellationTokenSource())
            {
                cancellation.Cancel(); var pending = Manager.PrepareForContentUpdateAsync(cancellation.Token).AsTask();
                while (!pending.IsCompleted) yield return null;
                Assert.Catch<OperationCanceledException>(() => pending.GetAwaiter().GetResult());
                Assert.IsTrue(Manager.IsInitialized); Assert.AreEqual("EN fixture", LocalizationManager.GetLoc("step23", "hello"));
            }
        }
    }
}
//추가 종료
