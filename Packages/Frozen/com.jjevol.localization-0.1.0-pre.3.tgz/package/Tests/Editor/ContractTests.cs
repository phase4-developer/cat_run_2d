//추가
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Step23.Tests.Editor
{
    public sealed class FixturePrebuild : IPrebuildSetup { public void Setup() => FixtureSetup.Prepare(); }
    public sealed class ContractTests
    {
        [Test] public void PreservedScriptGuidsResolveToOriginalTypes()
        {
            foreach (var pair in new[] {
                ("96635fa2adbd73d45ad36dac23e7727b", typeof(LocalizationManager)),
                ("5beb6f6c477480148a6eef02f804712b", typeof(LocalizeTmpTextEvent)) })
            {
                string path = AssetDatabase.GUIDToAssetPath(pair.Item1);
                Assert.IsTrue(path.StartsWith("Packages/com.jjevol.localization/"), path);
                Assert.AreEqual(pair.Item2, AssetDatabase.LoadAssetAtPath<MonoScript>(path).GetClass());
            }
        }
        [Test] public void OriginalSerializedFieldsRoundTrip()
        {
            FixtureSetup.Prepare();
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(FixtureSetup.Root + "/Resources/FixtureText.prefab");
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            try
            {
                var text = instance.GetComponent<LocalizeTmpTextEvent>();
                var serialized = new SerializedObject(text);
                foreach (string field in new[] { "updateText", "resolveMode", "m_StringReference", "tableCollection", "entryKey", "showDebugKeyWhenMissing", "previewInEditMode", "previewManualKeyInEditMode" })
                    Assert.NotNull(serialized.FindProperty(field), field);
                text.SetManualReference("step23", "hello", false); text.SetUpdateText(true, false);
                var clone = new GameObject("roundtrip", typeof(RectTransform)); clone.SetActive(false);
                try
                {
                    var target = clone.AddComponent<LocalizeTmpTextEvent>();
                    EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(text), target);
                    Assert.AreEqual("step23", target.TableCollection); Assert.AreEqual("hello", target.EntryKey); Assert.IsTrue(target.UpdateText);
                }
                finally { UnityEngine.Object.DestroyImmediate(clone); }
            }
            finally { UnityEngine.Object.DestroyImmediate(instance); }
        }
        [Test] public void OriginalPublicMethodsAndAssemblyIdentityArePresent()
        {
            var names = typeof(LocalizationManager).GetMethods().Select(x => x.Name).ToArray();
            foreach (string name in new[] { "InitLocalization", "SetLanguage", "GetLoc", "GetLocByLocale", "GetEnglishLoc", "PrepareForContentUpdateAsync", "ReloadLocalization", "GetCurrentLanguageCode", "ToLanguageCode", "GetLanguageDisplayName" })
                CollectionAssert.Contains(names, name);
            Assert.AreEqual("JJEvol.Localization.Runtime", typeof(LocalizationManager).Assembly.GetName().Name);
            Assert.AreEqual("", typeof(LocalizeTmpTextEvent).Namespace ?? "");
            Assert.AreEqual("jjevol", typeof(LocalizationManager).Namespace);
            Assert.AreEqual(typeof(LocalizationEventTypes), typeof(LocalizationEvent).GetField("EventType").FieldType);
        }
        [Test] public void RuntimeAssemblyHasNoGameOrVendorDependency()
        {
            var names = typeof(LocalizationManager).Assembly.GetReferencedAssemblies().Select(x => x.Name).ToArray();
            foreach (string word in new[] { "MoreMountains", "Firebase", "Economy", "UI.Addressables", "Google" })
                Assert.IsFalse(names.Any(n => n.Contains(word)), word);
        }
    }
}
//추가 종료
