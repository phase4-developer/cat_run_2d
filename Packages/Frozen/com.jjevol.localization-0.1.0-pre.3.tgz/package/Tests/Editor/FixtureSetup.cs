//추가
using System;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.Localization;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.Localization.Tables;
using Object = UnityEngine.Object;

namespace jjevol.Step23.Tests.Editor
{
    public static class FixtureSetup
    {
        public const string Root = "Assets/Step23Fixture";
        public static void Guard()
        {
            string assets = Path.GetFullPath(Application.dataPath).Replace('\\', '/');
            if (!assets.Contains("/.local/step23/") && !assets.Contains("/.local/validation-current/") && !assets.Contains("/.local/qa/Hosts/CombinedValidationHost/"))
                throw new InvalidOperationException("Only new STEP23 isolated Hosts may author fixtures");
        }
        public static void ImportTMP()
        {
            Guard();
            if (Shader.Find("TextMeshPro/Mobile/Distance Field") != null) { EditorApplication.Exit(0); return; }
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TMP_Text).Assembly);
            AssetDatabase.ImportPackage(Path.Combine(package.resolvedPath, "Package Resources", "TMP Essential Resources.unitypackage"), false);
            double end = EditorApplication.timeSinceStartup + 120;
            EditorApplication.CallbackFunction finish = null;
            finish = () =>
            {
                if (Shader.Find("TextMeshPro/Mobile/Distance Field") != null && !EditorApplication.isUpdating && !EditorApplication.isCompiling)
                { EditorApplication.update -= finish; EditorApplication.Exit(0); }
                else if (EditorApplication.timeSinceStartup > end) { EditorApplication.update -= finish; EditorApplication.Exit(1); }
            };
            EditorApplication.update += finish;
        }
        public static void PrepareAndExit()
        {
            try { Prepare(); EditorApplication.Exit(0); }
            catch (Exception ex) { Debug.LogException(ex); EditorApplication.Exit(1); }
        }
        public static void PackAndExit()
        {
            try
            {
                Guard(); Prepare();
                var settings = AddressableAssetSettingsDefaultObject.Settings;
                AddressableAssetSettings.BuildPlayerContent(out UnityEditor.AddressableAssets.Build.AddressablesPlayerBuildResult result);
                if (!string.IsNullOrEmpty(result.Error)) throw new InvalidOperationException(result.Error);
                bool found = false;
                for (int i = 0; i < settings.DataBuilders.Count; i++)
                    if (settings.DataBuilders[i] is BuildScriptPackedPlayMode) { settings.ActivePlayModeDataBuilderIndex = i; found = true; }
                if (!found) throw new InvalidOperationException("Actual SDK packed PlayMode builder missing");
                EditorUtility.SetDirty(settings); AssetDatabase.SaveAssets(); EditorApplication.Exit(0);
            }
            catch (Exception ex) { Debug.LogException(ex); EditorApplication.Exit(1); }
        }
        public static void Prepare()
        {
            Guard();
            if (AssetDatabase.IsValidFolder(Root))
            {
                var existing = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(Root + "/Addressables/Settings.asset");
                if (!existing || !AssetDatabase.LoadAssetAtPath<GameObject>(Root + "/Resources/FixtureText.prefab"))
                    throw new InvalidOperationException("Incomplete fixture; refuse overwrite");
                EnsureFailureFixture(existing);
                AddressableAssetSettingsDefaultObject.Settings = existing;
                SetRuntimePath(existing);
                return;
            }
            Directory.CreateDirectory(Root + "/Addressables");
            Directory.CreateDirectory(Root + "/Tables");
            Directory.CreateDirectory(Root + "/Resources");
            AssetDatabase.Refresh();
            var settings = AddressableAssetSettings.Create(Root + "/Addressables", "Settings", true, true);
            AddressableAssetSettingsDefaultObject.Settings = settings;
            for (int i = 0; i < settings.DataBuilders.Count; i++)
                if (settings.DataBuilders[i] is BuildScriptFastMode) settings.ActivePlayModeDataBuilderIndex = i;
            var localization = ScriptableObject.CreateInstance<LocalizationSettings>();
            AssetDatabase.CreateAsset(localization, Root + "/LocalizationSettings.asset");
            LocalizationSettings.Instance = localization;
            LocalizationEditorSettings.ActiveLocalizationSettings = localization;
            var ko = Locale.CreateLocale("ko"); var en = Locale.CreateLocale("en");
            AssetDatabase.CreateAsset(ko, Root + "/ko.asset"); AssetDatabase.CreateAsset(en, Root + "/en.asset");
            LocalizationEditorSettings.AddLocale(ko); LocalizationEditorSettings.AddLocale(en);
            LocalizationSettings.StartupLocaleSelectors.Clear();
            LocalizationSettings.StartupLocaleSelectors.Add(new SpecificLocaleSelector { LocaleId = new LocaleIdentifier("en") });
            var strings = LocalizationEditorSettings.CreateStringTableCollection("step23", Root + "/Tables");
            var names = LocalizationEditorSettings.CreateStringTableCollection("appInfo", Root + "/Tables");
            foreach (var table in strings.StringTables)
            {
                bool korean = table.LocaleIdentifier.Code == "ko";
                table.AddEntry("hello", korean ? "KO fixture" : "EN fixture");
                table.AddEntry("empty", "");
                table.AddEntry("echo", "echo");
                table.AddEntry("FixtureText", korean ? "KO object" : "EN object");
                table.AddEntry("ui", korean ? "KO ui" : "EN ui");
                EditorUtility.SetDirty(table);
            }
            foreach (var table in names.StringTables)
            {
                table.AddEntry("LanguageDisplayName", table.LocaleIdentifier.Code == "ko" ? "Fixture Korean" : "Fixture English");
                EditorUtility.SetDirty(table);
            }
            strings.RefreshAddressables(); names.RefreshAddressables();
            EnsureFailureFixture(settings);
            settings.AddLabel("Localization");
            foreach (var collection in new[] { strings, names })
                foreach (var table in collection.StringTables)
                    settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(table))).SetLabel("Localization", true);
            var text = new GameObject("FixtureText", typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            text.SetActive(false);
            text.AddComponent<LocalizeTmpTextEvent>();
            PrefabUtility.SaveAsPrefabAsset(text, Root + "/Resources/FixtureText.prefab"); Object.DestroyImmediate(text);
            EditorUtility.SetDirty(localization); EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
            SetRuntimePath(settings);
        }
        private static void SetRuntimePath(AddressableAssetSettings settings)
        {
            bool packed = settings.DataBuilders[settings.ActivePlayModeDataBuilderIndex] is BuildScriptPackedPlayMode;
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, packed
                ? "{UnityEngine.AddressableAssets.Addressables.RuntimePath}/settings.json"
                : "GUID:" + AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
        }
        private static void EnsureFailureFixture(AddressableAssetSettings settings)
        {
            var broken = LocalizationEditorSettings.GetAssetTableCollection("step23-broken");
            if (!broken)
            {
                broken = LocalizationEditorSettings.CreateAssetTableCollection("step23-broken", Root + "/Tables");
                foreach (var table in broken.AssetTables)
                {
                    table.AddEntry("deliberately-missing", "00000000000000000000000000000023");
                    EditorUtility.SetDirty(table);
                }
                broken.RefreshAddressables();
            }
            foreach (var table in broken.AssetTables)
                settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(table)), settings.DefaultGroup).address = "Step23/BrokenSdkTable/" + table.LocaleIdentifier.Code;
            EditorUtility.SetDirty(settings); AssetDatabase.SaveAssets();
        }
    }
}
//추가 종료
