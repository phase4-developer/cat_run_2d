using jjevol.Audio;
using System;
using UnityEngine;

namespace jjevol
{
    public enum AudioEventPlayerTrack
    {
        Sfx,
        UI,
        Voice,
        Music
    }

    public enum AudioEventPlayerAutoTiming
    {
        Awake,
        OnEnable,
        Start
    }

    public interface IAudioEventPlayable
    {
        void Play();
    }

    [DisallowMultipleComponent]
    [AddComponentMenu("jjevol/Audio/Audio Event Player")]
    public class AudioEventPlayer : MonoBehaviour, IAudioEventPlayable
    {
        [Header("Sound")]
        [SerializeField] private AudioEventPlayerTrack track = AudioEventPlayerTrack.UI;
        [SerializeField] private string key;
        // Keep the original serialized integer for explicit legacy prefab migration.
        [SerializeField, HideInInspector] private int soundType;

        [Header("Auto Play")]
        [SerializeField] private bool autoPlay = true;
        [SerializeField] private AudioEventPlayerAutoTiming autoTiming = AudioEventPlayerAutoTiming.OnEnable;

        [Tooltip("자동 재생만 1회로 제한합니다. 수동 Play 호출은 항상 재생됩니다.")]
        [SerializeField] private bool autoPlayOnlyOnce = false;

        private bool _autoPlayed;

        [Obsolete("The game-specific SoundType was removed. Use Key or SetSoundType with a registered enum.")]
        public int SoundType => soundType;
        public string Key => key;
        public AudioEventPlayerTrack Track => track;

        private void Awake()
        {
            TryAutoPlay(AudioEventPlayerAutoTiming.Awake);
        }

        private void OnEnable()
        {
            TryAutoPlay(AudioEventPlayerAutoTiming.OnEnable);
        }

        private void Start()
        {
            TryAutoPlay(AudioEventPlayerAutoTiming.Start);
        }

        private void TryAutoPlay(AudioEventPlayerAutoTiming timing)
        {
            if (!autoPlay)
                return;

            if (autoTiming != timing)
                return;

            if (autoPlayOnlyOnce && _autoPlayed)
                return;

            if (PlayInternal(track, key))
                _autoPlayed = true;
        }

        /// <summary>
        /// Animation Event / UnityEvent / 코드에서 직접 호출하는 기본 재생 함수.
        /// </summary>
        public void Play()
        {
            PlayInternal(track, key);
        }

        /// <summary>
        /// Animation Event에서 함수명이 더 명확하게 보이게 하고 싶을 때 사용.
        /// </summary>
        public void PlaySound(string soundKey)
        {
            switch (track)
            {
                case AudioEventPlayerTrack.Sfx:
                    AudioEvents.PlaySfx.Trigger(soundKey);
                    break;

                case AudioEventPlayerTrack.UI:
                    AudioEvents.PlayUI.Trigger(soundKey);
                    break;

                case AudioEventPlayerTrack.Voice:
                    AudioEvents.PlayVoice.Trigger(soundKey);
                    break;

                case AudioEventPlayerTrack.Music:
                    AudioEvents.PlayMusic.Trigger(soundKey);
                    break;
            }
        }

        public void PlaySfx()
        {
            PlayInternal(AudioEventPlayerTrack.Sfx, key);
        }

        public void PlayUI()
        {
            PlayInternal(AudioEventPlayerTrack.UI, key);
        }

        public void PlayVoice()
        {
            PlayInternal(AudioEventPlayerTrack.Voice, key);
        }

        public void PlayMusic()
        {
            PlayInternal(AudioEventPlayerTrack.Music, key);
        }

        public void ResetAutoPlayed()
        {
            _autoPlayed = false;
        }

        public void SetSoundType(Enum value) => key = AudioKeys.Get(value);

        public void SetKey(string value) => key = value;

        public void SetTrack(AudioEventPlayerTrack track)
        {
            this.track = track;
        }

        private bool PlayInternal(AudioEventPlayerTrack targetTrack, string sound)
        {
            if (string.IsNullOrWhiteSpace(sound))
                return false;

            switch (targetTrack)
            {
                case AudioEventPlayerTrack.Sfx:
                    AudioEvents.PlaySfx.Trigger(sound);
                    break;

                case AudioEventPlayerTrack.UI:
                    AudioEvents.PlayUI.Trigger(sound);
                    break;

                case AudioEventPlayerTrack.Voice:
                    AudioEvents.PlayVoice.Trigger(sound);
                    break;

                case AudioEventPlayerTrack.Music:
                    AudioEvents.PlayMusic.Trigger(sound);
                    break;
            }

            return true;
        }
    }
}
