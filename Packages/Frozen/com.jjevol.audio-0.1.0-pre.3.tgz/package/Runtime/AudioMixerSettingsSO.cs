using System;
using UnityEngine;
using UnityEngine.Audio;

namespace jjevol.Audio
{
    [CreateAssetMenu(menuName = "jjevol/Audio/AudioMixerSettings")]
    public class AudioMixerSettingsSO : ScriptableObject
    {
        [Header("Mixer & Groups")]
        public AudioMixer mixer;
        public AudioMixerGroup masterGroup;
        public AudioMixerGroup musicGroup;
        public AudioMixerGroup sfxGroup;
        public AudioMixerGroup uiGroup;
        public AudioMixerGroup voiceGroup;

        [Header("Exposed Parameter Names (must match mixer)")]
        public string masterParam = "MasterVolume";
        public string musicParam = "MusicVolume";
        public string sfxParam = "SfxVolume";
        public string uiParam = "UIVolume";
        public string voiceParam = "VoiceVolume";

        [Header("Behavior")]
        public bool autoLoadOnStart = true;
        public bool autoSaveOnChange = false;

        [Serializable]
        public struct Snapshot
        {
            public float master; public bool masterOn;
            public float music; public bool musicOn;
            public float sfx; public bool sfxOn;
            public float ui; public bool uiOn;
            public float voice; public bool voiceOn;
        }

        const string PlayerPrefsKey = "jjevol.audio.mixer.settings";

        public static float NormToDb(float norm)
        {
            norm = Mathf.Clamp(norm, 0.0001f, 10f);
            return Mathf.Log10(norm) * 20f;
        }
        public static float DbToNorm(float db) => Mathf.Pow(10f, db / 20f);

        public void Apply(Snapshot s)
        {
            if (!mixer) return;
            mixer.SetFloat(masterParam, s.masterOn ? NormToDb(s.master) : -80f);
            mixer.SetFloat(musicParam, s.musicOn ? NormToDb(s.music) : -80f);
            mixer.SetFloat(sfxParam, s.sfxOn ? NormToDb(s.sfx) : -80f);
            mixer.SetFloat(uiParam, s.uiOn ? NormToDb(s.ui) : -80f);
            mixer.SetFloat(voiceParam, s.voiceOn ? NormToDb(s.voice) : -80f);
        }

        public Snapshot Read()
        {
            var s = new Snapshot();
            s.master = GetNorm(masterParam, 1f, out var masterDb); s.masterOn = masterDb > -79.9f;
            s.music = GetNorm(musicParam, 1f, out var musicDb); s.musicOn = musicDb > -79.9f;
            s.sfx = GetNorm(sfxParam, 1f, out var sfxDb); s.sfxOn = sfxDb > -79.9f;
            s.ui = GetNorm(uiParam, 1f, out var uiDb); s.uiOn = uiDb > -79.9f;
            s.voice = GetNorm(voiceParam, 1f, out var voiceDb); s.voiceOn = voiceDb > -79.9f;
            return s;

            float GetNorm(string p, float def, out float db)
            {
                db = 0f;
                if (!mixer) return def;
                if (!mixer.GetFloat(p, out db)) db = NormToDb(def);
                return DbToNorm(db);
            }
        }

        [ContextMenu("Save To PlayerPrefs")]
        public void SaveToPrefs(Snapshot s)
        {
            var json = JsonUtility.ToJson(s);
            PlayerPrefs.SetString(PlayerPrefsKey, json);
            PlayerPrefs.Save();
        }

        [ContextMenu("Load From PlayerPrefs")]
        public bool LoadFromPrefs(out Snapshot s)
        {
            s = DefaultSnapshot();
            if (!PlayerPrefs.HasKey(PlayerPrefsKey)) return false;
            var json = PlayerPrefs.GetString(PlayerPrefsKey, "");
            if (string.IsNullOrEmpty(json)) return false;
            try { s = JsonUtility.FromJson<Snapshot>(json); return true; }
            catch { return false; }
        }

        [ContextMenu("Reset Saved Settings")]
        public void ResetPrefs() => PlayerPrefs.DeleteKey(PlayerPrefsKey);

        public static Snapshot DefaultSnapshot() => new Snapshot
        {
            master = 1f,
            masterOn = true,
            music = 1f,
            musicOn = true,
            sfx = 1f,
            sfxOn = true,
            ui = 1f,
            uiOn = true,
            voice = 1f,
            voiceOn = true,
        };
    }
}
