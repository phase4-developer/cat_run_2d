# JJEvol Localization TMP — local candidate

`com.jjevol.localization.tmp@0.1.0-pre.1`, Unity 6000.3 이상. 로컬 소스 후보이며 공식 릴리스나 고정 tarball이 아니다.

uGUI(TextMeshPro) 글자 현지화 컴포넌트 `LocalizeTmpTextEvent`와 그 Inspector다. UI Toolkit 게임이 TMP를 끌고 가지 않도록 `com.jjevol.localization`에서 떼어 냈다(UI Toolkit 계획 결정 G4). 클래스 이름, 직렬화 필드, 스크립트 GUID(`5beb6f6c477480148a6eef02f804712b`, Inspector는 원래 GUID)는 그대로라 기존 Prefab과 Scene은 바뀌지 않는다.

- uGUI 게임: `com.jjevol.localization` 0.1.0-pre.4로 올릴 때 이 패키지를 함께 설치한다. 설치하지 않으면 컴포넌트가 Missing Script로 보인다.
- UI Toolkit 게임: 설치하지 않는다. `com.jjevol.localization`의 `LocalizedTextBinding`을 쓴다.
- 사용법과 동작은 이전과 같다. 설명은 `com.jjevol.localization` README의 이전 판과 `com.jjevol.localization.authoring` README에 있다.

## 시험

이 컴포넌트의 시험은 픽스처를 공유하는 `com.jjevol.localization`(`TmpLocalizationTests`, `ContractTests`)과 `com.jjevol.localization.authoring`(`InspectorTests`)에 남아 있다. 그 시험 어셈블리 세 개는 이 패키지의 어셈블리를 참조하므로 이 패키지가 설치된 경우에만 컴파일된다(`JJEVOL_LOCALIZATION_TMP` 조건). 두 패키지를 `testables`에 넣고 이 패키지를 넣지 않은 Host에서는 그 시험 어셈블리가 통째로 빠진다. Localization 시험을 돌리는 Host는 이 패키지도 설치한다.
