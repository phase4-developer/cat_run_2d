# Changelog

## 0.1.0-pre.1 - 2026-11-11

- 첫 후보. `LocalizeTmpTextEvent`(이전 `com.jjevol.localization` 0.1.0-pre.3)와 `LocalizeTmpTextEventEditor`(이전 `com.jjevol.localization.authoring` 0.1.0-pre.12)를 같은 GUID로 옮겼다. 코드는 바꾸지 않았다.
