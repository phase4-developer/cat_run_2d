# Changelog

## 0.1.0-pre.3 - 2026-11-07

- A scene-local `UIManagerCreater` is no longer supported. Transitions refresh only a started creator and no longer reconnect one after an intermediate scene.

## 0.1.0-pre.2 - 2026-11-07

- The test fixture no longer clears a Host's default Addressables Settings when several fixtures run together. All fixtures share one saved value, the first save is kept, and a deleted asset is never restored.
- The saved runtime data path follows the same rules, so a chained run cannot restore a deleted Settings GUID.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.1 - 2026-11-06

`ISceneTransitionPresenter` over `UIManager` for `com.jjevol.scene`, written against `improve/runtime-hardening` fe7f5fb0f4d4efb2d4116235817686e464d1764f. Replaces the `UIManager` and `UIManagerCreater` calls in the mobile `CustomSceneManager`.

Uses `UILoadingSession` instead of `ShowLoadingUIAsync` and `HideLoadingUI`, so a transition never closes another caller's loading view. Looks up `UIManager` at every step and restores the cover after a scene-local creator takes the UI down. Starts the requested scene's creator after an intermediate scene that owned the UI unloads, but never another creator while an active one owns the UI. A failed reconnect still clears the fade, and `RevealAsync` passes the exception on.

PlayMode tests pass 13/13 in the Windows Editor against fe7f5fb, using real UIManager and loading prefabs, URP and scene assets. The three reconnect tests added after that run are not counted there. Player and device tests are NOT_RUN.
