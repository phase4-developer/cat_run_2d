# JJEvol Platform Purchase Unity IAP

Local validation candidate 0.1.0-pre.1. Unity IAP 5 provider for `com.jjevol.platform.purchase`: Google Play, the App Store and the Mac App Store.

The code is user-authored, confirmed by the user on 2026-11-08. No SDK, product ID or store setting is included.

## Install

Unity IAP (`com.unity.purchasing`) is required and is not a package dependency. Install it in the consumer project. This package was written against 5.3.1. Its assembly references `Unity.Purchasing` and `Newtonsoft.Json.dll`, and exists only in the Editor, Android, iOS and macOS. A project that also builds for another platform, or for ONE store, leaves this provider out of that build in its own start code and build settings.

Installing this package does not start anything. The project registers the provider:

```csharp
PurchaseManager.SetProvider(new UnityIAPPurchaseProvider());
```

`PurchaseProductDefinition.StoreProductId` is the ID for the store being built. Picking the Google Play or App Store ID belongs to the project.

## Behavior

| Call | Unity IAP |
|---|---|
| `Initialize` | `StoreController.Connect`, then `FetchProducts`. Pending orders are not processed automatically. |
| `Purchase` | `PurchaseProduct`. The pending order for the requested product answers the call. Any other pending order goes to `UnrequestedOrderReceived`. |
| `FetchPendingOrders` | `FetchPurchases`, pending orders. |
| `FetchOwnedOrders` | On iOS and macOS, `RestoreTransactions`, then `FetchPurchases`. Elsewhere `FetchPurchases`. Pending and confirmed orders. |
| `Confirm` | `ConfirmPurchase` on the pending order, answered by `OnPurchaseConfirmed`. |

`PurchaseOrder.VerificationData` is the Apple JWS when the order has one, otherwise the Google purchase token from the receipt, otherwise the receipt itself. `PurchaseOrder.Key` is the transaction ID.

A store disconnection ends every call in progress with `StoreUnavailable`. The next `Initialize` connects again. `PurchaseRequest.Payload` is ignored.

| `PurchaseFailureReason` | `PurchaseFailure` |
|---|---|
| `UserCancelled` | `Cancelled` |
| `ProductUnavailable` | `ProductUnavailable` |
| `PurchasingUnavailable`, `StoreNotConnected` | `StoreUnavailable` |
| `ExistingPurchasePending` | `Busy` |
| `DuplicateTransaction` | `AlreadyOwned` |
| Others | `ProviderError` |

A deferred purchase answers `Deferred`. When it is approved it arrives as an unrequested order.

## Validation

Tests are in `Tests/Editor`. They need Unity IAP, so this package is excluded from `Tools/Validate-Current.ps1`. `Hosts/PurchaseUnityIAPValidationHost` runs them. See `Docs/PlatformPurchase/Report.md` for what has run. Real purchases on a device are NOT_RUN.
