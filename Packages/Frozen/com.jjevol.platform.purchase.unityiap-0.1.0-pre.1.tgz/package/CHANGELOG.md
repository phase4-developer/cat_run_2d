# Changelog

## 0.1.0-pre.1 - 2026-11-08

New design, per `Docs/PlatformPurchase/Design.md`. It replaces the mobile library's `UnityIAPStoreProvider` and the Unity IAP parts of `UnityIAPBillingManager`. Class names and GUIDs are not kept.

- `UnityIAPPurchaseProvider` implements `IPurchaseProvider` with callbacks instead of `IPlatformStoreProvider` events.
- SDK failure reasons become `PurchaseFailure`. The reason number stays in `ProviderCode`.
- The `!ONE_STORE` define constraint is gone. The project decides where this provider is installed and used.
- The iOS `#if` for the verification data is now a runtime check for an Apple JWS.
- The iOS restore moved here from the game's billing manager. The SDK fetches the purchases after a restore, so the provider does not fetch again.
- A purchase failure the SDK cannot match to a catalog product ends the running purchase instead of being ignored.
- `UnityIAPReceipt` is unchanged.

Unity tests: compile and EditMode 9/9 PASS in `Hosts/PurchaseUnityIAPValidationHost` (Unity 6000.3.9f1, candidate `aada7e5`). Player and device tests are NOT_RUN. See `Docs/PlatformPurchase/Report.md`.
