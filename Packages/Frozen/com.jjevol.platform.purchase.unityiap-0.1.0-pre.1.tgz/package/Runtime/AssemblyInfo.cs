using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Purchase.UnityIAP.Tests.Editor")]
