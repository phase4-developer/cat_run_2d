using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Purchasing;

namespace PlatformLibrary.Purchase.UnityIAP
{
    /// <summary>
    /// Unity IAP 5 provider: Google Play, the App Store and the Mac App Store. Pending orders stay open until
    /// <see cref="PurchaseManager"/> closes them after verification.
    /// </summary>
    public sealed class UnityIAPPurchaseProvider : IPurchaseProvider, IDisposable
    {
        public const string ProviderName = "unity-iap";

        private readonly Dictionary<string, PendingOrder> _pendingOrders = new Dictionary<string, PendingOrder>(StringComparer.Ordinal);
        private readonly Dictionary<string, Action<PurchaseStatus>> _confirmCallbacks = new Dictionary<string, Action<PurchaseStatus>>(StringComparer.Ordinal);
        private StoreController _controller;
        private bool _connected;
        private int _connectionVersion;
        private List<ProductDefinition> _fetching;
        private Action<PurchaseStatus> _initializeCallback;
        private string _purchasingProductId;
        private Action<PurchaseStatus, PurchaseOrder> _purchaseCallback;
        private Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> _fetchCallback;
        private bool _fetchOwned;

        public string Name => ProviderName;

        public event Action<PurchaseOrder> UnrequestedOrderReceived;

        /// <summary>True on the platforms Unity IAP serves. Elsewhere every call answers <see cref="PurchaseFailure.Unsupported"/>.</summary>
        public static bool IsSupportedPlatform =>
            Application.isEditor ||
            Application.platform == RuntimePlatform.Android ||
            Application.platform == RuntimePlatform.IPhonePlayer ||
            Application.platform == RuntimePlatform.OSXPlayer;

        private static bool IsApplePlatform =>
            Application.platform == RuntimePlatform.IPhonePlayer || Application.platform == RuntimePlatform.OSXPlayer;

        public void Initialize(IReadOnlyList<PurchaseProductDefinition> products, Action<PurchaseStatus> completed)
        {
            if (!IsSupportedPlatform)
            {
                completed?.Invoke(PurchaseStatus.Failed(PurchaseFailure.Unsupported, 0, "UNSUPPORTED_PLATFORM"));
                return;
            }

            FinishInitialize(PurchaseStatus.Failed(PurchaseFailure.ProviderError, 0, "INITIALIZE_REPLACED"));
            _initializeCallback = completed;
            _fetching = products.Select(product => new ProductDefinition(product.Id, product.StoreProductId, ToNative(product.Type))).ToList();
            if (_connected) FetchProducts();
            else Connect(++_connectionVersion);
        }

        public PurchaseProduct GetProduct(string productId)
        {
            if (_controller == null || string.IsNullOrEmpty(productId)) return null;
            return ConvertProduct(_controller.GetProductById(productId));
        }

        public void Purchase(PurchaseRequest request, Action<PurchaseStatus, PurchaseOrder> completed)
        {
            Product product = _controller?.GetProductById(request.ProductId);
            if (!_connected || product == null || !product.availableToPurchase)
            {
                completed?.Invoke(PurchaseStatus.Failed(_connected ? PurchaseFailure.ProductUnavailable : PurchaseFailure.StoreUnavailable, 0, "PRODUCT_NOT_READY"), null);
                return;
            }

            _purchasingProductId = request.ProductId;
            _purchaseCallback = completed;
            _controller.PurchaseProduct(product);
        }

        public void FetchPendingOrders(Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> completed) => FetchOrders(false, completed);

        public void FetchOwnedOrders(Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> completed) => FetchOrders(true, completed);

        public void Confirm(PurchaseOrder order, Action<PurchaseStatus> completed)
        {
            if (_controller == null || order == null || !_pendingOrders.TryGetValue(order.Key, out PendingOrder pending))
            {
                completed?.Invoke(PurchaseStatus.Failed(PurchaseFailure.ProviderError, 0, "PENDING_ORDER_NOT_FOUND"));
                return;
            }

            if (_confirmCallbacks.ContainsKey(order.Key))
            {
                completed?.Invoke(PurchaseStatus.Failed(PurchaseFailure.Busy, 0, "CONFIRM_IN_PROGRESS"));
                return;
            }

            _confirmCallbacks[order.Key] = completed ?? (_ => { });
            _controller.ConfirmPurchase(pending);
        }

        public void Dispose()
        {
            _connectionVersion++;
            _connected = false;
            Fail(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 0, "DISPOSED"));
            _pendingOrders.Clear();
            if (_controller == null) return;
            Subscribe(_controller, false);
            _controller = null;
        }

        private async void Connect(int version)
        {
            try
            {
                if (_controller == null)
                {
                    _controller = UnityIAPServices.StoreController();
                    Subscribe(_controller, true);
                    // The manager decides when a pending order is verified and closed.
                    _controller.ProcessPendingOrdersOnPurchasesFetched(false);
                }

                await _controller.Connect();
                if (version != _connectionVersion) return;
                _connected = true;
                FetchProducts();
            }
            catch (Exception exception)
            {
                if (version != _connectionVersion) return;
                FinishInitialize(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 0, exception.Message));
            }
        }

        private void FetchProducts()
        {
            List<ProductDefinition> products = _fetching;
            _fetching = null;
            if (products == null) return;
            try { _controller.FetchProducts(products); }
            catch (Exception exception) { FinishInitialize(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 0, exception.Message)); }
        }

        private void FetchOrders(bool owned, Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> completed)
        {
            if (!_connected)
            {
                completed?.Invoke(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 0, "STORE_NOT_CONNECTED"), Array.Empty<PurchaseOrder>());
                return;
            }

            _fetchOwned = owned;
            _fetchCallback = completed;
            if (owned && IsApplePlatform)
            {
                // Apple returns earlier transactions only after a restore. A successful restore fetches the purchases
                // itself, and that fetch answers this call.
                _controller.RestoreTransactions((success, error) =>
                {
                    if (!success) FinishFetch(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 0, error ?? "RESTORE_FAILED"), null);
                });
            }
            else
            {
                _controller.FetchPurchases();
            }
        }

        private void OnProductsFetched(List<Product> products) => FinishInitialize(PurchaseStatus.Succeeded);

        private void OnProductsFetchFailed(ProductFetchFailed failure) =>
            FinishInitialize(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 0, failure?.FailureReason ?? "PRODUCTS_FETCH_FAILED"));

        internal void OnPurchasePending(PendingOrder order)
        {
            PurchaseOrder converted = Convert(order);
            if (converted == null) return;
            if (_purchaseCallback != null && converted.ProductId == _purchasingProductId) FinishPurchase(PurchaseStatus.Succeeded, converted);
            else UnrequestedOrderReceived?.Invoke(converted);
        }

        internal void OnPurchaseFailed(FailedOrder order)
        {
            if (_purchaseCallback == null) return;
            if (IsAnotherKnownProduct(order)) return;
            FinishPurchase(PurchaseStatus.Failed(UnityIAPFailureMap.ToFailure(order.FailureReason), (int)order.FailureReason, order.Details), null);
        }

        internal void OnPurchaseDeferred(DeferredOrder order)
        {
            if (_purchaseCallback == null) return;
            if (IsAnotherKnownProduct(order)) return;
            FinishPurchase(PurchaseStatus.Failed(PurchaseFailure.Deferred, 0, "DEFERRED"), null);
        }

        internal void OnPurchaseConfirmed(Order order)
        {
            string key = KeyOf(order);
            if (key == null || !_confirmCallbacks.TryGetValue(key, out Action<PurchaseStatus> callback)) return;
            _confirmCallbacks.Remove(key);
            if (order is FailedOrder failed)
            {
                callback(PurchaseStatus.Failed(UnityIAPFailureMap.ToFailure(failed.FailureReason), (int)failed.FailureReason, failed.Details));
                return;
            }

            _pendingOrders.Remove(key);
            callback(PurchaseStatus.Succeeded);
        }

        internal void OnPurchasesFetched(Orders orders)
        {
            if (_fetchCallback == null) return;
            var result = new List<PurchaseOrder>();
            if (orders?.PendingOrders != null) result.AddRange(orders.PendingOrders.Select(Convert));
            if (_fetchOwned && orders?.ConfirmedOrders != null) result.AddRange(orders.ConfirmedOrders.Select(Convert));
            FinishFetch(PurchaseStatus.Succeeded, result.Where(order => order != null).ToList());
        }

        private void OnPurchasesFetchFailed(PurchasesFetchFailureDescription failure)
        {
            PurchaseFailure reason = failure != null && failure.FailureReason == PurchasesFetchFailureReason.StoreNotConnected
                ? PurchaseFailure.StoreUnavailable
                : PurchaseFailure.ProviderError;
            FinishFetch(PurchaseStatus.Failed(reason, failure != null ? (int)failure.FailureReason : 0, failure?.Message ?? "PURCHASES_FETCH_FAILED"), null);
        }

        internal void OnStoreDisconnected(StoreConnectionFailureDescription failure)
        {
            _connectionVersion++;
            _connected = false;
            Fail(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 0, failure?.Message ?? "STORE_DISCONNECTED"));
        }

        private void Fail(PurchaseStatus status)
        {
            FinishInitialize(status);
            FinishPurchase(status, null);
            FinishFetch(status, null);
            foreach (Action<PurchaseStatus> callback in _confirmCallbacks.Values.ToList()) callback(status);
            _confirmCallbacks.Clear();
        }

        private void FinishInitialize(PurchaseStatus status)
        {
            Action<PurchaseStatus> callback = _initializeCallback;
            _initializeCallback = null;
            if (!status.Success) _fetching = null;
            callback?.Invoke(status);
        }

        private void FinishPurchase(PurchaseStatus status, PurchaseOrder order)
        {
            Action<PurchaseStatus, PurchaseOrder> callback = _purchaseCallback;
            _purchaseCallback = null;
            _purchasingProductId = null;
            callback?.Invoke(status, order);
        }

        private void FinishFetch(PurchaseStatus status, IReadOnlyList<PurchaseOrder> orders)
        {
            Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> callback = _fetchCallback;
            _fetchCallback = null;
            callback?.Invoke(status, orders ?? Array.Empty<PurchaseOrder>());
        }

        internal PurchaseOrder Convert(Order order)
        {
            PurchaseProduct product = ConvertProduct(ProductOf(order));
            string key = KeyOf(order);
            if (product == null || key == null) return null;

            PurchaseOrderState state = order is PendingOrder ? PurchaseOrderState.Pending : PurchaseOrderState.Confirmed;
            if (order is PendingOrder pending) _pendingOrders[key] = pending;
            string receipt = order.Info?.Receipt ?? string.Empty;
            string verificationData = order.Info?.Apple?.jwsRepresentation;
            if (string.IsNullOrEmpty(verificationData)) verificationData = UnityIAPReceipt.GetGoogleTokenOrReceipt(receipt);
            return new PurchaseOrder(key, product, state, order.Info?.TransactionID, receipt, verificationData);
        }

        /// <summary>
        /// A failure for another catalog product belongs to no call here. A failure the SDK could not match to a catalog
        /// product (Google builds one from the purchase token) ends the current purchase, or it would never be answered.
        /// </summary>
        private bool IsAnotherKnownProduct(Order order)
        {
            string productId = ProductOf(order)?.definition?.id;
            return productId != null && productId != _purchasingProductId && _controller?.GetProductById(productId) != null;
        }

        private static Product ProductOf(Order order) => order?.CartOrdered?.Items()?.FirstOrDefault()?.Product;

        /// <summary>
        /// The transaction ID. Without one, a key that holds only for this order object, as the source library did,
        /// so the order can still be closed in this run.
        /// </summary>
        private static string KeyOf(Order order)
        {
            if (order == null) return null;
            string transactionId = order.Info?.TransactionID;
            if (!string.IsNullOrEmpty(transactionId)) return transactionId;
            string productId = ProductOf(order)?.definition?.id;
            return string.IsNullOrEmpty(productId) ? null : productId + "_" + System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(order);
        }

        internal static PurchaseProduct ConvertProduct(Product product)
        {
            ProductDefinition definition = product?.definition;
            if (definition == null || string.IsNullOrWhiteSpace(definition.id) || string.IsNullOrWhiteSpace(definition.storeSpecificId)) return null;
            var converted = new PurchaseProductDefinition(definition.id, definition.storeSpecificId, FromNative(definition.type));
            ProductMetadata metadata = product.metadata;
            return new PurchaseProduct(converted, product.availableToPurchase, metadata?.localizedPriceString, metadata?.localizedPrice ?? 0m, metadata?.isoCurrencyCode, metadata?.localizedTitle);
        }

        private static ProductType ToNative(PurchaseProductType type) =>
            type == PurchaseProductType.Subscription ? ProductType.Subscription :
            type == PurchaseProductType.NonConsumable ? ProductType.NonConsumable : ProductType.Consumable;

        private static PurchaseProductType FromNative(ProductType type) =>
            type == ProductType.Subscription ? PurchaseProductType.Subscription :
            type == ProductType.NonConsumable ? PurchaseProductType.NonConsumable : PurchaseProductType.Consumable;

        private void Subscribe(StoreController controller, bool subscribe)
        {
            if (subscribe)
            {
                controller.OnProductsFetched += OnProductsFetched;
                controller.OnProductsFetchFailed += OnProductsFetchFailed;
                controller.OnPurchasePending += OnPurchasePending;
                controller.OnPurchaseFailed += OnPurchaseFailed;
                controller.OnPurchaseDeferred += OnPurchaseDeferred;
                controller.OnPurchaseConfirmed += OnPurchaseConfirmed;
                controller.OnPurchasesFetched += OnPurchasesFetched;
                controller.OnPurchasesFetchFailed += OnPurchasesFetchFailed;
                controller.OnStoreDisconnected += OnStoreDisconnected;
            }
            else
            {
                controller.OnProductsFetched -= OnProductsFetched;
                controller.OnProductsFetchFailed -= OnProductsFetchFailed;
                controller.OnPurchasePending -= OnPurchasePending;
                controller.OnPurchaseFailed -= OnPurchaseFailed;
                controller.OnPurchaseDeferred -= OnPurchaseDeferred;
                controller.OnPurchaseConfirmed -= OnPurchaseConfirmed;
                controller.OnPurchasesFetched -= OnPurchasesFetched;
                controller.OnPurchasesFetchFailed -= OnPurchasesFetchFailed;
                controller.OnStoreDisconnected -= OnStoreDisconnected;
            }
        }
    }
}
