using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Purchase.UnityIAP
{
    public static class UnityIAPReceipt
    {
        /// <summary>
        /// The Google Play purchase token inside a Unity IAP receipt. Any other receipt, or one that cannot be read,
        /// is returned unchanged.
        /// </summary>
        public static string GetGoogleTokenOrReceipt(string receipt)
        {
            if (string.IsNullOrEmpty(receipt)) return string.Empty;
            try
            {
                string payload = JObject.Parse(receipt)["Payload"]?.ToString();
                if (string.IsNullOrEmpty(payload)) return receipt;
                JObject data = JObject.Parse(payload);
                string token = data["purchaseToken"]?.ToString();
                if (!string.IsNullOrEmpty(token)) return token;
                string json = data["json"]?.ToString();
                if (string.IsNullOrEmpty(json)) return receipt;
                JObject purchase = JObject.Parse(json);
                token = purchase["purchaseToken"]?.ToString();
                if (string.IsNullOrEmpty(token)) token = purchase["token"]?.ToString();
                return string.IsNullOrEmpty(token) ? receipt : token;
            }
            catch
            {
                return receipt;
            }
        }
    }
}
