using UnityEngine.Purchasing;

namespace PlatformLibrary.Purchase.UnityIAP
{
    internal static class UnityIAPFailureMap
    {
        public static PurchaseFailure ToFailure(PurchaseFailureReason reason)
        {
            switch (reason)
            {
                case PurchaseFailureReason.UserCancelled: return PurchaseFailure.Cancelled;
                case PurchaseFailureReason.ProductUnavailable: return PurchaseFailure.ProductUnavailable;
                case PurchaseFailureReason.PurchasingUnavailable:
                case PurchaseFailureReason.StoreNotConnected: return PurchaseFailure.StoreUnavailable;
                case PurchaseFailureReason.ExistingPurchasePending: return PurchaseFailure.Busy;
                case PurchaseFailureReason.DuplicateTransaction: return PurchaseFailure.AlreadyOwned;
                default: return PurchaseFailure.ProviderError;
            }
        }
    }
}
