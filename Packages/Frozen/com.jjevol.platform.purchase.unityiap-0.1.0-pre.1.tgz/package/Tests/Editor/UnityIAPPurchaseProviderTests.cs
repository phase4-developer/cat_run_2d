using System;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine.Purchasing;

namespace PlatformLibrary.Purchase.UnityIAP.Tests
{
    public sealed class UnityIAPPurchaseProviderTests
    {
        private const BindingFlags Hidden = BindingFlags.Instance | BindingFlags.NonPublic;

        [Test]
        public void GoogleReceiptGivesThePurchaseToken()
        {
            string json = new JObject { ["purchaseToken"] = "store-token" }.ToString();
            string receipt = new JObject { ["Payload"] = new JObject { ["json"] = json }.ToString() }.ToString();
            Assert.That(UnityIAPReceipt.GetGoogleTokenOrReceipt(receipt), Is.EqualTo("store-token"));
        }

        [Test]
        public void GoogleReceiptFallsBackToTheTokenField()
        {
            string json = new JObject { ["token"] = "store-token" }.ToString();
            string receipt = new JObject { ["Payload"] = new JObject { ["json"] = json }.ToString() }.ToString();
            Assert.That(UnityIAPReceipt.GetGoogleTokenOrReceipt(receipt), Is.EqualTo("store-token"));
        }

        [Test]
        public void ADirectTokenAndAnUnreadableReceiptStayCompatible()
        {
            string direct = new JObject { ["Payload"] = new JObject { ["purchaseToken"] = "direct-token" }.ToString() }.ToString();
            Assert.That(UnityIAPReceipt.GetGoogleTokenOrReceipt(direct), Is.EqualTo("direct-token"));
            foreach (string receipt in new[] { "malformed", "{}", "{\"Payload\":\"{}\"}" })
                Assert.That(UnityIAPReceipt.GetGoogleTokenOrReceipt(receipt), Is.EqualTo(receipt));
            Assert.That(UnityIAPReceipt.GetGoogleTokenOrReceipt(null), Is.Empty);
        }

        [Test]
        public void SdkReasonsBecomeFailures()
        {
            Assert.That(UnityIAPFailureMap.ToFailure(PurchaseFailureReason.UserCancelled), Is.EqualTo(PurchaseFailure.Cancelled));
            Assert.That(UnityIAPFailureMap.ToFailure(PurchaseFailureReason.ProductUnavailable), Is.EqualTo(PurchaseFailure.ProductUnavailable));
            Assert.That(UnityIAPFailureMap.ToFailure(PurchaseFailureReason.StoreNotConnected), Is.EqualTo(PurchaseFailure.StoreUnavailable));
            Assert.That(UnityIAPFailureMap.ToFailure(PurchaseFailureReason.PurchasingUnavailable), Is.EqualTo(PurchaseFailure.StoreUnavailable));
            Assert.That(UnityIAPFailureMap.ToFailure(PurchaseFailureReason.ExistingPurchasePending), Is.EqualTo(PurchaseFailure.Busy));
            Assert.That(UnityIAPFailureMap.ToFailure(PurchaseFailureReason.DuplicateTransaction), Is.EqualTo(PurchaseFailure.AlreadyOwned));
            Assert.That(UnityIAPFailureMap.ToFailure(PurchaseFailureReason.Unknown), Is.EqualTo(PurchaseFailure.ProviderError));
        }

        [Test]
        public void APendingOrderNobodyAskedForIsReportedWithItsMetadata()
        {
            PendingOrder pending = CreatePending("701", "store.item", ProductType.NonConsumable, "transaction");
            using (var provider = new UnityIAPPurchaseProvider())
            {
                PurchaseOrder received = null;
                provider.UnrequestedOrderReceived += order => received = order;
                provider.OnPurchasePending(pending);

                Assert.That(received.State, Is.EqualTo(PurchaseOrderState.Pending));
                Assert.That(received.Key, Is.EqualTo("transaction"));
                Assert.That(received.ProductId, Is.EqualTo("701"));
                Assert.That(received.Product.Definition.StoreProductId, Is.EqualTo("store.item"));
                Assert.That(received.Product.Definition.Type, Is.EqualTo(PurchaseProductType.NonConsumable));
                Assert.That(received.Product.Price, Is.EqualTo(1.99m));
                Assert.That(received.Product.Currency, Is.EqualTo("USD"));
                Assert.That(received.TransactionId, Is.EqualTo("transaction"));
                Assert.That(received.Receipt, Is.EqualTo(pending.Info.Receipt));
                Assert.That(received.VerificationData, Is.EqualTo(pending.Info.Receipt));

                var handles = (Dictionary<string, PendingOrder>)typeof(UnityIAPPurchaseProvider).GetField("_pendingOrders", Hidden).GetValue(provider);
                Assert.That(handles[received.Key], Is.SameAs(pending));
            }
        }

        [Test]
        public void AnOrderWithoutATransactionIdStillGetsAKey()
        {
            using (var provider = new UnityIAPPurchaseProvider())
            {
                PurchaseOrder converted = provider.Convert(CreatePending("701", "store.item", ProductType.Consumable, ""));
                Assert.That(converted.Key, Does.StartWith("701_"));
            }
        }

        [Test]
        public void ClosingAnUnknownOrderFails()
        {
            using (var provider = new UnityIAPPurchaseProvider())
            {
                var product = new PurchaseProduct(new PurchaseProductDefinition("a", "store.a"), true, null, 0m, null, null);
                PurchaseStatus status = default;
                provider.Confirm(new PurchaseOrder("k", product, PurchaseOrderState.Pending, null, null, null), result => status = result);
                Assert.That(status.Failure, Is.EqualTo(PurchaseFailure.ProviderError));
            }
        }

        [Test]
        public void CallsBeforeConnectingAnswerStoreUnavailable()
        {
            using (var provider = new UnityIAPPurchaseProvider())
            {
                var failures = new List<PurchaseFailure>();
                provider.Purchase(new PurchaseRequest("a"), (status, order) => failures.Add(status.Failure));
                provider.FetchPendingOrders((status, orders) => failures.Add(status.Failure));
                provider.FetchOwnedOrders((status, orders) => failures.Add(status.Failure));
                Assert.That(failures, Is.EqualTo(new[] { PurchaseFailure.StoreUnavailable, PurchaseFailure.StoreUnavailable, PurchaseFailure.StoreUnavailable }));
                Assert.That(provider.GetProduct("a"), Is.Null);
            }
        }

        [Test]
        public void ADisconnectWithNothingRunningIsHarmless()
        {
            using (var provider = new UnityIAPPurchaseProvider())
                Assert.DoesNotThrow(() => provider.OnStoreDisconnected(null));
        }

        private static PendingOrder CreatePending(string id, string storeId, ProductType type, string transactionId)
        {
            var definition = new ProductDefinition(id, storeId, type);
            var metadata = new ProductMetadata("$1.99", "Item", "", "USD", 1.99m);
            var product = (Product)Activator.CreateInstance(typeof(Product), Hidden, null, new object[] { definition, metadata }, null);
            Type orderInfoType = typeof(PendingOrder).Assembly.GetType("UnityEngine.Purchasing.OrderInfo", true);
            var info = (IOrderInfo)Activator.CreateInstance(orderInfoType, "raw-receipt", transactionId, "GooglePlay");
            return new PendingOrder(new Cart(new CartItem(product)), info);
        }
    }
}
