using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine;

namespace jjevol.Effect
{
    public sealed class AddressablesEffectPrefabProvider : IEffectPrefabProvider
    {
        public async UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var handle = Addressables.LoadAssetAsync<GameObject>(key);
            bool transferred = false;
            try
            {
                // 이 어셈블리는 UniTask.Addressables를 참조하지 않는다. handle.ToUniTask()는
                // IEnumerator 오버로드로 묶여 실패해도 예외가 없으므로 상태를 직접 읽는다.
                if (!handle.IsDone) await UniTask.WaitUntil(() => handle.IsDone);
                cancellationToken.ThrowIfCancellationRequested();
                if (handle.Status != AsyncOperationStatus.Succeeded)
                    throw handle.OperationException ?? new InvalidOperationException($"Effect prefab '{key}' failed to load.");
                if (!handle.Result) return null;
                var lease = new EffectPrefabLease(handle.Result, () => { if(handle.IsValid()) Addressables.Release(handle); });
                transferred = true;
                return lease;
            }
            finally { if(!transferred && handle.IsValid()) Addressables.Release(handle); }
        }
    }
}
