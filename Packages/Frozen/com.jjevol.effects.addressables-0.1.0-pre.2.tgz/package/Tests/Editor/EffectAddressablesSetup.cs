using System;
using System.IO;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEngine.AddressableAssets;
using UnityEngine.TestTools;
namespace jjevol.Effect.Tests
{
    public sealed class EffectAddressablesSetup : IPrebuildSetup, IPostBuildCleanup
    {
        public void Setup()
        {
            string root="Assets/JJEvolEffectTests_"+Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets",Path.GetFileName(root));
            var settings=AddressableAssetSettings.Create(root,"Settings",true,true);
            for(int i=0;i<settings.DataBuilders.Count;i++) if(settings.DataBuilders[i] is BuildScriptFastMode) settings.ActivePlayModeDataBuilderIndex=i;
            EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();
            SessionState.SetString("EffectTestRoot",root);
            SessionState.SetString("EffectTestPreviousPath",SessionState.GetString(Addressables.kAddressablesRuntimeDataPath,""));
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
        }
        public void Cleanup()
        {
            string old=SessionState.GetString("EffectTestPreviousPath","");
            if(old=="")SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            else SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,old);
            string root=SessionState.GetString("EffectTestRoot","");
            if(root.StartsWith("Assets/JJEvolEffectTests_")&&AssetDatabase.IsValidFolder(root))
            {
                if(!string.Equals(Path.GetDirectoryName(Path.GetFullPath(root)),Path.GetFullPath(UnityEngine.Application.dataPath),StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Unsafe test cleanup path");
                AssetDatabase.DeleteAsset(root);
            }
            SessionState.EraseString("EffectTestRoot");SessionState.EraseString("EffectTestPreviousPath");
        }
    }
}
