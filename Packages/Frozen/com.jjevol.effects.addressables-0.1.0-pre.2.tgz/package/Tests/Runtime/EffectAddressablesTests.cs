using System;
using System.Collections;
using NUnit.Framework;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;
namespace jjevol.Effect.Tests
{
    [PrebuildSetup("jjevol.Effect.Tests.EffectAddressablesSetup")]
    [PostBuildCleanup("jjevol.Effect.Tests.EffectAddressablesSetup")]
    [Timeout(20000)]
    public sealed class EffectAddressablesTests
    {
        sealed class PrefabSource:ResourceProviderBase
        {
            readonly string _id="effect-test-"+Guid.NewGuid().ToString("N");
            public override string ProviderId=>_id;
            internal int Loads,Releases;internal bool Fail;
            public override void Provide(ProvideHandle handle)
            {
                Loads++;
                if(Fail){handle.Complete<GameObject>(null,false,new InvalidOperationException("expected SDK effect failure"));return;}
                var go=new GameObject("SDK-effect-prefab");go.AddComponent<SpriteRenderer>();handle.Complete(go,true,null);
            }
            public override void Release(IResourceLocation location,object value){Releases++;if(value is GameObject go)Object.Destroy(go);}
        }
        PrefabSource _source; ResourceLocationMap _locator; EffectManager _manager;
        [UnitySetUp] public IEnumerator Setup()
        {
            var initialized=Addressables.InitializeAsync(false);yield return initialized;
            Assert.AreEqual(UnityEngine.ResourceManagement.AsyncOperations.AsyncOperationStatus.Succeeded,initialized.Status);
            Addressables.Release(initialized);
            _source=new PrefabSource();Addressables.ResourceManager.ResourceProviders.Add(_source);
            _locator=new ResourceLocationMap("effect-locator-"+Guid.NewGuid().ToString("N"));
            _locator.Add("test",new ResourceLocationBase("test","effect-prefab",_source.ProviderId,typeof(GameObject)));
            Addressables.AddResourceLocator(_locator);
            _manager=new GameObject("sdk-effect-manager").AddComponent<EffectManager>();
            _manager.SetPrefabProvider(new AddressablesEffectPrefabProvider());
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {
            if(_manager)Object.Destroy(_manager.gameObject);yield return null;yield return null;
            Addressables.RemoveResourceLocator(_locator);Addressables.ResourceManager.ResourceProviders.Remove(_source);
        }
        [UnityTest]public IEnumerator ConcurrentPlaySharesPrefabAndRetainsUntilManagerDestroy()
        {
            var first=_manager.PlayAsync(new EffectRequest("test",loop:true)).AsTask();
            var second=_manager.PlayAsync(new EffectRequest("test",loop:true)).AsTask();
            while(!first.IsCompleted||!second.IsCompleted)yield return null;
            Assert.AreEqual(1,_source.Loads);Assert.AreNotSame(first.Result,second.Result);
            _manager.Despawn(first.Result);_manager.Despawn(second.Result);
            Assert.AreEqual(0,_source.Releases);
            Object.Destroy(_manager.gameObject);yield return null;yield return null;
            Assert.AreEqual(1,_source.Releases);
        }
        [UnityTest]public IEnumerator IdleCullReturnsTheRealPrefabHandle()
        {
            _manager.SetPoolProfile("test",0,4,0.1f);
            var task=_manager.PlayAsync(new EffectRequest("test",loop:true)).AsTask();
            while(!task.IsCompleted)yield return null;
            _manager.Despawn(task.Result);
            yield return new WaitForSecondsRealtime(0.9f);
            Assert.AreEqual(1,_source.Releases);
        }
        [UnityTest]public IEnumerator SdkFailureFaultsPlayAsyncRecoversHandleAndRetries()
        {
            // The SDK logs the failed operation itself. This test asserts delivery, not that log.
            LogAssert.ignoreFailingMessages=true;
            try
            {
                _source.Fail=true;int calls=0;
                var failed=_manager.PlayAsync(new EffectRequest("test",loop:true,callBack:()=>calls++)).AsTask();
                while(!failed.IsCompleted)yield return null;
                Assert.IsTrue(failed.IsFaulted,"Failure must arrive as an exception, not as a silent null lease");
                StringAssert.Contains("expected SDK effect failure",failed.Exception.GetBaseException().ToString());
                Assert.AreEqual(1,calls);
                _source.Fail=false;
                var retry=_manager.PlayAsync(new EffectRequest("test",loop:true)).AsTask();
                while(!retry.IsCompleted)yield return null;
                Assert.IsFalse(retry.IsFaulted);Assert.IsTrue(retry.Result.IsPlaying);Assert.AreEqual(2,_source.Loads);
            }
            finally{LogAssert.ignoreFailingMessages=false;}
        }
    }
}
