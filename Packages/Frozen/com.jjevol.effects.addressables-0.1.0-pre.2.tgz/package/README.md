# JJEvol Effects Addressables — local candidate

Optional provider using real Unity Addressables 4.0.1 and the Core's EffectPrefabLease. Install Core and this package, pin UniTask in the Host manifest, then call SetPrefabProvider(new AddressablesEffectPrefabProvider()) before loading.

Core shares a prefab acquisition per key and owns its lease across active and idle instances. The final pool cull or manager destruction destroys instances before returning the handle. This provider checks cancellation before and after the actual SDK load; it does not claim to cancel the underlying operation or provide immediate caller cancellation.

A failed SDK operation throws its OperationException after the handle is released, so PlayAsync faults and Play logs it. This assembly does not reference UniTask.Addressables, where handle.ToUniTask() would throw; here that call binds to the IEnumerator overload, which never does, so the provider reads the status itself. A successful operation with no result returns null. Both cases recover the EffectHandle, call back once and retry on the next request.

No Groups/catalog/build/deployment policy, Audio dependency, or SDK source is included. Test providers create synthetic GameObjects through the real Addressables ResourceManager. Player, bundles, remote download and visual quality are unverified.
