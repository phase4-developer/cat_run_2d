# Changelog

## 0.1.0-pre.2 - 2026-11-06

- Load failures now surface as `OperationException` instead of null.

Unity tests for this candidate are NOT_RUN.
