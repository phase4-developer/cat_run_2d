# JJEvol Managed Addressables 사용 가이드

문서 기준: 2026-11-09 / `1.3.12-pre.15` 내부 후보. 신규 게임의 제작·운영 안내 정본이다. 정식 릴리스나 제품 적용 완료 선언은 아니다. pre.10에서 Windows Mono Player까지 이 가이드의 단계별 순서로 검증했다. pre.11의 PC별 값 분리, 산출물 정리, 로컬 호스트 원격 갱신은 Editor·PlayMode 시험과 Windows Mono Player 체인에서 통과했다. pre.15의 앱 빌드는 Editor 시험과 Revision Host 체인에서 확인했다. 공개 API `ManagedAppBuild.Build`와 배치 진입점이 각각 Windows Mono 개발 Player를 만들었고, 두 Player 모두 앱 포함 A로 시작했다. 창 버튼 경로로 만든 Player와 출시 앱 빌드는 NOT_RUN이다. 실제 원격 서버는 NOT_RUN이다. Framework 자체의 Android, iOS 실행은 NOT_RUN이다. 소비 게임 시험 적용에서 Android 개발 빌드가 기기에서 열린 기록(pre.14)은 그 게임 쪽 기록이며 이 문서의 검증으로 세지 않는다.

Managed는 개발자가 정한 폴더 규칙을 Addressables Group, Address, Bundle 제작 설정으로 연결하는 도구다. 콘텐츠 경로는 BootstrapSplit 하나다. 앱에 포함되는 Boot Catalog와, 앱이 소유한 저장소에서 여는 Revision Catalog로 나뉜다.

## 1. Quick Start

### 설치 전제

- 프로젝트가 선택한 고정 패키지와 의존성을 먼저 확인한다. package.json은 Unity 최소 선언 `2022.3`, Addressables `4.0.1`, Newtonsoft JSON `3.2.2`, IMGUI 모듈을 요구한다. 실제 검증 환경은 Unity `6000.3.9f1`이다.
- Unity 6.7은 Addressables 4.1.2를 강제한다. 1.3.12-pre.18부터 Editor 분할 빌드(BootstrapSplit)는 Addressables 4.0.1과 4.1.2 두 버전만 받는다(4.1.0·4.1.1은 비교하지 않아 막힌다). Runtime Revision 적용은 pre.16부터 4.0.1~4.1.2 범위를 받는다.
- Managed, 일반 자산 로더 `com.jjevol.resources.addressables`, UI 소비자 `com.jjevol.ui.addressables`는 역할이 다르다. Managed 설치가 로더와 UI의 자동 연결까지 완료하지는 않는다.

### 최소 구성 순서

1. 게임별 Root를 정한다. 예: `Assets/Game/Addressables`. 기존 Art와 Prefab 원본은 유지하고 이 Root 아래에 독립 로딩할 최종 자산만 둔다.
2. `Local/UI`, `Remote/Gameplay` 등 필요한 Category 폴더를 만든다.
3. `JJEvol/Addressables/Control Center`를 열고 `설정 만들기`(English: `Create Config`)로 Config를 만든다. 창 오른쪽 위에서 한국어·English를 고른다. 기본 위치는 `Assets/ArtressManagedAddressables/ManagedAddressableProjectConfig.asset`이다. 기존 Config는 덮어쓰지 않는다.
4. Content Root와 Resolved Path가 의도한 게임 폴더인지 확인한다.
5. 「고급 > 콘텐츠 등록」에서 `등록 미리 보기` → `미리 본 계획 적용` → `등록 검사` 순으로 진행한다. 이후 빌드는 첫 화면의 `앱 빌드`가 등록 동기화부터 한 번에 한다(4절).
6. 작은 자산 한 개를 등록하고 Groups에서 GUID, Entry, Address, Group을 확인한다. 소비자가 같은 Key로 로드·사용·반환하는 것을 확인한 뒤 범위를 넓힌다.

| 옵션 | 권고 값과 의미 |
|---|---|
| `contentRootFolder` / `ContentRootPath` | 게임 Root. 유효한 폴더 참조가 문자열 경로보다 우선 |
| `categoryRules` | ReservedFolder, PackTogether, enabled=true |
| `autoRegister`, `createGroupIfMissing` | true. 명시 Sync 시 등록·Group 생성 옵션이며 시작 시 자동 등록이 아님 |
| `preserveExistingAddressesOnSync` | true |
| `includeExtension`, `ensureUnique`, `pathSeparator` | false / false / `_`. 기본 ignorePathPrefixes=`Texture` |
| `allowDevelopmentHttp` | false. 6절 참고 |
| `backupBeforeApply`, `backupRoot` | true / `Library/ArtressManagedAddressablesBackup` |

## 2. Folder / Address / Group 규칙

```text
<Content Root>/
  Local/<Category>/.../Asset.ext
  Remote/<Category>/.../Asset.ext
  Remote/<Category>/Update/<BundleKey>/.../Asset.ext
```

| 개념 | 사용 방법 |
|---|---|
| Delivery | Local은 앱 포함 콘텐츠, Remote는 원격 콘텐츠. 다른 폴더 이름은 Sync가 거부 |
| Category | 기본 Group 단위. 기본 Local Group=`Category`, Remote Group=`Remote_Category`. 명시한 groupNamePattern이 우선 |
| Update/BundleKey | ReservedFolder 전략에서 Category 바로 아래에 사용. Group=`기본Group_BundleKey`. Address 후보에서는 Update/BundleKey를 제외 |
| BundleKey | 개발자가 정하는 제작 묶음. Unity Content Update 명령이나 서버 Revision이 아님 |

기본 ReservedFolder, 확장자 제외, `_`, ignorePathPrefixes=`Texture`에서 **새 등록** 예:

| Root 뒤 파일 경로 | Group | 신규 Address 후보 |
|---|---|---|
| `Local/UI/Home.prefab` | `UI` | `Home` |
| `Local/UI/UI_Home.prefab` | `UI` | `UI_Home` |
| `Remote/Character/Enemies/Boss.prefab` | `Remote_Character` | `Enemies_Boss` |
| `Remote/Character/Update/Pack02/Enemies/Boss.prefab` | `Remote_Character_Pack02` | `Enemies_Boss` |
| `Remote/Texture/Icon/Coin.png` | `Remote_Texture` | `Coin` |

Category의 UI가 Key에 자동으로 붙지는 않는다. Texture 예는 Category 자체가 ignore 대상이므로 파일명만 남는다. 주소 규칙의 구현은 `ManagedAddressNaming`이다.

일반 Sync는 GUID로 기존 Entry를 찾고, 계산 Group으로 옮긴 뒤 기존 비어 있지 않은 Address를 보존한다. `.meta`와 GUID를 유지한 이동·재명명은 Key 유지와 함께 가능하다. 명시적 Address Rebuild는 다른 작업이므로 예상 Key diff를 확인한다. 다른 자산에 `.meta`를 복사해 GUID를 재사용하지 않는다.

원본 Art는 Root 밖에 유지할 수 있다. Root 안 Prefab이 밖 원본을 참조할 수 있으며 실제 Bundle 포함과 공유 의존성은 SDK 빌드 결과에서 확인한다.

## 3. Control Center 등록 절차

1. 대상 게임, 타깃, 앱 버전과 Config의 Root, 규칙을 확인한다.
2. 「고급 > 콘텐츠 등록」의 `등록 미리 보기`로 신규 등록, Group 이동, Address 변경·유지 계획을 검토한다. 미리 보기는 Settings와 Entry를 바꾸지 않는다.
3. `미리 본 계획 적용`을 실행한다. 검토 뒤 입력이 바뀌면 다시 미리 봐야 한다. 앱 빌드는 이 계획을 스스로 만들어 적용하고 결과 창에 목록을 남긴다.
4. 결과 메시지와 실제 Groups, Entry, Schema를 확인하고 `등록 검사`를 실행한다.
5. 작은 자산을 실제 소비자 Key로 획득·사용·반환한다.

기존 Group은 이름이나 폴더로 자동 채택하지 않는다. 등록·정책 수정 대상으로 삼으려면 「고급 > Group 소유」의 `Group 채택 미리 보기`로 명시 채택한다. Sync가 새로 만든 Group은 자동으로 채택 목록에 들어간다. 채택 목록의 GUID가 없는 Group을 가리키면 오류로 막지 않고 경고로 남긴다. 정리는 `없는 Group 참조 정리 미리 보기`로 명시적으로 한다(2026-11-05 사용자 조건).

Settings가 없는 최초 Sync는 Profile, Group baseline을 만든다. 새 Profile의 `Remote.LoadPath` 기본값은 미설정(`<undefined>`)이다. **Revision 빌드 전에 이 값을 실제 HTTPS 루트로 바꿔야 한다.** 바꾸기 전에는 Revision 검증이 차단한다. 등록 검사는 Key 중복과 경로를 검사하는 기능이며 이전 앱과 새 Revision의 호환성 검증이 아니다.

## 4. Boot / Revision 제작

처음 한 번은 1~4번으로 준비하고, 그다음부터는 첫 화면의 `앱 빌드` 하나로 5~7번을 한 번에 한다.

1. 「고급 > 빌드 역할」의 `폴더로 역할 제안`을 누르면 Local 폴더 Group은 Boot, Remote 폴더 Group은 Revision으로 초안이 채워진다. shared 대상과 필수 Boot Key도 함께 채워지고, 이미 적은 행은 그대로 둔다. 폴더로 판단할 수 없는 Group은 결과 메시지에 나오므로 직접 추가한다.
2. `빌드 역할 미리 보기`에서 초안을 검토하고 `미리 본 계획 적용`으로 적용한다. SDK `DoNotBuildWithPlayer`가 함께 설정된다.
3. Sync가 만든 Remote Group은 Revision이 요구하는 cache, CRC, 다른 버전 보존 설정을 이미 갖췄다. 기존 Group을 채택했다면 「고급 > 단계별 빌드」의 `원격 캐시·CRC 정책 미리 보기`로 맞춘다. NoHash는 Bundle 파일 이름 정책이며 Catalog 안의 Hash와 별개다. Revision Runtime은 0이 아닌 원격 Bundle Hash를 계속 요구한다.
4. 「고급 > 배포 값」을 미리 보고 적용한다. Product ID, Authority, Compatibility family는 Config에 저장되어 Git으로 공유된다. Channel과 순번은 이 PC의 `UserSettings/ArtressManagedAddressables/Release-<Config GUID>.json`에 저장된다. PC마다 다른 Channel을 쓴다. 순번은 배포 주체가 정한다. 앱 빌드는 개발 빌드일 때만 이 PC에 저장된 순번과 마지막 Revision 중 큰 값에 1을 더해 저장하고, 뒤 단계가 실패하면 되돌린다. 출시 빌드는 저장된 순번을 쓰고, 그 값이 0이거나 마지막 Revision 이하이면, 또는 `개발용 HTTP 허용`이 켜져 있으면 굽기 전에 막는다. 같은 순번으로 내용이 다른 앱을 덮어 설치하면 기기에서 `AmbiguousEqualDeploymentSequence`로 열리지 않기 때문이다.
5. Revision 굽기(앱 빌드 3단계, 또는 「고급 > 단계별 빌드」의 `Revision 빌드 미리 보기` → `Revision 빌드`). 산출물은 빌드마다 새 stamp 폴더에 쌓이고 `revision_publisher.json`과 그 SHA-256이 나온다.
6. 앱 포함 A 연결(앱 빌드 4~5단계, 또는 `앱 포함 A 미리 보기` → `앱 포함 A 적용`). 앱 빌드는 굽기 뒤 Config를 다시 읽어 저장한 다음 연결한다. 연결은 이 PC의 파일에 플랫폼별로 남으므로 다른 PC는 자기 A를 만든다.
7. Player 빌드(앱 빌드 6단계, 또는 Unity Build Settings의 빌드). Boot를 자동 제작하고 staging을 검증한다. `Boot 빌드`는 진단용이다. 앱 빌드는 늘 LZ4로 빌드하고, Android는 직전에 Gradle 쪽 Player 데이터 폴더를 비우며, 빌드 뒤 이번 빌드보다 오래된 `data.unity3d`가 남았으면 실패로 보고한다. 배치 실행과 공개 API는 패키지 README 「배치 실행」을 본다.

Boot에는 HTTP 경로를 쓸 수 없다. Revision에는 고정 HTTPS 루트가 필요하다. 제작 중 Settings, Group, schema는 임시로 바뀌고 끝나면 복원되며, 복원을 확인할 수 없으면 그 빌드는 실패한다.

Project Config가 있는 프로젝트의 모든 Player 빌드는 이 경로를 탄다. 역할이나 앱 포함 A가 없으면 빌드가 실패한다.

Player Scene 목록, Resources, 앱 버전이 바뀌면 앱 포함 A를 만든 Revision의 입력도 바뀐다. 이때 Player 빌드는 실패하므로 5번의 Revision부터 다시 만든다.

산출물은 빌드마다 쌓인다. 「고급 > 산출물 정리」에서 미리 본 뒤 적용으로 정리한다. 이 PC가 연결한 앱 포함 A, 플랫폼별 최근 Revision N개(기본 3), 최신·stage·짝 Boot만 남는다.

## 5. 콘텐츠 변경과 배포

| 변경 | 제작 작업 | 주의 |
|---|---|---|
| 이미지, Prefab 등 내용 수정 | GUID와 Key 유지, Sync 후 새 Revision | 같은 Key·경로·Bundle 배치·의존성 조건만 시험됨 |
| 신규 리소스 | 새 GUID, Entry, Key 등록 후 실제 소비 확인 | 신규 Key의 원격 갱신은 미검증 |
| Prefab의 신규 Material, Texture 참조 | 새 자원의 실제 Bundle 의존성 확인 | 신규 의존성 그래프는 미검증 |
| 이동, 재명명 | meta와 GUID 보존, Key 유지 확인 | Bundle 내부 경로가 바뀔 수 있음 |
| Group, Bundle 구성 변경 | 예상 Group과 의존성 확인 | 재편성은 미검증 |

Local 콘텐츠, 앱 코드, 직렬화 타입이 바뀌면 Player를 함께 제작한다. 서버는 앱 버전과 플랫폼별로 호환되는 Revision을 선택한다. Revision은 전체 파일이 산출되는 Full Snapshot이며 Unity Content Update를 쓰지 않는다. 게임 서버 URL과 인증은 게임의 서버 연동이 소유한다.

앱 시작과 교체 절차는 [Runtime 계약](AR2-Runtime2.md)이 정본이다. 요약하면 다음과 같다.

1. 앱이 SDK Boot를 초기화하고 실제 등록된 Locator를 받는다.
2. `ManagedAddressableRevision.CreatePackaged`와 `ManagedRevisionApplication`을 구성해 `OpenForApplicationAsync`를 호출한다.
3. 성공한 뒤에만 Revision 소비자를 시작한다.
4. 새 Revision은 `PrepareAsync`로 준비하고, 안전 시점에 `ApplyAsync`로 교체한다.

앱 포함 A의 anchor는 `ManagedPackagedRevisionLoader.LoadAsync()`가 읽어 `ManagedRevisionApplication`을 만든다. Android의 jar 경로도 처리한다.

### 게임 서버 없는 원격 시험

게임 서버 연동 전에는 로컬 호스트가 서버를 대신한다. 개발 전용이며 포인터의 SHA는 파일과 같은 서버에서 오므로 운영 신뢰 기준이 아니다.

1. `Remote.LoadPath`를 `http://127.0.0.1:<port>/<경로>`로 두고 「고급 > 배포 값」의 `개발용 HTTP 허용`을 켠 뒤 Development Player를 만든다.
2. Revision 내용만 고쳐 다음 순번으로 빌드한다. Player는 다시 만들지 않는다.
3. 「고급 > 로컬 호스트 게시」에서 서버 폴더를 저장하고 미리 본 뒤 적용한다. 포인터 `split/latest/<플랫폼>/<channel>.json`이 파일 복사 뒤에 기록된다.
4. `Tests/Fixtures~/Serve-LocalHost.ps1 -Root <폴더> -Port <port>`로 제공한다. Android 실기기는 `adb reverse tcp:<port> tcp:<port>`.
5. 앱은 포인터를 받아 `ManagedRevisionLocalHostPointer.Parse(json).ToRevision()`을 `PrepareAsync` → `ApplyAsync`에 넘긴다. 재시작하면 확정된 Revision을 앱 저장소에서 연다.

## 6. 개발용 http

기본은 HTTPS만 허용한다. 로컬 시험 서버에 평문 http가 필요하면 Control Center 「고급 > 배포 값」의 `개발용 HTTP 허용`을 켠다.

| 상태 | 동작 |
|---|---|
| 꺼짐 | http Revision URL은 Editor 검증과 Runtime 검사에서 실패 |
| 켜짐, Development Build | `insecureHttpOption`이 `NotAllowed`이면 빌드 동안 `DevelopmentOnly`로 바꾸고 되돌림. iOS는 Xcode `Info.plist`에 ATS 예외 추가 |
| 켜짐, Release Build | 시작 단계에서 빌드 실패 |

Release Player는 어떤 경우에도 http를 거부한다. 이 설정이 바꾸는 Player Settings는 Player 빌드에만 적용되며, Editor Play 모드는 프로젝트의 `insecureHttpOption`을 그대로 쓴다.

## 7. 문제 발생 시 확인 순서

1. 단계부터 구분한다. Config 저장과 미리 보기, 등록 동기화와 등록 검사, 배포 순번, Boot·Revision 제작, 앱 포함 A 연결, Player 빌드, Runtime Open, Prepare, Apply 중 어디서 실패했는지 기록한다.
2. 게임, 타깃, 앱 버전, 고정 패키지, Revision을 확인한다. Key → GUID → AssetPath → Entry Group을 확인한다.
3. 제작 문제면 앱 빌드 결과 창의 단계 목록, 미리 보기 결과와 receipt를 확인한다. 기존 Key를 일괄 재발급하거나 Group과 meta를 삭제·재생성해 맞추지 않는다.
4. 중단된 빌드는 「고급 > 중단 복구」의 `중단된 Split 설정 미리 보기`·`복원`과 `중단된 Player 빌드 정보 복원`으로 복원한다.
5. Runtime 문제면 `ManagedRevisionResult`의 `Error`, `RecoveryRequired`, `Deferred`, `ReasonCode`와 `LastCleanupWarning`을 확인한다. 확인할 수 없는 결과를 성공으로 처리하지 않는다.

## 8. 구현 참조

[ProjectConfig](../Editor/ManagedAddressableProjectConfig.cs), [Window](../Editor/ManagedAddressablesWindow.cs), [PathRules](../Editor/ManagedAddressablePathRules.cs), [Naming](../Editor/ManagedAddressNaming.cs), [Preset](../Editor/ManagedAddressablePreset.cs), [Split build](../Editor/ManagedAddressableBuildExporter.Split.cs), [Player build](../Editor/ManagedBootstrapSplitPlayerBuild.cs), [Session](../Runtime/ManagedAddressableRevisionSession.cs), [Storage](../Runtime/ManagedAddressableRevisionStorage.cs).

현재 고정본의 검증 기록은 Framework checkout의 `Docs/AddressablesAudit/Pre10CompletionReport.md`, 그 뒤 후보의 검증 기록은 [CHANGELOG](../CHANGELOG.md)에 있다.
