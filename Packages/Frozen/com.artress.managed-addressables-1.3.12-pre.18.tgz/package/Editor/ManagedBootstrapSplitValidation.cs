using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedSplitEntry
    {
        internal AddressableAssetEntry entry;
        internal ManagedGroupBuildRole role;
        internal string groupAssetGuid;
        internal readonly HashSet<string> keys = new HashSet<string>(StringComparer.Ordinal);
    }

    internal static partial class ManagedAddressableBuildExporter
    {
        internal static string SplitGuid(UnityEngine.Object value) => value == null ? "" : AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(value));

        internal static List<ManagedSplitEntry> SplitEntries(ManagedAddressableProjectConfig config, AddressableAssetSettings settings)
        {
            var result = new List<ManagedSplitEntry>();
            foreach (var group in settings.groups.Where(g => g != null))
            {
                var role = (config.groupBuildRoles ?? new List<ManagedGroupBuildRoleSetting>()).FirstOrDefault(r => r != null && string.Equals(r.groupAssetGuid, SplitGuid(group), StringComparison.OrdinalIgnoreCase));
                if (role == null || role.role == ManagedGroupBuildRole.Unassigned) continue;
                var expanded = new List<AddressableAssetEntry>();
                group.GatherAllAssets(expanded, true, true, false);
                var schema = group.GetSchema<BundledAssetGroupSchema>();
                foreach (var entry in expanded.Where(e => e != null && !AssetDatabase.IsValidFolder(e.AssetPath)).GroupBy(e => e.guid).Select(g => g.First()))
                {
                    var row = new ManagedSplitEntry { entry = entry, role = role.role, groupAssetGuid = SplitGuid(group) };
                    string folderKey = schema == null || schema.IncludeFolderKeysInCatalog ? entry.ParentFolderAddress : null;
                    bool folderChild = !string.IsNullOrEmpty(folderKey) && folderKey != entry.address;
                    if ((schema == null || schema.IncludeAddressInCatalog) && (schema == null || schema.IncludeAddressesForFolderChildren || !folderChild)) row.keys.Add(entry.address);
                    if (schema == null || schema.IncludeGUIDInCatalog) row.keys.Add(entry.guid);
                    if (schema == null || schema.IncludeLabelsInCatalog) row.keys.UnionWith(entry.labels);
                    if (folderChild) row.keys.Add(folderKey);
                    row.keys.RemoveWhere(string.IsNullOrEmpty);
                    result.Add(row);
                }
            }
            return result;
        }

        public static ManagedSplitBuildReport ValidateSplitBuild(ManagedAddressableProjectConfig config, ManagedGroupBuildRole purpose)
        {
            var report = new ManagedSplitBuildReport();
            try
            {
                if (config == null) throw new InvalidOperationException("Select a Project Config.");
                if (!EditorUtility.IsPersistent(config)) report.errors.Add("Save the Split Project Config as an asset before building; SDK builds may unload transient editor objects.");
                if (purpose != ManagedGroupBuildRole.Boot && purpose != ManagedGroupBuildRole.Revision) throw new InvalidOperationException("A Boot or Revision purpose is required.");
                RequireNoPendingSplitSettings();
                var settings = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration();
                if (settings == null) throw new InvalidOperationException("Select an existing Addressables Settings using the official tools.");
                if (!ManagedAddressableBuildExporter.SplitAdapterAvailable) report.errors.Add("BootstrapSplit's binary/literal-profile adapter is verified for Addressables " + string.Join(" and ", ManagedAddressableBuildExporter.SplitVerifiedAddressablesVersions) + " only (found " + ManagedAddressableBuildExporter.AddressablesVersion + "); this build is blocked for an unsupported SDK.");
                if (settings.BuildAddressablesWithPlayerBuild != AddressableAssetSettings.PlayerBuildOption.DoNotBuildWithPlayer)
                    report.errors.Add(ManagedEditorText.L("고급 > 빌드 역할에서 빌드 역할 미리 보기 → 미리 본 계획 적용으로 DoNotBuildWithPlayer를 고르세요. SDK 자동 재빌드가 섞인 설정으로 Boot를 덮어쓸 수 있습니다.", "Select DoNotBuildWithPlayer with Advanced > Build roles > Preview Build Roles → Apply Previewed Plan. SDK automatic rebuilding can overwrite Boot with restored mixed settings."));
                if ((config.requiredBootKeys ?? new List<string>()).All(string.IsNullOrWhiteSpace)) report.errors.Add(ManagedEditorText.L("고급 > 빌드 역할에서 필수 Boot 키를 하나 이상 정하세요.", "Assign at least one required Boot key in Advanced > Build roles."));
                var roles = (config.groupBuildRoles ?? new List<ManagedGroupBuildRoleSetting>()).Where(r => r != null).ToList();
                if (roles.GroupBy(r => r.groupAssetGuid ?? "", StringComparer.OrdinalIgnoreCase).Any(g => g.Count() > 1)) report.errors.Add("Duplicate Group asset GUID role rows.");
                var groups = settings.groups.Where(g => g != null).ToList();
                foreach (var role in roles)
                    if (!groups.Any(g => string.Equals(SplitGuid(g), role.groupAssetGuid, StringComparison.OrdinalIgnoreCase)))
                        report.warnings.Add("Missing/inactive Group role GUID is preserved; remove its row explicitly if obsolete: " + role.groupAssetGuid);
                foreach (var group in groups)
                {
                    var role = roles.FirstOrDefault(r => string.Equals(r.groupAssetGuid, SplitGuid(group), StringComparison.OrdinalIgnoreCase));
                    bool special = group.Schemas.Any(s => s != null && !(s is BundledAssetGroupSchema) && !(s is ContentUpdateGroupSchema) && !(s is PlayerDataGroupSchema));
                    if (role == null || role.role == ManagedGroupBuildRole.Unassigned)
                    {
                        report.errors.Add(ManagedEditorText.L("역할이 없는 Group: ", "Unclassified Group: ") + group.Name + " / " + SplitGuid(group) + ManagedEditorText.L(". 고급 > 빌드 역할에서 이 GUID의 역할을 정하세요. 이름으로 역할을 추정하지 않으며, 빈 SDK 기본 Group도 같습니다.", ". Assign its explicit GUID in Advanced > Build roles; no role is inferred from its name, even for an empty SDK scaffold."));
                        continue;
                    }
                    bool included = role.role == purpose;
                    if (role.role != ManagedGroupBuildRole.Boot && role.role != ManagedGroupBuildRole.Revision)
                        report.errors.Add(ManagedEditorText.L("Group의 저장된 역할이 잘못됐습니다: ", "Invalid serialized role for Group ") + group.Name + " / " + SplitGuid(group) + ManagedEditorText.L(". 고급 > 빌드 역할에서 Boot 또는 Revision을 정하세요.", ". Assign Boot or Revision in Advanced > Build roles."));
                    var schema = group.GetSchema<BundledAssetGroupSchema>();
                    if (special) report.errors.Add("Unsupported contributing schema requires a reviewed SDK adapter: " + group.Name + " / " + SplitGuid(group));
                    bool schemaWrite = included && purpose == ManagedGroupBuildRole.Revision && schema != null;
                    if ((group.IncludeInBuild != included || schemaWrite) && (!config.OwnsGroup(group) || group.ReadOnly))
                        report.errors.Add("Explicit adoption is required for this build's temporary Include/path changes: " + group.Name + " / " + SplitGuid(group) + ". Role assignment grants no modification permission.");
                    if (schemaWrite && groups.Any(g => g != group && g.Schemas.Contains(schema))) report.errors.Add("Shared schema cannot be temporarily rewritten: " + AssetDatabase.GetAssetPath(schema));
                    if (schemaWrite && schema.UseDefaultSchemaSettings) report.errors.Add("Select explicit schema settings through the official Inspector before Split authoring: " + group.Name);
                    if (role.role == ManagedGroupBuildRole.Boot && schema != null && (group.entries.Count > 0 || role.useForSharedBundles) && IsHttp(schema.LoadPath.GetValue(settings)))
                        report.errors.Add("Boot requires packaged Local Bundle paths, not HTTP: " + group.Name);
                    if (role.role == ManagedGroupBuildRole.Revision && schema != null && (group.entries.Count > 0 || role.useForSharedBundles))
                    {
                        if (!IsRevisionUrl(config, schema.LoadPath.GetValue(settings))) report.errors.Add("Revision requires a fixed HTTPS root. " + ManagedRevisionTransport.PlainHttpRefused + " " + group.Name);
                        if (!schema.UseAssetBundleCache) report.errors.Add("Enable SDK AssetBundle Cache explicitly for nonzero Revision Hash identity: " + group.Name);
                        if (schema.AssetBundledCacheClearBehavior != BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache) report.errors.Add("Revision requires Keep Other Versions in the official schema: " + group.Name);
                    }
                }
                foreach (var role in new[] { ManagedGroupBuildRole.Boot, ManagedGroupBuildRole.Revision })
                {
                    var shared = roles.Where(r => r.role == role && r.useForSharedBundles).ToList();
                    if (shared.Count != 1) { report.errors.Add("Select exactly one shared-bundle target Group GUID for " + role); continue; }
                    var group = groups.FirstOrDefault(g => string.Equals(SplitGuid(g), shared[0].groupAssetGuid, StringComparison.OrdinalIgnoreCase));
                    if (group == null || !group.HasSchema<BundledAssetGroupSchema>()) report.errors.Add("Shared target is not an active bundled Group: " + shared[0].groupAssetGuid);
                }
                var entries = SplitEntries(config, settings);
                foreach (var key in config.requiredBootKeys ?? new List<string>())
                    if (!entries.Any(e => e.role == ManagedGroupBuildRole.Boot && e.keys.Contains(key))) report.errors.Add("Required Boot key has no explicit Boot entry: " + key);
                foreach (var address in entries.Where(e => e.keys.Contains(e.entry.address)).GroupBy(e => e.entry.address, StringComparer.Ordinal).Where(g => g.Select(e => e.entry.guid).Distinct().Count() > 1))
                    report.errors.Add("Ambiguous role address maps to different GUIDs: " + address.Key);
                var boot = entries.Where(e => e.role == ManagedGroupBuildRole.Boot).ToList();
                var revision = entries.Where(e => e.role == ManagedGroupBuildRole.Revision).ToList();
                foreach (var key in boot.SelectMany(e => e.keys).Intersect(revision.SelectMany(e => e.keys), StringComparer.Ordinal))
                {
                    var owners = entries.Where(e => e.keys.Contains(key)).ToList();
                    if (owners.All(e => e.entry.labels.Contains(key) && e.entry.address != key && e.entry.guid != key)) report.warnings.Add("Common label is not an exclusive role key (identity is checked separately): " + key);
                    else report.errors.Add("Boot/Revision key collision (Address/GUID/Label): " + key);
                }
                ValidateSplitDependencies(boot, revision, report);
                ValidateSplitLocalization(entries, report);
                foreach (var path in DirtyProjectAssets()) report.errors.Add("Save or discard dirty persistent input using its owner before SDK build: " + path);
                SplitOutputRoot(config); // Validate the configured output before any write.
                if (!Path.GetFullPath(UnityEngine.AddressableAssets.Addressables.BuildPath).StartsWith(Path.GetFullPath("Library") + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    report.errors.Add("Addressables BuildPath must stay inside Library: " + UnityEngine.AddressableAssets.Addressables.BuildPath);
            }
            catch (Exception e) { report.errors.Add(e.Message); }
            return report;
        }

        private static bool IsHttp(string value) => Uri.TryCreate(value, UriKind.Absolute, out var uri) && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
        private static bool IsRevisionUrl(ManagedAddressableProjectConfig config, string value) => Uri.TryCreate(value, UriKind.Absolute, out var uri) && (uri.Scheme == Uri.UriSchemeHttps || (uri.Scheme == Uri.UriSchemeHttp && config.allowDevelopmentHttp));
        // Only edits an owner can save or discard count. Imported assets (shaders, fonts, textures) keep editor-only
        // state such as dynamic font glyphs that marks them dirty and that no Save can clear. Dirty AssetImporter
        // objects (unapplied import settings) are kept. Sync uses the same rule for what SaveAssets would write.
        internal static bool IsSavableDirtyAsset(UnityEngine.Object o) =>
            o != null && EditorUtility.IsPersistent(o) && EditorUtility.IsDirty(o) && (o is AssetImporter || AssetDatabase.IsNativeAsset(o));

        internal static bool IsProjectAssetPath(string p) =>
            !string.IsNullOrEmpty(p) && (p.StartsWith("Assets/", StringComparison.Ordinal) || p.StartsWith("Packages/", StringComparison.Ordinal));

        // Unsaved edits in open scenes and in Prefab Mode live on scene objects, not persistent ones, so they are
        // listed separately. Without this the SDK builds the saved file and silently drops the edit.
        internal static IEnumerable<string> DirtyProjectAssets()
        {
            var paths = Resources.FindObjectsOfTypeAll<UnityEngine.Object>().Where(IsSavableDirtyAsset).Select(AssetDatabase.GetAssetPath).ToList();
            for (int i = 0; i < UnityEngine.SceneManagement.SceneManager.sceneCount; i++)
            {
                var scene = UnityEngine.SceneManagement.SceneManager.GetSceneAt(i);
                if (scene.isLoaded && scene.isDirty) paths.Add(scene.path);
            }
            var stage = UnityEditor.SceneManagement.PrefabStageUtility.GetCurrentPrefabStage();
            if (stage != null && stage.scene.isDirty) paths.Add(stage.assetPath);
            return paths.Where(IsProjectAssetPath).Distinct().OrderBy(p => p, StringComparer.Ordinal).ToArray();
        }
        private static IEnumerable<string> ResourcePaths() => AssetDatabase.GetAllAssetPaths().Where(p => p.StartsWith("Assets/", StringComparison.Ordinal) && p.Contains("/Resources/") && !AssetDatabase.IsValidFolder(p) && !p.EndsWith(".cs", StringComparison.Ordinal));
        private static IEnumerable<string> PlayerInputPaths() => EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).Concat(ResourcePaths()).Concat(PlayerSettings.GetPreloadedAssets().Where(o => o != null).Select(AssetDatabase.GetAssetPath)).Where(p => !string.IsNullOrEmpty(p)).Distinct();

        private static void ValidateSplitDependencies(List<ManagedSplitEntry> boot, List<ManagedSplitEntry> revision, ManagedSplitBuildReport report)
        {
            var revisionPaths = new HashSet<string>(revision.Select(e => e.entry.AssetPath), StringComparer.Ordinal);
            var bootDependencies = new HashSet<string>(AssetDatabase.GetDependencies(boot.Select(e => e.entry.AssetPath).ToArray(), true), StringComparer.Ordinal);
            var revisionDependencies = new HashSet<string>(AssetDatabase.GetDependencies(revision.Select(e => e.entry.AssetPath).ToArray(), true), StringComparer.Ordinal);
            foreach (var path in bootDependencies.Intersect(revisionPaths)) report.errors.Add("Boot depends on a Revision-owned explicit asset: " + path);
            foreach (var path in AssetDatabase.GetDependencies(PlayerInputPaths().ToArray(), true).Intersect(revisionPaths)) report.errors.Add("Player Scene/Resources/preloaded graph bakes a Revision asset independently of catalog separation: " + path);
            foreach (var path in bootDependencies.Intersect(revisionDependencies).Where(p => !p.EndsWith(".cs", StringComparison.Ordinal) && !p.EndsWith(".dll", StringComparison.Ordinal) && !p.EndsWith(".asmdef", StringComparison.Ordinal) && !p.EndsWith(".asmref", StringComparison.Ordinal)))
            {
                var value = AssetDatabase.LoadMainAssetAtPath(path);
                if (value is ScriptableObject) report.errors.Add("ScriptableObject/Localization dependency occurs in both role graphs; identity versus read-only semantics requires an explicit review before this build: " + path + ". No implicit duplication allowance is granted.");
                else report.warnings.Add("Read-only dependency may be duplicated across role bundles (object identity is not shared): " + path);
            }
        }

        private static bool IsLocalizationData(UnityEngine.Object value) => value != null && value.GetType().Namespace != null && value.GetType().Namespace.StartsWith("UnityEngine.Localization", StringComparison.Ordinal);
        private static object PublicProperty(object value, string name) => value?.GetType().GetProperty(name)?.GetValue(value);
        private static string LocaleCode(UnityEngine.Object value) => Convert.ToString(PublicProperty(PublicProperty(value, "LocaleIdentifier"), "Code"));
        private static void ValidateSplitLocalization(List<ManagedSplitEntry> entries, ManagedSplitBuildReport report)
        {
            var tables = new Dictionary<string, ManagedSplitEntry>(StringComparer.Ordinal);
            var locales = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var row in entries)
            {
                var value = AssetDatabase.LoadMainAssetAtPath(row.entry.AssetPath);
                if (!IsLocalizationData(value)) continue;
                if (value.GetType().FullName == "UnityEngine.Localization.Locale")
                {
                    string code = Convert.ToString(PublicProperty(PublicProperty(value, "Identifier"), "Code"));
                    if (row.role != ManagedGroupBuildRole.Boot) report.errors.Add("Locale identity belongs to Boot only: " + row.entry.AssetPath);
                    if (locales.TryGetValue(code, out var guid) && guid != row.entry.guid) report.errors.Add("Different Locale assets claim the same locale identity: " + code);
                    locales[code] = row.entry.guid;
                }
                var shared = PublicProperty(value, "SharedData");
                string collection = Convert.ToString(PublicProperty(shared, "TableCollectionNameGuid"));
                if (string.IsNullOrEmpty(collection)) continue;
                string identity = collection + "|" + LocaleCode(value);
                if (tables.TryGetValue(identity, out var previous) && previous.entry.guid != row.entry.guid) report.errors.Add("Conflicting Localization Collection GUID/Locale/Table identity: " + identity + " / " + previous.entry.AssetPath + " / " + row.entry.AssetPath);
                else tables[identity] = row;
            }
        }

        internal static string SplitFingerprint(ManagedAddressableProjectConfig config, AddressableAssetSettings settings)
        {
            var paths = SplitEntries(config, settings).Select(e => e.entry.AssetPath).Concat(PlayerInputPaths()).Distinct().OrderBy(p => p, StringComparer.Ordinal);
            return SplitHashText(ManagedAddressableSynchronizer.SyncFingerprint(config, settings) + "\n" + ManagedLocalRelease.FingerprintText(config) + "\n" +
                EditorUserBuildSettings.activeBuildTarget + "|" + PlayerSettings.bundleVersion + "\n" +
                string.Join("\n", paths.Select(p => p + "|" + AssetDatabase.GetAssetDependencyHash(p))));
        }
        internal static string SplitContentFingerprint(ManagedAddressableProjectConfig config, AddressableAssetSettings settings)
        {
            var paths = SplitEntries(config, settings).Select(e => e.entry.AssetPath).Concat(PlayerInputPaths()).Distinct().OrderBy(p => p, StringComparer.Ordinal);
            string configPath = AssetDatabase.GetAssetPath(config);
            return SplitHashText(ManagedAddressableSynchronizer.SyncContentFingerprint(config, settings) + "\n" + EditorUserBuildSettings.activeBuildTarget + "|" + PlayerSettings.bundleVersion + "\n" +
                string.Join("\n", paths.Select(p => p + "|" + (p == configPath ? SplitHashText(ManagedAddressableSynchronizer.SplitContentConfigFile(p)) : AssetDatabase.GetAssetDependencyHash(p).ToString()))));
        }
        internal static string SplitHashText(string value) { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(value))).Replace("-", "").ToLowerInvariant(); }
        internal static string SplitFileHash(string path) { using (var sha = SHA256.Create()) using (var stream = File.OpenRead(path)) return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant(); }
        // The validated configured root that holds every target/version split output.
        private static string SplitOutputBase(ManagedAddressableProjectConfig config)
        {
            string configured = GetBuildOutputRoot(config).Replace('\\', '/');
            string project = Path.GetFullPath(".").TrimEnd('/', '\\') + Path.DirectorySeparatorChar;
            string root = Path.GetFullPath(configured);
            string first = configured.Split('/')[0];
            if (Path.IsPathRooted(configured) || configured.Split('/').Any(p => p == "." || p == "..") || !root.StartsWith(project, StringComparison.OrdinalIgnoreCase) || first.StartsWith(".", StringComparison.Ordinal) ||
                new[] { "Assets", "Packages", "ProjectSettings", "Library", "Temp", "UserSettings", "Logs" }.Contains(first, StringComparer.OrdinalIgnoreCase))
                throw new InvalidOperationException("Split output must be a dedicated project-relative directory outside source/settings/cache folders: " + configured);
            return root;
        }

        private static string SplitOutputRoot(ManagedAddressableProjectConfig config)
        {
            string root = SplitOutputBase(config);
            if (string.IsNullOrWhiteSpace(PlayerSettings.bundleVersion) || PlayerSettings.bundleVersion.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || PlayerSettings.bundleVersion.Contains("/") || PlayerSettings.bundleVersion.Contains("\\"))
                throw new InvalidOperationException("App version must be one safe output path segment.");
            return Path.GetFullPath(Path.Combine(root, EditorUserBuildSettings.activeBuildTarget.ToString(), PlayerSettings.bundleVersion, "split"));
        }
    }
}
