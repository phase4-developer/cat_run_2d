namespace PlatformLibrary.Network
{
    /// <summary>Who handles a request. None follows <see cref="NetworkManager.DefaultRoute"/>.</summary>
    public enum NetworkRoute
    {
        None,
        Server,
        Local
    }

    /// <summary>Server provider keys. A request without its own target uses <see cref="Default"/>.</summary>
    public static class NetworkTarget
    {
        public const string Default = "default";
    }
}
