using System;
using System.Collections.Generic;
using UnityEngine;

namespace PlatformLibrary.Network
{
    /// <summary>
    /// Fails a named request a set number of times with a chosen failure, on server and local routes.
    /// Works only in the Editor and Development builds; elsewhere calls are ignored with a warning.
    /// </summary>
    public static class NetworkTestFailures
    {
        private sealed class Rule
        {
            public NetworkFailure Failure;
            public string ServerErrorCode;
            public int Remaining;
        }

        private static readonly Dictionary<string, Rule> Rules = new Dictionary<string, Rule>(StringComparer.Ordinal);

        public static bool IsAvailable
        {
            get
            {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                return true;
#else
                return false;
#endif
            }
        }

        public static void Fail(string requestName, NetworkFailure failure, int count = 1, string serverErrorCode = null)
        {
            if (string.IsNullOrEmpty(requestName)) throw new ArgumentException("A request name is required.", nameof(requestName));
            if (failure == NetworkFailure.None) throw new ArgumentException("Choose a failure.", nameof(failure));
            if (count <= 0) throw new ArgumentOutOfRangeException(nameof(count));
            if (!IsAvailable) { Debug.LogWarning("[Network] Test failures are ignored outside the Editor and Development builds."); return; }
            Rules[requestName] = new Rule { Failure = failure, ServerErrorCode = serverErrorCode, Remaining = count };
        }

        public static void Clear() => Rules.Clear();

        internal static bool TryConsume(string requestName, out NetworkResult result)
        {
            result = default;
            if (!IsAvailable || requestName == null || !Rules.TryGetValue(requestName, out Rule rule)) return false;
            if (--rule.Remaining <= 0) Rules.Remove(requestName);
            NetworkResponseFormat format = NetworkManager.ResponseFormat;
            string code = rule.ServerErrorCode;
            if (string.IsNullOrEmpty(code))
            {
                if (rule.Failure == NetworkFailure.SessionInvalid) code = format.SessionInvalidCode;
                else if (rule.Failure == NetworkFailure.Maintenance) code = format.MaintenanceCode;
                else if (rule.Failure == NetworkFailure.Rejected) code = "TEST_REJECTED";
            }
            Debug.LogWarning("[Network Test Failure] " + requestName + " -> " + rule.Failure);
            result = NetworkResult.Failed(rule.Failure, code, detail: "Injected test failure.");
            return true;
        }
    }
}
