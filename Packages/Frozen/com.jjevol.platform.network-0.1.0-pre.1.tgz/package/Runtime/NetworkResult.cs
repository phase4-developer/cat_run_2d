using System;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network
{
    /// <summary>The outcome of one request. Server and local results have the same shape.</summary>
    public readonly struct NetworkResult
    {
        public NetworkFailure Failure { get; }
        public bool Success => Failure == NetworkFailure.None;
        /// <summary>Session invalid, maintenance or cancellation. The default failure handler is not called for these.</summary>
        public bool IsInterruption => Failure == NetworkFailure.SessionInvalid || Failure == NetworkFailure.Maintenance || Failure == NetworkFailure.Cancelled;
        /// <summary>The route that actually handled the request. For logs and tests.</summary>
        public NetworkRoute Route { get; }
        /// <summary>The game error string sent by the server or local service. Defined by the game.</summary>
        public string ServerErrorCode { get; }
        public string Message { get; }
        /// <summary>Success data.</summary>
        public JObject Data { get; }
        /// <summary>The whole response, for investigation.</summary>
        public JObject Response { get; }
        /// <summary>HTTP status or Functions error code. Logs only; do not branch on it.</summary>
        public int ProviderCode { get; }
        public string Detail { get; }

        private NetworkResult(NetworkFailure failure, NetworkRoute route, string serverErrorCode, string message, JObject data, JObject response, int providerCode, string detail)
        {
            Failure = failure;
            Route = route;
            ServerErrorCode = serverErrorCode ?? string.Empty;
            Message = message ?? string.Empty;
            Data = data;
            Response = response;
            ProviderCode = providerCode;
            Detail = detail ?? string.Empty;
        }

        public static NetworkResult Succeeded(JObject data, JObject response = null, int providerCode = 0)
            => new NetworkResult(NetworkFailure.None, NetworkRoute.None, null, null, data ?? new JObject(), response, providerCode, null);

        public static NetworkResult Failed(NetworkFailure failure, string serverErrorCode = null, string message = null,
            JObject response = null, int providerCode = 0, string detail = null)
        {
            if (failure == NetworkFailure.None) throw new ArgumentException("Use Succeeded for a successful result.", nameof(failure));
            return new NetworkResult(failure, NetworkRoute.None, serverErrorCode, message, null, response, providerCode, detail);
        }

        internal NetworkResult WithRoute(NetworkRoute route)
            => new NetworkResult(Failure, route, ServerErrorCode, Message, Data, Response, ProviderCode, Detail);

        internal NetworkResult AsApplyFailed(Exception exception)
            => new NetworkResult(NetworkFailure.ApplyFailed, Route, ServerErrorCode, Message, Data, Response, ProviderCode, exception?.GetType().Name + ": " + exception?.Message);

        public override string ToString()
            => Success ? "Success(" + Route + ")" : Failure + "(" + Route + ") " + ServerErrorCode + " " + Detail;
    }
}
