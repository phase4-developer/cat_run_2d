namespace PlatformLibrary.Network
{
    /// <summary>Why a request did not succeed. Games branch on this, never on numeric provider codes.</summary>
    public enum NetworkFailure
    {
        None,
        /// <summary>No server provider or local service, or the local service does not handle the request.</summary>
        Unsupported,
        /// <summary>A provider exists but is not ready for the current environment.</summary>
        NotInitialized,
        NoConnection,
        Timeout,
        /// <summary>CancelAll, environment or route switch, session change, or caller cancellation.</summary>
        Cancelled,
        /// <summary>No or expired authentication after one forced token refresh.</summary>
        Unauthorized,
        /// <summary>The request requires a game session and there is none.</summary>
        SessionNotReady,
        /// <summary>The server reported the game session as invalid (for example a duplicate login).</summary>
        SessionInvalid,
        Maintenance,
        /// <summary>The server or local service returned a game error. See <see cref="NetworkResult.ServerErrorCode"/>.</summary>
        Rejected,
        ServerError,
        /// <summary>The response could not be decoded or parsed.</summary>
        InvalidResponse,
        /// <summary>The response applier threw. The game must not continue with unapplied data.</summary>
        ApplyFailed,
        ProviderError
    }
}
