using System;
using System.Collections.Generic;
using System.Linq;

namespace PlatformLibrary.Network
{
    /// <summary>
    /// Request spacing for server data loads: no duplicate while in flight, a cooldown after success, and
    /// invalidation that allows the next request at once. Keys are a data key plus an optional group.
    /// The clock is injected; the manager invalidates everything on environment or route switches.
    /// </summary>
    public static class NetworkRequestCache
    {
        public static readonly TimeSpan DefaultCooldown = TimeSpan.FromMinutes(15);

        private sealed class State
        {
            public long LastSuccessMs;
            public bool InFlight;
            public bool Invalidated;
        }

        private static readonly Dictionary<(string Key, int Group), State> States = new Dictionary<(string, int), State>();
        private static Func<long> _clock = () => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        /// <summary>Milliseconds clock. A project passes its server-adjusted clock.</summary>
        public static void SetClock(Func<long> clockMilliseconds) => _clock = clockMilliseconds ?? throw new ArgumentNullException(nameof(clockMilliseconds));

        /// <summary>True and marks in flight when a request may start now.</summary>
        public static bool TryBegin(string dataKey, int group = 0, bool force = false, TimeSpan? cooldown = null, bool allowDuplicateInFlight = false)
        {
            if (string.IsNullOrEmpty(dataKey)) return false;
            State state = GetOrCreate(dataKey, group);
            if (state.InFlight && !allowDuplicateInFlight) return false;
            if (!force && !state.Invalidated && !CooldownElapsed(state, cooldown ?? DefaultCooldown)) return false;
            state.InFlight = true;
            state.Invalidated = false;
            return true;
        }

        /// <summary>Records the end. A success starts the cooldown unless invalidated meanwhile; a failure allows the next request at once.</summary>
        public static void End(string dataKey, int group = 0, bool success = true)
        {
            if (string.IsNullOrEmpty(dataKey)) return;
            State state = GetOrCreate(dataKey, group);
            state.InFlight = false;
            if (success) { if (!state.Invalidated) state.LastSuccessMs = _clock(); }
            else { state.Invalidated = true; state.LastSuccessMs = 0; }
        }

        public static void MarkFresh(string dataKey, int group = 0)
        {
            if (string.IsNullOrEmpty(dataKey)) return;
            State state = GetOrCreate(dataKey, group);
            state.InFlight = false;
            state.Invalidated = false;
            state.LastSuccessMs = _clock();
        }

        public static bool CanRequest(string dataKey, int group = 0, bool force = false, TimeSpan? cooldown = null)
        {
            if (string.IsNullOrEmpty(dataKey)) return false;
            if (!States.TryGetValue((dataKey, group), out State state)) return true;
            if (state.InFlight) return false;
            return force || state.Invalidated || CooldownElapsed(state, cooldown ?? DefaultCooldown);
        }

        public static bool IsInFlight(string dataKey, int group = 0)
            => !string.IsNullOrEmpty(dataKey) && States.TryGetValue((dataKey, group), out State state) && state.InFlight;

        public static TimeSpan GetRemainingCooldown(string dataKey, int group = 0, TimeSpan? cooldown = null)
        {
            if (string.IsNullOrEmpty(dataKey) || !States.TryGetValue((dataKey, group), out State state) || state.Invalidated || state.LastSuccessMs <= 0)
                return TimeSpan.Zero;
            double remaining = (cooldown ?? DefaultCooldown).TotalMilliseconds - (_clock() - state.LastSuccessMs);
            return remaining > 0 ? TimeSpan.FromMilliseconds(remaining) : TimeSpan.Zero;
        }

        /// <summary>The next request may start at once. An in-flight request is not duplicated.</summary>
        public static void Invalidate(string dataKey, int group = 0)
        {
            if (string.IsNullOrEmpty(dataKey)) return;
            GetOrCreate(dataKey, group).Invalidated = true;
        }

        public static void InvalidateAllGroups(string dataKey)
        {
            foreach (var pair in States.Where(pair => pair.Key.Key == dataKey)) pair.Value.Invalidated = true;
        }

        public static void InvalidateAll()
        {
            foreach (State state in States.Values) state.Invalidated = true;
        }

        // Environment and route switches cancel every request, so nothing stays in flight.
        internal static void ResetForSwitch()
        {
            foreach (State state in States.Values) { state.Invalidated = true; state.InFlight = false; }
        }

        public static void ResetAll()
        {
            States.Clear();
            _clock = () => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }

        private static State GetOrCreate(string key, int group)
        {
            if (!States.TryGetValue((key, group), out State state)) States[(key, group)] = state = new State();
            return state;
        }

        private static bool CooldownElapsed(State state, TimeSpan cooldown)
            => state.LastSuccessMs <= 0 || _clock() - state.LastSuccessMs >= cooldown.TotalMilliseconds;
    }
}
