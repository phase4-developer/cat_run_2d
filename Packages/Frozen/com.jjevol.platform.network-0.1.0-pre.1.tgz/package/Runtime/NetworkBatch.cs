using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace PlatformLibrary.Network
{
    /// <summary>Sends several requests and completes when all have finished. <c>yield return batch</c> waits for it.</summary>
    public sealed class NetworkBatch : IEnumerator
    {
        private readonly List<NetworkRequest> _requests;
        private int _remaining;
        private Action<NetworkBatch> _completed;
        private bool _started;

        public IReadOnlyList<NetworkRequest> Requests => _requests;
        public bool Completed { get; private set; }
        public bool Success => Completed && _requests.All(request => request.Result.Success);
        public NetworkRequest FirstFailure => _requests.FirstOrDefault(request => request.Completed && !request.Result.Success);

        public NetworkBatch(IEnumerable<NetworkRequest> requests)
        {
            if (requests == null) throw new ArgumentNullException(nameof(requests));
            _requests = requests.Where(request => request != null).ToList();
        }

        /// <summary>Sends every request at once.</summary>
        public NetworkBatch Post(Action<NetworkBatch> completed = null) => Send(completed, false);

        /// <summary>Sends every request through the ordered queue.</summary>
        public NetworkBatch PostQueue(Action<NetworkBatch> completed = null) => Send(completed, true);

        private NetworkBatch Send(Action<NetworkBatch> completed, bool queued)
        {
            if (_started) throw new InvalidOperationException("A batch is sent once.");
            _started = true;
            _completed = completed;
            _remaining = _requests.Count;
            if (_remaining == 0) { Complete(); return this; }
            foreach (NetworkRequest request in _requests)
            {
                if (queued) NetworkManager.PostQueue(request, OnRequestCompleted);
                else NetworkManager.Post(request, OnRequestCompleted);
            }
            return this;
        }

        private void OnRequestCompleted(NetworkResult result)
        {
            if (--_remaining == 0) Complete();
        }

        private void Complete()
        {
            Completed = true;
            try { _completed?.Invoke(this); }
            catch (Exception exception) { UnityEngine.Debug.LogException(exception); }
        }

        object IEnumerator.Current => null;
        bool IEnumerator.MoveNext() => !Completed;
        void IEnumerator.Reset() { }
    }
}
