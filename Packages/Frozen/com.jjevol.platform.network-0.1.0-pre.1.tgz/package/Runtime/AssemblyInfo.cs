using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Network.Tests.Editor")]
