using System;

namespace PlatformLibrary.Network
{
    /// <summary>Automatic retry for NoConnection, Timeout and ServerError. Off unless a request sets it.</summary>
    public sealed class NetworkRetryPolicy
    {
        /// <summary>Extra attempts after the first.</summary>
        public int Retries { get; }
        public TimeSpan Delay { get; }
        public double Multiplier { get; }

        public NetworkRetryPolicy(int retries, TimeSpan delay, double multiplier = 2d)
        {
            if (retries < 0) throw new ArgumentOutOfRangeException(nameof(retries));
            if (delay < TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(delay));
            if (multiplier < 1d) throw new ArgumentOutOfRangeException(nameof(multiplier));
            Retries = retries; Delay = delay; Multiplier = multiplier;
        }

        public static bool IsRetryable(NetworkFailure failure)
            => failure == NetworkFailure.NoConnection || failure == NetworkFailure.Timeout || failure == NetworkFailure.ServerError;

        public bool ShouldRetry(NetworkFailure failure, int attempt) => IsRetryable(failure) && attempt <= Retries;

        /// <summary>Delay before the next attempt after <paramref name="attempt"/> failed.</summary>
        public TimeSpan GetDelay(int attempt)
            => TimeSpan.FromMilliseconds(Delay.TotalMilliseconds * Math.Pow(Multiplier, Math.Max(0, attempt - 1)));
    }

    /// <summary>
    /// Given to the default failure handler. The request callback waits until the handler calls
    /// <see cref="Retry"/> or <see cref="Finish"/>. If the handler throws, the request finishes.
    /// </summary>
    public sealed class NetworkFailureContext
    {
        private readonly Action _retry, _finish;
        private bool _decided;
        public NetworkRequest Request { get; }
        public NetworkResult Result { get; }
        public bool IsDecided => _decided;

        internal NetworkFailureContext(NetworkRequest request, NetworkResult result, Action retry, Action finish)
        { Request = request; Result = result; _retry = retry; _finish = finish; }

        /// <summary>Sends the same request again (for example after the user confirms). The callback gets the new result.</summary>
        public void Retry() { if (Decide()) _retry(); }
        /// <summary>Gives up and delivers this failure to the request callback.</summary>
        public void Finish() { if (Decide()) _finish(); }

        private bool Decide()
        {
            if (_decided) return false;
            _decided = true;
            return true;
        }
    }

    /// <summary>Session invalid or maintenance notice, raised once per state change.</summary>
    public readonly struct NetworkInterruption
    {
        public NetworkFailure Reason { get; }
        public string ServerErrorCode { get; }
        public string Message { get; }
        public NetworkInterruption(NetworkFailure reason, string serverErrorCode, string message)
        { Reason = reason; ServerErrorCode = serverErrorCode ?? string.Empty; Message = message ?? string.Empty; }
    }

    /// <summary>Read-only view of the game session and maintenance state. The session ID is never stored.</summary>
    public sealed class NetworkSession
    {
        public string SessionId { get; internal set; }
        public bool HasSession => !string.IsNullOrEmpty(SessionId);
        public bool IsSessionInvalid { get; internal set; }
        public bool IsMaintenance { get; internal set; }
        public string MaintenanceMessage { get; internal set; } = string.Empty;
        public bool MaintenanceBypass { get; internal set; }

        internal void Reset()
        {
            SessionId = null;
            IsSessionInvalid = false;
            IsMaintenance = false;
            MaintenanceMessage = string.Empty;
            MaintenanceBypass = false;
        }
    }
}
