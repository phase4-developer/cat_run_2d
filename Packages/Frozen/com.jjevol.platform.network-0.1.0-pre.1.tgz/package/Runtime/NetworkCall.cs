using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network
{
    /// <summary>One attempt of a request as handed to a provider or local service.</summary>
    public sealed class NetworkCall
    {
        public NetworkRequest Request { get; }
        /// <summary>Defaults merged with the request values. Providers may add transport values (for example the session ID).</summary>
        public Dictionary<string, object> Parameters { get; }
        public string EnvironmentKey { get; }
        /// <summary>The current game session ID, or null.</summary>
        public string SessionId { get; }
        /// <summary>1 for the first attempt, then 2, 3 for automatic retries.</summary>
        public int Attempt { get; }
        public NetworkRoute Route { get; }
        public NetworkResponseFormat Format { get; }

        public NetworkCall(NetworkRequest request, Dictionary<string, object> parameters, string environmentKey, string sessionId,
            int attempt, NetworkRoute route, NetworkResponseFormat format)
        {
            Request = request ?? throw new ArgumentNullException(nameof(request));
            Parameters = parameters ?? new Dictionary<string, object>(StringComparer.Ordinal);
            EnvironmentKey = environmentKey ?? string.Empty;
            SessionId = sessionId;
            Attempt = attempt;
            Route = route;
            Format = format ?? new NetworkResponseFormat();
        }
    }

    /// <summary>A server transport (HTTP, Firebase Functions). Holds no session state.</summary>
    public interface INetworkProvider
    {
        bool IsReady(string environmentKey);
        /// <summary>
        /// Sends one attempt and maps transport errors to <see cref="NetworkFailure"/>. The manager owns routing,
        /// session and maintenance state, retries, the queue, loading, the response applier and callbacks.
        /// </summary>
        Task<NetworkResult> SendAsync(NetworkCall call, CancellationToken cancellationToken);
    }

    /// <summary>Project-implemented local processing for requests routed to <see cref="NetworkRoute.Local"/>.</summary>
    public interface INetworkLocalService
    {
        bool CanHandle(NetworkRequest request);
        /// <summary>Returns the success data. Throw <see cref="NetworkRejection"/> for a game error.</summary>
        Task<JObject> HandleAsync(NetworkCall call, CancellationToken cancellationToken);
    }
}
