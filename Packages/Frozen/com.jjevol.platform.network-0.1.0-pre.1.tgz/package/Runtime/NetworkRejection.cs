using System;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network
{
    /// <summary>Thrown by a local service to return a game error. The request ends as <see cref="NetworkFailure.Rejected"/>.</summary>
    public sealed class NetworkRejection : Exception
    {
        public string Code { get; }
        public JObject Details { get; }

        public NetworkRejection(string code, string message = null, JObject details = null)
            : base(string.IsNullOrEmpty(message) ? code : message)
        {
            if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("A game error code is required.", nameof(code));
            Code = code;
            Details = details;
        }
    }
}
