# Changelog

## 0.1.0-pre.1 - 2026-11-08

- First candidate. `NetworkManager`, `NetworkRequest`, `NetworkResult`, `NetworkFailure`, `NetworkRoute`, `INetworkProvider`, `INetworkLocalService`, `NetworkRejection`, `NetworkResponseFormat`, `NetworkRetryPolicy`, `NetworkFailureContext`, `NetworkSession`, `NetworkBatch`, `NetworkRequestCache`, `NetworkTestFailures`.
- Environment, route and session changes update the state before cancelled callbacks run, so requests posted from those callbacks use the new environment and session.
- `SetSession`, `ClearSession` and `ResetSession` cancel sent and undecided requests only. Queued requests stay and are sent with the new session.
- The `PostAsync` and `PostQueueAsync` cancellation token also ends a request waiting in the queue or for a failure decision.
- Design: `Docs/PlatformNetwork/Design.md`.

Unity EditMode tests passed on Hosts/NetworkValidationHost (job network-host-2, candidate abd61a5). The Editor tests passed in an offline .NET runner with a stand-in for `UnityEngine.Debug`.
