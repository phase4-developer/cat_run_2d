# Provenance and distribution boundary

User-authored code, written as a redesign of the user's original network libraries (`jjevol_library_mobile` `Assets/Common/Script/Network` and `Assets/Common/Script/Firebase/Network`, read only). The originals and the user's existing mobile and Steam games were used as reference only; class names and GUIDs are not kept, with the user's approval on 2026-11-08.

No SDK source, product keys, server addresses, company content or paid Vendor source is bundled. Unity Newtonsoft JSON is a declared dependency.

This is an unfrozen local validation candidate. Publishing and installing into existing games remain separate review steps.
