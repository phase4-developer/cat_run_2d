using UnityEngine;
using System;

namespace jjevol.Effect.Behaviours
{
    public class JumpPopBehaviour : MonoBehaviour, IEffectBehaviour
    {
        private bool _isConfigured;
        public bool IsFinished { get; private set; }

        public Action OnComplete;

        private Vector3 _bounceStartPos;
        private float _timer;
        private float _duration;
        private float _xForce;
        private float _yForce;
        private int _currentBounce;
        private int _maxBounce;

        public void SetJump(float xPower, float yPower, float duration = 0.5f, int bounceCount = 2)
        {
            //수정
            _duration = Mathf.Max(0.01f, duration);
            _maxBounce = Mathf.Max(1, bounceCount);
            //수정 종료

            _currentBounce = 0;
            _xForce = xPower;
            _yForce = yPower;
            _timer = 0f;

            _isConfigured = true;
            IsFinished = false;
        }

        public void Begin(EffectHandle handle)
        {
            _bounceStartPos = transform.localPosition;
        }

        public void Tick(float dt)
        {
            if (!_isConfigured || IsFinished) return;

            _timer += dt;
            float t = _timer / _duration;

            Vector3 currentPos = _bounceStartPos;
            currentPos.x += _timer * _xForce;
            currentPos.y += CalculateJumpCurve(t) * _yForce;

            transform.localPosition = currentPos;

            if (t >= 1.0f)
            {
                _currentBounce++;

                if (_currentBounce < _maxBounce)
                {
                    _bounceStartPos = transform.localPosition;
                    _timer = 0f;
                    _xForce *= 0.5f;
                    _yForce *= 0.5f;
                }
                else
                {
                    IsFinished = true;
                    OnComplete?.Invoke();
                }
            }
        }

        private float CalculateJumpCurve(float t)
        {
            t = Mathf.Clamp01(t);
            return 4 * t * (1 - t);
        }

        //수정
        public void End()
        {
            OnComplete = null;
            _bounceStartPos = Vector3.zero;
            _timer = 0f;
            _duration = 0f;
            _xForce = 0f;
            _yForce = 0f;
            _currentBounce = 0;
            _maxBounce = 0;
            _isConfigured = false;
            IsFinished = true;
        }
        //수정 종료
    }
}
