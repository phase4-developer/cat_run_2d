﻿//추가
using System;
using UnityEngine;

namespace jjevol.Effect.Behaviours
{
    public class UIJumpPopBehaviour : MonoBehaviour, IEffectBehaviour
    {
        private bool _isConfigured;
        public bool IsFinished { get; private set; }

        public Action OnComplete;

        private RectTransform _rectTransform;
        private Vector2 _bounceStartPos;

        private float _timer;
        private float _duration;
        private float _xPower;
        private float _yPower;
        private int _currentBounce;
        private int _maxBounce;

        public void SetJump(float xPower, float yPower, float duration = 0.35f, int bounceCount = 1)
        {
            _duration = Mathf.Max(0.01f, duration);
            _maxBounce = Mathf.Max(1, bounceCount);

            _xPower = xPower;
            _yPower = yPower;
            _timer = 0f;
            _currentBounce = 0;

            _isConfigured = true;
            IsFinished = false;
        }

        public void Begin(EffectHandle handle)
        {
            _rectTransform = transform as RectTransform;

            if (_rectTransform == null)
            {
                IsFinished = true;
                return;
            }

            _bounceStartPos = _rectTransform.anchoredPosition;
        }

        public void Tick(float dt)
        {
            if (!_isConfigured || IsFinished || _rectTransform == null) return;

            _timer += dt;
            float t = Mathf.Clamp01(_timer / _duration);

            Vector2 currentPos = _bounceStartPos;
            currentPos.x += _timer * _xPower;
            currentPos.y += CalculateJumpCurve(t) * _yPower;

            _rectTransform.anchoredPosition = currentPos;

            if (t >= 1f)
            {
                _currentBounce++;

                if (_currentBounce < _maxBounce)
                {
                    _bounceStartPos = _rectTransform.anchoredPosition;
                    _timer = 0f;
                    _xPower *= 0.5f;
                    _yPower *= 0.5f;
                }
                else
                {
                    IsFinished = true;
                    OnComplete?.Invoke();
                }
            }
        }

        private float CalculateJumpCurve(float t)
        {
            return 4f * t * (1f - t);
        }

        public void End()
        {
            OnComplete = null;
            _rectTransform = null;
            _bounceStartPos = Vector2.zero;
            _timer = 0f;
            _duration = 0f;
            _xPower = 0f;
            _yPower = 0f;
            _currentBounce = 0;
            _maxBounce = 0;
            _isConfigured = false;
            IsFinished = true;
        }
    }
}
//추가 종료
