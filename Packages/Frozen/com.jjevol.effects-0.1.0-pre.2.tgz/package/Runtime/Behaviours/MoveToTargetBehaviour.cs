﻿using System;
using UnityEngine;

namespace jjevol.Effect.Behaviours
{
    public class MoveToTargetBehaviour : MonoBehaviour, IEffectBehaviour
    {
        private bool _isConfigured;
        public bool IsFinished { get; private set; }

        public Action OnReached;

        private Transform _target;
        private float _speed;
        private float _accel = 15f;

        private bool _useFixedTargetPosition;
        private Vector3 _fixedTargetPosition;

        public void SetTarget(Transform target, float startSpeed = 5f)
        {
            _isConfigured = true;

            _useFixedTargetPosition = false;
            _fixedTargetPosition = Vector3.zero;

            _target = target;
            _speed = Mathf.Max(0f, startSpeed);
            IsFinished = _target == null;
        }

        public void SetTargetPosition(Vector3 targetPosition, float startSpeed = 5f)
        {
            _isConfigured = true;

            _target = null;
            _useFixedTargetPosition = true;
            _fixedTargetPosition = targetPosition;

            _speed = Mathf.Max(0f, startSpeed);
            IsFinished = false;
        }

        public void SetWorldPosition(Vector3 worldPosition, float startSpeed = 5f)
        {
            SetTargetPosition(worldPosition, startSpeed);
        }

        public void Begin(EffectHandle handle) { }

        public void Tick(float dt)
        {
            if (!_isConfigured || IsFinished) return;

            Vector3 destination;

            if (_useFixedTargetPosition)
            {
                destination = _fixedTargetPosition;
            }
            else
            {
                if (!_target)
                {
                    IsFinished = true;
                    return;
                }

                destination = _target.position;
            }

            _speed += _accel * dt;
            transform.position = Vector3.MoveTowards(transform.position, destination, _speed * dt);

            if (Vector3.Distance(transform.position, destination) < 0.1f)
            {
                IsFinished = true;
                OnReached?.Invoke();
            }
        }

        public void End()
        {
            OnReached = null;
            _target = null;
            _speed = 0f;

            _useFixedTargetPosition = false;
            _fixedTargetPosition = Vector3.zero;

            _isConfigured = false;
            IsFinished = true;
        }
    }
}
