using UnityEngine;

namespace jjevol.Effect
{
    public sealed class FollowTargetBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public bool IsFinished { get; private set; }

        public Transform Target;
        public Vector3 Offset;

        EffectHandle _handle;
        // 프리팹에 저장된 값. 코드로 붙이면 비어 있다. End가 여기로 되돌려 풀 재사용에도 유지된다.
        Transform _authoredTarget;
        Vector3 _authoredOffset;
        bool _authoredCaptured;
        // Target이 없는 동안에는 설정을 기다리고, 한 번 따라간 Target이 사라지면 끝난다.
        bool _hadTarget;

        public void Begin(EffectHandle handle)
        {
            if (!_authoredCaptured)
            {
                _authoredCaptured = true;
                _authoredTarget = Target;
                _authoredOffset = Offset;
            }

            _handle = handle;
            _hadTarget = false;
            IsFinished = false;
        }

        public void Tick(float dt)
        {
            if (!_handle)
            {
                IsFinished = true;
                return;
            }

            if (!Target)
            {
                if (_hadTarget) IsFinished = true;
                return;
            }

            _hadTarget = true;
            _handle.transform.position = Target.position + Offset;
        }

        public void End()
        {
            Target = _authoredTarget;
            Offset = _authoredOffset;
            _handle = null;
            IsFinished = true;
        }
    }
}
