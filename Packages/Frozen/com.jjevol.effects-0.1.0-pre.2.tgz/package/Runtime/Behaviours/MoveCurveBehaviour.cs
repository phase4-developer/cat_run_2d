using System;
using UnityEngine;

namespace jjevol.Effect.Behaviours
{
    /// <summary>
    /// UI 요소를 곡선(베지어) 궤적으로 이동시키는 범용 모듈.
    /// 시작점, 제어점(랜덤), 도착점(고정)을 이용해 이동합니다.
    /// </summary>
    public class MoveCurveBehaviour : MonoBehaviour, IEffectBehaviour
    {
        private bool _isConfigured;
        public bool IsFinished { get; private set; }

        public Action OnReached;

        private RectTransform _rectTransform;
        private Vector3 _startPos;
        private Vector3 _controlPoint;
        private Vector3 _endPos;
        private float _duration;
        private float _elapsed;

        private bool _useWorldPosition;
        private bool _useCubicCurve;
        private Transform _worldTarget;
        private Vector3 _controlPoint2;

        /// <summary>
        /// 곡선 이동 설정
        /// </summary>
        /// <param name="endPos">최종 도착지 (부모 RectTransform 기준 anchoredPosition)</param>
        /// <param name="duration">이동 시간</param>
        /// <param name="spreadDistance">사방으로 퍼지는 거리</param>
        public void SetCurve(Vector2 endPos, float duration, float spreadDistance)
        {
            _isConfigured = true;

            _useWorldPosition = false;
            _useCubicCurve = false;
            _worldTarget = null;

            //수정
            _rectTransform = transform as RectTransform;
            if (_rectTransform == null)
            {
                IsFinished = true;
                return;
            }

            _duration = Mathf.Max(0.01f, duration);
            //수정 종료

            _elapsed = 0f;
            _startPos = _rectTransform.anchoredPosition;
            _endPos = endPos;

            Vector2 randomDir = UnityEngine.Random.insideUnitCircle.normalized;

            //추가
            if (randomDir == Vector2.zero)
                randomDir = Vector2.right;
            //추가 종료

            _controlPoint = _startPos + (Vector3)(randomDir * spreadDistance);

            IsFinished = false;
        }

        /// <summary>
        /// 월드 좌표 기준 흡혈형 곡선 이동.
        /// 시작 위치에서 먼저 뒤쪽으로 빠졌다가, 타겟으로 빨려 들어가는 형태입니다.
        /// </summary>
        public void SetWorldDrainCurve(
            Transform target,
            float duration,
            float backDistance,
            float curveHeight,
            float targetPullDistance = 0.4f)
        {
            _isConfigured = true;

            _useWorldPosition = true;
            _useCubicCurve = true;
            _worldTarget = target;
            _rectTransform = null;

            _duration = Mathf.Max(0.01f, duration);
            _elapsed = 0f;

            _startPos = transform.position;
            _endPos = target != null ? target.position : _startPos;

            Vector3 dirToTarget = (_endPos - _startPos).normalized;
            if (dirToTarget == Vector3.zero)
                dirToTarget = Vector3.right;

            Vector3 backDir = -dirToTarget;

            float verticalSign = UnityEngine.Random.value > 0.5f ? 1f : -1f;
            Vector3 verticalOffset = Vector3.up * curveHeight * verticalSign;

            _controlPoint =
                _startPos +
                backDir * backDistance +
                verticalOffset;

            _controlPoint2 =
                _endPos +
                backDir * targetPullDistance -
                verticalOffset * 0.35f;

            IsFinished = false;
        }

        public void Begin(EffectHandle handle) { }

        public void Tick(float dt)
        {
            if (!_isConfigured || IsFinished) return;

            //추가
            if (!_useWorldPosition && _rectTransform == null)
            {
                IsFinished = true;
                return;
            }
            //추가 종료

            _elapsed += dt;
            float t = Mathf.Clamp01(_elapsed / _duration);

            if (_useWorldPosition && _worldTarget != null)
            {
                _endPos = _worldTarget.position;
            }

            Vector3 nextPos;

            if (_useCubicCurve)
            {
                nextPos = CalculateCubicBezier(_startPos, _controlPoint, _controlPoint2, _endPos, t);
            }
            else
            {
                nextPos = Mathf.Pow(1 - t, 2) * _startPos +
                          2 * (1 - t) * t * _controlPoint +
                          Mathf.Pow(t, 2) * _endPos;
            }

            if (_useWorldPosition)
                transform.position = nextPos;
            else
                _rectTransform.anchoredPosition = nextPos;

            if (t >= 1.0f)
            {
                IsFinished = true;
                OnReached?.Invoke();
            }
        }

        private Vector3 CalculateCubicBezier(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            float invT = 1f - t;

            return
                invT * invT * invT * p0 +
                3f * invT * invT * t * p1 +
                3f * invT * t * t * p2 +
                t * t * t * p3;
        }

        //수정
        public void End()
        {
            OnReached = null;
            _rectTransform = null;
            _worldTarget = null;
            _startPos = Vector3.zero;
            _controlPoint = Vector3.zero;
            _controlPoint2 = Vector3.zero;
            _endPos = Vector3.zero;
            _duration = 0f;
            _elapsed = 0f;
            _useWorldPosition = false;
            _useCubicCurve = false;
            _isConfigured = false;
            IsFinished = true;
        }
        //수정 종료
    }
}
