using System;
using UnityEngine;

namespace jjevol.Effect.Behaviours
{
    public class UIBurstScatterBehaviour : MonoBehaviour, IEffectBehaviour
    {
        private bool _isConfigured;
        //수정
        public bool IsFinished { get; private set; }
        //수정 종료

        public Action OnReached;

        private RectTransform _rectTransform;
        private Vector2 _startPos;
        private Vector2 _controlPoint;
        private Vector2 _endPos;
        private float _duration;
        private float _elapsed;

        public void SetBurst(Vector2 localEndPos, float burstRadius, float duration)
        {
            _isConfigured = true;

             _rectTransform = GetComponent<RectTransform>();
            _endPos = localEndPos;
            _duration = Mathf.Max(0.01f, duration);
            _elapsed = 0f;
            _startPos = _rectTransform.anchoredPosition;

            Vector2 dirToTarget = (_endPos - _startPos).normalized;

            if (dirToTarget == Vector2.zero)
                dirToTarget = Vector2.right;

            Vector2 awayDir = -dirToTarget;
            Vector2 sideDir = new Vector2(-dirToTarget.y, dirToTarget.x);
            float sideSign = (UnityEngine.Random.value > 0.5f) ? 1f : -1f;

            _controlPoint = _startPos + (awayDir * burstRadius * 0.7f) + (sideDir * sideSign * burstRadius * 1.0f);

            IsFinished = false;
        }

        public void Begin(EffectHandle handle) { }

        public void Tick(float dt)
        {
            if (!_isConfigured || IsFinished || _rectTransform == null) return;

            _elapsed += dt;
            float rawT = Mathf.Clamp01(_elapsed / _duration);

            float t = rawT == 1f ? 1f : 1f - Mathf.Pow(2f, -7f * rawT);

            Vector2 nextPos = Mathf.Pow(1 - t, 2) * _startPos +
                              2 * (1 - t) * t * _controlPoint +
                              Mathf.Pow(t, 2) * _endPos;

            _rectTransform.anchoredPosition = nextPos;

            if (rawT >= 1.0f)
            {
                IsFinished = true;
                OnReached?.Invoke();
            }
        }

        //수정
        public void End()
        {
            OnReached = null;
            _rectTransform = null;
            _startPos = Vector2.zero;
            _controlPoint = Vector2.zero;
            _endPos = Vector2.zero;
            _duration = 0f;
            _elapsed = 0f;
            _isConfigured = false;
            IsFinished = true;
        }
        //수정 종료
    }
}
