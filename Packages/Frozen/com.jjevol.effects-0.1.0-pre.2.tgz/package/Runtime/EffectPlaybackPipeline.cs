using System;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>Play와 PlayAsync의 공통 파이프라인: 프리팹 확보 → 바인딩 → 재생.</summary>
    internal sealed class EffectPlaybackPipeline
    {
        readonly EffectPrefabCache _prefabs;
        readonly EffectInstanceBinder _binder;

        public EffectPlaybackPipeline(EffectPrefabCache prefabs, EffectInstanceBinder binder)
        {
            _prefabs = prefabs;
            _binder = binder;
        }

        public async UniTaskVoid RunDetached(EffectHandle handle, int version)
        {
            try { await Run(handle, version); }
            catch (OperationCanceledException) { }
            catch (Exception exception) { Debug.LogException(exception); }
        }

        public async UniTask<bool> Run(EffectHandle handle, int version)
        {
            try
            {
                // 풀 Handle을 켜는 OnEnable에서 끝난 요청을 재사용 경로가 되살리지 않게 한다.
                if (!handle.IsCurrent(version)) return false;

                // 프리팹 인스턴스가 스스로 파괴되었으면 이 요청에서 다시 바인딩한다.
                if (handle.IsRendererDestroyed) handle.Unbind();

                if (handle.Renderer == null)
                {
                    var prefab = await _prefabs.LoadAsync(handle.EffectType);
                    if (handle == null || !handle.IsCurrent(version)) return false;

                    if (!prefab)
                    {
                        handle.Terminate(EffectEndReason.Failed);
                        return false;
                    }

                    _binder.Bind(handle, prefab, version);
                    if (!handle.IsCurrent(version)) return false;
                }

                handle.StartPlayback();
                return true;
            }
            catch (Exception) when (handle != null && handle.IsCurrent(version))
            {
                handle.Terminate(EffectEndReason.Failed);
                throw;
            }
        }
    }
}
