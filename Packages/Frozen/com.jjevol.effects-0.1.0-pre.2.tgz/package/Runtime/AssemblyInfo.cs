using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("JJEvol.Effects.Tests.Runtime")]
