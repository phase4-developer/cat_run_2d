using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol.Effect
{
    public sealed class EffectPrefabLease : IDisposable
    {
        Action _release;
        public GameObject Prefab { get; }
        public EffectPrefabLease(GameObject prefab, Action release = null) { Prefab = prefab; _release = release; }
        public void Dispose() => Interlocked.Exchange(ref _release, null)?.Invoke();
    }
    public interface IEffectPrefabProvider
    {
        UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken cancellationToken);
    }
    public sealed class ResourcesEffectPrefabProvider : IEffectPrefabProvider
    {
        public UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var prefab = Resources.Load<GameObject>(key);
            return UniTask.FromResult(prefab ? new EffectPrefabLease(prefab) : null);
        }
    }
    public static class EffectRendererAdapters
    {
        public static readonly List<Func<GameObject, IEffectRenderer>> Factories = new();
    }
}

namespace Jjevol.EditorAttributes
{
    public sealed class SortingLayerFieldAttribute : PropertyAttribute { }
}
