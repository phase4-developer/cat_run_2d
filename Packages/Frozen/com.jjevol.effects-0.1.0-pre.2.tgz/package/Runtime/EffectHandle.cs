using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>
    /// Handle 수명 상태. 값은 <see cref="EffectHandle"/>의 필드 하나에만 있다.
    /// Idle(풀 대기) → Loading → Playing → Finished(Stop으로 멈춤, 회수 대기) → Retiring → Idle
    /// Loading과 Playing은 Finished를 거치지 않고 바로 Retiring으로 갈 수 있다.
    /// </summary>
    internal enum EffectHandleState { Idle, Loading, Playing, Finished, Retiring }

    /// <summary> 단일 이펙트 인스턴스 수명 제어 </summary>
    public sealed class EffectHandle : MonoBehaviour
    {
        public IEffectRenderer Renderer { get; private set; }
        public EffectRequest Request { get; private set; }
        public string EffectType { get; private set; }
        public bool IsPlaying => State == EffectHandleState.Playing;
        public bool IsLoop => Request.loop;
        public int RequestVersion => _requestVersion;

        /// <summary>Renderer가 자연 완료했을 때 1회 호출. 구독은 현재 요청에만 유효하다.</summary>
        public event Action<EffectHandle> OnComplete;

        internal EffectHandleState State { get; private set; }

        private IEffectHandleHost _host;
        private int _requestVersion;
        // 수명 상태와 직교하는 두 플래그. 요청마다 초기화한다.
        private bool _isPaused;
        // 비활성 계층에 있어 Renderer를 돌릴 수 없고 Host의 지연 처리를 기다리는 중이다.
        private bool _suspended;

        private readonly List<IEffectBehaviour> _activeBehaviours = new(4);
        // 재사용을 위해 대기 중인 모듈 풀 (Type별 관리)
        private readonly Dictionary<Type, Stack<IEffectBehaviour>> _behaviourPool = new();
        private readonly List<IEffectBehaviour> _builtInBehaviours = new(4);

        private bool IsLive => State == EffectHandleState.Loading || State == EffectHandleState.Playing;

        // Renderer는 인터페이스라 == null이 Unity 파괴를 보지 못한다. Unity 객체가 아닌 구현은 파괴되지 않는다.
        internal bool IsRendererDestroyed => Renderer is UnityEngine.Object unityRenderer && unityRenderer == null;

        internal bool IsCurrent(int requestVersion) => this != null && IsLive && _requestVersion == requestVersion;

        internal void Initialize(string effectType, IEffectHandleHost host)
        {
            if (_host != null) throw new InvalidOperationException("An EffectHandle is initialized once.");
            EffectType = effectType;
            _host = host;
        }

        private void OnDisable()
        {
            // 비활성화 콜백 안에서는 재부모화할 수 없으므로 표시만 하고 Host에 맡긴다.
            if (!IsLive) return;
            _suspended = true;
            _host?.RequestSettle(this);
        }

        private void OnEnable()
        {
            if (_suspended) _host?.RequestSettle(this);
        }

        private void OnDestroy() => Terminate(EffectEndReason.Destroyed);

        internal int Configure(in EffectRequest req)
        {
            InvalidateRequest();

            // 이미 끝난 Handle에 늦게 구독한 호출자가 다음 요청의 완료를 받지 않게 한다.
            OnComplete = null;
            Request = req;
            State = EffectHandleState.Loading;
            _isPaused = false;
            _suspended = false;

            var rt = transform as RectTransform; // RectTransform으로 취급

            if (req.parent && rt.parent != req.parent)
                rt.SetParent(req.parent, false);

            // --- UI/World 전환 대응을 위한 초기화 ---
            if (req.parent is RectTransform)
            {
                rt.anchorMin = Vector2.one * 0.5f;
                rt.anchorMax = Vector2.one * 0.5f;
                rt.pivot = Vector2.one * 0.5f;

                rt.anchoredPosition3D = req.localPosition;
            }
            else
            {
                rt.localPosition = req.localPosition;
            }

            rt.localRotation = req.localRotation;
            rt.localScale = req.localScale;

            return _requestVersion;
        }

        internal void Bind(IEffectRenderer renderer)
        {
            Renderer = renderer;
            (renderer as IEffectRendererStateRestore)?.CaptureState();
        }

        /// <summary>바인딩에 실패했거나 파괴된 인스턴스의 참조를 지운다. 인스턴스 파괴는 호출자가 한다.</summary>
        internal void Unbind()
        {
            Renderer = null;
            foreach (var b in _builtInBehaviours) _activeBehaviours.Remove(b);
            _builtInBehaviours.Clear();
        }

        // ▼ 초기 로드 시 프리팹에 붙어있는 모듈을 등록하고 바로 시작
        internal void RegisterBuiltIn(IEffectBehaviour b, int version)
        {
            if (b == null || _builtInBehaviours.Contains(b)) return;

            _builtInBehaviours.Add(b);
            // 앞선 Begin이 요청을 끝냈으면 목록에만 남겨 재사용 때 시작하게 한다.
            if (!IsCurrent(version)) return;

            _activeBehaviours.Add(b);
            b.Begin(this);
        }

        /// <summary> 런타임에 모듈을 추가하거나 풀에서 꺼내옴 (Tweener 방식) </summary>
        public T AddBehaviour<T>() where T : Component, IEffectBehaviour
        {
            Type type = typeof(T);
            T behaviour;

            // 1. 풀에 사용 가능한 컴포넌트가 있는지 확인
            if (_behaviourPool.TryGetValue(type, out var stack) && stack.Count > 0)
            {
                behaviour = (T)stack.Pop();
                (behaviour as Behaviour).enabled = true; // 활성화하여 재사용
            }
            else
            {
                // 2. 없으면 새로 생성
                behaviour = gameObject.AddComponent<T>();
            }

            _activeBehaviours.Add(behaviour);
            behaviour.Begin(this);
            return behaviour;
        }

        /// <summary>Loading → Playing. 비활성 계층이면 Renderer를 돌리지 않고 지연 처리로 넘긴다.</summary>
        internal void StartPlayback()
        {
            State = EffectHandleState.Playing;

            if (!gameObject.activeInHierarchy)
            {
                _suspended = true;
                _host?.RequestSettle(this);
                return;
            }

            RunRenderer();
        }

        private void RunRenderer()
        {
            _suspended = false;

            Renderer.SetSorting(Request.sortingLayer, Request.sortingOrder);
            Renderer.SetUnscaledTime(Request.unscaledTime);
            Renderer.SetSkin(Request.skinIndex);

            foreach (var b in _builtInBehaviours)
            {
                // 비동기 로드 직후에는 RegisterBuiltIn이 이미 Begin을 호출했으므로 중복 호출 방지
                if (!_activeBehaviours.Contains(b))
                {
                    var comp = b as Behaviour;
                    if (comp != null) comp.enabled = true;

                    _activeBehaviours.Add(b);
                    b.Begin(this);
                }
            }

            int version = _requestVersion;
            Renderer.Play(Request.animationIndex, Request.loop, () => OnRendererCompleted(version));
            // 로드 완료 전에 요청된 일시정지와 재활성화 전의 일시정지를 유지한다.
            if (_isPaused && IsCurrent(version)) Renderer.SetPaused(true);
        }

        private void OnRendererCompleted(int version)
        {
            if (IsCurrent(version) && State == EffectHandleState.Playing && !IsLoop)
                Terminate(EffectEndReason.Completed);
        }

        /// <summary>
        /// EffectSettleQueue가 비활성화 콜백 밖에서 부른다.
        /// 비루프는 Interrupted로 끝내고, 루프는 계층이 다시 활성화되면 재생을 다시 시작한다.
        /// </summary>
        internal void Settle()
        {
            if (State == EffectHandleState.Idle)
            {
                _host?.ReturnSettledToRoot(this);
                return;
            }

            if (!IsLive || !_suspended) return;

            if (!IsLoop)
            {
                // 코루틴은 비활성화와 함께 끝났으므로 같은 프레임에 다시 켜졌어도 완료 통지가 오지 않는다.
                Terminate(EffectEndReason.Interrupted);
                return;
            }

            if (State == EffectHandleState.Playing && gameObject.activeInHierarchy) RestartRenderer();
        }

        private void RestartRenderer()
        {
            Renderer.StopAndClear();

            for (int i = _activeBehaviours.Count - 1; i >= 0; i--)
                if (_activeBehaviours[i].IsFinished) RecycleBehaviour(_activeBehaviours[i]);

            RunRenderer();
        }

        public void Pause()
        {
            if (!IsLive) return;
            _isPaused = true;
            Renderer?.SetPaused(true);
        }

        public void Resume()
        {
            if (!IsLive) return;
            _isPaused = false;
            Renderer?.SetPaused(false);
        }

        public void SetSorting(string layer, int order) { Renderer?.SetSorting(layer, order); }
        public void SetSkin(int skinIndex) { Renderer?.SetSkin(skinIndex); }
        public void SetUnscaledTime(bool unscaled) { Renderer?.SetUnscaledTime(unscaled); }

        private void Update()
        {
            if (State != EffectHandleState.Playing || _isPaused || _suspended) return;
            float dt = Request.unscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
            int version = _requestVersion;

            // 역순으로 돌면서 업데이트 및 완료된 모듈 정리
            for (int i = _activeBehaviours.Count - 1; i >= 0; i--)
            {
                if (i >= _activeBehaviours.Count) continue;

                var b = _activeBehaviours[i];
                try
                {
                    b.Tick(dt);

                    // Tick 안에서 Despawn·재사용되면 남은 순회는 이전 요청의 것이다.
                    if (_requestVersion != version) return;

                    // 유한한 동작(점프 등)이 끝났을 경우 자동 회수
                    if (b.IsFinished)
                    {
                        RecycleBehaviour(b);
                    }
                }
                catch (Exception exception)
                {
                    Debug.LogException(exception);
                    // Tick이 요청을 끝낸 뒤 던졌다면 Handle은 이미 다음 요청의 것이다.
                    if (IsCurrent(version)) Terminate(EffectEndReason.Failed);
                    return;
                }
            }
        }

        private void RecycleBehaviour(IEffectBehaviour b)
        {
            if (b == null || !_activeBehaviours.Contains(b)) return;

            b.End();
            if (_activeBehaviours.Remove(b))
            {
                var comp = b as Behaviour;
                if (comp != null) comp.enabled = false;

                if (_builtInBehaviours.Contains(b)) return;

                Type type = b.GetType();
                if (!_behaviourPool.ContainsKey(type))
                    _behaviourPool[type] = new Stack<IEffectBehaviour>();

                _behaviourPool[type].Push(b);
            }
        }

        /// <summary>재생만 멈춘다. Handle 회수와 callBack은 Despawn에서 일어난다.</summary>
        public void Stop()
        {
            if (!IsLive) return;

            State = EffectHandleState.Finished;
            InvalidateRequest();
            _suspended = false;
            StopRenderer();
        }

        /// <summary>
        /// 유일한 종료 경로. 자연 완료, Despawn, 로드 실패, 예외, 부모 비활성, 파괴가 모두 여기를 지난다.
        /// Destroyed를 제외한 이유는 Handle을 풀로 돌리고 callBack을 정확히 한 번 호출한다.
        /// 지연 처리 전에 파괴된 Handle은 onEnded만 부른다. 소유자 파괴는 그 전에 Despawned로 끝난다.
        /// </summary>
        internal void Terminate(EffectEndReason reason)
        {
            bool destroyed = reason == EffectEndReason.Destroyed;
            bool retiring = State == EffectHandleState.Retiring;
            if (!destroyed && (State == EffectHandleState.Idle || retiring)) return;

            Action callBack = destroyed ? null : Request.callBack;
            Action<EffectHandle> completed = reason == EffectEndReason.Completed ? OnComplete : null;
            // 종료 도중 파괴되면 진행 중인 Terminate가 onEnded를 이미 쥐고 있다.
            Action<EffectEndReason> ended = retiring ? null : Request.onEnded;

            State = EffectHandleState.Retiring;
            InvalidateRequest();

            // 프리팹 Renderer와 모듈은 자기 OnDestroy로 정리된다.
            if (!destroyed) ReleasePlayback();

            // Cleanup may destroy this handle at once. The nested Destroyed end has already retired it.
            if (!destroyed && this == null)
            {
                Notify(callBack, completed, ended, reason);
                return;
            }

            Request = EffectRequest.Default;
            OnComplete = null;
            _isPaused = false;
            _suspended = false;

            if (destroyed)
            {
                State = EffectHandleState.Idle;
                _host?.Retire(this);
                Notify(null, null, ended, reason);
                return;
            }

            gameObject.SetActive(false);
            State = EffectHandleState.Idle;

            // 알림이 끝난 뒤 풀로 돌린다. OnComplete가 새 요청을 재생 중인 Handle을 받지 않게 한다.
            Notify(callBack, completed, ended, reason);
            _host?.Reclaim(this);
        }

        private void StopRenderer()
        {
            if (Renderer == null || IsRendererDestroyed) return;

            // Renderer의 일시정지를 풀어 다음 요청이 멈춘 채 시작하지 않게 한다.
            if (_isPaused) Renderer.SetPaused(false);
            _isPaused = false;
            Renderer.StopAndClear();
        }

        private void ReleasePlayback()
        {
            try { StopRenderer(); }
            catch (Exception exception) { Debug.LogException(exception); }

            while (_activeBehaviours.Count > 0)
            {
                // 리스트의 마지막 요소를 꺼내서 RecycleBehaviour에 전달 (매개변수 1개)
                var behaviour = _activeBehaviours[_activeBehaviours.Count - 1];
                try { RecycleBehaviour(behaviour); }
                catch (Exception exception)
                {
                    _activeBehaviours.Remove(behaviour);
                    Debug.LogException(exception);
                }
            }

            try { if (!IsRendererDestroyed) (Renderer as IEffectRendererStateRestore)?.RestoreState(); }
            catch (Exception exception) { Debug.LogException(exception); }
        }

        private void Notify(Action callBack, Action<EffectHandle> completed, Action<EffectEndReason> ended, EffectEndReason reason)
        {
            // 호출자 하나의 예외가 다른 Handle의 종료를 끊지 않게 로그로 남긴다.
            try { callBack?.Invoke(); }
            catch (Exception exception) { Debug.LogException(exception); }

            try { completed?.Invoke(this); }
            catch (Exception exception) { Debug.LogException(exception); }

            try { ended?.Invoke(reason); }
            catch (Exception exception) { Debug.LogException(exception); }
        }

        private void InvalidateRequest()
        {
            unchecked
            {
                _requestVersion++;

                if (_requestVersion == 0)
                    _requestVersion = 1;
            }
        }
    }
}
