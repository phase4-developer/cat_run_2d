using Jjevol.EditorAttributes;
using System;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary> 인스펙터 편집 가능하도록 직렬화된 이펙트 요청 값 </summary>
    [Serializable]
    public struct EffectRequest
    {
        [Header("Type / Anim")]
        public string effectType;
        public int skinIndex;
        public int animationIndex;
        public bool loop;

        [Header("Sorting")]
        [SortingLayerField, SerializeField] public string sortingLayer;   // 예: "Effect"
        public int sortingOrder;

        [Header("Timing")]
        public bool unscaledTime;

        // ScriptableObject 자산에서 씬 오브젝트 참조는 깨지기 쉽습니다.
        // 필요 시 런타임에만 세팅하세요. (인스펙터 노출을 원하면 [SerializeField] 유지)
        [Header("Attach (Optional at Runtime)")]
        public Transform parent;

        [Header("Transform (Local)")]
        public Vector3 localPosition;
        public Vector3 localScale;
        public Quaternion localRotation;

        public string icon;

        public bool IsValid => !string.IsNullOrEmpty(effectType);

        public Action callBack;

        /// <summary>요청이 끝날 때 이유와 함께 1회 호출. callBack과 달리 Handle 파괴도 전달한다.</summary>
        public Action<EffectEndReason> onEnded;

        public void SetScale(Vector3 scale)
        {
            localScale = scale;
        }

        // 인스펙터용 기본값
        public static EffectRequest Default => new EffectRequest
        {
            effectType = "",
            skinIndex = 0,
            animationIndex = 0,
            loop = false,
            sortingLayer = "",
            sortingOrder = 0,
            unscaledTime = false,
            parent = null,
            localPosition = Vector3.zero,
            localScale = Vector3.one,
            localRotation = Quaternion.identity,
            icon = string.Empty,
            callBack = null,
            onEnded = null
        };

        // 필요 시 코드에서 편하게 빌드하는 생성자(선택)
        public EffectRequest(
            string effectType,
            int skinIndex = 0,
            int animationIndex = 0,
            bool loop = false,
            string sortingLayer = "",
            int sortingOrder = 0,
            bool unscaledTime = false,
            Transform parent = null,
            Vector3? localPos = null,
            Vector3? localScale = null,
            Quaternion? localRot = null,
            string icon = null,
            Action callBack = null,
            Action<EffectEndReason> onEnded = null)
        {
            this.effectType = effectType;
            this.skinIndex = skinIndex;
            this.animationIndex = animationIndex;
            this.loop = loop;
            this.sortingLayer = sortingLayer;
            this.sortingOrder = sortingOrder;
            this.unscaledTime = unscaledTime;
            this.parent = parent;
            this.localPosition = localPos ?? Vector3.zero;
            this.localScale = localScale ?? Vector3.one;
            this.localRotation = localRot ?? Quaternion.identity;
            this.icon = icon ?? string.Empty;
            this.callBack = callBack;
            this.onEnded = onEnded;
        }
    }
}
