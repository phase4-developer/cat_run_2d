namespace jjevol.Effect
{
    /// <summary>EffectHandle이 소유자에게 요구하는 동작 전부.</summary>
    internal interface IEffectHandleHost
    {
        /// <summary>비활성화 콜백 밖에서 Handle.Settle이 불리도록 예약한다.</summary>
        void RequestSettle(EffectHandle handle);

        /// <summary>종료된 Handle을 풀로 돌린다. Terminate만 호출한다.</summary>
        void Reclaim(EffectHandle handle);

        /// <summary>지연 처리의 Idle 경로 전용. 진행 중인 비활성화가 없을 때만 불린다.</summary>
        void ReturnSettledToRoot(EffectHandle handle);

        /// <summary>파괴된 Handle의 소유를 끝낸다.</summary>
        void Retire(EffectHandle handle);
    }
}
