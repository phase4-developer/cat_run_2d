using System;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>Spine/Particle/Sprite 렌더러 공통 어댑터</summary>
    public interface IEffectRenderer
    {
        Transform Root { get; }
        void SetSorting(string layer, int order);
        void SetPaused(bool paused);
        void SetUnscaledTime(bool unscaled);
        void SetSkin(int skinIndex);
        void Play(int animationIndex, bool loop, Action onComplete);
        void StopAndClear();
    }
}
