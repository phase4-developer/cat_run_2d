using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace jjevol.Effect
{
    /// <summary>
    /// 프리팹 인스턴스의 Sorting 값을 저장하고 복원한다.
    /// IEffectRendererStateRestore 구현에서 쓴다. 요청의 빈 Sorting Layer는 값을 바꾸지 않으므로,
    /// 복원하지 않으면 이전 요청의 값이 다음 요청으로 넘어간다.
    /// </summary>
    public sealed class EffectSortingSnapshot
    {
        readonly List<(Renderer target, int layerId, int order)> _renderers = new();
        readonly List<(SortingGroup target, int layerId, int order)> _groups = new();
        readonly List<(Canvas target, bool overrideSorting, int layerId, int order)> _canvases = new();

        /// <summary>root와 비활성을 포함한 자식의 현재 값을 저장한다.</summary>
        public void Capture(GameObject root)
        {
            _renderers.Clear();
            _groups.Clear();
            _canvases.Clear();

            foreach (var renderer in root.GetComponentsInChildren<Renderer>(true))
                _renderers.Add((renderer, renderer.sortingLayerID, renderer.sortingOrder));
            foreach (var group in root.GetComponentsInChildren<SortingGroup>(true))
                _groups.Add((group, group.sortingLayerID, group.sortingOrder));
            foreach (var canvas in root.GetComponentsInChildren<Canvas>(true))
                _canvases.Add((canvas, canvas.overrideSorting, canvas.sortingLayerID, canvas.sortingOrder));
        }

        /// <summary>Capture 이후 파괴된 대상은 건너뛴다.</summary>
        public void Restore()
        {
            foreach (var (target, layerId, order) in _renderers)
            {
                if (!target) continue;
                target.sortingLayerID = layerId;
                target.sortingOrder = order;
            }

            foreach (var (target, layerId, order) in _groups)
            {
                if (!target) continue;
                target.sortingLayerID = layerId;
                target.sortingOrder = order;
            }

            foreach (var (target, overrideSorting, layerId, order) in _canvases)
            {
                if (!target) continue;
                target.overrideSorting = overrideSorting;
                target.sortingLayerID = layerId;
                target.sortingOrder = order;
            }
        }
    }
}
