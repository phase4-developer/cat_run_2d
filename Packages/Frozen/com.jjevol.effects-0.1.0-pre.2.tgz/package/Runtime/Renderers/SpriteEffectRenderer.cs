using System;
using UnityEngine;

namespace jjevol.Effect.Renderers
{
    public sealed class SpriteEffectRenderer : MonoBehaviour, IEffectRenderer, IEffectRendererStateRestore
    {
        SpriteRenderer _sr;
        public Transform Root => transform;

        readonly EffectSortingSnapshot _sorting = new();
        void IEffectRendererStateRestore.CaptureState() => _sorting.Capture(gameObject);
        void IEffectRendererStateRestore.RestoreState() => _sorting.Restore();

        void Awake()
        {
            _sr = GetComponent<SpriteRenderer>() ?? gameObject.AddComponent<SpriteRenderer>();
        }

        public void SetSorting(string layer, int order)
        {
            if (string.IsNullOrEmpty(layer)) return;

            if (_sr) { _sr.sortingLayerName = layer; _sr.sortingOrder = order; }
        }

        public void SetPaused(bool paused) { }
        public void SetUnscaledTime(bool unscaled) { }
        public void SetSkin(int skinIndex) { }

        public void Play(int animationIndex, bool loop, Action onComplete)
        {
            if (!loop) onComplete?.Invoke();
        }

        public void StopAndClear() { }
    }
}
