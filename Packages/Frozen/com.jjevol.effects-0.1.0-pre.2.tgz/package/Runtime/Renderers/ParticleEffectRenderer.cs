using System;
using UnityEngine;
using UnityEngine.Rendering;

namespace jjevol.Effect.Renderers
{
    public sealed class ParticleEffectRenderer : MonoBehaviour, IEffectRenderer, IEffectRendererStateRestore
    {
        // ��Ʈ�� ParticleSystem �ϳ�, �Ǵ� ��Ʈ�� �����̸� �ڽ� ��ü.
        ParticleSystem[] _systems = Array.Empty<ParticleSystem>();
        SortingGroup _sortingGroup;

        bool _useUnscaledTime;
        bool _isPaused;
        Coroutine _waitCo;

        readonly EffectSortingSnapshot _sorting = new();
        void IEffectRendererStateRestore.CaptureState() => _sorting.Capture(gameObject);
        void IEffectRendererStateRestore.RestoreState() => _sorting.Restore();

        public Transform Root => transform;

        void Awake()
        {
            var rootSystem = GetComponent<ParticleSystem>();
            _systems = rootSystem ? new[] { rootSystem } : GetComponentsInChildren<ParticleSystem>();
            _sortingGroup = GetComponent<SortingGroup>();
        }

        public void SetSorting(string layer, int order)
        {
            if (string.IsNullOrEmpty(layer)) return;

            foreach (var system in _systems)
            {
                if (!system) continue;
                var pr = system.GetComponent<ParticleSystemRenderer>();
                if (!pr) continue;
                pr.sortingLayerName = layer;
                pr.sortingOrder = order;
            }

            if (_sortingGroup)
            {
                _sortingGroup.sortingLayerName = layer;
                _sortingGroup.sortingOrder = order;
            }
        }

        public void SetPaused(bool paused)
        {
            _isPaused = paused;
            foreach (var system in _systems)
            {
                if (!system) continue;
                if (paused) system.Pause();
                else system.Play();
            }
        }

        public void SetUnscaledTime(bool unscaled)
        {
            _useUnscaledTime = unscaled;
            // simulation and waiter must use the same clock.
            foreach (var system in _systems)
            {
                if (!system) continue;
                var main = system.main;
                main.useUnscaledTime = unscaled;
            }
        }

        public void SetSkin(int skinIndex) { /* not used for particle */ }

        public void Play(int animationIndex, bool loop, Action onComplete)
        {
            // �ߺ� ��� ��ȣ
            if (_waitCo != null)
            {
                StopCoroutine(_waitCo);
                _waitCo = null;
            }

            // ����� ����� ���� ������� Handle�� ����� ���� �ʰ� �ٷ� �Ϸ��Ѵ�.
            if (!AnySystem())
            {
                if (!loop) onComplete?.Invoke();
                return;
            }

            _isPaused = false;
            foreach (var system in _systems)
            {
                if (!system) continue;
                var main = system.main;
                main.loop = loop;
                main.useUnscaledTime = _useUnscaledTime;
                system.Play(true);
            }

            if (!loop)
            {
                _waitCo = StartCoroutine(Co_FinishAfterPlay(onComplete));
            }
        }

        System.Collections.IEnumerator Co_FinishAfterPlay(Action onComplete)
        {
            // 1) Ÿ�Ӿƿ�(���� �� ��ƼŬ ����): duration / simulationSpeed + startLifetimeMultiplier (+ ��)
            float approxDuration = 0f;
            foreach (var system in _systems)
            {
                if (!system) continue;
                var main = system.main;
                float simSpeed = Mathf.Max(0.0001f, main.simulationSpeed);
                approxDuration = Mathf.Max(approxDuration, (main.duration / simSpeed) + main.startLifetimeMultiplier + 0.05f);
            }

            float elapsed = 0f;

            // 2) �Ϸ� ����:
            // Include child emitters when the root only groups the effect.
            //   - Ȥ�� IsAlive�� Ư�̼������� ��� true�� �Ǵ��� Ÿ�Ӿƿ��� ����
            while (elapsed < approxDuration && AnyAlive())
            {
                // paused playback must not consume timeout.
                if (_isPaused) { yield return null; continue; }
                elapsed += _useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
                yield return null;
            }

            _waitCo = null;
            onComplete?.Invoke();
        }

        public void StopAndClear()
        {
            _isPaused = false;
            if (_waitCo != null)
            {
                StopCoroutine(_waitCo);
                _waitCo = null;
            }

            foreach (var system in _systems)
            {
                if (system) system.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            }
        }

        bool AnySystem()
        {
            foreach (var system in _systems)
                if (system) return true;
            return false;
        }

        bool AnyAlive()
        {
            foreach (var system in _systems)
                if (system && system.IsAlive(true)) return true;
            return false;
        }
    }
}
