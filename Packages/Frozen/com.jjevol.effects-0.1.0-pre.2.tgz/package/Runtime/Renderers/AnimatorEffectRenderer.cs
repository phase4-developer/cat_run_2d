﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace jjevol.Effect.Renderers
{
    public sealed class AnimatorEffectRenderer : MonoBehaviour, IEffectRenderer, IEffectRendererStateRestore
    {
        private enum AnimatorPlayMode
        {
            StateName,
            Trigger
        }

        [Header("Animator")]
        [SerializeField] private Animator animator;
        [SerializeField] private AnimatorPlayMode playMode = AnimatorPlayMode.StateName;
        [SerializeField] private int layerIndex = 0;

        [Header("State Play")]
        [SerializeField] private string defaultStateName = "Play";
        [SerializeField] private List<string> stateNames = new();

        [Header("Trigger Play")]
        [SerializeField] private string triggerName = "Play";
        [SerializeField] private string waitStateName = "";
        [SerializeField] private bool resetTriggerBeforePlay = true;

        [Header("Stop")]
        [SerializeField] private bool rewindOnStop = true;
        [SerializeField] private bool disableAnimatorOnStop = false;

        [Header("Particle References")]
        [SerializeField] private bool playParticles = true;
        [SerializeField] private bool clearParticlesOnPlay = true;
        [SerializeField] private bool clearParticlesOnStop = true;
        [SerializeField] private List<ParticleSystem> particleSystems = new();

        [Header("Sorting References")]
        [SerializeField] private List<Canvas> sortingCanvases = new();
        [SerializeField] private List<SortingGroup> sortingGroups = new();
        [SerializeField] private List<SpriteRenderer> spriteRenderers = new();
        [SerializeField] private List<ParticleSystemRenderer> particleRenderers = new();

        [Header("Safety")]
        [SerializeField] private float fallbackCompleteSeconds = 5f;

        private bool _useUnscaledTime;
        private bool _isPaused;
        private Coroutine _waitCoroutine;
        private string _lastPlayedStateName = "";

        private readonly EffectSortingSnapshot _sorting = new();
        void IEffectRendererStateRestore.CaptureState() => _sorting.Capture(gameObject);
        void IEffectRendererStateRestore.RestoreState() => _sorting.Restore();

        public Transform Root => transform;

        private void Awake()
        {
            if (animator == null)
                animator = GetComponent<Animator>();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (animator == null)
                animator = GetComponent<Animator>();
        }

        [ContextMenu("Collect References In Children")]
        private void CollectReferencesInChildrenEditorOnly()
        {
            particleSystems.Clear();
            sortingCanvases.Clear();
            sortingGroups.Clear();
            spriteRenderers.Clear();
            particleRenderers.Clear();

            ParticleSystem[] particles = GetComponentsInChildren<ParticleSystem>(true);
            for (int i = 0; i < particles.Length; i++)
            {
                if (particles[i] != null && !particleSystems.Contains(particles[i]))
                    particleSystems.Add(particles[i]);
            }

            Canvas[] canvases = GetComponentsInChildren<Canvas>(true);
            for (int i = 0; i < canvases.Length; i++)
            {
                if (canvases[i] != null && !sortingCanvases.Contains(canvases[i]))
                    sortingCanvases.Add(canvases[i]);
            }

            SortingGroup[] groups = GetComponentsInChildren<SortingGroup>(true);
            for (int i = 0; i < groups.Length; i++)
            {
                if (groups[i] != null && !sortingGroups.Contains(groups[i]))
                    sortingGroups.Add(groups[i]);
            }

            SpriteRenderer[] sprites = GetComponentsInChildren<SpriteRenderer>(true);
            for (int i = 0; i < sprites.Length; i++)
            {
                if (sprites[i] != null && !spriteRenderers.Contains(sprites[i]))
                    spriteRenderers.Add(sprites[i]);
            }

            ParticleSystemRenderer[] particleRenderersArray = GetComponentsInChildren<ParticleSystemRenderer>(true);
            for (int i = 0; i < particleRenderersArray.Length; i++)
            {
                if (particleRenderersArray[i] != null && !particleRenderers.Contains(particleRenderersArray[i]))
                    particleRenderers.Add(particleRenderersArray[i]);
            }

            UnityEditor.EditorUtility.SetDirty(this);
        }
#endif

        public void SetSorting(string layer, int order)
        {
            if (string.IsNullOrEmpty(layer)) return;

            for (int i = 0; i < sortingCanvases.Count; i++)
            {
                Canvas canvas = sortingCanvases[i];
                if (canvas == null) continue;

                canvas.overrideSorting = true;
                canvas.sortingLayerName = layer;
                canvas.sortingOrder = order;
            }

            for (int i = 0; i < sortingGroups.Count; i++)
            {
                SortingGroup sortingGroup = sortingGroups[i];
                if (sortingGroup == null) continue;

                sortingGroup.sortingLayerName = layer;
                sortingGroup.sortingOrder = order;
            }

            for (int i = 0; i < spriteRenderers.Count; i++)
            {
                SpriteRenderer spriteRenderer = spriteRenderers[i];
                if (spriteRenderer == null) continue;

                spriteRenderer.sortingLayerName = layer;
                spriteRenderer.sortingOrder = order;
            }

            for (int i = 0; i < particleRenderers.Count; i++)
            {
                ParticleSystemRenderer particleRenderer = particleRenderers[i];
                if (particleRenderer == null) continue;

                particleRenderer.sortingLayerName = layer;
                particleRenderer.sortingOrder = order;
            }
        }

        public void SetPaused(bool paused)
        {
            _isPaused = paused;

            if (animator != null)
                animator.speed = paused ? 0f : 1f;

            if (!playParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem particleSystem = particleSystems[i];
                if (particleSystem == null) continue;

                if (paused)
                    particleSystem.Pause(true);
                else
                    particleSystem.Play(true);
            }
        }

        public void SetUnscaledTime(bool unscaled)
        {
            _useUnscaledTime = unscaled;

            if (animator != null)
            {
                animator.updateMode = unscaled
                    ? AnimatorUpdateMode.UnscaledTime
                    : AnimatorUpdateMode.Normal;
            }

            if (!playParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem particleSystem = particleSystems[i];
                if (particleSystem == null) continue;

                ParticleSystem.MainModule main = particleSystem.main;
                main.useUnscaledTime = unscaled;
            }
        }

        public void SetSkin(int skinIndex)
        {
        }

        public void Play(int animationIndex, bool loop, Action onComplete)
        {
            StopWaitCoroutine();

            if (animator == null)
            {
                onComplete?.Invoke();
                return;
            }

            _isPaused = false;

            animator.enabled = true;
            animator.speed = 1f;

            PrepareParticles(loop);

            string targetStateName = ResolveStateName(animationIndex);
            _lastPlayedStateName = targetStateName;

            if (playMode == AnimatorPlayMode.StateName)
            {
                if (string.IsNullOrEmpty(targetStateName))
                {
                    Debug.LogWarning($"[{nameof(AnimatorEffectRenderer)}] 재생할 Animator State Name이 비어 있습니다. Object:{name}");
                    onComplete?.Invoke();
                    return;
                }

                animator.Play(targetStateName, layerIndex, 0f);
                animator.Update(0f);
            }
            else
            {
                if (string.IsNullOrEmpty(triggerName))
                {
                    Debug.LogWarning($"[{nameof(AnimatorEffectRenderer)}] Trigger Name이 비어 있습니다. Object:{name}");
                    onComplete?.Invoke();
                    return;
                }

                if (resetTriggerBeforePlay)
                    animator.ResetTrigger(triggerName);

                animator.SetTrigger(triggerName);
                animator.Update(0f);
            }

            PlayParticles();

            if (!loop)
            {
                string stateNameToWait = GetWaitStateName(targetStateName);
                _waitCoroutine = StartCoroutine(Co_WaitComplete(stateNameToWait, onComplete));
            }
        }

        public void StopAndClear()
        {
            StopWaitCoroutine();

            _isPaused = false;

            StopParticles();

            if (animator == null) return;

            animator.speed = 1f;

            if (resetTriggerBeforePlay && !string.IsNullOrEmpty(triggerName))
                animator.ResetTrigger(triggerName);

            if (rewindOnStop)
            {
                string stateName = !string.IsNullOrEmpty(_lastPlayedStateName)
                    ? _lastPlayedStateName
                    : defaultStateName;

                if (!string.IsNullOrEmpty(stateName))
                {
                    animator.Play(stateName, layerIndex, 0f);
                    animator.Update(0f);
                }
            }

            if (disableAnimatorOnStop)
                animator.enabled = false;
        }

        private string ResolveStateName(int animationIndex)
        {
            if (stateNames != null &&
                animationIndex >= 0 &&
                animationIndex < stateNames.Count &&
                !string.IsNullOrEmpty(stateNames[animationIndex]))
            {
                return stateNames[animationIndex];
            }

            return defaultStateName;
        }

        private string GetWaitStateName(string targetStateName)
        {
            if (!string.IsNullOrEmpty(waitStateName))
                return waitStateName;

            return targetStateName;
        }

        private IEnumerator Co_WaitComplete(string stateNameToWait, Action onComplete)
        {
            float elapsed = 0f;

            yield return null;

            while (animator != null)
            {
                // paused playback must not consume fallback time.
                if (_isPaused) { yield return null; continue; }
                bool animatorDone = IsAnimatorDone(stateNameToWait);
                bool particlesDone = !AnyParticleAlive();

                if (animatorDone && particlesDone)
                    break;

                elapsed += _useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;

                if (elapsed >= fallbackCompleteSeconds)
                {
                    Debug.LogWarning($"[{nameof(AnimatorEffectRenderer)}] Animator 완료 대기 타임아웃. Object:{name}, State:{stateNameToWait}");
                    break;
                }

                yield return null;
            }

            _waitCoroutine = null;
            onComplete?.Invoke();
        }

        private bool IsAnimatorDone(string stateNameToWait)
        {
            if (animator == null)
                return true;

            if (animator.IsInTransition(layerIndex))
                return false;

            AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(layerIndex);

            if (!string.IsNullOrEmpty(stateNameToWait) && !stateInfo.IsName(stateNameToWait))
                return false;

            return stateInfo.normalizedTime >= 1f;
        }

        private void PrepareParticles(bool loop)
        {
            if (!playParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem particleSystem = particleSystems[i];
                if (particleSystem == null) continue;

                ParticleSystem.MainModule main = particleSystem.main;
                main.loop = loop;
                main.useUnscaledTime = _useUnscaledTime;

                if (clearParticlesOnPlay)
                    particleSystem.Clear(true);
            }
        }

        private void PlayParticles()
        {
            if (!playParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem particleSystem = particleSystems[i];
                if (particleSystem == null) continue;

                particleSystem.gameObject.SetActive(true);
                particleSystem.Play(true);
            }
        }

        private void StopParticles()
        {
            if (!playParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem particleSystem = particleSystems[i];
                if (particleSystem == null) continue;

                particleSystem.Stop(true, clearParticlesOnStop
                    ? ParticleSystemStopBehavior.StopEmittingAndClear
                    : ParticleSystemStopBehavior.StopEmitting);
            }
        }

        private bool AnyParticleAlive()
        {
            if (!playParticles) return false;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem particleSystem = particleSystems[i];
                if (particleSystem == null) continue;

                if (particleSystem.IsAlive(true))
                    return true;
            }

            return false;
        }

        private void StopWaitCoroutine()
        {
            if (_waitCoroutine == null) return;

            StopCoroutine(_waitCoroutine);
            _waitCoroutine = null;
        }
    }
}
