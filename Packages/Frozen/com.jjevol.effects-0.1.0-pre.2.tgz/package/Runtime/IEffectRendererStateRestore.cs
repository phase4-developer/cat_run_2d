namespace jjevol.Effect
{
    /// <summary>
    /// 선택 인터페이스. 풀 재사용 사이에 프리팹 원본 상태로 되돌려야 하는 Renderer가 구현한다.
    /// 구현하지 않은 Renderer는 기존처럼 SetPaused(false)와 StopAndClear만 받는다.
    /// </summary>
    public interface IEffectRendererStateRestore
    {
        /// <summary>인스턴스 바인딩 직후 한 번, 요청 값을 적용하기 전에 호출된다.</summary>
        void CaptureState();

        /// <summary>요청이 끝날 때마다 StopAndClear 뒤에 호출된다.</summary>
        void RestoreState();
    }
}
