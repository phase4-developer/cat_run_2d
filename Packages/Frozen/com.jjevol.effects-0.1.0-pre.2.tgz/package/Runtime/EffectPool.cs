using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>
    /// 타입 하나의 풀. per-handle 코루틴 기반 분산 Auto-Cull(Time.time)과 마지막 인스턴스의 프리팹 해제를 맡는다.
    /// 자기가 만든 Handle의 <see cref="IEffectHandleHost"/>이다.
    /// </summary>
    internal sealed class EffectPool : IEffectHandleHost
    {
        readonly string _key;
        readonly Transform _root;
        readonly MonoBehaviour _coroutines;
        readonly EffectSettleQueue _settleQueue;
        readonly EffectPrefabCache _prefabs;
        readonly HashSet<EffectHandle> _owned;

        PoolProfile _profile;

        readonly Stack<EffectHandle> _idle = new();
        // track scene-destroyed active instances.
        readonly HashSet<EffectHandle> _active = new();
        public int TotalCount => _active.Count + _idle.Count;

        public EffectPool(string key, Transform root, PoolProfile profile, MonoBehaviour coroutines, EffectSettleQueue settleQueue, EffectPrefabCache prefabs, HashSet<EffectHandle> owned)
        {
            _key = key; _root = root; _profile = profile;
            _coroutines = coroutines; _settleQueue = settleQueue; _prefabs = prefabs; _owned = owned;
        }

        public void SetProfile(PoolProfile p) => _profile = p;

        public EffectHandle Get()
        {
            EffectHandle h = null;
            if (_idle.Count > 0)
            {
                h = _idle.Pop();
                // 비활성 부모 아래에 남겨 둔 Handle이 그 부모로 재생되지 않게 한다.
                if (h.transform.parent != _root) h.transform.SetParent(_root, false);
            }
            else
            {
                var go = new GameObject(_key, typeof(RectTransform));
                go.transform.SetParent(_root, false);
                h = go.AddComponent<EffectHandle>();
                h.Initialize(_key, this);
                _owned.Add(h);
            }
            _active.Add(h);
            return h;
        }

        public void RequestSettle(EffectHandle handle) => _settleQueue.Add(handle);

        public void Reclaim(EffectHandle h)
        {
            // 소유자가 파괴된 뒤에는 돌아갈 루트가 없다.
            if (h == null || !_coroutines) return;
            _active.Remove(h);

            if (_idle.Contains(h)) return;
            ReturnToRoot(h);
            _idle.Push(h);

            // 분산 스윕: 핸들 별 개별 코루틴, Time.time 기준, 즉시 파괴 없음
            // inactive GameObjects cannot start coroutines.
            if (_coroutines.isActiveAndEnabled) _coroutines.StartCoroutine(CullWhenIdleTimeExceeded(h));
        }

        /// <summary>
        /// 비활성화가 진행 중인 계층에서는 SetParent가 실패한다. 어느 쪽이든 비활성이면 지연 처리로 넘긴다.
        /// </summary>
        void ReturnToRoot(EffectHandle handle)
        {
            var parent = handle.transform.parent;
            if (parent == _root) return;

            bool hierarchyMayBeChanging = (parent && !parent.gameObject.activeInHierarchy) || !_root.gameObject.activeInHierarchy;
            if (hierarchyMayBeChanging)
            {
                _settleQueue.Add(handle);
                return;
            }

            handle.transform.SetParent(_root, false);
        }

        /// <summary>
        /// LateUpdate에서 Handle 하나씩 처리하므로 진행 중인 비활성화가 없다.
        /// 지연 처리 중에 실행된 콜백이 다른 패널을 끄면 그 Despawn은 ReturnToRoot로 다음 LateUpdate까지 미룬다.
        /// </summary>
        public void ReturnSettledToRoot(EffectHandle handle)
        {
            if (handle.transform.parent != _root) handle.transform.SetParent(_root, false);
        }

        public void ResumeIdleCleanup()
        {
            foreach (var handle in _idle)
                if (handle) _coroutines.StartCoroutine(CullWhenIdleTimeExceeded(handle));
        }

        // scene unload/external Destroy retires pool ownership.
        public void Retire(EffectHandle h)
        {
            _active.Remove(h);
            _owned.Remove(h);
            if (_idle.Contains(h)) RemoveFromIdle(h);
            if (!_prefabs.IsShutDown && TotalCount == 0) _prefabs.Release(_key);
        }

        void RemoveFromIdle(EffectHandle h)
        {
            var remaining = new Stack<EffectHandle>(_idle.Count);
            while (_idle.Count > 0)
            {
                var candidate = _idle.Pop();
                if (!ReferenceEquals(candidate, h)) remaining.Push(candidate);
            }
            while (remaining.Count > 0) _idle.Push(remaining.Pop());
        }

        IEnumerator CullWhenIdleTimeExceeded(EffectHandle h)
        {
            // 분산을 위해 소폭 지터(0~0.5s) 추가
            float jitter = UnityEngine.Random.value * 0.5f;
            int idleVersion = h.RequestVersion;
            float start = Time.time;
            float deadline = start + Mathf.Max(0.1f, _profile.idleSeconds) + jitter;

            // idleSeconds 경과까지 대기 (게임 일시정지 시 정지됨)
            while (Time.time < deadline)
                yield return null;

            // 여전히 idle에 있고, 최소 유지 개수 이상일 때만 파괴
            bool stillIdle = h && _idle.Contains(h) && h.RequestVersion == idleVersion;
            if (stillIdle && _idle.Count > _profile.minRetain)
            {
                RemoveFromIdle(h);

                // 실제 파괴
                _owned.Remove(h); GameObject.Destroy(h.gameObject);

                // Addressables 해제 검토 (타입 전체가 비었을 때)
                if (TotalCount == 0)
                    _prefabs.Release(_key);
            }
        }
    }
}
