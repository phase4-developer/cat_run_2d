using Cysharp.Threading.Tasks;

namespace jjevol.Effect
{
    /// <summary>이펙트 재생 진입점. <see cref="EffectManager"/>가 구현한다.</summary>
    public interface IEffectPlayer
    {
        EffectHandle Play(EffectRequest request);
        UniTask<EffectHandle> PlayAsync(EffectRequest request);
        void Despawn(EffectHandle handle);
    }
}
