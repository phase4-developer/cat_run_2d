using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>프리팹 인스턴스를 만들어 Renderer와 내장 모듈을 Handle에 연결한다.</summary>
    internal sealed class EffectInstanceBinder
    {
        readonly IReadOnlyList<Func<GameObject, IEffectRenderer>> _rendererFactories;

        public EffectInstanceBinder(IReadOnlyList<Func<GameObject, IEffectRenderer>> rendererFactories)
        {
            _rendererFactories = rendererFactories;
        }

        public void Bind(EffectHandle handle, GameObject prefab, int version)
        {
            var inst = GameObject.Instantiate(prefab);
            inst.name = prefab.name;

            if (!handle.IsCurrent(version))
            {
                GameObject.Destroy(inst);
                return;
            }

            try
            {
                // 인스턴스가 활성인 동안 Renderer를 만들어 Awake가 끝난 뒤 상태를 저장한다.
                var renderer = CreateRenderer(inst);
                // 비활성 계층으로 옮긴 뒤에는 수집되지 않고, 재사용은 바인딩을 건너뛰므로 복구되지 않는다.
                var behaviours = inst.GetComponentsInChildren<IEffectBehaviour>();
                inst.transform.SetParent(handle.transform, false);
                handle.Bind(renderer);

                foreach (var b in behaviours)
                    handle.RegisterBuiltIn(b, version);
            }
            catch
            {
                handle.Unbind();
                GameObject.Destroy(inst);
                throw;
            }
        }

        IEffectRenderer CreateRenderer(GameObject go)
        {
            var effectRenderer = go.GetComponent<IEffectRenderer>();
            if (effectRenderer != null) return effectRenderer;

            if (go.GetComponent<Animator>())
                return go.AddComponent<Renderers.AnimatorEffectRenderer>();
            foreach (var factory in _rendererFactories)
            {
                var optional = factory(go);
                if (optional != null) return optional;
            }
            foreach (var component in go.GetComponents<Component>())
            {
                var componentNamespace = component ? component.GetType().Namespace : null;
                if (componentNamespace != null && (componentNamespace.StartsWith("DG.Tweening") || componentNamespace.StartsWith("Spine.Unity") || componentNamespace.StartsWith("Coffee.UIExtensions")))
                    throw new InvalidOperationException("Register the required optional Effect renderer adapter before playing this prefab.");
            }
            if (go.GetComponentInChildren<ParticleSystem>(true))
                return go.AddComponent<Renderers.ParticleEffectRenderer>();
            if (go.GetComponent<SpriteRenderer>())
                return go.AddComponent<Renderers.SpriteEffectRenderer>();

            Debug.LogWarning($"[{nameof(EffectManager)}] Effect prefab '{go.name}' has no recognizable renderer. Using the Sprite fallback, which completes immediately.");
            return go.AddComponent<Renderers.SpriteEffectRenderer>();
        }
    }
}
