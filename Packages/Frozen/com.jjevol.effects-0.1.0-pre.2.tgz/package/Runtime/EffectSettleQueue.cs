using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>비활성화 콜백과 분리해서 처리할 Handle. LateUpdate에서 비운다.</summary>
    internal sealed class EffectSettleQueue
    {
        List<EffectHandle> _pending = new();
        List<EffectHandle> _work = new();

        public void Add(EffectHandle handle) => _pending.Add(handle);

        public void Drain()
        {
            if (_pending.Count == 0) return;

            (_pending, _work) = (_work, _pending);
            foreach (var handle in _work)
            {
                if (!handle) continue;
                try { handle.Settle(); }
                catch (Exception exception)
                {
                    Debug.LogException(exception);
                    handle.Terminate(EffectEndReason.Failed);
                }
            }
            _work.Clear();
        }
    }
}
