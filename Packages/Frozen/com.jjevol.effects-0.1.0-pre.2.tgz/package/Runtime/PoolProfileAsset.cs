using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>
    /// 타입별 풀 정책을 에셋으로 보관하기 위한 ScriptableObject.
    /// - 인스펙터에서 기본 프로필과 타입별 프로필을 세팅합니다.
    /// - 런타임에는 Bootstrapper를 통해 EffectManager에 반영하세요.
    /// </summary>
    [CreateAssetMenu(fileName = "EffectPoolProfiles", menuName = "jjevol/Effect/Pool Profiles", order = 10)]
    public sealed class PoolProfileAsset : ScriptableObject
    {
        [Header("Default Profile (optional)")]
        public PoolProfile defaultProfile = new PoolProfile();

        [Header("Per-Type Profiles (effectType -> profile)")]
        public List<PoolProfileEntry> entries = new List<PoolProfileEntry>();
    }
}
