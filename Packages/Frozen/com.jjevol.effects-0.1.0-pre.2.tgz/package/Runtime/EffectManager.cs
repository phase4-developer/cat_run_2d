using System;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine;


namespace jjevol.Effect
{
    [System.Serializable]
    public class PoolProfile
    {
        [Min(0)] public int minRetain = 1;
        [Min(1)] public int maxPool = 32;
        [Min(0.1f)] public float idleSeconds = 15f;
    }

    [System.Serializable]
    public struct PoolProfileEntry
    {
        public string effectType;
        public PoolProfile profile;
    }

    /// <summary>
    /// 이펙트 모듈을 조립하는 MonoBehaviour. 직렬화 필드, Unity 수명 콜백, 공개 API만 둔다.
    /// 풀은 EffectPool, 재생 흐름은 EffectPlaybackPipeline, 바인딩은 EffectInstanceBinder, 지연 처리는 EffectSettleQueue가,
    /// 수명 상태는 EffectHandle이, 프리팹 상태는 EffectPrefabCache가 소유한다.
    /// </summary>
    public sealed class EffectManager : MonoBehaviour, IEffectPlayer
    {
        static EffectManager _instance;
        public static bool applicationIsQuitting;
        public static EffectManager Instance => !Application.isPlaying || applicationIsQuitting ? null : (_instance ? _instance : (_instance = new GameObject("EffectManager").AddComponent<EffectManager>()));
        public static bool HasInstance => !applicationIsQuitting && _instance;
        public static bool IsDestroyed => !HasInstance;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatic() { _instance = null; applicationIsQuitting = false; }
        void OnApplicationQuit() => applicationIsQuitting = true;

        [Header("Roots")]
        [SerializeField] Transform _poolRoot;

        [Header("Default Profile")]
        [SerializeField] PoolProfile _defaultProfile = new PoolProfile();

        [Header("Preset Profiles")]
        [SerializeField] PoolProfileEntry[] _profilesPreset = System.Array.Empty<PoolProfileEntry>();

        // 설정 API는 Awake 전에도 불릴 수 있다.
        readonly EffectPrefabCache _prefabs = new();
        readonly EffectSettleQueue _settleQueue = new();
        readonly HashSet<EffectHandle> _owned = new();
        // runtime profiles
        readonly Dictionary<string, PoolProfile> _profiles = new();
        // per-type pools
        readonly Dictionary<string, EffectPool> _pools = new();
        EffectPlaybackPipeline _pipeline;

        void Awake()
        {
            _pipeline = new EffectPlaybackPipeline(_prefabs, new EffectInstanceBinder(EffectRendererAdapters.Factories));

            if (_instance && _instance != this) { Destroy(gameObject); return; }
            _instance = this;
            transform.SetParent(null); DontDestroyOnLoad(gameObject);

            if (this != Instance) return;

            if (!_poolRoot)
            {
                var go = new GameObject("EffectManager");
                _poolRoot = go.transform; _poolRoot.SetParent(transform, false);
            }

            // presets
            foreach (var e in _profilesPreset)
            {
                if (!string.IsNullOrEmpty(e.effectType) && e.profile != null)
                    _profiles[e.effectType] = e.profile;
            }
        }

        // restart a full idle interval after enabling the manager.
        void OnEnable()
        {
            foreach (var pool in _pools.Values) pool.ResumeIdleCleanup();
        }

        void OnDisable()
        {
            // Unity stops these timers when the GameObject is disabled.
            StopAllCoroutines();
            foreach (var handle in new List<EffectHandle>(_owned))
                if (handle) handle.Terminate(EffectEndReason.Despawned);
        }

        void OnDestroy()
        {
            _prefabs.Shutdown();
            foreach (var handle in new List<EffectHandle>(_owned)) if (handle) Destroy(handle.gameObject);
            if (_instance == this) _instance = null;
        }

        void LateUpdate() => _settleQueue.Drain();

        public void SetPrefabProvider(IEffectPrefabProvider provider)
        {
            if (_pools.Count != 0 || _prefabs.HasLoadedOrPending) throw new InvalidOperationException("Configure the provider before loading effects.");
            _prefabs.SetProvider(provider ?? throw new ArgumentNullException(nameof(provider)));
        }

        /// <summary>런타임에 타입별 풀 정책 수정/등록</summary>
        public void SetPoolProfile(string effectType, int minRetain, int maxPool, float idleSeconds)
        {
            if (string.IsNullOrEmpty(effectType)) return;
            var p = new PoolProfile { minRetain = Mathf.Max(0, minRetain), maxPool = Mathf.Max(1, maxPool), idleSeconds = Mathf.Max(0.1f, idleSeconds) };
            _profiles[effectType] = p;

            if (_pools.TryGetValue(effectType, out var pool))
                pool.SetProfile(p);
        }

        public async UniTask PreloadAsync(string effectType)
        {
            await _prefabs.LoadAsync(effectType);
        }

        public EffectHandle Play(string effectName, Vector3 position, Transform parent = null)
        {
            return Play(new EffectRequest(effectType: effectName, localPos: position, parent: parent));
        }

        public EffectHandle PlayRouletteEffect(string effectName, int skinIndex, int animationIndex, Vector3 position, Transform parent = null)
        {
            return Play(new EffectRequest(effectType: effectName, skinIndex:skinIndex, animationIndex:animationIndex, localPos: position, parent: parent, sortingLayer: "RouletteEffect"));
        }

        /// <summary>
        /// 동기 Play: 즉시 핸들을 반환. 내부에서 비동기 로드/바인딩 후 준비되면 재생.
        /// 실패는 로그로 남기고 Handle은 종료 경로로 회수된다.
        /// </summary>
        public EffectHandle Play(EffectRequest request)
        {
            var handle = Acquire(request, out int version);
            if (handle != null) _pipeline.RunDetached(handle, version).Forget();
            return handle;
        }

        /// <summary>선택형 비동기 API. 실패는 Handle을 회수한 뒤 호출자에게 전달한다.</summary>
        public async UniTask<EffectHandle> PlayAsync(EffectRequest request)
        {
            var handle = Acquire(request, out int version);
            if (handle == null) return null;
            return await _pipeline.Run(handle, version) ? handle : null;
        }

        public void Despawn(EffectHandle handle)
        {
            if (handle == null) return;
            handle.Terminate(EffectEndReason.Despawned);
        }

        EffectHandle Acquire(in EffectRequest request, out int version)
        {
            version = 0;
            if (!request.IsValid) return null;
            // rejected calls must not consume an inactive pooled handle.
            if (!isActiveAndEnabled) return null;

            var handle = GetOrCreatePool(request.effectType).Get();
            version = handle.Configure(request);
            handle.gameObject.SetActive(true);
            return handle;
        }

        EffectPool GetOrCreatePool(string effectType)
        {
            if (_pools.TryGetValue(effectType, out var pool)) return pool;
            pool = new EffectPool(effectType, _poolRoot, GetProfile(effectType), this, _settleQueue, _prefabs, _owned);
            _pools.Add(effectType, pool);
            return pool;
        }

        PoolProfile GetProfile(string effectType)
        {
            if (string.IsNullOrEmpty(effectType)) return _defaultProfile;
            if (_profiles.TryGetValue(effectType, out var p)) return p;
            return _defaultProfile;
        }
    }
}
