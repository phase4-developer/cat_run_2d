using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>
    /// 프리팹 상태의 정본. 키당 레코드 하나가 로드 중, 성공, 실패(재시도 가능)를 표현한다.
    /// 같은 키의 동시 요청은 레코드의 Completion 하나를 공유한다.
    /// </summary>
    internal sealed class EffectPrefabCache
    {
        enum LoadState { Failed, Loading, Ready }

        sealed class Record
        {
            public LoadState State = LoadState.Failed;
            public EffectPrefabLease Lease;
            public UniTaskCompletionSource<GameObject> Completion;
        }

        readonly Dictionary<string, Record> _records = new();
        readonly CancellationTokenSource _lifetime = new();
        IEffectPrefabProvider _provider = new ResourcesEffectPrefabProvider();

        public bool IsShutDown => _lifetime.IsCancellationRequested;

        public bool HasLoadedOrPending
        {
            get
            {
                foreach (var record in _records.Values)
                    if (record.State != LoadState.Failed) return true;
                return false;
            }
        }

        public void SetProvider(IEffectPrefabProvider provider) => _provider = provider;

        /// <summary>프리팹을 돌려준다. 찾지 못하면 null이고 실패는 예외로 전달한다. 둘 다 다음 요청에서 재시도한다.</summary>
        public UniTask<GameObject> LoadAsync(string key)
        {
            if (string.IsNullOrEmpty(key) || IsShutDown) return UniTask.FromResult<GameObject>(null);

            if (!_records.TryGetValue(key, out var record))
            {
                record = new Record();
                _records.Add(key, record);
            }

            if (record.State == LoadState.Ready)
            {
                if (record.Lease.Prefab) return UniTask.FromResult(record.Lease.Prefab);

                record.Lease.Dispose();
                record.Lease = null;
                record.State = LoadState.Failed;
            }

            if (record.State == LoadState.Failed)
            {
                record.State = LoadState.Loading;
                record.Completion = new UniTaskCompletionSource<GameObject>();
                RunLoad(key, record).Forget();
            }

            return record.Completion.Task;
        }

        async UniTaskVoid RunLoad(string key, Record record)
        {
            var completion = record.Completion;
            try
            {
                var lease = await _provider.LoadAsync(key, _lifetime.Token);

                if (IsShutDown || lease == null || !lease.Prefab)
                {
                    lease?.Dispose();
                    record.State = LoadState.Failed;
                    if (!IsShutDown) Debug.LogWarning($"[{nameof(EffectManager)}] Effect prefab '{key}' was not found. The next request retries the load.");
                    completion.TrySetResult(null);
                    return;
                }

                record.Lease = lease;
                record.State = LoadState.Ready;
                completion.TrySetResult(lease.Prefab);
            }
            catch (OperationCanceledException exception)
            {
                record.State = LoadState.Failed;
                completion.TrySetCanceled(exception.CancellationToken);
            }
            catch (Exception exception)
            {
                record.State = LoadState.Failed;
                completion.TrySetException(exception);
            }
        }

        /// <summary>이 키의 인스턴스가 모두 사라졌을 때 호출한다. 진행 중인 로드는 건드리지 않는다.</summary>
        public void Release(string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (!_records.TryGetValue(key, out var record) || record.State == LoadState.Loading) return;

            _records.Remove(key);
            if (record.Lease != null) ReleaseAfterDestroy(record.Lease).Forget();
        }

        /// <summary>진행 중인 로드는 취소를 받고, 늦게 끝나면 lease를 곧바로 반환한다.</summary>
        public void Shutdown()
        {
            _lifetime.Cancel();
            foreach (var record in _records.Values)
                if (record.Lease != null) ReleaseAfterDestroy(record.Lease).Forget();
            _records.Clear();
            _lifetime.Dispose();
        }

        // 인스턴스의 Destroy가 끝난 뒤 lease를 반환한다.
        static async UniTaskVoid ReleaseAfterDestroy(EffectPrefabLease lease)
        {
            await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);
            lease.Dispose();
        }
    }
}
