using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>
    /// 시작 시 PoolProfileAsset 내용을 EffectManager에 반영하는 부트스트래퍼.
    /// - 씬에 배치하고 'Profiles' 필드에 SO를 할당하세요.
    /// - EffectManager.Instance가 존재해야 합니다(씬에 배치 또는 런타임 생성).
    /// </summary>
    public sealed class EffectProfileBootstrapper : MonoBehaviour
    {
        [Tooltip("프로필 설정을 담은 ScriptableObject")]
        public PoolProfileAsset Profiles;

        [Tooltip("효과 매니저를 명시적으로 지정(비워두면 Instance 사용)")]
        public EffectManager Manager;

        [Tooltip("Default Profile도 반영(현재 EffectManager의 기본값을 덮어쓰진 않고, 공통 타입에 일괄 적용하려면 true) ")]
        public bool ApplyDefaultAsCommon = false;

        void Awake()
        {
            var mgr = Manager ? Manager : EffectManager.Instance;
            if (!mgr || !Profiles) return;

            // 기본 프로필을 공통 타입에 덮어쓰고 싶다면, 여기서 대표 키들에 일괄 적용 가능
            if (ApplyDefaultAsCommon && Profiles.defaultProfile != null)
            {
                // 프로젝트에서 공통 프리팹 키 규칙이 있다면 여기에 적용하세요.
                // 예시: mgr.SetPoolProfile("VFX/_COMMON_", Profiles.defaultProfile.minRetain, Profiles.defaultProfile.maxPool, Profiles.defaultProfile.idleSeconds);
            }

            if (Profiles.entries != null)
            {
                foreach (var e in Profiles.entries)
                {
                    if (!string.IsNullOrEmpty(e.effectType) && e.profile != null)
                    {
                        mgr.SetPoolProfile(e.effectType, e.profile.minRetain, e.profile.maxPool, e.profile.idleSeconds);
                    }
                }
            }
        }
    }
}
