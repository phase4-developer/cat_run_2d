namespace jjevol.Effect
{
    /// <summary>
    /// 요청이 끝난 이유. Completed만 OnComplete를 발생시키고 Destroyed만 callBack을 부르지 않는다.
    /// Interrupted는 비루프 요청의 계층이 비활성화되거나, 부모나 Handle이 Object.Destroy로 파괴된 경우다.
    /// </summary>
    public enum EffectEndReason { Completed, Despawned, Failed, Interrupted, Destroyed }
}
