# Provenance

The user confirmed on 2026-10-31: “Effect 코드도 직접 개발했으며 공용 재사용 허용”.
This confirms the user-authored Effects scope, not Vendor asset redistribution or company contractual ownership.

Sources: {workspace}/jjevol_library_mobile/Assets/Common/Script/Effects. File/meta/GUID/hash records are in Docs/EffectExtraction/SourceInventory.json.

UniTask 2.5.10 declares MIT in the installed package metadata; consume the pinned SDK separately and retain its notices. No SDK cache, DOTween Pro/Spine/Coffee implementation, product prefab or art is redistributed. No public license is assigned to this local candidate.
