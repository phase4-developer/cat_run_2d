# 선택 기능의 현재 소유 위치

과거 추출 시점의 비활성 wrapper 설명은 현재 상태와 구별한다. 같은 클래스를 Core에 복제하지 않는다.

- DOTweenEffectRenderer: com.jjevol.effects.dotween-pro
- SpineEffectRenderer: com.jjevol.effects.spine (현재도 SDK 검증 BLOCKED)
- SyncUIParticleScale: com.jjevol.effects.coffee
- EffectIconBehaviour / ToastMessageEffectRenderer: com.jjevol.effects.ui

각 패키지의 실제 SDK 버전·소유권·검증·미검증 범위는 해당 README와 추출 보고서를 따른다. 선택 SDK를 Core에 강제하지 않는다. 이 목록은 모든 SDK/Player 검증 완료를 뜻하지 않는다.
