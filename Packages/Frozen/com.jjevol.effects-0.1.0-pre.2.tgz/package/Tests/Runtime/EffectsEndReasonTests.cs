using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Tests
{
    public sealed class DestroysHandleOnEndBehaviour : MonoBehaviour, IEffectBehaviour
    {
        EffectHandle _handle;
        public bool IsFinished => false;
        public void Begin(EffectHandle handle) => _handle = handle;
        public void Tick(float dt) { }
        public void End() { if (_handle) DestroyImmediate(_handle.gameObject); }
    }

    public sealed class DespawnsOnBeginBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public bool IsFinished => false;
        public void Begin(EffectHandle handle) => EffectManager.Instance.Despawn(handle);
        public void Tick(float dt) { }
        public void End() { }
    }

    // The end reasons of the README table, observed through callBack, OnComplete and onEnded.
    public sealed class EffectsEndReasonTests
    {
        sealed class Provider : IEffectPrefabProvider
        {
            public GameObject Prefab;
            // One scripted result per load. Runs inside LoadAsync, so it may throw synchronously.
            public readonly Queue<Func<EffectPrefabLease>> Script = new();
            public UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token)
                => UniTask.FromResult(Script.Count > 0 ? Script.Dequeue()() : new EffectPrefabLease(Prefab));
        }

        const string Call = "callBack", Complete = "OnComplete";
        static string Ended(EffectEndReason reason) => "onEnded:" + reason;

        EffectManager _manager;
        GameObject _prefab;
        Provider _provider;
        readonly List<GameObject> _objects = new();
        readonly List<string> _log = new();

        GameObject New(string name, params Type[] components)
        {
            var go = new GameObject(name, components); _objects.Add(go); return go;
        }
        EffectRequest Logged(bool loop = false, Transform parent = null)
            => new EffectRequest("fixture", loop: loop, parent: parent, callBack: () => _log.Add(Call), onEnded: reason => _log.Add(Ended(reason)));
        EffectHandle Play(bool loop = false, Transform parent = null)
        {
            var handle = _manager.Play(Logged(loop, parent));
            handle.OnComplete += _ => _log.Add(Complete);
            return handle;
        }
        void AssertLog(params string[] expected) => CollectionAssert.AreEqual(expected, _log);
        static RecordingEffectRenderer Rec(EffectHandle handle) => (RecordingEffectRenderer)handle.Renderer;
        static IEnumerator Frames(int count = 2) { for (int i = 0; i < count; i++) yield return null; }
        static IEnumerator Completed(Task task)
        {
            float end = Time.realtimeSinceStartup + 3f;
            while (!task.IsCompleted && Time.realtimeSinceStartup < end) yield return null;
            Assert.IsTrue(task.IsCompleted, "Task must finish");
        }

        [UnitySetUp] public IEnumerator Setup()
        {
            Time.timeScale = 1;
            _log.Clear();
            _prefab = New("end-reason-prefab");
            _prefab.AddComponent<RecordingEffectRenderer>();
            _manager = New("end-reason-manager").AddComponent<EffectManager>();
            _provider = new Provider { Prefab = _prefab };
            _manager.SetPrefabProvider(_provider);
            yield return null;
        }

        [UnityTest] public IEnumerator HandleDestroyedDuringItsOwnEndStillNotifiesOnce()
        {
            _prefab.AddComponent<DestroysHandleOnEndBehaviour>();
            var handle = Play(loop: true);
            yield return Frames();
            _manager.Despawn(handle);
            Assert.IsTrue(handle == null);
            AssertLog(Call, Ended(EffectEndReason.Despawned));
        }

        [UnityTearDown] public IEnumerator Cleanup()
        {
            foreach (var go in _objects) if (go) Object.Destroy(go);
            _objects.Clear();
            yield return null; yield return null;
        }

        // ---- Completed ----

        [UnityTest] public IEnumerator NaturalCompletionRunsAllThreeInOrderOnce()
        {
            var handle = Play();
            var completion = Rec(handle).Completion;
            completion();
            AssertLog(Call, Complete, Ended(EffectEndReason.Completed));

            completion(); _manager.Despawn(handle);
            Assert.AreEqual(3, _log.Count, "A finished request cannot end twice");
            yield return null;
        }

        // ---- Interrupted ----

        [UnityTest] public IEnumerator DeactivatedNonLoopIsInterruptedOutsideTheDisableCallback()
        {
            var parent = New("interrupted-parent", typeof(RectTransform));
            Play(parent: parent.transform);

            parent.SetActive(false);
            AssertLog();
            yield return Frames();
            AssertLog(Call, Ended(EffectEndReason.Interrupted));
        }

        [UnityTest] public IEnumerator PlayUnderAnInactiveParentIsInterrupted()
        {
            var parent = New("interrupted-inactive", typeof(RectTransform)); parent.SetActive(false);
            Play(parent: parent.transform);
            yield return Frames();
            AssertLog(Call, Ended(EffectEndReason.Interrupted));
        }

        [UnityTest] public IEnumerator DestroyedParentInterruptsTheHandle()
        {
            var parent = New("interrupted-destroyed", typeof(RectTransform));
            Play(parent: parent.transform);
            Object.Destroy(parent);
            yield return Frames();
            AssertLog(Call, Ended(EffectEndReason.Interrupted));
        }

        [UnityTest] public IEnumerator LoopUnderAnInactiveParentKeepsWaitingUntilDespawn()
        {
            var parent = New("loop-parent", typeof(RectTransform));
            var handle = Play(loop: true, parent: parent.transform);

            parent.SetActive(false); yield return Frames();
            AssertLog();
            Assert.IsTrue(handle.IsPlaying);

            parent.SetActive(true); yield return Frames();
            AssertLog();

            _manager.Despawn(handle);
            AssertLog(Call, Ended(EffectEndReason.Despawned));
        }

        // ---- Despawned ----

        [UnityTest] public IEnumerator DespawnSkipsOnCompleteAndIgnoresADuplicate()
        {
            var handle = Play(loop: true);
            _manager.Despawn(handle); _manager.Despawn(handle);
            AssertLog(Call, Ended(EffectEndReason.Despawned));
            yield return null;
        }

        [UnityTest] public IEnumerator StopThenDespawnEndsOnceAsDespawned()
        {
            var handle = Play(loop: true);
            handle.Stop();
            AssertLog();
            _manager.Despawn(handle);
            AssertLog(Call, Ended(EffectEndReason.Despawned));
            yield return null;
        }

        [UnityTest] public IEnumerator DisablingTheManagerDespawns()
        {
            Play(loop: true);
            _manager.enabled = false;
            AssertLog(Call, Ended(EffectEndReason.Despawned));
            yield return null;
        }

        [UnityTest] public IEnumerator DestroyingTheManagerDespawnsAndDoesNotReportDestroyed()
        {
            var handle = Play(loop: true);
            Object.Destroy(_manager.gameObject);
            yield return Frames();
            Assert.IsTrue(handle == null);
            AssertLog(Call, Ended(EffectEndReason.Despawned));
        }

        // ---- Failed ----

        [UnityTest] public IEnumerator MissingPrefabFails()
        {
            _provider.Script.Enqueue(() => null);
            Play(loop: true);
            AssertLog(Call, Ended(EffectEndReason.Failed));
            yield return null;
        }

        [UnityTest] public IEnumerator ProviderExceptionFails()
        {
            _provider.Script.Enqueue(() => throw new InvalidOperationException("expected fixture provider failure"));
            var task = _manager.PlayAsync(Logged(loop: true)).AsTask();
            yield return Completed(task);
            Assert.IsTrue(task.IsFaulted);
            AssertLog(Call, Ended(EffectEndReason.Failed));
        }

        [UnityTest] public IEnumerator BehaviourExceptionDuringPlaybackFails()
        {
            var handle = Play(loop: true);
            handle.AddBehaviour<ThrowOnTickBehaviour>();
            LogAssert.Expect(LogType.Exception, new Regex("expected fixture tick failure"));
            yield return Frames();
            AssertLog(Call, Ended(EffectEndReason.Failed));
        }

        // ---- Destroyed ----

        [UnityTest] public IEnumerator DestroyingTheHandleReportsOnlyOnEnded()
        {
            var handle = Play(loop: true);
            Object.Destroy(handle.gameObject);
            yield return Frames();
            AssertLog(Ended(EffectEndReason.Destroyed));
        }

        [UnityTest] public IEnumerator DestroyingAReturnedHandleReportsNothingMore()
        {
            var handle = Play(loop: true);
            _manager.Despawn(handle);
            Object.Destroy(handle.gameObject);
            yield return Frames();
            AssertLog(Call, Ended(EffectEndReason.Despawned));
        }

        // ---- delivery ----

        [UnityTest] public IEnumerator EachNotificationSurvivesTheOneBefore()
        {
            var ended = new List<EffectEndReason>();
            var handle = _manager.Play(new EffectRequest("fixture",
                callBack: () => throw new InvalidOperationException("expected fixture callback failure"), onEnded: ended.Add));
            handle.OnComplete += _ => throw new InvalidOperationException("expected fixture complete failure");

            LogAssert.Expect(LogType.Exception, new Regex("expected fixture callback failure"));
            LogAssert.Expect(LogType.Exception, new Regex("expected fixture complete failure"));
            Rec(handle).Completion();
            CollectionAssert.AreEqual(new[] { EffectEndReason.Completed }, ended);
            yield return null;
        }

        [UnityTest] public IEnumerator ThrowingOnEndedIsLoggedAndKeepsTheHandleReusable()
        {
            var handle = _manager.Play(new EffectRequest("fixture", onEnded: _ => throw new InvalidOperationException("expected fixture ended failure")));
            LogAssert.Expect(LogType.Exception, new Regex("expected fixture ended failure"));
            Rec(handle).Completion();
            Assert.AreSame(handle, _manager.Play(Logged(loop: true)));
            yield return null;
        }

        [UnityTest] public IEnumerator OnCompleteNeverReceivesAHandleAlreadyRunningANewRequest()
        {
            EffectHandle replay = null;
            var handle = _manager.Play(new EffectRequest("fixture", callBack: () => replay = _manager.Play(new EffectRequest("fixture", loop: true))));
            handle.OnComplete += finished => _manager.Despawn(finished);
            Rec(handle).Completion();
            Assert.IsTrue(replay.IsPlaying, "Cleaning up the finished request must leave the new request running");
            yield return null;
        }

        [UnityTest] public IEnumerator DespawnInsideBeginStopsTheRemainingBehaviours()
        {
            _prefab.AddComponent<DespawnsOnBeginBehaviour>();
            _prefab.AddComponent<LifecycleCountingBehaviour>();
            var handle = _manager.Play(Logged());
            Assert.AreEqual(0, handle.GetComponentInChildren<LifecycleCountingBehaviour>(true).Begins);
            Assert.IsFalse(handle.IsPlaying);
            AssertLog(Call, Ended(EffectEndReason.Despawned));
            yield return null;
        }

        [UnityTest] public IEnumerator HandleReturnsToThePoolAfterItsNotifications()
        {
            EffectHandle replay = null; bool active = true;
            EffectHandle handle = null;
            handle = _manager.Play(new EffectRequest("fixture", onEnded: _ =>
            {
                active = handle.gameObject.activeSelf;
                replay = _manager.Play(new EffectRequest("fixture", loop: true));
            }));

            Rec(handle).Completion();
            Assert.IsFalse(active, "The handle must be off before onEnded runs");
            Assert.AreNotSame(handle, replay, "A Play inside a notification cannot take the handle that is still notifying");
            Assert.IsTrue(replay.IsPlaying);
            Assert.AreSame(handle, _manager.Play(new EffectRequest("fixture", loop: true)), "The handle is reusable after its notifications");
            yield return null;
        }

        [UnityTest] public IEnumerator ReplayInsideCallBackKeepsEachRequestsOnEnded()
        {
            var first = new List<EffectEndReason>(); var second = new List<EffectEndReason>();
            EffectHandle replay = null;
            var handle = _manager.Play(new EffectRequest("fixture", onEnded: first.Add,
                callBack: () => replay = _manager.Play(new EffectRequest("fixture", loop: true, onEnded: second.Add))));

            Rec(handle).Completion();
            Assert.AreNotSame(handle, replay);
            CollectionAssert.AreEqual(new[] { EffectEndReason.Completed }, first);
            Assert.IsEmpty(second, "The replayed request is still running");

            _manager.Despawn(replay);
            CollectionAssert.AreEqual(new[] { EffectEndReason.Completed }, first);
            CollectionAssert.AreEqual(new[] { EffectEndReason.Despawned }, second);
            yield return null;
        }

        // ---- public shape ----

        [Test] public void PositionalRequestConstructorKeepsCompiling()
        {
            Action callBack = () => { };
            var request = new EffectRequest("fixture", 1, 2, true, "layer", 3, true, null, Vector3.one, Vector3.one, Quaternion.identity, "icon", callBack);
            Assert.AreSame(callBack, request.callBack);
            Assert.IsNull(request.onEnded);
            Assert.IsNull(EffectRequest.Default.onEnded);
        }

        [UnityTest] public IEnumerator EffectManagerPlaysThroughIEffectPlayer()
        {
            IEffectPlayer player = _manager;

            var handle = player.Play(Logged(loop: true));
            Assert.IsTrue(handle.IsPlaying);
            player.Despawn(handle);
            AssertLog(Call, Ended(EffectEndReason.Despawned));

            var task = player.PlayAsync(Logged(loop: true)).AsTask();
            yield return Completed(task);
            Assert.AreSame(handle, task.Result);
            Assert.IsTrue(task.Result.IsPlaying);
            player.Despawn(task.Result);
            Assert.IsFalse(handle.gameObject.activeSelf);

            Assert.IsNull(player.Play(default));
        }
    }
}
