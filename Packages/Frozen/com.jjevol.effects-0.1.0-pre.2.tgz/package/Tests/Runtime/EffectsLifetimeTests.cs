using System;
using System.Collections;
using System.Threading;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Tests
{
    public sealed class ControlledEffectRenderer : MonoBehaviour, IEffectRenderer
    {
        public Action Completion;
        public Transform Root => transform;
        public void Play(int animationIndex, bool loop, Action onComplete) => Completion = onComplete;
        public void StopAndClear() { }
        public void SetSorting(string layer, int order) { }
        public void SetPaused(bool paused) { }
        public void SetUnscaledTime(bool unscaled) { }
        public void SetSkin(int skinIndex) { }
    }
    public sealed class EffectsLifetimeTests
    {
        sealed class Provider : IEffectPrefabProvider
        {
            internal GameObject Prefab;
            internal int Loads, Releases;
            internal UniTaskCompletionSource<EffectPrefabLease> Gate;
            public async UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token)
            {
                Loads++;
                if (Gate != null) return await Gate.Task;
                return new EffectPrefabLease(Prefab, () => Releases++);
            }
        }
        EffectManager _manager;
        GameObject _prefab;
        Provider _provider;
        [UnitySetUp] public IEnumerator Setup()
        {
            _prefab = new GameObject("effect-test-prefab");
            _prefab.AddComponent<ControlledEffectRenderer>();
            _manager = new GameObject("effect-test-manager").AddComponent<EffectManager>();
            _provider = new Provider { Prefab = _prefab };
            _manager.SetPrefabProvider(_provider);
            yield return null;
        }
        [UnityTearDown] public IEnumerator Cleanup()
        {
            if (_manager) Object.Destroy(_manager.gameObject);
            yield return null;
            if (_prefab) Object.Destroy(_prefab);
            yield return null;
        }
        [UnityTest] public IEnumerator ReuseRejectsOldCompletionAndDuplicateDespawn()
        {
            var first = _manager.PlayAsync(new EffectRequest("test")).AsTask();
            while (!first.IsCompleted) yield return null;
            var handle = first.Result;
            var oldCompletion = ((ControlledEffectRenderer)handle.Renderer).Completion;
            _manager.Despawn(handle); _manager.Despawn(handle);
            var second = _manager.PlayAsync(new EffectRequest("test")).AsTask();
            while (!second.IsCompleted) yield return null;
            Assert.AreSame(handle, second.Result);
            oldCompletion();
            Assert.IsTrue(handle.IsPlaying);
            ((ControlledEffectRenderer)handle.Renderer).Completion();
            Assert.IsFalse(handle.gameObject.activeSelf);
            Assert.AreEqual(1, _provider.Loads);
        }
        [UnityTest] public IEnumerator LateLoadCannotReactivateReturnedHandle()
        {
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var handle = _manager.Play("late", Vector3.zero);
            _manager.Despawn(handle);
            _provider.Gate.TrySetResult(new EffectPrefabLease(_prefab, () => _provider.Releases++));
            yield return null; yield return null;
            Assert.IsFalse(handle.gameObject.activeSelf);
            Assert.IsNull(handle.Renderer);
        }
        [UnityTest] public IEnumerator ManagerDestroyReleasesPrefabAfterInstances()
        {
            var task = _manager.PlayAsync(new EffectRequest("test", loop:true)).AsTask();
            while (!task.IsCompleted) yield return null;
            Object.Destroy(_manager.gameObject);
            yield return null; yield return null;
            Assert.AreEqual(1, _provider.Releases);
        }
        [UnityTest] public IEnumerator LocalTransformAndCompletionCallbackAreRetained()
        {
            var parent = new GameObject("effect-parent", typeof(RectTransform));
            int completed = 0;
            var request = new EffectRequest("test", parent:parent.transform, localPos:new Vector3(1,2,3),localScale:Vector3.one*2,callBack:()=>completed++);
            var task = _manager.PlayAsync(request).AsTask();
            while (!task.IsCompleted) yield return null;
            Assert.AreEqual(new Vector3(1,2,3),task.Result.transform.localPosition);
            Assert.AreEqual(Vector3.one*2,task.Result.transform.localScale);
            _manager.Despawn(task.Result);
            Assert.AreEqual(1,completed);
            Object.Destroy(parent);
        }
        [UnityTest] public IEnumerator SpriteCompletesWithoutInventedDuration()
        {
            Object.DestroyImmediate(_prefab.GetComponent<ControlledEffectRenderer>());
            _prefab.AddComponent<SpriteRenderer>();
            var task = _manager.PlayAsync(new EffectRequest("sprite")).AsTask();
            while (!task.IsCompleted) yield return null;
            Assert.IsFalse(task.Result.gameObject.activeSelf);
        }
        [UnityTest] public IEnumerator RealParticleLoopStopsAndReturns()
        {
            Object.DestroyImmediate(_prefab.GetComponent<ControlledEffectRenderer>());
            var particles = _prefab.AddComponent<ParticleSystem>();
            var main = particles.main; main.playOnAwake = false;
            var task = _manager.PlayAsync(new EffectRequest("particles",loop:true)).AsTask();
            while (!task.IsCompleted) yield return null;
            Assert.IsInstanceOf<Renderers.ParticleEffectRenderer>(task.Result.Renderer);
            Assert.IsTrue(task.Result.IsPlaying);
            _manager.Despawn(task.Result);
            Assert.IsFalse(task.Result.gameObject.activeSelf);
        }
        [UnityTest] public IEnumerator ExternalParentInstanceIsOwnedUntilDestroy()
        {
            var parent=new GameObject("external-effect-parent",typeof(RectTransform));
            var task=_manager.PlayAsync(new EffectRequest("test",loop:true,parent:parent.transform)).AsTask();
            while(!task.IsCompleted)yield return null;
            var handle=task.Result;Object.Destroy(_manager.gameObject);
            yield return null;yield return null;
            Assert.IsTrue(handle==null);Assert.AreEqual(1,_provider.Releases);
            Object.Destroy(parent);
        }
        [UnityTest] public IEnumerator OldIdleTimerCannotCullANewerIdlePeriod()
        {
            _manager.SetPoolProfile("test",0,4,0.1f);
            var first=_manager.PlayAsync(new EffectRequest("test",loop:true)).AsTask();
            while(!first.IsCompleted)yield return null;
            _manager.Despawn(first.Result);
            yield return null;
            var second=_manager.PlayAsync(new EffectRequest("test",loop:true)).AsTask();
            while(!second.IsCompleted)yield return null;
            _manager.SetPoolProfile("test",0,4,2f);
            _manager.Despawn(second.Result);
            yield return new WaitForSecondsRealtime(0.75f);
            Assert.IsTrue(second.Result!=null);
        }
    }
}
