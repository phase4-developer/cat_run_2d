using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Tests
{
    public sealed class EffectModuleCoroutineFixture : MonoBehaviour { }

    // Each module built from its constructor, with no EffectManager in the scene.
    public sealed class EffectsModuleTests
    {
        sealed class FakeHost : IEffectHandleHost
        {
            public readonly List<string> Log;
            public FakeHost(List<string> log) => Log = log;
            public void RequestSettle(EffectHandle handle) => Log.Add(nameof(RequestSettle));
            public void Reclaim(EffectHandle handle) => Log.Add(nameof(Reclaim));
            public void ReturnSettledToRoot(EffectHandle handle) => Log.Add(nameof(ReturnSettledToRoot));
            public void Retire(EffectHandle handle) => Log.Add(nameof(Retire));
        }

        sealed class Provider : IEffectPrefabProvider
        {
            public GameObject Prefab;
            public int Releases;
            public UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token)
                => UniTask.FromResult(Prefab ? new EffectPrefabLease(Prefab, () => Releases++) : null);
        }

        readonly List<GameObject> _objects = new();
        readonly List<string> _log = new();
        readonly List<EffectPrefabCache> _caches = new();
        FakeHost _host;

        GameObject New(string name, params Type[] components)
        {
            var go = new GameObject(name, components); _objects.Add(go); return go;
        }
        EffectHandle Handle()
        {
            var handle = New("module-handle", typeof(RectTransform)).AddComponent<EffectHandle>();
            handle.Initialize("fixture", _host);
            return handle;
        }
        EffectRequest Logged(bool loop = false, Transform parent = null)
            => new EffectRequest("fixture", loop: loop, parent: parent, callBack: () => _log.Add("callBack"), onEnded: reason => _log.Add("onEnded:" + reason));
        EffectPrefabCache Cache(IEffectPrefabProvider provider)
        {
            var cache = new EffectPrefabCache();
            cache.SetProvider(provider);
            _caches.Add(cache);
            return cache;
        }
        static EffectInstanceBinder Binder(params Func<GameObject, IEffectRenderer>[] factories) => new EffectInstanceBinder(factories);
        static IEnumerator Until(Func<bool> predicate, string message, float seconds = 3f)
        {
            float end = Time.realtimeSinceStartup + seconds;
            while (!predicate() && Time.realtimeSinceStartup < end) yield return null;
            Assert.IsTrue(predicate(), message);
        }
        static IEnumerator Completed(Task task)
        {
            yield return Until(() => task.IsCompleted, "Task must finish");
        }

        [SetUp] public void Setup()
        {
            Time.timeScale = 1;
            _log.Clear();
            _host = new FakeHost(_log);
        }

        [UnityTearDown] public IEnumerator Cleanup()
        {
            foreach (var cache in _caches) cache.Shutdown();
            _caches.Clear();
            foreach (var go in _objects) if (go) Object.Destroy(go);
            _objects.Clear();
            yield return null; yield return null;
        }

        // ---- EffectHandle and IEffectHandleHost ----

        [UnityTest] public IEnumerator HandleReturnsToItsHostAfterNotifying()
        {
            var handle = Handle();
            handle.Configure(Logged());
            handle.Terminate(EffectEndReason.Despawned);
            CollectionAssert.AreEqual(new[] { "callBack", "onEnded:Despawned", "Reclaim" }, _log);
            yield return null;
        }

        [UnityTest] public IEnumerator HandleTellsItsHostWhenDestroyed()
        {
            var handle = Handle();
            handle.Configure(Logged());
            Object.Destroy(handle.gameObject);
            yield return null; yield return null;
            // Unity runs OnDisable before OnDestroy on an active object.
            CollectionAssert.AreEqual(new[] { "RequestSettle", "Retire", "onEnded:Destroyed" }, _log);
        }

        [UnityTest] public IEnumerator HandleIsInitializedOnce()
        {
            var handle = Handle();
            Assert.AreEqual("fixture", handle.EffectType);
            Assert.Throws<InvalidOperationException>(() => handle.Initialize("other", _host));
            Assert.AreEqual("fixture", handle.EffectType);
            yield return null;
        }

        // ---- EffectSettleQueue ----

        [UnityTest] public IEnumerator SettleQueueInterruptsADeactivatedNonLoop()
        {
            var handle = Handle();
            handle.Configure(Logged());
            handle.gameObject.SetActive(false);
            CollectionAssert.AreEqual(new[] { "RequestSettle" }, _log);

            var queue = new EffectSettleQueue();
            queue.Add(handle);
            queue.Drain();
            CollectionAssert.AreEqual(new[] { "RequestSettle", "callBack", "onEnded:Interrupted", "Reclaim" }, _log);

            queue.Drain();
            Assert.AreEqual(4, _log.Count, "Drain empties the queue");
            yield return null;
        }

        [UnityTest] public IEnumerator SettleQueueFailsAHandleWhoseRestartThrows()
        {
            var handle = Handle();
            handle.Configure(Logged(loop: true));
            var renderer = New("module-renderer").AddComponent<RecordingEffectRenderer>();
            handle.Bind(renderer);
            handle.StartPlayback();
            handle.gameObject.SetActive(false); handle.gameObject.SetActive(true);
            renderer.ThrowOnPlay = true;

            var queue = new EffectSettleQueue();
            queue.Add(handle);
            LogAssert.Expect(LogType.Exception, new Regex("expected fixture play failure"));
            queue.Drain();
            Assert.Contains("onEnded:Failed", _log);
            yield return null;
        }

        [UnityTest] public IEnumerator SettleQueueSkipsADestroyedHandle()
        {
            var handle = Handle();
            var queue = new EffectSettleQueue();
            queue.Add(handle);
            Object.Destroy(handle.gameObject);
            yield return null;
            Assert.DoesNotThrow(queue.Drain);
        }

        // ---- EffectInstanceBinder ----

        [UnityTest] public IEnumerator BinderParentsTheInstanceAndRegistersItsBehaviours()
        {
            var prefab = New("module-prefab");
            prefab.AddComponent<LifecycleCountingBehaviour>();
            var handle = Handle();
            int version = handle.Configure(Logged());

            Binder(go => go.AddComponent<RecordingEffectRenderer>()).Bind(handle, prefab, version);

            Assert.IsInstanceOf<RecordingEffectRenderer>(handle.Renderer);
            Assert.AreEqual(1, handle.transform.childCount);
            Assert.AreEqual(1, handle.GetComponentInChildren<LifecycleCountingBehaviour>().Begins);
            yield return null;
        }

        [UnityTest] public IEnumerator BinderDropsTheInstanceOfAnEndedRequest()
        {
            var prefab = New("module-stale-prefab");
            prefab.AddComponent<RecordingEffectRenderer>();
            var handle = Handle();
            int version = handle.Configure(Logged());
            handle.Terminate(EffectEndReason.Despawned);

            Binder().Bind(handle, prefab, version);

            Assert.IsNull(handle.Renderer);
            Assert.AreEqual(0, handle.transform.childCount);
            yield return null;
        }

        // ---- EffectPlaybackPipeline ----

        [UnityTest] public IEnumerator PipelineLoadsBindsAndStarts()
        {
            var prefab = New("module-pipeline-prefab");
            prefab.AddComponent<RecordingEffectRenderer>();
            var handle = Handle();
            int version = handle.Configure(Logged(loop: true));

            var run = new EffectPlaybackPipeline(Cache(new Provider { Prefab = prefab }), Binder()).Run(handle, version).AsTask();
            yield return Completed(run);

            Assert.IsTrue(run.Result);
            Assert.IsTrue(handle.IsPlaying);
            Assert.AreEqual(1, ((RecordingEffectRenderer)handle.Renderer).Plays);
        }

        [UnityTest] public IEnumerator PipelineFailsARequestWithoutAPrefab()
        {
            var handle = Handle();
            int version = handle.Configure(Logged(loop: true));

            var run = new EffectPlaybackPipeline(Cache(new Provider()), Binder()).Run(handle, version).AsTask();
            yield return Completed(run);

            Assert.IsFalse(run.Result);
            CollectionAssert.AreEqual(new[] { "callBack", "onEnded:Failed", "Reclaim" }, _log);
        }

        // ---- EffectPool ----

        EffectPool Pool(Transform root, EffectSettleQueue queue, EffectPrefabCache prefabs, HashSet<EffectHandle> owned, float idleSeconds = 30f)
        {
            var coroutines = New("module-coroutines").AddComponent<EffectModuleCoroutineFixture>();
            return new EffectPool("fixture", root, new PoolProfile { minRetain = 0, maxPool = 4, idleSeconds = idleSeconds }, coroutines, queue, prefabs, owned);
        }

        [UnityTest] public IEnumerator PoolHostsItsHandlesAndReusesThem()
        {
            var root = New("module-root").transform;
            var owned = new HashSet<EffectHandle>();
            var pool = Pool(root, new EffectSettleQueue(), Cache(new Provider()), owned);

            var handle = pool.Get();
            Assert.AreSame(root, handle.transform.parent);
            Assert.AreEqual("fixture", handle.EffectType);
            Assert.IsTrue(owned.Contains(handle));
            handle.Configure(Logged());

            handle.Terminate(EffectEndReason.Despawned);
            Assert.AreEqual(1, pool.TotalCount);
            Assert.AreSame(handle, pool.Get());
            Assert.AreEqual(1, pool.TotalCount);
            yield return null;
        }

        [UnityTest] public IEnumerator PoolDefersTheReturnFromAnInactiveParent()
        {
            var root = New("module-deferred-root").transform;
            var parent = New("module-inactive", typeof(RectTransform)); parent.SetActive(false);
            var queue = new EffectSettleQueue();
            var pool = Pool(root, queue, Cache(new Provider()), new HashSet<EffectHandle>());

            var handle = pool.Get();
            handle.Configure(Logged(parent: parent.transform));
            handle.Terminate(EffectEndReason.Despawned);
            Assert.AreSame(parent.transform, handle.transform.parent, "Reparenting waits for the queue");

            queue.Drain();
            Assert.AreSame(root, handle.transform.parent);
            yield return null;
        }

        [UnityTest] public IEnumerator PoolCullReleasesTheLastPrefabLease()
        {
            var root = New("module-cull-root").transform;
            var owned = new HashSet<EffectHandle>();
            var provider = new Provider { Prefab = New("module-cull-prefab") };
            var prefabs = Cache(provider);
            var pool = Pool(root, new EffectSettleQueue(), prefabs, owned, idleSeconds: 0.1f);

            var load = prefabs.LoadAsync("fixture").AsTask();
            yield return Completed(load);
            var handle = pool.Get();
            handle.Configure(Logged());
            handle.Terminate(EffectEndReason.Despawned);

            yield return Until(() => handle == null, "An idle handle past its profile must be culled");
            Assert.AreEqual(0, pool.TotalCount);
            Assert.IsEmpty(owned);
            yield return Until(() => provider.Releases == 1, "The last instance releases the lease");
        }

        [UnityTest] public IEnumerator PoolRetiresAHandleDestroyedWhileActive()
        {
            var root = New("module-retire-root").transform;
            var owned = new HashSet<EffectHandle>();
            var pool = Pool(root, new EffectSettleQueue(), Cache(new Provider()), owned);

            var handle = pool.Get();
            handle.Configure(Logged());
            Object.Destroy(handle.gameObject);
            yield return null; yield return null;

            Assert.AreEqual(0, pool.TotalCount);
            Assert.IsEmpty(owned);
            CollectionAssert.AreEqual(new[] { "onEnded:Destroyed" }, _log);
        }
    }
}
