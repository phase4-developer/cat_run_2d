using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.TestTools;
using jjevol.Effect.Renderers;
using Object = UnityEngine.Object;

namespace Spine.Unity.Fixture
{
    // A Vendor-namespaced root component without an adapter. No Vendor code is involved.
    public sealed class VendorRootMarker : MonoBehaviour { }
}

namespace jjevol.Effect.Tests
{
    public sealed class RecordingEffectRenderer : MonoBehaviour, IEffectRenderer, IEffectRendererStateRestore
    {
        public bool ThrowOnPlay;
        public int Plays, Stops, Captures, Restores;
        public bool Paused, Unscaled;
        public string Layer = "prefab";
        public int Order = -1;
        public Action Completion;
        public Transform Root => transform;
        public void Play(int animationIndex, bool loop, Action onComplete)
        {
            if (ThrowOnPlay) throw new InvalidOperationException("expected fixture play failure");
            Plays++; Completion = onComplete;
        }
        public void StopAndClear() => Stops++;
        public void SetSorting(string layer, int order) { Layer = layer; Order = order; }
        public void SetPaused(bool paused) => Paused = paused;
        public void SetUnscaledTime(bool unscaled) => Unscaled = unscaled;
        public void SetSkin(int skinIndex) { }
        void IEffectRendererStateRestore.CaptureState() => Captures++;
        void IEffectRendererStateRestore.RestoreState() { Restores++; Layer = "prefab"; Order = -1; }
    }

    // A third-party renderer that knows nothing about IEffectRendererStateRestore.
    public sealed class PauseOnlyEffectRenderer : MonoBehaviour, IEffectRenderer
    {
        public bool Paused;
        public Transform Root => transform;
        public void Play(int animationIndex, bool loop, Action onComplete) { }
        public void StopAndClear() { }
        public void SetSorting(string layer, int order) { }
        public void SetPaused(bool paused) => Paused = paused;
        public void SetUnscaledTime(bool unscaled) { }
        public void SetSkin(int skinIndex) { }
    }

    public sealed class ThrowOnBeginBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public bool Armed = true;
        public bool IsFinished => false;
        public void Begin(EffectHandle handle) { if (Armed) throw new InvalidOperationException("expected fixture begin failure"); }
        public void Tick(float dt) { }
        public void End() { }
    }

    public sealed class DespawnOnEndBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public EffectManager Manager;
        public EffectHandle Owner;
        public bool IsFinished => false;
        public void Begin(EffectHandle handle) => Owner = handle;
        public void Tick(float dt) { }
        public void End() { if (Manager) Manager.Despawn(Owner); }
    }

    public sealed class CountingTickBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public int Ticks;
        public bool IsFinished => false;
        public void Begin(EffectHandle handle) => Ticks = 0;
        public void Tick(float dt) => Ticks++;
        public void End() { }
    }

    public sealed class LifecycleCountingBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public int Begins, Ticks, Ends;
        public bool IsFinished => false;
        public void Begin(EffectHandle handle) { Begins++; Ticks = 0; }
        public void Tick(float dt) => Ticks++;
        public void End() => Ends++;
    }

    public sealed class ThrowOnTickBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public Action BeforeThrow;
        public bool IsFinished => false;
        public void Begin(EffectHandle handle) { }
        public void Tick(float dt)
        {
            BeforeThrow?.Invoke();
            throw new InvalidOperationException("expected fixture tick failure");
        }
        public void End() { }
    }

    // Ends the new request from inside the SetActive(true) that reuses a pooled handle.
    public sealed class StopHandleOnEnable : MonoBehaviour
    {
        public bool Armed;
        void OnEnable() { if (Armed) GetComponentInParent<EffectHandle>(true).Stop(); }
    }

    public sealed class DespawnOnDisable : MonoBehaviour
    {
        public EffectManager Manager;
        public EffectHandle Handle;
        void OnDisable() { if (Handle) Manager.Despawn(Handle); }
    }

    // State machine contract: every end of an effect passes one path and callBack runs exactly once.
    public sealed class EffectsLifecycleTests
    {
        sealed class Provider : IEffectPrefabProvider
        {
            public GameObject Prefab;
            public int Loads, Releases;
            public UniTaskCompletionSource<EffectPrefabLease> Gate;
            // One scripted result per load. Runs inside LoadAsync, so it may throw synchronously.
            public readonly Queue<Func<EffectPrefabLease>> Script = new();
            public UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token)
            {
                Loads++;
                if (Script.Count > 0) return UniTask.FromResult(Script.Dequeue()());
                return Gate != null ? Gate.Task : UniTask.FromResult(Lease());
            }
            public EffectPrefabLease Lease() => new EffectPrefabLease(Prefab, () => Releases++);
        }

        EffectManager _manager;
        GameObject _prefab;
        Provider _provider;
        readonly List<GameObject> _objects = new();

        GameObject New(string name, params Type[] components)
        {
            var go = new GameObject(name, components); _objects.Add(go); return go;
        }
        EffectHandle Play(bool loop = false, Transform parent = null, Action callBack = null, string sortingLayer = "", int sortingOrder = 0, Action<EffectEndReason> onEnded = null)
            => _manager.Play(new EffectRequest("fixture", loop: loop, parent: parent, callBack: callBack, sortingLayer: sortingLayer, sortingOrder: sortingOrder, onEnded: onEnded));
        Task<EffectHandle> PlayAsync(bool loop = false, Transform parent = null, Action callBack = null)
            => _manager.PlayAsync(new EffectRequest("fixture", loop: loop, parent: parent, callBack: callBack)).AsTask();
        static RecordingEffectRenderer Rec(EffectHandle handle) => (RecordingEffectRenderer)handle.Renderer;
        static IEnumerator Frames(int count = 2) { for (int i = 0; i < count; i++) yield return null; }
        static IEnumerator Until(Func<bool> predicate, string message, float seconds = 3f)
        {
            float end = Time.realtimeSinceStartup + seconds;
            while (!predicate() && Time.realtimeSinceStartup < end) yield return null;
            Assert.IsTrue(predicate(), message);
        }
        static IEnumerator Completed(Task task)
        {
            yield return Until(() => task.IsCompleted, "Task must finish");
        }
        ParticleSystem ChildParticles(string name, float lifetime = 0.1f)
        {
            var go = new GameObject(name); go.transform.SetParent(_prefab.transform, false);
            var particles = go.AddComponent<ParticleSystem>();
            particles.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var main = particles.main; main.playOnAwake = false; main.duration = 0.15f; main.startLifetime = lifetime;
            return particles;
        }

        [UnitySetUp] public IEnumerator Setup()
        {
            Time.timeScale = 1;
            _prefab = New("lifecycle-prefab");
            _manager = New("lifecycle-manager").AddComponent<EffectManager>();
            _provider = new Provider { Prefab = _prefab };
            _manager.SetPrefabProvider(_provider);
            yield return null;
        }

        [UnityTearDown] public IEnumerator Cleanup()
        {
            foreach (var go in _objects) if (go) Object.Destroy(go);
            _objects.Clear();
            yield return null; yield return null;
        }

        // ---- F1: inactive parents ----

        [UnityTest] public IEnumerator NonLoopInDeactivatedParentEndsOnceAndReturnsToPool()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-parent", typeof(RectTransform)); int calls = 0, completed = 0;
            var handle = Play(parent: parent.transform, callBack: () => calls++);
            handle.OnComplete += _ => completed++;
            var renderer = Rec(handle); var stale = renderer.Completion;

            parent.SetActive(false);
            Assert.AreEqual(0, calls, "Disable callback must only mark the handle");
            Assert.AreSame(parent.transform, handle.transform.parent, "Reparenting is deferred out of OnDisable");

            yield return Frames();
            Assert.AreEqual(1, calls); Assert.AreEqual(0, completed, "An interrupted effect did not complete");
            Assert.IsFalse(handle.IsPlaying); Assert.IsFalse(handle.gameObject.activeSelf);
            Assert.AreNotSame(parent.transform, handle.transform.parent);

            stale(); Assert.AreEqual(1, calls, "A stale renderer completion cannot end the request twice");
            Assert.AreSame(handle, Play(), "The recovered handle must return to the pool");
            _manager.Despawn(handle);
        }

        [UnityTest] public IEnumerator LoopSurvivesParentDeactivationAndRestartsOnActivation()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-loop-parent", typeof(RectTransform)); int calls = 0;
            var handle = Play(loop: true, parent: parent.transform, callBack: () => calls++);
            var renderer = Rec(handle);

            parent.SetActive(false); yield return Frames();
            Assert.IsTrue(handle.IsPlaying, "The owner keeps a loop until Despawn");
            Assert.AreEqual(0, calls); Assert.AreEqual(1, renderer.Plays);
            Assert.AreSame(parent.transform, handle.transform.parent);

            parent.SetActive(true); yield return Frames();
            Assert.AreEqual(2, renderer.Plays, "Reactivation restarts the stopped renderer");
            Assert.AreEqual(1, renderer.Stops);
            Assert.IsTrue(handle.IsPlaying);

            _manager.Despawn(handle);
            Assert.AreEqual(1, calls);
        }

        [UnityTest] public IEnumerator PausedLoopStaysPausedAfterReactivation()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-pause-parent", typeof(RectTransform));
            var handle = Play(loop: true, parent: parent.transform);
            var tick = handle.AddBehaviour<CountingTickBehaviour>();
            handle.Pause();

            parent.SetActive(false); yield return Frames();
            parent.SetActive(true); yield return Frames();

            Assert.IsTrue(Rec(handle).Paused, "Restart must reapply the pause");
            Assert.AreEqual(0, tick.Ticks, "Paused behaviours stay suspended");
            handle.Resume(); yield return Frames();
            Assert.Greater(tick.Ticks, 0);
            _manager.Despawn(handle);
        }

        [UnityTest] public IEnumerator SameFrameToggleStillEndsNonLoop()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-toggle-parent", typeof(RectTransform)); int calls = 0;
            var handle = Play(parent: parent.transform, callBack: () => calls++);
            parent.SetActive(false); parent.SetActive(true);
            yield return Frames();
            Assert.AreEqual(1, calls, "Renderer waiters die with the deactivation, so no later completion can arrive");
            Assert.IsFalse(handle.gameObject.activeSelf);
        }

        [UnityTest] public IEnumerator PlayUnderInactiveParentEndsNonLoopWithoutStartingRenderer()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-inactive", typeof(RectTransform)); parent.SetActive(false); int calls = 0;

            var handle = Play(parent: parent.transform, callBack: () => calls++);
            Assert.AreEqual(0, Rec(handle).Plays, "Coroutines cannot start on an inactive hierarchy");
            yield return Frames();
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.gameObject.activeSelf);

            var task = PlayAsync(parent: parent.transform, callBack: () => calls++);
            yield return Completed(task);
            Assert.AreSame(handle, task.Result);
            yield return Frames();
            Assert.AreEqual(2, calls); Assert.AreEqual(0, Rec(handle).Plays);
        }

        [UnityTest] public IEnumerator PlayUnderInactiveParentStartsLoopOnActivation()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-inactive-loop", typeof(RectTransform)); parent.SetActive(false); int calls = 0;

            var handle = Play(loop: true, parent: parent.transform, callBack: () => calls++);
            yield return Frames();
            Assert.IsTrue(handle.IsPlaying); Assert.AreEqual(0, Rec(handle).Plays); Assert.AreEqual(0, calls);

            parent.SetActive(true); yield return Frames();
            Assert.AreEqual(1, Rec(handle).Plays);
            _manager.Despawn(handle); Assert.AreEqual(1, calls);
        }

        [UnityTest] public IEnumerator DeactivationDuringLoadEndsNonLoopAndIgnoresLateLoad()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var parent = New("f1-load-parent", typeof(RectTransform)); int calls = 0;
            var handle = Play(parent: parent.transform, callBack: () => calls++);

            parent.SetActive(false); yield return Frames();
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.gameObject.activeSelf);

            _provider.Gate.TrySetResult(_provider.Lease()); yield return Frames();
            Assert.IsNull(handle.Renderer, "A retired request must not bind");
            Assert.AreEqual(1, calls);
        }

        [UnityTest] public IEnumerator DeactivationDuringLoadKeepsLoopAndPlaysOnActivation()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var parent = New("f1-load-loop", typeof(RectTransform));
            var handle = Play(loop: true, parent: parent.transform);

            parent.SetActive(false); yield return Frames();
            _provider.Gate.TrySetResult(_provider.Lease()); yield return Frames();
            Assert.IsTrue(handle.IsPlaying); Assert.AreEqual(0, Rec(handle).Plays);

            parent.SetActive(true); yield return Frames();
            Assert.AreEqual(1, Rec(handle).Plays);
            _manager.Despawn(handle);
        }

        [UnityTest] public IEnumerator OwnerDespawnInsideParentOnDisableIsSafe()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-owner", typeof(RectTransform)); int calls = 0;
            var handle = Play(loop: true, parent: parent.transform, callBack: () => calls++);
            var owner = parent.AddComponent<DespawnOnDisable>(); owner.Manager = _manager; owner.Handle = handle;

            parent.SetActive(false);
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.IsPlaying);
            yield return Frames();
            Assert.AreEqual(1, calls);
            Assert.AreNotSame(parent.transform, handle.transform.parent, "Pool parenting finishes after the disable callback");
            // Any Unity SetParent error during the disable fails this test through LogAssert.
        }

        [UnityTest] public IEnumerator DespawnedLoopUnderInactiveParentLeavesItOnLateUpdate()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("f1-despawn-inactive", typeof(RectTransform)); int calls = 0;
            var handle = Play(loop: true, parent: parent.transform, callBack: () => calls++);
            parent.SetActive(false); yield return Frames();

            _manager.Despawn(handle);
            Assert.AreEqual(1, calls);
            yield return Frames();
            Assert.AreNotSame(parent.transform, handle.transform.parent);

            parent.SetActive(true); yield return Frames();
            Assert.AreEqual(1, Rec(handle).Plays, "Reactivation must not restart a returned handle");
        }

        [UnityTest] public IEnumerator PanelDisabledByASettleCallbackStillDefersItsDespawn()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var panel = New("f1-other-panel", typeof(RectTransform)); int calls = 0;
            var other = Play(loop: true, parent: panel.transform, callBack: () => calls++);
            var owner = panel.AddComponent<DespawnOnDisable>(); owner.Manager = _manager; owner.Handle = other;

            var parent = New("f1-settling-parent", typeof(RectTransform)); Transform parentInCallback = null;
            Play(parent: parent.transform, callBack: () =>
            {
                panel.SetActive(false);
                parentInCallback = other.transform.parent;
            });

            parent.SetActive(false); yield return Frames();
            Assert.AreEqual(1, calls);
            Assert.AreSame(panel.transform, parentInCallback, "A disable running inside Settle must not reparent at once");
            Assert.AreNotSame(panel.transform, other.transform.parent, "The deferred return still finishes");
            // Any Unity SetParent error during the disable fails this test through LogAssert.
        }

        [UnityTest] public IEnumerator RealParticleWaiterKilledByDeactivationStillEnds()
        {
            ChildParticles("f1-particles", 5f);
            var parent = New("f1-particle-parent", typeof(RectTransform)); int calls = 0;
            var handle = Play(parent: parent.transform, callBack: () => calls++);
            Assert.IsInstanceOf<ParticleEffectRenderer>(handle.Renderer);
            parent.SetActive(false); yield return Frames();
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.gameObject.activeSelf);
        }

        [UnityTest] public IEnumerator DestroyingTheParentFinishesTheHandleOnceAndKeepsItPooled()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var parent = New("destroyed-parent", typeof(RectTransform)); int calls = 0;
            var ended = new List<EffectEndReason>();
            var handle = Play(parent: parent.transform, callBack: () => calls++, onEnded: ended.Add);
            Object.Destroy(parent); yield return Frames();
            Assert.IsTrue(parent == null, "The parent must be gone before the handle is judged");
            Assert.IsTrue(handle != null, "The handle leaves the dying parent through the deactivation path");
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.gameObject.activeSelf);
            Assert.IsTrue(handle.transform.parent != null, "The handle must be back under the pool root");
            CollectionAssert.AreEqual(new[] { EffectEndReason.Interrupted }, ended);
        }

        [UnityTest] public IEnumerator DestroyingANonLoopHandleEndsItOnceAsInterrupted()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            var ended = new List<EffectEndReason>();
            var handle = Play(callBack: () => calls++, onEnded: ended.Add);
            Object.Destroy(handle.gameObject); yield return Frames();
            Assert.IsTrue(handle == null); Assert.AreEqual(1, calls);
            CollectionAssert.AreEqual(new[] { EffectEndReason.Interrupted }, ended);
        }

        [UnityTest] public IEnumerator DestroyingALoopHandleSkipsTheCallback()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            var ended = new List<EffectEndReason>();
            var handle = Play(loop: true, callBack: () => calls++, onEnded: ended.Add);
            Object.Destroy(handle.gameObject); yield return Frames();
            Assert.IsTrue(handle == null); Assert.AreEqual(0, calls, "Handle destruction keeps its original no-callback behaviour");
            CollectionAssert.AreEqual(new[] { EffectEndReason.Destroyed }, ended);
        }

        [UnityTest] public IEnumerator DestroyingTheManagerCallsBackOnceThroughDisable()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            int active = 0, pending = 0;
            var handle = Play(loop: true, callBack: () => active++);
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var waiting = _manager.Play(new EffectRequest("pending", loop: true, callBack: () => pending++));

            Object.Destroy(_manager.gameObject); yield return Frames();

            Assert.IsTrue(handle == null && waiting == null);
            Assert.AreEqual(1, active, "Manager destruction despawns active handles in OnDisable, as before");
            Assert.AreEqual(1, pending);
            _provider.Gate.TrySetResult(_provider.Lease()); yield return Frames();
            Assert.AreEqual(1, active); Assert.AreEqual(1, pending);
        }

        // ---- F2: load failure and exceptions ----

        [UnityTest] public IEnumerator NullLeaseIsNotStickyAndTheNextPlayRetries()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            _provider.Script.Enqueue(() => null);

            var failed = Play(loop: true, callBack: () => calls++);
            Assert.IsFalse(failed.gameObject.activeSelf); Assert.AreEqual(1, calls);

            var retry = Play(loop: true);
            Assert.AreEqual(2, _provider.Loads, "A null result must not be memoized");
            Assert.IsTrue(retry.IsPlaying); Assert.AreSame(failed, retry);
            _manager.Despawn(retry);
            yield return null;
        }

        [UnityTest] public IEnumerator PlayAsyncNullLeaseReturnsNullAndCallsBackOnce()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            _provider.Script.Enqueue(() => null);
            var failed = PlayAsync(callBack: () => calls++);
            yield return Completed(failed);
            Assert.IsNull(failed.Result); Assert.AreEqual(1, calls);

            var retry = PlayAsync(loop: true);
            yield return Completed(retry);
            Assert.IsTrue(retry.Result.IsPlaying); Assert.AreEqual(2, _provider.Loads);
        }

        [UnityTest] public IEnumerator FailedPreloadDoesNotBlockTheNextLoad()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _provider.Script.Enqueue(() => null);
            var preload = _manager.PreloadAsync("fixture").AsTask();
            yield return Completed(preload);

            var handle = Play(loop: true);
            Assert.IsTrue(handle.IsPlaying); Assert.AreEqual(2, _provider.Loads);
        }

        [UnityTest] public IEnumerator LeaseWithoutPrefabIsDisposedAndRetried()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int disposed = 0;
            _provider.Script.Enqueue(() => new EffectPrefabLease(null, () => disposed++));
            var failed = Play(loop: true);
            Assert.AreEqual(1, disposed); Assert.IsFalse(failed.gameObject.activeSelf);
            Assert.IsTrue(Play(loop: true).IsPlaying);
            yield return null;
        }

        [UnityTest] public IEnumerator ProviderFailureInSyncPlayRecoversHandleAndRetries()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var failed = Play(loop: true, callBack: () => calls++);

            LogAssert.Expect(LogType.Exception, new Regex("expected fixture provider failure"));
            _provider.Gate.TrySetException(new InvalidOperationException("expected fixture provider failure"));
            yield return null;
            Assert.AreEqual(1, calls); Assert.IsFalse(failed.gameObject.activeSelf); Assert.IsFalse(failed.IsPlaying);

            _provider.Gate = null;
            var retry = Play(loop: true);
            Assert.IsTrue(retry.IsPlaying); Assert.AreSame(failed, retry); Assert.AreEqual(2, _provider.Loads);
        }

        [UnityTest] public IEnumerator ProviderSynchronousThrowFaultsPlayAsyncAndCallsBackOnce()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            _provider.Script.Enqueue(() => throw new InvalidOperationException("expected fixture provider failure"));

            var failed = PlayAsync(callBack: () => calls++);
            yield return Completed(failed);
            Assert.IsTrue(failed.IsFaulted); Assert.IsInstanceOf<InvalidOperationException>(failed.Exception.InnerException);
            Assert.AreEqual(1, calls);

            var retry = PlayAsync(loop: true);
            yield return Completed(retry);
            Assert.IsTrue(retry.Result.IsPlaying);
        }

        [UnityTest] public IEnumerator CanceledLoadRecoversHandleWithoutAnErrorLog()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int syncCalls = 0, asyncCalls = 0;
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var handle = Play(loop: true, callBack: () => syncCalls++);
            var task = PlayAsync(loop: true, callBack: () => asyncCalls++);

            _provider.Gate.TrySetCanceled();
            yield return Completed(task);
            // UniTask 2.5.10 AsTask reports cancellation through SetException, so the Task is Faulted rather than Canceled.
            Assert.IsInstanceOf<OperationCanceledException>(task.Exception?.GetBaseException());
            Assert.AreEqual(1, syncCalls); Assert.AreEqual(1, asyncCalls);
            Assert.IsFalse(handle.gameObject.activeSelf);
        }

        [UnityTest] public IEnumerator MissingAdapterRecoversHandleOnBothEntryPoints()
        {
            _prefab.AddComponent<Spine.Unity.Fixture.VendorRootMarker>(); int calls = 0;

            LogAssert.Expect(LogType.Exception, new Regex("Register the required optional Effect renderer adapter"));
            var synced = Play(loop: true, callBack: () => calls++);
            Assert.IsFalse(synced.gameObject.activeSelf); Assert.AreEqual(1, calls);

            var asynced = PlayAsync(loop: true, callBack: () => calls++);
            yield return Completed(asynced);
            Assert.IsTrue(asynced.IsFaulted); Assert.AreEqual(2, calls);

            yield return Frames();
            Assert.AreEqual(0, synced.transform.childCount, "The unbound instance must be destroyed");
            Assert.IsNull(synced.Renderer);
        }

        [UnityTest] public IEnumerator RendererPlayExceptionRecoversHandleAndAllowsReuse()
        {
            _prefab.AddComponent<RecordingEffectRenderer>().ThrowOnPlay = true; int calls = 0;

            LogAssert.Expect(LogType.Exception, new Regex("expected fixture play failure"));
            var handle = Play(callBack: () => calls++);
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.gameObject.activeSelf);

            var renderer = Rec(handle); renderer.ThrowOnPlay = false;
            Assert.AreSame(handle, Play(loop: true)); Assert.AreEqual(1, renderer.Plays);
            yield return null;
        }

        [UnityTest] public IEnumerator BehaviourBeginExceptionUnbindsSoTheNextRequestBindsAgain()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var behaviour = _prefab.AddComponent<ThrowOnBeginBehaviour>(); int calls = 0;

            LogAssert.Expect(LogType.Exception, new Regex("expected fixture begin failure"));
            var failed = Play(loop: true, callBack: () => calls++);
            Assert.AreEqual(1, calls); Assert.IsNull(failed.Renderer);

            behaviour.Armed = false;
            var retry = Play(loop: true);
            Assert.AreSame(failed, retry); Assert.IsTrue(retry.IsPlaying); Assert.IsNotNull(retry.Renderer);
            yield return null;
        }

        [UnityTest] public IEnumerator ConfiguringProviderAfterOnlyAFailedPreloadStaysAllowed()
        {
            _provider.Script.Enqueue(() => null);
            var preload = _manager.PreloadAsync("fixture").AsTask();
            yield return Completed(preload);
            Assert.DoesNotThrow(() => _manager.SetPrefabProvider(_provider));

            preload = _manager.PreloadAsync("fixture").AsTask();
            yield return Completed(preload);
            Assert.Throws<InvalidOperationException>(() => _manager.SetPrefabProvider(_provider));
        }

        [UnityTest] public IEnumerator BehaviourTickExceptionEndsTheRequestOnceAndKeepsTheHandleReusable()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0, completed = 0;
            var handle = Play(loop: true, callBack: () => calls++);
            handle.OnComplete += _ => completed++;
            handle.AddBehaviour<ThrowOnTickBehaviour>();

            LogAssert.Expect(LogType.Exception, new Regex("expected fixture tick failure"));
            yield return Frames();
            Assert.AreEqual(1, calls); Assert.AreEqual(0, completed, "Failure is not completion");
            Assert.IsFalse(handle.IsPlaying); Assert.IsFalse(handle.gameObject.activeSelf);

            Assert.AreSame(handle, Play(loop: true));
            yield return Frames();
            Assert.IsTrue(handle.IsPlaying, "The failed behaviour must not carry into the next request");
            _manager.Despawn(handle);
            Assert.AreEqual(1, calls);
        }

        [UnityTest] public IEnumerator TickThatEndsItsRequestBeforeThrowingLeavesTheNextRequestAlone()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0, nextCalls = 0;
            var handle = Play(loop: true, callBack: () => calls++);
            EffectHandle next = null;
            var behaviour = handle.AddBehaviour<ThrowOnTickBehaviour>();
            behaviour.BeforeThrow = () =>
            {
                behaviour.BeforeThrow = null;
                _manager.Despawn(handle);
                next = Play(loop: true, callBack: () => nextCalls++);
            };

            LogAssert.Expect(LogType.Exception, new Regex("expected fixture tick failure"));
            yield return Frames();
            Assert.AreEqual(1, calls); Assert.AreEqual(0, nextCalls);
            Assert.AreSame(handle, next); Assert.IsTrue(next.IsPlaying, "The exception belongs to the ended request");
            _manager.Despawn(next);
            Assert.AreEqual(1, nextCalls);
        }

        // ---- callBack exactly once ----

        [UnityTest] public IEnumerator CallbackRunsOnceAcrossCompletionAndDespawn()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            var handle = Play(callBack: () => calls++);
            var completion = Rec(handle).Completion;
            completion(); completion(); _manager.Despawn(handle); _manager.Despawn(handle);
            Assert.AreEqual(1, calls);
            yield return null;
        }

        [UnityTest] public IEnumerator StopThenDespawnCallsBackOnDespawnOnly()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            var handle = Play(loop: true, callBack: () => calls++);
            int version = handle.RequestVersion;
            handle.Stop(); handle.Stop();
            Assert.IsFalse(handle.IsPlaying); Assert.AreNotEqual(version, handle.RequestVersion);
            Assert.IsTrue(handle.gameObject.activeSelf); Assert.AreEqual(0, calls, "Stop keeps its original not-returned meaning");
            _manager.Despawn(handle); _manager.Despawn(handle);
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.gameObject.activeSelf);
            yield return null;
        }

        [UnityTest] public IEnumerator DespawnDuringLoadCallsBackOnceAndIgnoresLateLoad()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var handle = Play(callBack: () => calls++);
            _manager.Despawn(handle);
            _provider.Gate.TrySetResult(_provider.Lease()); yield return Frames();
            Assert.AreEqual(1, calls); Assert.IsNull(handle.Renderer);
        }

        [UnityTest] public IEnumerator ThrowingCallbackDoesNotStopOtherHandles()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            LogAssert.Expect(LogType.Exception, new Regex("expected fixture callback failure"));
            var first = Play(loop: true, callBack: () => throw new InvalidOperationException("expected fixture callback failure"));
            var second = Play(loop: true, callBack: () => calls++);
            _manager.enabled = false;
            Assert.IsFalse(first.gameObject.activeSelf); Assert.IsFalse(second.gameObject.activeSelf);
            Assert.AreEqual(1, calls);
            yield return null;
        }

        [UnityTest] public IEnumerator CallbackCanReplayOnAnotherHandle()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); EffectHandle replay = null;
            var handle = Play(callBack: () => replay = Play(loop: true));
            Rec(handle).Completion();
            Assert.AreNotSame(handle, replay, "The handle returns to the pool after its notifications");
            Assert.IsTrue(replay.IsPlaying); Assert.IsTrue(replay.gameObject.activeSelf);
            _manager.Despawn(replay);
            yield return null;
        }

        [UnityTest] public IEnumerator OnCompleteFiresForCompletionOnly()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int completed = 0;
            var handle = Play(); handle.OnComplete += _ => completed++;
            _manager.Despawn(handle);
            Assert.AreEqual(0, completed, "Despawn is not completion");

            handle = Play(); handle.OnComplete += _ => completed++;
            Rec(handle).Completion();
            Assert.AreEqual(1, completed);
            yield return null;
        }

        [UnityTest] public IEnumerator DespawnFromBehaviourEndCannotEndTheRequestTwice()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int calls = 0;
            var handle = Play(loop: true, callBack: () => calls++);
            handle.AddBehaviour<DespawnOnEndBehaviour>().Manager = _manager;
            _manager.Despawn(handle);
            Assert.AreEqual(1, calls);
            yield return null;
        }

        [UnityTest] public IEnumerator OnCompleteSubscribedAfterTheRequestEndedDoesNotReachTheNextOne()
        {
            _prefab.AddComponent<RecordingEffectRenderer>(); int stale = 0, current = 0;
            var handle = Play();
            _manager.Despawn(handle);
            handle.OnComplete += _ => stale++;

            Assert.AreSame(handle, Play());
            handle.OnComplete += _ => current++;
            Rec(handle).Completion();
            Assert.AreEqual(0, stale, "A subscription belongs to one request");
            Assert.AreEqual(1, current);
            yield return null;
        }

        // ---- F3: FollowTargetBehaviour ----

        [UnityTest] public IEnumerator CodeAddedFollowKeepsTrackingAfterTargetAssignment()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var target = New("f3-target"); target.transform.position = new Vector3(3, 1, 0);
            var handle = Play(loop: true);
            var follow = handle.AddBehaviour<FollowTargetBehaviour>();
            follow.Target = target.transform; follow.Offset = Vector3.up;

            yield return Frames(3);
            Assert.IsTrue(follow.enabled, "Target assigned after AddBehaviour must not retire the module");
            target.transform.position = new Vector3(6, 2, 0); yield return null;
            Assert.AreEqual(target.transform.position + Vector3.up, handle.transform.position);
            _manager.Despawn(handle);
        }

        [UnityTest] public IEnumerator FollowWaitsForATargetAssignedInALaterFrame()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var target = New("f3-late-target"); target.transform.position = new Vector3(2, 0, 0);
            var handle = Play(loop: true);
            var follow = handle.AddBehaviour<FollowTargetBehaviour>();
            yield return Frames(3);
            follow.Target = target.transform; yield return Frames(2);
            Assert.AreEqual(target.transform.position, handle.transform.position);

            Object.Destroy(target); yield return Frames(3);
            Assert.IsFalse(follow.enabled, "Losing an assigned Target still ends the module");
            _manager.Despawn(handle);
        }

        [UnityTest] public IEnumerator PrefabFollowTargetSurvivesPoolReuse()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var target = New("f3-prefab-target"); target.transform.position = new Vector3(4, 4, 0);
            var authored = _prefab.AddComponent<FollowTargetBehaviour>();
            authored.Target = target.transform; authored.Offset = Vector3.right;

            for (int run = 0; run < 3; run++)
            {
                target.transform.position = new Vector3(run, 5, 0);
                var handle = Play(loop: true);
                yield return Frames(2);
                Assert.AreEqual(target.transform.position + Vector3.right, handle.transform.position, "run " + run);
                _manager.Despawn(handle);
                handle.transform.position = Vector3.zero;
            }
        }

        [UnityTest] public IEnumerator PooledCodeFollowDoesNotKeepThePreviousTarget()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var target = New("f3-pooled-target");
            var handle = Play(loop: true);
            var follow = handle.AddBehaviour<FollowTargetBehaviour>(); follow.Target = target.transform; follow.Offset = Vector3.up;
            _manager.Despawn(handle);

            Assert.AreSame(handle, Play(loop: true));
            var reused = handle.AddBehaviour<FollowTargetBehaviour>();
            Assert.AreSame(follow, reused); Assert.IsTrue(reused.Target == null); Assert.AreEqual(Vector3.zero, reused.Offset);
            _manager.Despawn(handle);
            yield return null;
        }

        // ---- F4: pool reuse ----

        [UnityTest] public IEnumerator BuiltInBehaviourBoundUnderAnInactiveParentRunsAndSurvivesReuse()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _prefab.AddComponent<LifecycleCountingBehaviour>();
            var parent = New("f4-inactive-loop", typeof(RectTransform)); parent.SetActive(false);

            var handle = Play(loop: true, parent: parent.transform);
            var behaviour = handle.GetComponentInChildren<LifecycleCountingBehaviour>(true);
            Assert.AreEqual(1, behaviour.Begins, "The first bind must register built-ins under an inactive parent");

            parent.SetActive(true); yield return Frames();
            Assert.Greater(behaviour.Ticks, 0, "The registered module ticks once the hierarchy is active");
            _manager.Despawn(handle);
            Assert.AreEqual(1, behaviour.Ends);

            Assert.AreSame(handle, Play(loop: true));
            Assert.AreEqual(2, behaviour.Begins, "The second run reuses the bound instance");
            yield return Frames();
            Assert.Greater(behaviour.Ticks, 0);
            _manager.Despawn(handle);
            Assert.AreEqual(2, behaviour.Ends);
        }

        [UnityTest] public IEnumerator BuiltInBehaviourBoundForAnInactiveNonLoopIsEndedAndReused()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _prefab.AddComponent<LifecycleCountingBehaviour>();
            var parent = New("f4-inactive-once", typeof(RectTransform)); parent.SetActive(false); int calls = 0;

            var handle = Play(parent: parent.transform, callBack: () => calls++);
            var behaviour = handle.GetComponentInChildren<LifecycleCountingBehaviour>(true);
            Assert.AreEqual(1, behaviour.Begins);
            yield return Frames();
            Assert.AreEqual(1, calls); Assert.AreEqual(1, behaviour.Ends);

            Assert.AreSame(handle, Play(loop: true));
            Assert.AreEqual(2, behaviour.Begins);
            Assert.IsTrue(behaviour.enabled, "End disabled the module; reuse must enable it again");
            yield return Frames();
            Assert.Greater(behaviour.Ticks, 0);
            _manager.Despawn(handle);
        }

        [UnityTest] public IEnumerator RequestEndedWhileReactivatingAPooledHandleDoesNotPlay()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _prefab.AddComponent<StopHandleOnEnable>(); int calls = 0;
            var handle = Play(loop: true);
            var renderer = Rec(handle);
            var stopper = handle.GetComponentInChildren<StopHandleOnEnable>();
            _manager.Despawn(handle);

            stopper.Armed = true;
            Assert.AreSame(handle, Play(loop: true, callBack: () => calls++));
            Assert.AreEqual(1, renderer.Plays, "A stopped request must not start the renderer");
            Assert.IsFalse(handle.IsPlaying);

            _manager.Despawn(handle);
            Assert.AreEqual(1, calls, "Stop still waits for Despawn");
            yield return null;
        }

        [UnityTest] public IEnumerator InstanceDestroyedWhilePooledIsBoundAgain()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _prefab.AddComponent<LifecycleCountingBehaviour>(); int calls = 0;
            var handle = Play(loop: true);
            var destroyed = Rec(handle);
            _manager.Despawn(handle);
            Object.Destroy(destroyed.gameObject); yield return null;

            Assert.AreSame(handle, Play(loop: true, callBack: () => calls++));
            Assert.IsTrue(handle.IsPlaying);
            Assert.AreNotSame(destroyed, handle.Renderer, "A destroyed Unity renderer is not a usable binding");
            Assert.AreEqual(1, Rec(handle).Plays);
            Assert.AreEqual(1, handle.GetComponentInChildren<LifecycleCountingBehaviour>().Begins, "Built-ins come from the new instance");
            _manager.Despawn(handle);
            Assert.AreEqual(1, calls);
        }

        [UnityTest] public IEnumerator InstanceDestroyedDuringARequestEndsCleanlyAndBindsAgain()
        {
            _prefab.AddComponent<SpriteRenderer>(); int calls = 0;
            var handle = Play(loop: true, callBack: () => calls++);
            Object.Destroy(((Component)handle.Renderer).gameObject); yield return null;

            _manager.Despawn(handle);
            Assert.AreEqual(1, calls);

            Assert.AreSame(handle, Play(loop: true, sortingLayer: "Default", sortingOrder: 8));
            Assert.AreEqual(8, handle.GetComponentInChildren<SpriteRenderer>().sortingOrder, "The new instance receives the request");
            _manager.Despawn(handle);
            // A logged exception from the destroyed renderer fails this test through LogAssert.
        }

        [UnityTest] public IEnumerator PauseThenDespawnReuseRunsNormally()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var handle = Play(loop: true);
            var tick = handle.AddBehaviour<CountingTickBehaviour>();
            handle.Pause(); Assert.IsTrue(Rec(handle).Paused);
            _manager.Despawn(handle);
            Assert.IsFalse(Rec(handle).Paused, "Renderer must not keep the old pause");

            Assert.AreSame(handle, Play(loop: true));
            var reused = handle.AddBehaviour<CountingTickBehaviour>();
            Assert.AreSame(tick, reused);
            yield return Frames();
            Assert.Greater(reused.Ticks, 0, "A reused handle must not stay paused");
            Assert.IsFalse(Rec(handle).Paused);
        }

        [UnityTest] public IEnumerator PauseBeforeLoadThenDespawnDoesNotPauseTheNextRequest()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            _provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var handle = Play(loop: true); handle.Pause(); _manager.Despawn(handle);
            _provider.Gate.TrySetResult(_provider.Lease()); yield return Frames();
            _provider.Gate = null;

            Assert.AreSame(handle, Play(loop: true));
            Assert.IsFalse(Rec(handle).Paused); Assert.IsTrue(handle.IsPlaying);
        }

        [UnityTest] public IEnumerator RendererWithoutRestoreInterfaceIsStillUnpaused()
        {
            _prefab.AddComponent<PauseOnlyEffectRenderer>();
            var handle = Play(loop: true); handle.Pause();
            var renderer = (PauseOnlyEffectRenderer)handle.Renderer;
            Assert.IsTrue(renderer.Paused);
            _manager.Despawn(handle);
            Assert.IsFalse(renderer.Paused);
            yield return null;
        }

        [UnityTest] public IEnumerator PauseOnAReturnedHandleIsIgnored()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var handle = Play(loop: true); _manager.Despawn(handle);
            handle.Pause();
            Assert.IsFalse(Rec(handle).Paused);
            Assert.AreSame(handle, Play(loop: true));
            Assert.IsFalse(Rec(handle).Paused);
            _manager.Despawn(handle);
            yield return null;
        }

        [UnityTest] public IEnumerator SortingIsNotInheritedFromThePreviousRequest()
        {
            var sprite = _prefab.AddComponent<SpriteRenderer>(); sprite.sortingOrder = 3;
            var handle = Play(loop: true, sortingLayer: "Default", sortingOrder: 9);
            var instance = handle.GetComponentInChildren<SpriteRenderer>();
            Assert.AreEqual(9, instance.sortingOrder);
            _manager.Despawn(handle);
            Assert.AreEqual(3, instance.sortingOrder);

            Assert.AreSame(handle, Play(loop: true));
            Assert.AreEqual(3, instance.sortingOrder, "An empty layer keeps the prefab value, not the previous request");
            _manager.Despawn(handle);
            yield return null;
        }

        [UnityTest] public IEnumerator ChildParticleSortingIsRestored()
        {
            var particles = ChildParticles("f4-particles");
            particles.GetComponent<ParticleSystemRenderer>().sortingOrder = 2;
            var handle = Play(loop: true, sortingLayer: "Default", sortingOrder: 11);
            var instance = handle.GetComponentInChildren<ParticleSystemRenderer>();
            Assert.AreEqual(11, instance.sortingOrder);
            _manager.Despawn(handle);
            Assert.AreEqual(2, instance.sortingOrder);
            yield return null;
        }

        [UnityTest] public IEnumerator RendererStateIsCapturedOnceAndRestoredEveryRequest()
        {
            _prefab.AddComponent<RecordingEffectRenderer>();
            var handle = Play(loop: true, sortingLayer: "custom", sortingOrder: 7);
            var renderer = Rec(handle);
            Assert.AreEqual("custom", renderer.Layer);
            _manager.Despawn(handle);
            Assert.AreEqual("prefab", renderer.Layer);

            Assert.AreSame(handle, Play(loop: true)); _manager.Despawn(handle);
            Assert.AreEqual(1, renderer.Captures); Assert.AreEqual(2, renderer.Restores);
            yield return null;
        }

        [UnityTest] public IEnumerator SortingSnapshotRestoresEveryTargetAndSkipsDestroyedOnes()
        {
            var root = New("snapshot-root", typeof(Canvas));
            var nestedCanvas = New("snapshot-canvas", typeof(Canvas)); nestedCanvas.transform.SetParent(root.transform, false);
            var nested = New("snapshot-child", typeof(SortingGroup)); nested.transform.SetParent(root.transform, false);
            var lost = New("snapshot-lost", typeof(SpriteRenderer)); lost.transform.SetParent(root.transform, false);
            var canvas = nestedCanvas.GetComponent<Canvas>(); var group = nested.GetComponent<SortingGroup>(); group.sortingOrder = 4;

            var snapshot = new EffectSortingSnapshot();
            snapshot.Capture(root);
            canvas.overrideSorting = true; canvas.sortingOrder = 50; group.sortingOrder = 60;
            Object.DestroyImmediate(lost);

            Assert.DoesNotThrow(snapshot.Restore);
            Assert.IsFalse(canvas.overrideSorting); Assert.AreEqual(0, canvas.sortingOrder); Assert.AreEqual(4, group.sortingOrder);
            yield return null;
        }

        // ---- F5: renderer selection ----

        [UnityTest] public IEnumerator ChildOnlyParticlePrefabPlaysUntilItsParticlesFinish()
        {
            ChildParticles("f5-child", 0.2f); int calls = 0;
            var handle = Play(callBack: () => calls++);
            Assert.IsInstanceOf<ParticleEffectRenderer>(handle.Renderer);
            Assert.IsTrue(handle.IsPlaying, "A child-only particle must not be returned immediately");
            Assert.IsTrue(handle.GetComponentInChildren<ParticleSystem>().isPlaying);
            yield return Until(() => calls == 1, "Particles must finish and return");
            Assert.IsFalse(handle.gameObject.activeSelf);
        }

        [UnityTest] public IEnumerator GroupRootDrivesEverySiblingParticleSystem()
        {
            ChildParticles("f5-short", 0.05f); ChildParticles("f5-long", 0.3f); int calls = 0;
            var handle = Play(loop: true, callBack: () => calls++);
            var systems = handle.GetComponentsInChildren<ParticleSystem>();
            Assert.AreEqual(2, systems.Length);
            foreach (var system in systems) Assert.IsTrue(system.isPlaying);
            foreach (var system in systems) Assert.IsTrue(system.main.loop);
            yield return null;
            _manager.Despawn(handle);
            foreach (var system in systems) { Assert.IsFalse(system.isPlaying); Assert.AreEqual(0, system.particleCount); }
            Assert.AreEqual(1, calls);
        }

        [UnityTest] public IEnumerator RootSpriteWithChildParticleSelectsTheParticleRenderer()
        {
            _prefab.AddComponent<SpriteRenderer>(); ChildParticles("f5-mixed");
            var handle = Play(loop: true);
            Assert.IsInstanceOf<ParticleEffectRenderer>(handle.Renderer);
            _manager.Despawn(handle);
            yield return null;
        }

        [UnityTest] public IEnumerator PrefabWithoutAnyRendererWarnsAndCompletes()
        {
            int calls = 0;
            LogAssert.Expect(LogType.Warning, new Regex("no recognizable renderer"));
            var handle = Play(callBack: () => calls++);
            Assert.IsInstanceOf<SpriteEffectRenderer>(handle.Renderer);
            Assert.AreEqual(1, calls);
            yield return null;
        }

        [UnityTest] public IEnumerator ExplicitParticleRendererWithoutSystemsCompletesInsteadOfLeaking()
        {
            _prefab.AddComponent<ParticleEffectRenderer>(); int calls = 0;
            var handle = Play(callBack: () => calls++);
            Assert.AreEqual(1, calls); Assert.IsFalse(handle.gameObject.activeSelf);
            yield return null;
        }
    }
}
