using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.Effect.Tests
{
    public sealed class EffectsConcurrentLoadTests
    {
        sealed class Provider:IEffectPrefabProvider
        {
            public UniTaskCompletionSource<EffectPrefabLease> Gate=new();
            public int Loads,Returns;
            public UniTask<EffectPrefabLease> LoadAsync(string key,CancellationToken token){Loads++;return Gate.Task;}
        }
        EffectManager manager;GameObject prefab;Provider provider;
        [SetUp]public void Setup()
        {
            prefab=new GameObject("concurrent independent prefab");prefab.AddComponent<ControlledEffectRenderer>();
            manager=new GameObject("concurrent manager").AddComponent<EffectManager>();provider=new Provider();manager.SetPrefabProvider(provider);
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {if(manager)Object.Destroy(manager.gameObject);yield return null;yield return null;if(prefab)Object.Destroy(prefab);yield return null;}
        static IEnumerator Done(Task task)
        {float end=Time.realtimeSinceStartup+3;while(!task.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;Assert.That(task.IsCompleted,Is.True);}
        [UnityTest]public IEnumerator PendingConcurrentPlaysAndPreloadShareOneLease()
        {
            var a=manager.PlayAsync(new EffectRequest("one",loop:true)).AsTask();
            var b=manager.PlayAsync(new EffectRequest("one",loop:true)).AsTask();
            var preload=manager.PreloadAsync("one").AsTask();
            Assert.That(a.IsCompleted||b.IsCompleted||preload.IsCompleted,Is.False);Assert.That(provider.Loads,Is.EqualTo(1));
            provider.Gate.TrySetResult(new EffectPrefabLease(prefab,()=>provider.Returns++));yield return Done(Task.WhenAll(a,b,preload));
            Assert.That(a.IsFaulted||b.IsFaulted||preload.IsFaulted,Is.False);Assert.That(a.Result,Is.Not.SameAs(b.Result));
            Assert.That(a.Result.IsPlaying&&b.Result.IsPlaying,Is.True);
            Object.Destroy(manager.gameObject);yield return null;yield return null;Assert.That(provider.Returns,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator SharedFailureReachesBothConsumersAndRetryCreatesOneNewLoad()
        {
            var a=manager.PlayAsync(new EffectRequest("one",loop:true)).AsTask();var b=manager.PlayAsync(new EffectRequest("one",loop:true)).AsTask();
            provider.Gate.TrySetException(new InvalidOperationException("expected shared fixture failure"));yield return Done(a);yield return Done(b);
            Assert.That(a.Exception.GetBaseException(),Is.TypeOf<InvalidOperationException>());Assert.That(b.Exception.GetBaseException(),Is.TypeOf<InvalidOperationException>());
            provider.Gate=new UniTaskCompletionSource<EffectPrefabLease>();
            var retry=manager.PlayAsync(new EffectRequest("one",loop:true)).AsTask();Assert.That(provider.Loads,Is.EqualTo(2));
            provider.Gate.TrySetResult(new EffectPrefabLease(prefab,()=>provider.Returns++));yield return Done(retry);Assert.That(retry.Result.IsPlaying,Is.True);
        }
    }
}
