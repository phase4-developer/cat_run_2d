using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
namespace Jjevol.EditorAttributes
{
    [CustomPropertyDrawer(typeof(SortingLayerFieldAttribute))]
    public sealed class EffectSortingLayerFieldDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var names = SortingLayer.layers.Select(layer => layer.name).ToArray();
            int selected = Array.IndexOf(names, property.stringValue);
            EditorGUI.BeginChangeCheck();
            int next = EditorGUI.Popup(position, label.text, selected, names);
            if (EditorGUI.EndChangeCheck() && next >= 0) property.stringValue = names[next];
        }
    }
}
