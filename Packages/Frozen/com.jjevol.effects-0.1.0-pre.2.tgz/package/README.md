# JJEvol Effects — local candidate

Overall transfer status: PARTIAL. STEP 6 basic Core validation passed in Unity 6000.3.9f1 Editor: 31 standalone tests, including independent AnimatorController, movement/UI behaviours, pause and scene lifetime. The later lifecycle and module restructure, EffectsLifecycleTests, EffectsEndReasonTests and EffectsModuleTests were compiled statically and have NOT been run in Unity. Optional Vendor/UI integrations, original game content and Player/device validation remain incomplete. No release or frozen archive.

Install this package and explicitly select UniTask in the consuming project manifest:

~~~json
"com.cysharp.unitask": "https://github.com/Cysharp/UniTask.git?path=src/UniTask/Assets/Plugins/UniTask#f213ff497e4ff462a77319cf677cf20cc0860ca9"
~~~

The package declares UniTask 2.5.10; the Host pins its actual Git source. SDK sources are not bundled. Unity baseline is 6000.3.9f1.

Namespace remains jjevol.Effect. Play(string,Vector3,Transform), Play(EffectRequest), UniTask<EffectHandle> PlayAsync, UniTask PreloadAsync, PlayRouletteEffect, Despawn and profile configuration retain call shapes. Position is local, as in the original implementation.

~~~csharp
var effects = EffectManager.Instance;
// Optional: before any loads, when com.jjevol.effects.addressables is installed:
effects.SetPrefabProvider(new AddressablesEffectPrefabProvider());
await effects.PreloadAsync("MyEffect");
var handle = await effects.PlayAsync(new EffectRequest("MyEffect", loop: true, parent: effectRoot));
effects.Despawn(handle);
~~~

Without explicit provider configuration, Core uses Resources.Load<GameObject>(key). This changes the original implicit Common AddressablesManager initialization; Addressables-only keys require the optional provider above. No game Host is migrated automatically.

Core no longer depends on PersistentSingleton, Coffee, Spine or DOTween types. A small owned singleton retains Instance/HasInstance/IsDestroyed/applicationIsQuitting and scene persistence. Configure a provider before loading. Prefab loads are shared per key; one prefab lease remains while any active/idle instance exists. Idle cull or manager destruction destroys instances before deferred lease return. Preload pins until pool cull or manager destruction. Disable despawns owned active instances; individual Despawn invalidates late binding. Public async APIs retain their original absence of a caller CancellationToken parameter. Underlying loads are not claimed to be forcibly aborted.

Completion callbacks and idle cull use request identities. Manager tracks handles even when parented outside its hierarchy. maxPool remains the original declared field; the original pool did not enforce a capacity cap, and this candidate does not invent one.

Integrations~ contains unchanged user-authored DOTween/Spine/Toast/icon/Coffee-scale sources with original script metas. Unity excludes this folder. These are NOT installable/validated adapters: the Vendor assemblies, renderer registration and/or Common AddressableImage/AddressableTexture connection are still required. No Vendor binary/source or product effect prefab is included.

## Lifecycle

EffectHandle holds one lifetime state: Idle (pooled) -> Loading -> Playing -> Idle. Stop moves a live request to Finished, where it waits for Despawn. Pause and the inactive-hierarchy wait are separate flags. Play and PlayAsync run the same pipeline (prefab, bind, play); Play is a thin caller that logs what PlayAsync would throw.

Every end passes one exit with one EffectEndReason. EffectRequest.onEnded runs exactly once and receives that reason; callBack runs exactly once unless the handle itself was destroyed:

| End | Reason | callBack | OnComplete | onEnded | Notes |
|---|---|---|---|---|---|
| Natural completion | Completed | once | once | once | |
| Non-loop under a deactivated parent, parent destroyed, or the handle passed to Object.Destroy | Interrupted | once | no | once | Runs in EffectManager.LateUpdate, never inside the disable callback |
| Despawn, manager disable | Despawned | once | no | once | Duplicate Despawn is ignored |
| Manager destroy | Despawned | once | no | once | Unity calls OnDisable first, which despawns active and loading handles |
| Prefab not found | Failed | once | no | once | Play returns the recovered handle, PlayAsync returns null, Core logs a warning |
| Provider exception, missing adapter, renderer or behaviour exception | Failed | once | no | once | Play logs the exception, PlayAsync faults |
| Behaviour exception during playback (Tick, IsFinished, End) | Failed | once | no | once | Logged. A Tick that already ended its own request leaves the next request alone |
| Canceled load | Failed | once | no | once | Play stays silent, PlayAsync is canceled |
| Loop or stopped handle passed to Object.Destroy, or any handle passed to DestroyImmediate | Destroyed | no | no | once | callBack keeps its original behaviour |

A loop or stopped handle has no Interrupted path. If it dies with its parent, it ends as Destroyed. A live non-loop handle reaches the deferred settle before Object.Destroy finishes, measured in PlayMode.

callBack, OnComplete and onEnded run in that order, before the handle returns to the pool, so OnComplete never receives a handle that already runs a newer request. A Play inside a notification takes another handle. An exception from any of them is logged instead of reaching the caller or the next one, so one callback cannot stop other handles from ending. An OnComplete subscription lasts for one request: every new request clears it, including one added after the handle already ended.

Inactive parents: a non-loop effect ends as Interrupted when its parent is deactivated, even if the parent comes back in the same frame, because the renderer's waiter stopped with it. A loop stays Playing until its owner calls Despawn; when the hierarchy is active again the renderer restarts, finished built-in behaviours begin again and a pause is reapplied. Renderers whose own OnDisable clears data lose it: re-apply Toast data after reactivation. A Play under an inactive parent follows the same rule and does not start the renderer, and a first bind there still registers the prefab's built-in behaviours. Despawn from a parent's OnDisable is safe; the pool reparent waits for LateUpdate, including a panel disabled by another handle's callback.

Stop halts playback without returning the handle. The owner must still call Despawn, and Stop alone does not call back. A stopped handle is not ended by a parent deactivation.

## Structure

EffectManager is a thin MonoBehaviour. It composes the modules below, holds the serialized fields and pool profiles, receives Unity callbacks and forwards the public API. It implements IEffectPlayer, so code that only plays effects can depend on that interface. Modules are internal and receive their collaborators by constructor; the package has no dependency injection container.

| Module | Responsibility |
|---|---|
| EffectHandle | One lifetime state and the single exit. Knows its owner only through IEffectHandleHost, set once by Initialize |
| EffectPool | One per effect type: idle and active handles, idle cull, pool return and final prefab release. Hosts the handles it creates |
| EffectPlaybackPipeline | The flow shared by Play and PlayAsync: prefab, bind, start |
| EffectInstanceBinder | Instantiate, renderer selection, built-in behaviour collection, parenting into the handle |
| EffectSettleQueue | Handles waiting to leave a disable callback. Drained once per LateUpdate |
| EffectPrefabCache | Prefab state per key, see below |

## Prefab state

EffectPrefabCache keeps one record per key: Loading, Ready or Failed. Concurrent requests share one load. A null result or exception marks the record Failed and the next request loads again, including a Ready record whose prefab was destroyed. SetPrefabProvider also rejects a load still in progress; a key that only failed does not block it.

## Renderer selection and state

Selection order on the prefab root: an existing IEffectRenderer, Animator, registered adapter factories, then rejection of an unregistered Vendor root component. After that, a ParticleSystem anywhere under the root selects ParticleEffectRenderer, a root SpriteRenderer selects SpriteEffectRenderer, and otherwise the Sprite fallback is added with a warning. ParticleEffectRenderer drives the root system, or every active child system when the root only groups them, and waits for the longest one.

Prefab impact: a prefab with child-only particles used to fall through to the Sprite renderer and return at once; it now plays and waits. This includes a root SpriteRenderer with child particles, and a root with no renderer whose only particle child is inactive stays on the particle path and completes immediately. Sibling child systems are now started, stopped and given the request's loop and sorting. A ParticleEffectRenderer with no system completes at once instead of holding its handle.

F5 compatibility impact: on a prefab with a root SpriteRenderer and child particles, the request's Sorting now reaches only the particles (and a root SortingGroup, if any). The root sprite keeps its prefab sorting, where the Sprite path used to apply the request to it. Such a prefab needs a SortingGroup on its root, or matching authored sorting, to keep the sprite and particles together.

A prefab instance that destroys itself is not reused: a pooled handle whose Unity renderer is gone binds a new instance on its next request.

IEffectRendererStateRestore is optional. CaptureState runs once after binding, RestoreState after every request. EffectSortingSnapshot stores Renderer, SortingGroup and Canvas sorting for implementers; Animator, Particle, Sprite, DOTween and Spine renderers use it, so an empty request layer means the prefab value, not the previous request. Renderers without the interface still receive SetPaused(false) before StopAndClear when a paused request ends.

FollowTargetBehaviour waits while Target is unset, so a code-added module works when Target is assigned after AddBehaviour, even in a later frame. It ends when an assigned Target is lost. A Target and Offset stored on the prefab survive pool reuse; ones set from code do not.

## Optional renderers and limits

EffectRendererAdapters.Factories is an explicit optional renderer selection hook, after an existing IEffectRenderer/Animator and before basic Particle/Sprite fallback. Recognized Vendor root components without an adapter fail explicitly. Missing scripts or unsupported child-only Vendor compositions require asset validation; they are not verified by Core tests.

Pause suspends renderer completion time and behaviour ticks, including requests paused before binding. Both Play entry points reject disabled managers. Disabling the manager retains idle cache; re-enabling starts fresh idle intervals. Scene-destroyed handles retire their pool ownership before the final prefab lease is returned. Preload without instances has no idle expiration and remains until manager destruction or later final pool cull.

Basic Animator State/Trigger, movement/UI behaviours and Pause/Resume were exercised with independent assets. Full animation/curve combinations, original content compatibility, visual quality and legacy prefab migration remain NOT_VERIFIED. Existing no-op interface members such as Sprite skin are original behavior, not substitutes for missing Vendor functionality.

Original script GUIDs are preserved. Do not install alongside legacy classes/GUIDs. See Docs/EffectExtraction/Step6/STEP6_EffectCoreValidation.md for current scope and validation, and the unchanged STEP5_EffectExtraction.md/SourceInventory.json for original extraction provenance.
