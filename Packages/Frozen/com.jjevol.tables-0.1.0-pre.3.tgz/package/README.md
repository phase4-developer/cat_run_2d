# JJEvol Tables — local candidate

Basic Core validation is separate from the full mobile table/backend transfer. No release or frozen archive is produced. See the Framework `Docs/Guide/Verification.md` for validation scope and limitations.

Install this local UPM folder. Runtime assembly: `JJEvol.Tables.Runtime`. There are no SDK/UPM dependencies. Original namespaces (`jjevol`, `jjevol.Data`, global `TSVRow`/`ListDataBase`) and extracted script GUIDs are preserved. Do not install alongside the same legacy classes/GUIDs.

Game-owned row definitions derive from TableData; table definitions derive from KeyedTable, GroupedTable, IndexedTable or ListTable and implement ParseJson(TSVRow). TableCatalog joins indexed lookups. No game table definitions, numeric table allocations, content, save data or currencies are bundled.

Configure the source before loading, register all table instances, then call the existing repository API:

```csharp
GameTableSource.Configure(new PackagedTableSource(useEncrypt: false)); // explicitly plaintext
// TableRepository.Register(eachGameOwnedTable);
await jjevol.Data.TableRepository.LoadAllAsync();
// eachGameOwnedTable.Get(id), GetGroup(key), Datas, Dict
```

PackagedTableSource() and TableUtil methods retain encrypted defaults. Encrypted loading requires the Host to configure `TableRuntimeOptions.DecryptBytes`; absent configuration throws. The Core never treats encrypted data as plaintext automatically. The decoder receives decoded Base64 bytes and returns UTF-8 plaintext bytes. Original mobile Aes.Type.Simple keys/implementation, Firebase and SDK source are not copied. Independent AES fixtures validate the seam; mobile encrypted content compatibility remains unverified.

TableRuntimeOptions.Localization accepts ITableLocalization for string resolution. Not-ready/key/missing-entry semantics of GetLoc/GetLocWithFallback are preserved. The original TableData.GetLocEntry returns Unity Localization TableEntry and is **not available in the Core API**. Its original source is retained under Integrations~/Localization; this is not an active adapter. ServerTableSource remains unchanged reference source under Integrations~/Server and is not compiled. GameTableSource no longer selects by GameBackendBootstrap; games explicitly Configure an ITableSource. No automatic server revision/update/fallback is claimed.

The original cache path defaults to persistentDataPath/Assets/Table/<filename>.txt; a Host can override StaticTablePath. Resources calls must start from Unity's main thread. Async file loading keeps file I/O on a worker and Resources fallback on the caller's Unity context. Existing sync/async signatures, file fallback errors, local-path diagnostic parameter and export/debug helpers remain.

IDs use `(id / 1000000) % 1000`, `(id / 1000) % 1000`, `id % 1000`. No generic range/required/PK/FK checks are added. Single-source Keyed/Indexed tables overwrite duplicates; Grouped/List retain rows. IndexedTable.AddSource uses atomic duplicate-ID rejection when loaded through the virtual no-argument methods. The nonvirtual LoadDatas(ITableSource) overload retains the original primary-source-only behavior.

A table reload is atomic against parse failures: on every load path a row that fails to parse puts the previous rows back and rethrows. Every load path, including the no-argument `LoadDatas()`, reads before clearing, so a read failure keeps the previous rows. Classes deriving directly from TableBase override `CaptureData` and `RestoreData` to get the same protection; without them a failed reload leaves the table empty, never partial. A derived table that overrides `LoadDatas` and calls `_DataClear` and `InsertData` itself is outside this protection.

`KeyedTable.Datas` and `IndexedTable.Datas` return one read-only view per table instead of a new list per access. The view follows reloads, so a reference held across a reload shows the new rows; call `ToList()` for a fixed copy. A loop that is already enumerating keeps the rows it started with. Derived tables that replace a row in `_dict` directly, without changing the row count, are not noticed by the view until the next load.

TSV rules: the first line is the header and columns are found **by header name, never by position**. Names ignore case, surrounding spaces and a leading BOM, so `Get("id")` reads a column headed `ID` or ` id `. A column without a header name is ignored; with two equal names the first column wins. Rows whose cells are all empty or spaces are skipped, as are empty lines. A missing column reads as the getter default. Literal tabs, no quoting/comment/type-row normalization. Lists default to `/`, trim elements and retain empty elements. All numeric lists parse with the invariant culture. Invalid numbers return the existing fallback values. Game-specific `;` lists must explicitly select that separator.

TableRepository loads once in registration order; duplicate registration is allowed, late registration is not loaded after `loaded=true`, and Clear removes registrations. Individual table LoadDatas can reload. There is no new automatic reload, concurrency, transactional repository, schema or FK engine. Entering Play Mode clears registrations and the loaded flag, so with Domain Reload disabled a game must register its tables at startup, not in a static initializer. Validate game rules after all tables load.

Editor/Runtime tests are isolated in Tests. Resource TSV and AES files are independent synthetic fixtures, not consumer game data. Player/device, original production data, Unity Localization adapter, Firebase server cache, mobile encryption and export/editor-authoring workflows require separate validation.
