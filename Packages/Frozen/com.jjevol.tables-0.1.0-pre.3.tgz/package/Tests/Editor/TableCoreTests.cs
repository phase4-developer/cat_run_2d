using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using jjevol.Data;

namespace jjevol.Tables.Tests
{
    public sealed class TableCoreTests
    {
        FixtureSource source;
        static TSVRow Row(string text) => TSVRow.FromTsv(text).Single();
        [SetUp] public void Setup()
        {
            TableRepository.Clear(); TableRuntimeOptions.Localization = null; TableRuntimeOptions.DecryptBytes = null;
            TableRuntimeOptions.StaticTablePath = null;
            source = new FixtureSource(); source.Texts["fixture"] = "id\tkey\tgroup\tlink\n123456001\ta\t7\t123456002\n123456002\tb\t7\t0";
            GameTableSource.Configure(source);
        }
        [TearDown] public void Cleanup()
        {
            TableRepository.Clear(); TableRuntimeOptions.Localization = null; TableRuntimeOptions.DecryptBytes = null;
            TableRuntimeOptions.StaticTablePath = null; GameTableSource.Configure(new PackagedTableSource());
        }
        [TestCase(123456789,123,456,789)]
        [TestCase(0,0,0,0)]
        [TestCase(-123456789,-123,-456,-789)]
        public void ExistingIdArithmeticIsPreserved(int id,int table,int category,int index)
        {
            var data = new FixtureRow(Row("id\n" + id));
            Assert.AreEqual(table,data.table); Assert.AreEqual(category,data.category); Assert.AreEqual(index,data.index);
        }
        [Test] public void TableDataUppercasePrecedenceDefaultsAndNullableBase()
        {
            var row = new FixtureRow(Row("ID\tid\tgrade\n123456001\t5\t3"));
            Assert.AreEqual(123456001,row.id); Assert.AreEqual(row.id,row.sort); Assert.AreEqual(3,row.grade);
            Assert.AreEqual("123456001",row.name); Assert.AreEqual("123456001",row.description);
            Assert.IsTrue(row); Assert.IsFalse((FixtureRow)null);
            Assert.AreEqual(9999,new FixtureRow(Row("id\ninvalid")).id);
            Assert.AreEqual(0,new FixtureRow(Row("other\nx")).id);
        }
        [Test] public void TsvPreservesBlankFieldsShortRowsExtraFieldsAndFirstDuplicateHeaderWins()
        {
            var rows=TSVRow.FromTsv("id\tvalue\tvalue\tlast\r\n1\ta\tb\t\r\n\r\n2\tx\n3\tz\ty\tq\textra");
            Assert.AreEqual(3,rows.Count); Assert.AreEqual("a",rows[0].Get("value")); Assert.IsTrue(rows[0].Contains("last"));
            Assert.AreEqual("",rows[0].Get("last")); Assert.IsFalse(rows[1].Contains("last"));
            Assert.AreEqual("q",rows[2].Get("last")); Assert.IsNull(rows[0].Get("missing"));
        }
        [TestCase(null)] [TestCase("")] [TestCase("id")]
        public void EmptyOrHeaderOnlyHasNoRows(string text) => Assert.IsEmpty(TSVRow.FromTsv(text));
        [Test] public void ColumnsAreFoundByNameInAnyOrder()
        {
            var first=new FixtureRow(Row("grade\tsort\tid\n3\t7\t123456001"));
            var second=new FixtureRow(Row("id\tgrade\tsort\n123456001\t3\t7"));
            Assert.AreEqual(123456001,first.id); Assert.AreEqual(first.id,second.id);
            Assert.AreEqual(3,first.grade); Assert.AreEqual(7,first.sort); Assert.AreEqual(second.sort,first.sort);
        }
        [Test] public void HeaderNamesIgnoreCaseAndSurroundingSpaces()
        {
            var row=Row(" Grade \tNAME\t id\n3\tx\t42");
            Assert.AreEqual("3",row.Get("grade")); Assert.AreEqual("x",row.Get("name")); Assert.AreEqual("42",row.Get("ID"));
            Assert.AreEqual(42,new FixtureRow(row).id); Assert.AreEqual(3,new FixtureRow(row).grade);
        }
        [Test] public void UnnamedColumnsAndBlankRowsAreIgnoredAndMissingColumnsUseDefaults()
        {
            var rows=TSVRow.FromTsv("id\t\t  \tvalue\n1\tjunk\tmore\ta\n\t\t\t\n2\t\t\t");
            Assert.AreEqual(2,rows.Count); Assert.IsFalse(rows[0].Contains("")); Assert.AreEqual("a",rows[0].Get("value"));
            Assert.AreEqual(5,rows[0].GetInt("missing",5)); Assert.AreEqual("",rows[1].Get("value"));
            Assert.AreEqual(0,new FixtureRow(Row("value\nx")).grade);
        }
        [Test] public void DictionaryRowsUseTheSameNameRules()
        {
            var row=new TSVRow(new Dictionary<string,string>{{" Id ","5"},{"","x"}});
            Assert.AreEqual("5",row.Get("id")); Assert.IsFalse(row.Contains(""));
        }
        [Test] public void TsvHasNoQuoteUnescapingOrCommentFilteringAndIgnoresHeaderBom()
        {
            var rows=TSVRow.FromTsv("\uFEFFid\ttext\n1\t\"a\tb\"\n#comment\tx");
            Assert.AreEqual("1",rows[0].Get("id"));
            Assert.AreEqual("\"a",rows[0].Get("text")); Assert.AreEqual(2,rows.Count);
        }
        [Test] public void ScalarsUseInvariantConversionAndExistingFallbacks()
        {
            var row=Row("int\tfloat\tdouble\tlong\tdecimal\tbool\tnumericBool\tbad\tempty\n12\t1.25\t2.5\t4000000000\t3.75\tTRUE\t1\tx\t");
            var previous=CultureInfo.CurrentCulture;
            try
            {
                CultureInfo.CurrentCulture=CultureInfo.GetCultureInfo("fr-FR");
                Assert.AreEqual(12,row.GetInt("int")); Assert.AreEqual(1.25f,row.GetFloat("float"));
                Assert.AreEqual(2.5,row.GetDouble("double")); Assert.AreEqual(4000000000L,row.GetLong("long"));
                Assert.AreEqual(3.75m,row.GetDecimal("decimal")); Assert.IsTrue(row.GetBoolean("bool"));
                Assert.IsFalse(row.GetBoolean("numericBool")); Assert.AreEqual(9,row.GetInt("bad",9));
                Assert.AreEqual("fallback",row.GetString("empty","fallback")); Assert.AreEqual(5,row.GetInt("absent",5));
            }
            finally { CultureInfo.CurrentCulture=previous; }
        }
        [Test] public void ListsKeepSeparatorTrimEmptyElementsAndInvalidDefaults()
        {
            var row=Row("values\tcustom\tfloats\tbools\n1 / bad / / 3\t5;6\t1.25/bad/2.5\ttrue/1/false/TRUE");
            CollectionAssert.AreEqual(new[]{"1","bad","","3"},row.GetStringList("values"));
            CollectionAssert.AreEqual(new[]{1,0,0,3},row.GetIntList("values"));
            CollectionAssert.AreEqual(new long[]{1,0,0,3},row.GetLongList("values"));
            CollectionAssert.AreEqual(new[]{5,6},row.GetIntList("custom",';'));
            CollectionAssert.AreEqual(new[]{1.25f,0,2.5f},row.GetFloatList("floats"));
            CollectionAssert.AreEqual(new[]{1.25d,0,2.5d},row.GetDoubleList("floats"));
            CollectionAssert.AreEqual(new[]{true,false,false,true},row.GetBooleanList("bools")); Assert.IsEmpty(row.GetStringList("missing"));
        }
        [TestCase("2026-10-30T12:34:56+09:00",2026,10,30,3)]
        [TestCase("20261030123456",2026,10,30,12)]
        public void DateParsingUsesOriginalUtcRules(string value,int year,int month,int day,int hour)
        {
            var date=Row("time\n"+value).GetDateTime("time");
            Assert.AreEqual(DateTimeKind.Utc,date.Kind); Assert.AreEqual(new DateTime(year,month,day,hour,34,56,DateTimeKind.Utc),date);
            Assert.AreEqual(DateTime.UnixEpoch,Row("time\nbad").GetDateTime("time",DateTime.UnixEpoch));
        }
        [Test] public void KeyedAndIndexedSingleSourceKeepLastDuplicate()
        {
            source.Texts["fixture"]="id\tkey\n1\ta\n1\tb\n2\tb";
            var indexed=new FixtureIndexed(); indexed.LoadDatas(source); Assert.AreEqual("b",indexed.Get(1).key); Assert.IsNull(indexed.Get(99));
            var keyed=new FixtureKeyed(); keyed.LoadDatas(source); Assert.AreEqual(2,keyed.Get("b").id); Assert.IsNull(keyed.Get("absent"));
            Assert.AreEqual(2,indexed.Datas.Count); Assert.AreEqual(2,keyed.Dict.Count);
        }
        [Test] public void GroupedAndListKeepAllRowsAndGroupOrder()
        {
            var grouped=new FixtureGrouped(); grouped.LoadDatas(source);
            CollectionAssert.AreEqual(new[]{123456001,123456002},grouped.GetGroup(7).Select(d=>d.id));
            LogAssert.Expect(LogType.Warning,"fixture Data 8 Is Null "); Assert.IsNull(grouped.GetGroup(8));
            var list=new FixtureList(); list.LoadDatas(source); Assert.AreEqual(2,list.Datas.Count); Assert.AreEqual(typeof(FixtureRow),list.RowType);
        }
        [Test] public void RepositoryOrderDuplicateRegistrationLateRegistrationAndReloadPolicy()
        {
            var first=new FixtureIndexed("fixture");source.Texts["second"]="id\n2";source.Texts["late"]="id\n3";
            TableRepository.Register(first);TableRepository.Register(first);TableRepository.Register(new FixtureIndexed("second"));
            TableRepository.LoadAll(); CollectionAssert.AreEqual(new[]{"fixture","fixture","second"},source.Calls);
            TableRepository.Register(new FixtureIndexed("late"));TableRepository.LoadAll();Assert.AreEqual(3,source.Calls.Count);
            TableRepository.Clear();Assert.IsFalse(TableRepository.loaded);TableRepository.LoadAll();Assert.IsTrue(TableRepository.loaded);Assert.AreEqual(3,source.Calls.Count);
            first.LoadDatas();Assert.AreEqual(4,source.Calls.Count); // explicit table reload is separate from repository one-shot state
        }
        [Test] public async Task RepositoryAsyncProgressAndEmptyAlreadyLoadedRules()
        {
            var progress=new List<float>();TableRepository.Register(new FixtureIndexed());TableRepository.Register(new FixtureIndexed());
            await TableRepository.LoadAllAsync(progress.Add);CollectionAssert.AreEqual(new[]{0f,0.5f,1f},progress);
            progress.Clear();await TableRepository.LoadAllAsync(progress.Add);CollectionAssert.AreEqual(new[]{1f},progress);
            TableRepository.Clear();progress.Clear();await TableRepository.LoadAllAsync(progress.Add);CollectionAssert.AreEqual(new[]{1f},progress);
        }
        [Test] public void LoadFailureKeepsRepositoryUnloadedAndTheCurrentRows()
        {
            var table=new FixtureIndexed();table.LoadDatas();TableRepository.Register(table);source.Failure=new IOException("fixture failure");
            Assert.Throws<IOException>(()=>TableRepository.LoadAll());Assert.IsFalse(TableRepository.loaded);Assert.AreEqual(2,table.Datas.Count);
        }
        [Test] public async Task AsyncAndExplicitSourceFailuresPreservePriorDataUntilReadCompletes()
        {
            var table=new FixtureIndexed();table.LoadDatas();source.Failure=new IOException("fixture failure");
            Assert.Throws<IOException>(()=>table.LoadDatas(source));Assert.AreEqual(2,table.Datas.Count);
            try { await table.LoadDatasAsync();Assert.Fail("Expected IOException"); } catch(IOException) { }
            Assert.AreEqual(2,table.Datas.Count);Assert.Throws<ArgumentNullException>(()=>table.LoadDatas(null));
        }
        [Test] public void AdditionalSourcesRejectDuplicateIdsAtomicallyButExplicitBaseOverloadOnlyLoadsPrimary()
        {
            var table=new FixtureIndexed();source.Texts["more"]="id\tkey\n123456003\tc";
            table.AddSource("more",row=>new FixtureRow(row));table.LoadDatas();Assert.AreEqual(3,table.Datas.Count);
            source.Texts["more"]="id\n123456001";Assert.Throws<InvalidDataException>(()=>table.LoadDatas());Assert.AreEqual(3,table.Datas.Count);
            table.LoadDatas(source);Assert.AreEqual(2,table.Datas.Count);
            Assert.Throws<ArgumentException>(()=>table.AddSource("more",row=>new FixtureRow(row)));
            Assert.Throws<ArgumentException>(()=>table.AddSource<FixtureRow>("",null));
        }
        [Test] public async Task AdditionalSourcesAsyncAndCatalogLookup()
        {
            var first=new FixtureIndexed();source.Texts["more"]="id\tkey\n123456003\tc";first.AddSource("more",row=>new FixtureRow(row));
            await first.LoadDatasAsync();var catalog=new TableCatalog<TableData>().Add(()=>first);
            Assert.AreSame(first.Get(123456003),catalog.Get<FixtureRow>(123456003));Assert.AreEqual(3,catalog.Datas.Count());Assert.IsNull(catalog.Get(99));
        }
        sealed class Localization : ITableLocalization
        {
            public bool IsReady {get;set;}=true;
            public string GetString(string collection,string key)=>key=="present"?"translated":key=="empty"?"":null;
        }
        [Test] public void LocalizationTextContractPreservesReadyMissingEmptyAndFallbackSemantics()
        {
            Assert.AreEqual("missing",TableData.GetLoc("name","missing",false));
            var loc=new Localization();TableRuntimeOptions.Localization=loc;
            Assert.AreEqual("translated",TableData.GetLoc("name","present"));Assert.AreEqual("",TableData.GetLoc("name","missing",false));
            Assert.AreEqual("missing",TableData.GetLoc("name","missing"));Assert.AreEqual("",TableData.GetLoc("name","empty"));
            Assert.AreEqual("translated",TableData.GetLocWithFallback("name","missing","present"));
            Assert.AreEqual("missing",TableData.GetLocWithFallback("name","missing","other"));
            loc.IsReady=false;Assert.AreEqual("present",TableData.GetLoc("name","present"));Assert.AreEqual("",TableData.GetLoc("name",null));
        }
        [Test] public void StaticPathMatchesLegacyNormalizationAndAllowsHostOverride()
        {
            Assert.AreEqual(Path.Combine(Application.persistentDataPath,"Assets","Table","x.txt"),TableUtil.GetTablePath("folder/x"));
            StringAssert.EndsWith("x.TXT",TableUtil.GetTablePath("x.TXT"));
            TableRuntimeOptions.StaticTablePath=_=>"host-location";Assert.AreEqual("host-location",TableUtil.GetTablePath("x"));
        }
        [Test] public void NullDictionaryKeepsOriginalFallbackAndToStringError()
        {
            var row=new TSVRow(null);Assert.IsFalse(row.Contains("x"));Assert.AreEqual(8,row.GetInt("x",8));Assert.Throws<ArgumentNullException>(()=>row.ToString());
        }
        static FixtureRow Checked(TSVRow row)
        {
            var data=new FixtureRow(row);if(data.key=="bad")throw new InvalidDataException("fixture parse failure");return data;
        }
        sealed class CheckedIndexed:IndexedTable<FixtureRow>
        {
            public CheckedIndexed():base("fixture"){}
            protected override FixtureRow ParseJson(TSVRow row)=>Checked(row);
            public void WriteDirectly(FixtureRow row)=>_dict[row.id]=row;
        }
        sealed class CheckedKeyed:KeyedTable<string,FixtureRow>
        {
            public CheckedKeyed():base("fixture"){}
            protected override FixtureRow ParseJson(TSVRow row)=>Checked(row);
            protected override string GetKey(FixtureRow row)=>row.key;
        }
        sealed class CheckedGrouped:GroupedTable<int,FixtureRow>
        {
            public CheckedGrouped():base("fixture"){}
            protected override FixtureRow ParseJson(TSVRow row)=>Checked(row);
            protected override int GetKey(FixtureRow row)=>row.group;
        }
        sealed class CheckedList:ListTable<FixtureRow>
        {
            public CheckedList():base("fixture"){}
            protected override FixtureRow ParseJson(TSVRow row)=>Checked(row);
        }
        sealed class DirectTable:TableBase
        {
            public readonly List<string> Rows=new();
            public override Type RowType=>typeof(FixtureRow);
            public DirectTable():base("fixture"){}
            protected override void _DataClear()=>Rows.Clear();
            protected override void InsertData(List<TSVRow> datas){foreach(var row in datas)Rows.Add(Checked(row).key);}
        }
        async Task ExpectFailedReloadsKeepRows(TableBase table,Func<IEnumerable<int>> ids)
        {
            table.LoadDatas();var before=ids().ToArray();CollectionAssert.AreEqual(new[]{123456001,123456002},before);
            string good=source.Texts["fixture"];source.Texts["fixture"]="id\tkey\tgroup\n1\tfirst\t7\n2\tbad\t7";
            Assert.Throws<InvalidDataException>(()=>table.LoadDatas());CollectionAssert.AreEqual(before,ids());
            Assert.Throws<InvalidDataException>(()=>table.LoadDatas(source));CollectionAssert.AreEqual(before,ids());
            try{await table.LoadDatasAsync();Assert.Fail("Expected InvalidDataException");}catch(InvalidDataException){}
            CollectionAssert.AreEqual(before,ids());
            source.Texts["fixture"]=good;table.LoadDatas();CollectionAssert.AreEqual(before,ids());
        }
        [Test] public async Task IndexedParseFailureKeepsPreviousRowsOnEveryReloadPath()
        {
            var table=new CheckedIndexed();await ExpectFailedReloadsKeepRows(table,()=>table.Datas.Select(row=>row.id));
        }
        [Test] public async Task KeyedParseFailureKeepsPreviousRowsOnEveryReloadPath()
        {
            var table=new CheckedKeyed();await ExpectFailedReloadsKeepRows(table,()=>table.Datas.Select(row=>row.id));
        }
        [Test] public async Task GroupedParseFailureKeepsPreviousRowsOnEveryReloadPath()
        {
            var table=new CheckedGrouped();await ExpectFailedReloadsKeepRows(table,()=>table.Dict.Values.SelectMany(rows=>rows).Select(row=>row.id));
        }
        [Test] public async Task ListParseFailureKeepsPreviousRowsOnEveryReloadPath()
        {
            var table=new CheckedList();await ExpectFailedReloadsKeepRows(table,()=>table.Datas.Select(row=>row.id));
        }
        [Test] public void TableWithoutCaptureHookLeavesNoPartialRowsAfterParseFailure()
        {
            var table=new DirectTable();table.LoadDatas();source.Texts["fixture"]="id\tkey\n1\tfirst\n2\tbad";
            Assert.Throws<InvalidDataException>(()=>table.LoadDatas(source));Assert.IsEmpty(table.Rows);
        }
        [Test] public void DatasIsAStableReadOnlyViewThatFollowsReloads()
        {
            var indexed=new FixtureIndexed();indexed.LoadDatas();var keyed=new FixtureKeyed();keyed.LoadDatas();
            var indexedView=indexed.Datas;var keyedView=keyed.Datas;
            Assert.AreSame(indexedView,indexed.Datas);Assert.AreSame(keyedView,keyed.Datas);
            Assert.IsNotInstanceOf<IList<FixtureRow>>(indexedView);Assert.IsNotInstanceOf<IList<FixtureRow>>(keyedView);
            CollectionAssert.AreEqual(new[]{123456001,123456002},indexedView.Select(row=>row.id));Assert.AreEqual(123456002,keyedView[1].id);
            Assert.Throws<ArgumentOutOfRangeException>(()=>_=indexedView[2]);Assert.Throws<ArgumentOutOfRangeException>(()=>_=keyedView[-1]);
            source.Texts["fixture"]="id\tkey\n123456001\tchanged\n123456002\tb";indexed.LoadDatas();keyed.LoadDatas();
            Assert.AreEqual("changed",indexedView[0].key);Assert.AreEqual("changed",keyedView[0].key);
            source.Texts["fixture"]="id\tkey\n7\tonly";indexed.LoadDatas(source);Assert.AreEqual(1,indexedView.Count);Assert.AreEqual(7,indexedView[0].id);
        }
        [Test] public void ReloadDuringDatasEnumerationKeepsTheEnumerationValid()
        {
            var table=new FixtureIndexed();table.LoadDatas();int visited=0;
            foreach(var row in table.Datas){visited++;table.LoadDatas();}
            Assert.AreEqual(2,visited);
        }
        [Test] public void DatasNoticesRowsDerivedTablesWriteDirectly()
        {
            var table=new CheckedIndexed();table.LoadDatas();Assert.AreEqual(2,table.Datas.Count);
            table.WriteDirectly(new FixtureRow(Row("id\tkey\n123456003\tc")));
            CollectionAssert.AreEqual(new[]{123456001,123456002,123456003},table.Datas.Select(row=>row.id));
        }
        [Test] public void IntegerListsIgnoreTheCurrentCulture()
        {
            var row=Row("values\n-1/2/~3");var culture=(CultureInfo)CultureInfo.InvariantCulture.Clone();culture.NumberFormat.NegativeSign="~";
            var previous=CultureInfo.CurrentCulture;
            try
            {
                CultureInfo.CurrentCulture=culture;
                CollectionAssert.AreEqual(new[]{-1,2,0},row.GetIntList("values"));CollectionAssert.AreEqual(new long[]{-1,2,0},row.GetLongList("values"));
            }
            finally{CultureInfo.CurrentCulture=previous;}
        }
        [Test] public void SessionResetForgetsRegistrationsAndTheLoadedFlag()
        {
            TableRepository.Register(new FixtureIndexed());TableRepository.LoadAll();Assert.IsTrue(TableRepository.loaded);Assert.AreEqual(1,source.Calls.Count);
            typeof(TableRepository).GetMethod("ResetSession",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic).Invoke(null,null);
            Assert.IsFalse(TableRepository.loaded);TableRepository.LoadAll();Assert.AreEqual(1,source.Calls.Count);
        }
        [Test] public void MissingRequiredValuesAndForeignKeysAreNotAutomaticallyValidated()
        {
            source.Texts["fixture"]="id\tkey\tlink\ninvalid\t\t999999";var table=new FixtureIndexed();table.LoadDatas();
            Assert.AreEqual(9999,table.Datas[0].id);Assert.AreEqual("",table.Datas[0].key);Assert.IsNull(table.Get(table.Datas[0].link));
        }
    }
}
