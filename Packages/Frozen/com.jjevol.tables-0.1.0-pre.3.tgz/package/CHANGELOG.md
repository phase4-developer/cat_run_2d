# Changelog

## 0.1.0-pre.3 - 2026-11-10

- Breaking: `TSVRow` finds columns by header name ignoring case and surrounding spaces (and a leading BOM). `Get("id")` now reads a column headed `ID`, ` id ` or `Id`. Column order never mattered and still does not.
- Breaking: a column without a header name is ignored, and when two headers have the same name the first column wins (it was the last).
- Breaking: a row whose cells are all empty or spaces, as a spreadsheet copy leaves below its data, is skipped.
- A missing column still reads as the getter default. New `TSVRow.NormalizeHeader` exposes the name rule.

Unity 6000.3.9f1 on `Hosts/CombinedValidationHost`, candidate `0007c0f`: EditMode jobs `tm1110-comb-edit-tbl1-03` 208/208 (with compile) and `tm1110-comb-edit-tbl2-02` 72/72 passed; PlayMode `tm1110-comb-play-tbl-02` 7/7 passed (candidate `e7e91cc`, PlayMode tests unchanged since). Covers `TableCoreTests` and `TableLoadingTests`.

## 0.1.0-pre.2 - 2026-11-06

- A failed reload read or parse leaves the previous rows. Added `CaptureData` and `RestoreData`.
- Integer lists parse with InvariantCulture. Keyed and Indexed `Datas` are read-only views.
- Reset `TableRepository` when Domain Reload is disabled.

Unity tests for this candidate are NOT_RUN.

# 0.1.0-pre.1 — 2026-10-31

Local extraction candidate of existing table containers, repository and TSV parser. GameTableSource configuration and Host-owned string localization/decryption/path contracts separate Common backend dependencies. Resources async loading uses the built-in completion event instead of UniTask. Fixed reproduced worker-thread Resources fallback in LoadStaticTableAsync. Typed Localization entry API and Firebase ServerTableSource remain outside active Core; full mobile feature transfer is PARTIAL. No publication/snapshot/game migration.
