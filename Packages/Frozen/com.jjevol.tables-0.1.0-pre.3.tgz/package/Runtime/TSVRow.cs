using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

public class TSVRow
{
    private Dictionary<string, string> mData;

    // Columns are found by header name, never by position. Names ignore case and surrounding spaces.
    public TSVRow(Dictionary<string, string> data)
    {
        if (data == null) return;
        mData = new Dictionary<string, string>(data.Count, StringComparer.OrdinalIgnoreCase);
        foreach (var pair in data)
        {
            string name = NormalizeHeader(pair.Key);
            if (name.Length != 0 && !mData.ContainsKey(name)) mData.Add(name, pair.Value);
        }
    }

    /// <summary>Header text as columns are matched: BOM and surrounding white space removed.</summary>
    public static string NormalizeHeader(string header) => header == null ? string.Empty : header.Trim().Trim('\uFEFF').Trim();

    public static List<TSVRow> FromTsv(string tsvText)
    {
        var list = new List<TSVRow>();
        if (string.IsNullOrEmpty(tsvText)) return list;

        var lines = tsvText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        if (lines.Length < 2) return list;

        var headers = lines[0].Split('\t').Select(NormalizeHeader).ToArray();

        for (int i = 1; i < lines.Length; i++)
        {
            var fields = lines[i].Split('\t');
            // A row of empty cells, as a copied spreadsheet leaves below its data, is not a record.
            if (fields.All(f => f.Trim().Length == 0)) continue;
            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (int j = 0; j < headers.Length && j < fields.Length; j++)
            {
                // An unnamed column is ignored. With a repeated name the first column wins.
                if (headers[j].Length != 0 && !row.ContainsKey(headers[j])) row.Add(headers[j], fields[j]);
            }
            list.Add(new TSVRow(row));
        }

        return list;
    }

    public bool Contains(string name)
    {
        return mData != null && mData.ContainsKey(name);
    }

    public string Get(string name)
    {
        return mData != null && mData.TryGetValue(name, out var value) ? value : null;
    }

    private T GetValue<T>(string name, T defaultValue = default)
    {
        var value = Get(name);
        if (string.IsNullOrEmpty(value)) return defaultValue;

        try
        {
            if (typeof(T).IsEnum)
                return (T)Enum.Parse(typeof(T), value, true);

            return (T)Convert.ChangeType(value, typeof(T), CultureInfo.InvariantCulture);
        }
        catch
        {
            return defaultValue;
        }
    }

    public int GetInt(string name, int defaultValue = 0) => GetValue<int>(name, defaultValue);
    public float GetFloat(string name, float defaultValue = 0f) => GetValue<float>(name, defaultValue);
    public double GetDouble(string name, double defaultValue = 0d) => GetValue<double>(name, defaultValue);
    public bool GetBoolean(string name, bool defaultValue = false) => GetValue<bool>(name, defaultValue);
    public long GetLong(string name, long defaultValue = 0L) => GetValue<long>(name, defaultValue);
    public string GetString(string name, string defaultValue = "") => GetValue<string>(name, defaultValue);
    public decimal GetDecimal(string name, decimal defaultValue = 0L) => GetValue<decimal>(name, defaultValue);

    public DateTime GetDateTime(string name, DateTime defaultValue = default)
    {
        var dateTimeStr = GetString(name);

        if (!string.IsNullOrEmpty(dateTimeStr) && TryParseUtc(dateTimeStr, out var dt))
            return dt;

        return defaultValue;
    }

    // Identical date parsing rules from Timef.TryParseUtc; no clock/AntiCheat dependency.
    private static bool TryParseUtc(string value, out DateTime result)
    {
        const DateTimeStyles styles = DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal;
        return DateTime.TryParse(value, CultureInfo.InvariantCulture, styles, out result) || DateTime.TryParseExact(value, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, styles, out result);
    }


    public List<string> GetStringList(string name, char separator = '/')
    {
        var value = Get(name);
        return string.IsNullOrEmpty(value) ? new List<string>() :
            value.Split(separator).Select(s => s.Trim()).ToList();
    }

    public List<int> GetIntList(string name, char separator = '/')
    {
        return GetStringList(name, separator)
            .Select(s => int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : 0).ToList();
    }

    public List<long> GetLongList(string name, char separator = '/')
    {
        return GetStringList(name, separator)
            .Select(s => long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : 0L).ToList();
    }

    public List<float> GetFloatList(string name, char separator = '/')
    {
        return GetStringList(name, separator)
            .Select(s => float.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : 0f).ToList();
    }

    public List<double> GetDoubleList(string name, char separator = '/')
    {
        return GetStringList(name, separator)
            .Select(s => double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : 0d).ToList();
    }

    public List<bool> GetBooleanList(string name, char separator = '/')
    {
        return GetStringList(name, separator)
            .Select(s => bool.TryParse(s, out var v) && v).ToList();
    }

    public override string ToString()
    {
        return string.Join(", ", mData.Select(kvp => $"{kvp.Key}: {kvp.Value}"));
    }
}
