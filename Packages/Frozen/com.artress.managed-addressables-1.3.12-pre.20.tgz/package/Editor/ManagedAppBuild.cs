using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using static Artress.ManagedAddressables.Editor.ManagedEditorText;

namespace Artress.ManagedAddressables.Editor
{
    // What one App Build did, step by step. Failed builds keep the steps that ran.
    public sealed class ManagedAppBuildResult
    {
        internal readonly List<string> steps = new List<string>();
        public bool Succeeded { get; internal set; }
        public string OutputPath { get; internal set; }
        public long DeploymentSequence { get; internal set; }
        public string RevisionReceiptPath { get; internal set; }
        public string PackagedRevisionPath { get; internal set; }
        public string Error { get; internal set; }
        public IReadOnlyList<string> Steps => steps.AsReadOnly();

        public override string ToString() =>
            (Succeeded ? L("앱 빌드 완료", "App Build succeeded") : L("앱 빌드 실패", "App Build failed")) + "\n" +
            string.Join("\n", steps) + (string.IsNullOrEmpty(Error) ? string.Empty : "\n\n" + Error);
    }

    // One button from the current project to a Player: sync registration, choose the deployment
    // sequence, build Revision, reload the Config, link the app included Revision A, build the Player.
    // The individual steps stay internal; the Control Center's Advanced section runs them one by one.
    public static class ManagedAppBuild
    {
        internal const string OutputArgument = "-managedAppOutput";
        internal const string DevelopmentArgument = "-managedAppDevelopment";
        internal const string AndroidProjectRoot = "Library/Bee/Android/Prj";
        internal const string AndroidPlayerDataPath = "Gradle/unityLibrary/src/main/assets/bin/Data";
        private const int StepCount = 6;

        private sealed class StepFailure : Exception
        {
            public StepFailure(string message) : base(message) { }
        }

        // Builds the active build target. Does not quit Unity.
        public static ManagedAppBuildResult Build(string outputPath, bool development) =>
            Build(ManagedAddressableBuildExporter.LoadConfig(), outputPath, development, BuildPlayer);

        // Tests replace only the Player step; every step before it is the real one.
        internal static ManagedAppBuildResult Build(ManagedAddressableProjectConfig config, string outputPath, bool development, Func<string, bool, string> buildPlayer)
        {
            var result = new ManagedAppBuildResult { OutputPath = string.IsNullOrWhiteSpace(outputPath) ? outputPath : Path.GetFullPath(outputPath) };
            int step = 0;
            string name = L("준비 확인", "Readiness");
            // A development build saves its raised number before the bake reads it. When a later step
            // fails, the saved number goes back; a Revision already baked still counts as the previous one.
            long? savedBefore = null;
            string configPath = null;
            try
            {
                RequireReady(config, result.OutputPath, development);
                configPath = AssetDatabase.GetAssetPath(config);
                AssetDatabase.SaveAssetIfDirty(config);
                result.steps.Add("0/" + StepCount + " " + name + ": " + L("통과", "passed") + " (" + EditorUserBuildSettings.activeBuildTarget + ", " +
                    (development ? L("개발 빌드", "development build") : L("출시 빌드", "release build")) + ")");

                step = 1; name = L("등록 동기화", "Registration sync");
                var sync = ManagedAddressableSynchronizer.CreatePlan(config);
                if (!sync.CanApply) throw new StepFailure(L("등록 계획에 막힌 변경이 있습니다. 고급 > 콘텐츠 등록에서 확인하세요.\n", "The registration plan has blocked changes. Check Advanced > Content registration.\n") + string.Join("\n", sync.BlockedChanges));
                // A file left out by an address conflict would be missing from the app, so the app build stops here.
                if (sync.Errors.Count != 0) throw new StepFailure(L("같은 주소가 되는 파일이 있습니다. 파일 이름을 바꾼 뒤 다시 빌드하세요.\n", "Some files would get the same address. Rename them and build again.\n") + string.Join("\n", sync.Errors));
                if (sync.HasChanges)
                {
                    ManagedAddressableSynchronizer.ApplyPlan(config, sync);
                    config = ManagedAddressableBuildExporter.ReloadSplitConfigAfterSdk(configPath);
                }
                var invalid = ManagedAddressableValidator.Validate(config);
                if (invalid.Count != 0) throw new StepFailure(L("등록 검사 실패:\n", "Registration check failed:\n") + string.Join("\n", invalid));
                result.steps.Add(Line(step, name, sync.HasChanges ? L("변경 ", "changes: ") + sync.Changes.Count + L("건 적용", " applied") : L("변경 없음", "no changes")));
                foreach (var change in sync.Changes) result.steps.Add("    " + change);

                step = 2; name = L("배포 순번", "Deployment sequence");
                var release = ManagedLocalRelease.Effective(config);
                long previous = ManagedAddressableBuildExporter.PreviousDeploymentSequence(config, release);
                long sequence = ChooseDeploymentSequence(release.deploymentSequence, previous, development);
                if (sequence != release.deploymentSequence)
                {
                    var local = ManagedLocalRelease.Read(config);
                    savedBefore = local.deploymentSequence;
                    local.deploymentSequence = sequence;
                    ManagedLocalRelease.Write(config, local);
                }
                result.DeploymentSequence = sequence;
                result.steps.Add(Line(step, name, sequence + (sequence != release.deploymentSequence ? L(" (자동으로 올림, 직전 ", " (raised automatically, previous ") + Math.Max(release.deploymentSequence, previous) + ")" : string.Empty)));

                step = 3; name = L("Revision 굽기", "Revision build");
                var prebuild = ManagedAddressableBuildExporter.ValidateRevisionReleasePrebuild(config);
                if (!prebuild.CanBuild) throw new StepFailure(prebuild.ToString());
                var plan = ManagedAddressableBuildExporter.CreateSplitBuildPlan(config, ManagedGroupBuildRole.Revision);
                if (!plan.CanBuild) throw new StepFailure(plan.Report.ToString());
                var revision = ManagedAddressableBuildExporter.BuildReviewedSplitContent(config, plan);
                if (!revision.success) throw new StepFailure(revision.error);
                result.RevisionReceiptPath = revision.splitReceiptPath;
                result.steps.Add(Line(step, name, revision.splitReceiptPath));

                step = 4; name = L("Config 다시 읽기·저장", "Config reload and save");
                // The SDK build can unload the Config and leave the reloaded object dirty;
                // the app included A only accepts a clean saved Config.
                config = ManagedAddressableBuildExporter.ReloadSplitConfigAfterSdk(configPath);
                AssetDatabase.SaveAssetIfDirty(config);
                if (EditorUtility.IsDirty(config)) throw new StepFailure(L("Revision 굽기 뒤 Config를 저장하지 못했습니다: ", "The Config could not be saved after the Revision build: ") + configPath);
                string built = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(revision.splitReceiptPath))?.contentFingerprint;
                string now = ManagedAddressableBuildExporter.SplitContentFingerprint(config, ManagedAddressableSynchronizer.ReadSettingsWithoutMigration());
                if (built != now)
                    throw new StepFailure(L("Revision 굽기 뒤 콘텐츠 지문이 바뀌었습니다. Player의 Boot와 짝이 맞지 않으므로 멈춥니다. 영수증 ", "The content fingerprint changed after the Revision build, so it would not pair with the Player's Boot. Receipt ") + built + L(", 현재 ", ", now ") + now);
                result.steps.Add(Line(step, name, L("저장됨", "saved")));

                step = 5; name = L("앱 포함 A 적용", "App included A");
                var packaged = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, revision.splitReceiptPath, ManagedLocalRelease.Effective(config), null);
                if (!packaged.CanApply) throw new StepFailure(packaged.ToString());
                result.PackagedRevisionPath = ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, packaged);
                result.steps.Add(Line(step, name, result.PackagedRevisionPath));

                step = 6; name = L("Player 빌드", "Player build");
                result.steps.Add(Line(step, name, buildPlayer(result.OutputPath, development)));
                result.Succeeded = true;
            }
            catch (Exception error)
            {
                string message = error is StepFailure ? error.Message : error.ToString();
                result.steps.Add(Line(step, name, L("실패", "failed")));
                result.Error = message;
                if (savedBefore.HasValue) RestoreSequence(configPath, result, savedBefore.Value);
            }
            return result;
        }

        private static void RestoreSequence(string configPath, ManagedAppBuildResult result, long savedBefore)
        {
            try
            {
                // The SDK build can unload the Config object this build started with, so read it again by path.
                var config = ManagedAddressableBuildExporter.ReloadSplitConfigAfterSdk(configPath);
                var local = ManagedLocalRelease.Read(config);
                if (local.deploymentSequence != result.DeploymentSequence)
                {
                    result.steps.Add("    " + L("저장된 배포 순번이 ", "the saved deployment sequence is ") + local.deploymentSequence + L("로 바뀌어 있어 되돌리지 않음", " now, so it was left as it is"));
                    return;
                }
                local.deploymentSequence = savedBefore;
                ManagedLocalRelease.Write(config, local);
                result.steps.Add("    " + L("저장된 배포 순번을 ", "saved deployment sequence restored to ") + savedBefore + L("로 되돌림", string.Empty));
            }
            catch (Exception error)
            {
                result.steps.Add("    " + L("배포 순번을 되돌리지 못함: ", "could not restore the deployment sequence: ") + error.Message);
            }
        }

        // -executeMethod Artress.ManagedAddressables.Editor.ManagedAppBuild.BuildFromCommandLine
        //   -managedAppOutput <path>   (otherwise the Build Settings location of the active target)
        //   -managedAppDevelopment     (otherwise a release build)
        // In batch mode Unity exits with 0 on success and 1 on failure.
        public static void BuildFromCommandLine()
        {
            var (output, development) = ParseCommandLine(Environment.GetCommandLineArgs());
            if (string.IsNullOrWhiteSpace(output)) output = EditorUserBuildSettings.GetBuildLocation(EditorUserBuildSettings.activeBuildTarget);
            DateTime started = DateTime.Now;
            ManagedAppBuildResult result;
            try { result = Build(output, development); }
            finally
            {
                // Android leaves Unity's own Gradle daemon running, which keeps a batch run alive.
                if (Application.isBatchMode && EditorUserBuildSettings.activeBuildTarget == BuildTarget.Android)
                    foreach (string line in StopGradleDaemonsStartedAfter(started)) Debug.Log("[ManagedAppBuild] " + line);
            }
            if (result.Succeeded) Debug.Log("[ManagedAppBuild] " + result);
            else Debug.LogError("[ManagedAppBuild] " + result);
            if (Application.isBatchMode) EditorApplication.Exit(result.Succeeded ? 0 : 1);
        }

        internal static (string output, bool development) ParseCommandLine(IReadOnlyList<string> args)
        {
            string output = null;
            bool development = false;
            for (int i = 0; i < (args?.Count ?? 0); i++)
            {
                if (string.Equals(args[i], OutputArgument, StringComparison.OrdinalIgnoreCase) && i + 1 < args.Count) output = args[++i];
                else if (string.Equals(args[i], DevelopmentArgument, StringComparison.OrdinalIgnoreCase)) development = true;
            }
            return (output, development);
        }

        // Development builds take the next number themselves. A release build uses the number the
        // deployment authority gave, and an equal or lower number would make two different A's
        // ambiguous on a device (AmbiguousEqualDeploymentSequence), so it blocks.
        internal static long ChooseDeploymentSequence(long current, long previous, bool development)
        {
            if (development) return Math.Max(current, previous) + 1;
            if (current <= 0)
                throw new StepFailure(L("출시 빌드는 배포 순번을 자동으로 정하지 않습니다. 고급 > 배포 값에서 양수 순번을 저장하세요.",
                    "A release build never picks the deployment sequence. Save a positive sequence in Advanced > Release values."));
            if (current <= previous)
                throw new StepFailure(string.Format(L("배포 순번 {0}이 이전 Revision의 {1}보다 크지 않습니다. 같은 순번으로 내용이 다른 앱을 설치하면 기기에서 열리지 않습니다. 고급 > 배포 값에서 더 큰 순번을 저장하세요.",
                    "Deployment sequence {0} is not above the previous Revision's {1}. A different app with the same sequence does not open on a device. Save a larger sequence in Advanced > Release values."), current, previous));
            return current;
        }

        // What is missing before the button can run. Empty means ready. development null skips the
        // checks that depend on the build kind.
        internal static List<string> Readiness(ManagedAddressableProjectConfig config, bool? development = null)
        {
            var problems = new List<string>();
            if (config == null) { problems.Add(L("설정 에셋이 없습니다. 설정 만들기를 누르세요.", "No Project Config. Use Create Config.")); return problems; }
            if (string.IsNullOrEmpty(AssetDatabase.GetAssetPath(config))) problems.Add(L("설정 에셋이 저장되지 않았습니다.", "The Project Config is not saved as an asset."));
            if ((config.groupBuildRoles ?? new List<ManagedGroupBuildRoleSetting>()).All(role => role == null))
                problems.Add(L("빌드 역할이 없습니다. 고급 > 빌드 역할에서 정하세요.", "No build roles. Set them in Advanced > Build roles."));
            if ((config.requiredBootKeys ?? new List<string>()).All(string.IsNullOrWhiteSpace))
                problems.Add(L("필수 Boot 키가 없습니다. 고급 > 빌드 역할에서 정하세요.", "No required Boot key. Set one in Advanced > Build roles."));
            var shared = config.revisionShared ?? new ManagedRevisionSharedRelease();
            if (new[] { shared.productId, shared.authorityId, shared.compatibilityFamily }.Any(string.IsNullOrWhiteSpace))
                problems.Add(L("배포 공유 값(Product ID, Deployment authority, Compatibility family)이 없습니다. 고급 > 배포 값에서 저장하세요.",
                    "Shared release values (Product ID, Deployment authority, Compatibility family) are missing. Save them in Advanced > Release values."));
            try
            {
                if (string.IsNullOrWhiteSpace(ManagedLocalRelease.Read(config).channel))
                    problems.Add(L("이 PC의 Channel이 없습니다. 고급 > 배포 값에서 저장하세요.", "This PC has no Channel. Save one in Advanced > Release values."));
            }
            catch (Exception error) { problems.Add(error.Message); }
            if (ManagedAddressableBuildExporter.HasPendingSplitSettings || File.Exists(ManagedAddressableBuildExporter.PendingPlayerPath))
                problems.Add(L("중단된 빌드 기록이 남아 있습니다. 고급 > 중단 복구에서 복원하세요.", "An interrupted build left records. Restore them in Advanced > Interrupted build recovery."));
            if (!EditorBuildSettings.scenes.Any(scene => scene.enabled))
                problems.Add(L("Build Settings에 켜진 Scene이 없습니다.", "No enabled Scene in Build Settings."));
            if (development == false && config.allowDevelopmentHttp)
                problems.Add(ManagedAddressableBuildExporter.DevelopmentHttpInReleaseMessage());
            return problems;
        }

        private static void RequireReady(ManagedAddressableProjectConfig config, string outputPath, bool development)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating || BuildPipeline.isBuildingPlayer || ManagedAddressableBuildExporter.BuildInProgress)
                throw new StepFailure(L("Play, 컴파일, 가져오기, 다른 빌드 중에는 앱 빌드를 시작하지 않습니다.", "App Build does not start during Play, compilation, import or another build."));
            var problems = Readiness(config, development);
            if (string.IsNullOrWhiteSpace(outputPath))
                problems.Add(L("출력 경로가 없습니다.", "No output path."));
            else
            {
                string assets = Path.GetFullPath("Assets").TrimEnd('/', '\\') + Path.DirectorySeparatorChar;
                if ((Path.GetFullPath(outputPath) + Path.DirectorySeparatorChar).StartsWith(assets, StringComparison.OrdinalIgnoreCase))
                    problems.Add(L("출력 경로가 Assets 안에 있습니다: ", "The output path is inside Assets: ") + outputPath);
            }
            if (problems.Count != 0) throw new StepFailure(string.Join("\n", problems));
        }

        private static string BuildPlayer(string outputPath, bool development)
        {
            BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
            var notes = new List<string>();
            if (target == BuildTarget.Android)
                foreach (string cleared in ClearAndroidPlayerData(Path.GetFullPath(".")))
                    notes.Add(L("이전 Player 데이터 비움: ", "cleared previous Player data: ") + cleared);
            string parent = Path.GetDirectoryName(outputPath);
            if (!string.IsNullOrEmpty(parent)) Directory.CreateDirectory(parent);
            AssetDatabase.SaveAssets();
            DateTime started = DateTime.UtcNow;
            BuildReport report;
            try
            {
                // LZ4 always: a fresh data.unity3d replaces any older one in every target.
                report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
                {
                    scenes = EditorBuildSettings.scenes.Where(scene => scene.enabled).Select(scene => scene.path).ToArray(),
                    locationPathName = outputPath,
                    target = target,
                    targetGroup = BuildPipeline.GetBuildTargetGroup(target),
                    options = (development ? BuildOptions.Development : BuildOptions.None) | BuildOptions.CompressWithLz4
                });
            }
            finally
            {
                // The packaging scope restores its SDK link.xml when the Editor goes idle. Do it now so
                // a script that quits right after this call never leaves it behind.
                ManagedAddressableBuildExporter.RestoreInterruptedPlayerBuildMetadata();
            }
            if (report.summary.result != BuildResult.Succeeded)
                throw new StepFailure(L("Player 빌드 실패: ", "Player build failed: ") + report.summary.result + "\n" +
                    string.Join("\n", report.steps.SelectMany(s => s.messages).Where(m => m.type == LogType.Error || m.type == LogType.Exception).Select(m => m.content).Take(20)));
            var stale = StalePlayerData(target, outputPath, started, Path.GetFullPath("."));
            if (stale == null) notes.Add(L("이전 Player 데이터 검사: 이 플랫폼은 하지 않음", "previous Player data check: not done for this target"));
            else if (stale.Count != 0)
                throw new StepFailure(L("빌드 결과에 이번 빌드보다 오래된 Player 데이터가 남아 있습니다. 출력 폴더를 비우고 다시 빌드하세요.\n", "The build output still holds Player data older than this build. Empty the output folder and build again.\n") + string.Join("\n", stale));
            return outputPath + (notes.Count == 0 ? string.Empty : "\n    " + string.Join("\n    ", notes));
        }

        internal static IEnumerable<string> AndroidPlayerDataFolders(string projectRoot)
        {
            string root = Path.Combine(projectRoot, AndroidProjectRoot);
            return Directory.Exists(root)
                ? Directory.GetDirectories(root).Select(backend => Path.Combine(backend, AndroidPlayerDataPath)).Where(Directory.Exists).ToList()
                : new List<string>();
        }

        // Unity rewrites this Gradle project in Library on every build but leaves files it no
        // longer writes, such as data.unity3d from an earlier compressed build, which the Player
        // then reads before this build's files. It is cache, rebuilt by the next Player build.
        internal static List<string> ClearAndroidPlayerData(string projectRoot)
        {
            var cleared = AndroidPlayerDataFolders(projectRoot).ToList();
            foreach (string folder in cleared) Directory.Delete(folder, true);
            return cleared;
        }

        // The Player data folder of an output, or null when this target is not checked.
        internal static string PlayerDataFolder(BuildTarget target, string outputPath)
        {
            switch (target)
            {
                case BuildTarget.StandaloneWindows:
                case BuildTarget.StandaloneWindows64:
                case BuildTarget.StandaloneLinux64:
                    return Path.Combine(Path.GetDirectoryName(outputPath) ?? string.Empty, Path.GetFileNameWithoutExtension(outputPath) + "_Data");
                case BuildTarget.StandaloneOSX:
                    return Path.Combine(outputPath, "Contents", "Resources", "Data");
                case BuildTarget.iOS:
                    return Path.Combine(outputPath, "Data");
                default:
                    return null;
            }
        }

        // data.unity3d older than this build means the Player would read an earlier build's data.
        // Returns null when the target is not checked.
        internal static List<string> StalePlayerData(BuildTarget target, string outputPath, DateTime buildStartedUtc, string projectRoot)
        {
            IEnumerable<string> folders = target == BuildTarget.Android
                ? AndroidPlayerDataFolders(projectRoot)
                : (PlayerDataFolder(target, outputPath) is string folder ? new[] { folder } : null);
            if (folders == null) return null;
            // File times can be a little coarser than the clock.
            DateTime limit = buildStartedUtc.AddSeconds(-2);
            return folders.Select(folder => Path.Combine(folder, "data.unity3d"))
                .Where(file => File.Exists(file) && File.GetLastWriteTimeUtc(file) < limit).ToList();
        }

        // Only java processes from this Unity's bundled OpenJDK that started after the build began.
        // Another Editor of the same Unity version building Android at the same time would match too;
        // the batch entry is meant for a machine slot that runs one Editor.
        private static IEnumerable<string> StopGradleDaemonsStartedAfter(DateTime startedLocal)
        {
            var lines = new List<string>();
            // The Android playback engine sits beside Unity.app on macOS, not inside its Contents.
            string jdk = Path.GetFullPath(Path.Combine(BuildPipeline.GetPlaybackEngineDirectory(BuildTarget.Android, BuildOptions.None), "OpenJDK"));
            foreach (var process in System.Diagnostics.Process.GetProcessesByName("java"))
            {
                try
                {
                    if (process.StartTime < startedLocal || !process.MainModule.FileName.StartsWith(jdk, StringComparison.OrdinalIgnoreCase)) continue;
                    process.Kill();
                    process.WaitForExit(10000);
                    lines.Add("Gradle daemon stopped: " + process.Id);
                }
                catch (Exception error) { lines.Add("java process check failed: " + error.Message); }
                finally { process.Dispose(); }
            }
            return lines;
        }

        private static string Line(int step, string name, string detail) => step + "/" + StepCount + " " + name + ": " + detail;
    }
}
