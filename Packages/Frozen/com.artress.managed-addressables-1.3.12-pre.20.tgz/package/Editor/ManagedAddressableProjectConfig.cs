using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    public enum ManagedDeliveryMode
    {
        Local,
        Remote
    }

    public enum ManagedGroupStrategy
    {
        SingleGroup = 0,
        FirstSubfolder = 1,
        FolderDepth = 2,
        PreserveExistingGroup = 3,
        ReservedFolder = 4
    }

    // FileName: the address is the file name without its extension; sub folders only organise files.
    // Path: the older rule that joins the folders under the category (pathSeparator, ignorePathPrefixes, ensureUnique).
    public enum ManagedAddressNamingMode
    {
        FileName = 0,
        Path = 1
    }

    [Serializable]
    public sealed class ManagedCategoryRule
    {
        public string relativePath;
        public ManagedDeliveryMode delivery;
        public ManagedGroupStrategy groupStrategy = ManagedGroupStrategy.ReservedFolder;
        public int folderDepth = 1;
        public string groupNamePattern;
        public BundledAssetGroupSchema.BundlePackingMode bundleMode = BundledAssetGroupSchema.BundlePackingMode.PackTogether;
        public bool enabled = true;
    }

    public sealed class ManagedAddressableProjectConfig : ScriptableObject
    {
        public const string DefaultAssetPath = "Assets/ArtressManagedAddressables/ManagedAddressableProjectConfig.asset";

        [Header("Project")]
        public DefaultAsset contentRootFolder;
        [SerializeField] private string contentRoot = "Assets/Addressables";
        public string buildOutputRoot = "ServerData";
        public string profileName = "Artress Managed";

        [Header("Folder Bundle Rule")]
        public string updateFolderName = "Update";

        [Header("Address Naming")]
        [Tooltip("FileName: 주소는 파일 이름(확장자 제외)이고, 같은 주소가 둘 이상이면 Sync가 겹친 파일을 모두 적은 오류로 알리고 그 파일은 바꾸지 않습니다. Path: 분류 폴더 아래 경로를 구분자로 잇는 이전 규칙입니다.")]
        public ManagedAddressNamingMode addressNaming = ManagedAddressNamingMode.FileName;
        public bool autoRegister = true;
        public bool createGroupIfMissing = true;
        public bool preserveExistingAddressesOnSync = true;
        public bool includeExtension;
        [Tooltip("Path 방식에서만 씁니다.")]
        public bool ensureUnique;
        [Tooltip("Path 방식에서만 씁니다.")]
        public string pathSeparator = "_";
        [Tooltip("Path 방식에서만 씁니다.")]
        public List<string> ignorePathPrefixes = new List<string> { "Texture" };

        [Header("Category Policies")]
        public List<ManagedCategoryRule> categoryRules = new List<ManagedCategoryRule>();

        [Header("Explicit Content Build Roles")]
        public List<ManagedGroupBuildRoleSetting> groupBuildRoles = new List<ManagedGroupBuildRoleSetting>();
        public List<string> requiredBootKeys = new List<string>();

        [Header("Explicit Revision Release (shared)")]
        [Tooltip("팀이 공유하는 Release 값입니다. channel, 순번, 앱 포함 A 연결은 PC마다 UserSettings/ArtressManagedAddressables에 따로 저장합니다.")]
        public ManagedRevisionSharedRelease revisionShared = new ManagedRevisionSharedRelease();
        [Tooltip("Revision URL에 평문 http를 허용합니다. Development Build 전용이며 켠 채로 Release Player를 빌드하면 실패합니다.")]
        public bool allowDevelopmentHttp;

        [Header("Explicit Group Ownership")]
        [Tooltip("명시적으로 채택한 Group asset GUID입니다. 기존 Group은 자동 채택하지 않으며, 삭제된 GUID는 경고와 명시 정리 전까지 보존합니다.")]
        public List<string> ownedGroupGuids = new List<string>();

        internal bool OwnsGroup(AddressableAssetGroup group)
        {
            if (group == null) return false;
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
            return !string.IsNullOrEmpty(guid) && ownedGroupGuids != null && ownedGroupGuids.Exists(value => string.Equals(value, guid, StringComparison.OrdinalIgnoreCase));
        }

        [Header("Advanced")]
        public bool backupBeforeApply = true;
        public string backupRoot = "Library/ArtressManagedAddressablesBackup";

        public string ContentRootPath
        {
            get
            {
                string folderPath = contentRootFolder != null ? AssetDatabase.GetAssetPath(contentRootFolder) : string.Empty;
                if (!string.IsNullOrWhiteSpace(folderPath) && AssetDatabase.IsValidFolder(folderPath))
                    return Normalize(folderPath);
                return Normalize(contentRoot);
            }
        }

        public void SetContentRoot(string assetPath)
        {
            contentRoot = Normalize(assetPath);
            contentRootFolder = AssetDatabase.LoadAssetAtPath<DefaultAsset>(contentRoot);
            EditorUtility.SetDirty(this);
        }

        private void OnEnable()
        {
            ignorePathPrefixes ??= new List<string>();
            categoryRules ??= new List<ManagedCategoryRule>();
            ownedGroupGuids ??= new List<string>();
            groupBuildRoles ??= new List<ManagedGroupBuildRoleSetting>();
            requiredBootKeys ??= new List<string>();
            revisionShared ??= new ManagedRevisionSharedRelease();

            if (contentRootFolder == null && !string.IsNullOrWhiteSpace(contentRoot) && AssetDatabase.IsValidFolder(contentRoot))
                contentRootFolder = AssetDatabase.LoadAssetAtPath<DefaultAsset>(contentRoot);
        }

        private static string Normalize(string value)
        {
            return (value ?? string.Empty).Replace('\\', '/').Trim('/');
        }
    }
}
