using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor
{
    internal static partial class ManagedAddressableSynchronizer
    {
        public static ManagedAddressableSyncReport Sync(ManagedAddressableProjectConfig config, bool dryRun, bool rebuildAddresses = false, IEnumerable<string> forceAddressRebuildAssetPaths = null)
        {
            ManagedAddressableSyncPlan plan = CreatePlan(config, rebuildAddresses, forceAddressRebuildAssetPaths);
            return dryRun ? plan.Report : ApplyPlan(config, plan);
        }

        public static ManagedAddressableSyncPlan CreatePlan(ManagedAddressableProjectConfig config, bool rebuildAddresses = false, IEnumerable<string> forceAddressRebuildAssetPaths = null)
        {
            CheckSyncState(config);
            ValidateSyncPaths(config);
            AddressableAssetSettings settings = AddressableAssetSettingsDefaultObject.Settings;
            string[] paths = Directory.GetFiles(config.ContentRootPath, "*.*", SearchOption.AllDirectories).Select(p => p.Replace('\\', '/')).Where(IsManagedAssetFile).OrderBy(p => p, StringComparer.OrdinalIgnoreCase).ToArray();
            var changes = new List<ManagedAddressableSyncChange>();
            var blocked = new List<string>();
            var additions = new List<ManagedAddressableSyncPlan.GroupAddition>();
            var entryChanges = new List<ManagedAddressableSyncPlan.EntryChange>();
            var report = new ManagedAddressableSyncReport();
            var warnings = OwnershipWarnings(config, settings);
            List<AddressableAssetEntry> entries = settings == null ? new List<AddressableAssetEntry>() : settings.groups.Where(g => g != null).SelectMany(g => g.entries).Where(e => e != null).ToList();
            if (entries.Where(e => !string.IsNullOrEmpty(e.address)).GroupBy(e => e.address, StringComparer.Ordinal).Any(g => g.Select(e => e.guid).Distinct().Count() > 1 && g.Any(e => config.OwnsGroup(e.parentGroup))))
                throw new InvalidOperationException("Duplicate Address already exists; resolve it before Sync.");

            bool createSettings = settings == null;
            if (createSettings)
            {
                PlanInitialSettings(config, changes);
                if (Directory.Exists(AddressableAssetSettingsDefaultObject.kDefaultConfigFolder) && Directory.GetFiles(AddressableAssetSettingsDefaultObject.kDefaultConfigFolder, "*", SearchOption.AllDirectories).Length > 0)
                    blocked.Add("[Global] SDK default Settings folder already contains assets but no Settings is selected. Select the existing Settings through the official tools; Sync will not reinitialize dormant settings.");
            }
            HashSet<string> used = new HashSet<string>(entries.Where(e => !string.IsNullOrEmpty(e.address)).Select(e => e.address), StringComparer.Ordinal);
            HashSet<string> forced = new HashSet<string>((forceAddressRebuildAssetPaths ?? Array.Empty<string>()).Select(Normalize), StringComparer.OrdinalIgnoreCase);
            List<ManagedCategoryRule> rules = config.categoryRules.Where(r => r != null && r.enabled && !string.IsNullOrWhiteSpace(r.relativePath)).OrderByDescending(r => Normalize(r.relativePath).Length).ToList();
            bool fileNameAddresses = config.addressNaming == ManagedAddressNamingMode.FileName;
            // FileName rule: every content file that would get the same address, so one error can name all of them.
            Dictionary<string, List<string>> fileNameOwners = !fileNameAddresses ? null : paths
                .Where(p => p.Substring(config.ContentRootPath.Length).TrimStart('/').Split('/').Length >= 3)
                .GroupBy(p => ManagedAddressNaming.BuildFileNameAddress(p, config.includeExtension), StringComparer.Ordinal)
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
            var errors = new List<string>();
            var reportedConflicts = new HashSet<string>(StringComparer.Ordinal);
            void ReportConflict(string conflictAddress, IEnumerable<string> conflictPaths)
            {
                report.addressConflicts++;
                if (!reportedConflicts.Add(conflictAddress)) return;
                errors.Add("Duplicate Address '" + conflictAddress + "': rename the files so each name is unique. Files that would get this address keep their current state (no registration, move or address change); files listed that already hold it keep it: " + string.Join(", ", conflictPaths.Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(p => p, StringComparer.OrdinalIgnoreCase)));
            }
            // An owned content Entry that really gets a new address in this plan gives its current address up, so it
            // does not hold that address against a file processed before it (path order would otherwise decide).
            // "Really" is a fixed point: an Entry whose own new name conflicts, or whose new address is held by an
            // Entry that keeps it, stays where it is and therefore keeps holding its current address.
            HashSet<string> managedPaths = new HashSet<string>(paths.Where(p => p.Substring(config.ContentRootPath.Length).TrimStart('/').Split('/').Length >= 3), StringComparer.OrdinalIgnoreCase);
            var givingUp = new HashSet<string>(StringComparer.Ordinal);
            if (fileNameAddresses)
            {
                var rebuilt = entries.Where(e => config.OwnsGroup(e.parentGroup) && managedPaths.Contains(e.AssetPath) &&
                    !(!rebuildAddresses && !forced.Contains(Normalize(e.AssetPath)) && config.preserveExistingAddressesOnSync && !string.IsNullOrEmpty(e.address)))
                    .Select(e => (entry: e, next: ManagedAddressNaming.BuildFileNameAddress(e.AssetPath, config.includeExtension)))
                    .Where(x => fileNameOwners.TryGetValue(x.next, out var owners) && owners.Count == 1).ToList();
                givingUp.UnionWith(rebuilt.Select(x => x.entry.guid));
                for (bool changed = true; changed;)
                {
                    changed = false;
                    foreach (var x in rebuilt)
                        if (givingUp.Contains(x.entry.guid) && entries.Any(e => e.guid != x.entry.guid && string.Equals(e.address, x.next, StringComparison.Ordinal) && !givingUp.Contains(e.guid)))
                        {
                            givingUp.Remove(x.entry.guid);
                            changed = true;
                        }
                }
            }
            bool GivesAddressUp(AddressableAssetEntry e) => givingUp.Contains(e.guid);
            foreach (AddressableAssetEntry entry in entries)
            {
                string path = entry.AssetPath;
                if (!config.OwnsGroup(entry.parentGroup) || !Path.GetFileName(path).Equals("LightingData.asset", StringComparison.OrdinalIgnoreCase) || !Normalize(path).StartsWith(Normalize(config.ContentRootPath) + "/", StringComparison.OrdinalIgnoreCase)) continue;
                if (entry.ReadOnly || entry.parentGroup.ReadOnly) throw new InvalidOperationException("Read-only unsupported Entry: " + path);
                entryChanges.Add(new ManagedAddressableSyncPlan.EntryChange(entry.guid, null, null, true));
                changes.Add(new ManagedAddressableSyncChange("Entry", path, "Registration", entry.parentGroup.Name, "removed (unsupported LightingData.asset)"));
                report.removedEntries++;
                report.messages.Add("[Remove Unsupported Entry] " + path);
            }
            foreach (string path in paths)
            {
                string relative = path.Substring(config.ContentRootPath.Length).TrimStart('/');
                string[] parts = relative.Split('/');
                if (parts.Length < 3) continue;
                if (parts[0] != "Local" && parts[0] != "Remote") throw new InvalidOperationException("Unknown delivery folder: " + parts[0]);
                ManagedCategoryRule rule = FindBestRule(rules, relative) ?? CreateDefaultRule(parts[0], parts[1]);
                ManagedAddressablePathResolution resolution = ManagedAddressablePathRules.Resolve(relative, rule, config.updateFolderName);
                if (!resolution.IsValid) throw new InvalidOperationException(resolution.error);
                string guid = AssetDatabase.AssetPathToGUID(path);
                if (string.IsNullOrEmpty(guid)) throw new InvalidOperationException("Import the asset before Sync: " + path);
                // SDK FindAssetEntry materializes settings.currentHash even for a read-only
                // lookup. Use the explicit entries already captured by this Preview instead.
                AddressableAssetEntry entry = entries.FirstOrDefault(candidate => candidate.guid == guid);
                if (entry != null && !config.OwnsGroup(entry.parentGroup))
                {
                    report.preservedAddresses++;
                    warnings.Add("External Entry preserved: " + path + " -> " + entry.parentGroup.Name + ". Adopt its Group explicitly before changing registration or address.");
                    continue;
                }
                bool preserve = entry != null && !rebuildAddresses && !forced.Contains(Normalize(path)) && config.preserveExistingAddressesOnSync && !string.IsNullOrEmpty(entry.address);
                string fileNameAddress = fileNameAddresses && !preserve ? ManagedAddressNaming.BuildFileNameAddress(path, config.includeExtension) : null;
                // Checked before any Group is planned, so a conflicting file never leaves an empty new Group behind.
                // `used` also holds addresses of Entries outside the content root and preserved addresses.
                List<AddressableAssetEntry> holders = fileNameAddress == null ? null : entries.Where(e => e.guid != guid && string.Equals(e.address, fileNameAddress, StringComparison.Ordinal) && !GivesAddressUp(e)).ToList();
                if (fileNameAddress != null && (fileNameOwners[fileNameAddress].Count > 1 || holders.Count > 0))
                {
                    ReportConflict(fileNameAddress, fileNameOwners[fileNameAddress].Concat(holders.Select(e => e.AssetPath)));
                    continue;
                }
                AddressableAssetGroup group = rule.groupStrategy == ManagedGroupStrategy.PreserveExistingGroup && entry != null ? entry.parentGroup : settings == null ? null : FindGroup(settings, resolution.groupName);
                if (group != null && !config.OwnsGroup(group))
                {
                    warnings.Add("External target Group preserved: " + group.Name + ". Registration is not scheduled into that Group until explicit adoption.");
                    if (entry == null) continue;
                    group = entry.parentGroup;
                }
                string groupName = group == null ? resolution.groupName : group.Name;
                if (string.IsNullOrWhiteSpace(groupName) || groupName.IndexOfAny(new[] { '/', '\\' }) >= 0) throw new InvalidOperationException("Group name must be an explicit SDK Group name: " + groupName);
                if (group == null && config.createGroupIfMissing)
                {
                    ManagedDeliveryMode delivery = ManagedAddressablePathRules.ResolveDelivery(parts[0], rule.delivery);
                    var previous = additions.FirstOrDefault(g => string.Equals(g.name, groupName, StringComparison.OrdinalIgnoreCase));
                    if (previous != null && (previous.delivery != delivery || previous.bundleMode != rule.bundleMode)) throw new InvalidOperationException("Conflicting new Group baseline: " + groupName);
                    if (previous == null)
                    {
                        additions.Add(new ManagedAddressableSyncPlan.GroupAddition(groupName, delivery, rule.bundleMode));
                        PlanNewGroup(groupName, delivery, rule.bundleMode, changes);
                        changes.Add(new ManagedAddressableSyncChange("Group", groupName, "Config ownership", "absent", "register the new Group asset GUID after creation"));
                        report.createdGroups++;
                        report.messages.Add("[Create Group] " + groupName);
                        if (settings != null)
                        {
                            foreach (string variable in new[] { delivery == ManagedDeliveryMode.Local ? ManagedAddressableProfileUtility.LocalBuildPath : ManagedAddressableProfileUtility.RemoteBuildPath, delivery == ManagedDeliveryMode.Local ? ManagedAddressableProfileUtility.LocalLoadPath : ManagedAddressableProfileUtility.RemoteLoadPath })
                                if (!settings.profileSettings.GetVariableNames().Contains(variable)) blocked.Add("[Profile] Missing " + variable + "; create the path variable using official Profiles before registering " + groupName + ". Sync will not add a variable to every existing Profile.");
                        }
                    }
                }
                bool canRegister = group != null || config.createGroupIfMissing;
                if (entry == null && (!config.autoRegister || !canRegister)) continue;
                bool add = entry == null;
                bool move = entry != null && canRegister && (group == null || entry.parentGroup != group);
                string address = entry == null ? path : entry.address;
                if (preserve) report.preservedAddresses++;
                else
                {
                    if (entry != null) used.Remove(entry.address);
                    if (fileNameAddress != null)
                    {
                        address = fileNameAddress;
                        used.Add(address); // free: the conflict check above already ran
                    }
                    else
                    {
                        address = ManagedAddressNaming.BuildAddress(parts[1], resolution.addressPathAfterCategory, path, config.includeExtension, config.pathSeparator, config.ignorePathPrefixes);
                        if (config.ensureUnique) address = ManagedAddressNaming.EnsureUnique(address, path, used);
                        else if (!used.Add(address)) throw new InvalidOperationException("Duplicate Address: " + address + " (" + path + ")");
                    }
                }
                if (add)
                {
                    report.addedEntries++;
                    report.messages.Add("[Add Entry] " + path + " -> " + groupName);
                    changes.Add(new ManagedAddressableSyncChange("Entry", path, "Registration", "absent", groupName));
                }
                else if (move)
                {
                    report.movedEntries++;
                    report.messages.Add("[Move Entry] " + path + " -> " + groupName);
                    changes.Add(new ManagedAddressableSyncChange("Entry", path, "Group", entry.parentGroup.Name, groupName));
                }
                string before = entry == null ? path : entry.address;
                bool changeAddress = !string.Equals(before, address, StringComparison.Ordinal);
                if ((add || move || changeAddress) && ((group != null && group.ReadOnly) || (entry != null && (entry.ReadOnly || entry.parentGroup.ReadOnly))))
                    throw new InvalidOperationException("Read-only owned Group/Entry would be modified: " + path);
                if (changeAddress)
                {
                    report.changedAddresses++;
                    report.messages.Add("[Address] " + before + " -> " + address + " (" + path + ")");
                    changes.Add(new ManagedAddressableSyncChange("Entry", path, "Address", before, address));
                }
                if (add || move || changeAddress) entryChanges.Add(new ManagedAddressableSyncPlan.EntryChange(guid, canRegister ? groupName : entry.parentGroup.Name, address));
            }
            report.messages.Add("[Optional SDK Groups] Localization, Spine and Analyze-created Groups are preserved.");
            if (createSettings || additions.Count > 0)
            {
                report.messages.Add("[SDK Save] Public SDK Settings/Group schema creation calls SaveAssets. Unrelated dirty persistent assets block Apply before any write.");
                report.messages.Add("[SDK Save] Settings, the reviewed Config and affected entry Groups may persist their current input values with the registration changes.");
                blocked.AddRange(UnrelatedDirtyAssets(settings, config, AffectedGroups(settings, entryChanges)).Select(p => "[SDK Save] Unrelated dirty persistent asset: " + p + ". Save or discard it using its owner before applying this plan."));
            }
            report.messages.Add(createSettings ? "[Scope] New Settings initialization only; no existing Profile/Group is rewritten." : "[Scope] Existing Group schemas, Global settings, Profile values and active Profile are preserved.");
            foreach (string scope in new[] { "Group", "Entry", "Profile", "Global" })
                report.messages.Add("[Planned " + scope + " Changes] " + changes.Count(c => c.scope == scope));
            report.messages.AddRange(changes.Select(c => c.ToString()));
            report.messages.AddRange(warnings.Select(w => "[Warning] " + w));
            report.messages.AddRange(blocked.Select(c => "[Blocked] " + c));
            report.messages.AddRange(errors.Select(e => "[Error] " + e));
            return new ManagedAddressableSyncPlan(SyncFingerprint(config, settings), createSettings, additions, entryChanges, changes, blocked, report, warnings, errors: errors);
        }

        public static ManagedAddressableSyncReport ApplyPlan(ManagedAddressableProjectConfig config, ManagedAddressableSyncPlan plan)
        {
            CheckSyncState(config);
            if (plan == null) throw new ArgumentNullException(nameof(plan));
            ValidateSyncPaths(config);
            AddressableAssetSettings settings = AddressableAssetSettingsDefaultObject.Settings;
            if (!string.Equals(plan.fingerprint, SyncFingerprint(config, settings), StringComparison.Ordinal)) throw new InvalidOperationException("Sync plan is stale. Preview again before Apply; no changes were written.");
            if (!plan.CanApply) throw new InvalidOperationException("Sync plan has blocked changes:\n" + string.Join("\n", plan.BlockedChanges));
            if (!plan.HasChanges) return plan.Report;
            var affectedGroups = AffectedGroups(settings, plan.entries);
            if (settings != null) affectedGroups.AddRange(settings.groups.Where(g => g != null && plan.policies.Any(p => p.assetGuid == AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(g)))));
            if ((plan.createSettings || plan.groups.Count > 0) && UnrelatedDirtyAssets(settings, config, affectedGroups).Any()) throw new InvalidOperationException("SDK schema creation would save unrelated dirty persistent assets. Save or discard those edits using their owner and Preview again.");
            var policySchemas = affectedGroups.Where(g => plan.policies.Any(p => p.assetGuid == AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(g)))).Select(g => g.GetSchema<BundledAssetGroupSchema>()).Where(s => s != null).ToArray();
            // This PC's release file lives outside Assets, so the transaction restores it separately.
            byte[] localRelease = plan.HasReleaseMetadata ? ManagedLocalRelease.RawBytes(config) : null;
            using (ManagedAddressableSyncTransaction transaction = new ManagedAddressableSyncTransaction(settings, affectedGroups, config, policySchemas))
            {
                try
                {
                    if (settings != null && config.backupBeforeApply) BackupSettings(config, settings);
                    ApplySyncPlan(config, settings, plan, affectedGroups);
                    transaction.Complete();
                    return plan.Report;
                }
                catch
                {
                    transaction.Restore();
                    if (plan.HasReleaseMetadata) ManagedLocalRelease.Restore(config, localRelease);
                    throw;
                }
            }
        }

        private static List<AddressableAssetGroup> AffectedGroups(AddressableAssetSettings settings, IEnumerable<ManagedAddressableSyncPlan.EntryChange> entries)
        {
            return settings == null ? new List<AddressableAssetGroup>() : entries.Select(e => settings.FindAssetEntry(e.guid)?.parentGroup).Concat(entries.Where(e => !e.remove).Select(e => FindGroup(settings, e.groupName))).Where(g => g != null).Distinct().ToList();
        }

        internal static IEnumerable<string> UnrelatedDirtyAssets(AddressableAssetSettings settings, ManagedAddressableProjectConfig config, ICollection<AddressableAssetGroup> affectedGroups)
        {
            // Built-in resources can be persistent and dirty, but SaveAssets does not save them as user project
            // assets. Imported assets (shaders, fonts) dirty only in editor-only state are not written by SaveAssets
            // either, so they would block every Sync without any edit to protect.
            return UnityEngine.Resources.FindObjectsOfTypeAll<UnityEngine.Object>()
                .Where(o => o != settings && o != config && !(o is AddressableAssetGroup group && affectedGroups.Contains(group)) && ManagedAddressableBuildExporter.IsSavableDirtyAsset(o))
                .Select(AssetDatabase.GetAssetPath)
                .Where(ManagedAddressableBuildExporter.IsProjectAssetPath)
                .Distinct().OrderBy(p => p, StringComparer.Ordinal).ToArray();
        }

        private static void CheckSyncState(ManagedAddressableProjectConfig config)
        {
            if (config == null) throw new ArgumentNullException(nameof(config));
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || BuildPipeline.isBuildingPlayer) throw new InvalidOperationException("Sync cannot run during Play, compilation or a Player build.");
            RejectImplicitSettingsMigration();
        }

        internal static AddressableAssetSettings ReadSettingsWithoutMigration()
        {
            RejectImplicitSettingsMigration();
            return AddressableAssetSettingsDefaultObject.Settings;
        }

        private static void RejectImplicitSettingsMigration()
        {
            // The SDK Settings getter migrates the legacy mapping and calls SaveAssets.
            // Query public config mappings before touching that getter during Preview or Apply.
            if (!EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName, out AddressableAssetSettingsDefaultObject current) &&
                EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName, out AddressableAssetSettings legacy) && legacy != null)
                throw new InvalidOperationException("Legacy Addressables Settings mapping requires explicit migration using the official Addressables tools. Sync Preview/Apply will not migrate or save it; migrate explicitly and Preview again.");
        }

        private static void ValidateSyncPaths(ManagedAddressableProjectConfig config)
        {
            string root = config.ContentRootPath;
            string absolute = Path.GetFullPath(root);
            string assets = Path.GetFullPath("Assets") + Path.DirectorySeparatorChar;
            if (!root.StartsWith("Assets/", StringComparison.Ordinal) || !absolute.StartsWith(assets, StringComparison.OrdinalIgnoreCase) || root.Split('/').Any(p => p == ".." || p == ".")) throw new InvalidOperationException("Content Root must be an explicit folder under Assets.");
            if (!Directory.Exists(root)) throw new DirectoryNotFoundException("Content Root: " + root);
            Stack<string> pending = new Stack<string>();
            pending.Push(root);
            while (pending.Count > 0)
            {
                string directory = pending.Pop();
                if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0) throw new InvalidOperationException("Content Root cannot contain linked directories: " + directory);
                foreach (string file in Directory.GetFiles(directory)) if ((File.GetAttributes(file) & FileAttributes.ReparsePoint) != 0) throw new InvalidOperationException("Content Root cannot contain linked files: " + file);
                foreach (string child in Directory.GetDirectories(directory)) pending.Push(child);
            }
            if (!config.backupBeforeApply) return;
            string backup = config.backupRoot ?? string.Empty;
            string destination = Path.GetFullPath(backup);
            string project = Path.GetFullPath(".") + Path.DirectorySeparatorChar;
            string first = backup.Replace('\\', '/').Split('/')[0];
            if (string.IsNullOrWhiteSpace(backup) || Path.IsPathRooted(backup) || !destination.StartsWith(project, StringComparison.OrdinalIgnoreCase) || backup.Replace('\\', '/').Split('/').Any(p => p == "..") || new[] { "Assets", "Packages", "ProjectSettings" }.Contains(first, StringComparer.OrdinalIgnoreCase)) throw new InvalidOperationException("Backup Root must be a dedicated project-local folder outside Assets, Packages and ProjectSettings.");
        }

        internal static string SyncFingerprint(ManagedAddressableProjectConfig config, AddressableAssetSettings settings)
            => SyncFingerprintCore(config, settings, false);

        internal static string SyncContentFingerprint(ManagedAddressableProjectConfig config, AddressableAssetSettings settings)
            => SyncFingerprintCore(config, settings, true);

        private static string SplitContentConfigJson(ManagedAddressableProjectConfig config)
        {
            var json = JObject.Parse(EditorJsonUtility.ToJson(config));
            var fields = json["MonoBehaviour"] as JObject ?? json;
            foreach (string name in SplitReleaseFields) fields.Remove(name);
            return json.ToString(Newtonsoft.Json.Formatting.None);
        }

        private static readonly string[] SplitReleaseFields = { "revisionShared" };

        // The SDK serializes its derived currentHash cache. Reading currentHash fills it with no content
        // change, and the Player Boot step reads it before planning, so a Revision baked outside the
        // Player build would otherwise never match the Boot generation. The settings file bytes stay in.
        private static string SettingsJsonWithoutDerivedHash(AddressableAssetSettings settings)
        {
            var json = JObject.Parse(EditorJsonUtility.ToJson(settings));
            ((json["MonoBehaviour"] as JObject) ?? json).Remove("m_currentHash");
            return json.ToString(Newtonsoft.Json.Formatting.None);
        }

        // Only this known top-level Config field is omitted. This is a
        // bounded Unity-text Config adapter, not a YAML parser or an SDK cache filter.
        internal static string SplitContentConfigFile(string path)
        {
            string raw = File.ReadAllText(path).Replace("\r\n", "\n");
            if (!raw.StartsWith("%YAML", StringComparison.Ordinal) || !raw.Contains("\nMonoBehaviour:") || raw.IndexOf('\0') >= 0)
                throw new InvalidOperationException("contentFingerprint requires the known Unity text Project Config serialization: " + path);
            var result = new StringBuilder(); bool omit = false;
            foreach (string line in raw.Split('\n'))
            {
                if (SplitReleaseFields.Any(name => line.StartsWith("  " + name + ":", StringComparison.Ordinal))) { omit = true; continue; }
                if (omit && (line.Length == 0 || line.StartsWith("    ", StringComparison.Ordinal))) continue;
                omit = false; result.Append(line).Append('\n');
            }
            return result.ToString();
        }

        private static string SyncFingerprintCore(ManagedAddressableProjectConfig config, AddressableAssetSettings settings, bool contentOnly)
        {
            var text = new StringBuilder();
            text.AppendLine(contentOnly ? SplitContentConfigJson(config) : EditorJsonUtility.ToJson(config));
            string configPath = AssetDatabase.GetAssetPath(config);
            var files = new SortedSet<string>(StringComparer.Ordinal);
            AddObjectFiles(config, files);
            foreach (string file in Directory.GetFiles(config.ContentRootPath, "*", SearchOption.AllDirectories)) files.Add(file.Replace('\\', '/'));
            if (settings == null)
            {
                text.AppendLine("Settings:absent");
                if (Directory.Exists(AddressableAssetSettingsDefaultObject.kDefaultConfigFolder))
                    foreach (string file in Directory.GetFiles(AddressableAssetSettingsDefaultObject.kDefaultConfigFolder, "*", SearchOption.AllDirectories)) files.Add(file.Replace('\\', '/'));
            }
            else
            {
                text.AppendLine(AssetDatabase.GetAssetPath(settings)).AppendLine(SettingsJsonWithoutDerivedHash(settings));
                foreach (AddressableAssetGroup group in settings.groups.Where(g => g != null).OrderBy(g => g.Guid, StringComparer.Ordinal))
                {
                    text.AppendLine(EditorJsonUtility.ToJson(group));
                    AddObjectFiles(group, files);
                    foreach (AddressableAssetGroupSchema schema in group.Schemas.Where(s => s != null).OrderBy(s => s.GetType().FullName, StringComparer.Ordinal))
                    {
                        text.AppendLine(EditorJsonUtility.ToJson(schema));
                        AddObjectFiles(schema, files);
                    }
                    foreach (AddressableAssetEntry entry in group.entries.Where(e => e != null).OrderBy(e => e.guid, StringComparer.Ordinal))
                        if (!string.IsNullOrEmpty(entry.AssetPath)) text.AppendLine(entry.guid + ":" + AssetDatabase.GetAssetDependencyHash(entry.AssetPath));
                }
                AddObjectFiles(settings, files);
            }
            files.Add("ProjectSettings/EditorBuildSettings.asset");
            foreach (string path in files)
            {
                text.AppendLine(path);
                if (!File.Exists(path)) { text.AppendLine("absent"); continue; }
                bool normalizedConfig = contentOnly && path == configPath;
                using (SHA256 hash = SHA256.Create())
                {
                    if (normalizedConfig) text.AppendLine(Convert.ToBase64String(hash.ComputeHash(Encoding.UTF8.GetBytes(SplitContentConfigFile(path)))));
                    else using (FileStream stream = File.OpenRead(path)) text.AppendLine(Convert.ToBase64String(hash.ComputeHash(stream)));
                }
                if ((path.StartsWith("Assets/", StringComparison.Ordinal) || path.StartsWith("Packages/", StringComparison.Ordinal)) && IsManagedAssetFile(path))
                {
                    if (normalizedConfig)
                    {
                        // The SDK dependency hash also incorporates the excluded raw fields.
                        // Keep GUID and all other dependencies, with normalized Config bytes above.
                        text.AppendLine(AssetDatabase.AssetPathToGUID(path));
                        foreach (string dependency in AssetDatabase.GetDependencies(path, true).Where(p => p != path).OrderBy(p => p, StringComparer.Ordinal))
                            text.AppendLine(dependency + ":" + AssetDatabase.GetAssetDependencyHash(dependency));
                    }
                    else text.AppendLine(AssetDatabase.AssetPathToGUID(path) + ":" + AssetDatabase.GetAssetDependencyHash(path));
                }
            }
            using (SHA256 hash = SHA256.Create()) return Convert.ToBase64String(hash.ComputeHash(Encoding.UTF8.GetBytes(text.ToString())));
        }

        private static void AddObjectFiles(UnityEngine.Object value, ISet<string> files)
        {
            string path = AssetDatabase.GetAssetPath(value);
            if (string.IsNullOrEmpty(path)) return;
            files.Add(path);
            files.Add(path + ".meta");
        }
    }
}
