# Changelog

## 1.3.12-pre.20 - 2026-11-12

Internal candidate. One address rule: the address is the file name. No Runtime change.

### Changed

- New `ManagedAddressableProjectConfig.addressNaming` (`ManagedAddressNamingMode.FileName` / `Path`). The default is `FileName`: the address is the file name without its extension (`ManagedAddressNaming.BuildFileNameAddress`), so `Remote/Character/Enemies/Boss.prefab` becomes `Boss`. Folders under the category only organise files; the Group still comes from `Local/<Category>`, `Remote/<Category>` and `Update/<BundleKey>`. `.uss` and `.tss` keep their extension as in pre.19, and `includeExtension` still applies.
- Under `FileName`, files that would share an address are not given a `#hash` suffix. The registration plan lists every path in one error per address (`ManagedAddressableSyncPlan.Errors`, `[Error] Duplicate Address '<address>'` in the report, `ManagedAddressableSyncReport.addressConflicts`) and leaves those files as they are: no registration, Group move, address change or new Group. The rest of the plan still applies. An address already held by an Entry outside the content root counts as a conflict too. Names are compared across every file under the content root, including files that keep a preserved address or will not be registered. An owned content Entry whose address the same plan rebuilds does not count as a holder, so a rebuild does not depend on path order.
- A Config gains a field, so `SyncContentFingerprint` of an existing Config changes once after the upgrade.
- App Build (`ManagedAppBuild`) stops at step 1 when the registration plan has an address conflict, so an app is never built with those files missing.
- `Path` keeps the earlier rule unchanged (`pathSeparator`, `ignorePathPrefixes`, `ensureUnique`, exception on a duplicate without `ensureUnique`). The Control Center shows those three fields only under `Path`.
- A Config saved before pre.20 has no `addressNaming` field and reads as `FileName`. A project that already ships path addresses sets `Path` when it upgrades. Existing addresses stay either way through `preserveExistingAddressesOnSync`; only new Entries and an address rebuild follow the rule.

### Tests

- `ManagedAddressNamingTests`: two cases for `BuildFileNameAddress`.
- `ManagedFrameworkHostTests`: default is `FileName`; sub folders stay out of addresses and Groups; a duplicate is reported with every path and those files stay unchanged (preview and apply); a registered file is not renamed by a conflict, with or without an address rebuild; an address held outside the content root is a conflict; an address rebuild does not depend on path order; `Path` keeps `Tutorial_Guide` / `Enemies_Boss`. The two earlier duplicate tests now set `Path` and are renamed `PathNamingDuplicateNewKeyFailsBeforeAnyWrite` and `PathNamingUniquePolicyUsesStableGuidSuffixAndPreservesPublishedDuplicateResolution`.

## 1.3.12-pre.19 - 2026-11-11

Internal candidate. UI Toolkit plan stage 3: address and build-role checks that UI Toolkit content needs. No Runtime change.

### Changed

- `.uss` and `.tss` files keep their extension in a new address even when `includeExtension` is off (`ManagedAddressNaming.KeepsExtension`). A screen's UXML `Shop` and its style sheet `Shop.uss` can now sit in one folder. Every other type is unchanged, and `preserveExistingAddressesOnSync` still keeps addresses that already exist; an existing style sheet entry gets the new address only through a rebuild of addresses.
- Preview Build Roles (`CreateBuildRolePlan`) warns, for the draft roles, about what the split build would refuse later: a ScriptableObject that both Boot and Revision reach. UI Toolkit style sheets, themes, PanelSettings and font assets are ScriptableObjects, so a Remote screen that references a Local theme or font file directly now shows up before the build. The warning does not block the role plan; the split build check is unchanged.
- Both Preview Build Roles and the split build check warn about a Static font asset that still references its source font file. The Addressables content build packs that file into the bundle (UI Toolkit plan, stage 1 E6). The check reads `m_AtlasPopulationMode` and `m_SourceFontFile` by name, which TextCore and TextMesh Pro font assets share. Only asset types that declare `m_AtlasPopulationMode` are loaded, and a failure in these early checks becomes one warning instead of stopping the preview.

### Tests

- `ManagedAddressNamingTests`: three cases for the style sheet rule.
- `ManagedUIToolkitRoleWarningTests` (new, four cases) with the test-only asset `ManagedRoleWarningProbe`.

## 1.3.12-pre.18 - 2026-11-10

Internal candidate. The Editor BootstrapSplit adapter now accepts Addressables 4.1.2, the version Unity 6.7 forces, as well as 4.0.1. The allowed versions are an exact set, not a range: 4.1.0 and 4.1.1 were not compared and stay blocked for the split build. Runtime Revision apply keeps the closed range 4.0.1 to 4.1.2 from pre.16 (`ARTRESS_ADDRESSABLES_REVISION_BUNDLE_NAMES`), so the two policies differ on purpose: the split adapter depends on more SDK internals than the bundle name rule.

### Changed

- `ManagedBootstrapSplitValidation`, `ManagedBootstrapSplitSettingsScope` and the interrupted-build snapshot check in `ManagedBootstrapSplitInterruptedSettings` read one list, `ManagedAddressableBuildExporter.SplitVerifiedAddressablesVersions` (`4.0.1`, `4.1.2`). An interrupted snapshot still restores only on the same Addressables version that wrote it.
- Reason: a 2026-11-10 source comparison of Addressables 4.0.1 and 4.1.2 for every SDK detail the adapter depends on:
  - Same: the private `m_BundledAssetProviderType`/`m_AssetBundleProviderType` `SerializedType` fields, `SerializedType` itself (`ResourceManagerConfig.cs` is identical; `TypeNameResolver` changed only its cache lifetime, not how names resolve), `AddressableAssetSettings.OnAfterDeserialize`, the `CatalogProviderType` and Settings provider setters, `ProfileValueReference` (identical), `ProjectConfigData` (identical), `BuildScriptPackedMode` and the catalog writer (identical), and the Build Layout Group rows, which still list excluded Groups with zero Bundles.
  - Different but not used by the adapter: `m_cachedHash` is no longer serialized in the Settings asset, a new `m_ContentDirectoryArchiveMode` field, `RemoteCatalogBuildPath` now resets an empty (not only null) Id, and the Layout's `RemoteCatalogBuildPath` is empty when no remote catalog is built. The adapter restores the captured bytes of every touched asset and always writes a non-empty literal path, so none of these changes its result.
  - Different and relevant: in 4.1.2 the `BundledAssetGroupSchema` provider setters also write the value into the owning Settings. The adapter never calls these setters (restoration writes the fields directly), so production is unaffected.
- Unity 6000.6 and later compile Addressables with `ENABLE_CONTENT_DIRECTORIES` (an engine-version define in both 4.0.1 and 4.1.2). It adds a third Settings provider struct, `m_GroupAssetEntryProviderType`, that `OnAfterDeserialize` backfills with `NativeContentAssetEntryProvider` like the other two. The overlay now captures and restores it the same way when the field exists, and the interrupted-build snapshot records it. Without this, the first 6.7 run (`u67-ma67-01`) left the backfilled value in the restored Settings: 12 Editor cases failed on the restored Settings JSON or a stale content fingerprint, and the chain stopped at "content fingerprint changed after the Revision bake". On 6000.3 the field does not exist and the effective-settings text is unchanged, so receipts recorded there stay valid.

### Tests

- `ActualSdkFailureAndExceptionRestoreRawAndEffectiveSettings` authored the foreign Group's provider types through the schema setters. On 4.1.2 those setters overwrote the custom global providers the case relies on, so the fixture now writes the schema fields directly and asserts that the global providers stayed custom.

### Verification

- Unity 6000.3.9f1, Addressables 4.0.1: Revision Host chain job `u67-ma63-02` (script mode, fresh Host). Editor 243 of 244 (the chain case skips there and runs on its own), PlayMode 76 of 76, chain 1 of 1, batch App Build exit 0.
- Unity 6000.7.0b8, Addressables 4.1.2: job `u67-ma67-02`, same script and counts. The split build, the packaged A, the remote B apply and the restart that keeps B now pass on 6.7. The first 6.7 run `u67-ma67-01` (before the content-directory provider fix) failed 12 Editor cases and the chain.
- NOT_RUN: release builds, Android, iOS, IL2CPP, a real remote server. Details are in `Docs/Guide/Verification.md` (Unity 6.7 section).

## 1.3.12-pre.17 - 2026-11-10

- Menus moved: `Tools/Artress/Managed Addressables/Open Control Center` is now `JJEvol/Addressables/Control Center`, and `Tools/Artress/Managed Addressables/Build App` is now `JJEvol/Addressables/Build App`. Framework menus are grouped by feature under one `JJEvol/` root (Editor menus), `Assets/Create/JJEvol/` (asset menus) and `GameObject/UI/JJEvol/` (UI objects). Only the menu path changed; class names, serialized fields and GUIDs are unchanged, so existing assets keep working.

Unity tests for this candidate are NOT_RUN.

## 1.3.12-pre.16

Internal candidate. The Runtime allows Revision apply with Addressables 4.0.1 through 4.1.2, the version Unity 6.7 forces. Only 4.0.1 and 4.1.2 were compared; 4.1.0 and 4.1.1 fall inside the range unchecked. The Editor BootstrapSplit adapter still accepts only 4.0.1, so on 6.7 the split build and the chain do not run yet (see Verification below).

### Changed

- The asmdef version define is now `ARTRESS_ADDRESSABLES_REVISION_BUNDLE_NAMES` for `com.unity.addressables` `[4.0.1,4.1.2]` (was `ARTRESS_ADDRESSABLES_4_0_1` for `[4.0.1]`). Outside that closed range Revision apply still throws `NotSupportedException`, now `RevisionBundleNameAdapterRequiresAddressables4.0.1To4.1.2`.
- Reason: a 2026-11-10 source comparison found that bundle names, hashes, `AssetBundleRequestOptions.BundleName`/`Hash` and InternalIds are produced by the same code in 4.0.1 and 4.1.2 (`BundledAssetSchemaBuilder` changed only in folder packing and the new `CacheProbeMode`; `AddHashToBundleNameTask` and `BuildScriptPackedMode` are identical; Scriptable Build Pipeline 4.0.0 to 4.0.2 does not touch names). The `sdkBundleName + ".bundle"` rule for loaded bundle names is an engine observation, so it is now checked on the real Player.

### Fixed

- The deferred apply looked for the previous Revision's bundles by the exact name `sdkBundleName + ".bundle"`. The 2026-11-10 chain on 6000.3 (Addressables 4.0.1) showed that a remote Group bundle loads as `sdkBundleName + ".bundle_" + a 32-character suffix`, so the wait found nothing and reported the previous bundles as already unloaded. A loaded name now matches the stem exactly or the stem followed by `_`. This was wrong in pre.15 and earlier as well.

### Tests

- The Revision Host chain Player driver checks, every time it loads Revision content, that each loaded non-Boot bundle is named `sdkBundleName + ".bundle"`, alone or followed by `_` and a suffix, from the active Revision's publisher, and fails the chain otherwise. Before this the rule was not exercised: the deferred-apply wait would only have seen no bundles.
- `ALoadedRemoteBundleMatchesItsStemWithTheSdkSuffix` covers the name match.

### Verification

- Unity 6000.3.9f1, Addressables 4.0.1: Revision Host chain job `pkg1110-ma63-04` (script mode, fresh Host, 2026-11-10). Editor 243 of 244 (the chain case skips there and runs on its own), PlayMode 76 of 76, chain 1 of 1. The Player confirmed its packaged A offline, downloaded and applied B from the loopback local host, and the second start kept B; every load checked the loaded bundle names against the publisher. The earlier runs `pkg1110-ma63-01` to `-03` found the bundle name bug above and two chain driver mistakes (the remote publisher is a URL during validation and after commit).
- Unity 6000.7.0b8, Addressables 4.1.2: job `pkg1110-ma67-01` ran PlayMode 71 of 71, including `DeferredApplyCanResumeAOnlyWhenItsOwnedRegistrationIsIntact`. It ran before the bundle name fix and its 5 new cases, and was not rerun.
- On 6000.7.0b8 the Editor suite had 25 failures and the chain did not run. The Editor BootstrapSplit adapter still requires Addressables 4.0.1 (`ManagedBootstrapSplitValidation`, `ManagedBootstrapSplitSettingsScope`, `ManagedBootstrapSplitInterruptedSettings`). Widening it is an open item.
- NOT_RUN: the 6.7 Editor split build and chain, release builds, Android, iOS, IL2CPP, a real remote server.

## 1.3.12-pre.15

Internal candidate. Queue runner jobs `ma-pre15-full-a7` and `ma-pre15-full-b8` (2026-11-09) ran compile and the Editor suite on Unity 6000.3.9f1: 243 of 243 passed (every Editor test except the official Player chain and the separate-Editor-process test, as in pre.13). The App Build steps up to the Player ran with the Player step replaced. Then the Revision Host chain (job `ma-pre15-chain-1`, script mode, 2026-11-09, 8 min) ran on a fresh Host: Editor 243 of 244 (the chain case skips there and runs on its own), PlayMode 71 of 71, and the chain 1 of 1, now with `ManagedAppBuild.Build` and its real Player step making a Windows Mono Development Player. That Player confirmed its packaged A offline, reused it, downloaded and confirmed B from the loopback local host, and kept B offline. The batch entry `BuildFromCommandLine -managedAppOutput … -managedAppDevelopment` on the same Host exited 0, raised the sequence from 3 to 4, built a second Player, and that Player started on its own packaged A over the stored B. Release builds through App Build, Android, iOS, a real remote server and IL2CPP were NOT_RUN. The consumer game's Android device record from pre.14 belongs to that game's test integration, not to the Framework's own verification.

### Added

- `App Build` on the Control Center's first screen and under `Tools/Artress/Managed Addressables/Build App`. One button runs readiness, registration sync, the deployment sequence, the Revision bake, the Config reload and save, the app-included Revision A link and the Player build in that order, and stops with the failed step and where to fix it.
- Public API `ManagedAppBuild.Build(string outputPath, bool development)` returning `ManagedAppBuildResult` (`Succeeded`, `OutputPath`, `DeploymentSequence`, `RevisionReceiptPath`, `PackagedRevisionPath`, `Steps`, `Error`).
- Batch entry `ManagedAppBuild.BuildFromCommandLine` with `-managedAppOutput <path>` and `-managedAppDevelopment`. It exits with 0 or 1 after the build and, for Android, stops java processes from this Unity version's OpenJDK that started after the build began. Another Editor of the same version building Android at that time would lose its daemon too, so use it where one Editor runs.
- Development builds raise this PC's deployment sequence to the larger of the saved value and the last completed Revision, plus one, and save it. When a later step fails, the saved value goes back; a Revision already baked still counts as the last one. Release builds never raise it; they stop before the bake when the saved sequence is 0 or not above the last Revision, and stop before any step when Allow Development HTTP is on.
- App Build always builds with LZ4. For Android it clears the Gradle Player data folder under `Library/Bee/Android/Prj` before the build. For every target it reports a `data.unity3d` older than the build as a failure and leaves the file in place.
- Control Center window text can be switched between Korean and English (stored in EditorPrefs, default Korean). Unity menu items stay English.

### Changed

- The Control Center is reorganized: the first screen holds App Build, and the other tools sit under `Advanced` in eleven sections. Button names changed; the README has the full old-to-new table.
- Menus are `Open Control Center` and `Build App`. The `Remove Empty Groups` menu item is removed; the same action stays in the window under `Advanced > Content registration` (`Delete Empty Groups`).
- Block messages for the release values, an interrupted build, build roles, development http in a release build and a missing app-included A name the new location in the window.
- The window's App Build refuses to start while the release value draft or the build role draft is unapplied, so it never builds values other than the ones on screen.

## 1.3.12-pre.14

Internal candidate. Queue runner job `ma-pre14-hash-2` (2026-11-09) ran compile and 18 Editor tests (the pre.8 Editor contract suite without its enum-parameter cases, the dirty-input suite and the new test) on Unity 6000.3.9f1 and passed. A consumer game test integration built an Android Development Player that opened its app-included Revision A on a device, and a second build with a higher deployment sequence replaced it over an existing install. The full Editor and PlayMode suites, the Windows Player chain and iOS were not rerun.

### Fixed

- A Player build no longer rejects the app-included Revision A with "검증 세대가 다르며…" when nothing changed after the Revision bake. The Addressables settings serialize a derived hash cache (`m_currentHash`), and the Player Boot step fills it by reading `currentHash` before it plans. A Revision baked from the window or a script left it empty, so the two generations never matched. The generation fingerprints now leave this cache out. Fingerprints from earlier candidates no longer match; bake the Revision again.

## 1.3.12-pre.13

Internal candidate. Fixes the three findings of the after-the-fact review of pre.12 (review note on `64a701a`). Verification is recorded in FRAMEWORK-CANDIDATE.md.

### Fixed

- `Preview Sync` and `APPLY REVIEWED PLAN` no longer report "[SDK Save] Unrelated dirty persistent asset" for imported assets that are dirty only in editor-only state. Sync and the split build now share one rule: native assets and unapplied import settings count, imported assets do not.
- The split build now blocks on unsaved edits in open scenes and in Prefab Mode. Those edits live on scene objects, so pre.12 and earlier missed them and the SDK built the saved file. pre.12's changelog wrongly said scenes were covered.
- Added Editor tests for unapplied import settings and for an unsaved open scene, and checked the Sync rule alongside the split rule.

## 1.3.12-pre.12

Internal candidate. The split build's unsaved-input check is fixed; queue runner job `ma-pre12-dirty` (2026-11-08) ran compile and 38 Editor tests (the split authoring, split integration and build role suggestion suites plus the new test) on Unity 6000.3.9f1 and passed. The full Editor and PlayMode suites, the Player chain, Android and iOS were not rerun for this candidate.

### Fixed

- `Preview Revision Build` no longer reports "Save or discard dirty persistent input" for imported assets such as shaders, `.ttf` fonts and Shader Graphs. Unity marks them dirty for editor-only state (for example dynamic font glyphs) that Save Project and an Editor restart do not clear, so a consumer game project could never build. Native assets (`.asset`, `.prefab`, `.mat`, scenes) and unapplied import settings still block the build.

## 1.3.12-pre.11

Internal candidate. On a fresh Revision Host with Unity 6000.3.9f1, run by the queue runner in script mode (job `ma-pre11-chain-c5`, 2026-11-08, 13 min 12 s): Editor 228 of 229 (one skipped), PlayMode 71 of 71, and the chain 1 of 1. The chain Player started on the packaged A offline, read the local host pointer over loopback HTTP, downloaded B through the Revision storage, applied and kept it, and Addressables itself made no http request. Android, iOS, Vendor adapters, a real remote server, the Windows regression table, frame timing and IL2CPP are NOT_RUN.

### Changed

- Release Metadata is split. `productId`, `authorityId` and `compatibilityFamily` stay in the Project Config as `revisionShared` and go to Git. `channel` and `deploymentSequence` live in `UserSettings/ArtressManagedAddressables/Release-<Config GUID>.json` on each PC, so two PCs on two channels never share a sequence.
- The app-included Revision A link moved to the same PC file, one per build target. A Config pulled from Git no longer points at another PC's `ServerData`.

### Removed

- `revisionRelease`, `packagedRevisionMetadataPath` and `packagedRevisionMetadataSha256` on the Project Config. Enter the release values again and Apply the packaged A again on each PC.

### Added

- `Build Output Cleanup` in Control Center: Preview, then Apply. Keeps the packaged A this PC links, the newest N Revisions per target (3 by default), the newest Boot, the stage Boot and the Boot paired with a kept Revision. Deletes the rest and the `Runtime` and `ContentState` copies of kept Revisions.
- `Publish Revision to Local Host` in Control Center, development only. Copies one built Revision to where its catalog URLs point inside a served folder and writes `split/latest/<target>/<channel>.json`. Published Revisions are never overwritten.
- Runtime `ManagedPackagedRevisionLoader.LoadAsync` builds the `ManagedRevisionApplication` from the packaged anchor, including Android jar paths.
- Runtime `ManagedRevisionLocalHostPointer` reads that pointer and gives the remote Revision for `PrepareAsync`.
- `Tests/Fixtures~/Serve-LocalHost.ps1`, a loopback static server with no installs. `Run-RevisionHost.ps1` now builds B, publishes it and checks that the Player downloads, applies and keeps B.

### Fixed

- Every atomic file replacement (this PC's release file, the local host pointer, the interrupted Split settings record, and the Runtime Revision bundles, pointer and first-install marker) goes through `ManagedFileReplace`. On Windows, `File.Replace` fails with "unable to remove the file to be replaced" while an indexer, antivirus or file watcher briefly holds the destination. It now retries the same replacement, only while the source and the destination both still exist. Seen in the pre.11 Editor run: one failed write left `pending_split_settings.json.next` behind and blocked four later tests.
- `Publish Revision to Local Host` refuses a host folder inside the build output root, containing it, or equal to the project folder. Build Output Cleanup would have read a Revision published under `ServerData` as an unfinished build and deleted it, leaving the pointer on missing files.
- The pointer path also checks `target` the way it checks `channel`, so neither can carry `/` or a dot segment.
- This PC's release file is recovered from its finished `.tmp` copy when a replacement removed the file and then failed. Before, the next read saw no file, the packaged A links were lost, and Build Output Cleanup could delete those packaged A builds.
## 1.3.12-pre.10

Internal candidate. On a fresh Revision Host with Unity 6000.3.9f1: Editor 204 of 205, PlayMode 56 of 56, official chain 1 of 1, and a Windows Mono Player that confirmed its packaged A offline and reused it on the next start. The one Editor case left is the chain, which runs on its own. On the existing Hosts: restart across two processes and core 14 of 14. Android, iOS, Vendor adapters, remote update, the Windows regression table, frame timing and IL2CPP are NOT_RUN.

### Removed

- `ManagedAddressableRevisionSession.OpenAsync`. `OpenForApplicationAsync` is the one start entry.
- The public `ManagedAddressableRevision` constructor without a publisher. It is internal now.
- `generateBuildLayout` on the Project Config. Split builds always turn Build Layout on.
- Packaged receipts without `contentFingerprint`. Rebuild the Revision.

### Added

- `Suggest Roles from Folders` in Control Center. It fills the Build Roles draft from Local and Remote folders and writes nothing.

### Fixed

- A rejected `OpenForApplicationAsync` argument no longer leaves the Session in recovery.

## 1.3.12-pre.9

Internal candidate. pre.10 replaced it.

### Removed

- Runtime: `ManagedAddressablesBootstrap`, `ManagedAddressableContentInstaller`, `ManagedAddressableStorage`, `ManagedAddressableCatalogService`, `ManagedAddressableRuntimeSettings`, the manifest and progress models, `ManagedAddressableHashUtility`.
- Session: the `Obsolete` `OpenAsync` and `ApplyAsync` overloads.
- Editor: `ManagedContentBuildMode` and the ExistingWorkflow route, including `Build` and the non-Split Revision build; artifact deployment and store; the remote change report; seed settings and `managed_addressable_manifest.json`; localization repair; legacy config migration; `RemoteSeeded` delivery; the Spine prefab generator and `ManagedSpineShaderDependencies`; `Candidates~/WindowsLocal`.

### Fixed

- The Boot Catalog check rejected any Group with SDK cache off, which includes every Local Group from Sync. The official Player build failed on projects made by the guide.

### Added

- `allowDevelopmentHttp` on the Project Config for plain http in Development Builds.
- `Tests/Fixtures~/Run-RevisionHost.ps1` and `ManagedOfficialChainTests`. They replace the pre.8 fixture record and run from any folder.

### Changed

- `LegacyAddressNaming` is now `ManagedAddressNaming`. The address rule is unchanged.
- The new Profile `Remote.LoadPath` default is `<undefined>` instead of the Installer folder, and the `Storage` variable is gone.
- Sync-created Remote Groups now default to SDK cache and CRC on and keep other versions, which Revision requires.
- Plain http Revision URLs fail by default.
- Publishers require deployment metadata and `catalogBytes`; the exporter always writes them.
- `CreateBuildRolePlan` drops the mode and Player defaults parameters and always plans `DoNotBuildWithPlayer`.
- Revision metadata writes the publisher before the Catalog, and startup cleanup removes a Catalog with no publisher.
- Displayed URLs and download errors omit the query string.
