# Artress Managed Addressables

**현재 상태: 1.3.12-pre.15 내부 후보. 공식 릴리스가 아니다.** pre.15는 Control Center 첫 화면에 「앱 빌드」 버튼 하나를 두고 나머지 단계를 「고급」 구역으로 옮겼다. 앱 빌드는 등록 동기화 → 배포 순번 → Revision 굽기 → Config 다시 읽기·저장 → 앱 포함 A → Player 빌드를 한 번에 한다. 배치 실행 진입점 `ManagedAppBuild.BuildFromCommandLine`과 공개 API `ManagedAppBuild.Build`를 더했다. 창 글은 한국어·영어로 바꿀 수 있다. Editor 시험 243/243가 통과했다(실행기 잡 `ma-pre15-full-a7`, `ma-pre15-full-b8`, 앱 빌드의 Player 단계는 대체). 새 Revision Host 체인(실행기 잡 `ma-pre15-chain-1`)에서 PlayMode 71/71이 통과했고, 앱 빌드와 배치 진입점이 각각 Windows Mono 개발 Player를 만들어 둘 다 앱 포함 A로 시작했다. 출시 앱 빌드, Android, iOS는 NOT_RUN이다. 검증 범위는 [CHANGELOG](CHANGELOG.md) 1.3.12-pre.15에 있다. pre.14는 Player 빌드가 앱 안 Revision A를 "검증 세대가 다르며…"로 늘 거절하던 문제를 고쳤다. 아래 pre.11 결과는 전체 시험을 다시 돌리지 않고 승계한다. 새 Revision Host에서 Editor 228/229(1 건너뜀), PlayMode 71/71, 로컬 호스트 원격 갱신 체인 1/1이 통과했다(실행기 잡 `ma-pre11-chain-c5`, 2026-11-08). Framework 자체의 Android, iOS 실행과 Vendor 어댑터는 NOT_RUN이다. 소비 게임 시험 적용에서 Android 개발 빌드가 기기에서 열린 기록(pre.14)은 그 게임 쪽 기록이며 Framework 검증으로 세지 않는다. AR2-04, 소비 게임 적용, 공식 릴리스는 HOLD다.

## 패키지 구조

콘텐츠 경로는 BootstrapSplit 하나다. 앱에 포함되는 Boot 전용 Binary Catalog와, 앱이 소유한 저장소에서 여는 Revision JSON Catalog로 나뉜다.

| 영역 | 역할 |
|---|---|
| Runtime | `ManagedAddressableRevisionSession`, `ManagedAddressableRevisionStorage`, Revision 모델 |
| Editor 등록 | 폴더 규칙으로 Group·Address를 미리 보고 적용하는 Sync와 Control Center |
| Editor 제작 | 앱 빌드(`ManagedAppBuild`), Boot/Revision Split 빌드, publisher 기록, 앱 포함 A 연결, Player 빌드 연계 |

## 주소 규칙 (pre.20부터)

주소는 **파일 이름(확장자 제외)**이다. 폴더 경로는 주소에 넣지 않는다. Group은 최상단 분류 폴더(`Local/<분류>`, `Remote/<분류>`)와 `Update/<묶음키>`로 정하고, 그 아래 하위 폴더는 정리용이다.

| Root 뒤 파일 경로 | Group | 주소 |
|---|---|---|
| `Remote/Character/Enemies/Boss.prefab` | `Remote_Character` | `Boss` |
| `Local/Character/UI/Enemy/Common/Hooligan.prefab` | `Character` | `Hooligan` |
| `Remote/Character/Update/Pack02/BossElite.prefab` | `Remote_Character_Pack02` | `BossElite` |

같은 주소가 되는 파일이 둘 이상이면 등록 미리 보기가 겹친 파일 경로를 모두 적은 오류를 내고, 그 파일들은 등록·주소 변경을 하지 않는다. `#해시`를 붙여 피하지 않으니 파일 이름을 바꾼다. 앱 빌드는 이 오류가 있으면 멈춘다. `.uss`, `.tss`는 확장자를 남긴다(`Shop.uss`).

Config `addressNaming`의 기본값은 `FileName`이다. 폴더 경로를 `_`로 잇던 이전 규칙이 필요한 프로젝트는 `Path`로 둔다(`pathSeparator`, `ignorePathPrefixes`, `ensureUnique`는 Path에서만 쓴다). 이 필드가 없는 예전 Config는 업그레이드하면 `FileName`으로 읽히므로, 경로 주소를 쓰던 프로젝트는 Control Center 「주소 방식」을 `Path`로 바꾼다. 자세한 내용은 [사용 가이드](Documentation~/ManagedAddressablesGuide.md) 2절이다.

`OpenForApplicationAsync` 성공 뒤에만 Revision을 소비한다. [Runtime 계약](Documentation~/AR2-Runtime2.md)과 [사용 가이드](Documentation~/ManagedAddressablesGuide.md)를 함께 본다.

## 제작 흐름

Control Center(`JJEvol/Addressables/Control Center`) 첫 화면에서 **앱 빌드**를 누른다. 메뉴 `JJEvol/Addressables/Build App`도 같은 일을 한다. 창 오른쪽 위에서 한국어·English를 고른다(이 PC 사용자 설정). Unity 메뉴 이름은 컴파일 때 고정되므로 영어로 남는다.

처음 한 번은 「고급」에서 준비한다. 준비가 덜 되면 앱 빌드 버튼 위에 무엇이 빠졌는지와 어느 구역에서 채우는지가 나온다. 시작 전에 Profile의 `Remote.LoadPath`를 실제 HTTPS 루트로 지정한다.

1. **고급 > 빌드 역할:** Group 역할, 공유 Bundle 대상, 필수 Boot 키, 「Boot/Revision 임시 쓰기를 위해 채택」을 `빌드 역할 미리 보기`로 검토하고 `미리 본 계획 적용`으로 적용한다. 채택을 끄면 필요한 빌드가 차단되고 ReadOnly Group은 우회하지 않는다. 기존 채택 해제는 「Group 소유」 구역에서 한다. 이 계획은 SDK `DoNotBuildWithPlayer`도 함께 설정한다.
2. **고급 > 배포 값:** Product ID, Deployment authority, Compatibility family(공유 값)와 Channel, Deployment sequence(이 PC 값)를 `배포 값 미리 보기` → `미리 본 계획 적용`으로 저장한다.

앱 빌드 한 번은 다음을 차례로 한다. 한 단계가 실패하면 그 자리에서 멈추고 결과 창에 단계와 원인을 남긴다. 이미 만든 산출물은 지우지 않는다.

| 순서 | 단계 | 하는 일 |
|---|---|---|
| 0 | 준비 확인 | 설정 에셋, 빌드 역할, 배포 값, 중단 기록, 켜진 Scene, 출력 경로(Assets 밖)를 확인하고 Config를 저장한다 |
| 1 | 등록 동기화 | 등록 계획을 만들어 바뀔 것이 있으면 적용하고 결과에 목록을 남긴다. 주소 재계산은 하지 않는다 |
| 2 | 배포 순번 | 개발 빌드: 이 출력 폴더의 같은 범위 완료 Revision 중 가장 큰 순번과 저장된 순번 중 큰 값 + 1을 이 PC 파일에 저장하고 쓴다. 뒤 단계가 실패하면 저장한 순번을 되돌린다(이미 구운 Revision은 다음 계산의 직전 값으로 남는다). 출시 빌드: 저장된 순번을 쓰고, 0 이하이거나 이전 값 이하이면 막는다 |
| 3 | Revision 굽기 | Revision 빌드 계획을 만들고 굽는다 |
| 4 | Config 다시 읽기·저장 | SDK 빌드 뒤 Config를 경로로 다시 읽어 저장한다. 굽기 전후 콘텐츠 지문이 다르면 멈춘다 |
| 5 | 앱 포함 A | 방금 영수증과 저장된 배포 값으로 앱 포함 A를 만들고 이 PC에 연결한다 |
| 6 | Player 빌드 | 켜진 Scene, 활성 플랫폼, 출력 경로, 개발 빌드 여부로 빌드한다. Boot는 Player 빌드가 직접 굽는다. 압축은 늘 LZ4다. Android는 직전에 `Library/Bee/Android/Prj/*/Gradle/unityLibrary/src/main/assets/bin/Data`를 비운다. 빌드 뒤 Windows·Linux·macOS·iOS 출력과 Android Gradle 폴더에 빌드 시작보다 오래된 `data.unity3d`가 있으면 실패로 보고한다(지우지 않는다). 빌드가 끝나면 SDK link.xml 복원을 바로 한다 |

출시 빌드에서 순번을 자동으로 올리지 않는 이유: 배포 순번은 배포 주체(서버)가 정한다. 같은 순번으로 내용이 다른 앱 포함 A를 덮어 설치하면 기기에서 `AmbiguousEqualDeploymentSequence`로 열리지 않으므로, 이전 값 이하이면 빌드 전에 막는다.

iOS는 Xcode 프로젝트를 Replace로 새로 만든다(Append 옵션을 넘기지 않는다). 같은 폴더에 다시 빌드해도 예전 `Data`가 남지 않지만, Xcode 프로젝트를 손으로 고친 내용도 빌드마다 사라진다. 그런 수정은 PostProcessBuild로 넣는다.

### 배치 실행

```
Unity.exe -batchmode -projectPath <프로젝트> -buildTarget Android -executeMethod Artress.ManagedAddressables.Editor.ManagedAppBuild.BuildFromCommandLine -managedAppOutput Builds/game.apk -managedAppDevelopment
```

- `-managedAppOutput`이 없으면 Unity Build Settings가 그 플랫폼에 기억하는 경로를 쓴다.
- `-managedAppDevelopment`가 있으면 개발 빌드, 없으면 출시 빌드다.
- 배치 모드에서는 성공 0, 실패 1로 Unity를 끝낸다. `-quit`는 필요 없다. Android면 끝내기 전에 이 빌드가 시작된 뒤 이 Unity의 내장 OpenJDK에서 뜬 java(Gradle 데몬)만 끝낸다. 같은 Unity 버전의 다른 Editor가 그 사이 Android를 빌드하면 그 데몬도 끝날 수 있으므로, 한 기계에서 Editor 하나만 도는 자리에서 쓴다.
- Android 서명 비밀번호는 다루지 않는다. 서명을 바꿔야 하는 프로젝트는 자기 Editor 스크립트에서 PlayerSettings를 정한 뒤 `ManagedAppBuild.Build(outputPath, development)`를 부르고 결과의 `Succeeded`·`Error`·`Steps`를 본다. `Build`는 Unity를 끝내지 않는다.

### 단계별로 하기

「고급 > 단계별 빌드」에서 같은 단계를 하나씩 한다. 이 경로의 Revision 빌드는 배포 순번을 올리지 않고 이전 값 이하이면 경고만 한다.

1. `Revision 빌드 미리 보기` → `Revision 빌드`. 최근 완료 영수증이 앱 포함 A 입력의 기본값이다.
2. `앱 포함 A 미리 보기` → `앱 포함 A 적용`. 연결은 이 PC의 파일에 플랫폼별로 남는다. Catalog, Bundle, publisher, anchor와 원문 proof 산출물이 이 PC의 해당 경로에 있어야 한다.
3. Unity의 Player 빌드가 Boot를 자동 제작하고 실제 staging을 검증한다. 앱 포함 A는 필수이며 끄는 옵션은 없다.

Project Config가 있는 프로젝트의 모든 Player 빌드는 이 흐름을 탄다. 역할이나 앱 포함 A가 없으면 빌드가 실패한다.

### 버튼 이름 (pre.14 → pre.15)

| pre.14 | pre.15 한국어 | pre.15 English |
|---|---|---|
| (없음) | 앱 빌드 | Build App |
| CREATE CONFIG / PREVIEW | 설정 만들기 | Create Config |
| APPLY REVIEWED PLAN | 미리 본 계획 적용 | Apply Previewed Plan |
| Preview Sync / Validate | 등록 미리 보기 / 등록 검사 | Preview Registration / Check Registration |
| Preview Empty Groups / Remove Empty Groups(메뉴 포함) | 빈 Group 미리 보기 / 빈 Group 삭제(메뉴에서 뺌) | Preview Empty Groups / Delete Empty Groups |
| Preview Address Rebuild / REBUILD ADDRESSES | 주소 재계산 미리 보기 / 주소 재계산 적용 | Preview Address Rebuild / Apply Address Rebuild |
| Detect New Categories | 새 Category 찾기 | Find New Categories |
| Preview Group Adoption / Preview Release / Preview Missing Ownership Cleanup | Group 채택 미리 보기 / 채택 해제 미리 보기 / 없는 Group 참조 정리 미리 보기 | Preview Group Adoption / Preview Adoption Release / Preview Missing Group Cleanup |
| Preview Build Roles / Suggest Roles from Folders / Reload Role Draft / Add Role Row | 빌드 역할 미리 보기 / 폴더로 역할 제안 / 역할 초안 다시 읽기 / 역할 행 추가 | 같음 |
| Preview Release Metadata / Reload Release Draft | 배포 값 미리 보기 / 배포 값 다시 읽기 | Preview Release Values / Reload Release Values |
| Allow Development HTTP | 개발용 HTTP 허용 | Allow Development HTTP |
| Preview Player Boot Build / BUILD PLAYER BOOT CONTENT | Boot 빌드 미리 보기 / Boot 빌드 | Preview Boot Build / Build Boot |
| Preview Revision Build / BUILD SDK REVISION CONTENT | Revision 빌드 미리 보기 / Revision 빌드 | Preview Revision Build / Build Revision |
| Preview Owned Remote Cache / CRC Policy | 원격 캐시·CRC 정책 미리 보기 | Preview Remote Cache / CRC Policy |
| Preview Packaged Revision A / APPLY REVIEWED PACKAGED A | 앱 포함 A 미리 보기 / 앱 포함 A 적용 | Preview App Included A / Apply App Included A |
| Validate Player Staging | Player 스테이징 검사 | Check Player Staging |
| Preview Output Cleanup / APPLY REVIEWED CLEANUP | 산출물 정리 미리 보기 / 산출물 정리 적용 | Preview Output Cleanup / Apply Output Cleanup |
| Preview Local Host Publish / APPLY REVIEWED LOCAL HOST PUBLISH | 로컬 호스트 게시 미리 보기 / 로컬 호스트 게시 적용 | Preview Local Host Publish / Apply Local Host Publish |
| Preview / Restore Interrupted Split Build Settings | 중단된 Split 설정 미리 보기 / 복원 | Preview / Restore Interrupted Split Settings |
| Restore Interrupted Player Build Metadata | 중단된 Player 빌드 정보 복원 | Restore Interrupted Player Build Data |

## PC별 값

| 값 | 저장 위치 | Git |
|---|---|---|
| Product ID, Authority, Compatibility family | Project Config `revisionShared` | 공유 |
| Channel, sequence, 플랫폼별 앱 포함 A 연결, 로컬 호스트 폴더 | `UserSettings/ArtressManagedAddressables/Release-<Config GUID>.json` | 제외 |

각 PC는 자기 Revision과 앱 포함 A를 직접 빌드한다. PC마다 다른 Channel을 쓰면 다른 PC의 순번과 섞이지 않는다. 앱 빌드가 개발 빌드에서 올린 순번도 이 파일에 저장된다. 앱은 앱 포함 A의 Channel과 같은 Revision만 받는다. 앱 버전은 Revision 선택 조건이 아니므로 내용만 바뀐 Revision은 같은 앱에 다시 빌드하지 않고 보낼 수 있다.

## 산출물 정리

빌드할 때마다 `buildOutputRoot` 아래에 stamp 폴더가 쌓인다. Control Center의 「고급 > 산출물 정리」에서 `산출물 정리 미리 보기` → `산출물 정리 적용`으로 지운다. 이 PC가 연결한 앱 포함 A, 플랫폼별 최근 Revision N개(기본 3), 최신 Boot, stage Boot, 남긴 Revision의 짝 Boot는 남긴다. 남긴 Revision의 `Runtime`·`ContentState` 복사본은 지운다. 미리 본 뒤 산출물이 바뀌면 적용은 아무것도 지우지 않고 멈춘다. 개발 빌드의 다음 순번은 남은 Revision과 이 PC 파일 중 큰 값에서 정하므로 정리해도 순번이 내려가지 않는다.

## 로컬 호스트 시험 (개발용)

게임 서버 없이 원격 갱신을 시험할 때 쓴다. 운영 신뢰 기준이 아니다.

1. Profile의 `Remote.LoadPath`를 `http://127.0.0.1:<port>/<경로>`로 두고 「고급 > 배포 값」의 `개발용 HTTP 허용`을 켠다. Player는 Development Build로 만든다.
2. 서버가 제공할 폴더를 「고급 > 로컬 호스트 게시」의 `로컬 호스트 폴더`에 저장한다.
3. Revision을 빌드한 뒤 `로컬 호스트 게시 미리 보기` → `로컬 호스트 게시 적용`. Revision 파일이 Catalog URL대로 복사되고 `split/latest/<플랫폼>/<channel>.json` 포인터가 마지막에 기록된다. 이미 게시된 Revision 폴더는 덮어쓰지 않는다.
4. 정적 서버로 그 폴더를 제공한다. 설치가 필요 없는 `Tests/Fixtures~/Serve-LocalHost.ps1 -Root <폴더> -Port <port>`를 쓸 수 있다. Android 실기기는 `adb reverse tcp:<port> tcp:<port>`로 연결한다.
5. 앱은 `ManagedPackagedRevisionLoader.LoadAsync()`로 시작 범위를 만들고, 포인터를 받아 `ManagedRevisionLocalHostPointer.Parse(json).ToRevision()`을 `PrepareAsync` → `ApplyAsync`에 넘긴다.

## 개발용 http

Revision URL은 HTTPS가 기본이다. 로컬 시험 서버처럼 평문 http가 필요하면 Control Center 「고급 > 배포 값」의 `개발용 HTTP 허용`(`ManagedAddressableProjectConfig.allowDevelopmentHttp`)을 켠다. 기본값은 꺼짐이다.

- **꺼짐:** http URL은 Editor 검증과 Runtime Revision·Storage 검사에서 실패한다.
- **켜짐:** Development Build만 허용한다. Player 빌드 단계가 `PlayerSettings.insecureHttpOption`이 `NotAllowed`일 때 그 빌드 동안만 `DevelopmentOnly`로 바꾸고 끝나면 되돌린다. iOS는 생성된 Xcode `Info.plist`에 ATS 예외를 추가한다. StreamingAssets 표식으로 Runtime이 같은 설정을 읽는다.
- **Release 빌드:** 켠 채로 빌드하면 명확한 오류로 실패한다. Release Player는 표식과 관계없이 http를 거부한다.

이 설정이 바꾸는 Player Settings는 Player 빌드에만 적용된다. Editor Play 모드는 프로젝트의 `insecureHttpOption`을 그대로 쓴다.

## 중단 복구

중단된 Split 임시 설정 기록이 있으면 Boot, Revision, Player 제작을 시작 전에 차단한다. 「고급 > 중단 복구」의 `중단된 Split 설정 미리 보기`로 원본, 기록 임시, 현재 SHA와 충돌을 확인한 뒤 `중단된 Split 설정 복원`을 실행한다. `중단된 Player 빌드 정보 복원`은 별도로 link.xml과 개발용 http가 바꾼 Player Settings를 복원한다.

충돌로 자동 복원이 차단되거나 `.next` 파일만 남았으면 수동으로 해결한다. `Library/ArtressManagedAddressablesSplit/pending_split_settings.json`과 같은 경로의 `.next` 중 존재하는 파일을 먼저 백업하고, 기록된 값과 현재 Settings, Group, schema, Profile을 소유자와 확인해 해결한 뒤 해당 pending 파일만 삭제하고 다시 미리 본다. 삭제만으로 설정이 복원되지는 않는다.

Runtime 시작 정리에서 읽을 수 없는 미확정 publisher나 모호한 파일 관계가 있으면 해당 회차 정리를 생략하고 `LastCleanupWarning`을 남긴다. 같은 후보가 남아 있으면 이후 시작에서도 정리가 생략될 수 있다. publisher가 없는 Catalog는 보존 관계가 없으므로 정리한다.

## 알려진 한계

- **디스크 반영:** Bundle과 metadata는 `FileStream.Flush(true)` 호출 뒤 최종 위치로 옮기고 그 뒤에 포인터를 기록한다. Windows Mono에서는 디스크 반영 실패가 호출자에게 감지되지 않는다. 전원 차단 내구성은 확인하지 않았다.
- **앱 교체:** 최초 복사가 중단된 뒤 다른 앱 A로 교체되면 `InitialInstallMarkerDoesNotMatchPackagedA`로 Boot 복구에 남는다. 전용 ReasonCode는 없다.
- **플랫폼:** Framework 자체의 Android, iOS 실기기, iOS native link, 물리 ENOSPC, 운영 HTTPS, 제품 Save 호환성은 NOT_RUN이다. 앱 빌드의 실제 Player 단계와 배치 진입점은 Windows Mono 개발 빌드만 확인했고, 출시 빌드·Android·iOS는 NOT_RUN이다(CHANGELOG 1.3.12-pre.15).
