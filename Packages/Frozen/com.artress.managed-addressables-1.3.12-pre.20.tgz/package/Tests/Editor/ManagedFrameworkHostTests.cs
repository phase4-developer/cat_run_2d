using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedFrameworkHostTests
    {
        private string root;
        private AddressableAssetSettings settings;
        private AddressableAssetSettings previous;
        private ManagedAddressableProjectConfig config;
        private static readonly FieldInfo DefaultField = typeof(AddressableAssetSettingsDefaultObject).GetField("s_DefaultSettingsObject", BindingFlags.Static | BindingFlags.NonPublic);

        [SetUp]
        public void SetUp()
        {
            previous = AddressableAssetSettingsDefaultObject.Settings;
            ImportCallback(previous, false);
            root = "Assets/ManagedFrameworkTests_" + Guid.NewGuid().ToString("N");
            Directory.CreateDirectory(root + "/Content");
            AssetDatabase.Refresh();
            settings = AddressableAssetSettings.Create(root + "/Settings", "Settings", false, true);
            DefaultField.SetValue(null, settings);
            Group("Default", true);
            config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.SetContentRoot(root + "/Content");
            config.backupBeforeApply = false;
        }

        [TearDown]
        public void TearDown()
        {
            ImportCallback(settings, false);
            DefaultField.SetValue(null, previous);
            if (AssetDatabase.GetAssetPath(config) == "") UnityEngine.Object.DestroyImmediate(config);
            AssetDatabase.DeleteAsset(root);
            ImportCallback(previous, true);
        }

        internal static void ImportCallback(AddressableAssetSettings target, bool enable)
        {
            if (target == null) return;
            Type processor = typeof(AddressableAssetSettings).Assembly.GetType("UnityEditor.AddressableAssets.Settings.AddressablesAssetPostProcessor", true);
            object callbacks = processor.GetProperty("OnPostProcess", BindingFlags.Static | BindingFlags.Public).GetValue(null);
            MethodInfo register = callbacks.GetType().GetMethod("Register");
            Delegate callback = Delegate.CreateDelegate(register.GetParameters()[0].ParameterType, target, typeof(AddressableAssetSettings).GetMethod("OnPostprocessAllAssets", BindingFlags.Instance | BindingFlags.NonPublic));
            if (enable) register.Invoke(callbacks, new object[] { callback, 0 });
            else callbacks.GetType().GetMethod("Unregister").Invoke(callbacks, new object[] { callback });
        }

        private string Text(string relative)
        {
            string path = root + "/" + relative + ".txt";
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, "synthetic framework validation");
            AssetDatabase.Refresh();
            Assert.IsNotNull(AssetDatabase.LoadAssetAtPath<TextAsset>(path));
            return path;
        }

        private AddressableAssetGroup Group(string name, bool isDefault = false)
        {
            return settings.CreateGroup(name, isDefault, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
        }

        private AddressableAssetEntry Entry(string path) { return settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(path)); }
        private static Dictionary<string, string> Files(string path)
        {
            return Directory.GetFiles(path, "*", SearchOption.AllDirectories).ToDictionary(p => p.Replace('\\', '/'), p => Convert.ToBase64String(File.ReadAllBytes(p)));
        }

        [Test]
        public void DiscoversAllDeliveriesAndCreatesGroupsWithExistingKeysPreserved()
        {
            AddressableAssetGroup officialDefault = settings.DefaultGroup;
            string officialDefaultBefore = ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault);
            string local = Text("Content/Local/UI/LocalItem");
            string remote = Text("Content/Remote/Model/RemoteItem");
            string second = Text("Content/Remote/Boot/SecondItem");
            config.categoryRules = ManagedAddressableCategoryDiscovery.Discover(config.ContentRootPath);
            CollectionAssert.AreEquivalent(new[] { "Local/UI", "Remote/Model", "Remote/Boot" }, config.categoryRules.Select(r => r.relativePath));
            AddressableAssetEntry existing = settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(remote), Group("Previous"));
            existing.SetAddress("published-key");
            existing.SetLabel("keep-label", true, true);
            ManagedAR2G2IntegrationTests.ExplicitlyOwnGroupForFixture(config, existing.parentGroup);
            ManagedAddressableSynchronizer.Sync(config, false);
            Assert.AreEqual("UI", Entry(local).parentGroup.Name);
            Assert.AreEqual("LocalItem", Entry(local).address);
            Assert.AreEqual("Remote_Model", Entry(remote).parentGroup.Name);
            Assert.AreEqual("published-key", Entry(remote).address);
            CollectionAssert.Contains(Entry(remote).labels, "keep-label");
            Assert.AreEqual("Remote_Boot", Entry(second).parentGroup.Name);
            Assert.AreEqual(ManagedAddressableProfileUtility.RemoteBuildPath, settings.profileSettings.GetProfileDataById(Entry(second).parentGroup.GetSchema<BundledAssetGroupSchema>().BuildPath.Id).ProfileName);
            Assert.AreEqual(officialDefaultBefore, ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault));
            CollectionAssert.DoesNotContain(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(officialDefault)));
            foreach (string path in new[] { local, remote, second })
                CollectionAssert.Contains(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Entry(path).parentGroup)));
            CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config));
        }

        [Test]
        public void SameGuidRepeatedSyncIsIdempotent()
        {
            string path = Text("Content/Local/UI/Item");
            ManagedAddressableSynchronizer.Sync(config, false);
            string guid = Entry(path).guid;
            byte[] meta = File.ReadAllBytes(path + ".meta");
            ManagedAddressableSyncReport again = ManagedAddressableSynchronizer.Sync(config, false);
            Assert.AreEqual(0, again.createdGroups + again.addedEntries + again.movedEntries + again.changedAddresses);
            Assert.AreEqual(1, settings.groups.Where(g => g != null).SelectMany(g => g.entries).Count(e => e.guid == guid));
            CollectionAssert.AreEqual(meta, File.ReadAllBytes(path + ".meta"));
        }

        [Test]
        public void NewConfigDefaultsToFileNameNaming()
        {
            Assert.AreEqual(ManagedAddressNamingMode.FileName, config.addressNaming);
        }

        [Test]
        public void FileNameNamingLeavesSubFoldersOutOfAddressesAndGroups()
        {
            string boss = Text("Content/Remote/Character/Enemies/Boss");
            string hooligan = Text("Content/Local/Character/UI/Enemy/Common/Hooligan");
            string extra = Text("Content/Remote/Character/Update/Pack1/Skins/Extra");
            ManagedAddressableSyncPlan plan = ManagedAddressableSynchronizer.CreatePlan(config);
            CollectionAssert.IsEmpty(plan.Errors);
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreEqual("Boss", Entry(boss).address);
            Assert.AreEqual("Remote_Character", Entry(boss).parentGroup.Name);
            Assert.AreEqual("Hooligan", Entry(hooligan).address);
            Assert.AreEqual("Character", Entry(hooligan).parentGroup.Name);
            Assert.AreEqual("Extra", Entry(extra).address);
            Assert.AreEqual("Remote_Character_Pack1", Entry(extra).parentGroup.Name);
        }

        [TestCase(false)]
        [TestCase(true)]
        public void FileNameNamingDuplicateIsReportedWithEveryPathAndThoseFilesStayUnchanged(bool preview)
        {
            string a = Text("Content/Local/UI/Shared");
            string b = Text("Content/Remote/Model/Sub/Shared");
            string other = Text("Content/Local/UI/Other");
            ManagedAddressableSyncPlan plan = null;
            Assert.DoesNotThrow(() => plan = ManagedAddressableSynchronizer.CreatePlan(config));
            Assert.AreEqual(1, plan.Errors.Count, string.Join("\n", plan.Errors));
            StringAssert.Contains("'Shared'", plan.Errors[0]);
            StringAssert.Contains(a, plan.Errors[0]);
            StringAssert.Contains(b, plan.Errors[0]);
            Assert.AreEqual(2, plan.Report.addressConflicts);
            Assert.IsTrue(plan.Report.messages.Any(m => m.StartsWith("[Error] Duplicate Address 'Shared'", StringComparison.Ordinal)), plan.Report.ToString());
            Assert.IsTrue(plan.CanApply, "A conflict leaves only the named files out; the rest of the plan still applies.");
            if (preview) return;
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.IsNull(Entry(a));
            Assert.IsNull(Entry(b));
            Assert.AreEqual("Other", Entry(other).address);
            Assert.IsNull(settings.FindGroup("Remote_Model"), "A conflicting file must not leave an empty new Group.");
        }

        [Test]
        public void FileNameNamingConflictDoesNotRenameARegisteredFile()
        {
            string a = Text("Content/Local/UI/Shared");
            ManagedAddressableSynchronizer.Sync(config, false);
            Assert.AreEqual("Shared", Entry(a).address);
            Entry(a).SetAddress("published-shared");
            string b = Text("Content/Remote/Model/Shared");
            foreach (bool rebuild in new[] { false, true })
            {
                ManagedAddressableSyncPlan plan = ManagedAddressableSynchronizer.CreatePlan(config, rebuild);
                Assert.AreEqual(1, plan.Errors.Count, "rebuild=" + rebuild);
                StringAssert.Contains(a, plan.Errors[0]);
                StringAssert.Contains(b, plan.Errors[0]);
                ManagedAddressableSynchronizer.ApplyPlan(config, plan);
                Assert.AreEqual("published-shared", Entry(a).address, "rebuild=" + rebuild);
                Assert.IsNull(Entry(b), "rebuild=" + rebuild);
            }
        }

        [Test]
        public void FileNameNamingRebuildDoesNotDependOnPathOrder()
        {
            string a = Text("Content/Local/UI/Alpha");
            string b = Text("Content/Local/UI/Sub/Beta");
            ManagedAddressableSynchronizer.Sync(config, false);
            Entry(a).SetAddress("UI_Alpha");
            Entry(b).SetAddress("Alpha"); // Beta holds Alpha's new address and is processed after it.
            ManagedAddressableSyncPlan plan = ManagedAddressableSynchronizer.CreatePlan(config, true);
            CollectionAssert.IsEmpty(plan.Errors, plan.Report.ToString());
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreEqual("Alpha", Entry(a).address);
            Assert.AreEqual("Beta", Entry(b).address);
        }

        [Test]
        public void FileNameNamingRebuildKeepsAHolderWhoseOwnNameConflicts()
        {
            string a = Text("Content/Local/UI/A");
            string h = Text("Content/Local/UI/B");
            ManagedAddressableSynchronizer.Sync(config, false);
            Entry(a).SetAddress("old-a");
            Entry(h).SetAddress("A"); // H holds A's new address but cannot move: its own name B conflicts below.
            string other = Text("Content/Remote/X/B");
            ManagedAddressableSyncPlan plan = ManagedAddressableSynchronizer.CreatePlan(config, true);
            Assert.AreEqual(2, plan.Errors.Count, plan.Report.ToString());
            Assert.IsTrue(plan.Errors.Any(e => e.Contains("'B'") && e.Contains(h) && e.Contains(other)), plan.Report.ToString());
            Assert.IsTrue(plan.Errors.Any(e => e.Contains("'A'") && e.Contains(a) && e.Contains(h)), plan.Report.ToString());
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreEqual("old-a", Entry(a).address);
            Assert.AreEqual("A", Entry(h).address);
            Assert.IsNull(Entry(other));
            Assert.DoesNotThrow(() => ManagedAddressableSynchronizer.CreatePlan(config, true));
        }

        [Test]
        public void FileNameNamingReportsAnAddressHeldOutsideTheContentRoot()
        {
            string outside = root + "/Outside/Boss.txt";
            Directory.CreateDirectory(Path.GetDirectoryName(outside));
            File.WriteAllText(outside, "synthetic framework validation");
            AssetDatabase.Refresh();
            AddressableAssetGroup owned = Group("Owned Outside");
            ManagedAR2G2IntegrationTests.ExplicitlyOwnGroupForFixture(config, owned);
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(outside), owned).SetAddress("Boss");
            string boss = Text("Content/Remote/Character/Enemies/Boss");
            ManagedAddressableSyncPlan plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.AreEqual(1, plan.Errors.Count, plan.Report.ToString());
            StringAssert.Contains(outside, plan.Errors[0]);
            StringAssert.Contains(boss, plan.Errors[0]);
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.IsNull(Entry(boss));
            Assert.AreEqual("Boss", Entry(outside).address);
            Assert.IsNull(settings.FindGroup("Remote_Character"), "A conflicting file must not leave an empty new Group.");
        }

        [Test]
        public void PathNamingKeepsTheFolderAddress()
        {
            config.addressNaming = ManagedAddressNamingMode.Path;
            config.ignorePathPrefixes = new List<string>();
            string guide = Text("Content/Local/UI/Tutorial/Guide");
            string boss = Text("Content/Remote/Character/Enemies/Boss");
            ManagedAddressableSyncPlan plan = ManagedAddressableSynchronizer.CreatePlan(config);
            CollectionAssert.IsEmpty(plan.Errors);
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreEqual("Tutorial_Guide", Entry(guide).address);
            Assert.AreEqual("Enemies_Boss", Entry(boss).address);
            Assert.AreEqual("Remote_Character", Entry(boss).parentGroup.Name);
        }

        [TestCase(false)]
        [TestCase(true)]
        public void PathNamingDuplicateNewKeyFailsBeforeAnyWrite(bool preview)
        {
            config.addressNaming = ManagedAddressNamingMode.Path;
            Text("Content/Local/UI/Shared");
            Text("Content/Remote/Model/Shared");
            AssetDatabase.SaveAssets();
            var before = Files(root);
            string profile = settings.activeProfileId;
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.Sync(config, preview));
            CollectionAssert.AreEquivalent(before, Files(root));
            Assert.AreEqual(profile, settings.activeProfileId);
        }

        [Test]
        public void PathNamingUniquePolicyUsesStableGuidSuffixAndPreservesPublishedDuplicateResolution()
        {
            config.addressNaming = ManagedAddressNamingMode.Path;
            AddressableAssetGroup officialDefault = settings.DefaultGroup;
            string officialDefaultBefore = ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault);
            string a = Text("Content/Local/UI/Shared");
            string b = Text("Content/Remote/Model/Shared");
            config.ensureUnique = true;
            ManagedAddressableSynchronizer.Sync(config, false);
            Assert.AreEqual("Shared", Entry(a).address);
            Assert.AreEqual("Shared#" + AssetDatabase.AssetPathToGUID(b).Substring(0, 8), Entry(b).address);
            string address = Entry(b).address;
            ManagedAddressableSynchronizer.Sync(config, false);
            Assert.AreEqual(address, Entry(b).address);
            Assert.AreEqual(officialDefaultBefore, ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault));
            CollectionAssert.DoesNotContain(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(officialDefault)));
            CollectionAssert.Contains(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Entry(b).parentGroup)));
            CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config));
        }

        [Test]
        public void PreviewMatchesApplyAndDoesNotCreateSettingsWhenMissing()
        {
            Text("Content/Local/UI/First");
            Text("Content/Local/UI/Second");
            AssetDatabase.SaveAssets();
            var before = Files(root);
            DefaultField.SetValue(null, null);
            ManagedAddressableSyncReport absentPreview = ManagedAddressableSynchronizer.Sync(config, true);
            Assert.IsNull(AddressableAssetSettingsDefaultObject.Settings);
            Assert.AreEqual(2, absentPreview.addedEntries);
            DefaultField.SetValue(null, settings);
            ManagedAddressableSyncReport preview = ManagedAddressableSynchronizer.Sync(config, true);
            CollectionAssert.AreEquivalent(before, Files(root));
            ManagedAddressableSyncReport apply = ManagedAddressableSynchronizer.Sync(config, false);
            Assert.AreEqual(preview.createdGroups, apply.createdGroups);
            Assert.AreEqual(preview.addedEntries, apply.addedEntries);
            Assert.AreEqual(preview.movedEntries, apply.movedEntries);
            Assert.AreEqual(preview.changedAddresses, apply.changedAddresses);
            foreach (string message in preview.messages) CollectionAssert.Contains(apply.messages, message);
        }

        [Test]
        public void SavedConfigReloadKeepsPoliciesAndBytes()
        {
            config.categoryRules.Add(new ManagedCategoryRule { relativePath = "Local/UI", groupStrategy = ManagedGroupStrategy.SingleGroup, bundleMode = BundledAssetGroupSchema.BundlePackingMode.PackSeparately });
            config.preserveExistingAddressesOnSync = false;
            AssetDatabase.CreateAsset(config, root + "/Config.asset");
            AssetDatabase.SaveAssets();
            byte[] bytes = File.ReadAllBytes(root + "/Config.asset");
            AssetDatabase.ImportAsset(root + "/Config.asset", ImportAssetOptions.ForceUpdate);
            config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(root + "/Config.asset");
            Assert.AreEqual(root + "/Content", config.ContentRootPath);
            Assert.IsFalse(config.preserveExistingAddressesOnSync);
            Assert.AreEqual(ManagedGroupStrategy.SingleGroup, config.categoryRules[0].groupStrategy);
            CollectionAssert.AreEqual(bytes, File.ReadAllBytes(root + "/Config.asset"));
        }

        [Test]
        public void ReadOnlyGroupIsRejectedWithoutChangingAssets()
        {
            Text("Content/Local/UI/Item");
            var group = settings.CreateGroup("UI", false, true, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
            ManagedAR2G2IntegrationTests.ExplicitlyOwnGroupForFixture(config, group);
            AssetDatabase.SaveAssets();
            var before = Files(root);
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.Sync(config, false));
            CollectionAssert.AreEquivalent(before, Files(root));
        }

        [Test]
        public void UnownedReadOnlyGroupIsPreservedWithAWarningAndNoWrites()
        {
            string path = Text("Content/Local/UI/Item");
            settings.CreateGroup("UI", false, true, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
            AssetDatabase.SaveAssets();
            var before = Files(root);
            ManagedAddressableSyncReport report = null;
            Assert.DoesNotThrow(() => report = ManagedAddressableSynchronizer.Sync(config, false));
            Assert.IsTrue(report.messages.Any(message => message.Contains("External target Group preserved: UI")), report.ToString());
            CollectionAssert.AreEquivalent(before, Files(root));
            Assert.IsNull(Entry(path), "An unowned target is not registered into.");
            CollectionAssert.IsEmpty(ManagedAR2G2IntegrationTests.Owned(config));
        }

        [Test]
        public void InvalidRootCannotCreateSettingsOrChangeExistingContent()
        {
            Text("Outside/Keep");
            var before = Files(root);
            config.SetContentRoot("Assets/../Packages");
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.Sync(config, false));
            CollectionAssert.AreEquivalent(before, Files(root));
        }

        [TestCase("../outside-backup")]
        [TestCase("Assets/Backup")]
        public void UnsafeBackupPathIsRejectedBeforeSettingsChange(string path)
        {
            Text("Content/Local/UI/Item");
            config.backupBeforeApply = true;
            config.backupRoot = path;
            AssetDatabase.SaveAssets();
            var before = Files(root);
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.Sync(config, false));
            CollectionAssert.AreEquivalent(before, Files(root));
        }

        [Test]
        public void ExistingDuplicateKeyIsDiagnosedAndSyncCannotHideIt()
        {
            string a = Text("Outside/A");
            string b = Text("Outside/B");
            var group = Group("Published");
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(a), group).SetAddress("collision");
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(b), group).SetAddress("collision");
            ManagedAR2G2IntegrationTests.ExplicitlyOwnGroupForFixture(config, group);
            Assert.IsTrue(ManagedAddressableValidator.Validate(config).Any(e => e.Contains("중복 Address: collision")));
            AssetDatabase.SaveAssets();
            var before = Files(root);
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.Sync(config, false));
            CollectionAssert.AreEquivalent(before, Files(root));
        }

        [Test]
        public void DuplicateOnlyInsideAnUnownedGroupIsPreservedWithAWarningAndNoWrites()
        {
            string a = Text("Content/Local/UI/A");
            string b = Text("Content/Local/UI/B");
            var group = Group("Published");
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(a), group).SetAddress("collision");
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(b), group).SetAddress("collision");
            CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config));
            AssetDatabase.SaveAssets();
            var before = Files(root);
            ManagedAddressableSyncReport report = null;
            Assert.DoesNotThrow(() => report = ManagedAddressableSynchronizer.Sync(config, false));
            Assert.IsTrue(report.messages.Any(message => message.Contains("External Entry preserved: " + a)), report.ToString());
            Assert.IsTrue(report.messages.Any(message => message.Contains("External Entry preserved: " + b)), report.ToString());
            CollectionAssert.AreEquivalent(before, Files(root));
            Assert.AreEqual("collision", Entry(a).address);
            Assert.AreEqual("collision", Entry(b).address);
            Assert.AreSame(group, Entry(a).parentGroup);
            CollectionAssert.IsEmpty(ManagedAR2G2IntegrationTests.Owned(config));
        }

    }

    public sealed class ManagedFrameworkRestartTests
    {
        [Test]
        public void SavedConfigurationGroupsGuidAndAddressSurviveSeparateEditorProcesses()
        {
            const string root = "Assets/ManagedFrameworkRestartFixture";
            const string evidence = "Library/ManagedFrameworkRestartEvidence.json";
            AddressableAssetSettings previous = AddressableAssetSettingsDefaultObject.Settings;
            ManagedFrameworkHostTests.ImportCallback(previous, false);
            var field = typeof(AddressableAssetSettingsDefaultObject).GetField("s_DefaultSettingsObject", BindingFlags.Static | BindingFlags.NonPublic);
            AddressableAssetSettings settings = null;
            try
            {
                bool first = !File.Exists(evidence);
                if (first)
                {
                    Directory.CreateDirectory(root + "/Content/Local/UI");
                    File.WriteAllText(root + "/Content/Local/UI/Restart.txt", "synthetic persistent fixture");
                    AssetDatabase.Refresh();
                    settings = AddressableAssetSettings.Create(root + "/Settings", "Settings", false, true);
                    settings.CreateGroup("Default", true, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
                    ManagedAddressableProjectConfig created = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
                    created.SetContentRoot(root + "/Content");
                    created.backupBeforeApply = false;
                    AssetDatabase.CreateAsset(created, root + "/Config.asset");
                }
                settings = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(root + "/Settings/Settings.asset");
                field.SetValue(null, settings);
                var config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(root + "/Config.asset");
                Assert.AreEqual(root + "/Content", config.ContentRootPath);
                ManagedAddressableSynchronizer.Sync(config, false);
                AssetDatabase.SaveAssets();
                string guid = AssetDatabase.AssetPathToGUID(root + "/Content/Local/UI/Restart.txt");
                var entry = settings.FindAssetEntry(guid);
                string current = JsonUtility.ToJson(new RestartEvidence { guid = guid, address = entry.address, groupGuid = entry.parentGroup.Guid, configGuid = AssetDatabase.AssetPathToGUID(root + "/Config.asset") });
                if (first) File.WriteAllText(evidence, current);
                else Assert.AreEqual(File.ReadAllText(evidence), current, "Persisted GUIDs and published key must survive a new Unity process.");
                TestContext.WriteLine(first ? "RESTART_FIXTURE_CREATED" : "RESTART_FIXTURE_VERIFIED_IN_NEW_PROCESS");
                Assert.IsTrue(AppDomain.CurrentDomain.GetAssemblies().Any(a => a.GetName().Name == "RunnerBase.Runtime"));
                Assert.IsTrue(AppDomain.CurrentDomain.GetAssemblies().Any(a => a.GetName().Name == "RunnerBase.Editor"));
                Assert.IsTrue(AppDomain.CurrentDomain.GetAssemblies().Any(a => a.GetName().Name == "RunnerBase.Editor.Addressables"));
            }
            finally
            {
                ManagedFrameworkHostTests.ImportCallback(settings, false);
                field.SetValue(null, previous);
                ManagedFrameworkHostTests.ImportCallback(previous, true);
            }
        }

        [Serializable]
        private sealed class RestartEvidence { public string guid; public string address; public string groupGuid; public string configGuid; }
    }
}
