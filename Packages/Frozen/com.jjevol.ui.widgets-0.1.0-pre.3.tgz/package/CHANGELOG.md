# Changelog

## 0.1.0-pre.3 - 2026-11-21

- `AnimatedGauge`의 채움·잔상·앞선 막대가 Filled Image 대신 Slider도 받는다(새 직렬화 필드 `fillSlider`·`trailSlider`·`leadSlider`). Slider와 Sliced Fill로 만든 디자이너 게이지를 모양을 바꾸지 않고 쓴다. 막대마다 Image가 있으면 Image(`fillAmount`), 없으면 Slider(`normalizedValue`를 변경 알림 없이)를 쓴다. Slider 막대는 입력을 끄고(전환 없음·`interactable` 끔·탐색 없음) 잔상·앞선 막대 알파는 Slider fill rect의 Graphic에 준다. 기존 Image 필드·동작·laps·`OnLapCompleted`·`SetInstant`·`GaugeTiming`은 그대로다(Framework 요청, 중앙 요청 d64ea1d42298).

## 0.1.0-pre.2 - 2026-11-20

- 깨짐: `CountdownText.UtcNow`를 없앴다. 남은 시간의 믿을 시계는 `UIDisplayOptions.UtcNow`(`com.jjevol.ui.contracts@0.1.0-pre.5`)다(사용자 결정 2026-11-20 「ui.contracts 중립 설정」·「uGUI도 맞춤」).
- `AnimatedNumberText`·`CooldownOverlay`·`CountdownText`가 문화권·숫자 표기·로케일 변경 알림을 `UIDisplayOptions`에서 읽는다. UI Toolkit 위젯·재화 라벨과 같은 설정이다. 표시는 그대로다.

## 0.1.0-pre.1 - 2026-11-20

- New package (사용자 요청 2026-11-20: 애니메이트 슬라이더 게이지와 숫자 레이블, 토스트 메시지, 버튼 애니메이션, 그 밖의 위젯. 결정: uGUI·UI Toolkit 양쪽, 새 widgets 패키지, 자체 경량 트윈). 정크버스터즈 `UIAnimateSlider`·`DisplaySlider`·`UIButtonHoldRepeat`를 참고만 하고 DOTween 없이 새로 짰다.
- `AnimatedNumberText`, `AnimatedGauge`, `ToastPresenter`·`ToastView`, `ButtonFeedback`, `HoldRepeatButton`, `CooldownOverlay`, `CountdownText`, `AttentionPulse`, `TypewriterText`. 상태와 계산은 `com.jjevol.ui.contracts@0.1.0-pre.4` 위젯 모델을 쓴다.
