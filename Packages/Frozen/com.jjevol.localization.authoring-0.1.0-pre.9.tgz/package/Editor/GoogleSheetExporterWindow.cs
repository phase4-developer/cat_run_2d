// Assets/Common/Script/Localization/Editor/GoogleSheetExporterWindow.cs
#if UNITY_EDITOR
// Newtonsoft.Json
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.Localization;
using UnityEditor.Localization.Plugins.CSV;
using UnityEngine;
// Localization
using UnityEngine.Localization;
using UnityEngine.Localization.Pseudo;
using UnityEngine.Localization.Tables;
using UnityEngine.Networking;

public class GoogleSheetLocImporterWindow : EditorWindow
{
    private const string LocalizationAddressableLabel = "Localization";

    [Header("Google Sheet")]
    [SerializeField] private string spreadsheetUrlOrId = jjevol.CommonDataToolSettings.Current.LocalizationSpreadsheet;
    [SerializeField] private string googleApiKey = jjevol.CommonDataToolSettings.Current.GoogleApiKey;           // Optional: 시트 목록 자동 조회
    [SerializeField] private string manualSheetNames = "";       // 수동: "UI,Shop,Items"

    [Header("Export Options")]
    [SerializeField] private bool exportAsTsv = true;         // true: TSV, false: CSV
    [SerializeField] private bool addUtf8Bom = true;           // Windows/Excel 호환 ↑
    [SerializeField] private bool autoCreateLocalesFromHeader = true;
    [SerializeField] private bool strictLocaleCheck = false; // 헤더 언어코드가 컬렉션/프로젝트에 없으면 에러 중단

    [Header("Paths (under Assets/)")]
    [SerializeField] private string outputFolder = jjevol.CommonDataToolSettings.Current.LocalizationInputDirectory;
    [SerializeField] private string collectionSaveDir = jjevol.CommonDataToolSettings.Current.LocalizationOutputDirectory;

    private Vector2 _scroll;
    private readonly List<FetchedSheet> _fetchedSheets = new();
    private string _fetchedSpreadsheet;
    private string keyHeader = "Key";
    [SerializeField] private int requestTimeoutSeconds = 30;
    private CancellationTokenSource _requestCancellation;
    private Task _activeRequest;
    private int _requestGeneration;
    private bool _closed;
    private string _importStatus = "Ready";
    private ImportPlan[] _previewPlans;
    private bool _deletionConfirmed;
    internal Func<string, int, CancellationToken, Task<string>> RequestText = LocalizationEditorHttp.GetAsync;
    internal Action<string> ImportFault;
    internal Action<UnityEngine.Object> SaveAssetForImport = AssetDatabase.SaveAssetIfDirty;
    internal Func<StringTableCollection, LocaleIdentifier, StringTable> AddTableForImport = (collection, id) => collection.AddNewTable(id) as StringTable;
    private bool IsBusy => _activeRequest != null && !_activeRequest.IsCompleted;
    private void OnEnable() => _closed = false;
    private void OnDisable() { _closed = true; CancelPendingRequest(); _previewPlans = null; }
    private void CancelPendingRequest() { ++_requestGeneration; _requestCancellation?.Cancel(); }
    private Task StartOperation(Func<int, CancellationToken, Task> operation)
    {
        if (IsBusy) return _activeRequest;
        if (LocalizationImportTransaction.RecoveryRequired) throw new InvalidOperationException("RecoveryRequired: explicitly recover the previous import before retrying.");
        _requestCancellation = new CancellationTokenSource();
        int generation = ++_requestGeneration;
        return _activeRequest = RunOperation(operation, generation, _requestCancellation);
    }
    private async Task RunOperation(Func<int, CancellationToken, Task> operation, int generation, CancellationTokenSource cancellation)
    {
        _importStatus = "Downloading";
        try
        {
            await operation(generation, cancellation.Token);
            EnsureCurrent(generation, cancellation.Token);
            _importStatus = _previewPlans != null ? "PreviewReady" : "Completed";
        }
        catch (OperationCanceledException) { if (!_closed) _importStatus = "Cancelled"; }
        catch (Exception error)
        {
            if (!_closed && generation == _requestGeneration)
            {
                _importStatus = LocalizationImportTransaction.RecoveryRequired ? "RecoveryRequired" : "Failed";
                Debug.LogError(LocalizationHttpDiagnostics.ForDisplay(error, googleApiKey));
            }
        }
        finally
        {
            if (ReferenceEquals(_requestCancellation, cancellation)) _requestCancellation = null;
            cancellation.Dispose();
            if (!_closed) Repaint();
        }
    }
    private void EnsureCurrent(int generation, CancellationToken cancellation)
    {
        cancellation.ThrowIfCancellationRequested();
        if (_closed || generation != _requestGeneration) throw new OperationCanceledException();
    }
    private void RecoverImport() => _importStatus = LocalizationImportTransaction.Recover() ? "Ready" : "RecoveryRequired";

    [MenuItem("Custom/Localization/Google Sheet/Download & Import")]
    public static void ShowWindow()
    {
        var w = GetWindow<GoogleSheetLocImporterWindow>("Google Sheet → Localization");
        w.minSize = new Vector2(640, 520);
        w.Show();
    }

    private void OnGUI()
    {
        EditorGUILayout.LabelField("Import state", LocalizationImportTransaction.RecoveryRequired ? "RecoveryRequired" : _importStatus);
        if (IsBusy)
        {
            EditorGUILayout.HelpBox("All requested sheets are prepared before any asset is changed.", MessageType.Info);
            if (GUILayout.Button("Cancel request")) CancelPendingRequest();
            return;
        }
        if (LocalizationImportTransaction.RecoveryRequired)
        {
            EditorGUILayout.HelpBox("The previous import is uncertain. New imports are blocked. Recovery only restores recorded assets whose ownership still matches; uncertain hard interruptions require manual review.", MessageType.Error);
            if (GUILayout.Button("Recover recorded import")) RecoverImport();
            return;
        }
        if (_previewPlans != null)
        {
            DrawPreview();
            return;
        }
        requestTimeoutSeconds = Mathf.Clamp(EditorGUILayout.IntField("HTTP timeout (seconds)", requestTimeoutSeconds), 1, 300);
        using var sv = new EditorGUILayout.ScrollViewScope(_scroll);
        _scroll = sv.scrollPosition;

        EditorGUILayout.LabelField("Google Sheets → CSV/TSV → Unity Localization (Auto Import)", EditorStyles.boldLabel);
        EditorGUILayout.Space();

        spreadsheetUrlOrId = EditorGUILayout.TextField("Spreadsheet URL or ID", spreadsheetUrlOrId);
        googleApiKey = EditorGUILayout.PasswordField(new GUIContent("Google API Key (optional)", "시트 목록 자동 조회용"), googleApiKey);

        using (new EditorGUILayout.HorizontalScope())
        {
            manualSheetNames = EditorGUILayout.TextField(new GUIContent("Manual Sheets (comma)"), manualSheetNames);
            if (GUILayout.Button("Clear", GUILayout.Width(60))) manualSheetNames = "";
        }

        EditorGUILayout.Space();
        exportAsTsv = EditorGUILayout.ToggleLeft("Export as TSV (tab-separated)", exportAsTsv);
        addUtf8Bom = EditorGUILayout.ToggleLeft("Add UTF-8 BOM (Excel/Windows 권장)", addUtf8Bom);
        autoCreateLocalesFromHeader = EditorGUILayout.ToggleLeft("헤더 언어코드 자동 스캔 → 로케일 생성", autoCreateLocalesFromHeader);
        strictLocaleCheck = EditorGUILayout.ToggleLeft("strictLocaleCheck", strictLocaleCheck);

        EditorGUILayout.Space(6);
        DrawPathPicker("Output Folder", ref outputFolder);
        DrawPathPicker("Collection Save Dir", ref collectionSaveDir);

        EditorGUILayout.Space(6);
        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("Fetch Sheets (with API Key)", GUILayout.Height(28)))
                TryFetchSheets();

            GUILayout.FlexibleSpace();

            if (GUILayout.Button("Download & Preview", GUILayout.Height(38)))
                DownloadAndPreview();
        }

        if (_fetchedSheets.Count > 0)
        {
            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("Fetched Sheets (checked sheets are imported):", EditorStyles.boldLabel);
                if (GUILayout.Button("All", GUILayout.Width(60))) foreach (var sheet in _fetchedSheets) sheet.Selected = true;
                if (GUILayout.Button("None", GUILayout.Width(60))) foreach (var sheet in _fetchedSheets) sheet.Selected = false;
            }
            foreach (var sheet in _fetchedSheets) sheet.Selected = EditorGUILayout.ToggleLeft(sheet.Title, sheet.Selected);
        }

        EditorGUILayout.Space();
        EditorGUILayout.HelpBox(
            "- URL/ID와 API Key로 시트 목록을 조회해 체크한 시트만 받거나, Manual Sheets에 시트명을 직접 입력하세요.\n" +
            "- 시트를 받아 Key 추가·삭제 수를 먼저 보여 줍니다. 이 단계에서는 자산을 바꾸지 않습니다.\n" +
            "- Apply를 누르면 각 시트를 CSV/TSV로 저장하고 시트명과 동일한 컬렉션을 전체 교체합니다.\n" +
            "- 헤더(ko, en, ja 등)에서 언어코드 추출하여 로케일 자동 생성(옵션).\n" +
            "- 임포트 후 Unity Localization Addressable Entry를 갱신하고 StringTable에 Localization 레이블을 지정합니다.\n" +
            "- 실제 그룹/패킹 정책은 Managed Addressables SYNC에서 정리합니다.", MessageType.Info);
    }

    // Nothing here writes. Apply stays outside this OnGUI pass because it runs synchronous asset imports.
    private void DrawPreview()
    {
        EditorGUILayout.HelpBox("Preview only: no asset has changed. Apply replaces each collection with its sheet.", MessageType.Info);
        using var sv = new EditorGUILayout.ScrollViewScope(_scroll);
        _scroll = sv.scrollPosition;
        foreach (var plan in _previewPlans)
            EditorGUILayout.HelpBox(plan.Impact.Describe(), plan.Impact.RequiresConfirmation ? MessageType.Warning : MessageType.None);
        bool confirmationRequired = _previewPlans.Any(plan => plan.Impact.RequiresConfirmation);
        if (confirmationRequired)
            _deletionConfirmed = EditorGUILayout.ToggleLeft("I reviewed the keys above and want them deleted.", _deletionConfirmed);
        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("Discard Preview", GUILayout.Height(30))) DiscardPreview();
            using (new EditorGUI.DisabledScope(confirmationRequired && !_deletionConfirmed))
            {
                if (GUILayout.Button("Apply", GUILayout.Height(30)))
                {
                    bool confirmed = _deletionConfirmed;
                    EditorApplication.delayCall += () => { if (this && _previewPlans != null) ApplyPreview(confirmed); };
                }
            }
        }
    }

    // ---------------- Path pickers ----------------
    private void DrawPathPicker(string label, ref string assetPath)
    {
        using (new EditorGUILayout.HorizontalScope())
        {
            EditorGUILayout.PrefixLabel(label);
            if (GUILayout.Button(assetPath, EditorStyles.objectField))
            {
                var selected = EditorUtility.OpenFolderPanel("Select Folder (Must be under Assets/)", Application.dataPath, "");
                if (!string.IsNullOrEmpty(selected))
                {
                    if (selected.StartsWith(Application.dataPath))
                        assetPath = "Assets" + selected.Substring(Application.dataPath.Length);
                    else
                        EditorUtility.DisplayDialog("경고", "Assets/ 내부 폴더를 선택해주세요.", "OK");
                }
            }
        }
    }

    // ---------------- Fetch Sheets via API ----------------
    private void TryFetchSheets() => StartOperation(FetchSheetsAsync);
    private async Task FetchSheetsAsync(int generation, CancellationToken cancellation)
    {
        string sheetId = ExtractSpreadsheetId(spreadsheetUrlOrId);
        if (string.IsNullOrEmpty(sheetId) || string.IsNullOrEmpty(googleApiKey))
            throw new InvalidOperationException("A valid spreadsheet and API key are required to fetch sheet names.");
        string url = $"https://sheets.googleapis.com/v4/spreadsheets/{sheetId}?fields=sheets(properties(sheetId,title))&key={UnityWebRequest.EscapeURL(googleApiKey)}";
        string json = await RequestText(url, requestTimeoutSeconds, cancellation);
        EnsureCurrent(generation, cancellation);
        var meta = JsonConvert.DeserializeObject<SheetMetaRoot>(json);
        var sheets = meta?.sheets?.Select(sheet => sheet?.properties).Where(properties => !string.IsNullOrEmpty(properties?.title))
            .Select(properties => new FetchedSheet { Title = properties.title, Gid = properties.sheetId }).ToList();
        if (sheets == null || sheets.Count == 0) throw new InvalidDataException("No sheet names were returned.");
        _fetchedSheets.Clear(); _fetchedSheets.AddRange(sheets); _fetchedSpreadsheet = sheetId;
    }

    private void DownloadAndPreview() => StartOperation(DownloadAllAsync);
    private void DiscardPreview() { _previewPlans = null; _deletionConfirmed = false; _importStatus = "Ready"; }
    private void ApplyPreview(bool deletionConfirmed) => StartOperation((generation, cancellation) =>
    {
        var plans = _previewPlans ?? throw new InvalidOperationException("Preview the sheets before applying them.");
        if (!deletionConfirmed && plans.Any(plan => plan.Impact.RequiresConfirmation))
            throw new InvalidOperationException("Confirm the reported key deletion before applying this preview.");
        // A preview authorizes one attempt on the state it reported; any failure needs a new review.
        _previewPlans = null;
        foreach (var plan in plans)
        {
            var current = ExistingKeyIds(LocalizationEditorSettings.GetStringTableCollection(plan.Name));
            if (current.Count != plan.ExistingIds.Count || current.Any(pair => !plan.ExistingIds.TryGetValue(pair.Key, out long id) || id != pair.Value))
                throw new InvalidDataException("The collection changed after Preview. Preview it again before applying: " + plan.Name);
        }
        _importStatus = "Applying";
        ApplyPrepared(plans, cancellation);
        return Task.CompletedTask;
    });
    private async Task DownloadAllAsync(int generation, CancellationToken cancellation)
    {
        string sheetId = ExtractSpreadsheetId(spreadsheetUrlOrId);
        if (string.IsNullOrEmpty(sheetId)) throw new InvalidOperationException("A valid spreadsheet is required.");
        // A gid means nothing in another spreadsheet, and an unknown one can return the wrong sheet.
        if (_fetchedSheets.Count != 0 && _fetchedSpreadsheet != sheetId) throw new InvalidOperationException("The spreadsheet changed after Fetch Sheets. Fetch the sheet list again.");
        var targets = new SortedDictionary<string, long?>(StringComparer.Ordinal);
        foreach (string title in (manualSheetNames ?? "").Split(',').Select(title => title.Trim()).Where(title => title.Length != 0)) targets[title] = null;
        foreach (var sheet in _fetchedSheets.Where(sheet => sheet.Selected)) targets[sheet.Title] = sheet.Gid;
        if (targets.Count == 0) throw new InvalidOperationException("Select at least one sheet.");
        var plans = new List<ImportPlan>();
        foreach (var target in targets)
        {
            string title = target.Key;
            string selector = target.Value.HasValue ? "gid=" + target.Value.Value.ToString(CultureInfo.InvariantCulture) : "sheet=" + UnityWebRequest.EscapeURL(title);
            string url = $"https://docs.google.com/spreadsheets/d/{sheetId}/gviz/tq?tqx=out:csv&{selector}";
            string raw = await RequestText(url, requestTimeoutSeconds, cancellation);
            EnsureCurrent(generation, cancellation);
            if (string.IsNullOrEmpty(raw)) throw new InvalidDataException("The sheet returned no data.");
            raw = StripGvizPreamble(raw);
            if (exportAsTsv) raw = ConvertCsvToTsv(raw);
            var plan = PrepareImport(raw, title, exportAsTsv);
            plan.OutputPath = LocalizationImportTransaction.AssetPath(Path.Combine(outputFolder, MakeSafeFileName(title) + (exportAsTsv ? ".tsv" : ".csv")));
            byte[] content = Encoding.UTF8.GetBytes(raw);
            plan.OutputBytes = addUtf8Bom ? Encoding.UTF8.GetPreamble().Concat(content).ToArray() : content;
            plans.Add(plan);
        }
        EnsureCurrent(generation, cancellation);
        _deletionConfirmed = false;
        _previewPlans = plans.ToArray();
    }

    // gviz가 붙이는 XSSI 프리앰블/JS 래퍼 라인 제거
    private static string StripGvizPreamble(string s)
    {
        if (string.IsNullOrEmpty(s)) return s;

        var sb = new StringBuilder(s.Length);
        using (var sr = new StringReader(s))
        {
            string line;
            bool wroteAny = false;
            bool inPreamble = true;

            while ((line = sr.ReadLine()) != null)
            {
                var t = line.TrimStart();

                // 대표적인 불필요 줄: /*O_o*/, )]}', 그리고 JS 래퍼 시작
                // 첫 레코드 이후의 같은 문자열은 번역 데이터다.
                if (inPreamble && (t.StartsWith("/*O_o*/") ||
                    t.StartsWith(")]}'") ||
                    t.StartsWith("google.visualization.Query.setResponse")))
                {
                    continue; // 스킵
                }
                if (t.Length != 0) inPreamble = false;

                if (wroteAny) sb.Append('\n');
                sb.Append(line);
                wroteAny = true;
            }
        }
        return sb.ToString();
    }

    // CSV → TSV 변환기
    // - RFC4180 파서로 CSV를 안전하게 읽은 뒤, 탭 구분 형식으로 재직렬화
    // - 필드에 탭/개행/따옴표가 있으면 따옴표로 감싸고 내부 따옴표는 ""로 이스케이프
    private string ConvertCsvToTsv(string csvText)
    {
        var rows = ParseDelimitedLocal(csvText, ',');   // 아래 로컬 파서 이용
        var sb = new StringBuilder(csvText.Length);

        for (int r = 0; r < rows.Count; r++)
        {
            var row = rows[r];
            for (int c = 0; c < row.Length; c++)
            {
                string cell = row[c] ?? string.Empty;

                bool needQuote =
                    cell.IndexOf('\t') >= 0 ||
                    cell.IndexOf('\n') >= 0 ||
                    cell.IndexOf('\r') >= 0 ||
                    cell.IndexOf('"') >= 0;

                if (needQuote)
                {
                    sb.Append('"');
                    // 따옴표 이스케이프
                    sb.Append(cell.Replace("\"", "\"\""));
                    sb.Append('"');
                }
                else
                {
                    sb.Append(cell);
                }

                if (c < row.Length - 1) sb.Append('\t'); // TSV 구분자
            }
            if (r < rows.Count - 1) sb.Append('\n');
        }

        return sb.ToString();
    }

    // 로컬 RFC4180 파서. sep는 ',' 또는 '\t'
    private List<string[]> ParseDelimitedLocal(string text, char sepChar)
    {
        var result = new List<string[]>();
        var row = new List<string>();
        var sb = new StringBuilder();

        bool inQuotes = false;
        int i = 0;

        while (i < text.Length)
        {
            char ch = text[i];

            if (inQuotes)
            {
                if (ch == '"')
                {
                    // "" → "
                    if (i + 1 < text.Length && text[i + 1] == '"')
                    {
                        sb.Append('"');
                        i += 2;
                        continue;
                    }
                    // 인용 종료
                    inQuotes = false;
                    i++;
                    continue;
                }
                // 인용 내부 원문 유지
                sb.Append(ch);
                i++;
                continue;
            }
            else
            {
                if (ch == '"')
                {
                    inQuotes = true;
                    i++;
                    continue;
                }

                if (ch == sepChar)
                {
                    row.Add(sb.ToString());
                    sb.Length = 0;
                    i++;
                    continue;
                }

                if (ch == '\r')
                {
                    i++;
                    if (i < text.Length && text[i] == '\n') i++; // \r\n
                    row.Add(sb.ToString());
                    sb.Length = 0;
                    result.Add(row.ToArray());
                    row.Clear();
                    continue;
                }

                if (ch == '\n')
                {
                    i++;
                    row.Add(sb.ToString());
                    sb.Length = 0;
                    result.Add(row.ToArray());
                    row.Clear();
                    continue;
                }

                sb.Append(ch);
                i++;
            }
        }

        //추가
        if (inQuotes)
            throw new FormatException("Delimited input contains an unterminated quoted field.");
        //추가 종료

        // 마지막 필드/행 마무리
        row.Add(sb.ToString());
        result.Add(row.ToArray());

        return result;
    }



    private static string CleanText(string s)
    {
        if (string.IsNullOrEmpty(s)) return s;
        s = s.Trim().Trim('\uFEFF');                // BOM 제거
        s = s.Replace('\u200B', ' ')                 // zero-width space → space
             .Replace('\u00A0', ' ')                 // NBSP → space
             .Trim();

        // 양끝 큰따옴표 제거 (예: "Key" → Key)
        if (s.Length >= 2 && s[0] == '"' && s[^1] == '"')
            s = s.Substring(1, s.Length - 2).Trim();

        return s;
    }

    private static readonly HashSet<string> _ignoredHeaders = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "Key", "Comment", "Comments", "Description", "Description/Comments", "Notes", "Memo", "String ID"
    };

    // 해당 컬럼이 로케일 처리 가능한지 판단
    internal static bool IsValidLocaleColumn(string headerName)
    {
        if (string.IsNullOrWhiteSpace(headerName)) return false;
        if (IsIgnoredHeader(headerName)) return false;          // 무시할 목록 체크
        if (!LooksLikeLocaleCode(headerName)) return false;     // 언어 코드 형식인지 체크 (xx-XX 등)
        return true;
    }

    private static bool IsIgnoredHeader(string headerName)
    {
        // Indonesian Locale인 소문자 id만 허용하고 기존 메타 ID 표기는 계속 제외한다.
        if (string.Equals(headerName, "id", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(headerName, "id", StringComparison.Ordinal))
            return true;

        return _ignoredHeaders.Contains(headerName);
    }

    private sealed class LocaleHeader
    {
        public int ColumnIndex { get; }
        public string HeaderCode { get; }
        public CultureInfo Culture { get; }
        public string Code => Culture.Name;

        public LocaleHeader(int columnIndex, string headerCode, CultureInfo culture)
        {
            ColumnIndex = columnIndex;
            HeaderCode = headerCode;
            Culture = culture;
        }
    }

    // RFC4180 파싱, 헤더 로케일 처리, gviz 프리앰블 방어
    private sealed class ImportPlan
    {
        internal string Name, OutputPath;
        internal byte[] OutputBytes;
        internal List<LocaleHeader> Locales;
        internal Dictionary<string, string[]> Values;
        internal Dictionary<string, long> ExistingIds;
        internal LocalizationImportImpact Impact;
    }

    private ImportPlan PrepareImport(string raw, string collectionName, bool isTsv)
    {
        if (string.IsNullOrWhiteSpace(collectionName) || collectionName != collectionName.Trim()
            || collectionName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || (collectionName.Contains('[') && collectionName.Contains(']')))
            throw new InvalidDataException("Invalid collection name.");
        var rows = ParseDelimitedLocal(StripGvizPreamble(raw), isTsv ? '\t' : ',');
        if (rows.Count == 0 || rows[0].Length == 0) throw new InvalidDataException("A header is required.");
        var header = rows[0].Select(CleanText).ToArray();
        int keyIndex = IndexOfHeader(header, keyHeader);
        if (keyIndex < 0) throw new InvalidDataException("Header must contain key column: " + keyHeader);
        var locales = ValidateLocaleHeaders(header, collectionName);
        var collection = LocalizationEditorSettings.GetStringTableCollection(collectionName);
        if (strictLocaleCheck) ValidateLocalesFromHeaderStrict(locales, collectionName, collection);
        if (!autoCreateLocalesFromHeader)
            foreach (var locale in locales)
                if (LocalizationEditorSettings.GetLocale(locale.Code) == null) throw new InvalidDataException("A requested Locale is not registered: " + locale.Code);
        var values = new Dictionary<string, string[]>(StringComparer.Ordinal);
        int emptyKeyRows = 0, emptyKeyRowsWithText = 0;
        foreach (var row in rows.Skip(1))
        {
            string key = row.Length > keyIndex ? CleanText(row[keyIndex]) : null;
            if (string.IsNullOrEmpty(key))
            {
                ++emptyKeyRows;
                if (row.Any(cell => !string.IsNullOrEmpty(CleanText(cell)))) ++emptyKeyRowsWithText;
                continue;
            }
            values[key] = locales.Select(locale => locale.ColumnIndex < row.Length ? CleanText(row[locale.ColumnIndex]) : null).ToArray();
        }
        // Full replacement would turn an empty sheet into deleting every key and key ID.
        if (values.Count == 0) throw new InvalidDataException("The sheet has no Key rows and cannot replace a collection: " + collectionName);
        var ids = ExistingKeyIds(collection);
        return new ImportPlan { Name = collectionName, Locales = locales, Values = values, ExistingIds = ids,
            Impact = new LocalizationImportImpact(collectionName, ids.Keys, values.Keys, emptyKeyRows, emptyKeyRowsWithText) };
    }

    private static Dictionary<string, long> ExistingKeyIds(StringTableCollection collection)
        => collection && collection.SharedData ? collection.SharedData.Entries.ToDictionary(entry => entry.Key, entry => entry.Id, StringComparer.Ordinal) : new Dictionary<string, long>(StringComparer.Ordinal);

    private void ImportFileToCollection(string filePath, string collectionName, bool isTsv)
    {
        string raw = File.ReadAllText(filePath, new UTF8Encoding(false, true));
        ApplyPrepared(new[] { PrepareImport(raw, collectionName, isTsv) }, CancellationToken.None);
    }

    // This boundary runs once per button request, including every selected collection.
    private void ApplyPrepared(IEnumerable<ImportPlan> prepared, CancellationToken cancellation)
    {
        var plans = prepared.ToArray();
        if (plans.Length == 0 || plans.Select(plan => plan.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != plans.Length)
            throw new InvalidDataException("A request requires unique collection names.");
        var outputs = plans.Where(plan => plan.OutputPath != null).Select(plan => plan.OutputPath).ToArray();
        if (outputs.Distinct(StringComparer.OrdinalIgnoreCase).Count() != outputs.Length) throw new InvalidDataException("Sheet output filenames collide.");
        var allLocales = plans.SelectMany(plan => plan.Locales).GroupBy(locale => locale.Code, StringComparer.OrdinalIgnoreCase).Select(group => group.First()).ToArray();
        foreach (var first in allLocales)
            foreach (var second in allLocales)
                if (IsGenericRegionalLocaleConflict(first.Code, second.Code)) throw new InvalidDataException("The request contains conflicting generic/regional Locales.");
        ValidatePlannedAssetPaths(plans);
        cancellation.ThrowIfCancellationRequested();
        var transaction = new LocalizationImportTransaction(plans.Select(plan => plan.Name), allLocales.Select(locale => locale.Code), collectionSaveDir, GetLocaleSaveDir(), outputs)
        { Fault = ImportFault, SaveAsset = SaveAssetForImport };
        using var saveProtection = transaction.ProtectSaves();
        try
        {
            EnsureFolder(collectionSaveDir);
            if (!strictLocaleCheck && autoCreateLocalesFromHeader) transaction.ExecuteSdk(() => EnsureLocalesFromHeader(allLocales));
            transaction.Observe();
            foreach (var plan in plans)
            {
                cancellation.ThrowIfCancellationRequested();
                ApplyPlan(plan, transaction, cancellation);
            }
            transaction.SaveAffected();
            foreach (var plan in plans) VerifyPlan(plan);
            // Localization's synchronous table reimport can dirty its owning collection.
            // Persist that SDK-owned connection update, then verify without reimporting it again.
            transaction.SaveAffected();
            foreach (var plan in plans) VerifyPlan(plan, false);
            foreach (var plan in plans.Where(plan => plan.OutputPath != null)) transaction.WriteOutput(plan.OutputPath, plan.OutputBytes);
            cancellation.ThrowIfCancellationRequested();
            transaction.Commit();
        }
        catch (Exception error)
        {
            if (!transaction.Rollback()) throw new InvalidOperationException("RecoveryRequired: import failed and the previous state could not be verified. New imports are blocked. Cause: "
                + LocalizationHttpDiagnostics.ForDisplay(error, googleApiKey) + "; recovery: " + LocalizationHttpDiagnostics.Sanitize(transaction.RecoveryFailure ?? "recorded state/ownership mismatch", credential: googleApiKey));
            throw;
        }
    }

    private void ValidatePlannedAssetPaths(IEnumerable<ImportPlan> plans)
    {
        // These are the exact SDK 1.5.12 collection/shared/table filenames, not adopted loose assets.
        var reserved = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        void Reserve(string path)
        {
            string assetPath = LocalizationImportTransaction.AssetPath(path);
            if (!reserved.Add(assetPath) || File.Exists(assetPath) || Directory.Exists(assetPath) || File.Exists(assetPath + ".meta"))
                throw new InvalidDataException("An unowned asset or meta conflicts with the requested Localization output: " + assetPath);
        }
        foreach (var plan in plans)
        {
            var collection = LocalizationEditorSettings.GetStringTableCollection(plan.Name);
            string directory = collection ? Path.GetDirectoryName(AssetDatabase.GetAssetPath(collection)) : collectionSaveDir;
            if (!collection)
            {
                Reserve(Path.Combine(directory, plan.Name + ".asset"));
                Reserve(Path.Combine(directory, plan.Name + " Shared Data.asset"));
            }
            foreach (var locale in plan.Locales)
                if (!collection || !collection.GetTable(new LocaleIdentifier(locale.Culture)))
                    Reserve(Path.Combine(directory, plan.Name + "_" + locale.Code + ".asset"));
        }
    }

    private void ApplyPlan(ImportPlan plan, LocalizationImportTransaction transaction, CancellationToken cancellation)
    {
        var collection = LocalizationEditorSettings.GetStringTableCollection(plan.Name);
        if (!collection)
        {
            // In SDK 1.5.12 the factory has no finally around its asset-editing scope.
            // Validated arguments reach that scope; balance it if asset creation throws.
            transaction.ExecuteSdk(() =>
            {
                ValidatePlannedAssetPaths(new[] { plan });
                try { collection = LocalizationEditorSettings.CreateStringTableCollection(plan.Name, collectionSaveDir, new List<Locale>()); }
                catch { AssetDatabase.StopAssetEditing(); throw; }
            });
            if (!collection) throw new InvalidOperationException("Collection creation failed.");
            transaction.Observe();
        }
        var tables = new List<StringTable>();
        foreach (var locale in plan.Locales)
        {
            cancellation.ThrowIfCancellationRequested();
            ImportFault?.Invoke("BeforeAddTable:" + plan.Name + ":" + locale.Code);
            var table = collection.GetTable(new LocaleIdentifier(locale.Culture)) as StringTable;
            if (!table)
            {
                transaction.ExecuteSdk(() =>
                {
                    ValidatePlannedAssetPaths(new[] { plan });
                    table = AddTableForImport(collection, new LocaleIdentifier(locale.Culture));
                }, collection);
            }
            if (!table || table.SharedData != collection.SharedData || !string.Equals(table.LocaleIdentifier.Code, locale.Code, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("A requested Locale table was not created: " + locale.Code);
            tables.Add(table);
            ImportFault?.Invoke("AfterAddTable:" + plan.Name + ":" + locale.Code);
        }
        var shared = collection.SharedData;
        if (!shared) throw new InvalidOperationException("The collection has no shared key data.");
        var keys = new HashSet<string>(plan.Values.Keys, StringComparer.Ordinal);
        foreach (var entry in shared.Entries.Where(entry => !keys.Contains(entry.Key)).ToArray())
        {
            shared.RemoveKey(entry.Id);
            foreach (var table in collection.StringTables) { table.RemoveEntry(entry.Id); EditorUtility.SetDirty(table); }
        }
        RemoveOrphanEntries(collection.StringTables, new HashSet<long>(shared.Entries.Select(entry => entry.Id)));
        foreach (var pair in plan.Values)
        {
            cancellation.ThrowIfCancellationRequested();
            for (int index = 0; index < tables.Count; ++index)
            {
                ImportFault?.Invoke("BeforeValue:" + plan.Name + ":" + plan.Locales[index].Code + ":" + pair.Key);
                var existing = shared.GetEntry(pair.Key);
                StringTableEntry entry = existing != null ? tables[index].GetEntry(existing.Id) ?? tables[index].AddEntry(existing.Id, pair.Value[index]) : tables[index].AddEntry(pair.Key, pair.Value[index]);
                if (entry == null) throw new InvalidOperationException("A requested key could not be applied.");
                entry.Value = pair.Value[index];
                EditorUtility.SetDirty(tables[index]);
            }
        }
        EditorUtility.SetDirty(shared); EditorUtility.SetDirty(collection);
        ImportFault?.Invoke("BeforeAddressables:" + plan.Name);
        transaction.ExecuteSdk(() => { collection.RefreshAddressables(false); EnsureLocalizationAddressableLabels(collection); });
        ImportFault?.Invoke("AfterAddressables:" + plan.Name);
        transaction.Observe();
    }

    private static void VerifyPlan(ImportPlan plan, bool reloadAssets = true)
    {
        var collection = LocalizationEditorSettings.GetStringTableCollection(plan.Name);
        if (!collection || !collection.SharedData) throw new InvalidDataException("Applied collection cannot be verified.");
        if (reloadAssets)
        {
            AssetDatabase.ImportAsset(AssetDatabase.GetAssetPath(collection.SharedData), ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
            foreach (var table in collection.StringTables)
                AssetDatabase.ImportAsset(AssetDatabase.GetAssetPath(table), ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
        }
        var keys = new HashSet<string>(plan.Values.Keys, StringComparer.Ordinal);
        if (collection.SharedData.Entries.Any(entry => !keys.Contains(entry.Key))) throw new InvalidDataException("Stale keys remain after import.");
        for (int index = 0; index < plan.Locales.Count; ++index)
        {
            var locale = plan.Locales[index];
            var table = collection.GetTable(new LocaleIdentifier(locale.Culture)) as StringTable;
            if (!table || table.SharedData != collection.SharedData || !LocalizationEditorSettings.GetLocale(locale.Code)) throw new InvalidDataException("Requested Locale connection cannot be verified.");
            foreach (var pair in plan.Values)
            {
                var shared = collection.SharedData.GetEntry(pair.Key);
                var entry = shared == null ? null : table.GetEntry(shared.Id);
                if (entry == null || entry.Value != pair.Value[index]) throw new InvalidDataException("Applied value cannot be verified.");
                if (plan.ExistingIds.TryGetValue(pair.Key, out long id) && shared.Id != id) throw new InvalidDataException("An existing key ID changed.");
            }
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(table));
            var addressable = AddressableAssetSettingsDefaultObject.Settings.FindAssetEntry(guid);
            if (addressable == null || !addressable.labels.Contains(LocalizationAddressableLabel)) throw new InvalidDataException("Applied Addressables connection cannot be verified.");
        }
    }

    internal static int RemoveOrphanEntries(IEnumerable<StringTable> tables, ISet<long> validSharedIds)
    {
        if (tables == null || validSharedIds == null)
            return 0;

        int deleted = 0;
        foreach (var table in tables.Where(table => table != null))
        {
            var orphanIds = table.Values.Where(entry => !validSharedIds.Contains(entry.KeyId)).Select(entry => entry.KeyId).ToList();
            foreach (long orphanId in orphanIds)
            {
                if (table.RemoveEntry(orphanId))
                    deleted++;
            }

            if (orphanIds.Count > 0)
                EditorUtility.SetDirty(table);
        }

        return deleted;
    }

    private static void EnsureLocalizationAddressableLabels(StringTableCollection collection)
    {
        if (collection == null)
            return;

        var settings = AddressableAssetSettingsDefaultObject.Settings;
        if (settings == null)
            throw new Exception("Addressable Settings를 찾을 수 없습니다.");

        if (!settings.GetLabels().Contains(LocalizationAddressableLabel))
            settings.AddLabel(LocalizationAddressableLabel);

        foreach (var table in collection.StringTables)
        {
            if (table == null)
                continue;

            string path = AssetDatabase.GetAssetPath(table);
            string guid = AssetDatabase.AssetPathToGUID(path);

            //추가 시작
            if (string.IsNullOrEmpty(path))
                throw new Exception("StringTable AssetPath를 찾을 수 없습니다.");

            if (string.IsNullOrEmpty(guid))
                throw new Exception($"StringTable GUID를 찾을 수 없습니다: {path}");
            //추가 종료

            var entry = settings.FindAssetEntry(guid);

            if (entry == null)
                throw new Exception($"Localization Addressable Entry를 찾을 수 없습니다: {path}");

            entry.SetLabel(LocalizationAddressableLabel, true);
        }
    }

    static int IndexOfHeader(string[] header, string name)
    {
        for (int i = 0; i < header.Length; i++)
        {
            if (string.Equals(header[i]?.Trim(), name?.Trim(), StringComparison.OrdinalIgnoreCase))
                return i;
        }
        return -1;
    }

    private static Dictionary<string, CultureInfo> GetUnityAddLocaleCultures()
    {
        return CultureInfo.GetCultures(CultureTypes.AllCultures)
            .Where(culture => culture.LCID != CultureInfo.InvariantCulture.LCID && !culture.EnglishName.Contains("Legacy"))
            .GroupBy(culture => culture.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);
    }

    internal static bool IsUnityAddLocaleSupported(string code)
    {
        if (string.IsNullOrWhiteSpace(code)) return false;
        return GetUnityAddLocaleCultures().ContainsKey(code);
    }

    private static List<LocaleHeader> ValidateLocaleHeaders(string[] header, string collectionName)
    {
        var supportedCultures = GetUnityAddLocaleCultures();
        var localeHeaders = new List<LocaleHeader>();

        for (int i = 0; i < header.Length; i++)
        {
            var code = header[i];
            if (!IsValidLocaleColumn(code)) continue;

            if (!supportedCultures.TryGetValue(code, out var culture))
            {
                FailLocaleValidation(
                    "지원하지 않는 Locale 코드입니다.",
                    $"Sheet: {collectionName}\nLocale: {code}\nUnity Add Locale에서 지원되는 Locale 코드를 사용해주세요.");
            }

            localeHeaders.Add(new LocaleHeader(i, code, culture));
        }

        if (localeHeaders.Count == 0)
            FailLocaleValidation("Locale 컬럼을 찾을 수 없습니다.", $"Sheet: {collectionName}\nHeader의 Locale 코드를 확인해주세요.");

        if (TryFindDuplicateLocaleCode(localeHeaders.Select(localeHeader => localeHeader.HeaderCode), out var duplicate, out var duplicateOf))
        {
            FailLocaleValidation(
                "Locale 코드가 중복되었습니다.",
                $"Sheet: {collectionName}\nLocale: {duplicate}\nDuplicate Locale: {duplicateOf}\n대소문자만 다른 코드도 중복으로 처리됩니다.");
        }

        for (int i = 0; i < localeHeaders.Count; i++)
        {
            for (int j = i + 1; j < localeHeaders.Count; j++)
            {
                if (!IsGenericRegionalLocaleConflict(localeHeaders[i].Code, localeHeaders[j].Code)) continue;

                FailLocaleValidation(
                    "Locale 충돌 가능성이 있습니다.",
                    $"Sheet: {collectionName}\nSheet Locale: {localeHeaders[i].HeaderCode}\nConflicting Sheet Locale: {localeHeaders[j].HeaderCode}\n동일 언어의 일반 Locale과 지역 Locale을 동시에 사용하지 않도록 Locale 코드를 확인해주세요.");
            }
        }

        var projectLocales = GetProjectLocaleAssets();
        foreach (var localeHeader in localeHeaders)
        {
            foreach (var existingLocale in projectLocales)
            {
                var existingCode = existingLocale.Identifier.Code;
                if (string.Equals(localeHeader.Code, existingCode, StringComparison.OrdinalIgnoreCase)) continue;
                if (!IsGenericRegionalLocaleConflict(localeHeader.Code, existingCode)) continue;

                FailLocaleValidation(
                    "Locale 충돌 가능성이 있습니다.",
                    $"Sheet: {collectionName}\nSheet Locale: {localeHeader.HeaderCode}\nExisting Locale: {existingCode}\n동일 언어의 일반 Locale과 지역 Locale을 동시에 사용하지 않도록 Locale 코드를 확인해주세요.");
            }
        }

        return localeHeaders;
    }

    private static List<Locale> GetProjectLocaleAssets()
    {
        var locales = LocalizationEditorSettings.GetLocales().Where(locale => locale != null).ToList();
        var knownPaths = new HashSet<string>(locales.Select(AssetDatabase.GetAssetPath), StringComparer.OrdinalIgnoreCase);

        foreach (var guid in AssetDatabase.FindAssets("t:Locale"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (knownPaths.Contains(path)) continue;

            var locale = AssetDatabase.LoadAssetAtPath<Locale>(path);
            if (locale == null || locale is PseudoLocale) continue;

            locales.Add(locale);
            knownPaths.Add(path);
        }

        return locales;
    }

    internal static bool TryFindDuplicateLocaleCode(IEnumerable<string> codes, out string duplicate, out string duplicateOf)
    {
        var seen = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var code in codes)
        {
            if (seen.TryGetValue(code, out duplicateOf))
            {
                duplicate = code;
                return true;
            }

            seen.Add(code, code);
        }

        duplicate = null;
        duplicateOf = null;
        return false;
    }

    internal static bool IsGenericRegionalLocaleConflict(string firstCode, string secondCode)
    {
        if (string.IsNullOrWhiteSpace(firstCode) || string.IsNullOrWhiteSpace(secondCode)) return false;
        if (string.Equals(firstCode, secondCode, StringComparison.OrdinalIgnoreCase)) return false;

        bool firstIsGeneric = firstCode.IndexOfAny(new[] { '-', '_' }) < 0;
        bool secondIsGeneric = secondCode.IndexOfAny(new[] { '-', '_' }) < 0;
        if (firstIsGeneric == secondIsGeneric) return false;

        string firstLanguage = firstCode.Split('-', '_')[0];
        string secondLanguage = secondCode.Split('-', '_')[0];
        return string.Equals(firstLanguage, secondLanguage, StringComparison.OrdinalIgnoreCase);
    }

    private static void FailLocaleValidation(string reason, string details)
    {
        string message = $"[Loc Import] {reason}\n{details}";
        Debug.LogWarning(message);
        EditorUtility.DisplayDialog("Localization Import 중단", message, "OK");
        throw new InvalidOperationException(message);
    }

    // === 검증된 헤더 언어코드 → 로케일 자동 생성 ===
    private bool EnsureLocalesFromHeader(IReadOnlyList<LocaleHeader> localeHeaders)
    {
        var registered = new HashSet<string>(
            LocalizationEditorSettings.GetLocales()
                .Where(l => l != null)
                .Select(l => l.Identifier.Code)
                .Distinct(),
            StringComparer.OrdinalIgnoreCase);

        var localeAssets = GetProjectLocaleAssets()
            .Where(locale => !string.IsNullOrEmpty(locale.Identifier.Code))
            .GroupBy(locale => locale.Identifier.Code, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);

        bool addedAny = false; // 추가 여부 플래그

        foreach (var localeHeader in localeHeaders)
        {
            var code = localeHeader.Code;

            if (registered.Contains(code)) continue;

            if (localeAssets.TryGetValue(code, out var existingLocale))
            {
                LocalizationEditorSettings.AddLocale(existingLocale);
                registered.Add(code);
                Debug.Log($"[Locales] Registered existing '{code}': {AssetDatabase.GetAssetPath(existingLocale)}");
                addedAny = true;
            }
            else
            {
                var locale = ScriptableObject.CreateInstance<Locale>();
                locale.name = localeHeader.Culture.EnglishName;
                locale.Identifier = new LocaleIdentifier(localeHeader.Culture);

                var localeSaveDir = GetLocaleSaveDir();
                EnsureFolder(localeSaveDir);
                var assetPath = $"{localeSaveDir}/{locale.name} ({code}).asset";
                assetPath = AssetDatabase.GenerateUniqueAssetPath(assetPath);
                AssetDatabase.CreateAsset(locale, assetPath);
                LocalizationEditorSettings.AddLocale(locale);
                registered.Add(code);
                Debug.Log($"[Locales] Added '{code}': {assetPath}");

                addedAny = true; // 뭔가가 추가됨
            }
        }

        return addedAny; // 결과 반환
    }

    private string GetLocaleSaveDir()
    {
        var normalized = collectionSaveDir.Replace('\\', '/').TrimEnd('/');
        int lastSlash = normalized.LastIndexOf('/');
        return lastSlash > 0 ? normalized.Substring(0, lastSlash) : "Assets";
    }


    // 헤더에서 언어코드 목록을 뽑아 "프로젝트 로케일 + 컬렉션 테이블" 모두 존재하는지 검증
    private static void ValidateLocalesFromHeaderStrict(IReadOnlyList<LocaleHeader> localeHeaders, string collectionName, StringTableCollection collection)
    {
        // 프로젝트에 등록된 로케일 코드 집합
        var projectLocales = new HashSet<string>(
            LocalizationEditorSettings.GetLocales()
                .Where(l => l != null)
                .Select(l => l.Identifier.Code)
                .Distinct(),
            StringComparer.OrdinalIgnoreCase);

        // 컬렉션 내 실제 테이블 존재 여부를 로케일 코드 기준으로 확인
        var missing = new List<string>();
        foreach (var localeHeader in localeHeaders)
        {
            var code = localeHeader.Code;

            // 프로젝트에 로케일이 없는 경우
            if (!projectLocales.Contains(code))
            {
                missing.Add($"{code} (프로젝트 로케일 없음)");
                continue;
            }

            // 컬렉션에 테이블이 없는 경우
            var table = collection?.GetTable(new LocaleIdentifier(localeHeader.Culture));
            if (table == null)
                missing.Add($"{code} (컬렉션 테이블 없음)");
        }

        if (missing.Count > 0)
        {
            var msg =
                "[Strict Locale Check] 다음 언어 컬럼에 해당하는 로케일/테이블이 존재하지 않아 임포트를 중단합니다.\n" +
                $"Sheet: {collectionName}\n" +
                string.Join("\n", missing.Select(m => "• " + m)) +
                "\n\n- Localization 창에서 해당 로케일과 String Table을 먼저 생성하세요.\n" +
                "- 또는 Strict 옵션을 끄고(=autoCreateLocalesFromHeader 사용) 자동 생성하도록 전환하세요.";
            Debug.LogWarning(msg);
            EditorUtility.DisplayDialog("Missing Locales/Tables", msg, "OK");
            throw new Exception("Strict Locale Check 실패");
        }
    }

    private static bool LooksLikeLocaleCode(string code)
    {
        // 지원 여부는 Unity Add Locale과 동일한 CultureInfo 목록으로 별도 검증한다.
        return Regex.IsMatch(code, @"^[A-Za-z]{2,8}(?:[-_][A-Za-z0-9]{1,8})*$", RegexOptions.CultureInvariant);
    }

    // ---------------- Helpers ----------------
    private static string ExtractSpreadsheetId(string input)
    {
        if (string.IsNullOrEmpty(input)) return null;

        const string token = "/d/";
        var idx = input.IndexOf(token, StringComparison.Ordinal);
        if (idx >= 0)
        {
            var s = idx + token.Length;
            var rest = input.Substring(s);
            var slash = rest.IndexOf('/');
            return (slash > 0) ? rest.Substring(0, slash) : rest;
        }
        if (input.Length > 20 && !input.Contains(" "))
            return input;
        return null;
    }

    private static void EnsureFolder(string assetPath)
    {
        if (AssetDatabase.IsValidFolder(assetPath)) return;
        var parts = assetPath.Split('/');
        string cur = parts[0];
        for (int i = 1; i < parts.Length; i++)
        {
            var next = $"{cur}/{parts[i]}";
            if (!AssetDatabase.IsValidFolder(next))
                AssetDatabase.CreateFolder(cur, parts[i]);
            cur = next;
        }
    }

    private static string MakeSafeFileName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var sb = new StringBuilder(name.Length);
        foreach (var ch in name) sb.Append(invalid.Contains(ch) ? '_' : ch);
        return sb.ToString();
    }

    private sealed class FetchedSheet { public string Title; public long Gid; public bool Selected = true; }

    // Google Sheets API v4 meta classes
    [Serializable] private class SheetMetaRoot { public List<SheetMeta> sheets; }
    [Serializable] private class SheetMeta { public SheetProps properties; }
    [Serializable] private class SheetProps { public string title; public long sheetId; }
}
#endif
