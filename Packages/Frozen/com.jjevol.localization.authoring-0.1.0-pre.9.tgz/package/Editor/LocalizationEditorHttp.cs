using System;
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine.Networking;

/// <summary>One Editor update subscription per active request; no worker or persistent watcher.</summary>
internal static class LocalizationEditorHttp
{
    internal static Task<string> GetAsync(string url, int timeoutSeconds, CancellationToken cancellation)
    {
        cancellation.ThrowIfCancellationRequested();
        var completion = new TaskCompletionSource<string>();
        UnityWebRequest request = null;
        UnityWebRequestAsyncOperation operation;
        try
        {
            request = UnityWebRequest.Get(url);
            request.timeout = timeoutSeconds;
            operation = request.SendWebRequest();
        }
        catch (Exception error)
        {
            request?.Dispose();
            completion.SetException(LocalizationHttpDiagnostics.CreateFailure(url, 0, error.GetType().Name + ": " + error.Message));
            return completion.Task;
        }
        double deadline = EditorApplication.timeSinceStartup + timeoutSeconds;
        void Tick()
        {
            try
            {
                if (cancellation.IsCancellationRequested)
                {
                    request.Abort();
                    Finish(() => completion.TrySetCanceled());
                }
                else if (EditorApplication.timeSinceStartup >= deadline)
                {
                    var failure = LocalizationHttpDiagnostics.CreateFailure(url, request.responseCode, "Request timeout");
                    request.Abort();
                    Finish(() => completion.TrySetException(failure));
                }
                else if (operation.isDone)
                {
                    if (request.result == UnityWebRequest.Result.Success)
                    {
                        string text = request.downloadHandler.text;
                        Finish(() => completion.TrySetResult(text));
                    }
                    else
                    {
                        var failure = LocalizationHttpDiagnostics.CreateFailure(url, request.responseCode, request.error);
                        Finish(() => completion.TrySetException(failure));
                    }
                }
            }
            catch (Exception error)
            {
                var failure = LocalizationHttpDiagnostics.CreateFailure(url, 0, error.GetType().Name + ": " + error.Message);
                Finish(() => completion.TrySetException(failure));
            }
        }
        bool finished = false;
        void Finish(Action complete)
        {
            if (finished) return;
            finished = true;
            EditorApplication.update -= Tick;
            AssemblyReloadEvents.beforeAssemblyReload -= CancelForReload;
            EditorApplication.quitting -= CancelForReload;
            try { request.Dispose(); }
            finally { complete(); }
        }
        void CancelForReload()
        {
            request.Abort();
            Finish(() => completion.TrySetCanceled());
        }
        EditorApplication.update += Tick;
        AssemblyReloadEvents.beforeAssemblyReload += CancelForReload;
        EditorApplication.quitting += CancelForReload;
        return completion.Task;
    }
}
