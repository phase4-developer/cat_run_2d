using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.Localization;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.Localization.Tables;
using Object = UnityEngine.Object;
#if UNITY_6000_7_OR_NEWER
using ObjectId = UnityEngine.EntityId; // 6.7 makes Object.GetInstanceID a compile error; 6000.3 has no GetEntityId.
#else
using ObjectId = System.Int32;
#endif

/// <summary>Bounded backup of this import's assets, not a general filesystem transaction.</summary>
internal sealed class LocalizationImportTransaction
{
    [Serializable] internal sealed class FileState
    {
        public string path, data, meta, json, guid, observed, observedMeta, observedJson;
        public string savedJson, savedHash, savedMetaHash, savedGuid;
        public bool folder, rawOutput;
        public bool existed, metaExisted;
        public string configKind;
        public bool writable = true, initiallyDirty;
    }
    [Serializable] private sealed class Record
    {
        public int version = 2;
        public bool restorable, verificationChangedLiveState;
        public List<FileState> files = new List<FileState>();
        public List<FileState> created = new List<FileState>();
        public List<string> registeredLocales = new List<string>();
        public List<string> requestedLocales = new List<string>();
        public List<string> initialGroups = new List<string>();
        public List<string> initialSchemas = new List<string>();
        public List<string> requestedAssets = new List<string>();
        public List<string> unownedConfigAssets = new List<string>();
        public List<string> foreignConfigEdits = new List<string>();
        public string settingsPath;
    }
    private readonly Record record;
    private readonly HashSet<string> initialPaths;
    private readonly HashSet<string> collectionNames;
    private readonly HashSet<string> localeCodes;
    private readonly AddressableAssetSettings settings;
    private readonly string collectionRoot, localeRoot;
    private readonly HashSet<string> collectionDirectories = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    internal static string JournalPath => Path.GetFullPath("Library/JJEvol/LocalizationImport/pending.json");
    internal static bool RecoveryRequired => File.Exists(JournalPath);
    internal Action<string> Fault;
    internal Action<Object> SaveAsset = AssetDatabase.SaveAssetIfDirty;
    private readonly HashSet<string> sdkSaved = new HashSet<string>(StringComparer.Ordinal);
    internal string RecoveryFailure { get; private set; }

    internal IDisposable ProtectSaves() => LocalizationImportSaveGuard.Enter(record.files.Select(file => file.path), path => sdkSaved.Add(path), CanSdkSave);

    private bool CanSdkSave(string path)
    {
        var file = record.files.FirstOrDefault(item => item.path == path);
        if (file == null) return false;
        if (file.configKind == "schema" || file.configKind == "localization-settings") return false;
        if (file.configKind == "addressables-settings")
        {
            var asset = AssetDatabase.LoadMainAssetAtPath(path);
            return asset && ConfigMemoryOwned(file, EditorJsonUtility.ToJson(asset), record);
        }
        if (file.configKind != "group") return file.writable;
        var group = AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(path);
        return group && !file.initiallyDirty && GroupHasRequestEntries(file, group)
            && ConfigMemoryOwned(file, EditorJsonUtility.ToJson(group), record);
    }

    internal void ExecuteSdk(Action action, StringTableCollection tableOwner = null)
    {
        Observe();
        if (record.foreignConfigEdits.Count != 0) throw new IOException("Unowned configuration edits were preserved; recovery review is required.");
        sdkSaved.Clear();
        try { action(); }
        finally
        {
            if (tableOwner)
            {
                // Localization's Smart String synchronization uses SaveAssetIfDirty for this collection.
                foreach (var table in tableOwner.StringTables.Where(table => table)) sdkSaved.Add(AssetDatabase.GetAssetPath(table));
                sdkSaved.Add(AssetDatabase.GetAssetPath(tableOwner.SharedData));
            }
            foreach (var file in record.files.Where(file => sdkSaved.Contains(file.path)))
            {
                if (Hash(file.path + ".meta") != file.observedMeta) throw new IOException("SDK changed an existing asset GUID/meta.");
                file.observed = Hash(file.path);
            }
            Observe();
            if (record.foreignConfigEdits.Count != 0) throw new IOException("Unowned configuration edits were preserved; recovery review is required.");
        }
    }

    internal LocalizationImportTransaction(IEnumerable<string> collections, IEnumerable<string> locales, string collectionDirectory, string localeDirectory, IEnumerable<string> outputFiles)
    {
        if (RecoveryRequired) throw new InvalidOperationException("RecoveryRequired: resolve the preceding Localization import before retrying.");
        if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling)
            throw new InvalidOperationException("Localization import requires an idle Editor.");
        settings = AddressableAssetSettingsDefaultObject.Settings;
        if (!settings) throw new InvalidOperationException("Addressable settings must exist before importing Localization.");
        if (!LocalizationEditorSettings.ActiveLocalizationSettings)
            throw new InvalidOperationException("Localization settings must exist before importing.");
        collectionRoot = AssetPath(collectionDirectory);
        localeRoot = AssetPath(localeDirectory);
        collectionNames = new HashSet<string>(collections, StringComparer.Ordinal);
        collectionDirectories.Add(collectionRoot);
        localeCodes = new HashSet<string>(locales, StringComparer.OrdinalIgnoreCase);
        initialPaths = new HashSet<string>(AssetDatabase.GetAllAssetPaths(), StringComparer.Ordinal);
        record = new Record();
        record.settingsPath = AssetDatabase.GetAssetPath(settings);
        record.requestedLocales.AddRange(localeCodes);
        var paths = new HashSet<string>(StringComparer.Ordinal);
        void Include(Object asset) { if (asset) paths.Add(AssetDatabase.GetAssetPath(asset)); }
        Include(settings);
        Include(LocalizationEditorSettings.ActiveLocalizationSettings);
        foreach (var group in settings.groups.Where(group => group))
        {
            Include(group);
            record.initialGroups.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group)));
            foreach (var schema in group.Schemas)
            {
                Include(schema);
                record.initialSchemas.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(schema)));
            }
        }
        foreach (string name in collectionNames)
        {
            var collection = LocalizationEditorSettings.GetStringTableCollection(name);
            if (!collection) continue;
            collectionDirectories.Add(Path.GetDirectoryName(AssetDatabase.GetAssetPath(collection)).Replace('\\', '/'));
            Include(collection); Include(collection.SharedData);
            foreach (var table in collection.StringTables) Include(table);
        }
        foreach (var locale in LocalizationEditorSettings.GetLocales().Where(locale => locale))
        {
            record.registeredLocales.Add(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(locale)));
            if (localeCodes.Contains(locale.Identifier.Code)) Include(locale);
        }
        var rawOutputs = new HashSet<string>((outputFiles ?? Array.Empty<string>()).Select(AssetPath), StringComparer.Ordinal);
        foreach (string path in rawOutputs) paths.Add(path);
        foreach (string path in paths)
        {
            if (string.IsNullOrEmpty(path)) throw new InvalidOperationException("A required Localization asset is not persistent.");
            var asset = AssetDatabase.LoadMainAssetAtPath(path);
            if (asset && EditorUtility.IsDirty(asset) && !(asset is AddressableAssetGroup) && !(asset is AddressableAssetGroupSchema))
                throw new InvalidOperationException("Save the affected asset before import: " + path);
            var captured = Capture(path, asset); captured.rawOutput = rawOutputs.Contains(path);
            record.files.Add(captured);
        }
        Directory.CreateDirectory(Path.GetDirectoryName(JournalPath));
        using var file = new FileStream(JournalPath, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(JsonUtility.ToJson(record));
        file.Write(bytes, 0, bytes.Length); file.Flush(true);
    }

    internal void Observe()
    {
        var currentPaths = AssetDatabase.GetAllAssetPaths();
        record.requestedAssets = currentPaths.Where(path => path.StartsWith("Assets/", StringComparison.Ordinal) && path.EndsWith(".asset", StringComparison.OrdinalIgnoreCase)
                && (collectionDirectories.Any(directory => IsWithin(path, directory)) || IsWithin(path, localeRoot)))
            .Where(path => IsRequestedAsset(AssetDatabase.LoadMainAssetAtPath(path), path)).Select(AssetDatabase.AssetPathToGUID)
            .Concat(LocalizationEditorSettings.GetLocales().Where(locale => locale && localeCodes.Contains(locale.Identifier.Code))
                .Select(locale => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(locale))))
            .Where(guid => guid.Length != 0).Distinct().ToList();
        var ownedGroups = settings.groups.Where(group => group && !initialPaths.Contains(AssetDatabase.GetAssetPath(group))
            && group.entries.Count > 0 && group.entries.All(entry => record.requestedAssets.Contains(entry.guid))).ToArray();
        var ownedSchemas = ownedGroups.SelectMany(group => group.Schemas).ToArray();
        record.unownedConfigAssets.Clear();
        foreach (string path in currentPaths.Where(path => !initialPaths.Contains(path) && path.EndsWith(".asset", StringComparison.OrdinalIgnoreCase) && !AssetDatabase.IsValidFolder(path)))
        {
            if (record.created.Any(file => file.path == path)) continue;
            var asset = AssetDatabase.LoadMainAssetAtPath(path);
            bool own = IsRequestedAsset(asset, path) && !(asset is Locale && !IsWithin(path, localeRoot))
                || asset is AddressableAssetGroup group && ownedGroups.Contains(group)
                || asset is AddressableAssetGroupSchema schema && ownedSchemas.Contains(schema);
            if (own) { var created = Capture(path, asset); created.writable = true; record.created.Add(created); }
            else if ((asset is AddressableAssetGroup || asset is AddressableAssetGroupSchema) && IsWithin(path, settings.ConfigFolder))
                record.unownedConfigAssets.Add(path);
        }
        foreach (string path in currentPaths.Where(path => !initialPaths.Contains(path) && AssetDatabase.IsValidFolder(path)))
        {
            if (record.created.Any(file => file.path == path)) continue;
            if (!record.created.Any(file => !file.folder && IsWithin(file.path, path))
                && !record.files.Any(file => !file.existed && File.Exists(file.path) && IsWithin(file.path, path))) continue;
            var captured = Capture(path, null); captured.folder = true; record.created.Add(captured);
        }
        record.foreignConfigEdits.Clear();
        foreach (var file in record.files.Concat(record.created))
        {
            // Existing GUID/meta ownership cannot be changed by a Localization import.
            if (file.guid.Length != 0 && AssetDatabase.AssetPathToGUID(file.path) != file.guid)
                throw new IOException("Asset ownership changed during import: " + file.path);
            if (Hash(file.path) != file.observed || Hash(file.path + ".meta") != file.observedMeta)
                throw new IOException("Asset changed outside the import's recorded write: " + file.path);
            var current = file.folder ? null : AssetDatabase.LoadMainAssetAtPath(file.path);
            string json = current ? EditorJsonUtility.ToJson(current) : null;
            if (record.files.Contains(file) && !string.IsNullOrEmpty(file.configKind))
            {
                if (!ConfigMemoryOwned(file, json, record))
                {
                    record.foreignConfigEdits.Add(file.path);
                    continue; // Keep the last owned state instead of accepting a foreign Inspector edit.
                }
                if (current is AddressableAssetGroup group)
                {
                    bool requested = GroupHasRequestEntries(file, group);
                    if (requested && file.initiallyDirty && json != file.json)
                    {
                        record.foreignConfigEdits.Add(file.path); continue;
                    }
                    file.writable = requested && !file.initiallyDirty;
                }
            }
            file.observedJson = json;
        }
        Persist();
    }

    private bool GroupHasRequestEntries(FileState file, AddressableAssetGroup group)
    {
        if (group.entries.Any(entry => record.requestedAssets.Contains(entry.guid))) return true;
        var original = GroupSerializationBody(JObject.Parse(file.json));
        return (original["m_SerializeEntries"] as JArray)?.OfType<JObject>().Any(entry => record.requestedAssets.Contains((string)entry["m_GUID"])) == true;
    }

    private static bool ConfigMemoryOwned(FileState file, string current, Record record)
    {
        if (string.IsNullOrEmpty(file.configKind)) return true;
        if (file.configKind == "schema" || file.configKind == "localization-settings") return current == file.json;
        if (string.IsNullOrEmpty(current) || string.IsNullOrEmpty(file.json)) return false;
        if (file.configKind == "addressables-settings")
        {
            var before = JObject.Parse(file.json); var after = JObject.Parse(current);
            var originalBody = GroupSerializationBody(before); var body = GroupSerializationBody(after);
            originalBody.Remove("m_currentHash"); body.Remove("m_currentHash"); // SDK-derived cache; never an ownership proof.
            if (!(originalBody["m_GroupAssets"] is JArray) || !(body["m_GroupAssets"] is JArray groups)
                || !(originalBody["m_LabelTable"]?["m_LabelNames"] is JArray originalLabels)
                || !(body["m_LabelTable"]?["m_LabelNames"] is JArray labels))
                throw new InvalidDataException("The supported Addressables settings serialization is unavailable.");
            var ownGroups = new HashSet<string>(record.created.Where(item => item.configKind == "group").Select(item => item.guid), StringComparer.OrdinalIgnoreCase);
            foreach (var group in groups.OfType<JObject>().Where(group => ownGroups.Contains((string)group["guid"])).ToArray()) group.Remove();
            var existingLabels = new HashSet<string>(originalLabels.Values<string>(), StringComparer.Ordinal);
            var ownLabels = new HashSet<string>(new[] { "Localization", "Locale", "Preload" }.Concat(record.requestedLocales.Select(code => "Locale-" + code)), StringComparer.Ordinal);
            foreach (var label in labels.Where(label => !existingLabels.Contains((string)label) && ownLabels.Contains((string)label)).ToArray()) label.Remove();
            return JToken.DeepEquals(before, after);
        }
        var own = new HashSet<string>(record.requestedAssets, StringComparer.Ordinal);
        JObject StripOwnedEntries(string json)
        {
            var state = JObject.Parse(json);
            if (!(GroupSerializationBody(state)["m_SerializeEntries"] is JArray entries))
                throw new InvalidDataException("The supported Addressables group serialization is unavailable.");
            foreach (var entry in entries.OfType<JObject>().Where(entry => own.Contains((string)entry["m_GUID"])).ToArray()) entry.Remove();
            return state;
        }
        return JToken.DeepEquals(StripOwnedEntries(file.json), StripOwnedEntries(current));
    }

    private static JObject GroupSerializationBody(JObject state)
        => state["MonoBehaviour"] as JObject ?? state;

    private bool IsRequestedAsset(Object asset, string path)
    {
        bool collectionPath = collectionDirectories.Any(directory => IsWithin(path, directory));
        return asset is StringTable table && collectionNames.Contains(table.TableCollectionName) && collectionPath
            || asset is SharedTableData shared && collectionNames.Contains(shared.TableCollectionName) && collectionPath
            || asset is StringTableCollection collection && collectionNames.Contains(collection.TableCollectionName) && collectionPath
            || asset is Locale locale && localeCodes.Contains(locale.Identifier.Code);
    }

    private static bool ConnectionsOwned(Record state, bool allowUnsavedGroupRollback = false)
    {
        if (state.verificationChangedLiveState) return false;
        var current = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(state.settingsPath);
        if (!current) return false;
        foreach (var file in state.files.Where(file => !string.IsNullOrEmpty(file.configKind)))
        {
            var asset = AssetDatabase.LoadMainAssetAtPath(file.path);
            if (!asset) return false;
            string json = EditorJsonUtility.ToJson(asset);
            if (!ConfigMemoryOwned(file, json, state)) return false;
            if (!allowUnsavedGroupRollback && file.configKind == "group" && file.initiallyDirty && json != file.json) return false;
        }
        if (state.unownedConfigAssets.Any(path => File.Exists(AssetPath(path)) || File.Exists(AssetPath(path) + ".meta"))) return false;
        var owned = new HashSet<string>(state.created.Select(file => file.guid), StringComparer.Ordinal);
        foreach (var group in current.groups.Where(group => group))
        {
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
            if (!state.initialGroups.Contains(guid) && (!owned.Contains(guid) || group.entries.Any(entry => !state.requestedAssets.Contains(entry.guid)))) return false;
            foreach (var schema in group.Schemas)
            {
                string schemaGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(schema));
                if (!state.initialSchemas.Contains(schemaGuid) && !owned.Contains(schemaGuid)) return false;
            }
        }
        return true;
    }

    internal void WriteOutput(string path, byte[] bytes)
    {
        var state = record.files.Single(file => file.path == AssetPath(path));
        if (Hash(state.path) != state.observed || Hash(state.path + ".meta") != state.observedMeta) throw new IOException("Download output changed before apply.");
        Directory.CreateDirectory(Path.GetDirectoryName(state.path));
        File.WriteAllBytes(state.path, bytes);
        AssetDatabase.ImportAsset(state.path, ImportAssetOptions.ForceSynchronousImport);
        state.observed = Hash(state.path); state.observedMeta = Hash(state.path + ".meta");
        state.savedJson = null; // Raw CSV/TSV persistence is proven by the output bytes, not object JSON.
        state.savedHash = state.observed; state.savedMetaHash = state.observedMeta; state.savedGuid = AssetDatabase.AssetPathToGUID(state.path);
        Persist();
    }

    internal void SaveAffected()
    {
        Observe();
        if (!ConnectionsOwned(record)) throw new IOException("Unowned Addressables changes require explicit recovery review.");
        foreach (var file in record.files.Concat(record.created).ToArray())
        {
            if (!file.writable || file.rawOutput) continue;
            var asset = AssetDatabase.LoadMainAssetAtPath(file.path);
            if (!asset || file.folder) continue;
            RequireCollectionIdentity(asset);
            // An external disk change must never be hidden by saving the Editor object over it.
            if (Hash(file.path) != file.observed || Hash(file.path + ".meta") != file.observedMeta)
                throw new IOException("Asset changed before save: " + file.path);
            Fault?.Invoke("BeforeSave:" + file.path);
            if (!ConnectionsOwned(record) || Hash(file.path) != file.observed || Hash(file.path + ".meta") != file.observedMeta)
                throw new IOException("Asset ownership changed before save.");
            if ((File.GetAttributes(file.path) & FileAttributes.ReadOnly) != 0) throw new IOException("An affected asset is read-only: " + file.path);
            // Mark the proven owned writable candidate and permit only its exact scoped save.
            // The separate serialized-file read below proves that its prepared state reached disk.
            EditorUtility.SetDirty(asset);
            string serialized = EditorJsonUtility.ToJson(asset);
            using (LocalizationImportSaveGuard.Enter(new[] { file.path }, null)) SaveAsset(asset);
            file.observed = Hash(file.path); file.observedMeta = Hash(file.path + ".meta");
            VerifySavedAsset(file, asset, serialized);
            Persist();
            Fault?.Invoke("AfterSave:" + file.path);
        }
    }

    private void VerifySavedAsset(FileState file, Object asset, string expected)
    {
        string guid = AssetDatabase.AssetPathToGUID(file.path), bytes = Hash(file.path), meta = Hash(file.path + ".meta");
        if (!SavedJsonEqual(file, EditorJsonUtility.ToJson(asset), expected) || bytes != file.observed || meta != file.observedMeta)
            throw new IOException("An affected asset changed before persisted verification.");
        RequireCollectionIdentity(asset);
        string persisted = ReadPersistedJson(file, asset);
        if (AssetDatabase.AssetPathToGUID(file.path) != guid || Hash(file.path + ".meta") != meta
            || Hash(file.path) != bytes || !SavedJsonEqual(file, persisted, expected))
            throw new IOException("The saved asset does not contain the prepared serialized state: " + file.path);
        RequireCollectionIdentity(asset);
        file.savedJson = expected; file.savedHash = bytes; file.savedMetaHash = meta; file.savedGuid = guid;
    }

    private sealed class VerificationLiveState
    {
        internal FileState file;
        internal Object asset;
        internal ObjectId instance;
        internal bool dirty;
        internal string json, guid, bytes, meta;
    }

    private string ReadPersistedJson(FileState target, Object liveAsset)
    {
        // ImportAsset/LoadAssetAtPath may return an unchanged dirty cache. Read a separate
        // serialized-file object instead; it is never installed into the AssetDatabase or SDK cache.
        var live = record.files.Concat(record.created).Select(file =>
        {
            var asset = file.folder ? null : AssetDatabase.LoadMainAssetAtPath(file.path);
            string json = asset ? EditorJsonUtility.ToJson(asset) : null;
            if (asset) RequireCollectionIdentity(asset);
            return new VerificationLiveState { file = file, asset = asset, instance = asset ? IdOf(asset) : default,
                json = json, dirty = asset && EditorUtility.IsDirty(asset), guid = AssetDatabase.AssetPathToGUID(file.path),
                bytes = Hash(file.path), meta = Hash(file.path + ".meta") };
        }).ToArray();
        ObjectId settingsId = IdOf(settings);
        ObjectId localizationId = IdOf(LocalizationEditorSettings.ActiveLocalizationSettings);
        string[] locales = LocalizationEditorSettings.GetLocales().Where(locale => locale).Select(locale => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(locale))).OrderBy(id => id, StringComparer.Ordinal).ToArray();
        var liveIds = new HashSet<ObjectId>(live.Select(state => state.instance));
        Object[] detached = null;
        string jsonFromDisk = null;
        Exception failure = null;
        try
        {
            detached = InternalEditorUtility.LoadSerializedFileAndForget(Path.GetFullPath(target.path));
            if (detached == null || detached.Length != 1 || !detached[0]
                || detached[0].GetType() != liveAsset.GetType() || !(detached[0] is ScriptableObject)
                || EditorUtility.IsPersistent(detached[0]) || liveIds.Contains(IdOf(detached[0]))
                || !string.IsNullOrEmpty(AssetDatabase.GetAssetPath(detached[0])))
                throw new IOException("A separate serialized asset could not be read safely: " + target.path);
            jsonFromDisk = EditorJsonUtility.ToJson(detached[0]);
        }
        catch (Exception error) { failure = error; }
        finally
        {
            if (detached != null)
                foreach (var item in detached.Where(item => item).Distinct())
                    if (!EditorUtility.IsPersistent(item) && !liveIds.Contains(IdOf(item)) && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(item)))
                        try { Object.DestroyImmediate(item); }
                        catch (Exception error) { failure = failure ?? error; }
        }
        bool unchanged = AddressableAssetSettingsDefaultObject.Settings
            && IdOf(AddressableAssetSettingsDefaultObject.Settings) == settingsId
            && LocalizationEditorSettings.ActiveLocalizationSettings
            && IdOf(LocalizationEditorSettings.ActiveLocalizationSettings) == localizationId
            && locales.SequenceEqual(LocalizationEditorSettings.GetLocales().Where(locale => locale).Select(locale => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(locale))).OrderBy(id => id, StringComparer.Ordinal));
        foreach (var state in live)
        {
            var asset = state.file.folder ? null : AssetDatabase.LoadMainAssetAtPath(state.file.path);
            string current = asset ? EditorJsonUtility.ToJson(asset) : null;
            unchanged &= (asset ? IdOf(asset) : default) == state.instance
                && SavedJsonEqual(state.file, current, state.json) && (!asset || EditorUtility.IsDirty(asset) == state.dirty)
                && AssetDatabase.AssetPathToGUID(state.file.path) == state.guid
                && Hash(state.file.path) == state.bytes && Hash(state.file.path + ".meta") == state.meta;
            if (asset is StringTableCollection collection)
            {
                var cached = LocalizationEditorSettings.GetStringTableCollection(collection.TableCollectionName);
                unchanged &= cached && IdOf(cached) == state.instance;
            }
        }
        if (!unchanged)
        {
            record.verificationChangedLiveState = true; Persist();
            throw new IOException("Persisted verification changed live assets; preserve them for recovery review.");
        }
        if (failure != null) throw new IOException("The serialized asset could not be verified from disk: " + target.path, failure);
        return jsonFromDisk;
    }
    internal void Commit()
    {
        Observe();
        Fault?.Invoke("BeforeCommit");
        if (!ConnectionsOwned(record)) throw new IOException("Unowned Addressables changes require explicit recovery review.");
        foreach (var file in record.files.Concat(record.created))
            if (Hash(file.path) != file.observed || Hash(file.path + ".meta") != file.observedMeta)
                throw new IOException("Asset changed during import verification.");
        ClearVerifiedSavedFlags();
        File.Delete(JournalPath);
        if (File.Exists(JournalPath)) throw new IOException("Import completion marker could not be removed.");
    }

    private void ClearVerifiedSavedFlags()
    {
        foreach (var file in record.files.Concat(record.created))
        {
            if (!file.writable || file.folder || file.rawOutput || string.IsNullOrEmpty(file.savedJson)
                || file.initiallyDirty && !record.created.Contains(file)) continue;
            var asset = AssetDatabase.LoadMainAssetAtPath(file.path);
            if (!asset || !EditorUtility.IsDirty(asset)) continue;
            RequireCollectionIdentity(asset);
            // Only this request's proven saved serialization may lose a redundant SDK dirty flag.
            string current = EditorJsonUtility.ToJson(asset);
            if (!SavedJsonEqual(file, current, file.savedJson) || Hash(file.path) != file.savedHash || Hash(file.path + ".meta") != file.savedMetaHash
                || AssetDatabase.AssetPathToGUID(file.path) != file.savedGuid)
                throw new IOException("An affected asset changed after its scoped save: " + file.path);
            EditorUtility.ClearDirty(asset);
        }
    }

    private static bool SavedJsonEqual(FileState file, string first, string second)
    {
        if (string.IsNullOrEmpty(first) || string.IsNullOrEmpty(second)) return first == second;
        var left = JObject.Parse(first); var right = JObject.Parse(second);
        if (file.configKind == "addressables-settings")
        {
            // Recomputed by Addressables from the already-verified structure on demand.
            GroupSerializationBody(left).Remove("m_currentHash"); GroupSerializationBody(right).Remove("m_currentHash");
        }
        return JToken.DeepEquals(left, right);
    }

#if UNITY_6000_7_OR_NEWER
    private static ObjectId IdOf(Object value) => value.GetEntityId();
#else
    private static ObjectId IdOf(Object value) => value.GetInstanceID();
#endif

    private static void RequireCollectionIdentity(Object asset)
    {
        if (!(asset is StringTableCollection collection)) return;
        var cached = LocalizationEditorSettings.GetStringTableCollection(collection.TableCollectionName);
        if (!cached || IdOf(cached) != IdOf(collection))
            throw new InvalidDataException("The SDK collection cache and persistent main asset do not have the same identity.");
    }

    internal bool Rollback()
    {
        // Capture SDK-created assets even when its creation method threw after writing an asset.
        try { Observe(); record.restorable = true; Persist(); Fault?.Invoke("BeforeRollback"); }
        catch (Exception error) { RecoveryFailure = error.GetType().Name + ": " + error.Message; return false; }
        return Restore(record, Fault);
    }

    internal static bool Recover()
    {
        if (!RecoveryRequired) return true;
        try
        {
            var state = JsonUtility.FromJson<Record>(File.ReadAllText(JournalPath));
            // A hard interruption can occur between a Unity asset mutation and its observed checkpoint.
            if (state == null || state.version != 2 || !state.restorable) return false;
            return Restore(state, null, true);
        }
        catch { return false; }
    }

    private static bool Restore(Record state, Action<string> fault, bool manual = false)
    {
        try
        {
            if (!ConnectionsOwned(state, true)) return false;
            using var protection = LocalizationImportSaveGuard.Enter(state.files.Where(file => file.writable).Select(file => file.path), null);
            foreach (var file in state.files.Concat(state.created))
            {
                AssetPath(file.path);
                string bytes = Hash(file.path), meta = Hash(file.path + ".meta");
                bool observed = bytes == file.observed && meta == file.observedMeta;
                bool original = !state.created.Contains(file) && bytes == DataHash(file.data, file.existed) && meta == DataHash(file.meta, file.metaExisted);
                bool deleted = state.created.Contains(file) && !Directory.Exists(file.path) && bytes == "missing" && meta == "missing";
                if (!observed && !original && !deleted) return false;
                var current = file.folder ? null : AssetDatabase.LoadMainAssetAtPath(file.path);
                if (manual && current)
                {
                    string json = EditorJsonUtility.ToJson(current);
                    if (!SavedJsonEqual(file, json, file.observedJson) && !SavedJsonEqual(file, json, file.json)) return false;
                }
            }
            foreach (var locale in LocalizationEditorSettings.GetLocales().Where(locale => locale).ToArray())
            {
                string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(locale));
                if (!state.registeredLocales.Contains(guid) && state.requestedLocales.Contains(locale.Identifier.Code, StringComparer.OrdinalIgnoreCase))
                    LocalizationEditorSettings.RemoveLocale(locale);
            }
            // New raw downloads belong to record.files so their originals can be absent.
            // Remove their proven owned files before checking that their new folder is empty.
            foreach (var file in state.files.Where(file => file.rawOutput && !file.existed))
            {
                fault?.Invoke("DeleteNewOutput:" + file.path);
                if ((File.Exists(file.path) || File.Exists(file.path + ".meta")) && !AssetDatabase.DeleteAsset(file.path)) return false;
            }
            foreach (var file in state.created.OrderByDescending(file => file.path.Length))
            {
                fault?.Invoke("DeleteCreated:" + file.path);
                if (!File.Exists(file.path) && !Directory.Exists(file.path) && !File.Exists(file.path + ".meta")) continue;
                if (file.folder && Directory.EnumerateFileSystemEntries(Path.GetFullPath(file.path)).Any()) return false;
                if (AssetDatabase.AssetPathToGUID(file.path) != file.guid || !AssetDatabase.DeleteAsset(file.path)) return false;
            }
            foreach (var file in state.files.Where(file => file.configKind == "group" && file.initiallyDirty))
            {
                var group = AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(file.path);
                if (!group || !ConfigMemoryOwned(file, EditorJsonUtility.ToJson(group), state)) return false;
                // Undo only this request's entry changes in memory. The user's original unsaved
                // group state remains unsaved; its disk bytes are never written by this recovery.
                EditorJsonUtility.FromJsonOverwrite(file.json, group);
                group.OnAfterDeserialize();
                EditorUtility.SetDirty(group);
            }
            foreach (var file in state.files.Where(file => file.writable))
            {
                fault?.Invoke("Restore:" + file.path);
                if (!file.existed && File.Exists(file.path)) AssetDatabase.DeleteAsset(file.path);
                WriteOriginal(file.path, file.data, file.existed); WriteOriginal(file.path + ".meta", file.meta, file.metaExisted);
            }
            foreach (var file in state.files.Where(file => file.existed && file.writable))
            {
                AssetDatabase.ImportAsset(file.path, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
                var asset = AssetDatabase.LoadMainAssetAtPath(file.path);
                if (asset && !file.rawOutput && !string.IsNullOrEmpty(file.json))
                {
                    EditorJsonUtility.FromJsonOverwrite(file.json, asset);
                    if (asset is ISerializationCallbackReceiver callbacks) callbacks.OnAfterDeserialize();
                    EditorUtility.ClearDirty(asset);
                }
            }
            foreach (var file in state.files)
                if (Hash(file.path) != DataHash(file.data, file.existed) || Hash(file.path + ".meta") != DataHash(file.meta, file.metaExisted)
                    || file.guid.Length != 0 && AssetDatabase.AssetPathToGUID(file.path) != file.guid) return false;
            foreach (var file in state.files.Where(file => file.configKind == "group" && file.initiallyDirty))
            {
                var group = AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(file.path);
                if (!group || EditorJsonUtility.ToJson(group) != file.json || !EditorUtility.IsDirty(group)) return false;
            }
            if (state.created.Any(file => File.Exists(file.path) || Directory.Exists(file.path) || File.Exists(file.path + ".meta"))) return false;
            var locales = LocalizationEditorSettings.GetLocales().Where(locale => locale)
                .Select(locale => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(locale))).OrderBy(value => value);
            if (!locales.SequenceEqual(state.registeredLocales.OrderBy(value => value))) return false;
            File.Delete(JournalPath);
            return !File.Exists(JournalPath);
        }
        catch { return false; }
    }

    private void Persist()
    {
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(JsonUtility.ToJson(record));
        using var file = new FileStream(JournalPath, FileMode.Open, FileAccess.Write, FileShare.None);
        file.SetLength(0); file.Write(bytes, 0, bytes.Length); file.Flush(true);
    }
    private static FileState Capture(string path, Object asset)
    {
        string safePath = AssetPath(path);
        return new FileState { path = safePath, data = Read(safePath), meta = Read(safePath + ".meta"),
            json = asset ? EditorJsonUtility.ToJson(asset) : null, guid = AssetDatabase.AssetPathToGUID(safePath) ?? "",
            observed = Hash(safePath), observedMeta = Hash(safePath + ".meta"), observedJson = asset ? EditorJsonUtility.ToJson(asset) : null,
            existed = File.Exists(safePath), metaExisted = File.Exists(safePath + ".meta"),
            configKind = asset is AddressableAssetGroup ? "group" : asset is AddressableAssetGroupSchema ? "schema"
                : asset is AddressableAssetSettings ? "addressables-settings" : asset is LocalizationSettings ? "localization-settings" : null,
            writable = !(asset is AddressableAssetGroup) && !(asset is AddressableAssetGroupSchema) && !(asset is LocalizationSettings),
            initiallyDirty = asset && EditorUtility.IsDirty(asset) };
    }
    private static string Read(string path) => File.Exists(path) ? Convert.ToBase64String(File.ReadAllBytes(path)) : null;
    private static void WriteOriginal(string path, string bytes, bool existed)
    {
        if (!existed) { if (File.Exists(path)) File.Delete(path); return; }
        byte[] original = Convert.FromBase64String(bytes ?? "");
        if (File.Exists(path) && File.ReadAllBytes(path).SequenceEqual(original)) return;
        File.WriteAllBytes(path, original);
    }
    private static string Hash(string path) => File.Exists(path) ? BytesHash(File.ReadAllBytes(path)) : "missing";
    private static string DataHash(string data, bool existed) => !existed ? "missing" : BytesHash(Convert.FromBase64String(data ?? ""));
    private static string BytesHash(byte[] bytes)
    { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(bytes)); }
    private static bool IsWithin(string path, string root) => path.StartsWith(root.TrimEnd('/') + "/", StringComparison.OrdinalIgnoreCase);
    internal static string AssetPath(string path)
    {
        string full = Path.GetFullPath(path ?? "");
        string assets = Path.GetFullPath(Application.dataPath).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!full.StartsWith(assets, StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("Import paths must be below this project's Assets.");
        for (string cursor = full; cursor != null; cursor = Path.GetDirectoryName(cursor))
            if ((File.Exists(cursor) || Directory.Exists(cursor)) && (File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0)
                throw new ArgumentException("Import paths cannot traverse a reparse point.");
        return "Assets/" + full.Substring(assets.Length).Replace('\\', '/');
    }
}

/// <summary>Only filters a synchronous active import; ordinary Editor saves pass through unchanged.</summary>
internal sealed class LocalizationImportSaveGuard : AssetModificationProcessor
{
    private static HashSet<string> allowed;
    private static Action<string> saving;
    private static Func<string, bool> condition;
    internal static IDisposable Enter(IEnumerable<string> paths, Action<string> onSave, Func<string, bool> canSave = null)
    {
        var previousPaths = allowed; var previousSaving = saving; var previousCondition = condition;
        allowed = new HashSet<string>(paths, StringComparer.Ordinal); saving = onSave; condition = canSave;
        return new Scope(() => { allowed = previousPaths; saving = previousSaving; condition = previousCondition; });
    }
    private static string[] OnWillSaveAssets(string[] paths)
    {
        if (allowed == null) return paths;
        var scoped = paths.Where(path => allowed.Contains(path) && (condition == null || condition(path))).ToArray();
        foreach (string path in scoped) saving?.Invoke(path);
        return scoped;
    }
    private sealed class Scope : IDisposable
    {
        private Action release;
        internal Scope(Action release) => this.release = release;
        public void Dispose() { var action = release; release = null; action?.Invoke(); }
    }
}
