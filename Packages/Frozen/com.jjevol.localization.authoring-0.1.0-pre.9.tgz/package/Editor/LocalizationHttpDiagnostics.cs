using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

/// <summary>Safe diagnostics for the Editor's existing Google Sheets transport.</summary>
internal static class LocalizationHttpDiagnostics
{
    private const string Redacted = "[redacted]";

    internal static Exception CreateFailure(string requestUrl, long responseCode, string reason)
        => new InvalidOperationException("HTTP Error " + responseCode + ": " + Sanitize(reason, requestUrl) + "\n" + Sanitize(RequestTarget(requestUrl), requestUrl));

    internal static string ForDisplay(Exception exception, string credential)
        => Sanitize(exception.GetType().Name + ": " + exception.Message, credential: credential);

    internal static string Sanitize(string message, string requestUrl = null, string credential = null)
    {
        string safe = message ?? "Unknown transport error";
        var secrets = new HashSet<string>(StringComparer.Ordinal);
        var urlSecrets = new HashSet<string>(StringComparer.Ordinal);
        AddSecret(secrets, credential);
        AddSecret(urlSecrets, credential);
        if (Uri.TryCreate(requestUrl, UriKind.Absolute, out var request))
        {
            // A server may echo a query value without its parameter name or URL. Treat every value as private.
            foreach (string part in request.Query.TrimStart('?').Split('&'))
            {
                int equals = part.IndexOf('=');
                if (equals < 0) continue;
                AddSecret(secrets, part.Substring(equals + 1));
                string name = Uri.UnescapeDataString(part.Substring(0, equals));
                if (Regex.IsMatch(name, @"\A(?:key|api[_\-]?key|access[_\-]?token|refresh[_\-]?token|id[_\-]?token|token|auth|authorization|client[_\-]?secret|password|secret|signature)\z", RegexOptions.IgnoreCase))
                    AddSecret(urlSecrets, part.Substring(equals + 1));
            }
            AddSecret(secrets, request.Fragment.TrimStart('#'));
            AddSecret(urlSecrets, request.Fragment.TrimStart('#'));
            foreach (string part in request.UserInfo.Split(':')) { AddSecret(secrets, part); AddSecret(urlSecrets, part); }
        }

        // Sanitize surrounding text separately so private query values cannot redact the safe host/path itself.
        var result = new StringBuilder();
        int cursor = 0;
        foreach (Match match in Regex.Matches(safe, @"https?://[^\s""'<>]+", RegexOptions.IgnoreCase))
        {
            result.Append(SanitizeText(safe.Substring(cursor, match.Index - cursor), secrets));
            result.Append(ReplaceSecrets(RequestTarget(match.Value), urlSecrets));
            cursor = match.Index + match.Length;
        }
        result.Append(SanitizeText(safe.Substring(cursor), secrets));
        return result.ToString();
    }

    private static string SanitizeText(string safe, IEnumerable<string> secrets)
    {
        safe = Regex.Replace(safe, @"\b(?:authorization|proxy-authorization)\s*[:=][^\r\n]+", "authorization=" + Redacted, RegexOptions.IgnoreCase);
        safe = Regex.Replace(safe, @"\b(?:Bearer|Basic)\s+[A-Za-z0-9+/=._~%\-]+", "authorization=" + Redacted, RegexOptions.IgnoreCase);
        safe = Regex.Replace(safe, @"\b(key|api[_\-]?key|access[_\-]?token|refresh[_\-]?token|id[_\-]?token|client[_\-]?secret|password|secret|signature)\s*[:=]\s*(?:""[^""]*""|'[^']*'|[^\s&;,]+)", "$1=" + Redacted, RegexOptions.IgnoreCase);
        return ReplaceSecrets(safe, secrets);
    }

    private static string ReplaceSecrets(string text, IEnumerable<string> secrets)
    {
        foreach (string secret in secrets.OrderByDescending(value => value.Length)) text = text.Replace(secret, Redacted);
        return text;
    }

    private static void AddSecret(ISet<string> secrets, string value)
    {
        if (string.IsNullOrEmpty(value)) return;
        secrets.Add(value);
        secrets.Add(Uri.EscapeDataString(value));
        try { secrets.Add(Uri.UnescapeDataString(value.Replace("+", " "))); }
        catch (UriFormatException) { }
    }

    private static string RequestTarget(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
            return "<request URL omitted>";
        var target = new UriBuilder(uri) { UserName = string.Empty, Password = string.Empty, Query = string.Empty, Fragment = string.Empty };
        return target.Uri.GetLeftPart(UriPartial.Path);
    }
}
