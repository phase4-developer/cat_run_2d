﻿//수정
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.Localization.Components;

[CustomEditor(typeof(LocalizeTmpTextEvent))]
[CanEditMultipleObjects]
public class LocalizeTmpTextEventEditor : Editor
{
    private SerializedProperty updateTextProp;
    private SerializedProperty resolveModeProp;
    private SerializedProperty stringReferenceProp;
    private SerializedProperty tableCollectionProp;
    private SerializedProperty entryKeyProp;
    private SerializedProperty showDebugKeyWhenMissingProp;
    private SerializedProperty previewInEditModeProp;
    private SerializedProperty previewManualKeyInEditModeProp;

    private void OnEnable()
    {
        updateTextProp = serializedObject.FindProperty("updateText");
        resolveModeProp = serializedObject.FindProperty("resolveMode");
        stringReferenceProp = serializedObject.FindProperty("m_StringReference");
        tableCollectionProp = serializedObject.FindProperty("tableCollection");
        entryKeyProp = serializedObject.FindProperty("entryKey");
        showDebugKeyWhenMissingProp = serializedObject.FindProperty("showDebugKeyWhenMissing");
        previewInEditModeProp = serializedObject.FindProperty("previewInEditMode");
        previewManualKeyInEditModeProp = serializedObject.FindProperty("previewManualKeyInEditMode");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        DrawMainSection();
        EditorGUILayout.Space(8f);

        if (updateTextProp.boolValue)
        {
            DrawConflictWarning();
            DrawSourceSection();
            EditorGUILayout.Space(8f);
            DrawOptionsSection();
            EditorGUILayout.Space(8f);
            DrawPreviewSection();
        }
        else
        {
            DrawDisabledSection();
        }

        serializedObject.ApplyModifiedProperties();
    }

    private void DrawMainSection()
    {
        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
        {
            EditorGUILayout.LabelField("Text Localization", EditorStyles.boldLabel);

            EditorGUILayout.PropertyField(updateTextProp, new GUIContent("Update TMP Text"));

            if (updateTextProp.boolValue)
            {
                EditorGUILayout.PropertyField(resolveModeProp, new GUIContent("Resolve Mode"));
            }
        }
    }

    private void DrawDisabledSection()
    {
        EditorGUILayout.HelpBox(
            "Update TMP Text가 꺼져 있습니다. 이 컴포넌트는 TMP.text를 수정하지 않습니다.",
            MessageType.Info);

        DrawCurrentTextPreview();
    }

    private void DrawConflictWarning()
    {
        if (serializedObject.isEditingMultipleObjects)
            return;

        LocalizeTmpTextEvent localize = target as LocalizeTmpTextEvent;
        if (localize == null)
            return;

        LocalizeStringEvent legacy = localize.GetComponent<LocalizeStringEvent>();

        if (legacy == null)
            return;

        if (legacy.enabled)
        {
            EditorGUILayout.HelpBox(
                "같은 객체에 Localize String Event가 활성화되어 있습니다. 둘 다 TMP.text를 갱신하므로 충돌합니다.",
                MessageType.Error);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Import String Reference"))
                    ImportFromLegacy(localize, legacy, false);

                if (GUILayout.Button("Import + Disable Legacy"))
                    ImportFromLegacy(localize, legacy, true);
            }

            if (GUILayout.Button("Disable Legacy Only"))
            {
                Undo.RecordObject(legacy, "Disable Localize String Event");
                legacy.enabled = false;
                EditorUtility.SetDirty(legacy);
            }

            EditorGUILayout.Space(6f);
        }
        else
        {
            EditorGUILayout.HelpBox(
                "Localize String Event가 붙어 있지만 비활성화되어 있습니다.",
                MessageType.Info);
        }
    }

    private void DrawSourceSection()
    {
        LocalizeTmpTextEvent.TextResolveMode mode =
            (LocalizeTmpTextEvent.TextResolveMode)resolveModeProp.enumValueIndex;

        bool useStringReference =
            mode == LocalizeTmpTextEvent.TextResolveMode.StringReference
            || mode == LocalizeTmpTextEvent.TextResolveMode.StringReferenceThenManualKey;

        bool useManualKey =
            mode == LocalizeTmpTextEvent.TextResolveMode.ManualKey
            || mode == LocalizeTmpTextEvent.TextResolveMode.StringReferenceThenManualKey;

        if (useStringReference)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("String Reference", EditorStyles.boldLabel);
                EditorGUILayout.PropertyField(stringReferenceProp, GUIContent.none, true);
            }
        }

        if (useManualKey)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Manual Key", EditorStyles.boldLabel);

                EditorGUILayout.PropertyField(tableCollectionProp, new GUIContent("Table Collection"));
                EditorGUILayout.PropertyField(entryKeyProp, new GUIContent("Entry Key"));

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("Collection = ui"))
                        SetCollectionForTargets("ui");

                    if (GUILayout.Button("Entry Key = Object Name"))
                        SetEntryKeyByObjectName();

                    if (GUILayout.Button("Clear"))
                        ClearManualKey();
                }
            }
        }

        EditorGUILayout.HelpBox(
            GetModeDescription(mode),
            MessageType.Info);
    }

    private string GetModeDescription(LocalizeTmpTextEvent.TextResolveMode mode)
    {
        switch (mode)
        {
            case LocalizeTmpTextEvent.TextResolveMode.StringReference:
                return "String Reference만 사용합니다. 값이 없으면 디버그 키를 출력합니다.";

            case LocalizeTmpTextEvent.TextResolveMode.ManualKey:
                return "Manual Key만 사용합니다. 테이블에 아직 없어도 Collection/Key 형태로 출력됩니다.";

            case LocalizeTmpTextEvent.TextResolveMode.StringReferenceThenManualKey:
                return "String Reference 값을 먼저 찾고, 없으면 Manual Key를 사용합니다.";

            default:
                return string.Empty;
        }
    }

    private void DrawOptionsSection()
    {
        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
        {
            EditorGUILayout.LabelField("Options", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(showDebugKeyWhenMissingProp, new GUIContent("Show Debug Key When Missing"));
            EditorGUILayout.PropertyField(previewInEditModeProp, new GUIContent("Preview In Edit Mode"));
            EditorGUILayout.PropertyField(previewManualKeyInEditModeProp, new GUIContent("Preview Manual Key In Edit Mode"));

            if (!previewManualKeyInEditModeProp.boolValue)
            {
                EditorGUILayout.HelpBox(
                    "Manual Key는 에디터에서 TMP.text에 적용되지 않습니다. 레이아웃용 텍스트를 유지하고, 플레이 모드에서만 적용됩니다.",
                    MessageType.Info);
            }
        }
    }

    private void DrawPreviewSection()
    {
        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
        {
            EditorGUILayout.LabelField("Preview", EditorStyles.boldLabel);

            if (!serializedObject.isEditingMultipleObjects)
            {
                LocalizeTmpTextEvent localize = target as LocalizeTmpTextEvent;

                if (localize != null)
                {
                    TextMeshProUGUI tmp = localize.TargetText;

                    EditorGUILayout.LabelField("Current TMP Text");
                    EditorGUILayout.SelectableLabel(
                        tmp != null ? tmp.text : string.Empty,
                        GUILayout.Height(EditorGUIUtility.singleLineHeight));

                    EditorGUILayout.Space(4f);

                    EditorGUILayout.LabelField("Runtime Preview");
                    EditorGUILayout.SelectableLabel(
                        localize.GetRuntimeResolvedText(),
                        GUILayout.Height(EditorGUIUtility.singleLineHeight));
                }
            }

            if (GUILayout.Button("Refresh Preview"))
                RefreshTargets();
        }
    }

    private void DrawCurrentTextPreview()
    {
        if (serializedObject.isEditingMultipleObjects)
            return;

        LocalizeTmpTextEvent localize = target as LocalizeTmpTextEvent;
        if (localize == null)
            return;

        TextMeshProUGUI tmp = localize.TargetText;
        if (tmp == null)
            return;

        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
        {
            EditorGUILayout.LabelField("Current TMP Text", EditorStyles.boldLabel);
            EditorGUILayout.SelectableLabel(tmp.text, GUILayout.Height(EditorGUIUtility.singleLineHeight));
        }
    }

    private void SetCollectionForTargets(string collection)
    {
        serializedObject.ApplyModifiedProperties();

        foreach (Object obj in targets)
        {
            LocalizeTmpTextEvent localize = obj as LocalizeTmpTextEvent;
            if (localize == null)
                continue;

            Undo.RecordObject(localize, "Set Localize Collection");
            localize.SetManualReference(collection, localize.EntryKey, false);
            EditorUtility.SetDirty(localize);
        }

        serializedObject.Update();
        RefreshTargets();
    }

    private void SetEntryKeyByObjectName()
    {
        serializedObject.ApplyModifiedProperties();

        foreach (Object obj in targets)
        {
            LocalizeTmpTextEvent localize = obj as LocalizeTmpTextEvent;
            if (localize == null)
                continue;

            Undo.RecordObject(localize, "Set Localize Entry Key");
            localize.SetManualReference(localize.TableCollection, localize.gameObject.name, false);
            EditorUtility.SetDirty(localize);
        }

        serializedObject.Update();
        RefreshTargets();
    }

    private void ClearManualKey()
    {
        serializedObject.ApplyModifiedProperties();

        foreach (Object obj in targets)
        {
            LocalizeTmpTextEvent localize = obj as LocalizeTmpTextEvent;
            if (localize == null)
                continue;

            Undo.RecordObject(localize, "Clear Localize Manual Key");
            localize.SetManualReference(string.Empty, string.Empty, false);
            EditorUtility.SetDirty(localize);
        }

        serializedObject.Update();
        RefreshTargets();
    }

    private void RefreshTargets()
    {
        serializedObject.ApplyModifiedProperties();

        foreach (Object obj in targets)
        {
            LocalizeTmpTextEvent localize = obj as LocalizeTmpTextEvent;
            if (localize == null)
                continue;

            TextMeshProUGUI tmp = localize.TargetText;

            if (tmp != null)
                Undo.RecordObject(tmp, "Refresh Localize Text");

            localize.RefreshText();

            EditorUtility.SetDirty(localize);

            if (tmp != null)
                EditorUtility.SetDirty(tmp);
        }
    }

    private static void ImportFromLegacy(LocalizeTmpTextEvent targetEvent, LocalizeStringEvent legacyEvent, bool disableLegacy)
    {
        if (targetEvent == null || legacyEvent == null)
            return;

        Undo.RecordObject(targetEvent, "Import Localize String Reference");

        SerializedObject sourceObject = new SerializedObject(legacyEvent);
        SerializedProperty sourceProperty = sourceObject.FindProperty("m_StringReference");

        SerializedObject targetObject = new SerializedObject(targetEvent);

        if (sourceProperty != null)
        {
            targetObject.CopyFromSerializedProperty(sourceProperty);
            targetObject.ApplyModifiedProperties();
        }
        else
        {
            Debug.LogWarning("[LocalizeTmpTextEventEditor] LocalizeStringEvent의 m_StringReference를 찾지 못했습니다.");
        }

        if (disableLegacy)
        {
            Undo.RecordObject(legacyEvent, "Disable Localize String Event");
            legacyEvent.enabled = false;
            EditorUtility.SetDirty(legacyEvent);
        }

        targetEvent.SetUpdateText(true, false);
        targetEvent.RefreshText();

        EditorUtility.SetDirty(targetEvent);
    }

    [MenuItem("Tools/Localization/Convert Selected LocalizeStringEvent To LocalizeTmpTextEvent")]
    private static void ConvertSelected()
    {
        GameObject[] selectedObjects = Selection.gameObjects;

        if (selectedObjects == null || selectedObjects.Length <= 0)
        {
            Debug.LogWarning("[LocalizeTmpTextEventEditor] 선택된 객체가 없습니다.");
            return;
        }

        int convertedCount = 0;

        foreach (GameObject selected in selectedObjects)
        {
            if (selected == null)
                continue;

            LocalizeStringEvent[] legacyEvents = selected.GetComponentsInChildren<LocalizeStringEvent>(true);

            foreach (LocalizeStringEvent legacy in legacyEvents)
            {
                if (legacy == null)
                    continue;

                GameObject go = legacy.gameObject;

                if (go.GetComponent<TextMeshProUGUI>() == null)
                    continue;

                LocalizeTmpTextEvent targetEvent = go.GetComponent<LocalizeTmpTextEvent>();

                if (targetEvent == null)
                {
                    Undo.AddComponent<LocalizeTmpTextEvent>(go);
                    targetEvent = go.GetComponent<LocalizeTmpTextEvent>();
                }

                ImportFromLegacy(targetEvent, legacy, true);
                convertedCount++;
            }
        }

        Debug.Log($"[LocalizeTmpTextEventEditor] 변환 완료: {convertedCount}개");
    }

    [MenuItem("CONTEXT/Localize String Event/Convert To LocalizeTmpTextEvent")]
    private static void ConvertContext(MenuCommand command)
    {
        LocalizeStringEvent legacy = command.context as LocalizeStringEvent;
        if (legacy == null)
            return;

        GameObject go = legacy.gameObject;

        if (go.GetComponent<TextMeshProUGUI>() == null)
        {
            Debug.LogWarning("[LocalizeTmpTextEventEditor] TextMeshProUGUI가 없는 객체입니다.");
            return;
        }

        LocalizeTmpTextEvent targetEvent = go.GetComponent<LocalizeTmpTextEvent>();

        if (targetEvent == null)
        {
            Undo.AddComponent<LocalizeTmpTextEvent>(go);
            targetEvent = go.GetComponent<LocalizeTmpTextEvent>();
        }

        ImportFromLegacy(targetEvent, legacy, true);
    }

    [MenuItem("GameObject/UI/LocalizeText", false, 2030)]
    private static void CreateLocalizeText(MenuCommand menuCommand)
    {
        Transform parent = null;

        if (menuCommand.context is GameObject contextObject)
            parent = contextObject.transform;
        else if (Selection.activeTransform != null)
            parent = Selection.activeTransform;
        else
        {
            Canvas canvas = Object.FindObjectOfType<Canvas>();
            if (canvas != null)
                parent = canvas.transform;
        }

        GameObject go = new GameObject(
            "LocalizeText",
            typeof(RectTransform),
            typeof(TextMeshProUGUI),
            typeof(LocalizeTmpTextEvent));

        if (parent != null)
            go.transform.SetParent(parent, false);

        RectTransform rectTransform = go.GetComponent<RectTransform>();
        rectTransform.localScale = Vector3.one;
        rectTransform.localRotation = Quaternion.identity;
        rectTransform.anchoredPosition = Vector2.zero;
        rectTransform.sizeDelta = new Vector2(240f, 40f);

        TextMeshProUGUI tmp = go.GetComponent<TextMeshProUGUI>();
        tmp.text = "LocalizeText";
        tmp.raycastTarget = false;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.fontSize = 24f;

        LocalizeTmpTextEvent localize = go.GetComponent<LocalizeTmpTextEvent>();
        localize.SetUpdateText(true, false);
        localize.SetResolveMode(LocalizeTmpTextEvent.TextResolveMode.ManualKey, false);
        localize.SetManualReference("ui", "LocalizeText", false);

        Undo.RegisterCreatedObjectUndo(go, "Create LocalizeText");

        Selection.activeGameObject = go;
        EditorGUIUtility.PingObject(go);
    }
}
//수정 종료
