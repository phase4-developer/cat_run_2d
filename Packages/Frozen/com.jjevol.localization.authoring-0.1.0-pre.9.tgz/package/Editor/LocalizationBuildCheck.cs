#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;

/// <summary>
/// LocalizationManager preloads every StringTable with its Addressables label and throws when the table's Locale is
/// not available, so a Player built like that cannot finish initialization. This reports it before the build starts.
/// </summary>
internal sealed class LocalizationBuildCheck : IPreprocessBuildWithReport
{
    private const string TableLabel = "Localization";
    private const string LocaleLabel = "Locale";

    public int callbackOrder => 0;

    public void OnPreprocessBuild(BuildReport report)
    {
        var tables = FindUnregisteredTables();
        if (tables.Count == 0) return;
        throw new BuildFailedException("[Localization] Player 빌드를 막았습니다. 아래 언어 테이블의 Locale이 등록되어 있지 않아 실행 중 LocalizationManager 초기화가 실패합니다.\n"
            + string.Join("\n", tables.Select(table => "- " + table)) + "\nLocalization Settings에 이 Locale을 추가하거나 테이블을 제거하세요.");
    }

    internal static List<string> FindUnregisteredTables()
    {
        var found = new List<string>();
        var settings = AddressableAssetSettingsDefaultObject.Settings;
        if (settings == null) return found;
        var locales = Entries(settings, LocaleLabel).Select(entry => AssetDatabase.LoadAssetAtPath<Locale>(entry.AssetPath)).Where(locale => locale).Select(locale => locale.Identifier).ToList();
        foreach (var entry in Entries(settings, TableLabel))
        {
            var table = AssetDatabase.LoadAssetAtPath<StringTable>(entry.AssetPath);
            if (table && !locales.Contains(table.LocaleIdentifier)) found.Add(entry.AssetPath + ": Locale '" + table.LocaleIdentifier.Code + "'");
        }
        return found;
    }

    // Only what reaches the Player's catalog: an excluded group adds no Locale and no table at runtime.
    private static List<AddressableAssetEntry> Entries(AddressableAssetSettings settings, string label)
    {
        var entries = new List<AddressableAssetEntry>();
        settings.GetAllAssets(entries, false, group => group != null && group.GetSchema<BundledAssetGroupSchema>()?.IncludeInBuild != false, entry => entry.labels.Contains(label));
        return entries;
    }
}
#endif
