# Changelog

## 0.1.0-pre.9 - 2026-11-09

- Depends on `com.jjevol.tables.authoring` 0.1.0-pre.7, which waits briefly when Windows reports `File.Replace` `0x80070497`. Code in this package is unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.8 - 2026-11-09

- Compiles on Unity 6.7. The import transaction compares object identity through `GetEntityId()` on 6.7 and the instance ID on 6000.3. Behaviour is unchanged.

## 0.1.0-pre.7 - 2026-11-08

- Tests only. `LocalizationAuthoringRunResidue` removes the run's Addressables groups and labels only when Addressables settings existed when the run started. Without settings there is no snapshot, and the cleanup would have removed every group the run created, `Default Local Group` included.
- Runtime and Editor code are unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.6 - 2026-11-08

- Version 0.1.0-pre.6 follows the test-only 0.1.0-pre.5 on `fix/localization-authoring-test-residue`.
- The LocalizeText creation menu no longer adds `LocalizeTmpStyleEvent`, which `com.jjevol.localization` 0.1.0-pre.3 removed.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.5 - 2026-11-08

- Tests only. Import, transaction, protection, Inspector and build check tests remove what they leave in the Host: their fixture folders, an emptied `Step24AuthoringFixtures`, `Ae1LocalizationFixtures` or `T1LocalizationFixtures` root, and, once after the last test, the Addressables groups and labels the run created (`Ae1SaveGuard_*` and the extra Locale groups). Removing a group mid-run and creating one of the same name later in the same Editor session breaks the import's persisted verification, so groups are not removed per test. A test that saved the untitled scene into its folder opens an empty scene first.
- `RestartProofTests` is unchanged and still keeps its collection for the next run.
- Runtime and Editor code are unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.4 - 2026-11-07

- Fetch Sheets keeps each sheet's title and gid and shows a checkbox list, all on by default. Only checked sheets are downloaded, by gid. Manual Sheets names are still downloaded by name.
- The Google API Key field is a password field. The serialized field and its `CommonDataToolSettings` default are unchanged.
- Player build now stops with the table path and Locale code when a `Localization`-labelled StringTable has no registered Locale. `LocalizationManager` would throw on it during initialization, and its behaviour is unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.3 - 2026-11-06

- Google Sheet import is now Preview then Apply. Sheets with no keys are rejected, deletion impact is reported, and large deletions need confirmation.
- Preamble stripping stops at the first record.

Unity tests for this candidate are NOT_RUN.
