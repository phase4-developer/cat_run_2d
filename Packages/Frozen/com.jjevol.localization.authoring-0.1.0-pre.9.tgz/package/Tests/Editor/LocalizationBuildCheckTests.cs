using System;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.Build;
using UnityEditor.Localization;
using UnityEngine.Localization;
using jjevol.Step24.Tests;
using Object = UnityEngine.Object;

namespace jjevol.Localization.Authoring.Tests
{
    public class LocalizationBuildCheckTests
    {
        private static readonly Type Check = typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationBuildCheck", true);
        private GoogleSheetLocImporterWindow window;
        private string directory, collection;
        private HostResidue residue;
        private static string[] Found() => ((System.Collections.Generic.List<string>)Check.GetMethod("FindUnregisteredTables", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, null)).ToArray();
        private string[] OwnFound() => Found().Where(found => found.StartsWith(directory + "/", StringComparison.Ordinal)).ToArray();
        private static void RunCheck() => ((IPreprocessBuildWithReport)Activator.CreateInstance(Check)).OnPreprocessBuild(null);
        private static Locale Welsh => LocalizationEditorSettings.GetLocale("cy");

        [SetUp] public void Setup()
        {
            ImportTestUtil.Guard();
            collection = "t4_" + Guid.NewGuid().ToString("N"); directory = ImportTestUtil.Root + "/" + collection;
            residue = new HostResidue(directory); window = ImportTestUtil.Window(directory);
            ImportTestUtil.Import(window, directory, collection, "Key,cy\nhello,Helo\n");
        }
        [TearDown] public void Cleanup()
        {
            if (window) Object.DestroyImmediate(window);
            residue?.Clean();
        }

        [Test] public void ARegisteredTablePassesTheBuildCheck()
        {
            Assert.That(Welsh, Is.Not.Null);
            Assert.That(OwnFound(), Is.Empty);
        }
        [Test] public void ATableWhoseLocaleIsNotRegisteredStopsTheBuildAndIsNamed()
        {
            string path = AssetDatabase.GetAssetPath(ImportTestUtil.Table(collection, "cy"));
            LocalizationEditorSettings.RemoveLocale(Welsh);
            Assert.That(OwnFound().Single(), Does.Contain(path).And.Contain("'cy'"));
            var error = Assert.Throws<BuildFailedException>(RunCheck);
            Assert.That(error.Message, Does.Contain(path).And.Contain("'cy'").And.Contain("LocalizationManager"));
        }
    }
}
