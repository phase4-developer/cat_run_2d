//추가
using System;
using System.Collections;
using System.Reflection;
using NUnit.Framework;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Components;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.Step24.Tests
{
    public sealed class InspectorDrawWindow : EditorWindow
    {
        public UnityEditor.Editor Target;
        public int Draws;
        private void OnGUI(){if(Target){Target.OnInspectorGUI();Draws++;}}
    }
    public class InspectorTests
    {
        private GameObject _one,_two;private UnityEditor.Editor _editor;private HostResidue _residue;
        [SetUp]public void Setup()
        {
            ImportTestUtil.Guard();_residue=new HostResidue();_one=Text("First");_two=Text("Second");
            _editor=UnityEditor.Editor.CreateEditor(_one.GetComponent<LocalizeTmpTextEvent>());
        }
        private static GameObject Text(string name)
        {var go=new GameObject(name,typeof(RectTransform));go.SetActive(false);go.AddComponent<LocalizeTmpTextEvent>();return go;}
        [TearDown]public void Cleanup()
        {if(_editor)Object.DestroyImmediate(_editor);if(_one)Object.DestroyImmediate(_one);if(_two)Object.DestroyImmediate(_two);_residue?.Clean();}
        [Test]public void NativeCustomEditorAndOriginalPropertiesAndRecreation()
        {
            Assert.AreEqual(typeof(LocalizeTmpTextEventEditor),_editor.GetType());
            foreach(string name in new[]{"updateText","resolveMode","m_StringReference","tableCollection","entryKey","showDebugKeyWhenMissing","previewInEditMode","previewManualKeyInEditMode"})
                Assert.NotNull(_editor.serializedObject.FindProperty(name));
            Object.DestroyImmediate(_editor);_editor=UnityEditor.Editor.CreateEditor(_one.GetComponent<LocalizeTmpTextEvent>());
            Assert.AreEqual(typeof(LocalizeTmpTextEventEditor),_editor.GetType());
        }
        [Test]public void SerializedModeAndManualValuesApplyToActualComponent()
        {
            var so=_editor.serializedObject;so.Update();so.FindProperty("updateText").boolValue=true;
            so.FindProperty("resolveMode").enumValueIndex=(int)LocalizeTmpTextEvent.TextResolveMode.ManualKey;
            so.FindProperty("tableCollection").stringValue="fixture";so.FindProperty("entryKey").stringValue="hello";so.ApplyModifiedProperties();
            var local=_one.GetComponent<LocalizeTmpTextEvent>();Assert.IsTrue(local.UpdateText);Assert.AreEqual(LocalizeTmpTextEvent.TextResolveMode.ManualKey,local.ResolveMode);
            Assert.AreEqual("fixture",local.TableCollection);Assert.AreEqual("hello",local.EntryKey);
        }
        [Test]public void OriginalMultiObjectHelpersSupportUndoRedoAndClear()
        {
            Object.DestroyImmediate(_editor);_editor=UnityEditor.Editor.CreateEditor(new Object[]{_one.GetComponent<LocalizeTmpTextEvent>(),_two.GetComponent<LocalizeTmpTextEvent>()});
            Undo.IncrementCurrentGroup();ImportTestUtil.Invoke(_editor,"SetCollectionForTargets","fixture");Undo.FlushUndoRecordObjects();
            Assert.AreEqual("fixture",_one.GetComponent<LocalizeTmpTextEvent>().TableCollection);Assert.AreEqual("fixture",_two.GetComponent<LocalizeTmpTextEvent>().TableCollection);
            Undo.PerformUndo();Assert.AreEqual("",_one.GetComponent<LocalizeTmpTextEvent>().TableCollection);Assert.AreEqual("",_two.GetComponent<LocalizeTmpTextEvent>().TableCollection);
            Undo.PerformRedo();Assert.AreEqual("fixture",_one.GetComponent<LocalizeTmpTextEvent>().TableCollection);
            ImportTestUtil.Invoke(_editor,"SetEntryKeyByObjectName");Assert.AreEqual("First",_one.GetComponent<LocalizeTmpTextEvent>().EntryKey);Assert.AreEqual("Second",_two.GetComponent<LocalizeTmpTextEvent>().EntryKey);
            ImportTestUtil.Invoke(_editor,"ClearManualKey");Assert.AreEqual("",_one.GetComponent<LocalizeTmpTextEvent>().EntryKey);
        }
        [Test]public void LegacyReferenceTransferAndDisablePreservePublicRuntimeContract()
        {
            var legacy=_one.AddComponent<LocalizeStringEvent>();legacy.StringReference=new LocalizedString("step24-runtime","hello");
            ImportTestUtil.Invoke(_editor,"ImportFromLegacy",_one.GetComponent<LocalizeTmpTextEvent>(),legacy,true);
            Assert.IsFalse(legacy.enabled);Assert.IsTrue(_one.GetComponent<LocalizeTmpTextEvent>().UpdateText);Assert.IsTrue(_one.GetComponent<LocalizeTmpTextEvent>().HasStringReference);
        }
        [Test]public void PrefabAssetSaveReloadKeepsFieldsAndScriptGuid()
        {
            string folder=_residue.Track(ImportTestUtil.Root+"/Inspector-"+Guid.NewGuid().ToString("N"));System.IO.Directory.CreateDirectory(folder);AssetDatabase.Refresh();
            ImportTestUtil.Invoke(_editor,"SetCollectionForTargets","fixture");ImportTestUtil.Invoke(_editor,"SetEntryKeyByObjectName");
            string path=folder+"/Text.prefab";PrefabUtility.SaveAsPrefabAsset(_one,path);AssetDatabase.SaveAssets();AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceUpdate);
            var loaded=AssetDatabase.LoadAssetAtPath<GameObject>(path).GetComponent<LocalizeTmpTextEvent>();
            Assert.AreEqual("fixture",loaded.TableCollection);Assert.AreEqual("First",loaded.EntryKey);
            var script=MonoScript.FromMonoBehaviour(loaded);Assert.AreEqual("5beb6f6c477480148a6eef02f804712b",AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(script)));
        }
        [Test]public void PrefabInstanceButtonEditPersistsAcrossSceneReload()
        {
            string folder=_residue.Track(ImportTestUtil.Root+"/Override-"+Guid.NewGuid().ToString("N"));System.IO.Directory.CreateDirectory(folder);AssetDatabase.Refresh();
            string prefabPath=folder+"/Text.prefab";PrefabUtility.SaveAsPrefabAsset(_one,prefabPath);
            var initial=SceneManager.GetActiveScene();
            if(string.IsNullOrEmpty(initial.path))Assert.IsTrue(EditorSceneManager.SaveScene(initial,folder+"/Initial.unity"));
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
            var instance=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath),scene);instance.name="OverrideName";
            var instanceEditor=UnityEditor.Editor.CreateEditor(instance.GetComponent<LocalizeTmpTextEvent>());
            try
            {
                ImportTestUtil.Invoke(instanceEditor,"SetCollectionForTargets","fixture");ImportTestUtil.Invoke(instanceEditor,"SetEntryKeyByObjectName");Undo.FlushUndoRecordObjects();
                string path=folder+"/Scene.unity";Assert.IsTrue(EditorSceneManager.SaveScene(scene,path));EditorSceneManager.CloseScene(scene,true);
                scene=EditorSceneManager.OpenScene(path,OpenSceneMode.Additive);
                var local=scene.GetRootGameObjects()[0].GetComponent<LocalizeTmpTextEvent>();
                Assert.AreEqual("fixture",local.TableCollection);Assert.AreEqual("OverrideName",local.EntryKey,"Inspector button edit must survive Prefab instance reload");
            }
            finally{if(instanceEditor)Object.DestroyImmediate(instanceEditor);if(scene.IsValid()&&scene.isLoaded)EditorSceneManager.CloseScene(scene,true);}
        }
        [UnityTest]public IEnumerator ActualInspectorGuiHandlesLayoutRepaintForEveryMode()
        {
            var window=ScriptableObject.CreateInstance<InspectorDrawWindow>();window.Target=_editor;window.position=new Rect(10,10,500,650);window.ShowUtility();
            try
            {
                foreach(var mode in new[]{LocalizeTmpTextEvent.TextResolveMode.StringReference,LocalizeTmpTextEvent.TextResolveMode.ManualKey,LocalizeTmpTextEvent.TextResolveMode.StringReferenceThenManualKey})
                {
                    _one.GetComponent<LocalizeTmpTextEvent>().SetUpdateText(true,false);_one.GetComponent<LocalizeTmpTextEvent>().SetResolveMode(mode,false);
                    window.SendEvent(new Event{type=EventType.Layout});window.SendEvent(new Event{type=EventType.Repaint});window.Repaint();yield return null;
                }
                Assert.Greater(window.Draws,0,"The real IMGUI inspector must execute, not just reflection helpers");
            }
            finally{window.Close();}
        }
        [Test]public void OriginalEditorWindowFilenameClassMismatchStillCreatesAndSerializes()
        {
            var window=ImportTestUtil.Window(_residue.Track(ImportTestUtil.Root+"/Window-"+Guid.NewGuid().ToString("N")));
            try
            {
                string path=AssetDatabase.GUIDToAssetPath("3ac4e4af0a291de4792f84052faf6640");
                StringAssert.EndsWith("GoogleSheetExporterWindow.cs",path);Assert.AreEqual("GoogleSheetLocImporterWindow",window.GetType().Name);
                var so=new SerializedObject(window);Assert.NotNull(so.FindProperty("spreadsheetUrlOrId"));Assert.NotNull(so.FindProperty("collectionSaveDir"));
                var script=MonoScript.FromScriptableObject(window);
                TestContext.WriteLine("Original filename mismatch: MonoScript="+(script?AssetDatabase.GetAssetPath(script):"<null>")+", GetClass="+(script&&script.GetClass()!=null?script.GetClass().FullName:"<null>"));
                var clone=ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
                try
                {
                    EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(window),clone);
                    Assert.AreEqual(so.FindProperty("collectionSaveDir").stringValue,new SerializedObject(clone).FindProperty("collectionSaveDir").stringValue);
                }
                finally{Object.DestroyImmediate(clone);}
                Assert.NotNull(typeof(GoogleSheetLocImporterWindow).GetMethod("ShowWindow"));
                Assert.IsTrue(Attribute.IsDefined(typeof(LocalizeTmpTextEventEditor),typeof(CanEditMultipleObjects)));
                Assert.AreEqual(typeof(LocalizeTmpTextEventEditor),AssetDatabase.LoadAssetAtPath<MonoScript>(AssetDatabase.GUIDToAssetPath("3de1255ca6b5efb4aaa669d4385d3ac1")).GetClass());
            }
            finally{Object.DestroyImmediate(window);}
        }
    }
}
//추가 종료
