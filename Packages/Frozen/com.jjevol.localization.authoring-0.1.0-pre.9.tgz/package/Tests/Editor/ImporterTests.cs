//추가
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.Localization;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.Step24.Tests
{
    internal static class ImportTestUtil
    {
        public static readonly string Root="Assets/Step24AuthoringFixtures";
        public static void Guard()
        {
            string assets=Path.GetFullPath(Application.dataPath).Replace('\\','/').TrimEnd('/');
            if(!assets.Contains("/.local/step24/AuthoringHost/")
                && !assets.Contains("/.local/validation-current/")
                && !assets.Contains("/.local/qa/Hosts/CombinedValidationHost/")
                && !assets.Equals("C:/Project/JJEvolFramework/.local/ae1-20261104-4465/Host/Assets",StringComparison.OrdinalIgnoreCase)
                && !assets.Equals("C:/Project/JJEvolFramework/.local/ae1-20261104-4465/FrozenHost/Assets",StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Only approved AuthoringHost fixtures");
        }
        public static void Set(object target,string field,object value)=>target.GetType().GetField(field,BindingFlags.NonPublic|BindingFlags.Instance).SetValue(target,value);
        public static object Invoke(object target,string method,params object[] values)
        {
            try{return target.GetType().GetMethod(method,BindingFlags.NonPublic|BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static).Invoke(target,values);}
            catch(TargetInvocationException ex){System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex.InnerException).Throw();throw;}
        }
        public static GoogleSheetLocImporterWindow Window(string directory)
        {
            Guard();Directory.CreateDirectory(directory+"/Tables");AssetDatabase.Refresh();
            var window=ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            Set(window,"collectionSaveDir",directory+"/Tables");Set(window,"spreadsheetUrlOrId",string.Empty);Set(window,"googleApiKey",string.Empty);
            return window;
        }
        public static void Import(GoogleSheetLocImporterWindow window,string directory,string collection,string content,bool tsv=false)
        {
            string path=directory+"/Input"+(tsv?".tsv":".csv");File.WriteAllText(path,content,new UTF8Encoding(true));
            // This is exactly the production path called after DownloadOneSheetToFile; no network or alternate parser.
            Invoke(window,"ImportFileToCollection",path,collection,tsv);
        }
        public static StringTable Table(string collection,string locale)=>LocalizationEditorSettings.GetStringTableCollection(collection).GetTable(new LocaleIdentifier(locale)) as StringTable;
    }
    /// Removes what one test leaves in a Host that runs other Localization tests later: its folders and the locales
    /// inside them. Addressables groups and labels stay until RunResidue removes them after the whole run.
    internal sealed class HostResidue
    {
        private readonly List<string> _folders=new List<string>();
        public HostResidue(params string[] folders)=>_folders.AddRange(folders);
        public string Track(string folder){_folders.Add(folder);return folder;}
        public void Clean()
        {
            // A test that saved the untitled active scene into its folder would leave that path to be saved again later.
            string active=SceneManager.GetActiveScene().path;
            if(_folders.Any(folder=>active.StartsWith(folder+"/",StringComparison.Ordinal)))EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            foreach(string folder in _folders)
            {
                foreach(var locale in LocalizationEditorSettings.GetLocales().Where(locale=>locale&&AssetDatabase.GetAssetPath(locale).StartsWith(folder+"/",StringComparison.Ordinal)).ToArray())
                    LocalizationEditorSettings.RemoveLocale(locale);
                if(AssetDatabase.IsValidFolder(folder))AssetDatabase.DeleteAsset(folder);
            }
            var settings=AddressableAssetSettingsDefaultObject.Settings;if(!settings)return;
            foreach(var group in settings.groups.Where(group=>group))AssetDatabase.SaveAssetIfDirty(group);
            AssetDatabase.SaveAssetIfDirty(settings);
        }
    }
    public class ImporterTests
    {
        private GoogleSheetLocImporterWindow _window;private string _directory;private string _collection;private HostResidue _residue;
        [SetUp]public void Setup()
        {
            ImportTestUtil.Guard();_collection="step24_"+Guid.NewGuid().ToString("N");_directory=ImportTestUtil.Root+"/"+_collection;
            _residue=new HostResidue(_directory);_window=ImportTestUtil.Window(_directory);
        }
        [TearDown]public void Cleanup()
        {
            if(_window)Object.DestroyImmediate(_window);EditorUtility.ClearProgressBar();
            _residue?.Clean();
        }
        private void Import(string content,bool tsv=false)=>ImportTestUtil.Import(_window,_directory,_collection,content,tsv);
        private StringTable Table(string locale)=>ImportTestUtil.Table(_collection,locale);
        [Test]public void CsvCreatesCollectionLocalesAndActualUtf8QuotedValues()
        {
            Import("Key,ko,en,ja,id,Comment\nhello,안녕하세요,\"Hello, \"\"friend\"\"\nnext line\",こんにちは,Halo,ignored\n");
            Assert.AreEqual("안녕하세요",Table("ko").GetEntry("hello").Value);
            Assert.AreEqual("Hello, \"friend\"\nnext line",Table("en").GetEntry("hello").Value);
            Assert.AreEqual("こんにちは",Table("ja").GetEntry("hello").Value);Assert.AreEqual("Halo",Table("id").GetEntry("hello").Value);
            Assert.NotNull(LocalizationEditorSettings.GetLocale(new LocaleIdentifier("ja")));Assert.NotNull(LocalizationEditorSettings.GetLocale(new LocaleIdentifier("id")));
        }
        [Test]public void TsvRoundTripSupportsQuotedTabsQuotesAndEmbeddedNewline()
        {
            string csv="Key,ko,en\nhello,테스트,\"tab\tinside and \"\"quote\"\"\nnext\"\n";
            string tsv=(string)ImportTestUtil.Invoke(_window,"ConvertCsvToTsv",csv);Import(tsv,true);
            Assert.AreEqual("tab\tinside and \"quote\"\nnext",Table("en").GetEntry("hello").Value);
        }
        [Test]public void ReimportKeepsSharedIdsTableGuidsLocaleGuidsAndLatestValue()
        {
            Import("Key,ko,en\nkeep,하나,one\nempty,,\n");var collection=LocalizationEditorSettings.GetStringTableCollection(_collection);
            long id=collection.SharedData.GetEntry("keep").Id;string tableGuid=AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Table("en")));
            string localeGuid=AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(LocalizationEditorSettings.GetLocale(new LocaleIdentifier("en"))));
            Import("Key,ko,en\nkeep,둘,two\nempty,,\n");Import("Key,ko,en\nkeep,둘,two\nempty,,\n");
            Assert.AreEqual(id,collection.SharedData.GetEntry("keep").Id);Assert.AreEqual("two",Table("en").GetEntry(id).Value);
            Assert.AreEqual(tableGuid,AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Table("en"))));
            Assert.AreEqual(localeGuid,AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(LocalizationEditorSettings.GetLocale(new LocaleIdentifier("en")))));
            Assert.AreEqual(2,collection.SharedData.Entries.Count);
            Assert.NotNull(Table("en").GetEntry("empty"));Assert.AreEqual("",Table("en").GetEntry("empty").Value);Assert.IsNull(Table("en").GetEntry("absent"));
            string path=AssetDatabase.GetAssetPath(Table("en"));AssetDatabase.SaveAssets();AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceUpdate);
            Assert.AreEqual("two",AssetDatabase.LoadAssetAtPath<StringTable>(path).GetEntry(id).Value);
        }
        [Test]public void MissingRowsDeleteExistingKeysAndOrphansAcrossAllTables()
        {
            Import("Key,ko,en\nkeep,유지,keep\nremove,삭제,remove\n");var collection=LocalizationEditorSettings.GetStringTableCollection(_collection);
            var table=Table("en");table.AddEntry("orphan","orphan");long orphan=collection.SharedData.GetEntry("orphan").Id;collection.SharedData.RemoveKey(orphan);Assert.NotNull(table.GetEntry(orphan));
            Import("Key,ko,en\nkeep,수정,updated\n");Assert.IsNull(collection.SharedData.GetEntry("remove"));
            foreach(var current in collection.StringTables){Assert.IsNull(current.GetEntry("remove"));Assert.IsNull(current.GetEntry(orphan));}
            Assert.AreEqual("updated",Table("en").GetEntry("keep").Value);
        }
        [Test]public void DuplicateKeyPreservesOriginalLastRowWinsAndShortRowsRemainExistingNull()
        {
            Import("Key,ko,en\nsame,첫째,first\nsame,둘째,last\nshort,짧음\n");
            Assert.AreEqual("last",Table("en").GetEntry("same").Value);Assert.AreEqual("둘째",Table("ko").GetEntry("same").Value);
            Assert.NotNull(Table("en").GetEntry("short"));Assert.IsNull(Table("en").GetEntry("short").Value,"Original row padding leaves an existing null value, rather than a missing entry");
        }
        [TestCase("Key,ko,en,EN\nkeep,a,b,c\n")]
        [TestCase("Key,ko,zzzzzzzz\nkeep,a,b\n")]
        [TestCase("Key,ko,en,en-US\nkeep,a,b,c\n")]
        [TestCase("Wrong,ko,en\nkeep,a,b\n")]
        public void InvalidHeadersLeaveExistingAssetsUnchanged(string invalid)
        {
            Import("Key,ko,en\nkeep,기존,original\n");var table=Table("en");long id=table.GetEntry("keep").KeyId;
            string path=AssetDatabase.GetAssetPath(table);byte[] before=File.ReadAllBytes(path);
            if(!invalid.StartsWith("Wrong"))LogAssert.Expect(LogType.Assert,new Regex("DisplayDialog: Localization Import",RegexOptions.Singleline));
            Assert.Catch<Exception>(()=>Import(invalid));
            Assert.AreEqual("original",table.GetEntry("keep").Value);Assert.AreEqual(id,table.GetEntry("keep").KeyId);CollectionAssert.AreEqual(before,File.ReadAllBytes(path));
        }
        [Test]public void StrictLocaleCheckFailsBeforeCreatingMissingCollectionAndCanRetry()
        {
            ImportTestUtil.Set(_window,"strictLocaleCheck",true);
            LogAssert.Expect(LogType.Assert,new Regex("DisplayDialog: Missing Locales/Tables",RegexOptions.Singleline));
            Assert.Throws<Exception>(()=>Import("Key,ko,en\na,가,a\n"));
            Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(_collection));
            ImportTestUtil.Set(_window,"strictLocaleCheck",false);Import("Key,ko,en\na,가,a\n");Assert.NotNull(Table("en").GetEntry("a"));
        }
        [Test]public void ProductionImportAssignsLocalizationAddressableLabel()
        {
            Import("Key,ko,en\nhello,안녕,hello\n");var settings=AddressableAssetSettingsDefaultObject.Settings;
            foreach(var table in LocalizationEditorSettings.GetStringTableCollection(_collection).StringTables)
            {var entry=settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(table)));Assert.NotNull(entry);Assert.IsTrue(entry.labels.Contains("Localization"));}
        }
        [Test]public void InvalidUtf8DoesNotMutateExistingCollection()
        {
            Import("Key,ko,en\nkeep,기존,original\n");string path=_directory+"/invalid.csv";File.WriteAllBytes(path,Encoding.UTF8.GetBytes("Key,ko,en\nkeep,existing,").Concat(new byte[]{0xff}).ToArray());
            Assert.Throws<DecoderFallbackException>(()=>ImportTestUtil.Invoke(_window,"ImportFileToCollection",path,_collection,false));
            Assert.AreEqual("original",Table("en").GetEntry("keep").Value);
        }
        [Test]public void UnterminatedCsvQuoteMustNotDeleteExistingAssets()
        {
            Import("Key,ko,en\nkeep,기존,original\nother,유지,preserve\n");var table=Table("en");string path=AssetDatabase.GetAssetPath(table);byte[] before=File.ReadAllBytes(path);
            Assert.Throws<FormatException>(()=>Import("Key,ko,en\nnew,새값,\"unterminated\n"));
            Assert.AreEqual("original",table.GetEntry("keep").Value);Assert.AreEqual("preserve",table.GetEntry("other").Value);CollectionAssert.AreEqual(before,File.ReadAllBytes(path));
        }
    }
}
/// Outside any namespace, so it wraps every test in this assembly. Groups and labels an import created are removed
/// only after the last test: removing one and creating a group of the same name later in the same Editor session
/// makes the import's persisted verification fail and leaves a recovery journal that blocks every later import.
[SetUpFixture]
public sealed class LocalizationAuthoringRunResidue
{
    private static readonly string[] Roots={"Assets/Step24AuthoringFixtures","Assets/Ae1LocalizationFixtures","Assets/T1LocalizationFixtures"};
    private readonly HashSet<string> _groups=new HashSet<string>(),_labels=new HashSet<string>();
    // Without settings at the start there is no snapshot, and cleaning would remove every group the run's SDK created, Default Local Group included.
    private bool _hadSettings;
    [OneTimeSetUp]public void Snapshot()
    {
        var settings=AddressableAssetSettingsDefaultObject.Settings;
        _hadSettings=settings;
        if(settings){_groups.UnionWith(settings.groups.Where(group=>group).Select(group=>group.Guid));_labels.UnionWith(settings.GetLabels());}
    }
    [OneTimeTearDown]public void Clean()
    {
        foreach(string root in Roots)if(Directory.Exists(root)&&Directory.GetFileSystemEntries(root).Length==0)AssetDatabase.DeleteAsset(root);
        var settings=AddressableAssetSettingsDefaultObject.Settings;if(!settings||!_hadSettings)return;
        foreach(var group in settings.groups.Where(group=>group&&!_groups.Contains(group.Guid)).ToArray())settings.RemoveGroup(group);
        foreach(string label in settings.GetLabels().Where(label=>!_labels.Contains(label)).ToArray())settings.RemoveLabel(label);
        foreach(var group in settings.groups.Where(group=>group))AssetDatabase.SaveAssetIfDirty(group);
        AssetDatabase.SaveAssetIfDirty(settings);
    }
}
//추가 종료
