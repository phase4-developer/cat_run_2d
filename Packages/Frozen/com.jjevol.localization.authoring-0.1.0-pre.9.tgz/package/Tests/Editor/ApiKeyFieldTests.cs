using System.IO;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace jjevol.Localization.Authoring.Tests
{
    public class ApiKeyFieldTests
    {
        private static readonly FieldInfo Field = typeof(GoogleSheetLocImporterWindow).GetField("googleApiKey", BindingFlags.NonPublic | BindingFlags.Instance);

        [Test] public void TheKeyIsDrawnOnlyThroughAPasswordField()
        {
            // IMGUI masks the value while drawing, so the drawing call itself is what can regress.
            string package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(GoogleSheetLocImporterWindow).Assembly).resolvedPath;
            string source = File.ReadAllText(Path.Combine(package, "Editor", "GoogleSheetExporterWindow.cs"));
            StringAssert.Contains("googleApiKey = EditorGUILayout.PasswordField(", source);
            StringAssert.DoesNotContain("googleApiKey = EditorGUILayout.TextField(", source);
        }
        [Test] public void TheSerializedFieldAndItsDefaultAreKept()
        {
            Assert.IsNotNull(Field.GetCustomAttribute<SerializeField>());
            var window = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            try { Assert.AreEqual(jjevol.CommonDataToolSettings.Current.GoogleApiKey, Field.GetValue(window)); }
            finally { Object.DestroyImmediate(window); }
        }
    }
}
