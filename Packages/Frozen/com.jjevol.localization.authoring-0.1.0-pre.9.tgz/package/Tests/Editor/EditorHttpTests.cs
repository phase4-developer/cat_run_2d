using System;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine.TestTools;

namespace jjevol.Localization.Authoring.Tests
{
    public class EditorHttpTests
    {
        private TcpListener listener;
        private static Task<string> Request(string url, int timeout, CancellationToken token)
        {
            var type = typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationEditorHttp", true);
            return (Task<string>)type.GetMethod("GetAsync", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { url, timeout, token });
        }
        [SetUp] public void Setup()
        {
            jjevol.Step24.Tests.ImportTestUtil.Guard();
            listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
        }
        [TearDown] public void Cleanup() => listener?.Stop();
        private string Url => "http://127.0.0.1:" + ((IPEndPoint)listener.LocalEndpoint).Port + "/synthetic?key=synthetic_loopback_key";

        [UnityTest] public IEnumerator RealStalledTransportTimesOutAndTaskCompletesWithoutSecret()
        {
            Task<TcpClient> accepted = listener.AcceptTcpClientAsync();
            Task<string> request = Request(Url, 1, CancellationToken.None);
            int frames = 0;
            double end = UnityEditor.EditorApplication.timeSinceStartup + 8;
            while (!request.IsCompleted && UnityEditor.EditorApplication.timeSinceStartup < end) { ++frames; yield return null; }
            if (accepted.IsCompletedSuccessfully) accepted.Result.Dispose();
            Assert.IsTrue(request.IsCompleted, "Timeout must complete even when request.Dispose runs.");
            Assert.IsTrue(request.IsFaulted); Assert.Greater(frames, 1, "The Editor must continue updating.");
            StringAssert.Contains("timeout", request.Exception.ToString().ToLowerInvariant());
            StringAssert.DoesNotContain("synthetic_loopback_key", request.Exception.ToString());
        }

        [UnityTest] public IEnumerator RealTransportCancellationCompletesAndDisposesRequest()
        {
            Task<TcpClient> accepted = listener.AcceptTcpClientAsync();
            using var cancellation = new CancellationTokenSource();
            Task<string> request = Request(Url, 20, cancellation.Token);
            yield return null; cancellation.Cancel();
            double end = UnityEditor.EditorApplication.timeSinceStartup + 5;
            while (!request.IsCompleted && UnityEditor.EditorApplication.timeSinceStartup < end) yield return null;
            if (accepted.IsCompletedSuccessfully) accepted.Result.Dispose();
            Assert.IsTrue(request.IsCanceled);
        }

        [UnityTest] public IEnumerator ActualHttpFailurePreservesStatusAndRedactsEchoedQuery()
        {
            Task<TcpClient> accepted = listener.AcceptTcpClientAsync();
            Task<string> request = Request(Url, 5, CancellationToken.None);
            double acceptEnd = UnityEditor.EditorApplication.timeSinceStartup + 5;
            while (!accepted.IsCompleted && UnityEditor.EditorApplication.timeSinceStartup < acceptEnd) yield return null;
            Assert.IsTrue(accepted.IsCompleted, "The loopback transport did not connect.");
            using var client = accepted.Result;
            byte[] response = Encoding.ASCII.GetBytes("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
            client.GetStream().Write(response, 0, response.Length);
            double end = UnityEditor.EditorApplication.timeSinceStartup + 7;
            while (!request.IsCompleted && UnityEditor.EditorApplication.timeSinceStartup < end) yield return null;
            Assert.IsTrue(request.IsFaulted);
            StringAssert.Contains("403", request.Exception.ToString());
            StringAssert.DoesNotContain("synthetic_loopback_key", request.Exception.ToString());
        }
    }
}
