using System;
using System.Reflection;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Localization.Authoring.Tests
{
    public class HttpDiagnosticTests
    {
        private static readonly Type Diagnostics = typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationHttpDiagnostics", true);
        private static object Call(string method, params object[] values)
            => Diagnostics.GetMethod(method, BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, values);

        [Test]
        public void HttpFailurePreservesStatusAndCauseWithoutUrlCredentialsOrInnerException()
        {
            const string key = "synthetic_google_key_7e248";
            const string token = "synthetic_access_token_934a";
            string url = "https://sheets.googleapis.com/v4/spreadsheets/test?fields=sheets&key=" + key + "&access_token=" + token;
            var failure = (Exception)Call("CreateFailure", url, 403L, "Forbidden: " + url + " echoed " + key + " " + token);
            string diagnostic = failure.ToString();
            StringAssert.Contains("HTTP Error 403", diagnostic);
            StringAssert.Contains("Forbidden", diagnostic);
            StringAssert.Contains("https://sheets.googleapis.com/v4/spreadsheets/test", diagnostic);
            StringAssert.DoesNotContain(key, diagnostic);
            StringAssert.DoesNotContain(token, diagnostic);
            StringAssert.DoesNotContain("?", diagnostic);
            Assert.IsNull(failure.InnerException);
        }

        [Test]
        public void EncodedQueryUserInfoFragmentAndAuthorizationAreRemoved()
        {
            const string credential = "synthetic+key/value";
            string url = "https://synthetic_user:synthetic_password@docs.google.com/test?key=" + Uri.EscapeDataString(credential) + "#synthetic_fragment";
            string message = "Timeout for " + url + " echoed " + credential + "\nAuthorization: Bearer synthetic_bearer";
            var failure = (Exception)Call("CreateFailure", url, 0L, message);
            string diagnostic = failure.ToString();
            foreach (string secret in new[] { credential, Uri.EscapeDataString(credential), "synthetic_user", "synthetic_password", "synthetic_fragment", "synthetic_bearer" })
                StringAssert.DoesNotContain(secret, diagnostic);
            StringAssert.Contains("Timeout", diagnostic);
            StringAssert.Contains("HTTP Error 0", diagnostic);
        }

        [Test]
        public void DisplayAndLogTextDoNotExposeCredentialFromUnrelatedException()
        {
            const string key = "synthetic_layout_key_319d";
            var failure = new FormatException("Invalid metadata for " + key, new Exception("inner " + key));
            string display = (string)Call("ForDisplay", failure, key);
            StringAssert.Contains("FormatException", display);
            StringAssert.Contains("Invalid metadata", display);
            StringAssert.DoesNotContain(key, display);
            LogAssert.Expect(LogType.Error, new Regex("^" + Regex.Escape(display) + "$"));
            Debug.LogError(display);
        }

        [TestCase("not a valid URL?key=synthetic_invalid_key")]
        [TestCase(null)]
        public void InvalidRequestTargetIsNeverEchoed(string url)
        {
            var failure = (Exception)Call("CreateFailure", url, 0L, "Connection failed");
            StringAssert.Contains("Connection failed", failure.Message);
            StringAssert.Contains("<request URL omitted>", failure.Message);
            StringAssert.DoesNotContain("synthetic_invalid_key", failure.ToString());
        }

        [Test]
        public void KnownCredentialEchoedInRedirectPathIsRedacted()
        {
            const string key = "synthetic_redirect_key_392f";
            string display = (string)Call("ForDisplay", new Exception("redirect https://example.test/error/" + key), key);
            StringAssert.DoesNotContain(key, display);
            StringAssert.Contains("https://example.test/error/", display);
        }

        [Test]
        public void SensitiveQueryCredentialEchoedInAnotherUrlPathIsRedactedWithoutHidingSafeHost()
        {
            const string key = "synthetic_query_path_key_7b51";
            string url = "https://sheets.googleapis.com/test?fields=sheets&key=" + key;
            var failure = (Exception)Call("CreateFailure", url, 403L, "redirect https://example.test/error/" + key);
            StringAssert.DoesNotContain(key, failure.ToString());
            StringAssert.Contains("https://example.test/error/", failure.Message);
            StringAssert.Contains("https://sheets.googleapis.com/test", failure.Message);
        }
    }
}
