//추가
using System;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Localization;
using UnityEngine;
using UnityEngine.Localization;
using Object=UnityEngine.Object;
namespace jjevol.Step24.Tests
{
    public class RestartProofTests
    {
        [Serializable]private class Proof{public string sharedGuid,enGuid,localeGuid;public long id;}
        [Test]public void ProductionImportPersistsAndReimportsAfterEditorRestart()
        {
            ImportTestUtil.Guard();const string collectionName="step24_restart";string directory=ImportTestUtil.Root+"/Restart";
            string baseline=Path.GetFullPath(Path.Combine(Application.dataPath,"../Step24RestartBaseline.json"));
            Proof prior=File.Exists(baseline)?JsonUtility.FromJson<Proof>(File.ReadAllText(baseline)):null;
            var window=ImportTestUtil.Window(directory);
            try
            {
                // This collection stays in the Host for the next run, so it uses only locales the shared Host keeps registered.
                ImportTestUtil.Import(window,directory,collectionName,"Key,ko,en\nhello,재시작 검증,Hello restart\nempty,,\n");
                var collection=LocalizationEditorSettings.GetStringTableCollection(collectionName);var table=ImportTestUtil.Table(collectionName,"en");
                var actual=new Proof{sharedGuid=AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(collection.SharedData)),enGuid=AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(table)),
                    localeGuid=AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(LocalizationEditorSettings.GetLocale(new LocaleIdentifier("en")))),id=collection.SharedData.GetEntry("hello").Id};
                Assert.AreEqual("Hello restart",table.GetEntry("hello").Value);Assert.AreEqual("",table.GetEntry("empty").Value);
                if(prior!=null){Assert.AreEqual(prior.sharedGuid,actual.sharedGuid);Assert.AreEqual(prior.enGuid,actual.enGuid);Assert.AreEqual(prior.localeGuid,actual.localeGuid);Assert.AreEqual(prior.id,actual.id);}
                else File.WriteAllText(baseline,JsonUtility.ToJson(actual));
                AssetDatabase.SaveAssets();
            }
            finally{Object.DestroyImmediate(window);}
        }
    }
}
//추가 종료
