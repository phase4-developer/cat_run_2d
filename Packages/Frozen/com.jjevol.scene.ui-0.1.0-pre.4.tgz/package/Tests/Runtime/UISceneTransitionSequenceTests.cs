using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using Cysharp.Threading.Tasks;
using jjevol;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;
#if UNITY_EDITOR
using UnityEditor;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
#endif

namespace JJEvolSceneUITests
{
    /// <summary>Runs the real presenter against a real UIManager prefab, loading prefab and scene assets.</summary>
    [PrebuildSetup("JJEvolSceneUITests.SceneUIFixture")]
    [PostBuildCleanup("JJEvolSceneUITests.SceneUIFixture")]
    public sealed class UISceneTransitionSequenceTests
    {
        const string Plain = "JJEvolSceneUI_Plain";
        const string Holding = "JJEvolSceneUI_Holding";
        const string LoadingKey = "LoadingSceneScreen";

        ISceneTransitionPresenter _installedPresenter;
        ObservedPresenter _observed;
        GameObject _persistentCreator;

        static SceneLoadOption Fast(SceneLoadOption option)
        {
            option.sourceId = BuildSceneSource.SourceId;
            option.unloadUnusedAssets = false;
            option.minimumLoadingSeconds = 0f;
            if (option.loadType != SceneLoadType.None)
            {
                option.fadeInDuration = 0.02f;
                option.fadeOutDuration = 0.02f;
            }

            return option;
        }

        [UnitySetUp]
        public IEnumerator SetUp()
        {
#if UNITY_EDITOR
            var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(SceneUIFixturePaths.Pipeline);
            GraphicsSettings.defaultRenderPipeline = pipeline;
            QualitySettings.renderPipeline = pipeline;
#endif
            UIManager.applicationIsQuitting = false;
            AddressablesManager.applicationIsQuitting = false;
            FixtureLoadingView.Live.Clear();
            FixtureLoadingView.LastProgress = 0f;

            var initialize = Addressables.InitializeAsync(false);
            yield return initialize;
            Addressables.Release(initialize);

            _installedPresenter = CustomSceneManager.Presenter;
            _observed = new ObservedPresenter(new UISceneTransitionPresenter());
            CustomSceneManager.Presenter = _observed;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (_persistentCreator != null) Object.Destroy(_persistentCreator);
            yield return null;

            // A Single load leaves a test scene as the only one, and the last scene cannot be unloaded.
            var anchor = SceneManager.CreateScene("anchor-" + Guid.NewGuid().ToString("N"));
            SceneManager.SetActiveScene(anchor);
            for (int i = SceneManager.sceneCount - 1; i >= 0; i--)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (scene != anchor && scene.isLoaded) yield return SceneManager.UnloadSceneAsync(scene);
            }

            yield return null;
            if (UIManager.HasInstance) Object.Destroy(UIManager.Instance.gameObject);
            if (CustomSceneManager.HasInstance) Object.Destroy(CustomSceneManager.Instance.gameObject);
            yield return null;
            yield return null;

            CustomSceneManager.Presenter = _installedPresenter;
            CustomSceneManager.OnLoadStart = null;
            CustomSceneManager.OnLoadEnd = null;
            CustomSceneManager.OnProgressChanged = null;
            Assert.That(UIManager.HasInstance, Is.False, "A test left UI behind for the next one.");
        }

        async UniTask<UIManager> StartWithPersistentCreatorAsync()
        {
            await CustomSceneManager.Instance.LoadSceneAsync(Plain, Fast(SceneLoadOption.Direct()));

            _persistentCreator = new GameObject("persistent creator");
            Object.DontDestroyOnLoad(_persistentCreator);
            var creator = _persistentCreator.AddComponent<UIManagerCreater>();
            await creator.StartInitAsync();

            _observed.Log.Clear();
            return UIManager.Instance;
        }

        [UnityTest]
        public IEnumerator LoadingKeepsTheCoverWithAPersistentCreator() => UniTask.ToCoroutine(async () =>
        {
            var ui = await StartWithPersistentCreatorAsync();

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Holding, Fast(SceneLoadOption.Loading()));

            Assert.That(result.IsSuccess, Is.True, result.Exception?.Message);
            Assert.That(_observed.Log, Is.EqualTo(new[]
            {
                "cover fade=on view=1",
                "show fade=off view=1",
                "activated fade=off view=1",
                "prepared fade=off view=1",
                "hide fade=on view=0",
                "reveal fade=off view=0"
            }));
            Assert.That(UIManager.Instance, Is.SameAs(ui));
            Assert.That(FixtureLoadingView.LastProgress, Is.GreaterThan(0f));
        });

        [UnityTest]
        public IEnumerator FadeOnlyStaysCoveredUntilReveal() => UniTask.ToCoroutine(async () =>
        {
            await StartWithPersistentCreatorAsync();

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Holding, Fast(SceneLoadOption.WhiteFade()));

            Assert.That(result.IsSuccess, Is.True, result.Exception?.Message);
            Assert.That(_observed.Log, Is.EqualTo(new[]
            {
                "cover fade=on view=0",
                "show fade=on view=0",
                "activated fade=on view=0",
                "prepared fade=on view=0",
                "hide fade=on view=0",
                "reveal fade=off view=0"
            }));
        });

        [UnityTest]
        public IEnumerator DirectShowsNothing() => UniTask.ToCoroutine(async () =>
        {
            await StartWithPersistentCreatorAsync();

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Holding, Fast(SceneLoadOption.Direct()));

            Assert.That(result.IsSuccess, Is.True, result.Exception?.Message);
            Assert.That(_observed.Log, Has.All.Contains("fade=off view=0"));
        });

        [UnityTest]
        public IEnumerator TransitionLeavesAnUnstartedCreatorUnstarted() => UniTask.ToCoroutine(async () =>
        {
            await CustomSceneManager.Instance.LoadSceneAsync(Plain, Fast(SceneLoadOption.Direct()));
            _persistentCreator = new GameObject("unstarted creator");
            Object.DontDestroyOnLoad(_persistentCreator);
            var creator = _persistentCreator.AddComponent<UIManagerCreater>();

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Holding, Fast(SceneLoadOption.Loading()));

            Assert.That(result.IsSuccess, Is.True, result.Exception?.Message);
            Assert.That(creator.IsStarted, Is.False);
            Assert.That(creator.IsInitialized, Is.False);
            Assert.That(UIManager.HasInstance, Is.False);
        });

        [UnityTest]
        public IEnumerator IntermediateSceneKeepsTheViewWithAPersistentCreator() => UniTask.ToCoroutine(async () =>
        {
            await StartWithPersistentCreatorAsync();
            var option = Fast(SceneLoadOption.Loading());
            option.intermediateScene = Holding;

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Plain, option);

            Assert.That(result.IsSuccess, Is.True, result.Exception?.Message);
            Assert.That(_observed.Log, Is.EqualTo(new[]
            {
                "cover fade=on view=1",
                "activated fade=on view=1",
                "prepared fade=on view=1",
                "show fade=off view=1",
                "activated fade=off view=1",
                "prepared fade=off view=1",
                "hide fade=on view=0",
                "reveal fade=off view=0"
            }));
            Assert.That(SceneManager.GetSceneByName(Holding).isLoaded, Is.False);
        });

        [UnityTest]
        public IEnumerator FailedLoadClearsTheScreenAndKeepsTheScene() => UniTask.ToCoroutine(async () =>
        {
            await StartWithPersistentCreatorAsync();
            var active = SceneManager.GetActiveScene();
            var source = new StallingSceneSource { Failure = new InvalidOperationException("broken bundle") };
            SceneSources.Register(source);
            try
            {
                var option = Fast(SceneLoadOption.Loading());
                option.sourceId = source.Id;
                LogAssert.Expect(LogType.Error, new Regex(@"^\[CustomSceneManager\] Load Failed:"));

                var result = await CustomSceneManager.Instance.LoadSceneAsync(StallingSceneSource.Key, option);

                Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
                Assert.That(result.SceneChanged, Is.False);
                Assert.That(_observed.Log, Is.EqualTo(new[]
                {
                    "cover fade=on view=1",
                    "show fade=off view=1",
                    "hide fade=on view=0",
                    "reveal fade=off view=0"
                }));
                Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(active));
            }
            finally
            {
                SceneSources.Unregister(source);
            }
        });

        [UnityTest]
        public IEnumerator CancelingClearsTheScreen() => UniTask.ToCoroutine(async () =>
        {
            await StartWithPersistentCreatorAsync();
            var source = new StallingSceneSource();
            SceneSources.Register(source);
            try
            {
                var option = Fast(SceneLoadOption.Loading());
                option.sourceId = source.Id;
                using var cancellation = new CancellationTokenSource();
                var pending = CustomSceneManager.Instance.LoadSceneAsync(StallingSceneSource.Key, option, null, cancellation.Token);

                while (!source.Started) await UniTask.Yield();
                cancellation.Cancel();
                var result = await pending;

                Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Canceled));
                Assert.That(_observed.Log[_observed.Log.Count - 1], Is.EqualTo("reveal fade=off view=0"));
            }
            finally
            {
                SceneSources.Unregister(source);
            }
        });

        [UnityTest]
        public IEnumerator MissingLoadingPrefabFallsBackToTheFade() => UniTask.ToCoroutine(async () =>
        {
            await StartWithPersistentCreatorAsync();
            LogAssert.ignoreFailingMessages = true;
            try
            {
                var result = await CustomSceneManager.Instance.LoadSceneAsync(Holding, Fast(SceneLoadOption.Loading("JJEvolSceneUI/MissingLoading")));

                Assert.That(result.IsSuccess, Is.True, result.Exception?.Message);
                // The cover step ends in a logged failure, so the first record is the step after it, with the fade still up.
                Assert.That(_observed.Log[0], Is.EqualTo("show fade=on view=0"));
                Assert.That(_observed.Log[_observed.Log.Count - 1], Is.EqualTo("reveal fade=off view=0"));
            }
            finally
            {
                LogAssert.ignoreFailingMessages = false;
            }
        });

        [UnityTest]
        public IEnumerator AnotherCallersLoadingViewSurvivesTheTransition() => UniTask.ToCoroutine(async () =>
        {
            var ui = await StartWithPersistentCreatorAsync();
            var other = await ui.AcquireLoadingAsync(LoadingKey);

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Holding, Fast(SceneLoadOption.Loading()));

            Assert.That(result.IsSuccess, Is.True, result.Exception?.Message);
            Assert.That(other.IsActive, Is.True);
            Assert.That(FixtureLoadingView.Live.Count, Is.EqualTo(1));

            other.Dispose();
            await UniTask.NextFrame();

            Assert.That(FixtureLoadingView.Live, Is.Empty);
        });
    }
}
