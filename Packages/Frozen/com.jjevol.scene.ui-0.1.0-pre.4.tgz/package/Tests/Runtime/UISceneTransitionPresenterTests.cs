using System.Collections;
using Cysharp.Threading.Tasks;
using jjevol;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace JJEvolSceneUITests
{
    public sealed class UISceneTransitionPresenterTests
    {
        [Test]
        public void InstallingThePackageSelectsThePresenter()
        {
            Assert.That(CustomSceneManager.Presenter, Is.InstanceOf<UISceneTransitionPresenter>());
        }

        [UnityTest]
        public IEnumerator EveryStepIsSafeWithoutAnyUI() => UniTask.ToCoroutine(async () =>
        {
            var presenter = new UISceneTransitionPresenter();
            var option = SceneLoadOption.Loading();

            await presenter.CoverAsync(option, default);
            await presenter.ShowLoadingAsync(option, default);
            presenter.SetProgress(0.5f);
            await presenter.PrepareSceneAsync(SceneManager.GetActiveScene(), default);
            await presenter.HideLoadingAsync(option);
            await presenter.RevealAsync(option);
        });
    }
}
