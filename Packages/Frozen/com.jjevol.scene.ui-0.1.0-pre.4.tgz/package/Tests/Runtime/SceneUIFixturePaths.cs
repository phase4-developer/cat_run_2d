namespace JJEvolSceneUITests
{
    public static class SceneUIFixturePaths
    {
        public const string Root = "Assets/JJEvolSceneUITests";
        public const string Pipeline = Root + "/Pipeline.asset";
    }
}
