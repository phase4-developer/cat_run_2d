using System.Collections.Generic;
using jjevol;
using UnityEngine;

namespace JJEvolSceneUITests
{
    // Saved inside a prefab, so it needs a file of its own for Unity to keep the script reference.
    public sealed class FixtureLoadingView : MonoBehaviour, IUILoadingProgressView
    {
        public static readonly List<FixtureLoadingView> Live = new List<FixtureLoadingView>();
        public static float LastProgress;

        void OnEnable() => Live.Add(this);

        void OnDisable() => Live.Remove(this);

        public void SetProgress(float progress01) => LastProgress = progress01;

        public void SetMessage(string message) { }
    }
}
