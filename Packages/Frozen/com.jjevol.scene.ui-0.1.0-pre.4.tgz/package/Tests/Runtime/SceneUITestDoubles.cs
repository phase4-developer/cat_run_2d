using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using jjevol;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace JJEvolSceneUITests
{
    /// <summary>Records what the player could see after every step of the real presenter.</summary>
    internal sealed class ObservedPresenter : ISceneTransitionPresenter
    {
        readonly ISceneTransitionPresenter _inner;

        public ObservedPresenter(ISceneTransitionPresenter inner) => _inner = inner;

        public List<string> Log { get; } = new List<string>();

        static string Screen
        {
            get
            {
                var fader = UIManager.HasInstance ? UIManager.Instance.Fader : null;
                bool faded = fader != null && fader.IsVisible;
                return $"fade={(faded ? "on" : "off")} view={FixtureLoadingView.Live.Count}";
            }
        }

        void Record(string step) => Log.Add(step + " " + Screen);

        public async UniTask CoverAsync(SceneLoadOption option, CancellationToken cancellationToken)
        {
            await _inner.CoverAsync(option, cancellationToken);
            Record("cover");
        }

        public async UniTask ShowLoadingAsync(SceneLoadOption option, CancellationToken cancellationToken)
        {
            await _inner.ShowLoadingAsync(option, cancellationToken);
            Record("show");
        }

        public void SetProgress(float progress) => _inner.SetProgress(progress);

        public async UniTask PrepareSceneAsync(Scene scene, CancellationToken cancellationToken)
        {
            Record("activated");
            await _inner.PrepareSceneAsync(scene, cancellationToken);
            Record("prepared");
        }

        public async UniTask HideLoadingAsync(SceneLoadOption option)
        {
            await _inner.HideLoadingAsync(option);
            Record("hide");
        }

        public async UniTask RevealAsync(SceneLoadOption option)
        {
            await _inner.RevealAsync(option);
            Record("reveal");
        }
    }

    /// <summary>A scene that always exists and whose load fails or waits, so the UI's recovery paths can run.</summary>
    internal sealed class StallingSceneSource : ISceneSource
    {
        public const string Key = "JJEvolSceneUIStalling";

        public string Id => "stalling";
        public Exception Failure { get; set; }
        public bool Started { get; private set; }

        public UniTask<bool> ContainsAsync(string key, CancellationToken cancellationToken) => UniTask.FromResult(key == Key);

        public ISceneLoadOperation BeginLoad(string key, LoadSceneMode mode)
        {
            Started = true;
            return new Operation(this);
        }

        sealed class Operation : ISceneLoadOperation
        {
            readonly StallingSceneSource _source;

            public Operation(StallingSceneSource source) => _source = source;

            public bool CanAbandon => true;

            public async UniTask WaitUntilReadyAsync(IProgress<float> progress, CancellationToken cancellationToken)
            {
                await UniTask.Yield();
                if (_source.Failure != null) throw _source.Failure;
                await UniTask.WaitUntilCanceled(cancellationToken);
                cancellationToken.ThrowIfCancellationRequested();
            }

            public UniTask<Scene> ActivateAsync() => throw new InvalidOperationException("This scene never finishes loading.");

            public UniTask AbandonAsync() => UniTask.CompletedTask;

            public UniTask UnloadAsync() => UniTask.CompletedTask;
        }
    }
}
