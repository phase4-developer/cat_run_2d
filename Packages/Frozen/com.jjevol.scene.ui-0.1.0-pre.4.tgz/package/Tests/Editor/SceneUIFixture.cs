using System.Linq;
using jjevol;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace JJEvolSceneUITests
{
    /// <summary>Creates a throwaway URP, Addressables, UIManager prefab, loading prefab and scene set for the run.</summary>
    public sealed class SceneUIFixture : IPrebuildSetup, IPostBuildCleanup
    {
        const string Root = SceneUIFixturePaths.Root;
        const string Prefix = "JJEvolSceneUI_";
        internal const string PreviousPathKey = "JJEvolTestsPreviousRuntimeDataPath";
        const string NothingSaved = "nothing-saved";
        internal const string PreviousDefaultKey = "JJEvolTestsPreviousDefaultSettings";

        public void Setup()
        {
            if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", "JJEvolSceneUITests");

            // Unity refuses to add a scene next to an untitled one.
            var prior = SceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(prior.path)) EditorSceneManager.SaveScene(prior, Root + "/Anchor.unity");

            BuildPipeline();

            var settings = AddressableAssetSettings.Create(Root, "Settings", true, true);
            for (int i = 0; i < settings.DataBuilders.Count; i++)
                if (settings.DataBuilders[i] is BuildScriptFastMode)
                    settings.ActivePlayModeDataBuilderIndex = i;

            Register(settings, BuildManagerPrefab(), "UIManager");
            Register(settings, BuildLoadingPrefab(), UISceneTransitionPresenter.DefaultLoadingScreen);

            var scenes = new[]
            {
                BuildScene("Plain"),
                BuildScene("Holding")
            };
            if (prior.IsValid()) SceneManager.SetActiveScene(prior);
            EditorBuildSettings.scenes = EditorBuildSettings.scenes.Concat(scenes.Select(path => new EditorBuildSettingsScene(path, true))).ToArray();

            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets();

            SavePreviousPath();
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:" + AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));

            // Entering PlayMode rebuilds the default Settings and overwrites the runtime path, so a Host that has
            // default Settings must use this fixture's Settings for the run. A Host without them is left unchanged.
            if (AddressableAssetSettingsDefaultObject.SettingsExists)
            {
                SavePreviousDefault();
                AddressableAssetSettingsDefaultObject.Settings = settings;
            }
        }

        public void Cleanup()
        {
            EditorBuildSettings.scenes = EditorBuildSettings.scenes.Where(scene => !scene.path.StartsWith(Root)).ToArray();

            RestorePreviousPath();
            RestorePreviousDefault();

            GraphicsSettings.defaultRenderPipeline = null;
            QualitySettings.renderPipeline = null;
            AssetDatabase.DeleteAsset(Root);
        }

        // Every fixture uses this key, so in a chained run the first one's save, the Host's own Settings, is the one kept.
        internal static void SavePreviousDefault()
        {
            if (SessionState.GetString(PreviousDefaultKey, "") != "") return;
            SessionState.SetString(PreviousDefaultKey, AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(AddressableAssetSettingsDefaultObject.Settings)));
        }

        // Setting a deleted asset would clear the Host's default Settings GUID.
        internal static void RestorePreviousDefault()
        {
            string previous = SessionState.GetString(PreviousDefaultKey, "");
            SessionState.EraseString(PreviousDefaultKey);
            if (previous == "") return;
            var settings = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(AssetDatabase.GUIDToAssetPath(previous));
            if (settings != null) AddressableAssetSettingsDefaultObject.Settings = settings;
        }

        // An empty path is a real previous value, so "nothing saved" needs its own marker. The first fixture's save is
        // kept, and the later Cleanup in a chain finds nothing to restore instead of erasing what the first one put back.
        internal static void SavePreviousPath()
        {
            if (SessionState.GetString(PreviousPathKey, NothingSaved) != NothingSaved) return;
            SessionState.SetString(PreviousPathKey, SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, ""));
        }

        internal static void RestorePreviousPath()
        {
            string previous = SessionState.GetString(PreviousPathKey, NothingSaved);
            if (previous == NothingSaved) return;
            SessionState.EraseString(PreviousPathKey);
            bool deleted = previous.StartsWith("GUID:") && AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(AssetDatabase.GUIDToAssetPath(previous.Substring(5))) == null;
            if (previous == "" || deleted) SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            else SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, previous);
        }

        static void Register(AddressableAssetSettings settings, string path, string address)
            => settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), settings.DefaultGroup).address = address;

        static void BuildPipeline()
        {
            var renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
            AssetDatabase.CreateAsset(renderer, Root + "/Renderer.asset");

            var pipeline = UniversalRenderPipelineAsset.Create(renderer);
            AssetDatabase.CreateAsset(pipeline, SceneUIFixturePaths.Pipeline);

            GraphicsSettings.defaultRenderPipeline = pipeline;
            QualitySettings.renderPipeline = pipeline;
        }

        static GameObject Stretch(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = 5;
            go.transform.SetParent(parent, false);
            var rect = (RectTransform)go.transform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            return go;
        }

        static string BuildManagerPrefab()
        {
            var root = new GameObject("UIManager");
            root.SetActive(false);
            var manager = root.AddComponent<UIManager>();

            var cameraObject = new GameObject("UI Camera", typeof(Camera), typeof(UniversalAdditionalCameraData));
            cameraObject.transform.SetParent(root.transform, false);
            var camera = cameraObject.GetComponent<Camera>();
            camera.orthographic = true;
            camera.cullingMask = 1 << 5;

            var canvas = Stretch("UI Canvas", root.transform).AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceCamera;
            canvas.worldCamera = camera;

            var screens = Stretch("screens", canvas.transform);
            var popups = Stretch("popups", canvas.transform);
            Stretch("Backboard", popups.transform).AddComponent<Image>();
            var huds = Stretch("HUDs", canvas.transform);
            huds.AddComponent<Canvas>();
            var effects = Stretch("effects", canvas.transform);
            var loading = Stretch("loading", canvas.transform);

            var fadeObject = Stretch("fader", canvas.transform);
            var fadeCanvas = fadeObject.AddComponent<Canvas>();
            var fadeImage = fadeObject.AddComponent<Image>();
            fadeImage.color = new Color(0f, 0f, 0f, 0f);
            var fader = fadeObject.AddComponent<UIFader>();
            var faderFields = new SerializedObject(fader);
            faderFields.FindProperty("fadeCanvas").objectReferenceValue = fadeCanvas;
            faderFields.FindProperty("fadeImage").objectReferenceValue = fadeImage;
            faderFields.ApplyModifiedPropertiesWithoutUndo();

            var fields = new SerializedObject(manager);
            fields.FindProperty("uiCamera").objectReferenceValue = camera;
            fields.FindProperty("screenRoot").objectReferenceValue = screens.transform;
            fields.FindProperty("popupRoot").objectReferenceValue = popups.transform;
            fields.FindProperty("hudRoot").objectReferenceValue = huds.transform;
            fields.FindProperty("effectRoot").objectReferenceValue = effects.transform;
            fields.FindProperty("loadingRoot").objectReferenceValue = loading.transform;
            fields.FindProperty("uiFader").objectReferenceValue = fader;
            fields.ApplyModifiedPropertiesWithoutUndo();

            root.SetActive(true);
            string path = Root + "/UIManager.prefab";
            PrefabUtility.SaveAsPrefabAsset(root, path);
            Object.DestroyImmediate(root);
            return path;
        }

        static string BuildLoadingPrefab()
        {
            var root = new GameObject("loading view", typeof(RectTransform), typeof(FixtureLoadingView));
            string path = Root + "/Loading.prefab";
            PrefabUtility.SaveAsPrefabAsset(root, path);
            Object.DestroyImmediate(root);
            return path;
        }

        static string BuildScene(string name)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);

            var cameraObject = new GameObject("main camera", typeof(Camera), typeof(UniversalAdditionalCameraData));
            cameraObject.tag = "MainCamera";
            SceneManager.MoveGameObjectToScene(cameraObject, scene);

            string path = Root + "/" + Prefix + name + ".unity";
            EditorSceneManager.SaveScene(scene, path);
            EditorSceneManager.CloseScene(scene, true);
            return path;
        }
    }
}
