using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEngine.AddressableAssets;

namespace JJEvolSceneUITests
{
    public sealed class SceneUIFixtureDefaultSettingsTests
    {
        const string Deleted = "0123456789abcdef0123456789abcdef";
        const string Unset = "unset";
        string _saved, _savedPathKey, _savedPath;

        static string RuntimePath => SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, Unset);
        static string SavedPath => SessionState.GetString(SceneUIFixture.PreviousPathKey, Unset);
        static void Put(string key, string value) { if (value == Unset) SessionState.EraseString(key); else SessionState.SetString(key, value); }

        [SetUp] public void SetUp()
        {
            _saved = SessionState.GetString(SceneUIFixture.PreviousDefaultKey, ""); SessionState.EraseString(SceneUIFixture.PreviousDefaultKey);
            _savedPathKey = SavedPath; _savedPath = RuntimePath; SessionState.EraseString(SceneUIFixture.PreviousPathKey);
        }
        [TearDown] public void TearDown()
        {
            if (_saved == "") SessionState.EraseString(SceneUIFixture.PreviousDefaultKey);
            else SessionState.SetString(SceneUIFixture.PreviousDefaultKey, _saved);
            Put(SceneUIFixture.PreviousPathKey, _savedPathKey); Put(Addressables.kAddressablesRuntimeDataPath, _savedPath);
        }

        [Test] public void ASavedPreviousValueSurvivesAChainedFixture()
        {
            SessionState.SetString(SceneUIFixture.PreviousDefaultKey, "first-fixture-saved-this");
            SceneUIFixture.SavePreviousDefault();
            Assert.That(SessionState.GetString(SceneUIFixture.PreviousDefaultKey, ""), Is.EqualTo("first-fixture-saved-this"));
        }
        [Test] public void TheFirstFixtureSavesTheDefaultSettings()
        {
            Assume.That(AddressableAssetSettingsDefaultObject.SettingsExists, "Needs a Host with default Settings.");
            SceneUIFixture.SavePreviousDefault();
            Assert.That(SessionState.GetString(SceneUIFixture.PreviousDefaultKey, ""), Is.EqualTo(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(AddressableAssetSettingsDefaultObject.Settings))));
        }
        [Test] public void ADeletedPreviousAssetIsNeverRestored()
        {
            var current = AddressableAssetSettingsDefaultObject.GetSettings(false);
            SessionState.SetString(SceneUIFixture.PreviousDefaultKey, Deleted);
            SceneUIFixture.RestorePreviousDefault();
            Assert.That(AddressableAssetSettingsDefaultObject.GetSettings(false), Is.SameAs(current));
            Assert.That(SessionState.GetString(SceneUIFixture.PreviousDefaultKey, ""), Is.Empty);
        }
        [Test] public void AnEmptySavedPathSurvivesAChainedFixture()
        {
            SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            SceneUIFixture.SavePreviousPath();
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:" + Deleted);
            SceneUIFixture.SavePreviousPath();
            Assert.That(SavedPath, Is.Empty);
            SceneUIFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo(Unset));
        }
        [Test] public void ADeletedPreviousPathIsNeverRestored()
        {
            SessionState.SetString(SceneUIFixture.PreviousPathKey, "GUID:" + Deleted);
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:fixture-being-removed");
            SceneUIFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo(Unset));
            Assert.That(SavedPath, Is.EqualTo(Unset));
        }
        [Test] public void TheLaterCleanupInAChainLeavesTheRestoredPathAlone()
        {
            SessionState.SetString(SceneUIFixture.PreviousPathKey, "Host/Path");
            SceneUIFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo("Host/Path"));
            SceneUIFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo("Host/Path"));
        }
    }
}
