using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>
    /// Runs transitions through UIManager's fader and loading view. Installing this package selects it unless the game
    /// already set <see cref="CustomSceneManager.Presenter"/>.
    /// </summary>
    public sealed class UISceneTransitionPresenter : SceneTransitionPresenter
    {
        public const string DefaultLoadingScreen = "LoadingSceneScreen";

        UILoadingSession _session;
        string _loadingKey;
        Color _fadeColor;
        bool _covering;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void SelectOnStartup()
        {
            if (CustomSceneManager.Presenter == null) CustomSceneManager.Presenter = new UISceneTransitionPresenter();
        }

        static UIManager CurrentUI => UIManager.HasInstance ? UIManager.Instance : null;

        static UIFader CurrentFader
        {
            get
            {
                var ui = CurrentUI;
                return ui != null ? ui.Fader : null;
            }
        }

        public override async UniTask CoverAsync(SceneLoadOption option, CancellationToken cancellationToken)
        {
            ReleaseSession();
            _loadingKey = LoadingKeyOf(option);
            _fadeColor = option.fadeColor;
            _covering = option.loadType != SceneLoadType.None;

            if (!_covering) return;

            await FadeInAsync(option.fadeInDuration, cancellationToken);
            await AcquireLoadingAsync(cancellationToken);
        }

        public override async UniTask ShowLoadingAsync(SceneLoadOption option, CancellationToken cancellationToken)
        {
            if (IsLoadingShown) await FadeOutAsync(option.fadeOutDuration, cancellationToken);
        }

        public override void SetProgress(float progress) => _session?.Report(progress);

        public override async UniTask PrepareSceneAsync(Scene scene, CancellationToken cancellationToken)
        {
            // A creator the game has not started yet stays untouched, so the UI never opens before the game is ready.
            if (UIManagerCreater.HasInstance && UIManagerCreater.Instance.IsStarted && UIManagerCreater.Instance.isActiveAndEnabled)
                await UIManagerCreater.Instance.StartInitAsync(cancellationToken);

            if (_covering) await RestoreCoverAsync(cancellationToken);
        }

        // The session closes with the UI that owned it. Its fader went too, so the new UI has to take over the cover.
        // Losing the cover is a visual problem only, so it must not fail the scene that has already loaded.
        async UniTask RestoreCoverAsync(CancellationToken cancellationToken)
        {
            try
            {
                if (_loadingKey != null && !IsLoadingShown) await AcquireLoadingAsync(cancellationToken);
            }
            catch (Exception exception) when (!(exception is OperationCanceledException))
            {
                Debug.LogWarning($"[UISceneTransitionPresenter] Loading view '{_loadingKey}' could not be restored: {exception.Message}");
                _loadingKey = null;
            }

            var fader = CurrentFader;
            if (!IsLoadingShown && fader != null && !fader.IsVisible) fader.ShowImmediate(_fadeColor);
        }

        public override async UniTask HideLoadingAsync(SceneLoadOption option)
        {
            try
            {
                if (IsLoadingShown) await FadeInAsync(option.fadeInDuration, CancellationToken.None);
            }
            finally
            {
                ReleaseSession();
            }
        }

        public override async UniTask RevealAsync(SceneLoadOption option)
        {
            bool covered = _covering;
            _covering = false;
            if (covered) await FadeOutAsync(option.fadeOutDuration, CancellationToken.None);
        }

        bool IsLoadingShown => _session != null && _session.IsActive;

        void ReleaseSession()
        {
            _session?.Dispose();
            _session = null;
        }

        async UniTask AcquireLoadingAsync(CancellationToken cancellationToken)
        {
            var ui = CurrentUI;
            if (_loadingKey == null || ui == null) return;

            _session = await ui.AcquireLoadingAsync(_loadingKey, cancellationToken);
        }

        async UniTask FadeInAsync(float duration, CancellationToken cancellationToken)
        {
            var fader = CurrentFader;
            if (fader == null) return;

            if (duration <= 0f)
            {
                fader.ShowImmediate(_fadeColor);
                return;
            }

            await fader.FadeIn(duration, _fadeColor).AttachExternalCancellation(cancellationToken);
        }

        static async UniTask FadeOutAsync(float duration, CancellationToken cancellationToken)
        {
            var fader = CurrentFader;
            if (fader != null && fader.IsVisible) await fader.FadeOut(duration).AttachExternalCancellation(cancellationToken);
        }

        static string LoadingKeyOf(SceneLoadOption option)
        {
            if (option.loadType != SceneLoadType.LoadingScene || option.loadingScreen == string.Empty) return null;
            return option.loadingScreen ?? DefaultLoadingScreen;
        }
    }
}
