# JJEvol Scene UI — local candidate

Unity 6000.3.9f1. 로컬 소스 후보이며 공식 릴리스나 고정 tarball이 아니다.

`com.jjevol.scene`의 전환에 페이드, 로딩 화면, UI 초기화를 연결한다. 설치하면 시작할 때 자동으로 선택되고, 게임이 `CustomSceneManager.Presenter`를 먼저 지정했다면 그대로 둔다. `UIManager`나 `UIManagerCreater`가 없는 씬에서는 해당 단계를 건너뛴다.

## 로딩 화면

기본 프리팹 주소는 `LoadingSceneScreen`이다. 다른 주소는 `SceneLoadOption.Loading("MyLoading")`으로 지정한다. 프리팹이 없으면 경고를 남기고 페이드만으로 전환한다.

프리팹에 `IUILoadingProgressView`를 구현한 컴포넌트를 두면 진행률을 받는다. 정적 이벤트를 구독할 필요가 없다. 기존 `CustomSceneManager.OnProgressChanged` 구독도 계속 동작한다.

전체 화면 로딩은 다른 호출자와 공유된다. 이 패키지는 `HideLoadingUI`를 쓰지 않고 자기 `UILoadingSession`만 닫는다.

## UIManagerCreater 배치

첫 씬에 하나 두고 게임이 `DontDestroyOnLoad`로 유지한다. 페이드와 로딩 화면이 전환 내내 끊기지 않는다. 게임이 `StartInitAsync`로 시작한 creator만 전환 때 다시 초기화한다. 시작하지 않은 creator는 건드리지 않는다.

씬마다 하나씩 두는 구성은 지원하지 않는다.

대상 씬의 Base Camera는 `UIManagerCreater`의 `mainCamera` 규칙을 따른다. 중간 씬에도 같은 카메라가 필요하다.

## 시험

`Tests/Runtime`은 임시 URP 설정, Addressables, `UIManager`·로딩 프리팹, 씬을 만들어 실제 페이드와 로딩 화면 순서를 단계별로 확인하는 PlayMode 시험이다. `UIManagerCreater`를 유지하는 구성, 시작하지 않은 creator, 중간 씬을 쓰는 구성, 실패, 취소, 로딩 프리팹 누락, 다른 호출자와의 공유를 다룬다.

시험 프리팹은 `UIFader` 오브젝트를 활성 상태로 둔다. 프리팹에서 비활성으로 두면 첫 페이드에서 예외가 난다.
