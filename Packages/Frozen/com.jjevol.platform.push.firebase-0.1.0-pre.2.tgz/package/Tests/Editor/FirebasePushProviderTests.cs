using System;
using System.Collections.Generic;
using System.Threading;
using NUnit.Framework;

namespace PlatformLibrary.Push.Firebase.Tests
{
    public sealed class FirebasePushProviderTests
    {
        private FakeFirebaseMessagingClient _client;
        private FirebasePushProvider _provider;

        [SetUp]
        public void SetUp()
        {
            _client = new FakeFirebaseMessagingClient();
            _provider = new FirebasePushProvider(_client);
        }

        [Test]
        public void InitializeStartsTheSdkAndForwardsItsEvents()
        {
            string token = null;
            PushMessage message = null;
            _provider.TokenReceived += value => token = value;
            _provider.MessageReceived += value => message = value;

            PushResult result = Answer(_provider.Initialize);
            _client.TokenListener("t1");
            _client.MessageListener(new PushMessage("m1", null, null, null, false));

            Assert.IsTrue(result.Success);
            Assert.AreEqual("t1", token);
            Assert.AreEqual("m1", message.MessageId);
        }

        [Test]
        public void FailedStartIsReported()
        {
            _client.ThrowOnStart = new InvalidOperationException("Firebase not ready");

            Assert.AreEqual(PushFailure.ProviderError, Answer(_provider.Initialize).Failure);
        }

        [Test]
        public void InvalidTopicIsRejectedWithoutCallingTheSdk()
        {
            PushResult result = Answer(done => _provider.Subscribe("bad topic", done));

            Assert.AreEqual(PushFailure.InvalidTopic, result.Failure);
            Assert.AreEqual(FirebasePushFailureMap.InvalidTopicName, result.ProviderCode);
            CollectionAssert.IsEmpty(_client.Calls);
        }

        [Test]
        public void ValidTopicReachesTheSdk()
        {
            Assert.IsTrue(Answer(done => _provider.Subscribe("user-ko", done)).Success);
            Assert.IsTrue(Answer(done => _provider.Unsubscribe("user-ko", done)).Success);

            CollectionAssert.AreEqual(new[] { "Subscribe:user-ko", "Unsubscribe:user-ko" }, _client.Calls);
        }

        [Test]
        public void TopicNameRulesFollowFirebase()
        {
            Assert.IsTrue(FirebasePushProvider.IsValidTopic("a-b_c.d~e%f"));
            Assert.IsFalse(FirebasePushProvider.IsValidTopic(""));
            Assert.IsFalse(FirebasePushProvider.IsValidTopic(null));
            Assert.IsFalse(FirebasePushProvider.IsValidTopic("한글"));
            Assert.IsFalse(FirebasePushProvider.IsValidTopic(new string('a', 901)));
        }

        [Test]
        public void TokenComesBackWithTheResult()
        {
            string token = null;
            PushResult result = AnswerToken(out token);

            Assert.IsTrue(result.Success);
            Assert.AreEqual("sdk-token", token);
        }

        [Test]
        public void FaultedTaskKeepsTheSdkCode()
        {
            _client.Fault = new Exception("Invalid topic");
            _client.SdkCode = FirebasePushFailureMap.InvalidTopicName;

            PushResult result = AnswerToken(out string token);

            Assert.AreEqual(PushFailure.InvalidTopic, result.Failure);
            Assert.AreEqual(2, result.ProviderCode);
            Assert.IsNull(token);
        }

        [Test]
        public void CanceledTaskIsAProviderError()
        {
            _client.Cancel = true;

            Assert.AreEqual(PushFailure.ProviderError, Answer(_provider.DeleteToken).Failure);
        }

        [Test]
        public void ThrowingSdkCallIsAnswered()
        {
            _client.ThrowOnCall = new TimeoutException("slow");

            Assert.AreEqual(PushFailure.Timeout, Answer(_provider.RequestPermission).Failure);
            Assert.AreEqual(PushFailure.Timeout, AnswerToken(out _).Failure);
        }

        [Test]
        public void AutoRegistrationReachesTheSdk()
        {
            _provider.SetAutoRegistration(false);

            Assert.AreEqual(false, _client.AutoRegistrationValue);
        }

        [Test]
        public void ScopeIdIsTheAppId()
        {
            Assert.AreEqual("app-id", _provider.ScopeId);
        }

        [Test]
        public void MessageConversionKeepsDataAndOpened()
        {
            PushMessage message = FirebasePushProvider.ToMessage("id", null, "body", new Dictionary<string, string> { ["k"] = "v" }, true);

            Assert.AreEqual("id", message.MessageId);
            Assert.AreEqual(string.Empty, message.Title);
            Assert.AreEqual("body", message.Body);
            Assert.AreEqual("v", message.Data["k"]);
            Assert.IsTrue(message.Opened);
        }

        private static PushResult Answer(Action<Action<PushResult>> call)
        {
            PushResult? result = null;
            using (var done = new ManualResetEventSlim())
            {
                call(value =>
                {
                    result = value;
                    done.Set();
                });
                Assert.IsTrue(done.Wait(TimeSpan.FromSeconds(5)), "No answer.");
            }
            return result.Value;
        }

        private PushResult AnswerToken(out string token)
        {
            PushResult? result = null;
            string received = null;
            using (var done = new ManualResetEventSlim())
            {
                _provider.GetToken((value, sdkToken) =>
                {
                    result = value;
                    received = sdkToken;
                    done.Set();
                });
                Assert.IsTrue(done.Wait(TimeSpan.FromSeconds(5)), "No answer.");
            }
            token = received;
            return result.Value;
        }
    }
}
