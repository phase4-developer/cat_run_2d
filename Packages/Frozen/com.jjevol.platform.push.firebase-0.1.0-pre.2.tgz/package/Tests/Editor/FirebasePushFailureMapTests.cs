using System;
using System.IO;
using NUnit.Framework;

namespace PlatformLibrary.Push.Firebase.Tests
{
    public sealed class FirebasePushFailureMapTests
    {
        [Test]
        public void InvalidTopicNameMapsToInvalidTopic()
        {
            Assert.AreEqual(PushFailure.InvalidTopic, FirebasePushFailureMap.Map(new Exception("x"), 2).Failure);
        }

        [Test]
        public void NoRegistrationTokenMapsToTokenUnavailable()
        {
            Assert.AreEqual(PushFailure.TokenUnavailable, FirebasePushFailureMap.Map(new Exception("x"), 3).Failure);
        }

        [Test]
        public void ConnectionErrorsMapToNoConnection()
        {
            Assert.AreEqual(PushFailure.NoConnection, FirebasePushFailureMap.Map(new Exception("SERVICE_NOT_AVAILABLE"), null).Failure);
            Assert.AreEqual(PushFailure.NoConnection, FirebasePushFailureMap.Map(new IOException("reset"), null).Failure);
        }

        [Test]
        public void TimeoutsMapToTimeout()
        {
            Assert.AreEqual(PushFailure.Timeout, FirebasePushFailureMap.Map(new TimeoutException(), null).Failure);
            Assert.AreEqual(PushFailure.Timeout, FirebasePushFailureMap.Map(new Exception("TIMEOUT"), null).Failure);
        }

        [Test]
        public void NotSupportedMapsToUnsupported()
        {
            Assert.AreEqual(PushFailure.Unsupported, FirebasePushFailureMap.Map(new NotSupportedException(), null).Failure);
        }

        [Test]
        public void OtherErrorKeepsTheSdkCodeAndDetail()
        {
            PushResult result = FirebasePushFailureMap.Map(new InvalidOperationException("boom"), 4);

            Assert.AreEqual(PushFailure.ProviderError, result.Failure);
            Assert.AreEqual(4, result.ProviderCode);
            StringAssert.Contains("boom", result.Detail);
        }

        [Test]
        public void MissingExceptionIsAProviderError()
        {
            Assert.AreEqual(PushFailure.ProviderError, FirebasePushFailureMap.Map(null, null).Failure);
        }
    }
}
