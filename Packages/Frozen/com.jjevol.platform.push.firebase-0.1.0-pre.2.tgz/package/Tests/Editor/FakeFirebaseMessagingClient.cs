using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlatformLibrary.Push.Firebase.Tests
{
    internal sealed class FakeFirebaseMessagingClient : IFirebaseMessagingClient
    {
        public readonly List<string> Calls = new List<string>();
        public Action<string> TokenListener;
        public Action<PushMessage> MessageListener;
        public Exception ThrowOnStart;
        public Exception Fault;
        public Exception ThrowOnCall;
        public bool Cancel;
        public string Token = "sdk-token";
        public string AppIdValue = "app-id";
        public int? SdkCode;

        public bool? AutoRegistrationValue { get; private set; }

        public string AppId => AppIdValue ?? throw new InvalidOperationException("no app");

        public bool AutoRegistration
        {
            set => AutoRegistrationValue = value;
        }

        public void Start(Action<string> tokenReceived, Action<PushMessage> messageReceived)
        {
            Calls.Add("Start");
            if (ThrowOnStart != null) throw ThrowOnStart;
            TokenListener = tokenReceived;
            MessageListener = messageReceived;
        }

        public Task RequestPermissionAsync() => Finish("RequestPermission");

        public Task<string> GetTokenAsync()
        {
            Calls.Add("GetToken");
            if (ThrowOnCall != null) throw ThrowOnCall;
            if (Fault != null) return Task.FromException<string>(Fault);
            if (Cancel) return Task.FromCanceled<string>(new System.Threading.CancellationToken(true));
            return Task.FromResult(Token);
        }

        public Task DeleteTokenAsync() => Finish("DeleteToken");

        public Task SubscribeAsync(string topic) => Finish("Subscribe:" + topic);

        public Task UnsubscribeAsync(string topic) => Finish("Unsubscribe:" + topic);

        public int? ErrorCodeOf(Exception exception) => SdkCode;

        private Task Finish(string call)
        {
            Calls.Add(call);
            if (ThrowOnCall != null) throw ThrowOnCall;
            if (Fault != null) return Task.FromException(Fault);
            if (Cancel) return Task.FromCanceled(new System.Threading.CancellationToken(true));
            return Task.CompletedTask;
        }
    }
}
