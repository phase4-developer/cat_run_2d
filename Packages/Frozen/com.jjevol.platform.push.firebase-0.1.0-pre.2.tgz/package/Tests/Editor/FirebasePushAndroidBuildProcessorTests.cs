using System.IO;
using System.Xml;
using NUnit.Framework;
using PlatformLibrary.Push.Firebase.Editor;

namespace PlatformLibrary.Push.Firebase.Tests
{
    public sealed class FirebasePushAndroidBuildProcessorTests
    {
        private const string AndroidNamespace = "http://schemas.android.com/apk/res/android";
        private string _manifestPath;

        [SetUp]
        public void SetUp()
        {
            _manifestPath = Path.Combine(Path.GetTempPath(), "FirebasePushManifest-" + System.Guid.NewGuid().ToString("N") + ".xml");
        }

        [TearDown]
        public void TearDown()
        {
            if (File.Exists(_manifestPath)) File.Delete(_manifestPath);
        }

        [Test]
        public void AddsTheIconMetaData()
        {
            File.WriteAllText(_manifestPath,
                "<manifest xmlns:android=\"" + AndroidNamespace + "\"><application android:label=\"x\"></application></manifest>");

            FirebasePushAndroidBuildProcessor.ApplyDefaultNotificationIcon(_manifestPath, "ic_stat_push");

            Assert.AreEqual("@drawable/ic_stat_push", ReadIcon(out int count));
            Assert.AreEqual(1, count);
        }

        [Test]
        public void ReplacesAnExistingIconMetaData()
        {
            File.WriteAllText(_manifestPath,
                "<manifest xmlns:android=\"" + AndroidNamespace + "\"><application>" +
                "<meta-data android:name=\"" + FirebasePushAndroidBuildProcessor.DefaultNotificationIconMetaName + "\" android:resource=\"@drawable/old\" />" +
                "</application></manifest>");

            FirebasePushAndroidBuildProcessor.ApplyDefaultNotificationIcon(_manifestPath, "ic_new");

            Assert.AreEqual("@drawable/ic_new", ReadIcon(out int count));
            Assert.AreEqual(1, count);
        }

        [Test]
        public void ManifestWithoutApplicationFailsTheBuild()
        {
            File.WriteAllText(_manifestPath, "<manifest xmlns:android=\"" + AndroidNamespace + "\"></manifest>");

            Assert.Throws<UnityEditor.Build.BuildFailedException>(() =>
                FirebasePushAndroidBuildProcessor.ApplyDefaultNotificationIcon(_manifestPath, "ic_new"));
        }

        [Test]
        public void ResourceNameRulesFollowAndroid()
        {
            Assert.IsTrue(FirebasePushAndroidBuildProcessor.IsValidResourceName("ic_stat_notification"));
            Assert.IsFalse(FirebasePushAndroidBuildProcessor.IsValidResourceName("Ic_stat"));
            Assert.IsFalse(FirebasePushAndroidBuildProcessor.IsValidResourceName("1icon"));
            Assert.IsFalse(FirebasePushAndroidBuildProcessor.IsValidResourceName("ic-stat"));
            Assert.IsFalse(FirebasePushAndroidBuildProcessor.IsValidResourceName(""));
        }

        private string ReadIcon(out int count)
        {
            var document = new XmlDocument();
            document.Load(_manifestPath);
            string resource = null;
            count = 0;
            foreach (XmlElement element in document.GetElementsByTagName("meta-data"))
            {
                if (element.GetAttribute("name", AndroidNamespace) != FirebasePushAndroidBuildProcessor.DefaultNotificationIconMetaName) continue;
                count++;
                resource = element.GetAttribute("resource", AndroidNamespace);
            }
            return resource;
        }
    }
}
