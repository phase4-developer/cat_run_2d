using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Push.Firebase.Tests.Editor")]
