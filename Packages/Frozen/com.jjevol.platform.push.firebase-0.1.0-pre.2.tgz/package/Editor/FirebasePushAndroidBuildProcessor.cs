using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;
#if UNITY_ANDROID
using UnityEditor.Android;
#endif

namespace PlatformLibrary.Push.Firebase.Editor
{
    /// <summary>
    /// Copies the project's notification icon into the generated Android project and points Firebase's default
    /// notification icon at it. Does nothing without a <see cref="FirebasePushBuildSettings"/> asset.
    /// </summary>
    public sealed class FirebasePushAndroidBuildProcessor
#if UNITY_ANDROID
        : IPostGenerateGradleAndroidProject
#endif
    {
        internal const string DefaultNotificationIconMetaName = "com.google.firebase.messaging.default_notification_icon";
        private const string AndroidNamespace = "http://schemas.android.com/apk/res/android";
        private const string LogPrefix = "[FirebasePushBuild] ";
        private static readonly Regex AndroidResourceName = new Regex("^[a-z][a-z0-9_]*$", RegexOptions.Compiled);

        public int callbackOrder => 10000;

        public void OnPostGenerateGradleAndroidProject(string path)
        {
            Process(path, LoadSettings());
        }

        internal static bool IsValidResourceName(string name) => !string.IsNullOrWhiteSpace(name) && AndroidResourceName.IsMatch(name);

        /// <summary>Adds or replaces Firebase's default notification icon meta-data in a generated manifest.</summary>
        internal static void ApplyDefaultNotificationIcon(string manifestPath, string resourceName)
        {
            var document = new XmlDocument { PreserveWhitespace = true };
            document.Load(manifestPath);

            XmlElement manifest = document.DocumentElement;
            if (manifest == null || manifest.LocalName != "manifest")
                throw new BuildFailedException(LogPrefix + "Invalid generated AndroidManifest.xml.");

            XmlNodeList applications = manifest.GetElementsByTagName("application");
            XmlElement application = applications.Count > 0 ? applications[0] as XmlElement : null;
            if (application == null)
                throw new BuildFailedException(LogPrefix + "<application> not found in generated AndroidManifest.xml.");

            XmlElement metaData = FindMetaData(application, DefaultNotificationIconMetaName);
            if (metaData == null)
            {
                metaData = document.CreateElement("meta-data");
                application.AppendChild(metaData);
            }

            SetAndroidAttribute(document, metaData, "name", DefaultNotificationIconMetaName);
            SetAndroidAttribute(document, metaData, "resource", "@drawable/" + resourceName);
            document.Save(manifestPath);
        }

        private static void Process(string path, FirebasePushBuildSettings settings)
        {
            if (settings == null || !settings.AndroidEnabled) return;

            if (!TryValidate(settings, out string error))
            {
                HandleInvalid(settings, error);
                return;
            }

            string sourceIconPath = GetPhysicalAssetPath(AssetDatabase.GetAssetPath(settings.AndroidSmallIcon));
            string manifestPath = Path.Combine(path, "src", "main", "AndroidManifest.xml");
            string drawableDirectory = Path.Combine(path, "src", "main", "res", "drawable");
            string targetIconPath = Path.Combine(drawableDirectory, settings.AndroidResourceName + ".png");

            if (!File.Exists(manifestPath))
            {
                HandleInvalid(settings, "Generated AndroidManifest.xml not found: " + manifestPath);
                return;
            }

            Directory.CreateDirectory(drawableDirectory);
            File.Copy(sourceIconPath, targetIconPath, true);
            ApplyDefaultNotificationIcon(manifestPath, settings.AndroidResourceName);

            Debug.Log(LogPrefix + "Android notification icon applied: @drawable/" + settings.AndroidResourceName);
        }

        private static FirebasePushBuildSettings LoadSettings()
        {
            string[] guids = AssetDatabase.FindAssets("t:" + nameof(FirebasePushBuildSettings));
            if (guids.Length == 0)
            {
                Debug.LogWarning(LogPrefix + nameof(FirebasePushBuildSettings) + " not found. Skipping the Android notification icon.");
                return null;
            }

            FirebasePushBuildSettings fallback = null;
            FirebasePushBuildSettings configured = null;
            int configuredCount = 0;
            int settingsCount = 0;
            foreach (string guid in guids)
            {
                var settings = AssetDatabase.LoadAssetAtPath<FirebasePushBuildSettings>(AssetDatabase.GUIDToAssetPath(guid));
                if (settings == null) continue;
                settingsCount++;
                fallback = settings;
                if (!settings.AndroidEnabled || settings.AndroidSmallIcon == null) continue;
                configured = settings;
                configuredCount++;
            }

            if (configuredCount == 1) return configured;
            if (configuredCount > 1 || settingsCount > 1)
                throw new BuildFailedException(LogPrefix + "Several settings assets are ambiguous. Keep one in the project.");
            return fallback;
        }

        private static bool TryValidate(FirebasePushBuildSettings settings, out string error)
        {
            if (settings.AndroidSmallIcon == null)
            {
                error = "Android Small Icon is not assigned.";
                return false;
            }

            if (!IsValidResourceName(settings.AndroidResourceName))
            {
                error = $"Android Resource Name is invalid: '{settings.AndroidResourceName}'. Use lowercase letters, numbers and underscores, starting with a letter.";
                return false;
            }

            string assetPath = AssetDatabase.GetAssetPath(settings.AndroidSmallIcon);
            if (string.IsNullOrEmpty(assetPath) || !string.Equals(Path.GetExtension(assetPath), ".png", StringComparison.OrdinalIgnoreCase))
            {
                error = "Android Small Icon must be a standalone PNG Texture2D asset.";
                return false;
            }

            if (!File.Exists(GetPhysicalAssetPath(assetPath)))
            {
                error = "Android Small Icon source file not found: " + assetPath;
                return false;
            }

            error = null;
            return true;
        }

        private static string GetPhysicalAssetPath(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return string.Empty;
            if (Path.IsPathRooted(assetPath)) return assetPath;
            string projectRoot = Path.GetDirectoryName(Application.dataPath);
            return Path.GetFullPath(Path.Combine(projectRoot ?? string.Empty, assetPath));
        }

        private static void HandleInvalid(FirebasePushBuildSettings settings, string error)
        {
            string message = LogPrefix + error;
            if (settings != null && settings.FailBuildWhenInvalid) throw new BuildFailedException(message);
            Debug.LogWarning(message + " Notification icon setup skipped.");
        }

        private static XmlElement FindMetaData(XmlElement application, string metaName)
        {
            foreach (XmlNode child in application.ChildNodes)
            {
                if (child is XmlElement element && element.LocalName == "meta-data" && element.GetAttribute("name", AndroidNamespace) == metaName)
                    return element;
            }
            return null;
        }

        private static void SetAndroidAttribute(XmlDocument document, XmlElement element, string name, string value)
        {
            XmlAttribute attribute = element.GetAttributeNode(name, AndroidNamespace);
            if (attribute == null)
            {
                attribute = document.CreateAttribute("android", name, AndroidNamespace);
                element.Attributes.Append(attribute);
            }
            attribute.Value = value;
        }
    }
}
