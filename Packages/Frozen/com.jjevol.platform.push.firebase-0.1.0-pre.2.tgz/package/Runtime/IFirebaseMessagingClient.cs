using System;
using System.Threading.Tasks;

namespace PlatformLibrary.Push.Firebase
{
    /// <summary>The calls <see cref="FirebasePushProvider"/> makes on the SDK. Tests replace it.</summary>
    internal interface IFirebaseMessagingClient
    {
        string AppId { get; }
        bool AutoRegistration { set; }

        /// <summary>Starts listening to the SDK. Events may come from any thread.</summary>
        void Start(Action<string> tokenReceived, Action<PushMessage> messageReceived);

        Task RequestPermissionAsync();
        Task<string> GetTokenAsync();
        Task DeleteTokenAsync();
        Task SubscribeAsync(string topic);
        Task UnsubscribeAsync(string topic);

        /// <summary>The SDK's own error code, or null when the exception is not an SDK error.</summary>
        int? ErrorCodeOf(Exception exception);
    }
}
