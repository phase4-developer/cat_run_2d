using System;
using System.IO;

namespace PlatformLibrary.Push.Firebase
{
    /// <summary>Turns a Firebase Messaging error into <see cref="PushFailure"/>. The SDK code stays in the result for logs.</summary>
    internal static class FirebasePushFailureMap
    {
        // Firebase.Messaging.Error values in the Firebase Unity SDK.
        internal const int InvalidTopicName = 2;
        internal const int NoRegistrationToken = 3;

        private static readonly string[] TimeoutMarks = { "TIMEOUT", "timed out" };
        private static readonly string[] ConnectionMarks = { "SERVICE_NOT_AVAILABLE", "network", "offline", "Unable to resolve host" };

        public static PushResult Map(Exception exception, int? sdkCode)
        {
            if (exception == null) return PushResult.Failed(PushFailure.ProviderError, sdkCode ?? 0, "UNKNOWN");

            int code = sdkCode ?? 0;
            string detail = exception.GetType().Name + ": " + exception.Message;

            if (sdkCode == InvalidTopicName) return PushResult.Failed(PushFailure.InvalidTopic, code, detail);
            if (sdkCode == NoRegistrationToken) return PushResult.Failed(PushFailure.TokenUnavailable, code, detail);
            if (exception is NotSupportedException || exception is PlatformNotSupportedException)
                return PushResult.Failed(PushFailure.Unsupported, code, detail);
            if (exception is TimeoutException || HasMark(exception.Message, TimeoutMarks))
                return PushResult.Failed(PushFailure.Timeout, code, detail);
            if (exception is IOException || HasMark(exception.Message, ConnectionMarks))
                return PushResult.Failed(PushFailure.NoConnection, code, detail);

            return PushResult.Failed(PushFailure.ProviderError, code, detail);
        }

        private static bool HasMark(string message, string[] marks)
        {
            if (string.IsNullOrEmpty(message)) return false;
            foreach (string mark in marks)
            {
                if (message.IndexOf(mark, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            }
            return false;
        }
    }
}
