using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PlatformLibrary.Push.Firebase
{
    /// <summary>
    /// Firebase Cloud Messaging for <see cref="PushManager"/>. Set it after the project has finished initializing
    /// Firebase. This package does not initialize Firebase.
    /// </summary>
    public sealed class FirebasePushProvider : IPushProvider
    {
        // Firebase accepts topic names of these characters only.
        private static readonly Regex TopicName = new Regex(@"^[a-zA-Z0-9\-_.~%]{1,900}$", RegexOptions.Compiled);

        private readonly IFirebaseMessagingClient _client;

        public FirebasePushProvider()
            : this(new FirebaseMessagingClient())
        {
        }

        internal FirebasePushProvider(IFirebaseMessagingClient client)
        {
            _client = client ?? throw new ArgumentNullException(nameof(client));
        }

        public event Action<string> TokenReceived;
        public event Action<PushMessage> MessageReceived;

        /// <summary>The Firebase App ID, so each Firebase project keeps its own saved topics.</summary>
        public string ScopeId => _client.AppId;

        public void Initialize(Action<PushResult> completed)
        {
            try
            {
                _client.Start(token => TokenReceived?.Invoke(token), message => MessageReceived?.Invoke(message));
            }
            catch (Exception exception)
            {
                completed(FirebasePushFailureMap.Map(exception, _client.ErrorCodeOf(exception)));
                return;
            }

            completed(PushResult.Succeeded);
        }

        public void SetAutoRegistration(bool enabled) => _client.AutoRegistration = enabled;

        public void RequestPermission(Action<PushResult> completed) => Run(_client.RequestPermissionAsync, completed);

        public void GetToken(Action<PushResult, string> completed)
        {
            Task<string> task;
            try
            {
                task = _client.GetTokenAsync();
            }
            catch (Exception exception)
            {
                completed(FirebasePushFailureMap.Map(exception, _client.ErrorCodeOf(exception)), null);
                return;
            }

            task.ContinueWith(done =>
            {
                PushResult result = ToResult(done);
                completed(result, result.Success ? done.Result : null);
            }, TaskScheduler.Default);
        }

        public void DeleteToken(Action<PushResult> completed) => Run(_client.DeleteTokenAsync, completed);

        public void Subscribe(string topic, Action<PushResult> completed)
        {
            if (!IsValidTopic(topic))
            {
                completed(PushResult.Failed(PushFailure.InvalidTopic, FirebasePushFailureMap.InvalidTopicName, "INVALID_TOPIC_NAME: " + topic));
                return;
            }

            Run(() => _client.SubscribeAsync(topic), completed);
        }

        public void Unsubscribe(string topic, Action<PushResult> completed)
        {
            if (!IsValidTopic(topic))
            {
                completed(PushResult.Failed(PushFailure.InvalidTopic, FirebasePushFailureMap.InvalidTopicName, "INVALID_TOPIC_NAME: " + topic));
                return;
            }

            Run(() => _client.UnsubscribeAsync(topic), completed);
        }

        internal static bool IsValidTopic(string topic) => topic != null && TopicName.IsMatch(topic);

        internal static PushMessage ToMessage(string messageId, string title, string body, IDictionary<string, string> data, bool opened)
        {
            return new PushMessage(messageId, title, body, data, opened);
        }

        private void Run(Func<Task> start, Action<PushResult> completed)
        {
            Task task;
            try
            {
                task = start();
            }
            catch (Exception exception)
            {
                completed(FirebasePushFailureMap.Map(exception, _client.ErrorCodeOf(exception)));
                return;
            }

            task.ContinueWith(done => completed(ToResult(done)), TaskScheduler.Default);
        }

        private PushResult ToResult(Task task)
        {
            if (task.IsCanceled) return PushResult.Failed(PushFailure.ProviderError, 0, "CANCELED");
            if (!task.IsFaulted) return PushResult.Succeeded;

            Exception exception = task.Exception?.GetBaseException();
            return FirebasePushFailureMap.Map(exception, exception == null ? null : _client.ErrorCodeOf(exception));
        }
    }
}
