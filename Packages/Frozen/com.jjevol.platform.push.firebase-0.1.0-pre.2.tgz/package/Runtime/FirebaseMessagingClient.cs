using System;
using System.Threading.Tasks;
using UnityEngine;
#if !UNITY_EDITOR
using Firebase;
using Firebase.Messaging;
using MessagingSdk = Firebase.Messaging.FirebaseMessaging;
#endif

namespace PlatformLibrary.Push.Firebase
{
    /// <summary>
    /// The only type that touches the Firebase SDK. The Editor logs instead and hands out a fixed token, so the
    /// package compiles and the game's push flow runs in the Editor without the SDK.
    /// </summary>
    internal sealed class FirebaseMessagingClient : IFirebaseMessagingClient
    {
#if UNITY_EDITOR
        internal const string EditorToken = "editor-push-token";

        public string AppId => "editor";

        public bool AutoRegistration
        {
            set => Debug.Log($"[FirebasePushProvider][Editor] auto registration {value}");
        }

        public void Start(Action<string> tokenReceived, Action<PushMessage> messageReceived)
        {
        }

        public Task RequestPermissionAsync() => Task.CompletedTask;

        public Task<string> GetTokenAsync() => Task.FromResult(EditorToken);

        public Task DeleteTokenAsync() => Task.CompletedTask;

        public Task SubscribeAsync(string topic)
        {
            Debug.Log($"[FirebasePushProvider][Editor] subscribe {topic}");
            return Task.CompletedTask;
        }

        public Task UnsubscribeAsync(string topic)
        {
            Debug.Log($"[FirebasePushProvider][Editor] unsubscribe {topic}");
            return Task.CompletedTask;
        }

        public int? ErrorCodeOf(Exception exception) => null;
#else
        private Action<string> _tokenReceived;
        private Action<PushMessage> _messageReceived;
        private bool _started;

        public string AppId => FirebaseApp.DefaultInstance.Options.AppId;

        public bool AutoRegistration
        {
            set
            {
                if (MessagingSdk.RegistrationOnInitEnabled != value) MessagingSdk.RegistrationOnInitEnabled = value;
            }
        }

        public void Start(Action<string> tokenReceived, Action<PushMessage> messageReceived)
        {
            _tokenReceived = tokenReceived;
            _messageReceived = messageReceived;
            if (_started) return;
            MessagingSdk.TokenReceived += OnTokenReceived;
            MessagingSdk.MessageReceived += OnMessageReceived;
            _started = true;
        }

        public Task RequestPermissionAsync() => MessagingSdk.RequestPermissionAsync();

        public Task<string> GetTokenAsync() => MessagingSdk.GetTokenAsync();

        public Task DeleteTokenAsync() => MessagingSdk.DeleteTokenAsync();

        public Task SubscribeAsync(string topic) => MessagingSdk.SubscribeAsync(topic);

        public Task UnsubscribeAsync(string topic) => MessagingSdk.UnsubscribeAsync(topic);

        public int? ErrorCodeOf(Exception exception) => exception is FirebaseException firebase ? firebase.ErrorCode : (int?)null;

        private void OnTokenReceived(object sender, TokenReceivedEventArgs args) => _tokenReceived?.Invoke(args?.Token ?? string.Empty);

        private void OnMessageReceived(object sender, MessageReceivedEventArgs args)
        {
            FirebaseMessage message = args?.Message;
            if (message == null) return;

            _messageReceived?.Invoke(FirebasePushProvider.ToMessage(
                message.MessageId,
                message.Notification?.Title,
                message.Notification?.Body,
                message.Data,
                message.NotificationOpened));
        }
#endif
    }
}
