# Provenance and boundaries

CreateTable and CommonDataToolSettings are extracted under the user's explicit STEP 8 local authoring request from {workspace}/jjevol_library_mobile/Assets/Common/Script/Data/Editor. CreateTable is adapted; CommonDataToolSettings is byte-identical. Original script metas are preserved. Public redistribution terms remain unspecified; no new license grant is inferred.

Unity Editor and the existing Tables Core are required. No external SDK source, Aes implementation, encryption settings/keys, Google spreadsheet identifiers/credentials or product content is bundled. Legacy compatibility reference code and random test credentials exist only in the separate ignored validation Host, not this package. Localization, Firebase, remote deployment and general Addressables loading are not extracted.
