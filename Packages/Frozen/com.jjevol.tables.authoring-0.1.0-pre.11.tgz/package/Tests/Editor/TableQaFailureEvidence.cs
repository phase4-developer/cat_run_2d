using System;
using System.IO;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using UnityEngine;

namespace jjevol.Tables.Authoring.Tests
{
    // Opt-in QA evidence only. Normal package tests do not write a second artifact root.
    public static class TableQaFailureEvidence
    {
        public static void Capture(string root,string output)
        {
            string target=Environment.GetEnvironmentVariable("JJEvolTableQaEvidence");
            if(string.IsNullOrEmpty(target) || TestContext.CurrentContext.Result.Outcome.Status!=TestStatus.Failed)return;
            string allowed=Path.GetFullPath(Path.Combine(Application.dataPath,"../../../step05b-qa"));target=Path.GetFullPath(target);
            string source=Path.GetFullPath(root);
            string consumeQa=Path.GetFullPath(Path.Combine(Application.dataPath,"../../../step05c-validation"));
            string uxQa=Path.GetFullPath(Path.Combine(Application.dataPath,"../../../step05c-ux-validation"));
            string hostQa=Path.GetFullPath(Path.Combine(Application.dataPath,"../Temp/JJEvolTableQaEvidence"));
            if((!target.StartsWith(allowed+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase) && !target.StartsWith(consumeQa+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase) && !target.StartsWith(uxQa+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase) && !target.StartsWith(hostQa+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase)) || !Directory.Exists(target) ||
                !source.StartsWith(Path.GetFullPath(Application.dataPath)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase) ||
                !Path.GetFileName(source).StartsWith("JJEvolStep",StringComparison.Ordinal))throw new InvalidOperationException("Unsafe QA evidence path");
            string destination=Path.Combine(target,"failed-fixtures",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(destination);
            File.WriteAllText(Path.Combine(destination,"context.txt"),TestContext.CurrentContext.Test.FullName+"\n"+source+"\n"+DateTime.UtcNow.ToString("o"));
            if(Directory.Exists(source))Copy(source,Path.Combine(destination,"fixture"));
            string manifest=TableBuilder.GetManifestPath(output);
            foreach(string suffix in new[]{"",".pending"})if(File.Exists(manifest+suffix))File.Copy(manifest+suffix,Path.Combine(destination,"manifest.json"+suffix));
            if(File.Exists(manifest+".pending"))
            {
                var marker=JsonUtility.FromJson<Locator>(File.ReadAllText(manifest+".pending"));
                if(marker?.journal!=null)
                {
                    string project=Path.GetFullPath(Path.Combine(Application.dataPath,"..")),journal=Path.GetFullPath(Path.Combine(project,marker.journal));
                    string permitted=Path.Combine(project,"Library","JJEvol","TableAuthoring")+Path.DirectorySeparatorChar;
                    if(journal.StartsWith(permitted,StringComparison.OrdinalIgnoreCase) && File.Exists(journal))File.Copy(journal,Path.Combine(destination,"journal.json"));
                }
            }
            TestContext.Progress.WriteLine("[Table QA] Failed synthetic fixture preserved at "+destination);
        }
        static void Copy(string source,string destination)
        {
            if((File.GetAttributes(source)&FileAttributes.ReparsePoint)!=0)return;
            Directory.CreateDirectory(destination);
            foreach(string file in Directory.GetFiles(source))if((File.GetAttributes(file)&FileAttributes.ReparsePoint)==0)File.Copy(file,Path.Combine(destination,Path.GetFileName(file)));
            foreach(string directory in Directory.GetDirectories(source))Copy(directory,Path.Combine(destination,Path.GetFileName(directory)));
        }
        [Serializable]sealed class Locator{public string journal;}
    }
}
