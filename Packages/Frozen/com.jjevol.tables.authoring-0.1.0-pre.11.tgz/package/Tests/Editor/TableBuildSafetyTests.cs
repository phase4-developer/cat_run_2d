using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TableBuildSafetyTests
    {
        private string _root, _output;
        private static TableInput A(string value = "old") => TableInput.FromText("a", "key\tlabel\nx\t" + value);
        private static TableInput B(string value = "old") => TableInput.FromText("b", "key\tlabel\ny\t" + value);
        [SetUp] public void Setup()
        {
            _root = "Assets/JJEvolStep05Safety_" + Guid.NewGuid().ToString("N"); _output = _root + "/Resources/Tables";
            TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null; TableAuthoringOptions.ValidateTables = null;
            TableAuthoringOptions.CodecProfileVersion = "test:v1"; TableAuthoringOptions.ValidationVersion = "1";
        }
        [TearDown] public void Cleanup()
        {
            TableQaFailureEvidence.Capture(_root,_output);
            if (Directory.Exists(_root + "/Resources/Linked")) Directory.Delete(_root + "/Resources/Linked");
            PipelineValidation.ForgetFixtureMetadata(_root); AssetDatabase.Refresh(); if (AssetDatabase.IsValidFolder(_root)) AssetDatabase.DeleteAsset(_root);
            TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null; TableAuthoringOptions.ValidateTables = null;
            TableAuthoringOptions.CodecProfileVersion = ""; TableAuthoringOptions.ValidationVersion = "1";
        }
        private TableBuildPlan Plan(params TableInput[] inputs) => TableBuilder.Plan(new TableBuildRequest(inputs, _output, false));
        private TableBuildResult Apply(params TableInput[] inputs) => TableBuilder.Prepare(Plan(inputs)).Apply();
        private byte[] Bytes(string table) => File.ReadAllBytes(_output + "/" + table + ".txt");
        private static void Writer(TablePreparedBuild prepared, Func<Action<string, byte[]>, Action<string, byte[]>> wrap)
        { var field = typeof(TablePreparedBuild).GetField("WriteFile", BindingFlags.Instance | BindingFlags.NonPublic); field.SetValue(prepared, wrap((Action<string, byte[]>)field.GetValue(prepared))); }
        private static void Checkpoint(TablePreparedBuild prepared, Action<string, byte[], string> write)
        { typeof(TablePreparedBuild).GetField("WriteCheckpoint", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(prepared, write); }

        [Test]
        public void PreviewAndPrepareAreDeterministicAndDoNotCreateAnyOutputMetadataOrFolders()
        {
            var first = Plan(A()); var second = Plan(A()); Assert.That(first.Fingerprint, Is.EqualTo(second.Fingerprint));
            Assert.That(first.Changes.Single().Action, Is.EqualTo(TableOutputAction.Create)); Assert.That(Directory.Exists(_root), Is.False); Assert.That(File.Exists(first.ManifestPath), Is.False);
            TableBuilder.Prepare(first); Assert.That(Directory.Exists(_root), Is.False); Assert.That(File.Exists(first.ManifestPath), Is.False);
        }
        [Test]
        public void MissingRequiredValidatorBlocksButStructuralOnlyCoverageIsHonest()
        {
            var missing = TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _output, false, requireValidator:true)); Assert.That(missing.IsValid, Is.False);
            Assert.That(missing.Diagnostics.Any(d => d.Code == "MissingValidator"), Is.True); Assert.Throws<InvalidOperationException>(() => TableBuilder.Prepare(missing));
            Assert.That(Plan(A()).Coverage.Any(s => s.StartsWith("NOT VALIDATED")), Is.True); Assert.That(Directory.Exists(_root), Is.False);
            int calls = 0;
            var invalid = TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("a", "key\tKEY\nx\ty") }, _output, false, validate:_ => calls++));
            Assert.That(calls, Is.Zero); Assert.That(invalid.Coverage.Any(s => s.StartsWith("NOT RUN: game validator")), Is.True);
        }
        [Test]
        public void SingleAndMultipleSelectionPreserveOtherFilesAndTheirMetaExactly()
        {
            Apply(A(), B()); byte[] b = Bytes("b"), meta = File.ReadAllBytes(_output + "/b.txt.meta");
            File.WriteAllText(_output + "/manual.txt", "unmanaged"); AssetDatabase.Refresh(); byte[] manualMeta = File.ReadAllBytes(_output + "/manual.txt.meta");
            var selected = TableBuilder.Plan(new TableBuildRequest(new[] { A("new"), B("pending-not-applied") }, _output, false, selected:new[] { "a" }));
            Assert.That(selected.ValidationInputs.Single(i => i.TableName == "b").Rows[0].Get("label"), Is.EqualTo("old"));
            TableBuilder.Prepare(selected).Apply(); Assert.That(Bytes("b"), Is.EqualTo(b)); Assert.That(File.ReadAllBytes(_output + "/b.txt.meta"), Is.EqualTo(meta));
            Assert.That(File.ReadAllText(_output + "/manual.txt"), Is.EqualTo("unmanaged")); Assert.That(File.ReadAllBytes(_output + "/manual.txt.meta"), Is.EqualTo(manualMeta));
            Apply(A("newer"), B("updated")); Assert.That(File.ReadAllText(_output + "/a.txt"), Does.Contain("newer")); Assert.That(File.ReadAllText(_output + "/b.txt"), Does.Contain("updated"));
        }
        [Test]
        public void FullAndRemoveRequireExplicitScopesAndNeverOwnUnmanagedTxt()
        {
            Apply(A(), B()); File.WriteAllText(_output + "/manual.txt", "keep");
            Assert.That(TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _output, false, TableBuildOperation.Full)).IsValid, Is.False);
            var full = TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _output, false, TableBuildOperation.Full, completeCatalog:true));
            Assert.That(full.Changes.Single(c => c.Action == TableOutputAction.Delete).TableName, Is.EqualTo("b")); Assert.That(File.Exists(_output + "/b.txt"), Is.True);
            TableBuilder.Prepare(full).Apply(); Assert.That(File.Exists(_output + "/b.txt"), Is.False); Assert.That(File.Exists(_output + "/b.txt.meta"), Is.False); Assert.That(File.ReadAllText(_output + "/manual.txt"), Is.EqualTo("keep"));
            var empty = TableBuilder.Plan(new TableBuildRequest(Array.Empty<TableInput>(), _output, false, TableBuildOperation.Full, completeCatalog:true)); Assert.That(empty.IsValid, Is.False);
            var foreign = TableBuilder.Plan(new TableBuildRequest(Array.Empty<TableInput>(), _output, false, TableBuildOperation.Remove, selected:new[] { "manual" })); Assert.That(foreign.IsValid, Is.False);
            var remove = TableBuilder.Plan(new TableBuildRequest(Array.Empty<TableInput>(), _output, false, TableBuildOperation.Remove, selected:new[] { "a" }));
            TableBuilder.Prepare(remove).Apply(); Assert.That(File.Exists(_output + "/a.txt"), Is.False); Assert.That(File.Exists(_output + "/manual.txt"), Is.True);
        }
        [Test]
        public void InitialAdoptionRequiresExplicitReviewAndPreservesExistingGuid()
        {
            Directory.CreateDirectory(_output); File.WriteAllText(_output + "/a.txt", "key\tlabel\nx\tlegacy"); AssetDatabase.Refresh(); string guid = AssetDatabase.AssetPathToGUID(_output + "/a.txt");
            var blocked = Plan(A("adopted")); Assert.That(blocked.IsValid, Is.False); Assert.That(blocked.Changes.Single().Action, Is.EqualTo(TableOutputAction.Conflict));
            var adoption = TableBuilder.Plan(new TableBuildRequest(new[] { A("adopted") }, _output, false, adopt:new[] { "a" }));
            Assert.That(adoption.Changes.Single().ExistingGuid, Is.EqualTo(guid)); TableBuilder.Prepare(adoption).Apply();
            Assert.That(AssetDatabase.AssetPathToGUID(_output + "/a.txt"), Is.EqualTo(guid)); Assert.That(File.ReadAllText(_output + "/a.txt"), Does.Contain("adopted"));
        }
        [Test]
        public void IdenticalBuildIsNoOpAndRetainsFileMetaAndManifestBytes()
        {
            Apply(A()); byte[] output = Bytes("a"), meta = File.ReadAllBytes(_output + "/a.txt.meta"), manifest = File.ReadAllBytes(TableBuilder.GetManifestPath(_output));
            DateTime write = File.GetLastWriteTimeUtc(_output + "/a.txt"); var plan = Plan(A()); Assert.That(plan.Changes.Single().Action, Is.EqualTo(TableOutputAction.Unchanged));
            Assert.That(TableBuilder.Prepare(plan).Apply().NoOp, Is.True); Assert.That(Bytes("a"), Is.EqualTo(output)); Assert.That(File.ReadAllBytes(_output + "/a.txt.meta"), Is.EqualTo(meta));
            Assert.That(File.ReadAllBytes(plan.ManifestPath), Is.EqualTo(manifest)); Assert.That(File.GetLastWriteTimeUtc(_output + "/a.txt"), Is.EqualTo(write));
        }
        [TestCase("input")] [TestCase("output")] [TestCase("meta")] [TestCase("manifest")] [TestCase("catalog")]
        public void FileChangesAfterPreviewCannotBeApplied(string kind)
        {
            Directory.CreateDirectory(_root + "/Source"); string source = _root + "/Source/a.tsv"; File.WriteAllText(source, "key\tlabel\nx\told");
            TableBuilder.Build(_root + "/Source", _output, false);
            var plan = TableBuilder.Plan(new TableBuildRequest(TableBuilder.ReadDirectory(_root + "/Source"), _output, false, catalogDirectory:_root + "/Source"));
            if (kind == "input") File.AppendAllText(source, "\ny\tnew");
            if (kind == "output") File.AppendAllText(_output + "/a.txt", "foreign");
            if (kind == "meta") File.AppendAllText(_output + "/a.txt.meta", "\nuserData: changed\n");
            if (kind == "manifest") File.AppendAllText(plan.ManifestPath, " ");
            if (kind == "catalog") File.WriteAllText(_root + "/Source/b.tsv", "key\tlabel\ny\tnew");
            Assert.Throws<IOException>(() => TableBuilder.Prepare(plan));
        }
        [TestCase("validator")] [TestCase("decoder")] [TestCase("codec-version")] [TestCase("validator-version")]
        public void SettingsChangesAfterPreviewInvalidateThePlan(string kind)
        {
            var plan = Plan(A());
            if (kind == "validator") TableAuthoringOptions.ValidateTables = _ => { };
            if (kind == "decoder") TableRuntimeOptions.DecryptBytes = b => b;
            if (kind == "codec-version") TableAuthoringOptions.CodecProfileVersion = "changed";
            if (kind == "validator-version") TableAuthoringOptions.ValidationVersion = "changed";
            Assert.Throws<InvalidOperationException>(() => TableBuilder.Prepare(plan)); Assert.That(Directory.Exists(_root), Is.False);
        }
        [Test]
        public void OutputChangeAfterPrepareIsDetectedBeforeAnyApplyMutation()
        {
            Apply(A()); var prepared = TableBuilder.Prepare(Plan(A("new"))); string manifest = File.ReadAllText(TableBuilder.GetManifestPath(_output));
            File.WriteAllText(_output + "/a.txt", "foreign after Prepare");
            Assert.Throws<IOException>(() => prepared.Apply()); Assert.That(File.ReadAllText(_output + "/a.txt"), Is.EqualTo("foreign after Prepare"));
            Assert.That(File.ReadAllText(TableBuilder.GetManifestPath(_output)), Is.EqualTo(manifest));
        }
        [Test]
        public void GameValidatorCanReturnStructuredLocationsWithoutLoggingRawExceptionDetails()
        {
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _output, false, validate:_ =>
                throw new TableInputException(new TableDiagnostic(TableDiagnosticSeverity.Error,"GameFK","a","game fixture","Unknown referenced definition",2,2,2,3,"label"))));
            Assert.That(plan.IsValid, Is.False); var diagnostic = plan.Diagnostics.Single(d => d.Code == "GameFK");
            Assert.That(diagnostic.Row, Is.EqualTo(2)); Assert.That(diagnostic.Header, Is.EqualTo("label")); Assert.That(Directory.Exists(_root), Is.False);
        }
        [Test]
        public void ManagedManualEditsCannotBeOverwrittenOrPrunedEvenByFull()
        { Apply(A(), B()); File.AppendAllText(_output + "/b.txt", "manual edit"); var plan = TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _output, false, TableBuildOperation.Full, completeCatalog:true)); Assert.That(plan.IsValid, Is.False); Assert.Throws<InvalidDataException>(() => TableBuilder.Prepare(plan)); Assert.That(File.ReadAllText(_output + "/b.txt"), Does.EndWith("manual edit")); }
        [Test]
        public void SelectedForeignKeysValidateAgainstAppliedNonselectedRows()
        {
            Apply(TableInput.FromText("defs", "key\nold"), TableInput.FromText("use", "key\treference\nx\told"));
            Action<System.Collections.Generic.IReadOnlyList<TableBuildInput>> validate = inputs =>
            {
                var keys = inputs.Single(i => i.TableName == "defs").Rows.Select(r => r.Get("key")).ToArray();
                if (inputs.Single(i => i.TableName == "use").Rows.Any(r => !keys.Contains(r.Get("reference")))) throw new InvalidDataException("Unapplied FK");
            };
            var inputs = new[] { TableInput.FromText("defs", "key\nnew"), TableInput.FromText("use", "key\treference\nx\tnew") };
            var partial = TableBuilder.Plan(new TableBuildRequest(inputs, _output, false, selected:new[] { "use" }, validate:validate, requireValidator:true));
            Assert.That(partial.IsValid, Is.False); Assert.That(File.ReadAllText(_output + "/use.txt"), Does.Contain("old"));
            var both = TableBuilder.Plan(new TableBuildRequest(inputs, _output, false, validate:validate, requireValidator:true)); Assert.That(both.IsValid, Is.True); TableBuilder.Prepare(both).Apply();
        }
        [Test]
        public void NondeterministicEncryptionIsNotCalledOrRewrittenForUnchangedTables()
        {
            int calls = 0;
            TableAuthoringOptions.EncryptBytes = plain => { calls++; return Guid.NewGuid().ToByteArray().Concat(plain).ToArray(); };
            TableRuntimeOptions.DecryptBytes = bytes => bytes.Skip(16).ToArray();
            var request = new TableBuildRequest(new[] { A() }, _output, true); var first = TableBuilder.Plan(request); Assert.That(calls, Is.Zero);
            TableBuilder.Prepare(first).Apply(); byte[] bytes = Bytes("a"); Assert.That(calls, Is.EqualTo(1));
            var next = TableBuilder.Plan(request); Assert.That(next.Changes.Single().Action, Is.EqualTo(TableOutputAction.Unchanged));
            Assert.That(TableBuilder.Prepare(next).Apply().NoOp, Is.True); Assert.That(calls, Is.EqualTo(1)); Assert.That(Bytes("a"), Is.EqualTo(bytes));
            TableRuntimeOptions.DecryptBytes = _ => new byte[] { 1 }; Assert.That(TableBuilder.Plan(request).IsValid, Is.False);
        }
        [Test]
        public void CodecMismatchOnOneTablePreventsEveryOutputAndNeverFallsBackToPlaintext()
        {
            TableAuthoringOptions.EncryptBytes = b => b; TableRuntimeOptions.DecryptBytes = _ => new byte[] { 7 };
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { A(), B() }, _output, true)); Assert.That(plan.IsValid, Is.True);
            Assert.Throws<InvalidDataException>(() => TableBuilder.Prepare(plan)); Assert.That(Directory.Exists(_root), Is.False); Assert.That(File.Exists(plan.ManifestPath), Is.False);
        }
        [Test]
        public void InPlaceCodecDelegatesCannotMutateTheExpectedPlaintextOrStoredCiphertext()
        {
            TableAuthoringOptions.EncryptBytes = bytes => { for (int i = 0; i < bytes.Length; i++) bytes[i] ^= 0x55; return bytes; };
            TableRuntimeOptions.DecryptBytes = bytes => { for (int i = 0; i < bytes.Length; i++) bytes[i] ^= 0x55; return bytes; };
            var request = new TableBuildRequest(new[] { A() }, _output, true); TableBuilder.Prepare(TableBuilder.Plan(request)).Apply();
            byte[] encrypted = Convert.FromBase64String(File.ReadAllText(_output + "/a.txt"));
            Assert.That(Encoding.UTF8.GetString(TableRuntimeOptions.DecryptBytes(encrypted)), Is.EqualTo(A().Text));
            Assert.That(TableBuilder.Prepare(TableBuilder.Plan(request)).Apply().NoOp, Is.True);
        }
        [Test]
        public void CapturedCodecConfigurationChangeAfterPrepareBlocksBeforeCreatingFiles()
        {
            bool changed = false; TableAuthoringOptions.EncryptBytes = b => b;
            TableRuntimeOptions.DecryptBytes = b => changed ? new byte[] { 1 } : b;
            var prepared = TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _output, true))); changed = true;
            Assert.Throws<InvalidDataException>(() => prepared.Apply()); Assert.That(Directory.Exists(_root), Is.False); Assert.That(File.Exists(prepared.Plan.ManifestPath), Is.False);
        }
        [Test]
        public void FullPreviewReportsTheActualCompleteScopeRegardlessOfPartialSelection()
        {
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { A(), B() }, _output, false, TableBuildOperation.Full, selected:new[] { "a" }, completeCatalog:true));
            Assert.That(plan.Request.Selected, Is.EquivalentTo(new[] { "a", "b" })); Assert.That(plan.Changes.Select(c => c.TableName), Is.EquivalentTo(new[] { "a", "b" }));
        }
        [Test]
        public void SchemasDoNotPretendToProvideARequiredGameForeignKeyValidator()
        {
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _output, false, requireValidator:true,
                schemas:new[] { new TableSchema("a",new TableColumnRule("key")) }));
            Assert.That(plan.IsValid, Is.False); Assert.That(plan.Diagnostics.Any(d => d.Code == "MissingValidator"), Is.True);
        }
        [Test]
        public void CaseOnlyNameMigrationIsBlockedInsteadOfCreatingAnAmbiguousSecondAsset()
        { Apply(A()); var plan = Plan(TableInput.FromText("A", A().Text)); Assert.That(plan.IsValid, Is.False); Assert.That(plan.Diagnostics.Any(d => d.Code == "TableNameCaseChange"), Is.True); }
        [Test]
        public void GameCallbackCannotChangeFilesAfterTheFreshnessCheckAndStillApply()
        {
            Apply(A()); bool mutate = false;
            Action<System.Collections.Generic.IReadOnlyList<TableBuildInput>> validate = _ => { if (mutate) File.WriteAllText(_output + "/a.txt", "foreign callback"); };
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { A("new") }, _output, false, validate:validate)); mutate = true;
            Assert.Throws<IOException>(() => TableBuilder.Prepare(plan)); Assert.That(File.ReadAllText(_output + "/a.txt"), Is.EqualTo("foreign callback"));
        }
        [Test]
        public void MidApplyIoFailureRestoresAllOwnBytesMetaAndManifest()
        {
            Apply(A(), B()); byte[] a = Bytes("a"), b = Bytes("b"), meta = File.ReadAllBytes(_output + "/a.txt.meta"), manifest = File.ReadAllBytes(TableBuilder.GetManifestPath(_output));
            var prepared = TableBuilder.Prepare(Plan(A("new"), B("new")));
            Writer(prepared, original => (path, bytes) => { if (Path.GetFileName(path) == "b.txt") throw new IOException("injected second-file failure"); original(path, bytes); });
            Assert.Throws<IOException>(() => prepared.Apply()); Assert.That(Bytes("a"), Is.EqualTo(a)); Assert.That(Bytes("b"), Is.EqualTo(b));
            Assert.That(File.ReadAllBytes(_output + "/a.txt.meta"), Is.EqualTo(meta)); Assert.That(File.ReadAllBytes(TableBuilder.GetManifestPath(_output)), Is.EqualTo(manifest)); Assert.That(TableBuilder.Recover(_output), Is.True);
        }
        private void LeaveInterruptedBuild()
        {
            Apply(A(), B()); int aWrites = 0; var prepared = TableBuilder.Prepare(Plan(A("new"), B("new")));
            Writer(prepared, original => (path, bytes) =>
            { if (Path.GetFileName(path) == "b.txt" || (Path.GetFileName(path) == "a.txt" && ++aWrites > 1)) throw new IOException("injected apply/restore failure"); original(path, bytes); });
            Assert.Throws<TableBuildRecoveryException>(() => prepared.Apply());
        }
        [Test]
        public void RecoveryRequiredIsPersistentAndExplicitRecoveryUsesVerifiedBackups()
        {
            LeaveInterruptedBuild(); Assert.That(Plan(A()).IsValid, Is.False); Assert.That(TableBuilder.Recover(_output), Is.True);
            Assert.That(File.ReadAllText(_output + "/a.txt"), Does.EndWith("old")); Assert.That(Plan(A()).IsValid, Is.True);
        }
        [Test]
        public void LosingLibraryJournalNeverMakesMixedOutputsReady()
        {
            LeaveInterruptedBuild(); string manifest = TableBuilder.GetManifestPath(_output); var record = JsonUtility.FromJson<Marker>(File.ReadAllText(manifest + ".pending"));
            string journal = Path.GetFullPath(Path.Combine(Application.dataPath, "..", record.journal));
            Assert.That(journal, Does.StartWith(Path.GetFullPath(Path.Combine(Application.dataPath, "../Library/JJEvol/TableAuthoring")) + Path.DirectorySeparatorChar));
            File.Delete(journal); Assert.That(TableBuilder.Recover(_output), Is.False); Assert.That(Plan(A()).Diagnostics.Any(d => d.Code == "RecoveryRequired"), Is.True);
        }
        [Test]
        public void ForeignWriterDuringFailureIsNeverOverwrittenByRollbackOrRecovery()
        {
            Apply(A(), B()); var prepared = TableBuilder.Prepare(Plan(A("new"), B("new")));
            Writer(prepared, original => (path, bytes) =>
            { if (Path.GetFileName(path) == "b.txt") { File.WriteAllText(_output + "/a.txt", "foreign writer"); throw new IOException("foreign change"); } original(path, bytes); });
            Assert.Throws<TableBuildRecoveryException>(() => prepared.Apply()); Assert.That(File.ReadAllText(_output + "/a.txt"), Is.EqualTo("foreign writer"));
            Assert.That(TableBuilder.Recover(_output), Is.False); Assert.That(File.ReadAllText(_output + "/a.txt"), Is.EqualTo("foreign writer"));
        }
        [Test]
        public void ActualExclusiveFileLockFailsWithoutDeletingTheOriginal()
        {
            Apply(A()); byte[] before = Bytes("a"); var prepared = TableBuilder.Prepare(Plan(A("new")));
            using (var locked = new FileStream(_output + "/a.txt", FileMode.Open, FileAccess.Read, FileShare.None)) Assert.Throws<IOException>(() => prepared.Apply());
            Assert.That(Bytes("a"), Is.EqualTo(before)); Assert.That(TableBuilder.Recover(_output), Is.True);
        }
        [Test]
        public void TornCheckpointRemainsBlockedAndCannotBeMistakenForReady()
        {
            Apply(A()); var prepared = TableBuilder.Prepare(Plan(A("new"))); string manifest = prepared.Plan.ManifestPath;
            Checkpoint(prepared, (path, bytes, expected) => { File.WriteAllText(path, "{torn checkpoint"); throw new IOException("injected interrupted checkpoint"); });
            Assert.Throws<TableBuildRecoveryException>(() => prepared.Apply());
            Assert.That(File.Exists(manifest + ".pending"), Is.True); Assert.That(Plan(A()).IsValid, Is.False);
            Assert.That(TableBuilder.Recover(_output), Is.False); Assert.That(File.ReadAllText(manifest), Is.EqualTo("{torn checkpoint"));
            Assert.That(File.ReadAllText(_output + "/a.txt"), Does.EndWith("new"));
        }
        [Test]
        public void MissingFirstCheckpointStillHasPersistentRecoveryLocator()
        {
            var prepared = TableBuilder.Prepare(Plan(A())); string manifest = prepared.Plan.ManifestPath;
            Checkpoint(prepared, (path, bytes, expected) => { File.WriteAllText(path + ".pending", "foreign marker"); throw new IOException("checkpoint not reached"); });
            Assert.Throws<TableBuildRecoveryException>(() => prepared.Apply());
            Assert.That(File.Exists(manifest), Is.False); Assert.That(File.Exists(manifest + ".pending"), Is.True);
            Assert.That(Plan(A()).IsValid, Is.False); Assert.That(TableBuilder.Recover(_output), Is.False);
            Assert.That(File.ReadAllText(manifest + ".pending"), Is.EqualTo("foreign marker"));
            // This known synthetic locator has deliberately been made unparsable by this test.
            File.Delete(manifest + ".pending");
        }
        [Test]
        public void NativeCheckpointLockRetainsMarkerAndAllowsVerifiedRecoveryAfterUnlock()
        {
            Apply(A()); byte[] before = Bytes("a"); var prepared = TableBuilder.Prepare(Plan(A("new"))); string manifest = prepared.Plan.ManifestPath;
            var original = (Action<string, byte[], string>)typeof(TablePreparedBuild).GetField("WriteCheckpoint", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(prepared);
            FileStream locked = null;
            Checkpoint(prepared, (path, bytes, expected) => { locked = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.None); original(path, bytes, expected); });
            try { Assert.Throws<TableBuildRecoveryException>(() => prepared.Apply()); } finally { locked?.Dispose(); }
            Assert.That(File.Exists(manifest + ".pending"), Is.True); Assert.That(Plan(A()).IsValid, Is.False);
            Assert.That(TableBuilder.Recover(_output), Is.True); Assert.That(Bytes("a"), Is.EqualTo(before));
            Assert.That(File.Exists(manifest + ".pending"), Is.False);
        }
        [TestCase("../escape")] [TestCase("CON")] [TestCase("a/b")] [TestCase("a.")]
        public void UnsafeNamesAreRejectedBeforeOutputCreation(string name)
        { Assert.Throws<ArgumentException>(() => Plan(TableInput.FromText(name, "key\nx"))); Assert.That(Directory.Exists(_root), Is.False); }
        [Test]
        public void OverlappingOutsideAndDuplicateNamesAreRejected()
        {
            Assert.Throws<ArgumentException>(() => TableBuilder.Plan(new TableBuildRequest(new[] { A() }, _root + "/NotResources", false)));
            Assert.That(Plan(A(), A()).IsValid, Is.False);
            Directory.CreateDirectory(_output); File.WriteAllText(_output + "/a.tsv", "key\nx");
            Assert.Throws<ArgumentException>(() => TableBuilder.Build(_output, _output, false));
        }
        [Test]
        public void WindowsJunctionOutputCannotRedirectWritesToAnotherDirectory()
        {
            Assert.That(Application.platform, Is.EqualTo(RuntimePlatform.WindowsEditor));
            string target = Path.GetFullPath(_root + "/Target"), link = Path.GetFullPath(_root + "/Resources/Linked"); Directory.CreateDirectory(target); Directory.CreateDirectory(Path.GetDirectoryName(link));
            using var process = System.Diagnostics.Process.Start(new ProcessStartInfo("cmd.exe", "/c mklink /J \"" + link + "\" \"" + target + "\"") { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden, RedirectStandardOutput = true, RedirectStandardError = true });
            process.WaitForExit(); Assert.That(process.ExitCode, Is.Zero, "Isolated Windows junction fixture must be available");
            Assert.Throws<ArgumentException>(() => TableBuilder.Plan(new TableBuildRequest(new[] { A() }, link, false))); Assert.That(Directory.GetFiles(target), Is.Empty);
        }
        [Serializable] private sealed class Marker { public string journal; }
    }
}
