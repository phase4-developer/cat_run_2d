using System;
using NUnit.Framework;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TableSpreadsheetLinkTests
    {
        private const string Id = "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789_-abcd";

        [TestCase("https://docs.google.com/spreadsheets/d/" + Id + "/edit#gid=0")]
        [TestCase("https://docs.google.com/spreadsheets/d/" + Id)]
        [TestCase("https://docs.google.com/spreadsheets/d/" + Id + "/edit?usp=sharing")]
        [TestCase("  " + Id + "  ")]
        public void AddressOrBareIdGivesTheSpreadsheetId(string value)
        {
            Assert.That(TableSpreadsheetLink.TryGetId(value, out string id), Is.True); Assert.That(id, Is.EqualTo(Id));
        }

        [TestCase(null)][TestCase("")][TestCase("   ")][TestCase("short")]
        [TestCase("https://example.com/spreadsheets/d/" + Id)]
        [TestCase("http://docs.google.com/spreadsheets/d/" + Id)]
        [TestCase("https://docs.google.com/document/d/" + Id)]
        [TestCase("sheet id with spaces 0123456789")]
        public void OtherTextIsNotASpreadsheet(string value)
        {
            Assert.That(TableSpreadsheetLink.TryGetId(value, out string id), Is.False); Assert.That(id, Is.Null);
            Assert.Throws<ArgumentException>(() => TableSpreadsheetLink.OpenUrl(value));
        }

        [Test]
        public void OpenUrlKeepsAFullAddressAndBuildsOneFromAnId()
        {
            string full = "https://docs.google.com/spreadsheets/d/" + Id + "/edit#gid=42";
            Assert.That(TableSpreadsheetLink.OpenUrl(" " + full), Is.EqualTo(full));
            Assert.That(TableSpreadsheetLink.OpenUrl(Id), Is.EqualTo("https://docs.google.com/spreadsheets/d/" + Id + "/edit"));
        }
    }
}
