using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using NUnit.Framework;
using UnityEditor;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TableRecoveryBoundaryTests
    {
        string root,output;
        static TableInput A(string label="old")=>TableInput.FromText("a","key\tlabel\nx\t"+label);
        static TableInput B(string label="old")=>TableInput.FromText("b","key\tlabel\ny\t"+label);
        TableBuildPlan Plan(params TableInput[] inputs)=>TableBuilder.Plan(new TableBuildRequest(inputs,output,false));
        void Apply(params TableInput[] inputs)=>TableBuilder.Prepare(Plan(inputs)).Apply();
        [SetUp]public void Setup()
        {
            root="Assets/JJEvolStep05QARecovery_"+Guid.NewGuid().ToString("N");output=root+"/Resources/Tables";
            TableAuthoringOptions.ValidateTables=null;TableAuthoringOptions.EncryptBytes=null;TableRuntimeOptions.DecryptBytes=null;
        }
        [TearDown]public void Cleanup()
        {TableQaFailureEvidence.Capture(root,output);PipelineValidation.ForgetFixtureMetadata(root);AssetDatabase.Refresh();if(AssetDatabase.IsValidFolder(root))AssetDatabase.DeleteAsset(root);}
        static void Writer(TablePreparedBuild prepared,Func<Action<string,byte[]>,Action<string,byte[]>> wrap)
        {var f=typeof(TablePreparedBuild).GetField("WriteFile",BindingFlags.Instance|BindingFlags.NonPublic);f.SetValue(prepared,wrap((Action<string,byte[]>)f.GetValue(prepared)));}
        [TestCase("output")][TestCase("meta")]
        public void ForeignChangeLateDuringRollbackCannotClearPendingOrReportReady(string kind)
        {
            Apply(A(),B());var prepared=TableBuilder.Prepare(Plan(A("new"),B("new")));
            string foreign=output+(kind=="meta"?"/b.txt.meta":"/b.txt");
            Writer(prepared,original=>(path,bytes)=>
            {
                if(Path.GetFileName(path)=="b.txt")throw new IOException("QA second-file failure");
                original(path,bytes);
                if(Path.GetFileName(path)=="a.txt" && Encoding.UTF8.GetString(bytes).EndsWith("old",StringComparison.Ordinal))
                    if(kind=="meta")File.WriteAllText(foreign,System.Text.RegularExpressions.Regex.Replace(File.ReadAllText(foreign),"(?m)^guid: [0-9a-fA-F]{32}","guid: "+Guid.NewGuid().ToString("N")));else File.AppendAllText(foreign,"\nQA foreign edit during rollback");
            });
            Assert.Throws<TableBuildRecoveryException>(()=>prepared.Apply());
            Assert.That(File.Exists(prepared.Plan.ManifestPath+".pending"),Is.True);
            byte[] changed=File.ReadAllBytes(foreign);
            Assert.That(Plan(A("new"),B("new")).IsValid,Is.False);
            Assert.Throws<InvalidDataException>(()=>TableBuilder.Prepare(Plan(A("new"),B("new"))));
            Assert.That(TableBuilder.Recover(output),Is.False);Assert.That(File.ReadAllBytes(foreign),Is.EqualTo(changed));
        }
        [Test]
        public void FailureBeforeFirstOutputWritePreservesFilesMetaAndManifest()
        {
            Apply(A(),B());string manifest=TableBuilder.GetManifestPath(output);
            var paths=new[]{output+"/a.txt",output+"/a.txt.meta",output+"/b.txt",output+"/b.txt.meta",manifest};
            var before=paths.Select(File.ReadAllBytes).ToArray();var prepared=TableBuilder.Prepare(Plan(A("new"),B("new")));
            Writer(prepared,_=>(path,bytes)=>{throw new IOException("QA before first write");});
            Assert.Throws<IOException>(()=>prepared.Apply());
            for(int i=0;i<paths.Length;i++)Assert.That(File.ReadAllBytes(paths[i]),Is.EqualTo(before[i]));
            Assert.That(File.Exists(manifest+".pending"),Is.False);Assert.That(TableBuilder.Recover(output),Is.True);
        }
        [Test]
        public void WindowDisplaysRecoveryRequiredAndDropsThePreparedPlan()
        {
            var window=UnityEngine.ScriptableObject.CreateInstance<CreateTable>();
            try
            {
                typeof(CreateTable).GetMethod("Run",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(window,new object[]{(Action)(()=>{throw new TableBuildRecoveryException();})});
                string status=(string)typeof(CreateTable).GetField("_status",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(window);
                Assert.That(status,Does.StartWith("RecoveryRequired:"));
                Assert.That(typeof(CreateTable).GetField("_prepared",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(window),Is.Null);
                Assert.That(typeof(CreateTable).GetField("_plan",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(window),Is.Null);
            }
            finally{UnityEngine.Object.DestroyImmediate(window);}
        }
        [TestCase("output")][TestCase("meta")][TestCase("manifest")]
        public void ReadyMismatchIsDetectedWithoutChangingAnyFile(string kind)
        {
            Apply(A());string manifest=TableBuilder.GetManifestPath(output);
            string path=kind=="output"?output+"/a.txt":kind=="meta"?output+"/a.txt.meta":manifest;
            if(kind=="manifest")File.WriteAllText(path,File.ReadAllText(path).Replace("\"hash\": \"","\"hash\": \"foreign"));
            else File.AppendAllText(path,"\nQA mismatch");
            byte[] changed=File.ReadAllBytes(path);Assert.That(TableBuilder.Recover(output),Is.False);
            Assert.That(Plan(A()).IsValid,Is.False);Assert.That(File.ReadAllBytes(path),Is.EqualTo(changed));
        }
    }
}
