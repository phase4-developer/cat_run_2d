using System;
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TableInputPreviewTests
    {
        private string _root;
        [SetUp] public void Setup() { _root = "Assets/JJEvolStep05Input_" + Guid.NewGuid().ToString("N"); Directory.CreateDirectory(_root); }
        [TearDown] public void Cleanup() { PipelineValidation.ForgetFixtureMetadata(_root); AssetDatabase.Refresh(); AssetDatabase.DeleteAsset(_root); }

        [TestCase(TableDialect.PlainTsv, "key\tlabel\r\nx\ta\"b\r\n", "a\"b")]
        [TestCase(TableDialect.QuotedTsv, "key\tlabel\r\nx\t\"a\"\"b\"\r\n", "a\"b")]
        [TestCase(TableDialect.Csv, "key,label\nx,\"a,b\"", "a,b")]
        [TestCase(TableDialect.Csv, "key,label\nx,\"a\"\"b\"", "a\"b")]
        public void ExplicitDialectsProduceExactRuntimeCellsWithoutChangingSource(TableDialect dialect, string text, string label)
        {
            var input = TableInput.FromText("definition", text, dialect); var doc = TableDocument.Parse(input);
            Assert.That(doc.Diagnostics.Where(d => d.Severity == TableDiagnosticSeverity.Error), Is.Empty);
            Assert.That(doc.Records.Single()[1].Value, Is.EqualTo(label)); Assert.That(TSVRow.FromTsv(doc.RuntimeText).Single().Get("label"), Is.EqualTo(label));
            Assert.That(input.Text, Is.EqualTo(text));
        }
        [TestCase("id,label\n1,\"a\tb\"")]
        [TestCase("id,label\n1,\"a\nb\"")]
        [TestCase("id,label\n1,\"a\r\nb\"")]
        public void UnsupportedCellControlsReportOriginalCellAndHeaderWithoutReplacingAnything(string text)
        {
            var input = TableInput.FromText("definition", text, TableDialect.Csv); var doc = TableDocument.Parse(input);
            var error = doc.Diagnostics.Single(d => d.Code == "RuntimeCellDelimiterUnsupported");
            Assert.That(error.Row, Is.EqualTo(2)); Assert.That(error.Column, Is.EqualTo(2)); Assert.That(error.Header, Is.EqualTo("label"));
            Assert.That(error.Line, Is.EqualTo(2)); Assert.That(error.Character, Is.EqualTo(3)); Assert.That(doc.IsValid, Is.False); Assert.That(input.Text, Is.EqualTo(text));
        }
        [TestCase("id\tid\n1\t2", "DuplicateHeader")]
        [TestCase("id\tID\n1\t2", "DuplicateHeader")]
        [TestCase("id\t id \n1\t2", "DuplicateHeader")]
        [TestCase("\t \n1\t2", "EmptyHeader")]
        [TestCase("", "EmptyInput")]
        public void AmbiguousOrMissingHeadersAreErrors(string text, string code)
        {
            var input = TableInput.FromText("definition", text); var doc = TableDocument.Parse(input);
            Assert.That(doc.Diagnostics.Any(d => d.Code == code), Is.True); Assert.That(doc.IsValid, Is.False); Assert.That(input.Text, Is.EqualTo(text));
        }
        [TestCase("id,label\n1,\"unterminated", "UnterminatedQuote")]
        [TestCase("id,label\n1,a\"b", "UnexpectedQuote")]
        [TestCase("id,label\n1,\"a\" tail", "AfterClosingQuote")]
        public void BadQuotesAreLocatedAndNotCleaned(string text, string code)
        { var doc = TableDocument.Parse(TableInput.FromText("definition", text, TableDialect.Csv)); Assert.That(doc.Diagnostics.Any(d => d.Code == code && d.Line > 0), Is.True); }
        [Test]
        public void EmptyCellIsDifferentFromMissingFieldAndNoIntIdIsForced()
        {
            var empty = TableDocument.Parse(TableInput.FromText("strings", "key\tlabel\nx\t"));
            Assert.That(empty.IsValid, Is.True); Assert.That(empty.Records.Single()[1].Value, Is.Empty);
            var missing = TableDocument.Parse(TableInput.FromText("strings", "key\tlabel\nx"));
            Assert.That(missing.IsValid, Is.True); Assert.That(missing.Records.Single()[1].Value, Is.Empty);
            Assert.That(missing.Diagnostics.Single().Severity, Is.EqualTo(TableDiagnosticSeverity.Warning));
        }
        [TestCase("key\tlabel\nx", "MissingCells", 2, "label")]
        [TestCase("key\tlabel\nx\tvalue\textra", "ExtraCells", 3, "(no header)")]
        public void WidthWarningIdentifiesTheFirstMissingOrExcessColumn(string text, string code, int column, string header)
        {
            var warning = TableDocument.Parse(TableInput.FromText("strings", text)).Diagnostics.Single(d => d.Code == code);
            Assert.That(warning.Severity, Is.EqualTo(TableDiagnosticSeverity.Warning));
            Assert.That(warning.Row, Is.EqualTo(2)); Assert.That(warning.Column, Is.EqualTo(column)); Assert.That(warning.Header, Is.EqualTo(header));
        }
        [TestCase(false, false)] [TestCase(true, false)] [TestCase(true, true)]
        public void Utf8AndBomUtf16InputsDecodeStrictlyAndPreserveOriginalBytes(bool bom, bool utf16)
        {
            string text = "key\tlabel\r\nx\t다국어\r\n"; Encoding codec = utf16 ? new UnicodeEncoding(false, true, true) : new UTF8Encoding(bom, true);
            byte[] bytes = codec.GetPreamble().Concat(codec.GetBytes(text)).ToArray(); string path = _root + "/definition.tsv"; File.WriteAllBytes(path, bytes);
            var input = TableInput.FromFile(path); Assert.That(input.Text, Is.EqualTo(text)); Assert.That(input.HasBom, Is.EqualTo(bom));
            Assert.That(input.Newlines, Is.EqualTo("CRLF")); Assert.That(TableDocument.Parse(input).IsValid, Is.True); Assert.That(File.ReadAllBytes(path), Is.EqualTo(bytes));
        }
        [Test]
        public void InvalidUtf8IsNotRepairedWithReplacementCharacters()
        { string path = _root + "/broken.tsv"; byte[] bytes = { 0x69, 0x64, 0x0A, 0xC3, 0x28 }; File.WriteAllBytes(path, bytes); var error = Assert.Throws<TableInputException>(() => TableInput.FromFile(path)); Assert.That(error.Diagnostic.Code, Is.EqualTo("InputDecode")); Assert.That(error.Diagnostic.ByteOffset, Is.GreaterThanOrEqualTo(0)); Assert.That(File.ReadAllBytes(path), Is.EqualTo(bytes)); }
        [TestCase("2147483647", TableColumnKind.Int32, true)]
        [TestCase("-2147483648", TableColumnKind.Int32, true)]
        [TestCase("2147483648", TableColumnKind.Int32, false)]
        [TestCase("9223372036854775807", TableColumnKind.Int64, true)]
        [TestCase("-9223372036854775808", TableColumnKind.Int64, true)]
        [TestCase("9223372036854775808", TableColumnKind.Int64, false)]
        [TestCase("1.5", TableColumnKind.Int64, false)]
        [TestCase("invalid", TableColumnKind.Int64, false)]
        [TestCase("", TableColumnKind.Int64, false)]
        [TestCase(" 1", TableColumnKind.Int64, false)]
        public void DeclaredNumericColumnsRejectInvalidValuesRatherThanReturningZero(string value, TableColumnKind kind, bool valid)
        {
            var input = TableInput.FromText("definition", "key\tquantity\nx\t" + value);
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { input }, _root + "/Resources/Tables", false,
                schemas: new[] { new TableSchema("definition", new TableColumnRule("quantity", kind)) }));
            Assert.That(plan.IsValid, Is.EqualTo(valid)); Assert.That(input.Text, Does.EndWith(value));
            if (!valid) Assert.That(plan.Diagnostics.Any(d => d.Code == "SchemaValue" && d.Row == 2 && d.Header == "quantity"), Is.True);
        }
        [Test]
        public void RequiredColumnsUniquenessAndRangesAreGameSchemaRatherThanRuntimeDefaults()
        {
            var input = TableInput.FromText("definition", "code\tquantity\nx\t-1\nx\t3");
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { input }, _root + "/Resources/Tables", false, schemas: new[] {
                new TableSchema("definition", new TableColumnRule("code", unique:true), new TableColumnRule("quantity", TableColumnKind.Int64, minimum:0), new TableColumnRule("missing")) }));
            Assert.That(plan.IsValid, Is.False); Assert.That(plan.Diagnostics.Count(d => d.Code == "SchemaValue"), Is.EqualTo(2)); Assert.That(plan.Diagnostics.Any(d => d.Code == "MissingColumn"), Is.True);
        }
        private TableBuildPlan UniqueCodePlan(string text, bool required) => TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("definition", text) }, _root + "/Resources/Tables", false,
            schemas: new[] { new TableSchema("definition", new TableColumnRule("code", required: required, unique: true)) }));
        [Test]
        public void OptionalUniqueColumnAcceptsRepeatedEmptyCells()
        {
            var plan = UniqueCodePlan("id\tcode\n1\t\n2\t\n3\tx\n4\t", false);
            Assert.That(plan.Diagnostics.Where(d => d.Code == "SchemaValue"), Is.Empty, string.Join("\n", plan.Diagnostics)); Assert.That(plan.IsValid, Is.True, string.Join("\n", plan.Diagnostics));
        }
        [Test]
        public void OptionalUniqueColumnStillRejectsRepeatedValues()
        {
            var plan = UniqueCodePlan("id\tcode\n1\t\n2\tx\n3\t\n4\tx", false);
            var error = plan.Diagnostics.Single(d => d.Code == "SchemaValue");
            Assert.That(plan.IsValid, Is.False); Assert.That(error.Row, Is.EqualTo(5)); Assert.That(error.Reason, Does.Contain("Duplicate"));
        }
        [Test]
        public void RequiredUniqueColumnReportsEveryEmptyCellAsMissing()
        {
            var plan = UniqueCodePlan("id\tcode\n1\t\n2\t", true);
            var errors = plan.Diagnostics.Where(d => d.Code == "SchemaValue").ToArray();
            Assert.That(errors.Select(d => d.Row), Is.EqualTo(new[] { 2, 3 })); Assert.That(errors.All(d => d.Reason == "Required cell is empty."), Is.True);
        }
    }
}
