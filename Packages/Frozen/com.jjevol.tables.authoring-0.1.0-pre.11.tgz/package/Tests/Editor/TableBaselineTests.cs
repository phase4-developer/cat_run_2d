using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TableBaselineTests
    {
        private const string Table = "key\tlabel\nx\told\n";
        private string _root, _output;
        private string Output(string table) => _output + "/" + table + ".txt";
        private static TableInput A(string text = Table) => TableInput.FromText("a", text);
        private static TableInput B() => TableInput.FromText("b", Table);
        private TableBuildPlan Plan(params TableInput[] inputs) => TableBuilder.Plan(new TableBuildRequest(inputs, _output, false));
        private void Apply(params TableInput[] inputs) => TableBuilder.Prepare(Plan(inputs)).Apply();
        private string Manifest => TableBuilder.GetManifestPath(_output);
        private static string Sha(byte[] value) { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(value)).Replace("-", "").ToLowerInvariant(); }
        private static void ToCrlf(string path)
        { File.WriteAllBytes(path, Encoding.UTF8.GetBytes(Encoding.UTF8.GetString(File.ReadAllBytes(path)).Replace("\r\n", "\n").Replace("\n", "\r\n"))); }
        private void Accept() => TableBuilder.AcceptCurrentFiles(_output, TableBuilder.GetFileDifferences(_output));

        [SetUp] public void Setup()
        {
            _root = "Assets/JJEvolStepTableBaseline_" + Guid.NewGuid().ToString("N"); _output = _root + "/Resources/Tables";
            TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null; TableAuthoringOptions.ValidateTables = null;
        }
        [TearDown] public void Cleanup()
        {
            TableQaFailureEvidence.Capture(_root, _output);
            PipelineValidation.ForgetFixtureMetadata(_root); AssetDatabase.Refresh(); if (AssetDatabase.IsValidFolder(_root)) AssetDatabase.DeleteAsset(_root);
            TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null;
        }

        [Test] public void ManifestRecordedFromLfFilesStaysValidUnchanged()
        {
            Apply(A(), B());
            byte[] before = File.ReadAllBytes(Manifest); string recorded = Encoding.UTF8.GetString(before);
            // The exact-byte hashes of the previous format are what the comparison still finds.
            foreach (string path in new[] { Output("a"), Output("a") + ".meta", Output("b"), Output("b") + ".meta" }) Assert.That(recorded, Does.Contain(Sha(File.ReadAllBytes(path))));
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.Ready));
            var prepared = TableBuilder.Prepare(Plan(A(), B()));
            Assert.That(prepared.IsNoOp, Is.True); prepared.Apply();
            Assert.That(File.ReadAllBytes(Manifest), Is.EqualTo(before));
        }
        [Test] public void EncryptedRecordOfCrlfPlaintextStaysValidUnchanged()
        {
            TableAuthoringOptions.EncryptBytes = bytes => bytes.Reverse().ToArray(); TableRuntimeOptions.DecryptBytes = bytes => bytes.Reverse().ToArray();
            string plain = "key\tlabel\r\nx\told\r\n";
            TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(new[] { A(plain) }, _output, true))).Apply();
            // Earlier records held the exact plaintext hash, although the Base64 file itself has no CR.
            string normalized = Sha(Encoding.UTF8.GetBytes(plain.Replace("\r\n", "\n"))), exact = Sha(Encoding.UTF8.GetBytes(plain));
            string manifest = File.ReadAllText(Manifest); Assert.That(manifest, Does.Contain(normalized));
            File.WriteAllText(Manifest, manifest.Replace(normalized, exact), new UTF8Encoding(false));
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.Ready));
            var other = TableBuilder.Plan(new TableBuildRequest(new[] { B() }, _output, true));
            Assert.That(other.IsValid, Is.True, string.Join("\n", other.Diagnostics));
        }
        [Test] public void CrlfConversionOfOutputsDoesNotBlockAndStaysUnchanged()
        {
            Apply(A(), B());
            foreach (string path in new[] { Output("a"), Output("a") + ".meta", Output("b"), Output("b") + ".meta" }) ToCrlf(path);
            byte[] converted = File.ReadAllBytes(Output("a"));
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.Ready));
            Assert.That(TableBuilder.GetFileDifferences(_output), Is.Empty);
            var selected = Plan(A()); // b stays outside the selection and is read as applied context.
            Assert.That(selected.IsValid, Is.True, string.Join("\n", selected.Diagnostics));
            Assert.That(selected.Changes.Single().Action, Is.EqualTo(TableOutputAction.Unchanged));
            TableBuilder.Prepare(selected).Apply();
            Assert.That(File.ReadAllBytes(Output("a")), Is.EqualTo(converted));
        }
        [Test] public void LfConversionOfACrlfOutputDoesNotBlock()
        {
            Apply(A("key\tlabel\r\nx\told\r\n"), B());
            string text = Encoding.UTF8.GetString(File.ReadAllBytes(Output("a")));
            File.WriteAllBytes(Output("a"), Encoding.UTF8.GetBytes(text.Replace("\r\n", "\n")));
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.Ready));
            var other = Plan(B()); Assert.That(other.IsValid, Is.True, string.Join("\n", other.Diagnostics));
        }
        [Test] public void AContentChangeIsStillAConflictAfterNormalisation()
        {
            Apply(A()); File.WriteAllText(Output("a"), Table.Replace("old", "edited"));
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.RecoveryRequired));
            Assert.That(Plan(A()).Diagnostics.Any(d => d.Code == "ManagedConflict"), Is.True);
        }
        [Test] public void EveryBlockingMessageNamesTheFileAndTheReason()
        {
            Apply(A()); File.AppendAllText(Output("a"), "y\tedited\n");
            string file = Output("a");
            Assert.That(TableBuilder.GetStatus(_output).Reason, Does.Contain(file).And.Contain("내용"));
            var plan = Plan(A());
            Assert.That(plan.Diagnostics.Single(d => d.Code == "ManagedConflict").Reason, Does.Contain(file).And.Contain("내용"));
            Assert.That(Assert.Throws<InvalidDataException>(() => TableBuilder.Prepare(plan)).Message, Does.Contain(file));
            // PlayMode logs the same text; its callback needs an actual mode change.
            var guard = (IPreprocessBuildWithReport)Activator.CreateInstance(typeof(TableBuilder).Assembly.GetType("jjevol.TableBuildGuard", true));
            Assert.That(Assert.Throws<BuildFailedException>(() => guard.OnPreprocessBuild(null)).Message, Does.Contain(file).And.Contain("내용").And.Contain("새 기준으로 인정"));
        }
        [Test] public void MetaAndGuidChangesAreNamedSeparately()
        {
            Apply(A(), B());
            byte[] valid = File.ReadAllBytes(Output("b") + ".meta");
            File.AppendAllText(Output("a") + ".meta", "# changed\n");
            File.WriteAllText(Output("b") + ".meta", File.ReadAllText(Output("b") + ".meta").Replace("guid: ", "guid: 0"));
            try
            {
                var differences = TableBuilder.GetFileDifferences(_output);
                Assert.That(differences.Select(d => d.Path), Is.EqualTo(new[] { Output("a") + ".meta", Output("b") + ".meta" }));
                Assert.That(differences[0].Reason, Does.Contain(".meta")); Assert.That(differences[0].CanAccept, Is.True);
                Assert.That(differences[1].Reason, Does.Contain("GUID")); Assert.That(differences[1].CanAccept, Is.False, "A 33-character GUID is not valid.");
            }
            finally { File.WriteAllBytes(Output("b") + ".meta", valid); } // Unity must not import the invalid meta during cleanup.
        }
        [Test] public void AcceptingRewritesOnlyTheRecordAndUnblocks()
        {
            Apply(A(), B());
            File.WriteAllText(Output("a"), Table.Replace("old", "edited"), new UTF8Encoding(false)); byte[] file = File.ReadAllBytes(Output("a")), other = File.ReadAllBytes(Output("b"));
            var differences = TableBuilder.GetFileDifferences(_output);
            Assert.That(differences.Single().Path, Is.EqualTo(Output("a"))); Assert.That(differences.Single().CanAccept, Is.True);
            TableBuilder.AcceptCurrentFiles(_output, differences);
            Assert.That(File.ReadAllBytes(Output("a")), Is.EqualTo(file)); Assert.That(File.ReadAllBytes(Output("b")), Is.EqualTo(other));
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.Ready)); Assert.That(TableBuilder.GetFileDifferences(_output), Is.Empty);
            // The accepted file is the new applied context, and the unchanged source still wins on its next build.
            var context = Plan(B()); Assert.That(context.IsValid, Is.True, string.Join("\n", context.Diagnostics));
            var rebuild = Plan(A()); Assert.That(rebuild.IsValid, Is.True, string.Join("\n", rebuild.Diagnostics));
            Assert.That(rebuild.Changes.Single().Action, Is.EqualTo(TableOutputAction.Update));
        }
        [Test] public void AMissingOutputLeavesTheRecordAndIsCreatedByTheNextBuild()
        {
            Apply(A(), B()); File.Delete(Output("a")); File.Delete(Output("a") + ".meta");
            Assert.That(TableBuilder.GetFileDifferences(_output).All(d => d.CanAccept), Is.True);
            Accept();
            Assert.That(TableBuilder.GetManagedNames(_output), Is.EqualTo(new[] { "b" }));
            Assert.That(Plan(A()).Changes.Single().Action, Is.EqualTo(TableOutputAction.Create));
        }
        [Test] public void AnUnreadableFileCannotBeAccepted()
        {
            Apply(A()); File.WriteAllText(Output("a"), "key\tKEY\nragged\tx\n");
            byte[] manifest = File.ReadAllBytes(Manifest);
            Assert.That(TableBuilder.GetFileDifferences(_output).Single().CanAccept, Is.False);
            Assert.Throws<InvalidOperationException>(Accept);
            Assert.That(File.ReadAllBytes(Manifest), Is.EqualTo(manifest));
        }
        [Test] public void AMissingMetaBesideAnExistingFileCannotBeAccepted()
        {
            Apply(A()); File.Delete(Output("a") + ".meta");
            Assert.That(TableBuilder.GetFileDifferences(_output).Single().CanAccept, Is.False);
        }
        [Test] public void FilesChangedAfterTheReviewAreRefused()
        {
            Apply(A()); File.WriteAllText(Output("a"), Table.Replace("old", "first"));
            var reviewed = TableBuilder.GetFileDifferences(_output); byte[] manifest = File.ReadAllBytes(Manifest);
            File.WriteAllText(Output("a"), Table.Replace("old", "second"));
            Assert.Throws<IOException>(() => TableBuilder.AcceptCurrentFiles(_output, reviewed));
            Assert.That(File.ReadAllBytes(Manifest), Is.EqualTo(manifest));
        }
        [Test] public void NothingIsAcceptedWhileAPendingJournalNeedsRecovery()
        {
            Apply(A()); File.WriteAllText(Output("a"), Table.Replace("old", "edited"));
            var reviewed = TableBuilder.GetFileDifferences(_output); byte[] manifest = File.ReadAllBytes(Manifest);
            File.WriteAllText(Manifest + ".pending", "{}");
            try
            {
                Assert.That(TableBuilder.GetFileDifferences(_output), Is.Empty);
                Assert.Throws<InvalidOperationException>(() => TableBuilder.AcceptCurrentFiles(_output, reviewed));
                Assert.That(File.ReadAllBytes(Manifest), Is.EqualTo(manifest));
            }
            finally { File.Delete(Manifest + ".pending"); }
        }
        [Test] public void WindowOffersTheActionOnlyForADifferenceWithoutAPendingJournal()
        {
            Apply(A()); File.WriteAllText(Output("a"), Table.Replace("old", "edited"));
            var window = ScriptableObject.CreateInstance<CreateTable>();
            const BindingFlags Fields = BindingFlags.Instance | BindingFlags.NonPublic;
            int Offered()
            {
                typeof(CreateTable).GetMethod("RefreshRecordedStatus", Fields).Invoke(window, null);
                return ((IReadOnlyList<TableFileDifference>)typeof(CreateTable).GetField("_differences", Fields).GetValue(window)).Count;
            }
            try
            {
                typeof(CreateTable).GetField("savePath", Fields).SetValue(window, _output);
                Assert.That(Offered(), Is.EqualTo(1));
                File.WriteAllText(Manifest + ".pending", "{}");
                Assert.That(Offered(), Is.EqualTo(0));
            }
            finally { File.Delete(Manifest + ".pending"); UnityEngine.Object.DestroyImmediate(window); }
        }
    }
}
