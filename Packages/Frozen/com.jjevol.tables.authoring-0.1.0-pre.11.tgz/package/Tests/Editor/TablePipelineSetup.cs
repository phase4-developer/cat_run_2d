using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TablePipelineSetup : IPrebuildSetup, IPostBuildCleanup
    {
        public void Setup()
        {
            string id=Guid.NewGuid().ToString("N");string root="Assets/JJEvolStep8Pipeline_"+id;
            string input=root+"/TSV";string resource="Step8Pipeline_"+id;
            SessionState.SetString("Step8PipelineRoot",root);SessionState.SetString("Step8PipelineResource",resource);
            Directory.CreateDirectory(input);
            File.WriteAllText(input+"/definition.tsv",PipelineValidation.Definition);
            File.WriteAllText(input+"/usage.tsv",PipelineValidation.Usage);
            TableAuthoringOptions.EncryptBytes=LegacyFixture.Encrypt;TableRuntimeOptions.DecryptBytes=LegacyFixture.Decrypt;
            TableBuilder.Build(input,root+"/Resources/"+resource+"/Plain",false,PipelineValidation.Validate);
            string encrypted=root+"/Resources/"+resource+"/Encrypted";
            TableBuilder.Build(input,encrypted,true,PipelineValidation.Validate);
            File.WriteAllText(input+"/definition.tsv",PipelineValidation.Definition.Replace("fixture","modified"));
            TableBuilder.Build(input,encrypted,true,PipelineValidation.Validate);
            // Independent direct legacy-encoder output verifies the reverse input direction to Table Core.
            File.WriteAllText(encrypted+"/direct_legacy.txt",Convert.ToBase64String(LegacyFixture.Encrypt(Encoding.UTF8.GetBytes(PipelineValidation.Definition))),Encoding.UTF8);
            AssetDatabase.Refresh();
            TableAuthoringOptions.EncryptBytes=null;TableRuntimeOptions.DecryptBytes=null;
        }
        public void Cleanup()
        {
            string root=SessionState.GetString("Step8PipelineRoot","");
            if(root.StartsWith("Assets/JJEvolStep8Pipeline_") && AssetDatabase.IsValidFolder(root))
            {
                if(!string.Equals(Path.GetDirectoryName(Path.GetFullPath(root)),Path.GetFullPath(Application.dataPath),StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Unsafe fixture cleanup");
                PipelineValidation.ForgetFixtureMetadata(root);AssetDatabase.DeleteAsset(root);
            }
            SessionState.EraseString("Step8PipelineRoot");SessionState.EraseString("Step8PipelineResource");
        }
    }
}
