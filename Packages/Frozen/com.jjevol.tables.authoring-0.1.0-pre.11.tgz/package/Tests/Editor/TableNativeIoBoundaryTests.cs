using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tables.Authoring.Tests
{
    [UnityPlatform(RuntimePlatform.WindowsEditor)]
    public sealed class TableNativeIoBoundaryTests
    {
        private string _root, _output;
        private Func<byte[], byte[]> _encrypt, _decrypt;
        private Action<IReadOnlyList<TableBuildInput>> _validator;
        private string _codecVersion, _validationVersion;

        [SetUp]
        public void SetUp()
        {
            _root = "Assets/JJEvolStepAE1IO_" + Guid.NewGuid().ToString("N");
            _output = _root + "/Resources/Tables";
            Assert.That(Directory.Exists(_root), Is.False, "Every run requires a new synthetic fixture.");
            _encrypt = TableAuthoringOptions.EncryptBytes;
            _decrypt = TableRuntimeOptions.DecryptBytes;
            _validator = TableAuthoringOptions.ValidateTables;
            _codecVersion = TableAuthoringOptions.CodecProfileVersion;
            _validationVersion = TableAuthoringOptions.ValidationVersion;
            TableAuthoringOptions.EncryptBytes = null;
            TableRuntimeOptions.DecryptBytes = null;
            TableAuthoringOptions.ValidateTables = null;
            TableAuthoringOptions.CodecProfileVersion = "ae1-io:plain";
            TableAuthoringOptions.ValidationVersion = "ae1-io:v1";
        }

        [TearDown]
        public void TearDown()
        {
            TableAuthoringOptions.EncryptBytes = _encrypt;
            TableRuntimeOptions.DecryptBytes = _decrypt;
            TableAuthoringOptions.ValidateTables = _validator;
            TableAuthoringOptions.CodecProfileVersion = _codecVersion;
            TableAuthoringOptions.ValidationVersion = _validationVersion;
            // Failure evidence is opt-in and goes outside Assets, so a failed test leaves nothing for the Host to import.
            TableQaFailureEvidence.Capture(_root, _output);
            string full = Path.GetFullPath(_root);
            if (Path.GetDirectoryName(full) != Path.GetFullPath(Application.dataPath) ||
                !Path.GetFileName(full).StartsWith("JJEvolStepAE1IO_", StringComparison.Ordinal))
                throw new InvalidOperationException("Unsafe AE1 fixture cleanup.");
            PipelineValidation.ForgetFixtureMetadata(_root);
            AssetDatabase.Refresh();
            if (AssetDatabase.IsValidFolder(_root)) AssetDatabase.DeleteAsset(_root);
            if (Directory.Exists(full)) Directory.Delete(full, true);
            if (File.Exists(full + ".meta")) File.Delete(full + ".meta");
        }

        private static TableInput Input(string name, string value = "old")
            => TableInput.FromText(name, "key\tlabel\nx\t" + value);

        private TableBuildPlan Plan(params TableInput[] inputs)
            => TableBuilder.Plan(new TableBuildRequest(inputs, _output, false));

        private TableBuildResult Apply(params TableInput[] inputs)
            => TableBuilder.Prepare(Plan(inputs)).Apply();

        private static void WrapWriter(TablePreparedBuild prepared, Func<Action<string, byte[]>, Action<string, byte[]>> wrap)
        {
            var field = typeof(TablePreparedBuild).GetField("WriteFile", BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.That(field, Is.Not.Null);
            field.SetValue(prepared, wrap((Action<string, byte[]>)field.GetValue(prepared)));
        }

        private Dictionary<string, byte[]> Snapshot()
        {
            var result = Directory.GetFiles(_output).ToDictionary(p => Path.GetFullPath(p), File.ReadAllBytes);
            string manifest = TableBuilder.GetManifestPath(_output);
            if (File.Exists(manifest)) result.Add(manifest, File.ReadAllBytes(manifest));
            return result;
        }

        private Dictionary<string, byte[]> RecoverySnapshot()
        {
            string manifest = TableBuilder.GetManifestPath(_output);
            string project = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string gate = Path.Combine(project, "Library", "JJEvol", "TableAuthoring", "Locks", Path.GetFileName(manifest) + ".lock");
            var files = new[] { manifest, gate, manifest + ".pending" }.Where(File.Exists).ToList();
            string journalRoot = Path.Combine(project, "Library", "JJEvol", "TableAuthoring", Path.GetFileNameWithoutExtension(manifest));
            if (Directory.Exists(journalRoot)) files.AddRange(Directory.GetFiles(journalRoot, "*", SearchOption.AllDirectories));
            return files.ToDictionary(Path.GetFullPath, File.ReadAllBytes);
        }

        private static void AssertSameFiles(Dictionary<string, byte[]> actual, Dictionary<string, byte[]> before)
        {
            Assert.That(actual.Keys, Is.EquivalentTo(before.Keys));
            foreach (var pair in before) Assert.That(actual[pair.Key], Is.EqualTo(pair.Value), pair.Key);
        }

        private void AssertRestored(TablePreparedBuild prepared, Dictionary<string, byte[]> before)
        {
            Assert.That(prepared.State, Is.EqualTo(TableBuildState.Restored));
            Assert.That(Snapshot().Keys, Is.EquivalentTo(before.Keys));
            foreach (var pair in before) Assert.That(File.ReadAllBytes(pair.Key), Is.EqualTo(pair.Value), pair.Key);
            string manifest = TableBuilder.GetManifestPath(_output);
            Assert.That(File.Exists(manifest + ".pending"), Is.False);
            Assert.That(TableBuilder.Recover(_output), Is.True);
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.Ready));
        }

        private static void LogIo(string boundary, IOException error)
        {
            Exception native = error;
            while (native.InnerException != null) native = native.InnerException;
            TestContext.Progress.WriteLine("[AE1 Table IO] " + boundary + ": " + native.GetType().Name +
                ", HRESULT 0x" + native.HResult.ToString("X8") + "; only 0x80070497 waits for the same replacement, anything else is not repeated.");
        }

        [Test]
        public void CreateAndOneNativeReplacementPreserveTheTextAssetGuid()
        {
            Assert.That(Apply(Input("a")).State, Is.EqualTo(TableBuildState.Ready));
            string path = _output + "/a.txt";
            byte[] meta = File.ReadAllBytes(path + ".meta");
            string guid = AssetDatabase.AssetPathToGUID(path);
            Assert.That(guid, Does.Match("^[0-9a-fA-F]{32}$"));
            var prepared = TableBuilder.Prepare(Plan(Input("a", "new")));
            int replacements = 0;
            WrapWriter(prepared, original => (destination, bytes) =>
            {
                if (Path.GetFileName(destination) == "a.txt")
                {
                    Assert.That(File.Exists(destination), Is.True);
                    replacements++;
                }
                original(destination, bytes);
            });
            Assert.That(prepared.Apply().State, Is.EqualTo(TableBuildState.Ready));
            Assert.That(replacements, Is.EqualTo(1));
            Assert.That(File.ReadAllText(path), Does.EndWith("new"));
            Assert.That(File.ReadAllBytes(path + ".meta"), Is.EqualTo(meta));
            Assert.That(AssetDatabase.AssetPathToGUID(path), Is.EqualTo(guid));
            Assert.That(File.Exists(prepared.Plan.ManifestPath + ".pending"), Is.False);
            Assert.That(TableBuilder.Recover(_output), Is.True);
        }

        [Test]
        public void ReadSharedLockReachesNativeReplacementAndPreservesTheOriginalGeneration()
        {
            Apply(Input("a"));
            var before = Snapshot();
            var prepared = TableBuilder.Prepare(Plan(Input("a", "new")));
            int attempts = 0;
            WrapWriter(prepared, original => (path, bytes) => { attempts++; original(path, bytes); });
            IOException error;
            // Read access keeps freshness/hash checks possible while Windows denies replacement/delete.
            using (var locked = new FileStream(_output + "/a.txt", FileMode.Open, FileAccess.Read, FileShare.Read))
                error = Assert.Throws<IOException>(() => prepared.Apply());
            Assert.That(attempts, Is.EqualTo(1), "Failure must reach the production writer, not an earlier freshness read.");
            Assert.That(error.Message, Does.Contain("No fallback was attempted."));
            LogIo("read-shared native replace", error);
            AssertRestored(prepared, before);
        }

        [Test]
        public void SecondReadSharedLockRestoresTheFirstReplacementBeforeAFreshApply()
        {
            Apply(Input("a"), Input("b"));
            var before = Snapshot();
            var prepared = TableBuilder.Prepare(Plan(Input("a", "new"), Input("b", "new")));
            int firstWrites = 0, secondAttempts = 0;
            WrapWriter(prepared, original => (path, bytes) =>
            {
                if (Path.GetFileName(path) == "a.txt") firstWrites++;
                if (Path.GetFileName(path) == "b.txt") secondAttempts++;
                original(path, bytes);
            });
            IOException error;
            using (var locked = new FileStream(_output + "/b.txt", FileMode.Open, FileAccess.Read, FileShare.Read))
                error = Assert.Throws<IOException>(() => prepared.Apply());
            Assert.That(secondAttempts, Is.EqualTo(1));
            Assert.That(firstWrites, Is.EqualTo(2), "One real replacement followed by one verified rollback replacement.");
            LogIo("second native replace", error);
            AssertRestored(prepared, before);
            Assert.That(Apply(Input("a", "new"), Input("b", "new")).State, Is.EqualTo(TableBuildState.Ready));
            Assert.That(File.ReadAllText(_output + "/a.txt"), Does.EndWith("new"));
            Assert.That(File.ReadAllText(_output + "/b.txt"), Does.EndWith("new"));
        }

        [Test]
        public void FailureAfterNewTextCreationRemovesOnlyItsOwnNewFiles()
        {
            Directory.CreateDirectory(_output);
            string sentinel = _output + "/user-owned.keep";
            File.WriteAllText(sentinel, "unchanged synthetic user file");
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            var before = Snapshot();
            var prepared = TableBuilder.Prepare(Plan(Input("a")));
            int created = 0;
            WrapWriter(prepared, original => (path, bytes) =>
            {
                if (Path.GetFileName(path) == "a.txt.meta") throw new IOException("AE1 injected stop after native text creation.");
                original(path, bytes);
                if (Path.GetFileName(path) == "a.txt") created++;
            });
            Assert.Throws<IOException>(() => prepared.Apply());
            Assert.That(created, Is.EqualTo(1));
            AssertRestored(prepared, before);
            Assert.That(File.Exists(prepared.Plan.ManifestPath), Is.False);
            Assert.That(File.Exists(_output + "/a.txt"), Is.False);
            Assert.That(File.Exists(_output + "/a.txt.meta"), Is.False);
        }

        [TestCase(259)]
        [TestCase(260)]
        public void LongMetaPathCommitsTheWholeGenerationOrIsRejectedBeforeApply(int metaPathLength)
        {
            Apply(Input("a"));
            var before = Snapshot();
            int nameLength = metaPathLength - Path.GetFullPath(_output).Length - 1 - ".txt.meta".Length;
            Assert.That(nameLength, Is.InRange(1, 240), "Use the current short AE1 Host; do not relocate old failure evidence.");
            string name = new string('p', nameLength);
            string path = _output + "/" + name + ".txt";
            Assert.That(Path.GetFullPath(path + ".meta").Length, Is.EqualTo(metaPathLength));
            var recoveryBefore = RecoverySnapshot();
            if (metaPathLength == 260)
            {
                var error = Assert.Throws<ArgumentException>(() => Plan(Input("a"), Input(name, "long")));
                Assert.That(error.Message, Does.Contain("must be below 260"));
                Assert.Throws<ArgumentException>(() => TableBuilder.Plan(new TableBuildRequest(
                    new[] { Input("a"), Input(name, "long") }, _output, false,
                    operation: TableBuildOperation.Full, completeCatalog: true)));
                // An acquired but unselected long name must not restrict a short no-op request.
                var selected = TableBuilder.Plan(new TableBuildRequest(new[] { Input("a"), Input(name, "long") },
                    _output, false, selected: new[] { "a" }));
                Assert.That(selected.IsValid, Is.True);
                Assert.That(TableBuilder.Prepare(selected).Apply().NoOp, Is.True);
                AssertSameFiles(Snapshot(), before);
                AssertSameFiles(RecoverySnapshot(), recoveryBefore);

                const string enumName = "GameConsumeType";
                string codeParent = _root + "/Game";
                int padding = 260 - Path.GetFullPath(codeParent).Length - 2 - (enumName + "Extensions.Generated.cs.meta").Length;
                Assert.That(padding, Is.InRange(1, 240));
                string code = codeParent + "/" + new string('c', padding);
                Assert.That(Path.GetFullPath(Path.Combine(code, enumName + "Extensions.Generated.cs.meta")).Length, Is.EqualTo(260));
                Assert.That(Directory.Exists(codeParent), Is.False);
                string assembly = codeParent + "/Ae1Boundary.asmdef";
                EditorApplication.LockReloadAssemblies();
                AssetDatabase.DisallowAutoRefresh();
                AssetDatabase.StartAssetEditing();
                try
                {
                    // Prepare a valid game boundary without importing an asmdef or generating C#.
                    Directory.CreateDirectory(codeParent);
                    File.WriteAllText(assembly, "{\"name\":\"AE1.Boundary.G" + Guid.NewGuid().ToString("N") +
                        "\",\"references\":[\"JJEvol.Economy.Runtime\"]}");
                    byte[] assemblyBefore = File.ReadAllBytes(assembly);
                    var outputsBeforeCodePlan = Snapshot();
                    var recoveryBeforeCodePlan = RecoverySnapshot();
                    var settings = new ConsumeTypesGenerationSettings(code, "AE1.Fixture", enumName);
                    var definition = TableInput.FromText("ConsumeTypes", "typeId\tcodeName\n7\tCoins");
                    var codeError = Assert.Throws<ArgumentException>(() => TableBuilder.Plan(new TableBuildRequest(new[] { definition },
                        _output, false, consumeTypes: settings)));
                    Assert.That(codeError.Message, Does.Contain("must be below 260"));
                    Assert.That(File.ReadAllBytes(assembly), Is.EqualTo(assemblyBefore));
                    Assert.That(Directory.Exists(code), Is.False);
                    AssertSameFiles(Snapshot(), outputsBeforeCodePlan);
                    AssertSameFiles(RecoverySnapshot(), recoveryBeforeCodePlan);
                }
                finally
                {
                    // Remove only this case's raw boundary before imports/reloads are allowed again.
                    try
                    {
                        string full = Path.GetFullPath(codeParent);
                        if (Path.GetDirectoryName(full) != Path.GetFullPath(_root) || Path.GetFileName(full) != "Game")
                            throw new InvalidOperationException("Unsafe raw game boundary cleanup.");
                        if (File.Exists(assembly)) File.Delete(assembly);
                        if (File.Exists(assembly + ".meta")) File.Delete(assembly + ".meta");
                        if (Directory.Exists(codeParent) && !Directory.EnumerateFileSystemEntries(codeParent).Any()) Directory.Delete(codeParent);
                    }
                    finally
                    {
                        AssetDatabase.StopAssetEditing();
                        AssetDatabase.AllowAutoRefresh();
                        EditorApplication.UnlockReloadAssemblies();
                    }
                }

                AssertSameFiles(Snapshot(), before);
                AssertSameFiles(RecoverySnapshot(), recoveryBefore);
                Assert.That(File.Exists(TableBuilder.GetManifestPath(_output) + ".pending"), Is.False);
                TestContext.Progress.WriteLine("[AE1 Table IO] Selected 260-character meta paths rejected before Apply; original outputs, metadata and journals unchanged.");
                return;
            }

            var plan = Plan(Input("a"), Input(name, "long"));
            Assert.That(plan.IsValid, Is.True);
            var prepared = TableBuilder.Prepare(plan);
            Assert.That(prepared.Apply().State, Is.EqualTo(TableBuildState.Ready), "A supported 259-character meta path must complete; failure is not accepted as a passing boundary result.");
            Assert.That(prepared.State, Is.EqualTo(TableBuildState.Ready));
            Assert.That(File.ReadAllText(path), Does.EndWith("long"));
            Assert.That(AssetDatabase.AssetPathToGUID(path), Does.Match("^[0-9a-fA-F]{32}$"));
            foreach (var pair in before.Where(p => p.Key != plan.ManifestPath))
                Assert.That(File.ReadAllBytes(pair.Key), Is.EqualTo(pair.Value));
            Assert.That(File.Exists(plan.ManifestPath + ".pending"), Is.False);
            Assert.That(TableBuilder.Recover(_output), Is.True);
            TestContext.Progress.WriteLine("[AE1 Table IO] Complete long-path generation verified at meta path length " + metaPathLength + "; this is one Host observation, not general OS support.");
        }
    }
}
