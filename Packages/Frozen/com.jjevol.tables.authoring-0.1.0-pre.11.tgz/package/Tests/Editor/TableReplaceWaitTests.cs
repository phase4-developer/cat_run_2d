using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;

namespace jjevol.Tables.Authoring.Tests
{
    // A held destination cannot be produced on demand from user mode, so these cases drive the
    // replacement step with a scripted File.Replace and record each requested wait instead of sleeping.
    public sealed class TableReplaceWaitTests
    {
        private const int Busy = unchecked((int)0x80070497), SharingViolation = unchecked((int)0x80070020);
        private static readonly MethodInfo ReplaceStep = typeof(TableBuilder).Assembly.GetType("jjevol.TableFiles", true)
            .GetMethod("Replace", BindingFlags.Static | BindingFlags.NonPublic);
        private string directory, temp, path;
        private List<int> waits;
        private int calls;

        [SetUp] public void Setup()
        {
            directory = Path.Combine(Path.GetTempPath(), "JJEvolTableReplaceWait_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            temp = Path.Combine(directory, "next.tmp"); path = Path.Combine(directory, "a.txt");
            File.WriteAllText(temp, "new"); File.WriteAllText(path, "old");
            waits = new List<int>(); calls = 0;
        }
        [TearDown] public void Cleanup() { if (Directory.Exists(directory)) Directory.Delete(directory, true); }

        private void Run(Action<string, string> replace)
        {
            try { ReplaceStep.Invoke(null, new object[] { temp, path, replace, (Action<int>)waits.Add }); }
            catch (TargetInvocationException e) { throw e.InnerException; }
        }
        private Action<string, string> FailFirst(int failures, int hresult) => (source, destination) =>
        {
            Assert.That(source, Is.EqualTo(temp)); Assert.That(destination, Is.EqualTo(path));
            if (++calls <= failures) throw new IOException("Scripted replacement failure", hresult);
            File.Replace(source, destination, null);
        };

        [Test] public void AHeldDestinationIsReplacedOnceItIsReleased()
        {
            Run(FailFirst(2, Busy));
            Assert.That(calls, Is.EqualTo(3));
            Assert.That(waits, Is.EqualTo(new[] { 10, 20 }));
            Assert.That(File.ReadAllText(path), Is.EqualTo("new")); Assert.That(File.Exists(temp), Is.False);
        }
        [Test] public void ADestinationHeldPastTheBudgetThrowsTheOriginalErrorAndKeepsBothFiles()
        {
            var error = Assert.Throws<IOException>(() => Run(FailFirst(int.MaxValue, Busy)));
            Assert.That(error.HResult, Is.EqualTo(Busy));
            Assert.That(waits.Sum(), Is.EqualTo(2000)); Assert.That(waits.Max(), Is.LessThanOrEqualTo(250));
            Assert.That(calls, Is.EqualTo(waits.Count + 1));
            Assert.That(File.ReadAllText(path), Is.EqualTo("old")); Assert.That(File.ReadAllText(temp), Is.EqualTo("new"));
        }
        [Test] public void ASharingViolationIsNotRepeated()
        {
            var error = Assert.Throws<IOException>(() => Run(FailFirst(1, SharingViolation)));
            Assert.That(error.HResult, Is.EqualTo(SharingViolation));
            Assert.That(calls, Is.EqualTo(1)); Assert.That(waits, Is.Empty);
            Assert.That(File.ReadAllText(path), Is.EqualTo("old"));
        }
        [Test] public void AMissingStagedFileStopsTheWait()
        {
            var error = Assert.Throws<IOException>(() => Run((source, destination) => { calls++; File.Delete(source); throw new IOException("Scripted replacement failure", Busy); }));
            Assert.That(error.HResult, Is.EqualTo(Busy));
            Assert.That(calls, Is.EqualTo(1)); Assert.That(waits, Is.Empty);
            Assert.That(File.ReadAllText(path), Is.EqualTo("old"));
        }
    }
}
