using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;
using jjevol.Samples.MinimalTableFlow;

namespace jjevol.Tables.Authoring.SampleTests
{
    public sealed class MinimalTableFlowRuntimeTests
    {
        private const string Data = "id\tlabel\ttypeId\tquantity\n1001\tAmber token\t7\t4000000001\n1002\tBlue token\t9\t12";
        private sealed class MemorySource : ITableSource
        {
            private readonly string _text;
            public MemorySource(string text = Data) => _text = text;
            public bool RequiresRemoteUpdate => false;
            public bool HasTable(string name) => name == MinimalItemTable.ResourceName;
            public List<TSVRow> Load(string name)
            {
                if (!HasTable(name)) throw new ArgumentException("Unexpected resource path.");
                return TSVRow.FromTsv(_text);
            }
            public Task<List<TSVRow>> LoadAsync(string name) => Task.FromResult(Load(name));
        }
        private sealed class DelayedSource : ITableSource
        {
            public readonly TaskCompletionSource<List<TSVRow>> Completion = new TaskCompletionSource<List<TSVRow>>();
            public bool RequiresRemoteUpdate => false;
            public bool HasTable(string name) => true;
            public List<TSVRow> Load(string name) => throw new NotSupportedException();
            public Task<List<TSVRow>> LoadAsync(string name) => Completion.Task;
        }
        [Test] public void ServiceAndExistingPresentationContractUseExactTypeItemAndInt64Quantity()
        {
            using var session = MinimalTableFlowSession.Open(new MemorySource());
            var data = session.Items.CreateValue(1001);
            Assert.That(data.Quantity, Is.EqualTo(4000000001L));
            Assert.That(data.TypeId, Is.EqualTo(new ConsumeTypeId(7)));
            Assert.That(data.ItemId, Is.EqualTo(1001));
            Assert.That(data.Present(session.Presentation).Name, Is.EqualTo("Amber token"));
            Assert.That(session.Presentation.TryResolve(new ConsumeTypeId(9), 1001, out _), Is.False);
            Assert.That(session.Presentation.TryResolve(new ConsumeTypeId(7), 9999, out _), Is.False);
            Assert.Throws<ArgumentOutOfRangeException>(() => session.Items.CreateValue(9999));
        }
        [Test] public void SessionsRejectOverlapReleaseTheirDataAndLeaveGameSourceUntouched()
        {
            var gameSource = GameTableSource.Current;
            var path = TableRuntimeOptions.StaticTablePath;
            var decrypt = TableRuntimeOptions.DecryptBytes;
            var session = MinimalTableFlowSession.Open(new MemorySource());
            var oldService = session.Items;
            try { Assert.Throws<InvalidOperationException>(() => MinimalTableFlowSession.Open(new MemorySource())); }
            finally { session.Dispose(); session.Dispose(); }
            Assert.Throws<ObjectDisposedException>(() => oldService.Find(1001));
            using (var restarted = MinimalTableFlowSession.Open(new MemorySource())) Assert.That(restarted.Items.Items.Count, Is.EqualTo(2));
            Assert.Throws<ObjectDisposedException>(() => oldService.Find(1001));
            Assert.That(GameTableSource.Current, Is.SameAs(gameSource));
            Assert.That(TableRuntimeOptions.StaticTablePath, Is.SameAs(path));
            Assert.That(TableRuntimeOptions.DecryptBytes, Is.SameAs(decrypt));
        }
        [Test] public void FailedEmptyLoadReleasesSessionSoItCanBeRetried()
        {
            Assert.Throws<InvalidOperationException>(() => MinimalTableFlowSession.Open(new MemorySource("id\tlabel\ttypeId\tquantity")));
            using var next = MinimalTableFlowSession.Open(new MemorySource());
            Assert.That(next.Items.Find(1002).Quantity, Is.EqualTo(12));
        }
        [Test] public async Task ReleasedTableCannotBeRepopulatedByAnOldAsyncLoad()
        {
            var source = new DelayedSource();
            var table = new MinimalItemTable(source);
            var pending = table.LoadDatasAsync();
            table.ReleaseSampleData();
            source.Completion.SetResult(TSVRow.FromTsv(Data));
            await pending;
            Assert.That(table.Datas, Is.Empty);
        }
    }
}
