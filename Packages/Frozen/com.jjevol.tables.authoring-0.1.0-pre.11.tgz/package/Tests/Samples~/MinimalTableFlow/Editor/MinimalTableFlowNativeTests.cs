using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;
using jjevol.Data;
using jjevol.Samples.MinimalTableFlow;
using jjevol.Samples.MinimalTableFlow.Editor;

namespace jjevol.Tables.Authoring.SampleTests
{
    // Run this fixture alone in the isolated QA Host after BuildImportedSample and a real reload.
    // It deliberately refuses to reset a pre-existing game's global registry.
    public sealed class MinimalTableFlowNativeTests
    {
        private sealed class ObservedSource : ITableSource
        {
            private readonly PackagedTableSource _source = new PackagedTableSource(false);
            public int Loads { get; private set; }
            public bool RequiresRemoteUpdate => false;
            public bool HasTable(string name) => _source.HasTable(name);
            public List<TSVRow> Load(string name) { Loads++; return _source.Load(name); }
            public Task<List<TSVRow>> LoadAsync(string name) { Loads++; return _source.LoadAsync(name); }
        }
        [Test] public void AppliedAndCompiledSampleBootstrapsRepositoryAndPreservesForeignRegistrationOnClose()
        {
            Assert.That(TableRepository.loaded, Is.False, "Use a fresh isolated Host; this fixture never clears unowned registrations.");
            MinimalTableFlowAuthoring.VerifyImportedSample();
            var source = new ObservedSource();
            var table = new MinimalItemTable(source);
            TableRepository.Register(table); // Game startup owns this registration, not the demo session.
            TableRepository.LoadAll();
            try
            {
                Assert.That(TableRepository.loaded, Is.True);
                Assert.That(source.Loads, Is.EqualTo(1));
                var service = new MinimalItemService(table);
                var provider = new MinimalItemPresentationProvider(service);
                var data = service.CreateValue(1001);
                Assert.That(data.TypeId, Is.EqualTo(new ConsumeTypeId(7)));
                Assert.That(data.Quantity, Is.EqualTo(4000000001L));
                Assert.That(data.Present(provider).Name, Is.EqualTo("Amber token"));
                using (var demo = MinimalTableFlowSession.Open()) Assert.That(demo.Items.Find(1002).Label, Is.EqualTo("Blue token"));
                // Disposing a sample session must not call TableRepository.Clear or erase this table.
                Assert.That(TableRepository.loaded, Is.True);
                Assert.That(table.Get(1001).Quantity, Is.EqualTo(4000000001L));
                Assert.That(provider.TryResolve(new ConsumeTypeId(9), 1001, out _), Is.False);
            }
            finally { table.ReleaseSampleData(); }
        }
    }
}
