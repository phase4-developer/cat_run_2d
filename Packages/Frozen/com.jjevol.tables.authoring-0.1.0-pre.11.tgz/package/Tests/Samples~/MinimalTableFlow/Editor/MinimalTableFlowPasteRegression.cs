using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;
using jjevol.Samples.MinimalTableFlow;
using jjevol.Samples.MinimalTableFlow.Editor;

namespace jjevol.Tables.Authoring.SampleTests
{
    // Explicit multi-process QA entry points; never compiled by a normal sample import.
    public static class MinimalTableFlowPasteRegression
    {
        [Serializable] private sealed class LocalProof { public string itemsHash, typesHash; }
        private static string ProofPath => Path.GetFullPath(Path.Combine(Application.dataPath, "../Library/JJEvol/MinimalTableFlow/edited-paste-local-proof.json"));
        public static void BuildEditedPaste()
        {
            var items = MinimalTableFlowAuthoring.ReadItems();
            var types = MinimalTableFlowAuthoring.ReadTypes();
            Directory.CreateDirectory(Path.GetDirectoryName(ProofPath));
            File.WriteAllText(ProofPath, JsonUtility.ToJson(new LocalProof { itemsHash = items.RawHash, typesHash = types.RawHash }));
            string editedItems = items.Text.Replace("Amber token", "Pasted amber token").Replace("4000000001", "4000000002").TrimEnd('\r', '\n') + "\n1003\tGreen token\t11\t3\n";
            string editedTypes = types.Text.TrimEnd('\r', '\n') + "\n11\tGreen\tGreen token\tsample_green\n";
            var plan = MinimalTableFlowAuthoring.CreatePlan(TableInput.FromText("MinimalItems", editedItems), TableInput.FromText("ConsumeTypes", editedTypes),
                MinimalTableFlowAuthoring.OutputDirectory, MinimalTableFlowAuthoring.CodeDirectory);
            var result = MinimalTableFlowAuthoring.ApplyReviewedBuild(TableBuilder.Prepare(plan));
            Assert.That(result.State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            Debug.Log("AE2_EDITED_PASTE_APPLIED_ACTUAL_RELOAD_REQUIRED");
        }
        public static void VerifyEditedPasteAndLocalOriginals()
        {
            MinimalTableFlowAuthoring.VerifyImportedSample();
            var proof = JsonUtility.FromJson<LocalProof>(File.ReadAllText(ProofPath));
            Assert.That(MinimalTableFlowAuthoring.ReadItems().RawHash, Is.EqualTo(proof.itemsHash));
            Assert.That(MinimalTableFlowAuthoring.ReadTypes().RawHash, Is.EqualTo(proof.typesHash));
            var enumType = typeof(MinimalItemRow).Assembly.GetType(MinimalTableFlowAuthoring.GeneratedNamespace + "." + MinimalTableFlowAuthoring.GeneratedEnum, true);
            Assert.That(Enum.GetNames(enumType), Does.Contain("Green"));
            using var session = MinimalTableFlowSession.Open();
            Assert.That(session.Items.Items.Count, Is.EqualTo(3));
            Assert.That(session.Items.CreateValue(1001).Quantity, Is.EqualTo(4000000002L));
            Assert.That(session.Items.CreateValue(1001).Present(session.Presentation).Name, Is.EqualTo("Pasted amber token"));
            Assert.That(session.Items.Find(1003).TypeId, Is.EqualTo(new ConsumeTypeId(11)));
            Debug.Log("AE2_EDITED_PASTE_SEPARATE_PID_VERIFY_PASSED_LOCAL_ORIGINALS_UNCHANGED");
        }
    }
}
