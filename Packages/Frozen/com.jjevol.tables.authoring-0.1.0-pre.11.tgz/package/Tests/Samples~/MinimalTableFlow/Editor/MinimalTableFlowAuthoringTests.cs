using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using jjevol.Samples.MinimalTableFlow;
using jjevol.Samples.MinimalTableFlow.Editor;

namespace jjevol.Tables.Authoring.SampleTests
{
    public sealed class MinimalTableFlowAuthoringTests
    {
        private string _fixture, _output, _code, _namespace;
        [SetUp] public void SetUp()
        {
            string id = Guid.NewGuid().ToString("N");
            _fixture = MinimalTableFlowAuthoring.SampleRoot + "/TestFixtures_" + id;
            _output = _fixture + "/Resources";
            _code = MinimalTableFlowAuthoring.SampleRoot + "/Runtime/PlanCode_" + id;
            _namespace = "jjevol.Samples.Plan" + id;
        }
        [TearDown] public void TearDown()
        {
            // Only the test's own input copy is ever created. Plans/Prepare must not write.
            string expected = Path.GetFullPath(MinimalTableFlowAuthoring.SampleRoot) + Path.DirectorySeparatorChar;
            string full = Path.GetFullPath(_fixture);
            if (!full.StartsWith(expected, StringComparison.OrdinalIgnoreCase) || !Path.GetFileName(full).StartsWith("TestFixtures_", StringComparison.Ordinal))
                throw new InvalidOperationException("Unsafe sample fixture cleanup.");
            if (Directory.Exists(full)) Directory.Delete(full, true);
            if (File.Exists(full + ".meta")) File.Delete(full + ".meta");
        }
        private TableBuildPlan Plan(TableInput items = null, TableInput types = null) => MinimalTableFlowAuthoring.CreatePlan(
            items ?? MinimalTableFlowAuthoring.ReadItems(), types ?? MinimalTableFlowAuthoring.ReadTypes(), _output, _code, _namespace);

        [Test] public void LocalAndPasteProduceTheSameRuntimeDataAndRealGeneratedSourcePreview()
        {
            var local = Plan();
            var paste = Plan(TableInput.FromText("MinimalItems", MinimalTableFlowAuthoring.ReadItems().Text),
                TableInput.FromText("ConsumeTypes", MinimalTableFlowAuthoring.ReadTypes().Text));
            Assert.That(local.IsValid, Is.True, string.Join("\n", local.Diagnostics));
            Assert.That(paste.IsValid, Is.True, string.Join("\n", paste.Diagnostics));
            Assert.That(local.ValidationInputs.Select(input => input.Text), Is.EqualTo(paste.ValidationInputs.Select(input => input.Text)));
            Assert.That(local.ConsumeTypes.EnumSource, Is.EqualTo(paste.ConsumeTypes.EnumSource));
            Assert.That(local.ConsumeTypes.EnumSource, Does.Contain("Amber = 7").And.Contain("Blue = 9"));
            Assert.That(local.Changes.Select(change => change.TableName), Is.EqualTo(new[] { "MinimalItems" }));
            Assert.That(local.ConsumeTypes.Changes.Count, Is.EqualTo(2));
        }
        [Test] public void PrepareKeepsSourceAndOutputsUntouchedAndRequiresCompilation()
        {
            byte[] input = File.ReadAllBytes(MinimalTableFlowAuthoring.SampleRoot + "/Input/MinimalItems.tsv");
            var plan = Plan();
            var prepared = TableBuilder.Prepare(plan);
            Assert.That(prepared.State, Is.EqualTo(TableBuildState.Prepared));
            Assert.That(prepared.RequiresCompilation, Is.True);
            Assert.That(Directory.Exists(_output), Is.False);
            Assert.That(Directory.Exists(_code), Is.False);
            Assert.That(File.Exists(plan.ManifestPath), Is.False);
            Assert.That(File.ReadAllBytes(MinimalTableFlowAuthoring.SampleRoot + "/Input/MinimalItems.tsv"), Is.EqualTo(input));
        }
        [Test] public void EditedPasteReviewsItsOwnRowsAndNewEnumWithoutChangingLocalOriginals()
        {
            var localItems = MinimalTableFlowAuthoring.ReadItems();
            var localTypes = MinimalTableFlowAuthoring.ReadTypes();
            string items = localItems.Text.Replace("Amber token", "Pasted amber token").Replace("4000000001", "4000000002").TrimEnd('\r', '\n') + "\n1003\tGreen token\t11\t3\n";
            string types = localTypes.Text.TrimEnd('\r', '\n') + "\n11\tGreen\tGreen token\tsample_green\n";
            var plan = Plan(TableInput.FromText("MinimalItems", items), TableInput.FromText("ConsumeTypes", types));
            Assert.That(plan.IsValid, Is.True, string.Join("\n", plan.Diagnostics));
            Assert.That(plan.ValidationInputs.Single(input => input.TableName == "MinimalItems").Text, Does.Contain("Pasted amber token").And.Contain("4000000002").And.Contain("1003\tGreen token"));
            Assert.That(plan.ConsumeTypes.EnumSource, Does.Contain("Green = 11"));
            Assert.That(MinimalTableFlowAuthoring.ReadItems().RawHash, Is.EqualTo(localItems.RawHash));
            Assert.That(MinimalTableFlowAuthoring.ReadTypes().RawHash, Is.EqualTo(localTypes.RawHash));
        }
        [Test] public void UndefinedTypeReferenceHasLocatedGameDiagnosticAndCannotPrepare()
        {
            string text = MinimalTableFlowAuthoring.ReadItems().Text.Replace("1001\tAmber token\t7", "1001\tAmber token\t123");
            var plan = Plan(TableInput.FromText("MinimalItems", text));
            var diagnostic = plan.Diagnostics.Single(item => item.Code == "SampleUnknownType");
            Assert.That(diagnostic.Row, Is.EqualTo(2));
            Assert.That(diagnostic.Header, Is.EqualTo("typeId"));
            Assert.That(plan.IsValid, Is.False);
            Assert.Throws<InvalidDataException>(() => TableBuilder.Prepare(plan));
        }
        [TestCase("4000000001", "9223372036854775808")]
        [TestCase("4000000001", "0")]
        public void InvalidQuantityIsRejectedBeforeAnyOutput(string oldValue, string newValue)
        {
            var plan = Plan(TableInput.FromText("MinimalItems", MinimalTableFlowAuthoring.ReadItems().Text.Replace(oldValue, newValue)));
            Assert.That(plan.IsValid, Is.False);
            Assert.That(plan.Diagnostics.Any(item => item.Code == "SchemaValue" && item.Header == "quantity"), Is.True);
            Assert.Throws<InvalidDataException>(() => TableBuilder.Prepare(plan));
            Assert.That(Directory.Exists(_output), Is.False);
        }
        [Test] public void EditingLocalSourceAfterPrepareBlocksApplyInsteadOfUsingUnreviewedData()
        {
            Directory.CreateDirectory(_fixture + "/Input");
            string file = _fixture + "/Input/MinimalItems.tsv";
            File.WriteAllText(file, MinimalTableFlowAuthoring.ReadItems().Text);
            var prepared = TableBuilder.Prepare(Plan(TableInput.FromFile(file)));
            File.AppendAllText(file, "\n1003\tNew token\t7\t5");
            Assert.Throws<IOException>(() => prepared.Apply());
            Assert.That(Directory.Exists(_output), Is.False);
            Assert.That(Directory.Exists(_code), Is.False);
        }
    }
}
