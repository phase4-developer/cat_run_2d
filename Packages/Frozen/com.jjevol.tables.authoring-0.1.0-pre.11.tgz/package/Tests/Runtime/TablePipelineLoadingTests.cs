#if UNITY_EDITOR
using System;
using System.Collections;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;
using jjevol.Data;

namespace jjevol.Tables.Authoring.Tests
{
    [PrebuildSetup("jjevol.Tables.Authoring.Tests.TablePipelineSetup")]
    [PostBuildCleanup("jjevol.Tables.Authoring.Tests.TablePipelineSetup")]
    public sealed class TablePipelineLoadingTests
    {
        string resource;
        static IEnumerator Complete(Task task)
        {
            float end=Time.realtimeSinceStartup+5;
            while(!task.IsCompleted && Time.realtimeSinceStartup<end)yield return null;
            Assert.IsTrue(task.IsCompleted,"Pipeline table loading timed out");
            if(task.IsFaulted)Assert.Fail("Pipeline task failed: "+task.Exception.InnerException.GetType().Name);
        }
        [SetUp]public void Setup()
        {
            resource=SessionState.GetString("Step8PipelineResource","");Assert.IsNotEmpty(resource);
            TableRepository.Clear();TableRuntimeOptions.DecryptBytes=LegacyFixture.Decrypt;
        }
        [TearDown]public void Cleanup()
        {
            TableRepository.Clear();TableRuntimeOptions.DecryptBytes=null;GameTableSource.Configure(new PackagedTableSource());
        }
        [UnityTest]public IEnumerator EncryptedResourcesRegisterLoadQueryIdAndFkAfterRegeneration()
        {
            GameTableSource.Configure(new PackagedTableSource());
            var definition=new PipelineTable(resource+"/Encrypted/definition");var usage=new PipelineTable(resource+"/Encrypted/usage");
            TableRepository.Register(definition);TableRepository.Register(usage);yield return Complete(TableRepository.LoadAllAsync());
            var row=definition.Get(123456001);Assert.AreEqual("modified",row.label);
            Assert.AreEqual(123,row.table);Assert.AreEqual(456,row.category);Assert.AreEqual(1,row.index);
            Assert.IsNotNull(definition.Get(usage.Get(124456001).reference));Assert.IsTrue(TableRepository.loaded);
            yield return Complete(definition.LoadDatasAsync());Assert.AreEqual(2,definition.Datas.Count);
        }
        [UnityTest]public IEnumerator PlaintextOutputLoadsOnlyThroughExplicitPlaintextSource()
        {
            GameTableSource.Configure(new PackagedTableSource(false));var definition=new PipelineTable(resource+"/Plain/definition");
            TableRepository.Register(definition);yield return Complete(TableRepository.LoadAllAsync());
            Assert.AreEqual("fixture",definition.Get(123456001).label);Assert.AreEqual("다국어",definition.Get(123456002).label);
        }
        [UnityTest]public IEnumerator DirectLegacySimpleOutputLoadsThroughExistingDecryptBytesSeam()
        {
            var task=TableUtil.LoadLocalTableAsync(resource+"/Encrypted/direct_legacy");yield return Complete(task);
            Assert.AreEqual(2,task.Result.Count);Assert.AreEqual("fixture",task.Result[0].GetString("label"));
        }
    }
}
#endif
