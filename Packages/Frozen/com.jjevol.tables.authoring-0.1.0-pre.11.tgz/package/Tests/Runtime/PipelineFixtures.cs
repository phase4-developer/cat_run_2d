using System;
using System.Linq;

namespace jjevol.Tables.Authoring.Tests
{
    public static class LegacyFixture
    {
        public static Func<byte[], byte[]> Method(string method)
        {
            var type = AppDomain.CurrentDomain.GetAssemblies().Select(a => a.GetType("Step8Fixture.Cipher"))
                .FirstOrDefault(t => t != null);
            if (type == null) throw new InvalidOperationException("Read-only legacy reference fixture must be prepared in the isolated validation Host.");
            return (Func<byte[], byte[]>)Delegate.CreateDelegate(typeof(Func<byte[], byte[]>), type.GetMethod(method));
        }
        public static byte[] Encrypt(byte[] data) => Method("Encrypt")(data);
        public static byte[] Decrypt(byte[] data) => Method("Decrypt")(data);
    }
    public sealed class PipelineRow : TableData
    {
        public string label;
        public int reference;
        public PipelineRow(TSVRow row) : base(row) { label=row.GetString("label"); reference=row.GetInt("reference"); }
    }
    public sealed class PipelineTable : IndexedTable<PipelineRow>
    {
        public PipelineTable(string name) : base(name) { }
        protected override PipelineRow ParseJson(TSVRow row) => new PipelineRow(row);
    }
}
