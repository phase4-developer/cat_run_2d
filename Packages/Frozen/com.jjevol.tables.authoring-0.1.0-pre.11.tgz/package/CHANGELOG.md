# Changelog

## 0.1.0-pre.11 - 2026-11-10

- Every table may carry a human-readable `name` column (JJEvol table spec v1.1, the column after the key; in `ConsumeTypes`, after `typeId`). A game `TableSchema` no longer has to declare it: it is kept in the Runtime output without an `UnusedColumn` warning, may be absent or empty, and is not checked. A header that differs only in case (`Name`) is warned as `HeaderCase` and written as `name`, so the Runtime output header of an existing undeclared `Name` column changes to `name` on the next build. Tables without a schema are not normalized, as before. A schema that declares its own `name` column governs it as before. Other undeclared columns are still warned as `UnusedColumn`.
- Runtime is unchanged: `TableData` reads `nameKey`, and `TableData.name` is still the translated text, not the `name` cell. ConsumeTypes code generation reads only `typeId` and `codeName`, so the extra column does not change generated code or its definition hash.
- Position and blank checks for `name` are not added; the spec does not ask loaders to enforce them.

## 0.1.0-pre.10 - 2026-11-10

- ConsumeTypes definition errors (`ConsumeTypeId`, `DuplicateTypeId`, `ConsumeCodeName`, `DuplicateCodeName`, `ConsumeNone`) report the pasted source row after blank rows are skipped (`TableCell.Row`), like table diagnostics since 0.1.0-pre.9.
- Known limit: a table with no registered `TableSchema` has no declared columns. A column its row class reads through `TSVRow.Get` can be absent from the TSV without any warning, and reads as the getter default. Register a schema to be warned.

Unity 6000.3.9f1, candidate `a6456fa`: on `Hosts/CombinedValidationHost` EditMode `tm1110-comb-edit-tbl1-05` 209/209 (with compile) and `tm1110-comb-edit-tbl2-04` 74/74 passed. economy.drop, which reads tables through `TSVRow`, passed compile and EditMode 43/43 on `Hosts/EconomyDropValidationHost` (`tm1110-drop-edit-01`) against tables 0.1.0-pre.3. The three combined-Host exclusions listed under 0.1.0-pre.9 are still not run.

## 0.1.0-pre.9 - 2026-11-10

- Breaking: the `Custom/Create Table` menu is now `JJEvol/Tables/Table Builder` and the window is titled `Table Builder`. The `CreateTable` class, its script GUID and serialized fields are unchanged.
- Columns are matched by header name, ignoring case and surrounding spaces. Sheet data pasted into a TSV file no longer has to match a column order or exact spelling.
- These cases are now warnings and the table still builds: a header with surrounding spaces (`HeaderSpacing`), a header that differs from its schema column only in case (`HeaderCase`, written as the schema name), a column the game schema does not declare (`UnusedColumn`, kept), a column without a header name (`UnnamedColumn`, dropped), a row shorter than the header (`MissingCells`, read as empty), values to the right of the last header (`ExtraCells`, dropped), a row with no values (`BlankRecord`, skipped), and a missing optional schema column (`MissingColumn`, rows use the parser default).
- Still errors: duplicate headers (ignoring case and spaces), no named column at all, and a missing **required** schema column. The required-column rule is unchanged. `ColumnCount` and the blank-record error no longer exist.
- Manual column mapping no longer requires connecting optional schema columns, and finds headers ignoring case. ConsumeTypes finds `typeId`/`codeName` ignoring case.
- New Google spreadsheet connection: Project settings store the spreadsheet address or ID (`spreadsheet` in `ProjectSettings/JJEvolTableAuthoringSettings.json`), with a **시트 열기** button. The table tab warns and links to the setting until a spreadsheet is connected. Nothing is downloaded: copy a sheet tab and paste it into the input TSV file. `TableSpreadsheetLink` exposes the saved value and address checks.
- Diagnostics report the original source column even after unnamed columns are dropped (`TableCell.Column`). Requires `com.jjevol.tables` 0.1.0-pre.3.
- Diagnostics keep the source row after blank rows are skipped (`TableCell.Row`). `TableBuildInput.RequireInt64` finds its header ignoring case and spaces and reports the source row and column.
- Tests: `TableBaselineTests.AnUnreadableFileCannotBeAccepted` and `TableBuildSafetyTests.MissingRequiredValidatorBlocksButStructuralOnlyCoverageIsHonest` used a short row as their unreadable input. A short row is now a warning, so they use a duplicate header instead. `TableColumnNameTests` fixture folders start with `JJEvolStep`, which the shared metadata cleanup requires.

Unity 6000.3.9f1 on `Hosts/CombinedValidationHost`, candidate `223cf6e` (after review fixes): EditMode `tm1110-comb-edit-tbl1-04` 209/209 and `tm1110-comb-edit-tbl2-03` 73/73 passed; Economy 187/187 and 97/97 and localization.authoring 115/115 passed with it. Earlier candidate `0007c0f`: EditMode jobs `tm1110-comb-edit-tbl1-03` 208/208 (with compile) and `tm1110-comb-edit-tbl2-02` 72/72 passed; PlayMode `tm1110-comb-play-tbl-02` 7/7 passed (candidate `e7e91cc`, PlayMode tests unchanged since). Not run on the combined Host (they need the isolated Host's cipher fixture): `TableAuthoringTests` including its menu path assertion, `TablePipelineLoadingTests`, `CombinedCodeAndEncryptedTableUseTheSameFrozenValidatorInput`.

## 0.1.0-pre.8 - 2026-11-10

- Breaking: `ICommonDataToolSettings.GoogleApiKey` is removed. A project setting kept the key inside the project; localization.authoring 0.1.0-pre.10 now keeps it per user in EditorPrefs. Implementations that still declare the property compile unchanged.

Unity 6000.3.9f1 on `Hosts/CombinedValidationHost`: EditMode jobs `pkg1110-comb-edit-tblauth1-01` 204/204 and `pkg1110-comb-edit-tblauth2-01` 12/12 passed.

## 0.1.0-pre.7 - 2026-11-09

- Replacing an existing table, generated code or metadata file no longer fails when another process briefly holds a file that was written moments earlier. Windows reports this as `File.Replace` HRESULT `0x80070497` (`ERROR_UNABLE_TO_REMOVE_REPLACED`) and keeps both files under their original names. It was reproduced outside Unity under the project folder: about 1 in 300 to 1 in 500 write-then-replace pairs fail, `MoveFileEx` fails the same way, and Windows Search indexing is not the cause. On-access scanning is the likely holder.
- Only that error now waits and repeats the same `File.Replace`, starting at 10 ms and doubling to at most 250 ms per wait, for 2 seconds in total. When the budget is spent the same `IOException` as before is thrown. Nothing is deleted or moved instead, and every other error, a sharing violation included, still fails on the first attempt. The journal, checkpoint and recovery protocol are unchanged.
- This was the cause of `ConsumeTypesGenerationTests` failing one different case per run.
- New `TableReplaceWaitTests` drive the wait with a scripted replacement.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.6 - 2026-11-08

- Lock files move from `ProjectSettings` to `Library/JJEvol/TableAuthoring/Locks/`. They are taken and held exactly as before; only the location changes, so taking a lock no longer adds a file to `ProjectSettings`. This covers `ProjectSettings/JJEvolTableAuthoring/<hash>.json.lock` and `ProjectSettings/JJEvolTableAuthoringSettings.json.lock`.
- Existing `.lock` files in `ProjectSettings/JJEvolTableAuthoring/` and `ProjectSettings/JJEvolTableAuthoringSettings.json.lock` are no longer used and can be deleted while no Editor has the project open. Keep the `.json` and `.json.pending` files.
- Tests follow the new lock location.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.5 - 2026-11-07

- PlayMode, Player build, status and plan messages name each mismatching file and the reason.
- Create Table can accept the current files as the new baseline after a confirmation that lists them. It rewrites only the manifest record, and is unavailable while a `.pending` journal needs recovery. `TableBuilder.GetFileDifferences`, `TableBuilder.AcceptCurrentFiles` and `TableFileDifference` are the matching API.
- Create Table can rebuild hand-edited or missing generated code from the recorded definition after a confirmation that lists the files and says hand edits are lost. It uses the normal transaction, so changed C# stays pending until the compiled assembly is verified, and Recover puts the edited file back. `TableBuilder.RegenerateCode` and `TableFileDifference.CanRegenerate` are the matching API.
- Regenerating while a hand edit already breaks compilation is judged by the compile that follows. The earlier failure no longer records this generation as failed, and Recover stays hidden while that compile is awaited.
- Generated outputs are compared with line endings normalised to LF, so a CRLF conversion alone no longer blocks. A manifest recorded from LF files stays valid unchanged. An output recorded while it contained CRLF differs once and can be accepted.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.4 - 2026-11-06

- The Remove screen no longer reselects every input, and selection is limited to the visible managed list.
- Blank cells of optional Unique columns are not duplicates.

Unity tests for this candidate are NOT_RUN.

# 0.1.0-pre.1 — 2026-10-31

Optional Editor extraction of CreateTable and CommonDataToolSettings, preserving original script GUIDs and menu. Added a testable local builder, explicit plaintext mode, Host-owned codec/validator hooks, encrypted round-trip checks, failure-before-replacement and stable-GUID regeneration. Removed content previews and backend/JSON diagnostic dependencies. Table Core, existing packages and snapshots are unchanged. No publication or game installation.
