using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace jjevol.Samples.MinimalTableFlow.Editor
{
    public sealed class MinimalTableFlowWindow : EditorWindow
    {
        [SerializeField] private bool _paste;
        [SerializeField] private string _items = "", _types = "";
        [SerializeField] private string _status = "Read Local inputs or paste both tables, then Preview → Prepare → Apply.";
        private TableBuildPlan _plan;
        private TablePreparedBuild _prepared;
        private Vector2 _scroll;

        [MenuItem("JJEvol/Samples/Minimal Table Flow/Authoring")]
        public static void Open() => GetWindow<MinimalTableFlowWindow>("Minimal Table Flow").Show();

        [MenuItem("JJEvol/Samples/Minimal Table Flow/Create Demo Object")]
        public static void CreateDemoObject()
        {
            if (Application.isPlaying) throw new InvalidOperationException("Create the demo before entering Play Mode.");
            var demo = new GameObject("Minimal Table Flow Demo");
            Undo.RegisterCreatedObjectUndo(demo, "Create Minimal Table Flow Demo");
            demo.AddComponent<MinimalTableFlowDemo>();
            Selection.activeGameObject = demo;
        }

        private void Invalidate() { _plan = null; _prepared = null; }
        private void Run(Action action)
        {
            try { action(); }
            catch (Exception error) { _prepared = null; _status = error.Message; }
        }
        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.HelpBox("Optional typed sample: Tables + Authoring + Economy + Save. Plaintext sample policy is local to this request. Game-wide options/settings are untouched.", MessageType.Info);
            EditorGUI.BeginChangeCheck();
            _paste = EditorGUILayout.Toggle("Paste input", _paste);
            if (_paste)
            {
                EditorGUILayout.LabelField("MinimalItems TSV");
                _items = EditorGUILayout.TextArea(_items, GUILayout.MinHeight(85));
                EditorGUILayout.LabelField("ConsumeTypes TSV");
                _types = EditorGUILayout.TextArea(_types, GUILayout.MinHeight(65));
            }
            if (EditorGUI.EndChangeCheck()) Invalidate();
            if (GUILayout.Button("Read Local inputs into Paste fields")) Run(() => {
                _items = MinimalTableFlowAuthoring.ReadItems().Text;
                _types = MinimalTableFlowAuthoring.ReadTypes().Text;
                _paste = true;
                Invalidate();
            });
            RunPathLabels();
            if (GUILayout.Button(_paste ? "1. Preview Paste" : "1. Preview Local")) Run(() => {
                Invalidate();
                _plan = MinimalTableFlowAuthoring.CreatePlan(
                    _paste ? TableInput.FromText("MinimalItems", _items) : MinimalTableFlowAuthoring.ReadItems(),
                    _paste ? TableInput.FromText("ConsumeTypes", _types) : MinimalTableFlowAuthoring.ReadTypes(),
                    MinimalTableFlowAuthoring.OutputDirectory, MinimalTableFlowAuthoring.CodeDirectory);
                _status = _plan.IsValid ? "Preview is valid. Outputs are unchanged." : "Fix the diagnostics before preparing.";
            });
            if (_plan != null)
            {
                foreach (var diagnostic in _plan.Diagnostics) EditorGUILayout.HelpBox(diagnostic.ToString(), diagnostic.Severity == TableDiagnosticSeverity.Error ? MessageType.Error : MessageType.Warning);
                foreach (var input in _plan.ValidationInputs)
                {
                    EditorGUILayout.LabelField(input.TableName + " — " + input.Rows.Count + " rows", EditorStyles.boldLabel);
                    EditorGUILayout.SelectableLabel(input.Text, GUILayout.Height(75));
                }
                foreach (var change in _plan.Changes.Concat(_plan.ConsumeTypes?.Changes ?? Array.Empty<TableOutputChange>()))
                    EditorGUILayout.LabelField(change.Action + " " + change.TableName, change.Path);
                if (_plan.ConsumeTypes != null)
                {
                    EditorGUILayout.LabelField("Generated enum preview");
                    EditorGUILayout.SelectableLabel(_plan.ConsumeTypes.EnumSource, GUILayout.Height(110));
                }
            }
            using (new EditorGUI.DisabledScope(_plan == null || !_plan.IsValid))
                if (GUILayout.Button("2. Prepare reviewed outputs")) Run(() => { _prepared = TableBuilder.Prepare(_plan); _status = "Prepared; no outputs changed. Confirm the preview and Apply."; });
            using (new EditorGUI.DisabledScope(_prepared == null))
                if (GUILayout.Button("3. Apply data + ConsumeTypes")) Run(() => {
                    var result = MinimalTableFlowAuthoring.ApplyReviewedBuild(_prepared); _prepared = null; _plan = null;
                    _status = result.State + ". Wait for Unity compilation, then Verify.";
                });
            if (GUILayout.Button("4. Verify compiled generation + Runtime lookup")) Run(() => {
                MinimalTableFlowAuthoring.VerifyImportedSample(); _status = "Ready: actual compiled enum, data and provider verified. Create Demo Object and Play.";
            });
            if (GUILayout.Button("Inspect recorded build state")) Run(() => _status = TableBuilder.GetStatus(MinimalTableFlowAuthoring.OutputDirectory).ToString());
            if (GUILayout.Button("Recover this sample's recorded build")) Run(() => {
                Invalidate(); _status = "Recovery: " + TableBuilder.Recover(MinimalTableFlowAuthoring.OutputDirectory) + ". " + TableBuilder.GetStatus(MinimalTableFlowAuthoring.OutputDirectory);
            });
            EditorGUILayout.HelpBox(_status, MessageType.None);
            EditorGUILayout.EndScrollView();
        }
        private void RunPathLabels()
        {
            try
            {
                EditorGUILayout.LabelField("Local input", MinimalTableFlowAuthoring.SampleRoot + "/Input");
                EditorGUILayout.LabelField("Runtime data", MinimalTableFlowAuthoring.OutputDirectory);
                EditorGUILayout.LabelField("Generated C#", MinimalTableFlowAuthoring.CodeDirectory);
            }
            catch (Exception error) { EditorGUILayout.HelpBox(error.Message, MessageType.Warning); }
        }
    }
}
