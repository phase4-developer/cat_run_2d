using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace jjevol.Samples.MinimalTableFlow.Editor
{
    // A concrete game adapter around existing Authoring APIs, not a model/code generator.
    public static class MinimalTableFlowAuthoring
    {
        public const string GeneratedNamespace = "jjevol.Samples.MinimalTableFlow.Generated";
        public const string GeneratedEnum = "MinimalConsumeType";
        public static string SampleRoot
        {
            get
            {
                foreach (string guid in AssetDatabase.FindAssets("MinimalTableFlowWindow t:MonoScript"))
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    if (path.StartsWith("Assets/", StringComparison.Ordinal) &&
                        AssetDatabase.LoadAssetAtPath<MonoScript>(path)?.GetClass() == typeof(MinimalTableFlowWindow))
                        return Path.GetDirectoryName(Path.GetDirectoryName(path)).Replace('\\', '/');
                }
                throw new InvalidOperationException("Import the Minimal Table Flow sample into Assets first.");
            }
        }
        public static string OutputDirectory => SampleRoot + "/Runtime/Resources/JJEvolMinimalTableFlow";
        public static string CodeDirectory => SampleRoot + "/Runtime/Generated";
        public static TableInput ReadItems() => TableInput.FromFile(SampleRoot + "/Input/MinimalItems.tsv");
        public static TableInput ReadTypes() => TableInput.FromFile(SampleRoot + "/Input/ConsumeTypes.tsv");

        [Serializable] private sealed class AppliedReview
        {
            public int version = 1;
            public string output, code, space, definitionHash, itemsText, typesText, itemsKind, typesKind;
        }
        private static string ReviewDirectory(string output)
        {
            string full = Path.GetFullPath(output).Replace('\\', '/');
            using var hash = SHA256.Create();
            string key = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(full))).Replace("-", "");
            return Path.GetFullPath(Path.Combine(Application.dataPath, "../Library/JJEvol/MinimalTableFlow/Reviews", key));
        }
        public static TableBuildResult ApplyReviewedBuild(TablePreparedBuild prepared)
        {
            if (prepared == null) throw new ArgumentNullException(nameof(prepared));
            var plan = prepared.Plan;
            var items = plan.ValidationInputs.Single(input => input.TableName == MinimalItemTable.InputName);
            var types = plan.ValidationInputs.Single(input => input.TableName == "ConsumeTypes");
            var review = new AppliedReview {
                output = Path.GetFullPath(plan.OutputDirectory), code = Path.GetFullPath(plan.Request.ConsumeTypes.OutputDirectory),
                space = plan.Request.ConsumeTypes.Namespace, definitionHash = plan.ConsumeTypes.DefinitionHash,
                itemsText = items.Text, typesText = types.Text,
                itemsKind = items.Document.Input.Kind.ToString(), typesKind = types.Document.Input.Kind.ToString()
            };
            var result = prepared.Apply();
            // A sample-owned review receipt survives domain reload without changing Local inputs
            // or the Framework's canonical ownership manifest. Only successful Apply is recorded.
            string directory = ReviewDirectory(plan.OutputDirectory);
            Directory.CreateDirectory(directory);
            string path = Path.Combine(directory, DateTime.UtcNow.Ticks.ToString("D19", CultureInfo.InvariantCulture) + "_" + Guid.NewGuid().ToString("N") + ".json");
            string pending = path + ".pending";
            using (var file = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                byte[] bytes = new UTF8Encoding(false).GetBytes(JsonUtility.ToJson(review, true));
                file.Write(bytes, 0, bytes.Length);
                file.Flush(true);
            }
            File.Move(pending, path); // Create-only receipt; no File.Replace or core recovery bypass.
            return result;
        }
        private static AppliedReview ReadAppliedReview()
        {
            string directory = ReviewDirectory(OutputDirectory);
            string path = Directory.Exists(directory) ? Directory.GetFiles(directory, "*.json").OrderByDescending(value => value, StringComparer.Ordinal).FirstOrDefault() : null;
            if (path == null) throw new InvalidOperationException("No applied sample review exists. Preview and Apply through the sample controller before verifying.");
            var review = JsonUtility.FromJson<AppliedReview>(File.ReadAllText(path, new UTF8Encoding(false, true)));
            if (review == null || review.version != 1 || review.output != Path.GetFullPath(OutputDirectory) ||
                review.code != Path.GetFullPath(CodeDirectory) || review.space != GeneratedNamespace ||
                string.IsNullOrEmpty(review.definitionHash) || review.itemsText == null || review.typesText == null)
                throw new InvalidDataException("The sample review receipt is invalid or belongs to another output.");
            return review;
        }

        public static TableBuildPlan CreatePlan(TableInput items, TableInput types, string outputDirectory,
            string codeDirectory, string generatedNamespace = GeneratedNamespace)
        {
            if (items?.TableName != MinimalItemTable.InputName || types?.TableName != "ConsumeTypes")
                throw new ArgumentException("This sample expects MinimalItems and ConsumeTypes input snapshots.");
            return TableBuilder.Plan(new TableBuildRequest(new[] { items, types }, outputDirectory,
                useEncrypt: false, validate: ValidateGameData, requireValidator: true, validationVersion: "minimal-table-flow-1",
                schemas: new[] {
                    new TableSchema(MinimalItemTable.InputName,
                        new TableColumnRule("id", TableColumnKind.Int32, unique: true, minimum: 1),
                        new TableColumnRule("label"), new TableColumnRule("typeId", TableColumnKind.Int32),
                        new TableColumnRule("quantity", TableColumnKind.Int64, minimum: 1))
                }, consumeTypes: new ConsumeTypesGenerationSettings(codeDirectory, generatedNamespace, GeneratedEnum)));
        }

        private static void ValidateGameData(IReadOnlyList<TableBuildInput> inputs)
        {
            var types = inputs.Single(input => input.TableName == "ConsumeTypes");
            var allowed = new HashSet<long>(Enumerable.Range(0, types.Rows.Count).Select(row => types.RequireInt64(row, "typeId")));
            var items = inputs.Single(input => input.TableName == MinimalItemTable.InputName);
            for (int row = 0; row < items.Rows.Count; row++)
            {
                var parsed = new MinimalItemRow(items.Rows[row]); // The actual Runtime parser is part of validation.
                if (!allowed.Contains(parsed.TypeId.Value))
                {
                    int column = items.Document.Headers.ToList().IndexOf("typeId");
                    var cell = items.Document.Records[row][column];
                    throw new TableInputException(new TableDiagnostic(TableDiagnosticSeverity.Error, "SampleUnknownType",
                        items.TableName, items.SourcePath, "typeId must exist in this build's ConsumeTypes definition.",
                        row + 2, column + 1, cell.Line, cell.Character, "typeId"));
                }
            }
        }

        // Two separate batch entry points deliberately allow a real Unity reload between Apply
        // and verifying the compiled assembly. Neither supplies a fake generated enum.
        public static void BuildImportedSample()
        {
            var plan = CreatePlan(ReadItems(), ReadTypes(), OutputDirectory, CodeDirectory);
            var prepared = TableBuilder.Prepare(plan);
            var result = ApplyReviewedBuild(prepared);
            Debug.Log("[Minimal Table Flow] Apply: " + result.State + ". Recompile, then verify.");
        }
        public static void VerifyImportedSample()
        {
            var status = TableBuilder.VerifyCompiledGeneration(OutputDirectory);
            if (status.State != TableBuildState.Ready) throw new InvalidOperationException(status.ToString());
            var review = ReadAppliedReview();
            var items = TableInput.FromText("MinimalItems", review.itemsText, source: "applied sample review (" + review.itemsKind + ")");
            var types = TableInput.FromText("ConsumeTypes", review.typesText, source: "applied sample review (" + review.typesKind + ")");
            var plan = CreatePlan(items, types, OutputDirectory, CodeDirectory);
            if (!plan.IsValid) throw new InvalidDataException(string.Join("\n", plan.Diagnostics));
            if (plan.ConsumeTypes.DefinitionHash != review.definitionHash) throw new InvalidDataException("The applied review's definition hash differs from its frozen input.");
            var document = TableDocument.Parse(items);
            if (File.ReadAllText(OutputDirectory + "/MinimalItems.txt") != document.RuntimeText)
                throw new InvalidDataException("Applied Runtime TSV differs from the reviewed input.");
            var assembly = typeof(MinimalItemRow).Assembly;
            var enumType = assembly.GetType(GeneratedNamespace + "." + GeneratedEnum, true);
            var extensions = assembly.GetType(GeneratedNamespace + "." + GeneratedEnum + "Extensions", true);
            var forward = extensions.GetMethod("ToConsumeTypeId");
            var reverse = extensions.GetMethod("TryTo" + GeneratedEnum);
            foreach (var definition in plan.ConsumeTypes.Definitions)
            {
                object symbol = Enum.Parse(enumType, definition.CodeName);
                var wire = (ConsumeTypeId)forward.Invoke(null, new[] { symbol });
                object[] arguments = { wire, null };
                if (wire.Value != definition.TypeId || !(bool)reverse.Invoke(null, arguments) ||
                    Convert.ToInt32(arguments[1], CultureInfo.InvariantCulture) != definition.TypeId)
                    throw new InvalidDataException("Compiled ConsumeTypes conversion differs from the input definition.");
            }
            var table = new MinimalItemTable(new PackagedTableSource(false));
            table.LoadDatas();
            try
            {
                var service = new MinimalItemService(table);
                var presentation = new MinimalItemPresentationProvider(service);
                if (table.Datas.Count != document.Records.Count) throw new InvalidDataException("Runtime row count differs.");
                foreach (var row in plan.ValidationInputs.Single(input => input.TableName == MinimalItemTable.InputName).Rows)
                {
                    var expected = new MinimalItemRow(row);
                    var value = service.CreateValue(expected.id);
                    if (value.TypeId != expected.TypeId || value.Quantity != expected.Quantity || value.Present(presentation).Name != expected.Label)
                        throw new InvalidDataException("Runtime service/provider differs from the reviewed input.");
                }
            }
            finally { table.ReleaseSampleData(); }
            Debug.Log("[Minimal Table Flow] Ready: generated assembly, applied data, Runtime lookup and display provider verified.");
        }
    }
}
