using System;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;

namespace jjevol.Samples.MinimalTableFlow
{
    // This model and its exact column names belong to the sample game.
    public sealed class MinimalItemRow : TableData
    {
        public string Label { get; }
        public ConsumeTypeId TypeId { get; }
        public long Quantity { get; }

        public MinimalItemRow(TSVRow row) : base(row)
        {
            id = int.Parse(row.Get("id"), NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture);
            Label = row.Get("label");
            TypeId = new ConsumeTypeId(int.Parse(row.Get("typeId"), NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture));
            Quantity = long.Parse(row.Get("quantity"), NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture);
            if (id <= 0 || string.IsNullOrEmpty(Label) || Quantity <= 0)
                throw new InvalidDataException("MinimalItems requires a positive ID, label and positive Int64 quantity.");
        }
    }

    public sealed class MinimalItemTable : IndexedTable<MinimalItemRow>
    {
        public const string InputName = "MinimalItems";
        public const string ResourceName = "JJEvolMinimalTableFlow/MinimalItems";
        private ITableSource _source;
        private int _sourceGeneration;

        public MinimalItemTable(ITableSource source = null) : base(ResourceName) => _source = source;
        protected override MinimalItemRow ParseJson(TSVRow row) => new MinimalItemRow(row);

        // A source is owned by this table, so importing/running the sample never changes
        // GameTableSource.Current, a game's codec policy or another table's source.
        public void SetSource(ITableSource source)
        {
            _source = source ?? throw new ArgumentNullException(nameof(source));
            _sourceGeneration++;
        }
        public override void LoadDatas()
        {
            if (_source != null) base.LoadDatas(_source);
        }
        public override async Task LoadDatasAsync()
        {
            var source = _source;
            int generation = _sourceGeneration;
            if (source == null) return;
            var rows = await source.LoadAsync(TableName);
            if (generation != _sourceGeneration || !ReferenceEquals(source, _source)) return;
            _DataClear();
            InsertData(rows);
        }
        public void ReleaseSampleData()
        {
            _DataClear();
            _source = null;
            _sourceGeneration++;
        }
    }
}
