using System;
using System.Collections.Generic;
using jjevol.Data;

namespace jjevol.Samples.MinimalTableFlow
{
    public sealed class MinimalItemService
    {
        private readonly MinimalItemTable _table;
        private bool _released;
        public MinimalItemService(MinimalItemTable table) => _table = table ?? throw new ArgumentNullException(nameof(table));
        public IReadOnlyList<MinimalItemRow> Items { get { CheckActive(); return _table.Datas; } }
        public MinimalItemRow Find(int id) { CheckActive(); return _table.Get(id); }
        internal void Release() => _released = true;
        private void CheckActive() { if (_released) throw new ObjectDisposedException(nameof(MinimalItemService)); }
        public ConsumeData CreateValue(int id)
        {
            var row = Find(id) ?? throw new ArgumentOutOfRangeException(nameof(id), "Unknown sample item ID.");
            return new ConsumeData(row.TypeId, row.id, row.Quantity);
        }
    }

    public sealed class MinimalItemPresentationProvider : IConsumePresentationProvider
    {
        private readonly MinimalItemService _items;
        public MinimalItemPresentationProvider(MinimalItemService items) => _items = items ?? throw new ArgumentNullException(nameof(items));
        public bool TryResolve(ConsumeTypeId typeId, int itemId, out ConsumePresentation presentation)
        {
            var row = _items.Find(itemId);
            if (row == null || row.TypeId != typeId) { presentation = default; return false; }
            presentation = new ConsumePresentation(row, name: row.Label, description: "Minimal table sample item");
            return true;
        }
        public ConsumePresentation Resolve(ConsumeData data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (!TryResolve(data.TypeId, data.ItemId, out var presentation))
                throw new ArgumentOutOfRangeException(nameof(data), "Unknown sample type/item pair.");
            return presentation;
        }
    }

    /// <summary>A single explicit sample session; never clears the game's global repository.</summary>
    public sealed class MinimalTableFlowSession : IDisposable
    {
        private static readonly MinimalItemTable RegisteredTable = new MinimalItemTable();
        private static bool _registered;
        private static MinimalTableFlowSession _active;
        private bool _disposed;
        public MinimalItemService Items { get; }
        public MinimalItemPresentationProvider Presentation { get; }

        private MinimalTableFlowSession()
        {
            Items = new MinimalItemService(RegisteredTable);
            Presentation = new MinimalItemPresentationProvider(Items);
        }
        public static MinimalTableFlowSession Open(ITableSource source = null)
        {
            if (_active != null) throw new InvalidOperationException("Close the active Minimal Table Flow session first.");
            var session = new MinimalTableFlowSession();
            _active = session;
            try
            {
                RegisteredTable.SetSource(source ?? new PackagedTableSource(false));
                if (!_registered) { TableRepository.Register(RegisteredTable); _registered = true; }
                // Load only our table here. A game's startup can instead use Register + LoadAll.
                RegisteredTable.LoadDatas();
                if (session.Items.Items.Count == 0) throw new InvalidOperationException("Apply the sample's table data before starting it.");
                return session;
            }
            catch { session.Dispose(); throw; }
        }
        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            RegisteredTable.ReleaseSampleData();
            Items.Release();
            if (ReferenceEquals(_active, this)) _active = null;
            // TableRepository has no Unregister. Keep one inert empty registration; never Clear
            // registrations that might belong to a game. See Usage.md for bootstrap ownership.
        }
    }
}
