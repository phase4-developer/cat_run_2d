using System;
using System.Globalization;
using System.Text;
using UnityEngine;

namespace jjevol.Samples.MinimalTableFlow
{
    public sealed class MinimalTableFlowDemo : MonoBehaviour
    {
        private MinimalTableFlowSession _session;
        private string _display = "";
        private void OnEnable()
        {
            if (!Application.isPlaying) return;
            try
            {
                _session = MinimalTableFlowSession.Open();
                var text = new StringBuilder("Minimal Table Flow\n");
                foreach (var row in _session.Items.Items)
                {
                    var data = _session.Items.CreateValue(row.id);
                    var presentation = data.Present(_session.Presentation);
                    text.Append(presentation.Name).Append(" × ").Append(data.Quantity.ToString(CultureInfo.InvariantCulture))
                        .Append(" (type ").Append(data.TypeId.Value).Append(", item ").Append(data.ItemId).Append(")\n");
                }
                _display = text.ToString();
                Debug.Log(_display, this);
            }
            catch (Exception error) { _display = error.Message; Debug.LogError(_display, this); }
        }
        private void OnDisable() { _session?.Dispose(); _session = null; }
        private void OnGUI() => GUI.Label(new Rect(20, 20, 760, 150), _display);
    }
}
