# Minimal Table Flow

신규 게임이 직접 정의한 Row를 Local/Paste 입력으로 제작하고 Runtime Service 및 기존 표시 Provider 계약으로 소비하는 중립 예제다. 샘플 Import만으로 출력 생성, 전역 정책 변경, Scene 생성 또는 Google 접속이 발생하지 않는다.

## 설치 경계

| 목적 | 설치할 Framework 패키지 | 이 샘플 사용 |
| --- | --- | --- |
| 기본 Table 제작·조회 | `com.jjevol.tables` + `com.jjevol.tables.authoring` | 아래 Row/Parser와 Local/Paste 제작 흐름을 참고한다. 이 typed 샘플 전체 Import는 Economy가 필요하다. |
| ConsumeTypes 코드 생성·표시까지 실행 | 위 2개 + `com.jjevol.economy` + `com.jjevol.save` | 이 샘플 전체를 Import한다. Economy는 Save와 Tables를 직접 참조한다. |

Tables Authoring 본체에는 Economy/Save가 필수가 아니다. 이 샘플은 선택 기능의 실제 연결을 보여주기 위해 해당 의존성을 가진다. 네 패키지는 저장소의 `Docs/PackageInstallation.md`에 명시된 Save Candidate4/AE1/AE2 고정 후보 조합에서 선택한다. 같은 버전 문자열만 보고 후보가 동일하다고 판단하지 말고 고정 manifest와 파일 SHA를 함께 사용한다. 샘플 Import를 이유로 게임의 Save 설정·키·저장소를 초기화할 필요는 없다.

Unity Package Manager의 Table Authoring 패키지에서 **Minimal Table Flow**를 Import한다. Economy/Save를 설치한 뒤 Import해야 샘플 Runtime asmdef가 정상 컴파일된다. 이 샘플은 같은 프로젝트에서 1개만 Import한다. Package Manager Import 경로가 길면 Unity의 기존 Windows 260자 사전 검증에 걸릴 수 있으므로 QA Host/샘플 경로를 짧게 정한다.

## 실행 순서

1. `JJEvol > Samples > Minimal Table Flow > Authoring`을 연다. 기본 **Local** 모드는 Import한 샘플의 `Input/MinimalItems.tsv`와 `Input/ConsumeTypes.tsv`를 그대로 읽는다. **Read Local inputs into Paste fields**를 누르면 같은 데이터를 복사해 두 개의 Paste 입력으로 검토할 수 있다. Local 원본 파일은 변경하지 않는다.
2. **1. Preview Local/Paste**에서 각 입력의 실제 Runtime TSV, 행 수, 데이터/코드 출력 변경 및 생성 enum을 확인한다. 입력을 바꾸면 Preview/Prepare를 다시 해야 한다. `id` 중복, Int32/Int64 범위, 양수 수량, `typeId`의 ConsumeTypes 참조를 검증한다.
3. **2. Prepare**는 동결된 입력으로 준비만 하며 출력 파일을 쓰지 않는다. **3. Apply data + ConsumeTypes**가 기존 `TablePreparedBuild.Apply()`로 실제 데이터를 적용한다. `ConsumeTypes`는 Authoring 정의이며 Runtime TSV로 복제하지 않는다.
4. Unity가 실제 생성 C#을 컴파일하고 도메인을 다시 로드할 때까지 기다린다. **4. Verify**가 `VerifyCompiledGeneration`과 실제 로드된 enum/extensions 변환, 출력 TSV 및 Runtime Service/Provider 결과를 확인해야 완료다. `AppliedAwaitingCompile`은 완료가 아니다. Verify는 마지막 성공 Apply가 남긴 **검토 입력 스냅샷**을 사용하므로 편집한 Paste 결과를 Local 원본과 혼동하지 않는다.
5. `JJEvol > Samples > Minimal Table Flow > Create Demo Object`로 현재 Scene에 데모 객체를 만든 뒤 Play한다. 화면과 Console에 `Amber token × 4000000001`, `Blue token × 12`가 표시된다. 중복 데모 세션은 거부한다. 필요하면 게임이 소유한 Scene으로 저장한다.

**제품 프로젝트에서 실행하지 않는다.** Unity는 모든 `Resources` 폴더를 Player에 포함하므로, 이 샘플을 제품 프로젝트에 가져와 Apply하면 평문 예제 테이블이 Scene이나 Build Settings 등록 없이도 빌드에 들어간다. 빈 검증 프로젝트에서 실행하고, 제품 프로젝트에 이미 가져왔다면 빌드 전에 샘플 폴더를 지운다.

샘플은 `Runtime/Resources/JJEvolMinimalTableFlow/MinimalItems.txt`에 평문을 출력한다. `TableBuildRequest(useEncrypt: false)`와 `PackagedTableSource(false)`가 서로 대응하며 게임의 암호화 delegate/키/전역 옵션을 변경하지 않는다. 생성 C#은 `Runtime/Generated/MinimalConsumeType.Generated.cs` 및 `MinimalConsumeTypeExtensions.Generated.cs`다. 상위 Runtime asmdef의 명시적 `JJEvol.Economy.Runtime` 참조를 기존 generator가 검사한다.

샘플 controller의 `ApplyReviewedBuild`는 성공한 Apply의 정규화된 두 입력과 DefinitionHash를 `Library/JJEvol/MinimalTableFlow/Reviews`의 출력별 create-only receipt로 보존한다. 이 receipt는 도메인 리로드 뒤 샘플 Verify의 비교 기준이며, Framework 데이터 정본/ownership manifest를 대체하지 않는다. Local 원본·공용 설정·core API는 바뀌지 않는다. Library를 지웠거나 복구로 출력 세대를 되돌린 뒤 receipt가 맞지 않으면 검토한 입력을 다시 Preview/Apply해야 한다. receipt가 없거나 실제 적용 bytes/compiled generation과 다르면 Verify는 완료를 보고하지 않는다.

실패 시 **Inspect recorded build state**로 상태를 확인하고 샘플 출력의 기록된 복구만 명시적으로 실행한다. `RecoveryRequired`에서 반복 Apply하지 않는다. 기존 Native `File.Replace`의 `0x80070497` 환경 문제는 별도 OPEN이며, 샘플은 파일 교체 우회나 성공 위장을 제공하지 않는다. 생성 코드·meta·ProjectSettings의 ownership manifest 및 Library의 recovery journal은 수동 편집하지 않는다. 샘플 창은 공용 `CreateTable`의 저장 설정을 덮어쓰지 않는다.

## 코드와 데이터의 소유자

| 게임이 작성하는 부분 | 이 샘플의 실제 구현 | Framework 제공 부분 |
| --- | --- | --- |
| 데이터 의미·열·ID·수량 | `Input/*.tsv`, `MinimalItemRow`, `MinimalItemTable.ParseJson` | `TableData`, `TSVRow`, `IndexedTable<T>` |
| 관계·게임 규칙 검증 | `MinimalTableFlowAuthoring.ValidateGameData`와 선언 Schema | `TableDocument`, Schema 검증, 정확한 Runtime TSV round-trip 및 위치 진단 |
| 입력/출력 위치·typed 코드 이름 승인 | 전용 샘플 window/controller | `TableInput.FromFile/FromText`, `TableBuilder.Plan/Prepare`, `TablePreparedBuild.Apply` |
| 정수 ID의 게임 의미·이름 | `ConsumeTypes.tsv` | 기존 ConsumeTypes generator, ID 이력/충돌/meta/GUID/실제 컴파일 검증 |
| 조회·게임 값 변환·표시 정책 | `MinimalItemService`, `MinimalItemPresentationProvider` | `ConsumeTypeId`, `ConsumeData`, `IConsumePresentationProvider`, `ConsumePresentation`, `Present()` |

Row/Parser/Service를 자동 생성하는 새 범용 도구는 추가하지 않는다. 게임이 추가할 코드는 열의 의미/관계 검증/표시 정책이다. 파일 읽기, TSV 정규화, 원자적 적용/복구, enum 생성/컴파일 검증은 이미 Framework가 처리하므로 게임마다 복제하지 않는다. 작은 게임별 window가 반복되면 입력 경로/검증 delegate를 공용 창에 명시적으로 연결하는 편의성은 후속 후보가 될 수 있으나, 이번 예제는 새 공개 API를 요구하지 않는다.

## 신규 게임의 실제 bootstrap

```csharp
// 게임의 단일 bootstrap Owner가 전체 registry 초기화/수명과 LoadAll 호출 시점을 관리한다.
var table = new MinimalItemTable(new PackagedTableSource(false));
jjevol.Data.TableRepository.Register(table);
jjevol.Data.TableRepository.LoadAll(); // 이미 loaded=true이면 새 등록 table은 자동으로 로드되지 않는다.
var service = new MinimalItemService(table);
var provider = new MinimalItemPresentationProvider(service);
ConsumeData value = service.CreateValue(1001);
ConsumePresentation display = value.Present(provider);
```

예제의 `MinimalItems`는 Authoring 출력 파일 이름이고 `JJEvolMinimalTableFlow/MinimalItems`는 Resources 조회 경로다. 게임 이름/폴더로 바꿀 때 두 계약을 함께 바꾼다. 나중에 생성 enum을 직접 사용하는 게임 코드에서는 `Generated.MinimalConsumeType.Amber.ToConsumeTypeId()`를 사용할 수 있다. 생성 전에는 해당 타입이 존재하지 않으므로 초기 샘플 코드는 `ConsumeTypeId(int)`를 사용한다. Verify 단계가 실제 생성/컴파일된 enum과 양방향 변환을 reflection으로 검증한다. 가짜 enum·조건부 대체 enum·손으로 쓴 generated source는 없다.

`MinimalTableFlowSession` 데모는 전체 게임 registry를 소유하지 않는다. 전역 `GameTableSource`, codec, path delegate, 설정 파일을 변경하지 않고 **샘플 table만 직접 로드**한다. session 종료는 샘플 Row/source/service를 해제한다. `TableRepository`에 현재 per-table Unregister/등록 조회 API가 없어 하나의 빈 비활성 sample table 등록은 유지한다. 다른 게임 등록을 지우는 `TableRepository.Clear()`는 호출하지 않는다. 전역 registry를 외부에서 Clear한 뒤 같은 도메인에서 이 데모를 다시 등록하는 동작은 지원하지 않는다. 실제 게임은 위처럼 자신의 bootstrap에서 table을 등록하고 전체 registry 수명을 관리한다. 이는 기존 API 제약이며 이번 작업에서 공개 API를 바꾸지 않았다.

## 자체 검증 진입점

Runtime/Editor sample asmdef 및 meta는 통합 Owner가 제공한다. 테스트 원본은 패키지 `Tests/Samples~/MinimalTableFlow`에 있어 기본 설치에서 컴파일되지 않는다. 통합 Owner가 독립 QA Host의 Assets로 복사한 뒤 Editor/Runtime 테스트 각각을 고립 asmdef로 연결한다. 테스트를 위해 소비 게임이나 패키지 캐시를 수정하지 않는다.

- 초기 Import 컴파일: generated source 없는 상태에서 Runtime/Editor sample assembly가 컴파일되어야 한다.
- 실제 생성: `jjevol.Samples.MinimalTableFlow.Editor.MinimalTableFlowAuthoring.BuildImportedSample`를 호출한 뒤 Unity 컴파일/리로드를 별도 완료한다.
- 실제 확인: `MinimalTableFlowAuthoring.VerifyImportedSample`를 호출한다.
- fresh QA Host에서 `jjevol.Tables.Authoring.SampleTests.MinimalTableFlowNativeTests` fixture를 단독 실행한다. 실제 적용 파일·로드된 enum·Repository Register/LoadAll·Int64·Provider 및 타인 등록 보존을 검사한다. 이미 `TableRepository.loaded=true`인 Host를 임의 Clear하지 않고 실패로 알린다.
- `MinimalTableFlowAuthoringTests`는 Local/Paste 동등성, 실제 코드 Preview, Prepare 무쓰기, 잘못된 참조/수량 및 동결 이후 입력 변경 거부를 검사한다.
- 편집 Paste의 실제 적용/컴파일 회귀는 테스트 어셈블리의 `jjevol.Tables.Authoring.SampleTests.MinimalTableFlowPasteRegression.BuildEditedPaste` → **다른 Unity PID의 실제 컴파일/리로드** → `VerifyEditedPasteAndLocalOriginals`로 실행한다. Label/Int64와 새 ConsumeTypes ID를 바꾼 결과를 검증하고 Local 입력의 기존 SHA를 비교한다. 기본 2행을 기대하는 Native fixture를 먼저 실행한 뒤 이 회귀를 실행한다. 추가 enum ID의 삭제/retire 승인 없이 Local 정의로 자동 되돌리지 않는다.
- `MinimalTableFlowRuntimeTests`는 type/item 정확성, Service/Provider, 중첩 거부, 종료/재시작, 전역 옵션 보존, 실패 후 재시도 및 비동기 이전 결과의 재주입 방지를 검사한다.

위 항목의 실행 여부/PASS는 통합 후보의 QA 기록에 남긴다. 이 문서 자체는 Native Unity/Player 검증 완료 증거가 아니다.

## DESIGN_REVIEW-02: Sheets 취득 경계

이 절은 현재 소스에 대한 설계 검토이며 새 Google 연동/인증 구현은 없다. AE1 Localization의 비동기·취소·전체 성공/복구 계약을 유지한다.

실제 Tables 진입점은 `Editor/TableInput.cs`의 `TableInput.FromFile/FromText`와 `Editor/CreateTable.cs`의 `Acquire/Preview/ApplyOutputs`다. `TableInputKind.SheetsInput` enum은 있지만 공개 Sheets downloader/인증/선택 경로는 없다. 현재 public `FromText`로 넘긴 결과는 PastedText 스냅샷이다. Tables의 정본/검증/적용은 게임 Schema/validator 및 TableBuilder의 manifest/journal이다.

Localization은 `com.jjevol.localization.authoring/Editor/GoogleSheetExporterWindow.cs`의 `GoogleSheetLocImporterWindow`가 URL/ID, optional API key, 자동 목록 또는 수동 sheet명을 받는다. `FetchSheetsAsync`는 API key를 붙인 Sheets v4 metadata 요청을 보내고, `DownloadAllAsync`는 sheet별 gviz CSV를 취득한다. 현재 코드에는 OAuth/서비스 계정/private-sheet 권한 위임 흐름이 없다. API key를 입력했다고 비공개 시트 접근 권한이 생기는 계약이 아니다. `LocalizationEditorHttp.GetAsync`는 Editor update 기반 timeout/cancel/reload/quit 정리를, `LocalizationHttpDiagnostics`는 비밀정보 정제를 담당한다. 두 helper는 internal이고 Localization Editor assembly 안에 있어 Tables가 그대로 호출하는 공용 SDK가 아니다.

Localization의 CSV/TSV 준비, Key/locale 검사, Locale/StringTableCollection/Addressable entry 생성과 `LocalizationImportTransaction`의 전체 준비 후 적용/복구는 도메인 책임이다. Tables의 Row Schema/FK/ConsumeTypes/compiled-generation과 합치면 서로 필요 없는 Localization/Addressables 또는 Economy 의존성이 늘어난다. `CommonDataToolSettings`는 현재 공용 경로/시트/API key 설정 interface일 뿐 취득 pipeline/인증 저장소가 아니다.

| 대안 | 제작자 사용 단계 | 구현·이행 비용 | 인증과 실패 처리 |
| --- | --- | --- | --- |
| A. Local/Paste + 외부 다운로드 유지 | Sheets에서 TSV/CSV export 또는 셀 복사 → Local/Paste → Preview → Prepare/Apply | 지금 추가 구현 없음. 게임별로 파일/경로 선택과 최신 export 여부 확인이 반복됨. 이 샘플로 이후 단계가 재현 가능함 | 브라우저/외부 도구가 인증. Framework에는 credentials 불필요. 취득 실패는 입력 이전에 처리하며 내려받은 snapshot을 review해야 함 |
| B. Tables 취득 전용 Adapter | URL/ID와 sheet 선택 → download snapshot → 기존 TableInput/Preview → 동일 Apply | 작음~중간. Tables용 선택/취득/취소/진단 adapter 및 획득 snapshot 출처 계약이 필요. Localization helper를 복사하면 유지비가 생기므로 공유 범위를 명시해야 함 | 최초 범위를 공개/이미 허용된 export로 제한할지 사용자 결정 필요. timeout/cancel/비밀 정제 및 stale-response 폐기를 검증. 다운로드가 곧 Table Apply가 되어서는 안 됨 |
| C. 선택 공용 HTTP/Sheets 입력 도구 | 공통 sheet 선택/취득 → Tables 또는 Localization에 읽기 전용 snapshot 전달 → 각자 Preview/검증/Apply | 중간~큼. internal AE1 helper의 안전한 추출/선택 의존성 설계와 양쪽 회귀 검증 필요. 신규 게임 다수/반복 자동 취득 수요가 있을 때 절감 효과 | 취득 오류/취소/진단은 공유 가능. private-sheet 인증·credential 보관·권한 범위는 별도 사용자 결정. 일부 취득 실패에서 양쪽 consumer가 임의 부분 적용하면 안 됨 |

권장: **현재 A를 유지하고 실제 반복 취득 수요가 확인되면 B 범위부터 승인한다.** 현 소스/이번 요구에서 Tables의 직접 Sheets 취득이 필수라는 근거는 없다. 게임마다 Row/Parser/관계 검증/Service는 A~C 모두 필요하며 downloader 통합으로 없어지지 않는다. A의 추가 반복은 export/파일 선택, B/C의 절감은 그 취득 단계다. C로 진행한다면 HTTP timeout/cancel/redacted diagnostics와 sheet metadata/selection/download snapshot까지만 공유하고, Tables 생성/컴파일과 Localization locale/collection/Addressables/transaction은 분리한다. AE1 Import 전체 성공 정책을 바꿀 필요는 없다.

사용자 판단 사항: 직접 취득이 필요한 실제 게임/갱신 빈도, 공개 export만 지원할지 private 인증까지 필요한지, B의 좁은 adapter와 C의 추출 비용 중 어느 범위를 승인할지. 새 인증·외부 SDK·공개 API 변경은 이번 단계에서 확정/구현하지 않는다.
