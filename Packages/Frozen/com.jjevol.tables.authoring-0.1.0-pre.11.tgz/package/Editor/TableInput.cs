using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace jjevol
{
    public enum TableInputKind { LocalFile, PastedText, SheetsInput, AppliedOutput }
    public enum TableDialect { PlainTsv, QuotedTsv, Csv }
    public enum TableDiagnosticSeverity { Info, Warning, Error }

    public sealed class TableDiagnostic
    {
        public TableDiagnosticSeverity Severity { get; }
        public string Code { get; }
        public string TableName { get; }
        public string Source { get; }
        public int Row { get; }
        public int Column { get; }
        public int Line { get; }
        public int Character { get; }
        public string Header { get; }
        public string Reason { get; }
        public int ByteOffset { get; }
        public TableDiagnostic(TableDiagnosticSeverity severity, string code, string table, string source, string reason,
            int row = 0, int column = 0, int line = 0, int character = 0, string header = "", int byteOffset = -1)
        { Severity = severity; Code = code; TableName = table; Source = source; Reason = reason; Row = row; Column = column; Line = line; Character = character; Header = header; ByteOffset = byteOffset; }
        public override string ToString() => $"{Severity} {Code}: {TableName} row {Row}, column {Column} ({Header}), line {Line}:{Character}" + (ByteOffset < 0 ? "" : ", byte " + ByteOffset) + " — " + Reason;
    }
    public sealed class TableInputException : Exception
    {
        public TableDiagnostic Diagnostic { get; }
        public TableInputException(TableDiagnostic diagnostic) : base(diagnostic?.ToString()) { Diagnostic = diagnostic ?? throw new ArgumentNullException(nameof(diagnostic)); }
    }

    /// <summary>Read-only acquisition snapshot. No source rewriting or format guessing.</summary>
    public sealed class TableInput
    {
        public string TableName { get; }
        public string Source { get; }
        public string FilePath { get; }
        public string Text { get; }
        public TableDialect Dialect { get; }
        public TableInputKind Kind { get; }
        public string EncodingName { get; }
        public bool HasBom { get; }
        public string RawHash { get; }
        public string Newlines { get; }
        private TableInput(string name, string text, TableDialect dialect, TableInputKind kind, string source, string file, string encoding, bool bom, string hash)
        {
            TableName = name; Text = text ?? throw new ArgumentNullException(nameof(text)); Dialect = dialect; Kind = kind;
            Source = source; FilePath = file; EncodingName = encoding; HasBom = bom; RawHash = hash;
            Newlines = text.Contains("\r\n") ? (text.Replace("\r\n", "").IndexOfAny(new[] { '\r', '\n' }) >= 0 ? "Mixed" : "CRLF") : text.Contains("\r") ? (text.Contains("\n") ? "Mixed" : "CR") : "LF";
        }
        public static TableInput FromText(string tableName, string text, TableDialect dialect = TableDialect.PlainTsv, string source = "clipboard snapshot")
            => Snapshot(tableName, text, dialect, TableInputKind.PastedText, source);
        internal static TableInput Snapshot(string name, string text, TableDialect dialect, TableInputKind kind, string source)
            => new TableInput(name, text, dialect, kind, source, null, "UTF-8 text", text?.StartsWith("\uFEFF", StringComparison.Ordinal) == true, TableHash.Text(text ?? ""));
        public static TableInput FromFile(string path, TableDialect dialect = TableDialect.PlainTsv)
        {
            string full = Path.GetFullPath(path); TablePaths.NoReparse(full);
            byte[] bytes = File.ReadAllBytes(full); int skip = 0; Encoding encoding = new UTF8Encoding(false, true);
            if (bytes.Length >= 4 && ((bytes[0] == 0 && bytes[1] == 0 && bytes[2] == 254 && bytes[3] == 255) || (bytes[0] == 255 && bytes[1] == 254 && bytes[2] == 0 && bytes[3] == 0)))
                throw new InvalidDataException("UTF-32 input is not supported; no source was changed.");
            if (bytes.Length >= 3 && bytes[0] == 239 && bytes[1] == 187 && bytes[2] == 191) skip = 3;
            else if (bytes.Length >= 2 && bytes[0] == 255 && bytes[1] == 254) { encoding = new UnicodeEncoding(false, true, true); skip = 2; }
            else if (bytes.Length >= 2 && bytes[0] == 254 && bytes[1] == 255) { encoding = new UnicodeEncoding(true, true, true); skip = 2; }
            string text;
            try { text = encoding.GetString(bytes, skip, bytes.Length - skip); }
            catch (DecoderFallbackException e) { throw new TableInputException(new TableDiagnostic(TableDiagnosticSeverity.Error, "InputDecode", Path.GetFileNameWithoutExtension(full), full,
                "Invalid " + encoding.WebName + " bytes; no replacement or source rewriting is permitted.", byteOffset: Math.Max(0, e.Index))); }
            return new TableInput(Path.GetFileNameWithoutExtension(full), text, dialect,
                TableInputKind.LocalFile, full, full, encoding.WebName, skip != 0, TableHash.Bytes(bytes));
        }
    }

    public sealed class TableCell
    {
        public string Value { get; }
        public int Line { get; }
        public int Character { get; }
        /// <summary>1-based column in the source input, kept when unnamed columns are dropped.</summary>
        public int Column { get; }
        /// <summary>1-based record in the source input (the header is 1), kept when blank rows are skipped. 0 when unknown.</summary>
        public int Row { get; }
        internal TableCell(string value, int line, int character, int column = 0, int row = 0) { Value = value; Line = line; Character = character; Column = column; Row = row; }
    }

    public sealed class TableDocument
    {
        public TableInput Input { get; }
        public IReadOnlyList<string> Headers { get; }
        public IReadOnlyList<IReadOnlyList<TableCell>> Records { get; }
        public IReadOnlyList<TableDiagnostic> Diagnostics { get; }
        public string RuntimeText { get; }
        public string DataHash { get; }
        public bool IsValid => Diagnostics.All(d => d.Severity != TableDiagnosticSeverity.Error);
        internal TableDocument(TableInput input, List<List<TableCell>> rows, List<TableDiagnostic> diagnostics, bool normalizedHeaders = false)
        {
            Input = input;
            Headers = Array.AsReadOnly(rows.Count == 0 ? Array.Empty<string>() : rows[0].Select(c => c.Value).ToArray());
            Records = Array.AsReadOnly(rows.Skip(1).Select(r => (IReadOnlyList<TableCell>)r.AsReadOnly()).ToArray());
            Diagnostics = diagnostics.AsReadOnly();
            RuntimeText = input.Dialect == TableDialect.PlainTsv && !normalizedHeaders ? (input.Text.StartsWith("\uFEFF", StringComparison.Ordinal) ? input.Text.Substring(1) : input.Text)
                : string.Join("\n", rows.Select(r => string.Join("\t", r.Select(c => c.Value))));
            DataHash = TableHash.Parts(rows.SelectMany(r => new[] { r.Count.ToString(CultureInfo.InvariantCulture) }.Concat(r.Select(c => c.Value))));
        }
        public static TableDocument Parse(TableInput input)
        {
            if (input == null) throw new ArgumentNullException(nameof(input));
            var diagnostics = new List<TableDiagnostic>(); var rows = new List<List<TableCell>>(); var row = new List<TableCell>();
            string text = input.Text; int i = text.StartsWith("\uFEFF", StringComparison.Ordinal) ? 1 : 0;
            int line = 1, character = 1, cellLine = 1, cellCharacter = 1;
            bool quoted = false, afterQuote = false, fieldStarted = false, endedRecord = false;
            char delimiter = input.Dialect == TableDialect.Csv ? ',' : '\t';
            var value = new StringBuilder();
            Action<string, string, int, int, int, int> error = (code, reason, r, c, l, ch) => diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, code, input.TableName, input.Source, reason, r, c, l, ch));
            if (!Enum.IsDefined(typeof(TableDialect), input.Dialect)) error("InputDialect", "Unknown explicit input dialect.", 0, 0, 0, 0);
            Action finishCell = () => { row.Add(new TableCell(value.ToString(), cellLine, cellCharacter, row.Count + 1)); value.Clear(); fieldStarted = afterQuote = false; };
            while (i < text.Length)
            {
                char ch = text[i]; endedRecord = false;
                if (quoted)
                {
                    if (ch == '"')
                    {
                        if (i + 1 < text.Length && text[i + 1] == '"') { value.Append('"'); i += 2; character += 2; continue; }
                        quoted = false; afterQuote = true; i++; character++; continue;
                    }
                    value.Append(ch);
                    if (ch == '\r' || ch == '\n')
                    {
                        if (ch == '\r' && i + 1 < text.Length && text[i + 1] == '\n') { value.Append('\n'); i++; }
                        line++; character = 1;
                    }
                    else character++;
                    i++; continue;
                }
                if (ch == delimiter || ch == '\r' || ch == '\n')
                {
                    finishCell();
                    if (ch == delimiter) { i++; character++; cellLine = line; cellCharacter = character; continue; }
                    rows.Add(row); row = new List<TableCell>();
                    if (ch == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++;
                    i++; line++; character = 1; cellLine = line; cellCharacter = 1; endedRecord = true; continue;
                }
                if (afterQuote) error("AfterClosingQuote", "Only a delimiter or record ending may follow a closing quote.", rows.Count + 1, row.Count + 1, line, character);
                if (input.Dialect != TableDialect.PlainTsv && ch == '"')
                {
                    if (fieldStarted) error("UnexpectedQuote", "A quoted field must start at the first character of the cell.", rows.Count + 1, row.Count + 1, line, character);
                    else { quoted = true; fieldStarted = true; i++; character++; continue; }
                }
                value.Append(ch); fieldStarted = true; i++; character++;
            }
            if (quoted) error("UnterminatedQuote", "Quoted field has no closing quote.", rows.Count + 1, row.Count + 1, cellLine, cellCharacter);
            if (!endedRecord && (text.Length > 0 || row.Count > 0)) { finishCell(); rows.Add(row); }
            if (rows.Count == 0) error("EmptyInput", "A header record is required.", 1, 1, 1, 1);
            bool normalized = false;
            if (rows.Count > 0) rows = NormalizeColumns(input, rows, diagnostics, out normalized);
            for (int r = 0; r < rows.Count; r++)
                foreach (TableCell cell in rows[r])
                    if (cell.Value.IndexOfAny(new[] { '\t', '\r', '\n' }) >= 0)
                        diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "RuntimeCellDelimiterUnsupported", input.TableName, input.Source,
                            "Cell contains a tab/CR/LF unsupported by the current Runtime parser. Source is unchanged.", cell.Row != 0 ? cell.Row : r + 1, cell.Column, cell.Line, cell.Character, HeaderAt(rows[0], cell.Column)));
            var document = new TableDocument(input, rows, diagnostics, normalized);
            if (document.IsValid)
            {
                var runtime = TSVRow.FromTsv(document.RuntimeText);
                if (runtime.Count != document.Records.Count || runtime.Where((r, n) => document.Headers.Where((h, c) => r.Get(h) != document.Records[n][c].Value).Any()).Any())
                    error("RuntimeRoundTrip", "Output TSV does not reproduce every expected Runtime cell.", 0, 0, 0, 0);
            }
            return document;
        }
        private static string HeaderAt(List<TableCell> header, int column) => header.FirstOrDefault(h => h.Column == column)?.Value ?? "";

        // Columns are matched by header name, never by position. A copied spreadsheet often carries
        // unnamed columns, stray spaces, short or long rows and blank rows: each is reported as a
        // warning and handled the way Runtime TSVRow reads it, instead of blocking the table.
        private static List<List<TableCell>> NormalizeColumns(TableInput input, List<List<TableCell>> rows, List<TableDiagnostic> diagnostics, out bool normalized)
        {
            bool changed = false;
            Action<string, string, int, int, TableCell, string> warn = (code, reason, r, c, anchor, header) => diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Warning, code, input.TableName, input.Source,
                reason, r, c, anchor?.Line ?? 0, anchor?.Character ?? 0, header));
            List<TableCell> source = rows[0]; var kept = new List<int>(); var header = new List<TableCell>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int c = 0; c < source.Count; c++)
            {
                TableCell cell = source[c]; string name = TSVRow.NormalizeHeader(cell.Value);
                if (name.Length == 0)
                {
                    bool hasData = rows.Skip(1).Any(r => c < r.Count && r[c].Value.Trim().Length != 0);
                    warn("UnnamedColumn", hasData ? "Column has no header name. Its values are ignored." : "Column has no header name and is ignored.", 1, c + 1, cell, "");
                    changed = true; continue;
                }
                if (name != cell.Value) { warn("HeaderSpacing", "Header '" + cell.Value + "' is read as '" + name + "'.", 1, c + 1, cell, name); changed = true; }
                if (!seen.Add(name))
                    diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "DuplicateHeader", input.TableName, input.Source,
                        "Header duplicates another header, ignoring case and surrounding spaces.", 1, c + 1, cell.Line, cell.Character, name));
                kept.Add(c); header.Add(new TableCell(name, cell.Line, cell.Character, c + 1, 1));
            }
            if (header.Count == 0) diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "EmptyHeader", input.TableName, input.Source, "No column has a header name.", 1, 1, 1, 1));
            var result = new List<List<TableCell>> { header };
            for (int r = 1; r < rows.Count; r++)
            {
                List<TableCell> row = rows[r]; TableCell last = row[row.Count - 1];
                var cells = kept.Select(c => c < row.Count ? new TableCell(row[c].Value, row[c].Line, row[c].Character, c + 1, r + 1) : new TableCell("", last.Line, last.Character, c + 1, r + 1)).ToList();
                if (cells.All(cell => cell.Value.Trim().Length == 0))
                {
                    warn("BlankRecord", "Row has no values in named columns and is skipped.", r + 1, 1, row[0], "");
                    changed = true; continue;
                }
                if (row.Count > source.Count)
                {
                    if (row.Skip(source.Count).Any(cell => cell.Value.Trim().Length != 0))
                        warn("ExtraCells", "Row has values to the right of the last header. They are ignored.", r + 1, source.Count + 1, row[source.Count], "(no header)");
                    changed = true;
                }
                else if (row.Count < source.Count)
                {
                    warn("MissingCells", "Row is shorter than the header. Missing cells are read as empty.", r + 1, row.Count + 1, last, TSVRow.NormalizeHeader(source[row.Count].Value));
                    changed = true;
                }
                result.Add(cells);
            }
            normalized = changed;
            return result;
        }
        internal TableDocument WithHeaders(IReadOnlyList<string> headers)
        {
            if (headers.Count != Headers.Count) throw new ArgumentException("Mapping cannot add or discard columns.");
            var rows = new List<List<TableCell>> { headers.Select((name, c) => new TableCell(name, 1, c + 1, c + 1)).ToList() };
            rows.AddRange(Records.Select(r => r.ToList()));
            var diagnostics = Diagnostics.ToList();
            var mapped = new TableDocument(Input, rows, diagnostics, true);
            // Validate the normalized wire using the same parser and the actual Runtime TSVRow.
            var check = Parse(TableInput.FromText(Input.TableName, mapped.RuntimeText, TableDialect.PlainTsv, Input.Source));
            if (!check.IsValid || !check.Headers.SequenceEqual(headers) || check.Records.Count != Records.Count ||
                check.Records.Where((r, n) => r.Where((cell, c) => cell.Value != Records[n][c].Value).Any()).Any())
                diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "MappedRuntimeRoundTrip", Input.TableName, Input.Source, "Normalized headers/values cannot round-trip through the Runtime parser."));
            return mapped;
        }
    }

    public enum TableColumnKind { Text, Int32, Int64 }
    public sealed class TableColumnRule
    {
        public string Name { get; }
        public TableColumnKind Kind { get; }
        public bool Required { get; }
        public bool Unique { get; }
        public long? Minimum { get; }
        public long? Maximum { get; }
        public TableColumnRule(string name, TableColumnKind kind = TableColumnKind.Text, bool required = true, bool unique = false, long? minimum = null, long? maximum = null)
        {
            if (string.IsNullOrEmpty(name) || !Enum.IsDefined(typeof(TableColumnKind), kind) || (minimum.HasValue && maximum.HasValue && minimum.Value > maximum.Value)) throw new ArgumentException("Invalid column schema.");
            Name = name; Kind = kind; Required = required; Unique = unique; Minimum = minimum; Maximum = maximum;
        }
    }
    public sealed class TableSchema
    {
        public string TableName { get; }
        public IReadOnlyList<TableColumnRule> Columns { get; }
        public TableSchema(string tableName, params TableColumnRule[] columns)
        {
            if (string.IsNullOrEmpty(tableName) || columns == null || columns.Any(c => c == null) || columns.Select(c => c.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != columns.Length) throw new ArgumentException("Invalid table schema.");
            TableName = tableName; Columns = Array.AsReadOnly(columns.ToArray());
        }
        internal TableColumnRule Find(string header) => Columns.FirstOrDefault(c => string.Equals(c.Name, header, StringComparison.OrdinalIgnoreCase));

        /// <summary>
        /// Human-readable label column every game table may carry (JJEvol table spec v1.1, sections 3.1–3.2).
        /// It stays in the TSV and Runtime output but no Runtime code reads it; game text uses language keys.
        /// A schema that declares its own column of this name governs it instead.
        /// </summary>
        internal const string HumanNameColumn = "name";

        /// <summary>Spells each header as its declared column; headers the schema does not declare are reported and kept.</summary>
        internal TableDocument Canonicalize(TableDocument document, List<TableDiagnostic> diagnostics)
        {
            if (!document.IsValid) return document;
            var headers = new List<string>(); bool renamed = false;
            for (int c = 0; c < document.Headers.Count; c++)
            {
                string header = document.Headers[c]; TableColumnRule rule = Find(header);
                string canonical = rule?.Name ?? (string.Equals(header, HumanNameColumn, StringComparison.OrdinalIgnoreCase) ? HumanNameColumn : null);
                if (canonical == null)
                    diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Warning, "UnusedColumn", document.Input.TableName, document.Input.Source,
                        "Column is not declared in the game schema. It is kept but not checked.", 1, c + 1, 1, 0, header));
                else if (canonical != header)
                {
                    diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Warning, "HeaderCase", document.Input.TableName, document.Input.Source,
                        "Header '" + header + "' is read as " + (rule != null ? "schema" : "common") + " column '" + canonical + "'.", 1, c + 1, 1, 0, canonical));
                    header = canonical; renamed = true;
                }
                headers.Add(header);
            }
            return renamed ? document.WithHeaders(headers) : document;
        }
        internal void Validate(TableDocument document, List<TableDiagnostic> diagnostics)
        {
            foreach (TableColumnRule rule in Columns)
            {
                int index = document.Headers.ToList().FindIndex(h => string.Equals(h, rule.Name, StringComparison.OrdinalIgnoreCase)); var seen = new HashSet<string>(StringComparer.Ordinal);
                if (index < 0)
                {
                    // A required column cannot be read without its values. Other declared columns fall back to the row parser's defaults.
                    if (rule.Required) diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "MissingColumn", document.Input.TableName, document.Input.Source, "Missing required schema column: " + rule.Name, header: rule.Name));
                    else diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Warning, "MissingColumn", document.Input.TableName, document.Input.Source, "Missing optional schema column: " + rule.Name + ". Rows use the parser's default value.", header: rule.Name));
                    continue;
                }
                for (int r = 0; r < document.Records.Count; r++)
                {
                    TableCell cell = document.Records[r][index]; string value = cell.Value; string reason = null;
                    if (value.Length == 0) { if (rule.Required) reason = "Required cell is empty."; }
                    else if (rule.Kind != TableColumnKind.Text)
                    {
                        if (!long.TryParse(value, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out long number) ||
                            (rule.Kind == TableColumnKind.Int32 && (number < int.MinValue || number > int.MaxValue))) reason = "Invalid integer or overflow; no default value is substituted.";
                        else if ((rule.Minimum.HasValue && number < rule.Minimum.Value) || (rule.Maximum.HasValue && number > rule.Maximum.Value)) reason = "Integer is outside the declared range.";
                    }
                    // An empty optional cell has no value to collide; Required already reports the empty case.
                    if (rule.Unique && value.Length != 0 && !seen.Add(value)) reason = "Duplicate value in a unique schema column.";
                    if (reason != null) diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "SchemaValue", document.Input.TableName, document.Input.Source, reason, cell.Row != 0 ? cell.Row : r + 2, cell.Column != 0 ? cell.Column : index + 1, cell.Line, cell.Character, rule.Name));
                }
            }
        }
    }

    internal static class TableHash
    {
        internal static string Bytes(byte[] value) { using var sha = SHA256.Create(); return BitConverter.ToString(sha.ComputeHash(value)).Replace("-", "").ToLowerInvariant(); }
        internal static string Text(string value) => Bytes(new UTF8Encoding(false, true).GetBytes(value));
        // Every generated output is UTF-8 text, so a CRLF conversion alone is not a content change.
        // Files with no CRLF hash as their exact bytes. The journal keeps exact Bytes for restoration.
        internal static string Content(byte[] value) => Bytes(Lf(value));
        internal static string Content(string value) => Text(Lf(value));
        internal static bool SameContent(string first, string second) => Lf(first) == Lf(second);
        // An encrypted output has no CR, but its plaintext may: such a record holds the exact plaintext hash.
        internal static bool MatchesPlain(string recorded, string text) => recorded == Text(text) || recorded == Content(text);
        private static string Lf(string value) => value.Replace("\r\n", "\n");
        private static byte[] Lf(byte[] value)
        {
            using var stream = new MemoryStream(value.Length);
            for (int i = 0; i < value.Length; i++)
                if (value[i] != '\r' || i + 1 == value.Length || value[i + 1] != '\n') stream.WriteByte(value[i]);
            return stream.ToArray();
        }
        internal static string Parts(IEnumerable<string> values)
        { using var stream = new MemoryStream(); using (var writer = new BinaryWriter(stream, new UTF8Encoding(false, true), true)) foreach (string value in values) writer.Write(value ?? ""); return Bytes(stream.ToArray()); }
    }
}
