using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;

namespace jjevol
{
    public enum TableBuildOperation { Upsert, Full, Remove }
    public enum TableOutputAction { Create, Update, Unchanged, Delete, Adopt, Conflict }

    public sealed class TableBuildRequest
    {
        public IReadOnlyList<TableInput> Inputs { get; }
        public string OutputDirectory { get; }
        public TableBuildOperation Operation { get; }
        public IReadOnlyList<string> Selected { get; }
        public IReadOnlyList<string> Adopt { get; }
        public bool CompleteCatalog { get; }
        public bool RequireValidator { get; }
        public string ValidationVersion { get; }
        public IReadOnlyList<TableSchema> Schemas { get; }
        public string CatalogDirectory { get; }
        public bool UseEncrypt { get; }
        public ConsumeTypesGenerationSettings ConsumeTypes { get; }
        public IReadOnlyList<TableColumnMapping> ColumnMappings { get; }
        internal Action<IReadOnlyList<TableBuildInput>> Validator { get; }
        public TableBuildRequest(IEnumerable<TableInput> inputs, string outputDirectory, bool useEncrypt = true,
            TableBuildOperation operation = TableBuildOperation.Upsert, IEnumerable<string> selected = null, bool completeCatalog = false,
            IEnumerable<string> adopt = null, Action<IReadOnlyList<TableBuildInput>> validate = null, bool requireValidator = false,
            string validationVersion = "1", IEnumerable<TableSchema> schemas = null, string catalogDirectory = null,
            ConsumeTypesGenerationSettings consumeTypes = null, IEnumerable<TableColumnMapping> columnMappings = null)
        {
            Inputs = Array.AsReadOnly((inputs ?? throw new ArgumentNullException(nameof(inputs))).ToArray());
            if (Inputs.Any(i => i == null)) throw new ArgumentException("An input is null.");
            OutputDirectory = outputDirectory; UseEncrypt = useEncrypt; Operation = operation; CompleteCatalog = completeCatalog;
            Selected = Array.AsReadOnly((operation == TableBuildOperation.Full ? Inputs.Select(i => i.TableName) : selected ?? Inputs.Select(i => i.TableName)).ToArray());
            Adopt = Array.AsReadOnly((adopt ?? Array.Empty<string>()).ToArray());
            Validator = validate; RequireValidator = requireValidator; ValidationVersion = validationVersion ?? "";
            Schemas = Array.AsReadOnly((schemas ?? Array.Empty<TableSchema>()).ToArray());
            CatalogDirectory = catalogDirectory == null ? null : Path.GetFullPath(catalogDirectory);
            ConsumeTypes = consumeTypes;
            ColumnMappings = Array.AsReadOnly((columnMappings ?? Array.Empty<TableColumnMapping>()).ToArray());
            if (ColumnMappings.Any(m => m == null) || ColumnMappings.Select(m => m.TableName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != ColumnMappings.Count)
                throw new ArgumentException("Column mapping must have one explicit entry per table.");
        }
    }

    public sealed class TableOutputChange
    {
        public string TableName { get; }
        public string Path { get; }
        public TableOutputAction Action { get; }
        public string Reason { get; }
        public string ExistingHash { get; }
        public string ExistingMetaHash { get; }
        public string ExistingGuid { get; }
        internal TableDocument Document { get; }
        internal TableOutputChange(string name, string path, TableOutputAction action, string reason, TableDocument document = null)
        {
            TableName = name; Path = path; Action = action; Reason = reason; Document = document;
            ExistingHash = TablePaths.HashFile(path); ExistingMetaHash = TablePaths.HashFile(path + ".meta"); ExistingGuid = TablePaths.Guid(path + ".meta");
        }
    }

    public sealed class TableBuildPlan
    {
        public TableBuildRequest Request { get; }
        public string OutputDirectory { get; }
        public string ManifestPath { get; }
        public string Fingerprint { get; }
        public IReadOnlyList<TableDiagnostic> Diagnostics { get; }
        public IReadOnlyList<TableOutputChange> Changes { get; }
        public IReadOnlyList<string> Coverage { get; }
        public IReadOnlyList<TableBuildInput> ValidationInputs { get; }
        public ConsumeTypesCodePlan ConsumeTypes { get; }
        public bool IsValid => Diagnostics.All(d => d.Severity != TableDiagnosticSeverity.Error);
        internal readonly Func<byte[], byte[]> Encrypt, Decrypt;
        internal readonly Action<IReadOnlyList<TableBuildInput>> Validator;
        internal readonly bool GlobalValidator;
        internal readonly string CodecVersion, GlobalValidationVersion, ManifestHash, Inventory, CatalogInventory;
        internal readonly TableManifest Basis;
        internal readonly Dictionary<string, string> Preconditions;
        internal readonly string ManagedCodeInventory;
        internal TableBuildPlan(TableBuildRequest request)
        {
            Request = request; OutputDirectory = TablePaths.Output(request.OutputDirectory);
            ManifestPath = TablePaths.Manifest(OutputDirectory);
            // A Windows native move can create a 260-character meta that managed verification and
            // recovery cannot read. Reject needed paths before reading ownership or preparing writes.
            TablePaths.RequireWindowsFile(ManifestPath); TablePaths.RequireWindowsFile(ManifestPath + ".pending");
            foreach (string name in request.Selected)
            {
                if (request.ConsumeTypes != null && string.Equals(name, request.ConsumeTypes.TableName, StringComparison.OrdinalIgnoreCase)) continue;
                TablePaths.Name(name);
                string path = Path.Combine(OutputDirectory, name + ".txt");
                TablePaths.RequireWindowsFile(path); TablePaths.RequireWindowsFile(path + ".meta");
            }
            if (request.ConsumeTypes != null && request.Selected.Contains(request.ConsumeTypes.TableName, StringComparer.OrdinalIgnoreCase))
                foreach (string path in ConsumeTypesCodeGenerator.SourcePaths(request.ConsumeTypes.OutputDirectory, request.ConsumeTypes.EnumName))
                { TablePaths.RequireWindowsFile(path); TablePaths.RequireWindowsFile(path + ".meta"); }
            TablePaths.NoReparse(ManifestPath);
            Encrypt = TableAuthoringOptions.EncryptBytes; Decrypt = TableRuntimeOptions.DecryptBytes;
            Validator = request.Validator ?? TableAuthoringOptions.ValidateTables; GlobalValidator = request.Validator == null;
            CodecVersion = TableAuthoringOptions.CodecProfileVersion ?? ""; GlobalValidationVersion = TableAuthoringOptions.ValidationVersion ?? "";
            ManifestHash = TablePaths.HashFile(ManifestPath); Basis = TableManifest.Read(ManifestPath, OutputDirectory);
            Inventory = TablePaths.Inventory(OutputDirectory); CatalogInventory = request.CatalogDirectory == null ? "" : TablePaths.InputInventory(request.CatalogDirectory);
            Preconditions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) { [ManifestPath] = ManifestHash };
            Preconditions[ManifestPath + ".pending"] = TablePaths.HashFile(ManifestPath + ".pending");
            if (Basis.consume != null)
            {
                ConsumeTypesCodeGenerator.ValidateRecord(Basis.consume);
                string codeRoot = ConsumeTypesCodeGenerator.CodeRoot(Path.Combine(TablePaths.Project, Basis.consume.output));
                foreach (string path in ConsumeTypesCodeGenerator.Paths(Basis.consume))
                {
                    TablePaths.RequireWindowsFile(path); TablePaths.RequireWindowsFile(path + ".meta");
                    Preconditions[path] = TablePaths.HashFile(path); Preconditions[path + ".meta"] = TablePaths.HashFile(path + ".meta");
                }
                ManagedCodeInventory = TablePaths.Inventory(codeRoot);
            }
            var diagnostics = new List<TableDiagnostic>(); var changes = new List<TableOutputChange>(); var documents = new List<TableDocument>();
            var coverage = new List<string> { "Structure + exact Runtime TSV cell round-trip" };
            Action<string, string, string> error = (code, table, reason) => diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, code, table, "build plan", reason));
            if (!Enum.IsDefined(typeof(TableBuildOperation), request.Operation)) error("Operation", "", "Unknown operation.");
            if (Basis.status != "Ready") error("RecoveryRequired", "", "A previous build is incomplete. Recover before making another plan.");
            bool IsDefinition(string name) => request.ConsumeTypes != null && string.Equals(name, request.ConsumeTypes.TableName, StringComparison.OrdinalIgnoreCase);
            bool runtimeSelected = request.Selected.Any(n => !IsDefinition(n));
            if (request.UseEncrypt && runtimeSelected && (Encrypt == null || Decrypt == null)) error("MissingCodec", "", "Both Host encryption and decryption are required.");
            if (request.ConsumeTypes != null && request.Operation == TableBuildOperation.Remove) error("ConsumeRemoveScope", "", "Remove targets managed Runtime tables. Retire ConsumeTypes IDs through an explicit definition migration.");
            if (request.ConsumeTypes != null && Basis.tables.Any(t => IsDefinition(t.name))) error("ConsumeRoleConflict", request.ConsumeTypes.TableName, "Explicitly remove the old managed Runtime table before assigning its name an Authoring-only role.");
            if (Basis.consume != null)
                foreach (var file in Basis.consume.files)
                    foreach (var difference in TableFiles.Compare(file.name, Path.Combine(TablePaths.Project, Basis.consume.output, file.name), file.hash, file.metaHash, file.guid))
                        error("GeneratedManagedConflict", file.name, difference + ". Table-only builds cannot hide the conflict. " + TableFiles.NextStep);
            if (request.RequireValidator && Validator == null) error("MissingValidator", "", "Required game validator is not configured (schemas do not imply FK/business validation).");
            if (request.Operation == TableBuildOperation.Full && !request.CompleteCatalog) error("IncompleteCatalog", "", "Full requires an explicitly complete catalog.");
            if (request.Operation != TableBuildOperation.Remove && request.Inputs.Count == 0) error("EmptyCatalog", "", "Empty input never implies removing all outputs.");
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (TableInput input in request.Inputs)
            {
                TablePaths.Name(input.TableName);
                if (!names.Add(input.TableName)) error("DuplicateTable", input.TableName, "Multiple inputs map to the same output name.");
                if (input.FilePath != null)
                {
                    TablePaths.Disjoint(Path.GetDirectoryName(input.FilePath), OutputDirectory);
                    Preconditions[input.FilePath] = input.RawHash;
                }
            }
            if (request.CatalogDirectory != null) TablePaths.Disjoint(request.CatalogDirectory, OutputDirectory);
            var selected = new HashSet<string>(request.Selected, StringComparer.OrdinalIgnoreCase);
            if (request.Operation == TableBuildOperation.Full) selected = names;
            if (selected.Count != request.Selected.Count && request.Operation != TableBuildOperation.Full) error("DuplicateSelection", "", "Selection contains duplicate names.");
            if (selected.Count == 0) error("EmptySelection", "", "Select at least one table; use explicit Remove for deletion.");
            foreach (string name in selected)
            {
                TablePaths.Name(name);
                if (request.Operation != TableBuildOperation.Remove && !names.Contains(name)) error("MissingSelection", name, "Selected input was not acquired.");
            }
            foreach (var record in Basis.tables)
            {
                TablePaths.Name(record.name); string path = TablePaths.RecordPath(OutputDirectory, record);
                TablePaths.RequireWindowsFile(path); TablePaths.RequireWindowsFile(path + ".meta");
                Preconditions[path] = TablePaths.HashFile(path); Preconditions[path + ".meta"] = TablePaths.HashFile(path + ".meta");
                foreach (var difference in TableFiles.Compare(record.name, path, record.hash, record.metaHash, record.guid))
                    error("ManagedConflict", record.name, difference + ". No automatic overwrite or deletion. " + TableFiles.NextStep);
            }
            foreach (TableInput input in request.Inputs.Where(i => selected.Contains(i.TableName) && request.Operation != TableBuildOperation.Remove))
            {
                TableDocument document = TableDocument.Parse(input);
                var mapping = request.ColumnMappings.SingleOrDefault(m => string.Equals(m.TableName, input.TableName, StringComparison.OrdinalIgnoreCase));
                if (mapping != null)
                {
                    if (IsDefinition(input.TableName)) error("ColumnMapping", input.TableName, "ConsumeTypes uses fixed headers and cannot be mapped.");
                    else document = mapping.Apply(document, request.Schemas.SingleOrDefault(s => string.Equals(s.TableName, input.TableName, StringComparison.OrdinalIgnoreCase)), diagnostics);
                }
                var declared = IsDefinition(input.TableName) ? null : request.Schemas.SingleOrDefault(s => string.Equals(s.TableName, input.TableName, StringComparison.OrdinalIgnoreCase));
                if (declared != null) document = declared.Canonicalize(document, diagnostics);
                documents.Add(document); diagnostics.AddRange(document.Diagnostics);
            }
            foreach (var mapping in request.ColumnMappings)
                if (!selected.Contains(mapping.TableName) || !request.Inputs.Any(i => string.Equals(i.TableName, mapping.TableName, StringComparison.OrdinalIgnoreCase)))
                    error("ColumnMapping", mapping.TableName, "Mapping must refer to a selected acquired table.");
            foreach (var record in Basis.tables.Where(t => !selected.Contains(t.name) && request.Operation != TableBuildOperation.Full))
            {
                try
                {
                    var document = TableFiles.ReadApplied(TablePaths.RecordPath(OutputDirectory, record), record, Decrypt);
                    if (!TableHash.MatchesPlain(record.plainHash, document.RuntimeText)) throw new InvalidDataException();
                    documents.Add(document);
                }
                catch { error("AppliedContextUnavailable", record.name, "Cannot verify the actual applied nonselected table. It is not replaced by pending source data."); }
            }
            foreach (var schema in request.Schemas)
            {
                var document = documents.FirstOrDefault(d => string.Equals(d.Input.TableName, schema.TableName, StringComparison.OrdinalIgnoreCase));
                if (document == null) error("SchemaContextMissing", schema.TableName, "Schema target is not in the acquired/applied validation context.");
                else if (document.IsValid) schema.Validate(document, diagnostics);
                coverage.Add("Schema: " + schema.TableName + " — " + string.Join(", ", schema.Columns.Select(c => c.Name + " " + c.Kind + (c.Required ? " required" : " optional") + (c.Unique ? " unique" : ""))));
            }
            if (request.ConsumeTypes != null)
            {
                var definition = documents.FirstOrDefault(d => IsDefinition(d.Input.TableName) && d.Input.Kind != TableInputKind.AppliedOutput);
                ConsumeTypes = new ConsumeTypesCodePlan(definition, request.ConsumeTypes, Basis, OutputDirectory, ManifestPath, diagnostics, Preconditions);
                coverage.Add("ConsumeTypes: signed Int32, C# symbols, ID history and explicit generated source/meta ownership; compilation remains pending until loaded generation verification.");
                foreach (var input in request.Inputs.Where(i => i.FilePath != null)) TablePaths.Disjoint(Path.GetDirectoryName(input.FilePath), Path.GetDirectoryName(ConsumeTypes.Changes[0].Path));
                if (request.CatalogDirectory != null) TablePaths.Disjoint(request.CatalogDirectory, Path.GetDirectoryName(ConsumeTypes.Changes[0].Path));
            }
            ValidationInputs = Array.AsReadOnly(documents.Where(d => d.IsValid).OrderBy(d => d.Input.TableName, StringComparer.Ordinal).Select(d => new TableBuildInput(d)).ToArray());
            if (Validator != null)
            {
                bool canValidate = !diagnostics.Any(d => d.Severity == TableDiagnosticSeverity.Error);
                coverage.Add((canValidate ? "Game validator: " : "NOT RUN: game validator (prerequisite errors): ") + request.ValidationVersion + "/" + GlobalValidationVersion);
                if (canValidate)
                    try { Validator(ValidationInputs); }
                    catch (TableInputException e) { diagnostics.Add(e.Diagnostic); }
                    catch (Exception e) { error("GameValidation", "", "Game validator rejected data (" + e.GetType().Name + "). Provider details are not logged."); }
            }
            else
            {
                coverage.Add("NOT VALIDATED: cross-table FK/business rules and fields outside declared schemas");
                diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Warning, "StructuralOnly", "", "build plan", "Only structure, Runtime compatibility and declared schema columns are checked. Other IDs/FK/quantities need a game validator; mark it required when needed."));
            }
            if (request.UseEncrypt && runtimeSelected && CodecVersion.Length == 0) diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Warning, "UnversionedCodec", "", "build plan", "Host codec has no declared version. No-op still requires current decoder equivalence; declare a version for key/configuration migration."));
            foreach (TableDocument doc in documents.Where(d => selected.Contains(d.Input.TableName) && !IsDefinition(d.Input.TableName) && d.Input.Kind != TableInputKind.AppliedOutput))
            {
                string path = Path.Combine(OutputDirectory, doc.Input.TableName + ".txt"); var previous = Basis.tables.SingleOrDefault(t => string.Equals(t.name, doc.Input.TableName, StringComparison.OrdinalIgnoreCase));
                if (previous != null && previous.name != doc.Input.TableName) error("TableNameCaseChange", doc.Input.TableName, "A case-only table rename is ambiguous across file systems; use an explicit migration.");
                Preconditions[path] = TablePaths.HashFile(path); Preconditions[path + ".meta"] = TablePaths.HashFile(path + ".meta");
                TableOutputAction action = File.Exists(path) ? TableOutputAction.Update : TableOutputAction.Create; string reason = "Selected input";
                if (previous == null && (File.Exists(path) || File.Exists(path + ".meta")))
                {
                    if (request.Adopt.Contains(doc.Input.TableName, StringComparer.OrdinalIgnoreCase)) { action = TableOutputAction.Adopt; reason = "Explicit adoption of the previewed current bytes/meta/GUID"; }
                    else { action = TableOutputAction.Conflict; reason = "Unmanaged output requires explicit adoption"; error("UnmanagedConflict", doc.Input.TableName, reason); }
                }
                else if (previous != null && doc.IsValid && previous.encrypted == request.UseEncrypt && previous.codec == CodecVersion && TableHash.MatchesPlain(previous.plainHash, doc.RuntimeText))
                {
                    try
                    {
                        if (TableHash.SameContent(TableBuilder.Decode(File.ReadAllBytes(path), previous.encrypted, Decrypt), doc.RuntimeText)) { action = TableOutputAction.Unchanged; reason = "Same bytes/metadata and current decoder reproduces the expected plaintext"; }
                        else error("DecoderMismatch", doc.Input.TableName, "Current decoder did not reproduce the previously validated plaintext.");
                    }
                    catch { error("DecoderMismatch", doc.Input.TableName, "Current decoder cannot read the previously applied output."); }
                }
                changes.Add(new TableOutputChange(doc.Input.TableName, path, action, reason, doc));
            }
            if (request.Operation == TableBuildOperation.Full || request.Operation == TableBuildOperation.Remove)
                foreach (var record in Basis.tables.Where(t => request.Operation == TableBuildOperation.Full ? !names.Contains(t.name) : selected.Contains(t.name)))
                    changes.Add(new TableOutputChange(record.name, TablePaths.RecordPath(OutputDirectory, record), TableOutputAction.Delete, "Explicit " + request.Operation + "; ownership and unchanged bytes/meta/GUID verified"));
            if (request.Operation == TableBuildOperation.Remove)
                foreach (string name in selected.Where(n => !Basis.tables.Any(t => string.Equals(t.name, n, StringComparison.OrdinalIgnoreCase)))) error("UnmanagedRemove", name, "Remove only accepts recorded managed table names.");
            if (Directory.Exists(OutputDirectory))
                foreach (string path in Directory.GetFiles(OutputDirectory).Where(p => string.Equals(Path.GetExtension(p), ".txt", StringComparison.OrdinalIgnoreCase) && !Basis.tables.Any(t => string.Equals(t.name, Path.GetFileNameWithoutExtension(p), StringComparison.OrdinalIgnoreCase))))
                    diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Info, "UnmanagedFile", Path.GetFileNameWithoutExtension(path), path, "Unmanaged file is preserved unless explicitly adopted in this selection."));
            Diagnostics = diagnostics.AsReadOnly(); Changes = changes.AsReadOnly(); Coverage = coverage.AsReadOnly();
            Fingerprint = TableHash.Parts(new[] { OutputDirectory, request.Operation.ToString(), request.CompleteCatalog.ToString(), request.UseEncrypt.ToString(), CodecVersion, request.ValidationVersion, GlobalValidationVersion, DelegateId(Validator), DelegateId(Encrypt), DelegateId(Decrypt), ManifestHash, Inventory, CatalogInventory, request.ConsumeTypes?.Fingerprint ?? "", ConsumeTypes?.Inventory ?? "", ManagedCodeInventory ?? "" }
                .Concat(request.Inputs.SelectMany(i => new[] { i.TableName, i.RawHash, i.Dialect.ToString() })).Concat(request.ColumnMappings.Select(m => m.Fingerprint)).Concat(selected.OrderBy(s => s, StringComparer.Ordinal)).Concat(request.Adopt.OrderBy(s => s, StringComparer.Ordinal))
                .Concat(request.Schemas.SelectMany(s => new[] { s.TableName }.Concat(s.Columns.Select(c => c.Name + ":" + c.Kind + ":" + c.Required + ":" + c.Unique + ":" + c.Minimum?.ToString(System.Globalization.CultureInfo.InvariantCulture) + ":" + c.Maximum?.ToString(System.Globalization.CultureInfo.InvariantCulture))))));
        }
        private static string DelegateId(Delegate value) => value == null ? "none" : string.Join(";", value.GetInvocationList().Select(d => d.Method.DeclaringType?.AssemblyQualifiedName + ":" + d.Method.Name + ":" + d.Method.Module.ModuleVersionId + ":" + d.Method.MetadataToken));
        internal void EnsureFresh()
        {
            if (!IsValid) throw Diagnostics.Any(d => d.Code == "MissingCodec" || d.Code == "MissingValidator") ? new InvalidOperationException("Required validator/codec is missing.") : new InvalidDataException("Table plan has validation errors: " + string.Join(", ", Diagnostics.Where(d => d.Severity == TableDiagnosticSeverity.Error).Select(d => d.Code.EndsWith("ManagedConflict", StringComparison.Ordinal) ? d.Code + " (" + d.Reason + ")" : d.Code)));
            TablePaths.Output(OutputDirectory); TablePaths.NoReparse(ManifestPath);
            if (!Equals(Encrypt, TableAuthoringOptions.EncryptBytes) || !Equals(Decrypt, TableRuntimeOptions.DecryptBytes) || CodecVersion != (TableAuthoringOptions.CodecProfileVersion ?? "") ||
                GlobalValidationVersion != (TableAuthoringOptions.ValidationVersion ?? "") || (GlobalValidator && !Equals(Validator, TableAuthoringOptions.ValidateTables)))
                throw new InvalidOperationException("Validator/codec settings changed after Preview; make a new plan.");
            foreach (var pair in Preconditions) { TablePaths.NoReparse(pair.Key); if (TablePaths.HashFile(pair.Key) != pair.Value) throw new IOException("Input/output/manifest changed after Preview; make a new plan."); }
            if (Inventory != TablePaths.Inventory(OutputDirectory) || (Request.CatalogDirectory != null && CatalogInventory != TablePaths.InputInventory(Request.CatalogDirectory))) throw new IOException("Input/output catalog changed after Preview; make a new plan.");
            CheckCodeFreshness();
            // Also catches a mutable game validator that starts rejecting the same frozen data.
            if (Validator != null) { try { Validator(ValidationInputs); } catch (Exception e) { throw new InvalidDataException("Frozen input validation failed (" + e.GetType().Name + ")."); } }
            // An impure callback may itself change files/settings; recheck after calling game code.
            if (!Equals(Encrypt, TableAuthoringOptions.EncryptBytes) || !Equals(Decrypt, TableRuntimeOptions.DecryptBytes) || CodecVersion != (TableAuthoringOptions.CodecProfileVersion ?? "") || GlobalValidationVersion != (TableAuthoringOptions.ValidationVersion ?? "") || (GlobalValidator && !Equals(Validator, TableAuthoringOptions.ValidateTables))) throw new InvalidOperationException("Settings changed during validation.");
            foreach (var pair in Preconditions) if (TablePaths.HashFile(pair.Key) != pair.Value) throw new IOException("Files changed during validation.");
            if (Inventory != TablePaths.Inventory(OutputDirectory) || (Request.CatalogDirectory != null && CatalogInventory != TablePaths.InputInventory(Request.CatalogDirectory))) throw new IOException("Catalog changed during validation.");
            CheckCodeFreshness();
        }
        private void CheckCodeFreshness()
        {
            if (Basis.consume != null && ManagedCodeInventory != TablePaths.Inventory(ConsumeTypesCodeGenerator.CodeRoot(Path.Combine(TablePaths.Project, Basis.consume.output))))
                throw new IOException("Managed code inventory changed after Preview.");
            if (ConsumeTypes != null)
            {
                string root = ConsumeTypesCodeGenerator.CodeRoot(Request.ConsumeTypes.OutputDirectory);
                if (ConsumeTypes.Inventory != TablePaths.Inventory(root) || ConsumeTypes.AssemblyDefinitionPath != ConsumeTypesCodeGenerator.AssemblyDefinition(root))
                    throw new IOException("Code output/assembly boundary changed after Preview.");
                var diagnostics = new List<TableDiagnostic>(); ConsumeTypesCodeGenerator.CheckOwners(ConsumeTypes.Record, ManifestPath, diagnostics);
                if (diagnostics.Count != 0) throw new IOException("Another generation acquired this code output/type identity.");
            }
        }
    }

    [Serializable] internal sealed class TableManagedRecord
    {
        public string name, hash, metaHash, guid, plainHash, sourceHash, source, sourceKind, codec;
        public bool encrypted;
    }
    [Serializable] internal sealed class TableManifest
    {
        public int version = 1;
        public string output, status = "Ready", journal = "";
        public List<TableManagedRecord> tables = new List<TableManagedRecord>();
        public bool hasConsume;
        public ConsumeCodeRecord consume;
        internal static TableManifest Read(string path, string output)
        {
            if (File.Exists(path + ".pending"))
            {
                TablePaths.NoReparse(path + ".pending");
                return new TableManifest { output = TablePaths.Relative(output), status = "RecoveryRequired" };
            }
            if (!File.Exists(path)) return new TableManifest { output = TablePaths.Relative(output) };
            TableManifest value;
            try { value = Parse(File.ReadAllText(path, new UTF8Encoding(false, true))); }
            catch { throw new InvalidDataException("Invalid table build manifest; explicit recovery is required."); }
            if (value == null || (value.version != 1 && (value.version != 2 || !value.hasConsume)) || value.output != TablePaths.Relative(output) || value.tables == null || value.tables.Any(t => t == null) || value.tables.Select(t => t.name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != value.tables.Count)
                throw new InvalidDataException("Invalid or foreign table build manifest.");
            if (value.consume != null) ConsumeTypesCodeGenerator.ValidateRecord(value.consume);
            return value;
        }
        internal static TableManifest Parse(string text)
        {
            var value = JsonUtility.FromJson<TableManifest>(text);
            // JsonUtility serializes null inline classes as empty objects. The explicit role bit
            // distinguishes absent legacy data from an actual managed code generation.
            if (value != null && !value.hasConsume)
            {
                if (!string.IsNullOrEmpty(value.consume?.output)) throw new InvalidDataException("ConsumeTypes metadata role bit is missing.");
                value.consume = null;
            }
            if (value?.hasConsume == true && value.consume == null) throw new InvalidDataException("ConsumeTypes metadata is missing.");
            return value;
        }
        internal TableManifest Copy() => Parse(Encoding.UTF8.GetString(Bytes()));
        internal byte[] Bytes()
        {
            object value = hasConsume ? this : (object)new TableLegacyManifest { version = version, output = output, status = status, journal = journal, tables = tables };
            return new UTF8Encoding(false, true).GetBytes(JsonUtility.ToJson(value, true) + "\n");
        }
    }
    // Preserve the exact existing table-only metadata shape and no-op behavior.
    [Serializable] internal sealed class TableLegacyManifest
    {
        public int version;
        public string output, status, journal;
        public List<TableManagedRecord> tables;
    }

    internal static class TablePaths
    {
        internal static string Project => Path.GetFullPath(Path.Combine(Application.dataPath, "..")).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        internal static string Relative(string path) => Path.GetFullPath(path).Substring(Project.Length + 1).Replace('\\', '/');
        internal static string Output(string directory)
        {
            string full = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string prefix = Path.GetFullPath(Application.dataPath) + Path.DirectorySeparatorChar;
            if (!full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || !full.Substring(prefix.Length).Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar).Contains("Resources"))
                throw new ArgumentException("Output must be a Resources directory inside this project's Assets.");
            NoReparse(full); return full;
        }
        internal static string Manifest(string output) => Path.Combine(Project, "ProjectSettings", "JJEvolTableAuthoring", TableHash.Text(Relative(output)) + ".json");
        // A gate file holds no data; only its exclusive handle matters. It lives under Library so that taking it never adds a file to ProjectSettings.
        internal static string Lock(string path) => Path.Combine(Project, "Library", "JJEvol", "TableAuthoring", "Locks", Path.GetFileName(path) + ".lock");
        internal static FileStream Gate(string path)
        {
            string gate = Lock(path); NoReparse(gate); Directory.CreateDirectory(Path.GetDirectoryName(gate));
            return new FileStream(gate, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        }
        internal static void RequireWindowsFile(string path)
        {
            if (Application.platform != RuntimePlatform.WindowsEditor) return;
            string full = Path.GetFullPath(path);
            if (full.Length >= 260)
                throw new ArgumentException("Table Authoring cannot safely verify or recover a Windows Editor file path of " + full.Length +
                    " characters (must be below 260). Shorten the Host/output path or managed filename before applying: " + full, nameof(path));
        }
        internal static void Name(string name)
        {
            if (string.IsNullOrWhiteSpace(name) || name != name.Trim() || name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || name.Contains("/") || name.Contains("\\") || name.EndsWith(".", StringComparison.Ordinal) || name == "." || name == ".." ||
                new[] { "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9" }.Contains(name.Split('.')[0], StringComparer.OrdinalIgnoreCase))
                throw new ArgumentException("Unsafe or ambiguous table/output name.");
        }
        internal static void NoReparse(string path)
        {
            for (string cursor = Path.GetFullPath(path); !string.IsNullOrEmpty(cursor); cursor = Path.GetDirectoryName(cursor))
                try { if ((File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0) throw new ArgumentException("Reparse point/junction/symlink paths are not supported."); }
                catch (FileNotFoundException) { } catch (DirectoryNotFoundException) { }
        }
        internal static void Disjoint(string input, string output)
        {
            string a = Path.GetFullPath(input).TrimEnd(Path.DirectorySeparatorChar), b = Path.GetFullPath(output).TrimEnd(Path.DirectorySeparatorChar);
            if (a.Equals(b, StringComparison.OrdinalIgnoreCase) || a.StartsWith(b + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || b.StartsWith(a + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("Input and output must not overlap.");
        }
        internal static string HashFile(string path) => File.Exists(path) ? TableHash.Bytes(File.ReadAllBytes(path)) : "missing";
        internal static string HashContent(string path) => File.Exists(path) ? TableHash.Content(File.ReadAllBytes(path)) : "missing";
        internal static string Guid(string meta)
        { if (!File.Exists(meta)) return ""; return File.ReadLines(meta).FirstOrDefault(l => l.StartsWith("guid: ", StringComparison.Ordinal))?.Substring(6).Trim() ?? ""; }
        internal static string RecordPath(string output, TableManagedRecord record) { Name(record.name); return Path.Combine(output, record.name + ".txt"); }
        internal static string Inventory(string directory)
        { NoReparse(directory); return !Directory.Exists(directory) ? "missing" : TableHash.Parts(Directory.GetFiles(directory).OrderBy(p => p, StringComparer.Ordinal).SelectMany(p => { NoReparse(p); return new[] { Path.GetFileName(p), HashFile(p) }; })); }
        internal static string InputInventory(string directory)
        { NoReparse(directory); return TableHash.Parts(TableBuilder.ReadDirectory(directory).SelectMany(i => new[] { i.FilePath, i.RawHash })); }
    }
}
