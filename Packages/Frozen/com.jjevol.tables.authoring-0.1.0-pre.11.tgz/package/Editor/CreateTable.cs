using UnityEditor;
using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace jjevol
{
    internal enum TableAuthoringTask { AllTables, SelectedTables, AllData, CodeOnly, Adoption, CleanupFull, Remove, Migration }

    public class CreateTable : EditorWindow
    {
        internal const string MenuName = "JJEvol/Tables/Table Builder";
        internal const string WindowTitle = "Table Builder";
        // Existing serialized names remain readable. Policy switches are now Host-owned.
        [SerializeField] private string assetPath = CommonDataToolSettings.Current.TableInputDirectory;
        [SerializeField] private string savePath = CommonDataToolSettings.Current.TableOutputDirectory;
        [SerializeField] private bool useEncrypt = true;
        [SerializeField] private int inputMode;
        [SerializeField] private TableDialect dialect;
        [SerializeField] private string pastedName = "table", pastedText = "";
        [SerializeField] private bool completeCatalog, adoptSelected, requireValidator;
        [SerializeField] private bool generateConsumeTypes;
        [SerializeField] private string consumeTypesName = "ConsumeTypes", codeOutputPath = "", codeNamespace = "", codeEnumName = "GameConsumeType";
        [SerializeField] private string renameIds = "", retireIds = "", migrationReason = "";
        [SerializeField] private string spreadsheet = "";
        [SerializeField] private string _savedSpreadsheet = "";
        [SerializeField] private List<string> _files = new List<string>();
        [SerializeField] private List<string> _selected = new List<string>();
        [SerializeField] private int _tab, _scope, _management, _cleanup;
        [SerializeField] private bool _migrationWithTables, _showGeneratedSource, _showDetails, _showDialect;
        [SerializeField] private bool _settingsLoaded;
        [SerializeField] private string _settingsHash;
        [Serializable] private sealed class HeaderConnection { public string table, target, source; }
        [SerializeField] private List<HeaderConnection> _connections = new List<HeaderConnection>();
        [SerializeField] private List<string> _mappingEnabled = new List<string>();
        private IReadOnlyList<TableInput> _inputs = Array.Empty<TableInput>();
        private IReadOnlyList<ConsumeTypeDefinition> _definitions = Array.Empty<ConsumeTypeDefinition>();
        private IReadOnlyList<TableDiagnostic> _definitionErrors = Array.Empty<TableDiagnostic>();
        private string[] _managedNames = Array.Empty<string>();
        private TableBuildPlan _plan;
        private TablePreparedBuild _prepared;
        private string _preparedContext, _sourceKey;
        [SerializeField] private string _status = "원본 선택 → 변경사항 확인 → 적용 순서로 진행하세요.";
        private TableBuildStatus _recorded;
        private IReadOnlyList<TableFileDifference> _differences = Array.Empty<TableFileDifference>();
        private bool _interactive, _settingsConflict;
        private double _nextPoll, _awaitingSince;
        private Vector2 _scroll;

        private void OnEnable()
        {
            Run(() => LoadSettings(false));
            EditorApplication.update += Poll;
            UnityEditor.Compilation.CompilationPipeline.compilationFinished += OnCompilationFinished;
        }
        private void OnDisable()
        {
            EditorApplication.update -= Poll;
            UnityEditor.Compilation.CompilationPipeline.compilationFinished -= OnCompilationFinished;
        }
        private void OnCompilationFinished(object context) => TableCompilation.WhenIdle(RefreshRecordedStatus);
        private void RefreshRecordedStatus()
        {
            if (this == null) return;
            var previous = _recorded?.State;
            _recorded = TableBuilder.GetStatus(savePath);
            RefreshDifferences();
            bool hasRecord = _recorded.State == TableBuildState.Ready && File.Exists(TableBuilder.GetManifestPath(savePath));
            if (previous != _recorded.State && (previous.HasValue || _recorded.State != TableBuildState.Ready || hasRecord))
                _status = StateLabel(_recorded.State);
            Repaint();
        }
        private void RefreshDifferences()
        {
            _differences = Array.Empty<TableFileDifference>();
            if (_recorded.State != TableBuildState.RecoveryRequired) return;
            try { _differences = TableBuilder.GetFileDifferences(savePath); }
            catch (Exception) { } // The status line already reports an unreadable record.
        }
        private void Poll()
        {
            if (!_interactive || this == null || EditorApplication.timeSinceStartup < _nextPoll) return;
            _nextPoll = EditorApplication.timeSinceStartup + 1;
            try
            {
                if (_settingsHash != TableAuthoringProjectSettings.CurrentHash)
                { _settingsConflict = true; ClearPlan(); _status = "프로젝트 설정이 다른 창에서 변경됐습니다. 관리 탭에서 다시 읽어 주세요."; }
                if (_prepared != null && (_preparedContext != ContextKey() ||
                    _plan.Preconditions.Any(p => TablePaths.HashFile(p.Key) != p.Value) ||
                    _plan.Inventory != TablePaths.Inventory(_plan.OutputDirectory) ||
                    (_plan.Request.CatalogDirectory != null && _plan.CatalogInventory != TablePaths.InputInventory(_plan.Request.CatalogDirectory))))
                { ClearPlan(); _status = "입력·설정·출력이 변경되어 준비본을 취소했습니다. 변경사항을 다시 확인하세요."; }
                RefreshRecordedStatus();
                // Rereading inputs selects every input; on the Remove screen that selection would be a hidden delete list.
                if (inputMode == 0 && !IsRemoveScreen && _sourceKey != SourceKey() && Directory.Exists(assetPath) && !_settingsConflict)
                {
                    _sourceKey = SourceKey(); string message = _status; bool acquired = false;
                    Run(() => { if (_tab == 1) ReadDefinitions(); else ReadInputs(); acquired = true; });
                    if (acquired) _status = message; // Discovery must not replace the actual Apply/compile result.
                }
            }
            catch { ClearPlan(); _status = "상태를 확인할 수 없습니다. 설정·원본 경로를 확인하거나 관리·복구를 열어 주세요."; }
        }
        [MenuItem(MenuName)]
        private static void Init() { var window = GetWindow<CreateTable>(WindowTitle); window.minSize = new Vector2(820, 620); }
        private void OnGUI()
        {
            _interactive = true; minSize = new Vector2(820, 620);
            int next = GUILayout.Toolbar(_tab, new[] { "일반 테이블", "ConsumeType", "관리·복구" }, GUILayout.Height(28));
            if (next != _tab) { ReleaseTextFocus(); _tab = next; ClearPlan(); _sourceKey = null; }
            if (_settingsConflict) EditorGUILayout.HelpBox("프로젝트 설정 변경을 감지했습니다. 관리 → 프로젝트 설정 다시 읽기가 필요합니다.", MessageType.Warning);
            EditorGUILayout.HelpBox(_status, _recorded?.State == TableBuildState.RecoveryRequired ? MessageType.Warning : MessageType.Info);
            if (_recorded != null && _recorded.State != TableBuildState.Ready && _tab != 2)
            {
                EditorGUILayout.LabelField(StateLabel(_recorded.State));
                if (GUILayout.Button("관리·복구 열기")) { ReleaseTextFocus(); _tab = 2; _management = 3; ClearPlan(); }
            }
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            if (_tab == 0) DrawTables(); else if (_tab == 1) DrawConsumeTypes(); else DrawManagement();
            DrawPreview(_tab == 2);
            EditorGUILayout.EndScrollView();
        }
        private static void ReleaseTextFocus() { EditorGUIUtility.editingTextField = false; GUIUtility.keyboardControl = 0; GUI.FocusControl(null); }
        private static bool IsDefinition(string name) => string.Equals(name, "ConsumeTypes", StringComparison.OrdinalIgnoreCase);
        private static string StateLabel(TableBuildState state) => state switch
        {
            TableBuildState.Ready => "Ready — 적용 파일과 컴파일 상태를 확인했습니다.",
            TableBuildState.AppliedAwaitingCompile => "AppliedAwaitingCompile — 파일 적용 완료, Unity 컴파일 확인 중입니다.",
            TableBuildState.Restored => "Restored — 이전 파일을 복원했습니다. 컴파일 결과를 확인합니다.",
            TableBuildState.RecoveryRequired => "RecoveryRequired — 정상 완료가 아닙니다. 관리·복구에서 확인하세요.",
            _ => state.ToString()
        };
        private void DrawSource(bool definition)
        {
            EditorGUI.BeginChangeCheck();
            int mode = GUILayout.Toolbar(inputMode, new[] { "원본 폴더", "Paste" });
            if (mode != inputMode) { ReleaseTextFocus(); inputMode = mode; }
            if (inputMode == 0)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    assetPath = EditorGUILayout.TextField("TSV/TXT 원본 폴더", assetPath);
                    if (GUILayout.Button("선택", GUILayout.Width(64)))
                    {
                        string chosen = EditorUtility.OpenFolderPanel("원본 폴더 선택 (읽기 전용)", assetPath, "");
                        if (chosen.Length != 0) { assetPath = chosen; _files.Clear(); _sourceKey = null; }
                    }
                }
                if (_files.Count != 0) EditorGUILayout.HelpBox("이전 개별 파일 선택이 유지됩니다. 관리 설정에서 폴더 입력으로 전환할 수 있습니다.", MessageType.Info);
            }
            else
            {
                if (definition) EditorGUILayout.LabelField("정의 이름", "ConsumeTypes"); else pastedName = EditorGUILayout.TextField("테이블 이름", pastedName);
                pastedText = EditorGUILayout.TextArea(pastedText, GUILayout.Height(85));
            }
            _showDialect = EditorGUILayout.Foldout(_showDialect, "입력 형식 (기본 TSV)");
            if (_showDialect) dialect = (TableDialect)EditorGUILayout.EnumPopup("명시적 형식", dialect);
            if (EditorGUI.EndChangeCheck()) { ClearPlan(); _inputs = Array.Empty<TableInput>(); _definitions = Array.Empty<ConsumeTypeDefinition>(); _definitionErrors = Array.Empty<TableDiagnostic>(); _sourceKey = null; }
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("테이블 출력", savePath);
                if (GUILayout.Button("설정", GUILayout.Width(64))) { ReleaseTextFocus(); _tab = 2; _management = 0; }
            }
            if (GUILayout.Button(definition ? "ConsumeTypes 정의 읽기" : "목록 새로 읽기", GUILayout.Width(220)))
                Run(() => { if (definition) ReadDefinitions(); else ReadInputs(); });
        }
        // Sheet data is copied by hand into the input TSV files; the tool only keeps and opens the spreadsheet.
        private void DrawSpreadsheet()
        {
            if (!TableSpreadsheetLink.TryGetId(_savedSpreadsheet, out _))
            {
                EditorGUILayout.HelpBox("연결할 Google 스프레드시트가 없습니다. 먼저 관리·복구 → 프로젝트 설정에서 시트 주소를 저장하세요. 테이블 원본은 그 시트에서 복사해 TSV 파일에 붙여 넣습니다.", MessageType.Warning);
                if (GUILayout.Button("스프레드시트 연결하기", GUILayout.Width(220))) { ReleaseTextFocus(); _tab = 2; _management = 0; ClearPlan(); }
                return;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("Google 스프레드시트", _savedSpreadsheet);
                if (GUILayout.Button("시트 열기", GUILayout.Width(90))) Application.OpenURL(TableSpreadsheetLink.OpenUrl(_savedSpreadsheet));
            }
            EditorGUILayout.LabelField("시트 탭 하나를 복사해 원본 폴더의 '테이블 이름.tsv'에 붙여 넣습니다. 열은 순서가 아니라 머리 행 이름으로 맞춥니다.", EditorStyles.wordWrappedMiniLabel);
        }
        private void DrawTables()
        {
            DrawSpreadsheet();
            DrawSource(false);
            EditorGUI.BeginChangeCheck();
            _scope = EditorGUILayout.Popup("작업 범위", _scope, new[] { "전체 갱신 — 일반 테이블 모두, 삭제 없음", "선택 갱신 — 선택 테이블만, 삭제 없음", "전체 데이터 갱신 — 일반 테이블 + 게임 타입 코드" });
            if (EditorGUI.EndChangeCheck()) ClearPlan();
            DrawTableList(_scope == 1, false);
            DrawMappings();
            if (_scope == 2 && !GameSettingsValid()) DrawGameSetup();
            DrawHostReadiness(_inputs.Any(i => !IsDefinition(i.TableName)));
            DrawActions("변경사항 확인", "적용", CreateTables);
        }
        private void DrawTableList(bool selection, bool managed)
        {
            var names = (managed ? _managedNames : _inputs.Select(i => i.TableName)).Where(n => !IsDefinition(n)).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            EditorGUILayout.LabelField(managed ? "관리 중인 테이블" : "발견한 일반 테이블 (" + names.Length + ")", EditorStyles.boldLabel);
            foreach (string name in names)
            {
                if (!selection) { EditorGUILayout.LabelField("  " + name); continue; }
                bool selected = EditorGUILayout.ToggleLeft(name, IsSelected(name));
                if (selected != IsSelected(name)) { Select(name, selected); ClearPlan(); }
            }
            if (!managed && _inputs.Any(i => IsDefinition(i.TableName))) EditorGUILayout.LabelField("ConsumeTypes: Authoring 정의 (일반 갱신에서 제외)", EditorStyles.miniLabel);
        }
        private void DrawConsumeTypes()
        {
            DrawSource(true);
            EditorGUILayout.LabelField("양식: typeId, codeName (displayName, localizationKey 선택)", EditorStyles.miniLabel);
            foreach (var row in _definitions) EditorGUILayout.LabelField(row.TypeId.ToString(), row.CodeName + (row.DisplayName.Length == 0 ? "" : " — " + row.DisplayName));
            foreach (var error in _definitionErrors) EditorGUILayout.HelpBox(error.ToString(), MessageType.Error);
            if (!GameSettingsValid()) DrawGameSetup(); else EditorGUILayout.LabelField("프로젝트 코드 설정", codeNamespace + "." + codeEnumName);
            DrawActions("변경사항 확인", "코드 생성", () => Run(() => Preview(TableAuthoringTask.CodeOnly)));
        }
        private void DrawGameSetup()
        {
            EditorGUILayout.HelpBox("처음 한 번 게임 코드 위치와 이름을 저장하세요. 기존 게임 asmdef와 Economy 참조를 확인하며 자동 수정하지 않습니다.", MessageType.Info);
            EditorGUI.BeginChangeCheck();
            codeOutputPath = EditorGUILayout.TextField("게임 코드 출력 폴더", codeOutputPath);
            codeNamespace = EditorGUILayout.TextField("게임 namespace", codeNamespace);
            codeEnumName = EditorGUILayout.TextField("enum 이름", codeEnumName);
            if (EditorGUI.EndChangeCheck()) ClearPlan();
            if (GUILayout.Button("프로젝트 설정 저장")) Run(SaveSettings);
        }
        private void DrawHostReadiness(bool runtime)
        {
            if (!runtime) return;
            if (TableAuthoringOptions.UseEncryption && (TableAuthoringOptions.EncryptBytes == null || TableRuntimeOptions.DecryptBytes == null))
                EditorGUILayout.HelpBox("Host의 암호화/복호화 provider 등록이 필요합니다. 등록 전에는 적용할 수 없습니다.", MessageType.Warning);
            if (TableAuthoringOptions.ValidateTables == null) EditorGUILayout.HelpBox("Host의 게임 검증기 등록이 필요합니다. Schema만으로 관계/게임 검증을 대신하지 않습니다.", MessageType.Warning);
        }
        private void DrawActions(string preview, string apply, Action action)
        {
            using (new EditorGUI.DisabledScope(_settingsConflict || EditorApplication.isCompiling || (_recorded != null && _recorded.State != TableBuildState.Ready)))
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(preview, GUILayout.Height(30))) action();
                using (new EditorGUI.DisabledScope(_prepared == null)) if (GUILayout.Button(apply, GUILayout.Height(30))) ApplyOutputs();
            }
        }
        private void DrawManagement()
        {
            int next = GUILayout.Toolbar(_management, new[] { "프로젝트 설정", "출력 등록·정리", "ID 이행", "복구·진단" });
            if (next != _management) { ReleaseTextFocus(); _management = next; ClearPlan(); }
            if (_management == 0) DrawSettings();
            else if (_management == 1) DrawCleanup();
            else if (_management == 2) DrawMigration();
            else DrawRecovery();
        }
        private void DrawSettings()
        {
            EditorGUILayout.HelpBox("프로젝트 경로·연결 시트·게임 코드 이름만 저장합니다. 키·인증 정보·provider·검증기는 저장하지 않습니다.", MessageType.Info);
            EditorGUI.BeginChangeCheck();
            EditorGUILayout.LabelField("Google 스프레드시트 연결", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                spreadsheet = EditorGUILayout.TextField("시트 주소 또는 ID", spreadsheet);
                bool valid = TableSpreadsheetLink.TryGetId(spreadsheet, out _);
                using (new EditorGUI.DisabledScope(!valid)) if (GUILayout.Button("시트 열기", GUILayout.Width(90))) Application.OpenURL(TableSpreadsheetLink.OpenUrl(spreadsheet));
            }
            if (string.IsNullOrWhiteSpace(spreadsheet)) EditorGUILayout.HelpBox("테이블을 쓰려면 원본이 될 Google 스프레드시트 주소를 먼저 입력하고 저장하세요.", MessageType.Warning);
            else if (!TableSpreadsheetLink.TryGetId(spreadsheet, out _)) EditorGUILayout.HelpBox("https://docs.google.com/spreadsheets/d/... 주소나 그 ID를 넣으세요.", MessageType.Error);
            EditorGUILayout.LabelField("자동 가져오기는 없습니다. 시트에서 복사한 내용을 원본 폴더의 TSV 파일에 붙여 넣으세요.", EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space();
            assetPath = EditorGUILayout.TextField("기본 원본 폴더", assetPath);
            savePath = EditorGUILayout.TextField("테이블 출력 폴더", savePath);
            codeOutputPath = EditorGUILayout.TextField("게임 코드 출력 폴더", codeOutputPath);
            codeNamespace = EditorGUILayout.TextField("게임 namespace", codeNamespace);
            codeEnumName = EditorGUILayout.TextField("enum 이름", codeEnumName);
            if (EditorGUI.EndChangeCheck()) { ClearPlan(); _sourceKey = null; }
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("프로젝트 설정 저장")) Run(SaveSettings);
                if (GUILayout.Button("프로젝트 설정 다시 읽기")) Run(() => LoadSettings(true));
                if (_files.Count != 0 && GUILayout.Button("개별 파일 해제 → 폴더 입력")) { _files.Clear(); _sourceKey = null; ClearPlan(); }
            }
            EditorGUILayout.LabelField("Host 출력 정책", TableAuthoringOptions.UseEncryption ? "암호화" : "명시적 평문 정책");
            EditorGUILayout.LabelField("Host codec version", TableAuthoringOptions.CodecProfileVersion);
            EditorGUILayout.LabelField("Host validation version", TableAuthoringOptions.ValidationVersion);
            DrawHostReadiness(true);
        }
        private void DrawCleanup()
        {
            EditorGUI.BeginChangeCheck();
            _cleanup = EditorGUILayout.Popup("명시적 관리 작업", _cleanup, new[] { "미관리 출력 등록 (Adoption)", "전체 목록 대조·관리 출력 정리 (Full)", "선택 관리 출력 삭제 (Remove)" });
            if (EditorGUI.EndChangeCheck()) { ClearPlan(); _selected.Clear(); _sourceKey = null; }
            if (_cleanup == 2)
            {
                if (GUILayout.Button("관리 출력 목록 읽기")) Run(() => { _managedNames = TableBuilder.GetManagedNames(savePath).ToArray(); _selected.Clear(); ClearPlan(); });
                DrawTableList(true, true);
            }
            else { DrawSource(false); DrawTableList(_cleanup == 0, false); DrawMappings(); }
            EditorGUILayout.HelpBox(_cleanup == 0 ? "선택한 미관리 파일만 명시적으로 등록합니다. Preview에서 기존 파일·GUID를 확인하세요."
                : "삭제 작업입니다. 관리 중이며 변경되지 않은 출력만 정리합니다. 일반 전체 갱신의 Upsert와 다릅니다.", MessageType.Warning);
            if (_cleanup == 1)
            {
                bool approved = EditorGUILayout.ToggleLeft("원본 폴더가 전체 일반 테이블 목록임을 확인했습니다.", completeCatalog);
                if (approved != completeCatalog) { completeCatalog = approved; ClearPlan(); }
            }
            DrawActions("관리 변경사항 확인", "확인한 관리 작업 적용", () => Run(() => Preview(_cleanup == 0 ? TableAuthoringTask.Adoption : _cleanup == 1 ? TableAuthoringTask.CleanupFull : TableAuthoringTask.Remove)));
        }
        private void DrawMigration()
        {
            EditorGUILayout.HelpBox("정확한 ID와 사유로 rename/retire를 승인합니다. 일반 갱신에는 이 승인이 전달되지 않습니다. 재번호화·퇴역 ID 재사용은 계속 금지됩니다.", MessageType.Warning);
            DrawSource(true);
            EditorGUI.BeginChangeCheck();
            renameIds = EditorGUILayout.TextField("승인할 rename IDs (CSV)", renameIds);
            retireIds = EditorGUILayout.TextField("승인할 retire IDs (CSV)", retireIds);
            migrationReason = EditorGUILayout.TextField("이행 사유", migrationReason);
            _migrationWithTables = EditorGUILayout.ToggleLeft("일반 테이블도 동일 계획으로 갱신", _migrationWithTables);
            if (EditorGUI.EndChangeCheck()) ClearPlan();
            if (!GameSettingsValid()) DrawGameSetup();
            DrawActions("이행 변경사항 확인", "승인한 이행 적용", () => Run(() => Preview(TableAuthoringTask.Migration)));
        }
        private void DrawRecovery()
        {
            EditorGUILayout.LabelField("상태", _recorded?.ToString() ?? "확인 중");
            EditorGUILayout.LabelField("관리 출력", savePath);
            if (_differences.Count != 0) DrawBaseline();
            else if (_recorded?.State == TableBuildState.RecoveryRequired && GUILayout.Button("기록된 자기 변경 복구")) RecoverRecorded();
            if (_recorded?.State == TableBuildState.AppliedAwaitingCompile && !EditorApplication.isCompiling && EditorApplication.timeSinceStartup - _awaitingSince > 15)
            {
                EditorGUILayout.HelpBox("자동 완료를 확인하지 못했습니다. 명시적으로 확인·재개할 수 있습니다.", MessageType.Warning);
                if (GUILayout.Button("컴파일된 생성본 확인")) Run(() => { _recorded = TableBuilder.VerifyCompiledGeneration(savePath); _status = StateLabel(_recorded.State); });
                if (GUILayout.Button("대기 중 컴파일 재개")) Run(() => TableBuilder.ResumeCompilation(savePath));
            }
            if (GUILayout.Button("상태 다시 확인")) RefreshRecordedStatus();
            EditorGUILayout.HelpBox("충돌 파일을 덮어쓰거나 pending/journal을 삭제하지 마세요. 소유권·현재 파일·GUID가 일치하지 않으면 복구는 차단됩니다.", MessageType.Info);
            _showDetails = EditorGUILayout.Foldout(_showDetails, "manifest / journal / GUID / 상세 해시");
            if (_showDetails)
            {
                try
                {
                    string manifest = TableBuilder.GetManifestPath(savePath); EditorGUILayout.SelectableLabel(manifest, GUILayout.Height(35));
                    if (File.Exists(manifest + ".pending")) EditorGUILayout.SelectableLabel(File.ReadAllText(manifest + ".pending"), GUILayout.Height(65));
                    if (File.Exists(manifest)) EditorGUILayout.SelectableLabel(File.ReadAllText(manifest), GUILayout.Height(220));
                }
                catch { EditorGUILayout.HelpBox("관리 기록을 읽을 수 없습니다. 원본을 덮어쓰지 않았습니다.", MessageType.Warning); }
            }
        }
        private void DrawBaseline()
        {
            EditorGUILayout.HelpBox("아래 파일이 마지막 빌드 기록과 달라서 PlayMode와 Player 빌드가 막혀 있습니다. 표 파일을 지금 상태로 쓰려면 새 기준으로 인정하고, 생성 코드는 다시 만드세요.", MessageType.Warning);
            foreach (var difference in _differences) EditorGUILayout.HelpBox(difference.ToString(), difference.CanAccept ? MessageType.Info : MessageType.Error);
            bool regenerate = _differences.Any(d => d.CanRegenerate), others = _differences.Any(d => !d.IsCode);
            if (regenerate && others) EditorGUILayout.HelpBox("표 파일을 먼저 새 기준으로 인정하면 생성 코드를 다시 만들 수 있습니다.", MessageType.Info);
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(EditorApplication.isCompiling || !_differences.Any(d => d.CanAccept) || _differences.Any(d => !d.CanAccept && !d.CanRegenerate)))
                    if (GUILayout.Button("현재 파일을 새 기준으로 인정", GUILayout.Height(30))) AcceptCurrentFiles();
                if (regenerate)
                    using (new EditorGUI.DisabledScope(EditorApplication.isCompiling || others))
                        if (GUILayout.Button("생성 코드 다시 만들기", GUILayout.Height(30))) RegenerateCode();
            }
        }
        private void AcceptCurrentFiles()
        {
            var reviewed = _differences;
            const int shown = 15;
            string files = string.Join("\n", reviewed.Take(shown)) + (reviewed.Count > shown ? "\n외 " + (reviewed.Count - shown) + "개 (창의 목록 참고)" : "");
            string message = "아래 파일을 지금 상태 그대로 새 기준으로 기록합니다.\n\n" + files + "\n\n파일은 바꾸지 않고 빌드 기록만 고칩니다. 없는 파일은 기록에서 뺍니다.\n원본 TSV는 그대로이므로, 다음 갱신 때 원본과 다른 내용은 원본 기준으로 다시 덮어씁니다.";
            if (!EditorUtility.DisplayDialog("현재 파일을 새 기준으로 인정", message, "새 기준으로 인정", "취소")) return;
            Run(() =>
            {
                TableBuilder.AcceptCurrentFiles(savePath, reviewed); ClearPlan();
                _status = "현재 파일을 새 기준으로 기록했습니다. 파일은 바꾸지 않았습니다.";
                RefreshRecordedStatus();
            });
        }
        private void RegenerateCode()
        {
            var reviewed = _differences;
            string files = string.Join("\n", reviewed.Where(d => d.CanRegenerate).Select(d => d.Path));
            string message = "아래 생성 코드를 마지막 빌드의 정의로 다시 만듭니다.\n\n" + files + "\n\n이 파일에 직접 고친 내용은 사라집니다.\nUnity 컴파일이 끝나면 PlayMode와 Player 빌드 차단이 풀립니다.";
            if (!EditorUtility.DisplayDialog("생성 코드 다시 만들기", message, "다시 만들기", "취소")) return;
            Run(() =>
            {
                var state = TableBuilder.RegenerateCode(savePath, reviewed); ClearPlan();
                _status = state == TableBuildState.Ready ? "생성 코드의 .meta를 복원했습니다." : "생성 코드를 다시 만들었습니다. Unity 컴파일이 끝나면 자동으로 완료됩니다.";
                _awaitingSince = EditorApplication.timeSinceStartup; RefreshRecordedStatus();
            });
        }
        private void DrawMappings()
        {
            foreach (var input in _inputs.Where(i => !IsDefinition(i.TableName) && (_scope != 1 || IsSelected(i.TableName))))
            {
                var schemas = (TableAuthoringOptions.Schemas ?? Array.Empty<TableSchema>()).Where(s => s.TableName == input.TableName).ToArray();
                if (schemas.Length != 1) continue;
                var schema = schemas[0]; var document = TableDocument.Parse(input);
                if (!document.IsValid) continue;
                var missing = schema.Columns.Where(c => !document.Headers.Contains(c.Name, StringComparer.OrdinalIgnoreCase)).Select(c => c.Name).ToArray();
                bool enabled = _mappingEnabled.Contains(input.TableName);
                if (missing.Length == 0 && !enabled) continue;
                EditorGUILayout.HelpBox(input.TableName + " — " + (missing.Length == 0 ? "명시적 컬럼 연결 사용 중" : "누락된 기대 컬럼: " + string.Join(", ", missing)), MessageType.Warning);
                if (!enabled)
                {
                    if (GUILayout.Button(input.TableName + ": 수동 컬럼 연결")) { _mappingEnabled.Add(input.TableName); ClearPlan(); }
                    continue;
                }
                foreach (var rule in schema.Columns)
                {
                    var connection = _connections.FirstOrDefault(c => c.table == input.TableName && c.target == rule.Name);
                    if (connection == null) { connection = new HeaderConnection { table = input.TableName, target = rule.Name, source = document.Headers.FirstOrDefault(h => string.Equals(h, rule.Name, StringComparison.OrdinalIgnoreCase)) ?? "" }; _connections.Add(connection); }
                    string[] options = new[] { "(선택 필요)" }.Concat(document.Headers).ToArray();
                    int current = Math.Max(0, Array.IndexOf(options, connection.source));
                    int next = EditorGUILayout.Popup(rule.Name + " (" + rule.Kind + ")", current, options);
                    if (next != current) { connection.source = next == 0 ? "" : options[next]; ClearPlan(); }
                }
                if (GUILayout.Button(input.TableName + ": 연결 해제 (원본 헤더 사용)")) { _mappingEnabled.Remove(input.TableName); _connections.RemoveAll(c => c.table == input.TableName); ClearPlan(); }
            }
        }
        private void DrawPreview(bool details)
        {
            if (_plan == null) return;
            EditorGUILayout.Space(); EditorGUILayout.LabelField("확인한 변경사항", EditorStyles.boldLabel);
            foreach (var change in _plan.Changes) EditorGUILayout.LabelField(change.Action + " " + change.TableName, change.Reason);
            if (_plan.ConsumeTypes != null)
            {
                foreach (string diff in _plan.ConsumeTypes.Differences) EditorGUILayout.LabelField(diff);
                foreach (var change in _plan.ConsumeTypes.Changes) EditorGUILayout.LabelField(change.Action + " " + change.TableName, change.Path);
                _showGeneratedSource = EditorGUILayout.Foldout(_showGeneratedSource, "생성할 C# 코드");
                if (_showGeneratedSource)
                {
                    EditorGUILayout.SelectableLabel(_plan.ConsumeTypes.EnumSource, GUILayout.Height(170));
                    EditorGUILayout.SelectableLabel(_plan.ConsumeTypes.ExtensionsSource, GUILayout.Height(230));
                }
            }
            foreach (var mapping in _plan.Request.ColumnMappings) EditorGUILayout.LabelField("연결 " + mapping.TableName, string.Join(", ", mapping.SourcesByTarget.Select(p => p.Value + " → " + p.Key)));
            foreach (var error in _plan.Diagnostics) EditorGUILayout.HelpBox(error.ToString(), error.Severity == TableDiagnosticSeverity.Error ? MessageType.Error : error.Severity == TableDiagnosticSeverity.Warning ? MessageType.Warning : MessageType.Info);
            if (_plan.Diagnostics.Any(d => d.Code.Contains("Conflict") || d.Code.Contains("Approval") || d.Code.Contains("Retired") || d.Code.Contains("Renumber")) && _tab != 2)
                if (GUILayout.Button("충돌·ID 이행 관리 열기"))
                {
                    ReleaseTextFocus(); _tab = 2;
                    _management = _plan.Diagnostics.Any(d => d.Code == "UnmanagedConflict") ? 1 : _plan.Diagnostics.Any(d => d.Code.Contains("Approval")) ? 2 : 3;
                    _cleanup = 0; ClearPlan();
                }
            if (details && _plan != null)
            {
                EditorGUILayout.LabelField("Plan", _plan.Fingerprint);
                foreach (var change in _plan.Changes.Concat(_plan.ConsumeTypes?.Changes ?? Array.Empty<TableOutputChange>()))
                    EditorGUILayout.LabelField(change.TableName + " hash / GUID", change.ExistingHash + " / " + change.ExistingGuid);
            }
        }
        private void ClearPlan() { _plan = null; _prepared = null; _preparedContext = null; }
        private bool IsRemoveScreen => _tab == 2 && _management == 1 && _cleanup == 2;
        private bool IsSelected(string name) => _selected.Contains(name, StringComparer.OrdinalIgnoreCase);
        private void Select(string name, bool selected) { _selected.RemoveAll(n => string.Equals(n, name, StringComparison.OrdinalIgnoreCase)); if (selected) _selected.Add(name); }
        private string SourceKey() => inputMode + ":" + _tab + ":" + assetPath + ":" + string.Join("|", _files);
        private IReadOnlyList<TableInput> Acquire(bool definitionOnly = false)
        {
            if (inputMode == 1) return new[] { TableInput.FromText(definitionOnly ? "ConsumeTypes" : pastedName, pastedText, dialect) };
            if (!definitionOnly) return _files.Count == 0 ? TableBuilder.ReadDirectory(assetPath, dialect) : _files.Select(f => TableInput.FromFile(f, dialect)).ToArray();
            string[] candidates = _files.Where(f => IsDefinition(Path.GetFileNameWithoutExtension(f))).ToArray();
            if (candidates.Length == 0)
            {
                string root = Path.GetFullPath(assetPath); TablePaths.NoReparse(root);
                candidates = Directory.GetFiles(root).Where(f => IsDefinition(Path.GetFileNameWithoutExtension(f)) && new[] { ".tsv", ".txt" }.Contains(Path.GetExtension(f), StringComparer.OrdinalIgnoreCase)).ToArray();
            }
            return candidates.Select(f => TableInput.FromFile(f, dialect)).ToArray();
        }
        private void ReadInputs()
        {
            _inputs = Acquire(); _sourceKey = SourceKey(); _managedNames = Array.Empty<string>(); _selected.Clear();
            foreach (var input in _inputs.Where(i => !IsDefinition(i.TableName))) Select(input.TableName, true);
            ClearPlan(); _status = "일반 테이블 " + _selected.Count + "개를 찾았습니다. 변경사항을 확인하세요.";
        }
        private void ReadDefinitions()
        {
            _inputs = Acquire(true); _sourceKey = SourceKey(); ClearPlan(); var errors = new List<TableDiagnostic>();
            if (_inputs.Count != 1) errors.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "ConsumeTypesInput", "ConsumeTypes", assetPath, "Exactly one ConsumeTypes.tsv/txt definition is required."));
            var document = _inputs.Count == 1 ? TableDocument.Parse(_inputs[0]) : null;
            if (document != null) errors.AddRange(document.Diagnostics);
            _definitions = ConsumeTypesCodeGenerator.ReadDefinitions(document, "ConsumeTypes", codeEnumName, errors); _definitionErrors = errors;
            _status = errors.Count == 0 ? "타입 ID와 코드 이름을 읽었습니다. 변경사항을 확인한 뒤 코드를 생성하세요." : "정의 오류가 있습니다. 원본을 변경하지 않았습니다.";
        }
        private void CreateTables() => Run(() => Preview(_tab == 1 ? TableAuthoringTask.CodeOnly : _scope == 1 ? TableAuthoringTask.SelectedTables : _scope == 2 ? TableAuthoringTask.AllData : TableAuthoringTask.AllTables));
        private void Preview(TableAuthoringTask task)
        {
            ClearPlan();
            if (_settingsConflict || _settingsHash != TableAuthoringProjectSettings.CurrentHash) throw new InvalidOperationException("Reload project settings.");
            bool code = task == TableAuthoringTask.CodeOnly || task == TableAuthoringTask.AllData || task == TableAuthoringTask.Migration;
            bool runtime = task != TableAuthoringTask.CodeOnly && !(task == TableAuthoringTask.Migration && !_migrationWithTables);
            bool remove = task == TableAuthoringTask.Remove;
            // Only names listed on the Remove screen can be ticked, so nothing else may reach the delete plan.
            string[] removal = remove ? _selected.Where(n => !IsDefinition(n) && _managedNames.Contains(n, StringComparer.OrdinalIgnoreCase)).ToArray() : Array.Empty<string>();
            if (remove && removal.Length == 0) { _status = "삭제할 관리 출력을 선택하세요. 관리 출력 목록을 읽은 뒤 표시된 항목만 선택할 수 있습니다."; return; }
            if (inputMode == 0 && _files.Count != 0 && (task == TableAuthoringTask.AllTables || task == TableAuthoringTask.AllData || task == TableAuthoringTask.CleanupFull))
                throw new InvalidOperationException("Clear the old explicit file selection in management before a whole-folder operation.");
            if (code && !GameSettingsValid()) throw new InvalidOperationException("Save valid game code project settings before generation.");
            _inputs = remove ? Array.Empty<TableInput>() : Acquire(code && !runtime); _sourceKey = SourceKey();
            var inputs = code ? _inputs : _inputs.Where(i => !IsDefinition(i.TableName)).ToArray();
            string[] selected = remove ? removal
                : task == TableAuthoringTask.SelectedTables || task == TableAuthoringTask.Adoption ? _selected.Where(n => !IsDefinition(n)).ToArray()
                : inputs.Select(i => i.TableName).ToArray();
            if (task == TableAuthoringTask.AllData && (!inputs.Any(i => IsDefinition(i.TableName)) || !inputs.Any(i => !IsDefinition(i.TableName))))
                throw new InvalidDataException("All data update requires both ordinary tables and ConsumeTypes.");
            var migration = task == TableAuthoringTask.Migration ? new ConsumeTypeMigration(ParseIds(renameIds), ParseIds(retireIds), migrationReason) : null;
            var generation = code ? DraftSettings().Generation(migration) : null;
            useEncrypt = TableAuthoringOptions.UseEncryption; requireValidator = runtime && !remove; generateConsumeTypes = code; consumeTypesName = "ConsumeTypes";
            adoptSelected = task == TableAuthoringTask.Adoption;
            var mappings = _mappingEnabled.Where(t => selected.Contains(t, StringComparer.OrdinalIgnoreCase))
                .Select(t => new TableColumnMapping(t, _connections.Where(c => c.table == t).Select(c => new KeyValuePair<string, string>(c.target, c.source)))).ToArray();
            _plan = TableBuilder.Plan(new TableBuildRequest(inputs, savePath, useEncrypt,
                remove ? TableBuildOperation.Remove : task == TableAuthoringTask.CleanupFull ? TableBuildOperation.Full : TableBuildOperation.Upsert,
                selected, completeCatalog: task == TableAuthoringTask.CleanupFull && completeCatalog,
                adopt: adoptSelected ? selected : null, requireValidator: requireValidator,
                schemas: (TableAuthoringOptions.Schemas ?? Array.Empty<TableSchema>()).Where(s => !remove && (inputs.Any(i => i.TableName == s.TableName) || TableBuilder.GetManagedNames(savePath).Contains(s.TableName))).ToArray(),
                catalogDirectory: inputMode == 0 && _files.Count == 0 && !remove ? assetPath : null, consumeTypes: generation, columnMappings: mappings));
            if (!_plan.IsValid) { _status = "변경사항 확인이 차단됐습니다. 아래 오류를 수정하세요. 출력은 변경하지 않았습니다."; return; }
            PrepareOutputs();
        }
        private void PrepareOutputs() => Run(() => { _prepared = TableBuilder.Prepare(_plan); _preparedContext = ContextKey(); _status = "변경 내용의 검증과 준비를 마쳤습니다. 출력은 아직 변경하지 않았습니다. 확인한 내용을 적용하세요."; });
        private void ApplyOutputs() => Run(() =>
        {
            if (_prepared == null || _preparedContext != ContextKey()) throw new InvalidOperationException("Prepared review changed; review again.");
            var result = _prepared.Apply();
            _status = (result.NoOp ? "No-op — 변경 없음. " : "") + StateLabel(result.State) + " 출력 " + result.OutputFiles.Count + ", 삭제 " + result.RemovedObsoleteFiles;
            if (result.State == TableBuildState.Ready && _plan.ConsumeTypes == null) Debug.Log($"[CreateTable] Complete. Table Count: {result.OutputFiles.Count}");
            else Debug.Log($"[CreateTable] {result.State}. Output Count: {result.OutputFiles.Count}");
            _awaitingSince = EditorApplication.timeSinceStartup; ClearPlan(); RefreshRecordedStatus();
        });
        private string ContextKey() => TableHash.Parts(new[] { TableAuthoringProjectSettings.CurrentHash, assetPath, savePath, inputMode.ToString(), dialect.ToString(), pastedName, pastedText,
            _tab.ToString(), _scope.ToString(), _management.ToString(), _cleanup.ToString(), codeOutputPath, codeNamespace, codeEnumName, renameIds, retireIds, migrationReason,
            completeCatalog.ToString(), _migrationWithTables.ToString(), TableAuthoringOptions.UseEncryption.ToString(), CommonDataToolSettings.Current.TableInputDirectory, CommonDataToolSettings.Current.TableOutputDirectory }
            .Concat(_files).Concat(_selected).Concat(_mappingEnabled).Concat(_connections.SelectMany(c => new[] { c.table, c.target, c.source }))
            .Concat((TableAuthoringOptions.Schemas ?? Array.Empty<TableSchema>()).SelectMany(s => new[] { s.TableName }.Concat(s.Columns.SelectMany(c => new[] { c.Name, c.Kind.ToString(), c.Required.ToString(), c.Unique.ToString(), c.Minimum?.ToString(), c.Maximum?.ToString() })))));
        private TableAuthoringProjectSettings DraftSettings() => new TableAuthoringProjectSettings { inputDirectory = assetPath, outputDirectory = savePath, codeDirectory = codeOutputPath, gameNamespace = codeNamespace, enumName = codeEnumName, spreadsheet = spreadsheet };
        private bool GameSettingsValid()
        {
            try
            {
                DraftSettings().ValidateGame();
                if (_settingsHash == "missing" || _settingsHash != TableAuthoringProjectSettings.CurrentHash) return false;
                var saved = TableAuthoringProjectSettings.Read();
                return saved.codeDirectory == codeOutputPath && saved.gameNamespace == codeNamespace && saved.enumName == codeEnumName && saved.Output == savePath;
            }
            catch { return false; }
        }
        private void SaveSettings()
        {
            var draft = DraftSettings(); draft.Save(_settingsHash); spreadsheet = _savedSpreadsheet = draft.spreadsheet;
            _settingsHash = TableAuthoringProjectSettings.CurrentHash; _settingsLoaded = true; _settingsConflict = false; ClearPlan();
            _status = "프로젝트 설정을 저장했습니다. 다음 실행에도 재사용합니다.";
        }
        private void LoadSettings(bool force)
        {
            var settings = TableAuthoringProjectSettings.Read(); string hash = TableAuthoringProjectSettings.CurrentHash;
            if (!force && _settingsLoaded && _settingsHash != hash)
            { _settingsConflict = true; ClearPlan(); _status = "프로젝트 설정 변경을 감지했습니다. 관리 탭에서 다시 읽어 주세요."; return; }
            if (force || (!_settingsLoaded && hash != "missing"))
            { assetPath = settings.Input; savePath = settings.Output; codeOutputPath = settings.codeDirectory; codeNamespace = settings.gameNamespace; codeEnumName = settings.enumName; spreadsheet = settings.spreadsheet; }
            _savedSpreadsheet = settings.spreadsheet;
            _settingsHash = hash; _settingsLoaded = true; _settingsConflict = false; _sourceKey = null; ClearPlan();
        }
        private void RecoverRecorded() => Run(() =>
        {
            bool pending = File.Exists(TableBuilder.GetManifestPath(savePath) + ".pending");
            bool ok = TableBuilder.Recover(savePath); ClearPlan();
            _status = ok ? (pending ? "Restored — 이전 파일 확인 완료. " : "") + StateLabel(TableBuilder.GetStatus(savePath).State)
                : "RecoveryRequired — 복구를 확인할 수 없습니다. 현재 파일과 journal을 보존했습니다.";
            RefreshRecordedStatus();
        });
        private static int[] ParseIds(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return Array.Empty<int>();
            return text.Split(',').Select(s => int.TryParse(s.Trim(), System.Globalization.NumberStyles.AllowLeadingSign, System.Globalization.CultureInfo.InvariantCulture, out int id)
                ? id : throw new ArgumentException("Migration IDs must be explicit signed Int32 values.")).ToArray();
        }
        private void Run(Action action)
        {
            try { action(); }
            catch (TableInputException e) { ClearPlan(); _status = e.Diagnostic.ToString(); }
            catch (TableBuildRecoveryException) { ClearPlan(); _status = "RecoveryRequired: 적용 실패 후 복구를 확인하지 못했습니다. 관리·복구에서 기록을 확인하세요."; }
            catch (Exception e)
            {
                bool restored = _prepared?.State == TableBuildState.Restored; ClearPlan();
                _status = restored ? "Restored: 적용에 실패했으나 이전 파일을 확인했습니다. 다시 변경사항을 확인하세요."
                    : "차단됨 (" + e.GetType().Name + "). 필수 설정·원본·Host 등록을 확인하고 변경사항을 다시 확인하세요. 원본은 변경하지 않았습니다.";
            }
        }
    }
}

