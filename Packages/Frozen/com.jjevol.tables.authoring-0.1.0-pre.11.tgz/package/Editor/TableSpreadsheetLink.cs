using System;
using System.Text.RegularExpressions;

namespace jjevol
{
    /// <summary>
    /// The Google spreadsheet a project's tables come from. The tool only stores and opens it:
    /// sheet data is copied by hand and pasted into the input TSV files. Nothing is downloaded.
    /// </summary>
    public static class TableSpreadsheetLink
    {
        private static readonly Regex UrlPattern = new Regex(@"^https://docs\.google\.com/spreadsheets/d/([A-Za-z0-9_-]{20,})(?:[/?#].*)?$", RegexOptions.CultureInvariant);
        private static readonly Regex IdPattern = new Regex(@"^[A-Za-z0-9_-]{20,}$", RegexOptions.CultureInvariant);

        /// <summary>Accepts a spreadsheet address or its bare ID. Surrounding spaces are ignored.</summary>
        public static bool TryGetId(string value, out string id)
        {
            id = null; value = value?.Trim();
            if (string.IsNullOrEmpty(value)) return false;
            Match url = UrlPattern.Match(value);
            if (url.Success) { id = url.Groups[1].Value; return true; }
            if (IdPattern.IsMatch(value)) { id = value; return true; }
            return false;
        }

        /// <summary>The address to open. A full address keeps its tab (gid); a bare ID opens the spreadsheet.</summary>
        public static string OpenUrl(string value)
        {
            if (!TryGetId(value, out string id)) throw new ArgumentException("Not a Google spreadsheet address or ID.", nameof(value));
            value = value.Trim();
            return UrlPattern.IsMatch(value) ? value : "https://docs.google.com/spreadsheets/d/" + id + "/edit";
        }

        /// <summary>The spreadsheet saved in this project's Table Authoring settings, or empty when none is connected.</summary>
        public static string Saved => TableAuthoringProjectSettings.Read().spreadsheet ?? string.Empty;

        public static bool IsConnected => TryGetId(Saved, out _);
    }
}
