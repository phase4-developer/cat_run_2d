using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace jjevol
{
    public enum TableBuildState { Prepared, Applying, AppliedAwaitingCompile, Ready, Restored, RecoveryRequired }
    public sealed class TableBuildStatus
    {
        public TableBuildState State { get; }
        public string Reason { get; }
        internal TableBuildStatus(TableBuildState state, string reason) { State = state; Reason = reason; }
        public override string ToString() => State + ": " + Reason;
    }

    /// <summary>Editor-only completion of a recorded transaction, never a Runtime type registry.</summary>
    [InitializeOnLoad]
    internal static class TableCompilation
    {
        private static bool compilationErrors;
        private static bool previousCompileFailure;
        // Set when generated code is written while the flag is already on, cleared when a compile reports errors.
        // Until then the flag describes the compile before that write, so it says nothing about this generation.
        private static bool failureFlagIsOld;
        internal static Func<bool> ScriptCompilationFailed = () => EditorUtility.scriptCompilationFailed;
        private static bool CompilationFailed => ScriptCompilationFailed() && !failureFlagIsOld;
        private static readonly HashSet<string> failureWriteAttempts = new HashSet<string>(StringComparer.Ordinal);
        private static readonly HashSet<string> unrecordedFailures = new HashSet<string>(StringComparer.Ordinal);
        static TableCompilation()
        {
            CompilationPipeline.compilationStarted += OnCompilationStarted;
            CompilationPipeline.assemblyCompilationFinished += OnAssemblyCompilationFinished;
            CompilationPipeline.compilationFinished += OnCompilationFinished;
            EditorApplication.update += ObserveCompilerFailure;
            WhenIdle(() => Scan(CompilationFailed));
        }
        private static void OnCompilationStarted(object context) => compilationErrors = false;
        private static void OnAssemblyCompilationFinished(string assembly, CompilerMessage[] messages)
        {
            if (!messages.Any(m => m.type == CompilerMessageType.Error)) return;
            compilationErrors = true; failureFlagIsOld = false;
            Scan(true); // Record against the immutable journal even inside a synchronous Refresh.
        }
        private static void OnCompilationFinished(object context)
        {
            bool failed = compilationErrors || CompilationFailed;
            if (failed) Scan(true);
            WhenIdle(() => Scan(failed || CompilationFailed));
        }
        internal static void ExpectCompile() => failureFlagIsOld = ScriptCompilationFailed();
        private static void ObserveCompilerFailure()
        {
            bool failed = CompilationFailed;
            if (failed && !previousCompileFailure) Scan(true);
            previousCompileFailure = failed;
        }
        // No Inspector/repaint dependency and no IO retry: one action on the next idle update.
        internal static void WhenIdle(Action action)
        {
            double deadline = EditorApplication.timeSinceStartup + 120;
            EditorApplication.CallbackFunction tick = null;
            tick = () =>
            {
                if (EditorApplication.timeSinceStartup > deadline)
                {
                    EditorApplication.update -= tick;
                    Debug.LogWarning("[Table Authoring] Compile completion did not reach an idle Editor. Pending remains; explicitly verify or recover.");
                    return;
                }
                if (EditorApplication.isCompiling || EditorApplication.isUpdating) return;
                EditorApplication.update -= tick; action();
            };
            EditorApplication.update += tick;
        }
        // Test boundary: a real request keeps isCompiling on for the rest of an EditMode run, which shuts every Apply guard.
        internal static Action RequestCompilation = () => WhenIdle(() => CompilationPipeline.RequestScriptCompilation());
        internal static void Request() => RequestCompilation();
        private static void Scan(bool failed)
        {
            if ((!failed && (EditorApplication.isCompiling || EditorApplication.isUpdating)) || EditorApplication.isPlayingOrWillChangePlaymode) return;
            string directory = Path.Combine(TablePaths.Project, "ProjectSettings", "JJEvolTableAuthoring");
            if (!Directory.Exists(directory)) return;
            TablePaths.NoReparse(directory);
            foreach (string marker in Directory.GetFiles(directory, "*.json.pending"))
            {
                try
                {
                    TablePaths.NoReparse(marker);
                    var pending = JsonUtility.FromJson<TablePending>(File.ReadAllText(marker));
                    string output = TablePaths.Output(Path.Combine(TablePaths.Project, pending.output));
                    if (failed) RecordCompileFailure(output);
                    else Verify(output);
                }
                catch (Exception e) { Debug.LogWarning("[Table Authoring] Compile completion remains unresolved (" + e.GetType().Name + "). Pending was not accepted as Ready."); }
            }
        }
        private static string FailurePath(TableJournal journal) => Path.Combine(Path.GetDirectoryName(Path.Combine(TablePaths.Project, journal.id)), "compile-failed.json");
        private static void RecordCompileFailure(string output)
        {
            if (!ReadPending(output, out var journal, out var candidate, false)) return;
            string path = FailurePath(journal); TablePaths.NoReparse(path);
            if (File.Exists(path) || !failureWriteAttempts.Add(journal.id)) return;
            try { TableFiles.CreatePending(path, Encoding.UTF8.GetBytes("{\"version\":1,\"generation\":\"" + candidate.consume.definitionHash + "\"}")); }
            catch { unrecordedFailures.Add(journal.id); throw; }
        }
        internal static TableBuildStatus Status(string directory)
        {
            try
            {
                string output = TablePaths.Output(directory), path = TablePaths.Manifest(output);
                if (File.Exists(path + ".pending"))
                {
                    if (!ReadPending(output, out var journal, out var candidate)) return Required("Incomplete/mixed outputs or missing/foreign journal. Explicit recovery is required.");
                    if (File.Exists(FailurePath(journal)) || unrecordedFailures.Contains(journal.id) || CompilationFailed) return Required("Unity compilation failed. This generation is not Ready; explicitly restore before a new build.");
                    return new TableBuildStatus(TableBuildState.AppliedAwaitingCompile, "Files match the recorded generation. Verify the newly loaded game assembly after compilation.");
                }
                var manifest = TableManifest.Read(path, output);
                if (manifest.status != "Ready" || !TableFiles.VerifyManifest(manifest)) return Required(TableFiles.Describe(manifest));
                if (manifest.consume != null && CompilationFailed) return Required("Project has compilation errors; generated code cannot be accepted as currently usable.");
                if (manifest.consume != null && (EditorApplication.isCompiling || EditorApplication.isUpdating || !LoadedGeneration(manifest.consume)))
                    return new TableBuildStatus(TableBuildState.AppliedAwaitingCompile, "Committed/restored files are verified, but their matching loaded game assembly is not yet verified.");
                return new TableBuildStatus(TableBuildState.Ready, File.Exists(path) ? "Recorded generation verified." : "No recorded generation.");
            }
            catch (Exception e) { return Required("State verification failed (" + e.GetType().Name + "); no success was reported."); }
        }
        internal static TableBuildStatus Verify(string directory)
        {
            try
            {
                string output = TablePaths.Output(directory), path = TablePaths.Manifest(output);
                if (!File.Exists(path + ".pending")) return Status(output);
                using var gate = TablePaths.Gate(path);
                if (!ReadPending(output, out var journal, out var candidate)) return Required("Cannot verify the complete pending generation/journal.");
                if (File.Exists(FailurePath(journal)) || unrecordedFailures.Contains(journal.id) || CompilationFailed) return Required("Compilation failed. Explicit recovery is required; no automatic promotion.");
                if (EditorApplication.isCompiling || EditorApplication.isUpdating || !LoadedGeneration(candidate.consume))
                    return new TableBuildStatus(TableBuildState.AppliedAwaitingCompile, "A matching compiled and loaded game assembly has not been verified.");
                var ready = candidate.Copy(); ready.status = "Ready"; ready.journal = "";
                string currentHash = TablePaths.HashFile(path), readyHash = TableHash.Bytes(ready.Bytes());
                if (currentHash != readyHash) TableFiles.Checkpoint(path, ready.Bytes(), currentHash);
                if (TablePaths.HashFile(path) != readyHash || !TableFiles.VerifyManifest(ready) || TablePaths.HashFile(path + ".pending") != journal.markerHash)
                    return Required("Compile completion checkpoint/output verification failed.");
                File.Delete(path + ".pending");
                if (File.Exists(path + ".pending")) return Required("Compile completion marker removal was not confirmed.");
                return new TableBuildStatus(TableBuildState.Ready, "Newly loaded enum/extension generation, complete files and checkpoint verified.");
            }
            catch (Exception e)
            {
                Exception cause = e; while (cause.InnerException != null) cause = cause.InnerException;
                Debug.LogWarning("[Table Authoring] Compile completion failed (" + cause.GetType().Name + ", HRESULT 0x" + cause.HResult.ToString("X8") + "). No Ready result was returned.");
                return Required("Compile completion failed; retain pending and explicitly verify or recover.");
            }
        }
        private static TableBuildStatus Required(string reason) => new TableBuildStatus(TableBuildState.RecoveryRequired, reason);
        private static bool ReadPending(string output, out TableJournal journal, out TableManifest candidate, bool requireAppliedCheckpoint = true)
        {
            journal = null; candidate = null;
            string manifest = TablePaths.Manifest(output), markerPath = manifest + ".pending"; TablePaths.NoReparse(markerPath);
            if (!File.Exists(markerPath)) return false;
            var marker = JsonUtility.FromJson<TablePending>(File.ReadAllText(markerPath));
            if (marker == null || marker.version != 1 || marker.output != TablePaths.Relative(output) || string.IsNullOrEmpty(marker.journal)) return false;
            string path = Path.GetFullPath(Path.Combine(TablePaths.Project, marker.journal));
            string root = Path.Combine(TablePaths.Project, "Library", "JJEvol", "TableAuthoring") + Path.DirectorySeparatorChar;
            if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(path)) return false;
            TablePaths.NoReparse(path); journal = TableJournal.Parse(File.ReadAllText(path));
            if (journal == null || (journal.version != 1 && journal.version != 2) || journal.id != TablePaths.Relative(path) || journal.manifest != TablePaths.Relative(manifest) ||
                journal.output != marker.output || journal.entries == null || TablePaths.HashFile(markerPath) != journal.markerHash) return false;
            candidate = TableManifest.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(journal.resultManifest)));
            if (candidate == null || candidate.status != "AppliedAwaitingCompile" || candidate.journal != journal.id || candidate.output != marker.output || candidate.consume == null) return false;
            ConsumeTypesCodeGenerator.ValidateRecord(candidate.consume);
            if (!requireAppliedCheckpoint) return true; // Only a create-only failure receipt, never a data/checkpoint mutation.
            if (!TableFiles.IsResultManifest(journal, TablePaths.HashFile(manifest)) || !TableFiles.VerifyManifest(candidate)) return false;
            var record = journal;
            return record.entries.All(entry => TablePaths.HashFile(TableFiles.EntryPath(record, entry)) == entry.newHash);
        }
        private static bool LoadedGeneration(ConsumeCodeRecord record)
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().SingleOrDefault(a => a.GetName().Name == record.assembly);
            Type type = assembly?.GetType(record.space + "." + record.enumName, false);
            Type extensions = assembly?.GetType(record.space + "." + record.enumName + "Extensions", false);
            if (type == null || !type.IsEnum || Enum.GetUnderlyingType(type) != typeof(int) || extensions == null ||
                (string)extensions.GetField("DefinitionHash", BindingFlags.Public | BindingFlags.Static)?.GetRawConstantValue() != record.definitionHash) return false;
            string[] names = Enum.GetNames(type);
            if (names.Length != record.active.Count || record.active.Any(s => !names.Contains(s.name) || Convert.ToInt32(Enum.Parse(type, s.name)) != s.id)) return false;
            MethodInfo forward = extensions.GetMethod("ToConsumeTypeId", BindingFlags.Public | BindingFlags.Static);
            MethodInfo reverse = extensions.GetMethod("TryTo" + record.enumName, BindingFlags.Public | BindingFlags.Static);
            if (forward == null || reverse == null || forward.ReturnType.FullName != "jjevol.ConsumeTypeId" || reverse.ReturnType != typeof(bool)) return false;
            Type wire = forward.ReturnType; PropertyInfo value = wire.GetProperty("Value");
            foreach (var item in record.active)
            {
                object enumValue = Enum.Parse(type, item.name), id = forward.Invoke(null, new[] { enumValue });
                object[] args = { id, null };
                if ((int)value.GetValue(id) != item.id || !(bool)reverse.Invoke(null, args) || Convert.ToInt32(args[1]) != item.id) return false;
            }
            int unknown = int.MinValue;
            while (record.active.Any(s => s.id == unknown)) unknown = checked(unknown + 1);
            object[] unknownArgs = { Activator.CreateInstance(wire, unknown), null };
            return !(bool)reverse.Invoke(null, unknownArgs) && Convert.ToInt32(unknownArgs[1]) == unknown;
        }
    }
}
