using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace jjevol
{
    public static class TableAuthoringOptions
    {
        public static Func<byte[], byte[]> EncryptBytes { get; set; }
        public static Action<IReadOnlyList<TableBuildInput>> ValidateTables { get; set; }
        public static string CodecProfileVersion { get; set; } = "";
        public static string ValidationVersion { get; set; } = "1";
        // Host policy, not per-build switches in the authoring window. No credentials are stored.
        public static bool UseEncryption { get; set; } = true;
        public static IReadOnlyList<TableSchema> Schemas { get; set; } = Array.Empty<TableSchema>();
    }
    public sealed class TableBuildInput
    {
        public string TableName { get; }
        public string SourcePath { get; }
        public string Text { get; }
        private readonly TableDocument _document;
        public IReadOnlyList<TSVRow> Rows => Array.AsReadOnly(_document.Records.Select(r => new TSVRow(_document.Headers.Select((h, c) => new { h, c }).ToDictionary(p => p.h, p => r[p.c].Value))).ToArray());
        public TableDocument Document => _document;
        internal TableBuildInput(TableDocument document)
        {
            _document = document; SourcePath = document.Input.Source; TableName = document.Input.TableName; Text = document.RuntimeText;
        }
        public long RequireInt64(int rowIndex, string header)
        {
            int c = _document.Headers.ToList().FindIndex(h => string.Equals(h, TSVRow.NormalizeHeader(header ?? ""), StringComparison.OrdinalIgnoreCase));
            if (c < 0 || rowIndex < 0 || rowIndex >= _document.Records.Count) throw new InvalidDataException("Required column or row is missing.");
            var cell = _document.Records[rowIndex][c];
            if (!long.TryParse(cell.Value, System.Globalization.NumberStyles.AllowLeadingSign, System.Globalization.CultureInfo.InvariantCulture, out long value))
                throw new InvalidDataException($"Invalid Int64 at {TableName} row {(cell.Row != 0 ? cell.Row : rowIndex + 2)}, column {(cell.Column != 0 ? cell.Column : c + 1)}, line {cell.Line}:{cell.Character}.");
            return value;
        }
    }
    public sealed class TableBuildResult
    {
        public IReadOnlyList<string> OutputFiles { get; }
        public int RemovedObsoleteFiles { get; }
        public bool NoOp { get; }
        public TableBuildState State { get; }
        internal TableBuildResult(List<string> files, int removed, bool noOp, TableBuildState state = TableBuildState.Ready) { OutputFiles = files.AsReadOnly(); RemovedObsoleteFiles = removed; NoOp = noOp; State = state; }
    }
    public static class TableBuilder
    {
        /// <summary>Source-compatible safe upsert. Full/Remove/adoption require an explicit previewed request.</summary>
        public static TableBuildResult Build(string inputDirectory, string outputDirectory, bool useEncrypt = true,
            Action<IReadOnlyList<TableBuildInput>> validate = null)
        {
            TablePaths.Output(outputDirectory); TablePaths.Disjoint(inputDirectory, outputDirectory);
            return Prepare(Plan(new TableBuildRequest(ReadDirectory(inputDirectory), outputDirectory, useEncrypt, validate: validate, catalogDirectory: inputDirectory))).Apply();
        }
        public static IReadOnlyList<TableInput> ReadDirectory(string directory, TableDialect dialect = TableDialect.PlainTsv)
        {
            string full = Path.GetFullPath(directory); TablePaths.NoReparse(full);
            if (!Directory.Exists(full)) throw new DirectoryNotFoundException("Table input directory does not exist.");
            return Array.AsReadOnly(Directory.GetFiles(full).Where(p => new[] { ".tsv", ".txt" }.Contains(Path.GetExtension(p), StringComparer.OrdinalIgnoreCase))
                .OrderBy(p => p, StringComparer.Ordinal).Select(p => TableInput.FromFile(p, dialect)).ToArray());
        }
        public static TableBuildPlan Plan(TableBuildRequest request) => new TableBuildPlan(request ?? throw new ArgumentNullException(nameof(request)));
        public static TablePreparedBuild Prepare(TableBuildPlan plan) => new TablePreparedBuild(plan ?? throw new ArgumentNullException(nameof(plan)));
        public static bool Recover(string outputDirectory) => TableFiles.Recover(outputDirectory);
        /// <summary>Generated files that differ from the last recorded build. Empty while an interrupted build awaits <see cref="Recover"/>.</summary>
        public static IReadOnlyList<TableFileDifference> GetFileDifferences(string outputDirectory) => TableFiles.GetDifferences(outputDirectory).AsReadOnly();
        /// <summary>Records the current files as the new baseline without changing them. <paramref name="reviewed"/> is what the user confirmed, from <see cref="GetFileDifferences"/>; files that changed since then are refused.</summary>
        public static void AcceptCurrentFiles(string outputDirectory, IReadOnlyList<TableFileDifference> reviewed) => TableFiles.AcceptCurrentFiles(outputDirectory, reviewed ?? throw new ArgumentNullException(nameof(reviewed)));
        /// <summary>Rebuilds generated code that differs from its record, from the recorded definition. Hand edits in those files are lost. Returns <see cref="TableBuildState.AppliedAwaitingCompile"/> until the compiled assembly is verified, as a normal build does.</summary>
        public static TableBuildState RegenerateCode(string outputDirectory, IReadOnlyList<TableFileDifference> reviewed) => TableFiles.RegenerateCode(outputDirectory, reviewed ?? throw new ArgumentNullException(nameof(reviewed)));
        public static TableBuildStatus GetStatus(string outputDirectory) => TableCompilation.Status(outputDirectory);
        public static TableBuildStatus VerifyCompiledGeneration(string outputDirectory) => TableCompilation.Verify(outputDirectory);
        public static void ResumeCompilation(string outputDirectory)
        {
            if (GetStatus(outputDirectory).State != TableBuildState.AppliedAwaitingCompile) throw new InvalidOperationException("Only a verified awaiting generation can request compilation. Recover failed/uncertain builds first.");
            TableCompilation.Request();
        }
        public static string GetManifestPath(string outputDirectory) => TablePaths.Manifest(TablePaths.Output(outputDirectory));
        public static IReadOnlyList<string> GetManagedNames(string outputDirectory)
        { string output = TablePaths.Output(outputDirectory); return Array.AsReadOnly(TableManifest.Read(TablePaths.Manifest(output), output).tables.Select(t => t.name).ToArray()); }
        internal static string Decode(byte[] bytes, bool encrypted, Func<byte[], byte[]> decrypt)
        {
            string text = new UTF8Encoding(false, true).GetString(bytes);
            if (text.StartsWith("\uFEFF", StringComparison.Ordinal)) text = text.Substring(1);
            if (!encrypted) return text;
            if (decrypt == null) throw new InvalidOperationException("Host decoder is required.");
            byte[] decoded = decrypt(Convert.FromBase64String(text));
            if (decoded == null || decoded.Length == 0) throw new InvalidDataException("Decoder returned no data.");
            return new UTF8Encoding(false, true).GetString(decoded);
        }
    }
}
