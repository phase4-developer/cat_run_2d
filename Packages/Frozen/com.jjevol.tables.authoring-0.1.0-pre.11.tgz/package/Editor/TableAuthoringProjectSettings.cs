using System;
using System.IO;
using UnityEngine;

namespace jjevol
{
    /// <summary>Nonsecret Editor configuration. Output ownership remains in the existing manifests.</summary>
    [Serializable]
    internal sealed class TableAuthoringProjectSettings
    {
        public int version = 1;
        public string inputDirectory = "", outputDirectory = "";
        public string codeDirectory = "", gameNamespace = "", enumName = "GameConsumeType";
        // Google spreadsheet the TSV inputs are copied from: an address or bare ID. Opened only, never downloaded.
        public string spreadsheet = "";
        internal string Input => string.IsNullOrEmpty(inputDirectory) ? CommonDataToolSettings.Current.TableInputDirectory : inputDirectory;
        internal string Output => string.IsNullOrEmpty(outputDirectory) ? CommonDataToolSettings.Current.TableOutputDirectory : outputDirectory;
        internal static string PathName => Path.Combine(TablePaths.Project, "ProjectSettings", "JJEvolTableAuthoringSettings.json");
        internal static string CurrentHash { get { TablePaths.NoReparse(PathName); return TablePaths.HashFile(PathName); } }
        internal static TableAuthoringProjectSettings Read()
        {
            TablePaths.NoReparse(PathName);
            if (!File.Exists(PathName)) return new TableAuthoringProjectSettings();
            var value = JsonUtility.FromJson<TableAuthoringProjectSettings>(File.ReadAllText(PathName));
            if (value != null && value.spreadsheet == null) value.spreadsheet = "";
            if (value == null || value.version != 1 || value.enumName == null) throw new InvalidDataException("Unsupported or damaged Table Authoring project settings. Existing settings were not overwritten.");
            return value;
        }
        internal void Save(string expectedHash)
        {
            TablePaths.Output(Output);
            spreadsheet = spreadsheet?.Trim() ?? "";
            if (spreadsheet.Length != 0 && !TableSpreadsheetLink.TryGetId(spreadsheet, out _))
                throw new ArgumentException("Spreadsheet must be a Google spreadsheet address (https://docs.google.com/spreadsheets/d/...) or its ID. Settings were not saved.");
            if (!string.IsNullOrWhiteSpace(codeDirectory) || !string.IsNullOrWhiteSpace(gameNamespace)) ValidateGame();
            TablePaths.NoReparse(PathName); Directory.CreateDirectory(Path.GetDirectoryName(PathName));
            using var gate = TablePaths.Gate(PathName);
            if (CurrentHash != expectedHash) throw new IOException("Project settings changed in another window. Reload settings before saving.");
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(JsonUtility.ToJson(this, true));
            TableFiles.Checkpoint(PathName, bytes, expectedHash);
            if (TablePaths.HashFile(PathName) != TableHash.Bytes(bytes)) throw new IOException("Project settings save could not be verified.");
        }
        internal void ValidateGame()
        {
            ConsumeTypesCodeGenerator.ValidateTypeNames(gameNamespace, enumName);
            string root = ConsumeTypesCodeGenerator.CodeRoot(codeDirectory);
            TablePaths.Disjoint(root, TablePaths.Output(Output));
            if (!string.IsNullOrWhiteSpace(Input)) TablePaths.Disjoint(root, Path.GetFullPath(Input));
            string assembly = ConsumeTypesCodeGenerator.AssemblyDefinition(root);
            var definition = JsonUtility.FromJson<ConsumeAssemblyDefinition>(File.ReadAllText(assembly));
            if (string.IsNullOrWhiteSpace(definition?.name) || !System.Linq.Enumerable.Any(definition.references ?? Array.Empty<string>(), ConsumeTypesCodeGenerator.IsEconomyReference))
                throw new InvalidDataException("Game asmdef must explicitly reference JJEvol.Economy.Runtime. No asmdef was changed.");
        }
        internal ConsumeTypesGenerationSettings Generation(ConsumeTypeMigration migration = null)
        { ValidateGame(); return new ConsumeTypesGenerationSettings(codeDirectory, gameNamespace, enumName, "ConsumeTypes", migration); }
    }
}
