using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace jjevol
{
    public sealed class ConsumeTypeMigration
    {
        public IReadOnlyList<int> RenameIds { get; }
        public IReadOnlyList<int> RetireIds { get; }
        public string Reason { get; }
        public ConsumeTypeMigration(IEnumerable<int> renameIds = null, IEnumerable<int> retireIds = null, string reason = "")
        {
            RenameIds = Array.AsReadOnly((renameIds ?? Array.Empty<int>()).Distinct().OrderBy(i => i).ToArray());
            RetireIds = Array.AsReadOnly((retireIds ?? Array.Empty<int>()).Distinct().OrderBy(i => i).ToArray());
            Reason = reason ?? "";
            if ((RenameIds.Count != 0 || RetireIds.Count != 0) && string.IsNullOrWhiteSpace(Reason)) throw new ArgumentException("A scoped migration requires a reason.");
        }
    }

    /// <summary>Explicit game-owned output approval. No game or folder is selected by the Framework.</summary>
    public sealed class ConsumeTypesGenerationSettings
    {
        public string TableName { get; }
        public string OutputDirectory { get; }
        public string Namespace { get; }
        public string EnumName { get; }
        public ConsumeTypeMigration Migration { get; }
        public ConsumeTypesGenerationSettings(string outputDirectory, string @namespace, string enumName = "GameConsumeType",
            string tableName = "ConsumeTypes", ConsumeTypeMigration migration = null)
        { OutputDirectory = outputDirectory; Namespace = @namespace; EnumName = enumName; TableName = tableName; Migration = migration ?? new ConsumeTypeMigration(); }
        internal string Fingerprint => TableHash.Parts(new[] { OutputDirectory, Namespace, EnumName, TableName, Migration.Reason }
            .Concat(Migration.RenameIds.Select(i => "rename:" + i.ToString(CultureInfo.InvariantCulture)))
            .Concat(Migration.RetireIds.Select(i => "retire:" + i.ToString(CultureInfo.InvariantCulture))));
    }

    public sealed class ConsumeTypeDefinition
    {
        public int TypeId { get; }
        public string CodeName { get; }
        public string DisplayName { get; }
        public string LocalizationKey { get; }
        internal ConsumeTypeDefinition(int id, string name, string display, string localization)
        { TypeId = id; CodeName = name; DisplayName = display; LocalizationKey = localization; }
    }

    public sealed class ConsumeTypesCodePlan
    {
        public IReadOnlyList<ConsumeTypeDefinition> Definitions { get; }
        public IReadOnlyList<string> Differences { get; }
        public IReadOnlyList<TableOutputChange> Changes { get; }
        public string EnumSource { get; }
        public string ExtensionsSource { get; }
        public string DefinitionHash { get; }
        internal readonly ConsumeCodeRecord Record;
        internal readonly string Inventory, AssemblyDefinitionPath, AssemblyDefinitionHash;
        internal ConsumeTypesCodePlan(TableDocument document, ConsumeTypesGenerationSettings settings, TableManifest basis,
            string tableOutput, string manifest, List<TableDiagnostic> diagnostics, Dictionary<string, string> preconditions)
        {
            var differences = new List<string>(); var definitions = new List<ConsumeTypeDefinition>(); var changes = new List<TableOutputChange>();
            Action<string, string> error = (code, reason) => diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, code, settings.TableName, "ConsumeTypes generation", reason));
            if (EditorUtility.scriptCompilationFailed) error("ProjectCompileErrors", "Resolve existing Unity compilation errors before preparing a generated source change.");
            string root = ConsumeTypesCodeGenerator.CodeRoot(settings.OutputDirectory);
            ConsumeTypesCodeGenerator.ValidateTypeNames(settings.Namespace, settings.EnumName);
            TablePaths.Disjoint(root, tableOutput);
            foreach (var input in new[] { document?.Input }.Where(i => i?.FilePath != null)) TablePaths.Disjoint(Path.GetDirectoryName(input.FilePath), root);
            AssemblyDefinitionPath = ConsumeTypesCodeGenerator.AssemblyDefinition(root);
            AssemblyDefinitionHash = TablePaths.HashFile(AssemblyDefinitionPath); preconditions[AssemblyDefinitionPath] = AssemblyDefinitionHash;
            var gameAssembly = JsonUtility.FromJson<ConsumeAssemblyDefinition>(File.ReadAllText(AssemblyDefinitionPath));
            string assembly = gameAssembly?.name;
            if (string.IsNullOrWhiteSpace(assembly)) throw new InvalidDataException("The game assembly definition has no name.");
            if (!(gameAssembly.references ?? Array.Empty<string>()).Any(ConsumeTypesCodeGenerator.IsEconomyReference))
                error("ConsumeAssemblyDependency", "The game asmdef must explicitly reference JJEvol.Economy.Runtime (name or GUID). The Authoring assembly does not acquire that Runtime dependency.");
            Inventory = TablePaths.Inventory(root);
            definitions.AddRange(ConsumeTypesCodeGenerator.ReadDefinitions(document, settings.TableName, settings.EnumName, diagnostics));
            Definitions = Array.AsReadOnly(definitions.OrderBy(d => d.TypeId).ToArray());
            DefinitionHash = ConsumeTypesCodeGenerator.DefinitionHash(settings.Namespace, settings.EnumName,
                Definitions.Select(d => new ConsumeSymbol { id = d.TypeId, name = d.CodeName }));
            Record = new ConsumeCodeRecord { output = TablePaths.Relative(root), space = settings.Namespace, enumName = settings.EnumName,
                assembly = assembly, definitionHash = DefinitionHash, generator = ConsumeTypesCodeGenerator.Version,
                active = Definitions.Select(d => new ConsumeSymbol { id = d.TypeId, name = d.CodeName }).ToList() };
            var previous = basis.consume;
            if (previous != null)
            {
                ConsumeTypesCodeGenerator.ValidateRecord(previous);
                if (previous.output != Record.output || previous.space != Record.space || previous.enumName != Record.enumName || previous.assembly != Record.assembly)
                    error("ConsumeIdentityChange", "Output root, namespace, enum or assembly identity changes require a separate source migration; automatic relocation is blocked.");
                Record.retired = previous.retired.Select(s => s.Copy()).ToList(); Record.symbols = previous.symbols.Select(s => s.Copy()).ToList();
                Record.migrations = previous.migrations.ToList();
                foreach (var item in Definitions)
                {
                    if (previous.retired.Any(s => s.id == item.TypeId)) error("RetiredTypeId", "A retired typeId cannot be reused: " + item.TypeId);
                    if (previous.symbols.Any(s => string.Equals(s.name, item.CodeName, StringComparison.OrdinalIgnoreCase) && s.id != item.TypeId))
                        error("RenumberTypeId", "Existing/historical codeName cannot move to another numeric ID: " + item.CodeName);
                    var old = previous.active.FirstOrDefault(s => s.id == item.TypeId);
                    if (old == null) differences.Add("Add ID " + item.TypeId + ": " + item.CodeName);
                    else if (old.name != item.CodeName)
                    {
                        differences.Add("BREAKING rename ID " + item.TypeId + ": " + old.name + " -> " + item.CodeName);
                        if (!settings.Migration.RenameIds.Contains(item.TypeId)) error("RenameApprovalRequired", "Approve this exact rename ID and record migration reason: " + item.TypeId);
                        else Record.migrations.Add("Rename " + item.TypeId + ": " + old.name + " -> " + item.CodeName + " / " + settings.Migration.Reason);
                    }
                }
                foreach (var removed in previous.active.Where(s => !Definitions.Any(d => d.TypeId == s.id)))
                {
                    differences.Add("BREAKING retire ID " + removed.id + ": " + removed.name);
                    if (!settings.Migration.RetireIds.Contains(removed.id)) error("RetireApprovalRequired", "Deletion is blocked unless this exact ID is explicitly retired: " + removed.id);
                    else { Record.retired.Add(removed.Copy()); Record.migrations.Add("Retire " + removed.id + ": " + removed.name + " / " + settings.Migration.Reason); }
                }
            }
            else differences.AddRange(Definitions.Select(d => "Initial ID " + d.TypeId + ": " + d.CodeName));
            foreach (var item in Record.active)
                if (!Record.symbols.Any(s => s.id == item.id && s.name == item.name)) Record.symbols.Add(item.Copy());
            Record.retired = Record.retired.OrderBy(s => s.id).ToList(); Record.symbols = Record.symbols.OrderBy(s => s.id).ThenBy(s => s.name, StringComparer.Ordinal).ToList();
            if (Definitions.Any(d => d.TypeId == 0)) differences.Add("Explicit ID 0: " + Definitions.First(d => d.TypeId == 0).CodeName + " (game-owned meaning).");
            ConsumeTypesCodeGenerator.CheckOwners(Record, manifest, diagnostics);
            foreach (string typeName in new[] { Record.enumName, Record.enumName + "Extensions" })
                foreach (var loaded in AppDomain.CurrentDomain.GetAssemblies())
                    if (loaded.GetType(Record.space + "." + typeName, false) != null && (previous == null || loaded.GetName().Name != previous.assembly))
                        error("ConsumeTypeCollision", "A compiled type already owns " + Record.space + "." + typeName);
            EnumSource = ConsumeTypesCodeGenerator.EnumText(Record); ExtensionsSource = ConsumeTypesCodeGenerator.ExtensionsText(Record);
            var texts = new[] { EnumSource, ExtensionsSource }; var paths = ConsumeTypesCodeGenerator.Paths(Record);
            for (int i = 0; i < paths.Length; i++)
            {
                string path = paths[i]; TablePaths.NoReparse(path); TablePaths.NoReparse(path + ".meta");
                preconditions[path] = TablePaths.HashFile(path); preconditions[path + ".meta"] = TablePaths.HashFile(path + ".meta");
                var old = previous?.files.FirstOrDefault(f => f.name == Path.GetFileName(path));
                if (old == null && (File.Exists(path) || File.Exists(path + ".meta"))) error("GeneratedUnmanagedConflict", "An existing unowned generated filename/meta is never overwritten: " + Path.GetFileName(path));
                if (old != null)
                    foreach (var difference in TableFiles.Compare(old.name, path, old.hash, old.metaHash, old.guid))
                        error("GeneratedManagedConflict", difference.ToString());
                var action = old == null ? TableOutputAction.Create : TablePaths.HashContent(path) == TableHash.Text(texts[i]) ? TableOutputAction.Unchanged : TableOutputAction.Update;
                changes.Add(new TableOutputChange(Path.GetFileName(path), path, action, "Explicit game C# output; existing meta/GUID preserved"));
            }
            Differences = differences.AsReadOnly(); Changes = changes.AsReadOnly();
        }
    }

    [Serializable] internal sealed class ConsumeSymbol { public int id; public string name; internal ConsumeSymbol Copy() => new ConsumeSymbol { id = id, name = name }; }
    [Serializable] internal sealed class ConsumeCodeFile { public string name, hash, metaHash, guid; }
    [Serializable] internal sealed class ConsumeCodeRecord
    {
        public string output, space, enumName, assembly, definitionHash, generator;
        public List<ConsumeSymbol> active = new List<ConsumeSymbol>(), retired = new List<ConsumeSymbol>(), symbols = new List<ConsumeSymbol>();
        public List<string> migrations = new List<string>();
        public List<ConsumeCodeFile> files = new List<ConsumeCodeFile>();
    }
    [Serializable] internal sealed class ConsumeAssemblyDefinition { public string name; public string[] references; }

    internal static class ConsumeTypesCodeGenerator
    {
        internal const string Version = "consume-types-1";
        private static readonly HashSet<string> Keywords = new HashSet<string>(("abstract as base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach goto if implicit in int interface internal is lock long namespace new null object operator out override params private protected public readonly ref return sbyte sealed short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using virtual void volatile while add alias and ascending args async await by descending dynamic equals file field from get global group init into join let managed nameof nint not notnull nuint on or orderby partial record remove required scoped select set unmanaged value var when where with yield").Split(' '), StringComparer.Ordinal);
        internal static IReadOnlyList<ConsumeTypeDefinition> ReadDefinitions(TableDocument document, string tableName, string enumName, List<TableDiagnostic> diagnostics)
        {
            var definitions = new List<ConsumeTypeDefinition>();
            Action<string, string> error = (code, reason) => diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, code, tableName, document?.Input.Source ?? "ConsumeTypes", reason));
            if (document == null) error("ConsumeTypesMissing", "Acquire and select the configured ConsumeTypes input.");
            else if (document.IsValid)
            {
                Func<string, int> headerIndex = name => document.Headers.ToList().FindIndex(h => string.Equals(h, name, StringComparison.OrdinalIgnoreCase));
                int idColumn = headerIndex("typeId"), nameColumn = headerIndex("codeName");
                int displayColumn = headerIndex("displayName"), localizationColumn = headerIndex("localizationKey");
                if (idColumn < 0 || nameColumn < 0) error("ConsumeTypesColumns", "typeId and codeName columns are required. Header names ignore case and surrounding spaces.");
                else
                {
                    var ids = new HashSet<int>(); var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    for (int row = 0; row < document.Records.Count; row++)
                    {
                        var cells = document.Records[row]; string name = cells[nameColumn].Value, value = cells[idColumn].Value;
                        Action<string, string, int> cellError = (code, reason, column) =>
                        { var cell = cells[column]; diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, code, tableName, document.Input.Source, reason, cell.Row != 0 ? cell.Row : row + 2, cell.Column != 0 ? cell.Column : column + 1, cell.Line, cell.Character, document.Headers[column])); };
                        if (!int.TryParse(value, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out int id))
                        { cellError("ConsumeTypeId", "An explicit signed Int32 decimal is required; invalid/overflow values are not defaulted.", idColumn); continue; }
                        if (!ids.Add(id)) cellError("DuplicateTypeId", "Duplicate numeric typeId.", idColumn);
                        if (!ConsumeTypesCodeGenerator.Identifier(name) || name.Equals(enumName, StringComparison.OrdinalIgnoreCase) || name.Equals("value__", StringComparison.OrdinalIgnoreCase))
                            cellError("ConsumeCodeName", "Invalid/reserved C# enum member or containing type collision. No sanitization is performed.", nameColumn);
                        if (!names.Add(name)) cellError("DuplicateCodeName", "Duplicate or case-only duplicate codeName.", nameColumn);
                        if (name == "None" && id != 0) cellError("ConsumeNone", "An explicitly declared None member must use 0. No None member is inserted.", idColumn);
                        definitions.Add(new ConsumeTypeDefinition(id, name, displayColumn < 0 ? "" : cells[displayColumn].Value, localizationColumn < 0 ? "" : cells[localizationColumn].Value));
                    }
                }
            }
            return Array.AsReadOnly(definitions.OrderBy(d => d.TypeId).ToArray());
        }
        internal static bool Identifier(string name) => name != null && Regex.IsMatch(name, @"\A[A-Za-z_][A-Za-z0-9_]*\z") && !Keywords.Contains(name);
        internal static void ValidateTypeNames(string space, string name)
        {
            if (!Identifier(name) || name == "value__" || string.IsNullOrEmpty(space) || space.Split('.').Any(s => !Identifier(s))) throw new ArgumentException("Explicit valid C# namespace and enum name are required.");
            TablePaths.Name(name); TablePaths.Name(name + "Extensions");
        }
        internal static string CodeRoot(string directory)
        {
            if (string.IsNullOrWhiteSpace(directory)) throw new ArgumentException("Approve a game code output folder.");
            string full = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string assets = Path.GetFullPath(Application.dataPath) + Path.DirectorySeparatorChar;
            if (!full.StartsWith(assets, StringComparison.OrdinalIgnoreCase) || full.Substring(assets.Length).Split(Path.DirectorySeparatorChar).Any(s => new[] { "Resources", "Editor", "StreamingAssets" }.Contains(s, StringComparer.OrdinalIgnoreCase)))
                throw new ArgumentException("Generated code must be inside the current Assets, outside Resources/Editor/StreamingAssets.");
            TablePaths.NoReparse(full); return full;
        }
        internal static string AssemblyDefinition(string codeRoot)
        {
            string assets = Path.GetFullPath(Application.dataPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            for (string cursor = Path.GetFullPath(codeRoot); cursor != null && (cursor.Equals(assets, StringComparison.OrdinalIgnoreCase) || cursor.StartsWith(assets + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)); cursor = Path.GetDirectoryName(cursor))
            {
                TablePaths.NoReparse(cursor); if (!Directory.Exists(cursor)) continue;
                if (Directory.GetFiles(cursor, "*.asmref").Length != 0) throw new ArgumentException("Generated output requires an explicit game asmdef, not an asmref boundary.");
                string[] definitions = Directory.GetFiles(cursor, "*.asmdef");
                if (definitions.Length == 1) { TablePaths.NoReparse(definitions[0]); return definitions[0]; }
                if (definitions.Length > 1) throw new ArgumentException("Ambiguous game assembly boundary.");
            }
            throw new ArgumentException("The approved code folder must be below an existing game-owned asmdef.");
        }
        internal static bool IsEconomyReference(string reference)
        {
            if (reference == "JJEvol.Economy.Runtime") return true;
            if (reference == null || !reference.StartsWith("GUID:", StringComparison.Ordinal)) return false;
            string path = AssetDatabase.GUIDToAssetPath(reference.Substring(5));
            if (string.IsNullOrEmpty(path) || !path.EndsWith(".asmdef", StringComparison.Ordinal) || !File.Exists(path)) return false;
            TablePaths.NoReparse(path);
            return JsonUtility.FromJson<ConsumeAssemblyDefinition>(File.ReadAllText(path))?.name == "JJEvol.Economy.Runtime";
        }
        internal static string[] Paths(ConsumeCodeRecord record)
        {
            ValidateTypeNames(record.space, record.enumName); string root = CodeRoot(Path.Combine(TablePaths.Project, record.output));
            return SourcePaths(root, record.enumName);
        }
        internal static string[] SourcePaths(string root, string enumName)
            => new[] { Path.Combine(root, enumName + ".Generated.cs"), Path.Combine(root, enumName + "Extensions.Generated.cs") };
        internal static void ValidateRecord(ConsumeCodeRecord record)
        {
            Paths(record);
            if (record.active == null || record.retired == null || record.symbols == null || record.files == null || record.migrations == null ||
                record.active.Any(s => s == null || !Identifier(s.name)) || record.retired.Any(s => s == null || !Identifier(s.name)) ||
                record.symbols.Any(s => s == null || !Identifier(s.name)) || record.active.Select(s => s.id).Distinct().Count() != record.active.Count ||
                record.active.Select(s => s.name).Distinct(StringComparer.OrdinalIgnoreCase).Count() != record.active.Count ||
                record.active.Any(s => record.retired.Any(r => r.id == s.id) || !record.symbols.Any(h => h.id == s.id && h.name == s.name)) ||
                record.retired.Select(s => s.id).Distinct().Count() != record.retired.Count ||
                record.symbols.GroupBy(s => s.name, StringComparer.OrdinalIgnoreCase).Any(g => g.Select(s => s.id).Distinct().Count() != 1) ||
                record.generator != Version || record.definitionHash != DefinitionHash(record.space, record.enumName, record.active) || record.files.Count != 2 ||
                !record.files.Select(f => f?.name).OrderBy(n => n, StringComparer.Ordinal).SequenceEqual(Paths(record).Select(Path.GetFileName).OrderBy(n => n, StringComparer.Ordinal)))
                throw new InvalidDataException("Invalid ConsumeTypes management metadata.");
            var texts = new[] { EnumText(record), ExtensionsText(record) };
            var paths = Paths(record);
            for (int i = 0; i < paths.Length; i++)
            {
                var file = record.files.Single(f => f.name == Path.GetFileName(paths[i]));
                if (file.hash != TableHash.Text(texts[i]) || file.metaHash == null || file.metaHash.Length != 64 || file.guid == null || file.guid.Length != 32 || !file.guid.All(Uri.IsHexDigit))
                    throw new InvalidDataException("ConsumeTypes metadata does not describe the deterministic generated source/meta.");
            }
        }
        internal static string DefinitionHash(string space, string name, IEnumerable<ConsumeSymbol> symbols)
            => TableHash.Parts(new[] { Version, space, name }.Concat(symbols.OrderBy(s => s.id).SelectMany(s => new[] { s.id.ToString(CultureInfo.InvariantCulture), s.name })));
        internal static void CheckOwners(ConsumeCodeRecord record, string ownManifest, List<TableDiagnostic> diagnostics)
        {
            string directory = Path.GetDirectoryName(ownManifest); if (!Directory.Exists(directory)) return;
            // An interrupted generation can claim a root before its first manifest checkpoint exists.
            foreach (string markerPath in Directory.GetFiles(directory, "*.json.pending"))
                if (!string.Equals(markerPath, ownManifest + ".pending", StringComparison.OrdinalIgnoreCase))
                    diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "OtherPendingGeneration", "", markerPath, "Resolve the other pending generation before acquiring/changing generated code ownership."));
            foreach (string path in Directory.GetFiles(directory, "*.json"))
            {
                if (string.Equals(path, ownManifest, StringComparison.OrdinalIgnoreCase)) continue;
                TablePaths.NoReparse(path); var other = TableManifest.Parse(File.ReadAllText(path));
                if (other?.consume == null) continue;
                var code = other.consume; Paths(code);
                string a = CodeRoot(Path.Combine(TablePaths.Project, record.output)), b = CodeRoot(Path.Combine(TablePaths.Project, code.output));
                if (a.Equals(b, StringComparison.OrdinalIgnoreCase) || a.StartsWith(b + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || b.StartsWith(a + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(record.space + "." + record.enumName, code.space + "." + code.enumName, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(record.space + "." + record.enumName + "Extensions", code.space + "." + code.enumName, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(record.space + "." + record.enumName, code.space + "." + code.enumName + "Extensions", StringComparison.OrdinalIgnoreCase))
                    diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "GeneratedOwnerConflict", "", path, "Another managed generation owns this code root or type identity."));
            }
        }
        private static string Header(ConsumeCodeRecord record) => "// <auto-generated/>\n// " + Version + "; definition " + record.definitionHash + "\n";
        internal static string EnumText(ConsumeCodeRecord record)
        {
            var text = new StringBuilder(Header(record)).Append("namespace ").Append(record.space).Append("\n{\n    public enum ").Append(record.enumName).Append(" : int\n    {\n");
            foreach (var item in record.active.OrderBy(s => s.id)) text.Append("        ").Append(item.name).Append(" = ").Append(item.id.ToString(CultureInfo.InvariantCulture)).Append(",\n");
            return text.Append("    }\n}\n").ToString();
        }
        internal static string ExtensionsText(ConsumeCodeRecord record)
        {
            string name = record.enumName;
            var text = new StringBuilder(Header(record)).Append("namespace ").Append(record.space).Append("\n{\n    public static class ").Append(name).Append("Extensions\n    {\n")
                .Append("        public const string DefinitionHash = \"").Append(record.definitionHash).Append("\";\n")
                .Append("        public static global::jjevol.ConsumeTypeId ToConsumeTypeId(this ").Append(name).Append(" value) => new global::jjevol.ConsumeTypeId((int)value);\n")
                .Append("        public static bool TryTo").Append(name).Append("(this global::jjevol.ConsumeTypeId typeId, out ").Append(name).Append(" value)\n        {\n            switch (typeId.Value)\n            {\n");
            foreach (var item in record.active.OrderBy(s => s.id)) text.Append("                case ").Append(item.id.ToString(CultureInfo.InvariantCulture)).Append(": value = ").Append(name).Append('.').Append(item.name).Append("; return true;\n");
            return text.Append("                default: value = (").Append(name).Append(")typeId.Value; return false; // Preserve unknown numeric ID; false means undefined.\n            }\n        }\n    }\n}\n").ToString();
        }
    }
}
