# JJEvol UI URP Bootstrap — local validation candidate

`com.jjevol.ui.urp@0.1.0-pre.6` activates the original `jjevol.UIManagerCreater`
as an optional package. Unity 6000.3.9f1 / URP 17.3.0 / Addressables 4.0.1 /
UniTask 2.5.10 were used. It is not a new UI system or an external release.

Direct dependencies: UI Addressables, URP, UniTask. Existing UI Addressables
brings UI Core, Resources Addressables, Audio Core, Effects Core and Input System transitively.
Economy, Runner, Managed Addressables and Effects UI are not required by this
bootstrap. URP is not forced into any existing Core package.

Place UIManager on the addressed Prefab root and wire its existing UI Camera and
Screen/Popup/HUD/Loading/Effect roots. Use a game-owned compatible URP pipeline
and Base Camera. Wire ScreenSpaceCamera Canvas references to the UI Camera;
Camera and its Canvas should be sibling objects under the manager. The default
key is `UIManager`; configure `UIManagerAddress` to use another game-owned key.

A root Canvas created in code must have its camera assigned at creation. A
ScreenSpaceCamera Canvas without a camera reads as Overlay, so UIManagerCreater
does not bind it to the UI Camera.

```csharp
await creator.StartInitAsync();
await UIManager.Instance.SpawnUIPopupAsync(gamePopupId);
creator.Shutdown();
```

The creator does not start itself. The game calls StartInitAsync when its data is
ready, and IsStarted reports that. Each scene opens its own first Screen from a scene
initializer.

The original public fields `mainCamera`, `cashScreenTypes`, `cashHudTypes`,
`createId`, no-argument StartInitAsync and Script GUID
`1dc16205668f7f741a7bd97f16a022fb` are preserved. New assembly identity is
`JJEvol.UI.URP.Runtime`; assembly-qualified/SerializeReference migrations and
actual game assets require their own validation. Do not install alongside the
original mobile source. Original text remains recoverable from STEP13 commit
deb457593c1ddf08be887b5f6adbcaa1e967c90a and the unchanged STEP12 tarball.

StartInitAsync completes after cache preparation and
camera binding. Same-scene concurrent calls share initialization. The overload
with CancellationToken cancels only that caller's wait. Shutdown cancels shared
work; Disable/Destroy also shut down. Failed initialization can be retried.
IsInitialized and LastInitializationError expose status without silently
accepting an invalid pipeline, camera or renderer.

Bootstrap owns only the root SDK InstantiateAsync handle it created and returns
it with ReleaseInstance(handle), including failed/canceled late results. Existing
UIManager children retain their UIInstanceOwner contracts. A preexisting root
is borrowed and remains the external creator's responsibility. No ordinary
Asset/Lease API substitutes for native SDK instance ownership.

SDK instantiation itself cannot be aborted. A restart waits for a retired native
load and deferred Destroy cleanup before creating another root. A provider that
never completes therefore needs game/operational timeout policy; Bootstrap does
not force-release live shared operations. Do not use ReleaseAllLoadedAssets as
normal shutdown.

Keep one creator in the first Scene and persist its GameObject across Scenes; a
creator per Scene is not supported. A started creator closes popups, drops Screens
outside its cache lists and reuses the UIManager on scene changes, and reconnects a
destroyed main camera through the active scene's MainCamera tag. Initially null mainCamera
preserves the original standalone UI Base-camera mode. Another active creator
is rejected rather than stealing the singleton.

Bootstrap does not assign Resources.AfterSceneReload. Existing game hooks may
await StartInitAsync; same-scene requests coalesce with scene callbacks. Duplicate
and destroyed stack entries are removed without changing other overlays' order;
shutdown detaches only the UI overlay and restores borrowed camera settings.

LateUpdate compares the bound cameras, render types, renderers and stack without
allocating and rebinds only when something changed. New root Canvases are found
through the manager's hierarchy size, plus a one-second scan for changes that keep
that size, such as adding a Canvas to an existing object. A new ScreenSpaceCamera
root Canvas can therefore wait up to one second in that case. Failed rebinds keep
the existing behavior: IsInitialized becomes false and LastInitializationError is set.

Runtime assembly references UI Core/UI Addressables/Resources/URP/Core RP/
Addressables/ResourceManager/UniTask; it has no Editor/vendor integration.
Tests are isolated Editor/Runtime test assemblies. Their full co-existence
fixture additionally uses the separately installed Audio/Effect SDK providers
and STEP14 Effects UI. Fixtures author only the dedicated STEP15 Host and never
copy game content. TMP Essentials come from installed uGUI.

See `Docs/Guide/Installation.md` and `Docs/Guide/Verification.md` in the
Framework checkout for installation, results and limits.
No Player/device/remote catalog/product-art quality claim is made. STEP12
Snapshot is unchanged; pinning this new candidate is a separate review.
