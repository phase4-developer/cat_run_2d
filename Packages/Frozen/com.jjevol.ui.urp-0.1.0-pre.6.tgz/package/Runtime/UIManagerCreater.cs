﻿using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
//추가
using System.Threading;
using UnityEngine.Rendering;
using UnityEngine.ResourceManagement.AsyncOperations;
//추가 종료
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace jjevol
{
    public class UIManagerCreater : Singleton<UIManagerCreater>
    {
        public Camera mainCamera;

        [Header("Caching Settings")]
        [UIAddressId(UIAddress.ScreenPrefix)] public List<string> cashScreenTypes;
        [UIAddressId(UIAddress.HudPrefix)] public List<string> cashHudTypes;

        public int createId;

        //수정
        private bool _init;
        private UniTaskCompletionSource _initTcs;
        //추가
        [SerializeField] private string uiManagerAddress = "UIManager";
        private UIManager _manager, _ownedManager;
        private AsyncOperationHandle<GameObject> _ownedHandle;
        private UniTaskCompletionSource<UIManager> _creation;
        private static UniTaskCompletionSource _nativeDrain;
        private CancellationTokenSource _lifecycleCTS, _requestCTS;
        private int _lifecycle, _generation;
        // Scene, not Scene.handle: 6.7 makes the handle a SceneHandle with no implicit int conversion. default means none.
        private Scene _requestScene, _readyScene;
        private bool _registered, _shutdown, _requiredBase, _started;
        private Camera _boundBase, _boundUI, _originalUICamera;
        private List<Camera> _boundStack;
        private UniversalAdditionalCameraData _boundBaseData, _boundUIData;
        private ScriptableRenderer _boundBaseRenderer, _boundUIRenderer;
        private readonly List<Canvas> _canvasScan = new();
        private int _boundHierarchyCount;
        private float _nextCanvasScan;
        private const float CanvasScanInterval = 1f;
        private CameraRenderType _originalRenderType;
        private CameraClearFlags _originalClearFlags;
        private readonly List<(Canvas canvas, Camera original)> _canvases = new();
        public string UIManagerAddress { get => uiManagerAddress; set => uiManagerAddress = value; }
        /// <summary>True after <see cref="StartInitAsync()"/> until Shutdown. Only a started creator follows scene changes.</summary>
        public bool IsStarted => _started;
        public bool IsInitialized => _init && _manager && _manager.isActiveAndEnabled;
        public Exception LastInitializationError { get; private set; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetBootstrapState()
        { _nativeDrain = null; _instance = null; applicationIsQuitting = false; }
        //추가 종료

        protected override void Awake()
        {
            if (!_instance || _instance == this || !_instance.isActiveAndEnabled) base.Awake();
        }
        private void OnEnable()
        {
            if (_instance && _instance != this && _instance.isActiveAndEnabled) return;
            InitializeSingleton();
            _shutdown = false;
            RegisterCallbacks();
        }
        private void OnDisable()
        {
            UnregisterCallbacks();
            Shutdown();
            if (_instance == this) _instance = null;
        }
        protected override void OnDestroy()
        {
            UnregisterCallbacks();
            Shutdown();
            if (_instance == this) base.OnDestroy();
        }
        private void _OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (mode == LoadSceneMode.Single || scene == SceneManager.GetActiveScene()) RefreshForScene();
        }
        private void OnActiveSceneChanged(Scene previous, Scene next) => RefreshForScene();
        private void RefreshForScene()
        {
            if (_started && !_shutdown && isActiveAndEnabled && _instance == this)
                StartInitAsync().Forget(exception => Debug.LogWarning("[UIManagerCreater] Scene initialization failed: " + exception.GetType().Name));
        }
        private void RegisterCallbacks()
        {
            if (_registered) return;
            SceneManager.sceneLoaded += _OnSceneLoaded;
            SceneManager.activeSceneChanged += OnActiveSceneChanged;
            _registered = true;
        }
        private void UnregisterCallbacks()
        {
            if (!_registered) return;
            SceneManager.sceneLoaded -= _OnSceneLoaded;
            SceneManager.activeSceneChanged -= OnActiveSceneChanged;
            _registered = false;
        }

        public UniTask StartInitAsync() => StartInitAsync(CancellationToken.None);
        //추가
        // Caller cancellation retires only that wait; Shutdown retires shared initialization.
        public UniTask StartInitAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!isActiveAndEnabled) return UniTask.FromException(new InvalidOperationException("Enable the UI bootstrap before initialization."));
            if (_instance && _instance != this && _instance.isActiveAndEnabled)
                return UniTask.FromException(new InvalidOperationException("Only one active UIManagerCreater may own UI initialization."));
            if (_instance != this) { InitializeSingleton(); RegisterCallbacks(); }
            _shutdown = false;
            _started = true;
            Scene scene = SceneManager.GetActiveScene();
            if (_initTcs != null && _initTcs.Task.Status == UniTaskStatus.Pending && _requestScene == scene)
                return _initTcs.Task.AttachExternalCancellation(cancellationToken);
            if (IsInitialized && _readyScene == scene)
            {
                try { _CameraSetting(_manager); return UniTask.CompletedTask; }
                catch (Exception exception) { _init = false; LastInitializationError = exception; return UniTask.FromException(exception); }
            }
            bool previousPending = _initTcs != null && _initTcs.Task.Status == UniTaskStatus.Pending;
            //추가
            bool sceneChanged = _requestScene != default && _requestScene != scene;
            //추가 종료
            Cancel(ref _requestCTS);
            if (_lifecycleCTS == null) _lifecycleCTS = CancellationTokenSource.CreateLinkedTokenSource(this.GetCancellationTokenOnDestroy());
            _requestCTS = CancellationTokenSource.CreateLinkedTokenSource(_lifecycleCTS.Token);
            _init = false;
            LastInitializationError = null;
            _requestScene = scene;
            int generation = ++_generation;
            var pending = _initTcs = new UniTaskCompletionSource();
            //수정
            InitAsync(generation, scene, pending, _requestCTS.Token, sceneChanged, previousPending).Forget();
            //수정 종료
            return pending.Task.AttachExternalCancellation(cancellationToken);
        }
        public void Shutdown()
        {
            _shutdown = true;
            _started = false;
            ++_lifecycle; ++_generation;
            bool pending = _initTcs != null && _initTcs.Task.Status == UniTaskStatus.Pending;
            Cancel(ref _requestCTS);
            Cancel(ref _lifecycleCTS);
            _initTcs?.TrySetCanceled();
            _initTcs = null;
            _init = false;
            if (pending && _manager && _manager != _ownedManager && _manager.isActiveAndEnabled) _manager.Init();
            DetachCamera();
            ReleaseOwnedManager();
            _manager = null;
            _readyScene = _requestScene = default;
            _requiredBase = false;
        }
        private static void Cancel(ref CancellationTokenSource source)
        { var previous = source; source = null; if (previous != null) { previous.Cancel(); previous.Dispose(); } }
        private bool Current(int generation) => this && isActiveAndEnabled && !_shutdown && generation == _generation;
        //추가 종료

        //수정
        private async UniTask InitAsync(int generation, Scene scene, UniTaskCompletionSource pending, CancellationToken token, bool sceneChanged, bool previousPending)
        //수정 종료
        {
            try
            {
                //추가
                // Retire the previous Scene's popups synchronously, before any load/cache await.
                // Publish the new request generation first so reentrant/duplicate callbacks share it.
                if (sceneChanged)
                {
                    var previous = _manager ? _manager : UIManager.HasInstance ? UIManager.Instance : null;
                    previous?.popupManager?.ForceCloseAllPopups();
                    token.ThrowIfCancellationRequested();
                    if (!Current(generation)) throw new OperationCanceledException(token);
                }
                // Existing pending-initialization reset, after Popup close and under this request's lifetime.
                if (previousPending && _manager && _manager.isActiveAndEnabled) _manager.Init();
                token.ThrowIfCancellationRequested();
                if (!Current(generation)) throw new OperationCanceledException(token);
                //추가 종료
                ValidatePipeline();
                var ui = await EnsureManagerAsync(token);
                token.ThrowIfCancellationRequested();
                if (!Current(generation)) throw new OperationCanceledException(token);
                if (!ui || !ui.isActiveAndEnabled || ui.screenManager == null || ui.popupManager == null || ui.hudManager == null)
                    throw new InvalidOperationException("UIManager Prefab must initialize its Screen/Popup/HUD roots in Awake.");
                _manager = ui;
                _CameraSetting(ui);
                var screens = cashScreenTypes == null ? new List<string>() : new List<string>(cashScreenTypes);
                var huds = cashHudTypes == null ? new List<string>() : new List<string>(cashHudTypes);
                //수정
                // A Scene boundary was already cleaned before awaiting: do not close its newly created popups later.
                if (!sceneChanged) ui.popupManager.CloseAllPopups();
                //수정 종료
                var remove = new List<string>();
                foreach (var pair in ui.screenManager.screenPool)
                    if (screens.Contains(pair.Key)) screens.Remove(pair.Key); else remove.Add(pair.Key);
                foreach (var type in remove) ui.screenManager.DestroyScreen(type);
                ui.hudManager.ReleaseUnusedHuds(huds);
                await ui.screenManager.CachingScreenAsync(screens).AttachExternalCancellation(token);
                token.ThrowIfCancellationRequested();
                await ui.hudManager.CachingHudAsync(huds).AttachExternalCancellation(token);
                token.ThrowIfCancellationRequested();
                token.ThrowIfCancellationRequested();
                if (!Current(generation)) throw new OperationCanceledException(token);
                _CameraSetting(ui);
                _readyScene = scene;
                _init = true;
                pending.TrySetResult();
            }
            catch (OperationCanceledException)
            { pending.TrySetCanceled(token); }
            catch (Exception exception)
            {
                if (Current(generation))
                {
                    _init = false;
                    LastInitializationError = exception;
                    DetachCamera();
                    ReleaseOwnedManager();
                    _manager = null;
                }
                pending.TrySetException(exception);
            }
            finally { if (ReferenceEquals(_initTcs, pending) && !_init) _initTcs = null; }
        }

        //추가
        private async UniTask<UIManager> EnsureManagerAsync(CancellationToken token)
        {
            while (_creation != null)
            {
                var previous = _creation;
                try { await previous.Task.AttachExternalCancellation(token); }
                catch (OperationCanceledException) { token.ThrowIfCancellationRequested(); }
                if (ReferenceEquals(_creation, previous)) await UniTask.NextFrame(cancellationToken: token);
            }
            if (_nativeDrain != null) await _nativeDrain.Task.AttachExternalCancellation(token);
            token.ThrowIfCancellationRequested();
            if (_ownedManager) return _ownedManager;
            if (UIManager.HasInstance) return UIManager.Instance;
            if (string.IsNullOrWhiteSpace(uiManagerAddress)) throw new InvalidOperationException("Configure a game-owned UIManager Addressables key.");
            var pending = _creation = new UniTaskCompletionSource<UIManager>();
            _CreateUIManagerAsync(_lifecycle, uiManagerAddress, pending).Forget();
            return await pending.Task.AttachExternalCancellation(token);
        }
        //추가 종료

        private async UniTaskVoid _CreateUIManagerAsync(int lifecycle, string key, UniTaskCompletionSource<UIManager> pending)
        {
            var previous = _nativeDrain;
            var drain = _nativeDrain = new UniTaskCompletionSource();
            AsyncOperationHandle<GameObject> operation = default;
            bool transferred = false;
            try
            {
                if (previous != null) await previous.Task;
                if (!this || !isActiveAndEnabled || lifecycle != _lifecycle) throw new OperationCanceledException();
                if (UIManager.HasInstance) { pending.TrySetResult(UIManager.Instance); return; }
                /* 제거: 고정 const path 대신 소비 게임이 설정하는 uiManagerAddress를 사용. 기본값은 원래 UIManager. */
                operation = Addressables.InstantiateAsync(key);
                var root = await operation;
                if (!this || !isActiveAndEnabled || lifecycle != _lifecycle)
                    throw new OperationCanceledException();
                var manager = root ? root.GetComponent<UIManager>() : null;
                if (!manager) throw new InvalidOperationException("The addressed Prefab root must contain UIManager.");
                root.name = "UIManager";
                _ownedHandle = operation;
                _ownedManager = manager;
                transferred = true;
                pending.TrySetResult(manager);
            }
            catch (OperationCanceledException) { pending.TrySetCanceled(); }
            catch (Exception exception) { pending.TrySetException(exception); }
            finally
            {
                if (!transferred && operation.IsValid())
                {
                    if (operation.Status == AsyncOperationStatus.Succeeded) Addressables.ReleaseInstance(operation);
                    else Addressables.Release(operation);
                    await UniTask.NextFrame();
                }
                if (ReferenceEquals(_creation, pending)) _creation = null;
                drain.TrySetResult();
                if (ReferenceEquals(_nativeDrain, drain)) _nativeDrain = null;
            }
        }

        //추가
        private void ReleaseOwnedManager()
        {
            var operation = _ownedHandle;
            _ownedHandle = default;
            _ownedManager = null;
            if (!operation.IsValid()) return;
            Addressables.ReleaseInstance(operation);
            var previous = _nativeDrain;
            var drain = _nativeDrain = new UniTaskCompletionSource();
            CompleteReleaseAsync(previous, drain).Forget();
        }
        private static async UniTaskVoid CompleteReleaseAsync(UniTaskCompletionSource previous, UniTaskCompletionSource drain)
        {
            if (previous != null) await previous.Task;
            await UniTask.NextFrame();
            drain.TrySetResult();
            if (ReferenceEquals(_nativeDrain, drain)) _nativeDrain = null;
        }
        private static void ValidatePipeline()
        {
            if (!(GraphicsSettings.currentRenderPipeline is UniversalRenderPipelineAsset))
                throw new InvalidOperationException("An active URP Render Pipeline Asset is required for UI URP bootstrap.");
        }
        private Camera ResolveBaseCamera()
        {
            if (mainCamera) { _requiredBase = true; return mainCamera; }
            if (!_requiredBase) return null; // Original null-main-camera standalone UI mode.
            var scene = SceneManager.GetActiveScene();
            foreach (var root in scene.GetRootGameObjects())
                foreach (var camera in root.GetComponentsInChildren<Camera>())
                    if (camera.CompareTag("MainCamera") && camera != _boundUI) return mainCamera = camera;
            throw new InvalidOperationException("The previous Base Camera was destroyed; configure the new Scene's MainCamera.");
        }
        //추가 종료

        private void _CameraSetting(UIManager ui)
        {
            ValidatePipeline();
            var camera = ui ? ui.UICamera : null;
            if (!camera || !camera.isActiveAndEnabled) throw new InvalidOperationException("UIManager needs an active UI Camera reference.");
            var main = ResolveBaseCamera();
            if (main == camera) throw new InvalidOperationException("UI and Base Cameras must be different objects.");
            var uiData = camera.GetUniversalAdditionalCameraData();
            List<Camera> stack = null;
            UniversalAdditionalCameraData mainData = null;
            if (main)
            {
                mainData = main.GetUniversalAdditionalCameraData();
                if (mainData.renderType != CameraRenderType.Base) throw new InvalidOperationException("Configured mainCamera must be URP Base.");
                if (mainData.scriptableRenderer == null || !mainData.scriptableRenderer.SupportsCameraStackingType(CameraRenderType.Base) ||
                    uiData.scriptableRenderer == null || !uiData.scriptableRenderer.SupportsCameraStackingType(CameraRenderType.Overlay))
                    throw new InvalidOperationException("The selected URP Renderer does not support Base/Overlay camera stacking.");
                if (mainData.scriptableRenderer.GetType() != uiData.scriptableRenderer.GetType())
                    throw new InvalidOperationException("Base and Overlay Cameras require compatible URP Renderer types.");
                stack = mainData.cameraStack;
                if (stack == null) throw new InvalidOperationException("URP Base Camera has no supported stack.");
            }
            if (_boundStack != null && !ReferenceEquals(_boundStack, stack)) _boundStack.RemoveAll(item => !item || item == _boundUI);
            if (!_originalUICamera)
            { _originalUICamera = camera; _originalRenderType = uiData.renderType; _originalClearFlags = camera.clearFlags; }
            uiData.renderType = main ? CameraRenderType.Overlay : CameraRenderType.Base;
            if (main) camera.clearFlags = CameraClearFlags.Depth;
            if (stack != null)
            {
                bool found = false;
                stack.RemoveAll(item => { if (!item) return true; if (item != camera) return false; if (found) return true; found = true; return false; });
                if (!found) stack.Add(camera); // Preserve the original stack position and other overlays' order.
            }
            _boundBase = main; _boundUI = camera; _boundStack = stack;
            _boundBaseData = mainData; _boundUIData = uiData;
            _boundBaseRenderer = main ? mainData.scriptableRenderer : null; _boundUIRenderer = uiData.scriptableRenderer;
            BindCanvases(ui, camera);
        }
        private void BindCanvases(UIManager ui, Camera camera)
        {
            ui.GetComponentsInChildren(true, _canvasScan);
            foreach (var canvas in _canvasScan)
            {
                if (!canvas.isRootCanvas || canvas.renderMode != RenderMode.ScreenSpaceCamera) continue;
                if (canvas.worldCamera && canvas.worldCamera != camera)
                    throw new InvalidOperationException("Root ScreenSpaceCamera Canvas references a different Camera.");
                if (!canvas.worldCamera) { _canvases.Add((canvas, null)); canvas.worldCamera = camera; }
            }
            _canvasScan.Clear();
            _boundHierarchyCount = ui.transform.hierarchyCount;
            _nextCanvasScan = Time.unscaledTime + CanvasScanInterval;
        }
        //추가
        private void DetachCamera()
        {
            if (_boundStack != null) _boundStack.RemoveAll(item => !item || item == _boundUI);
            if (_originalUICamera)
            { _originalUICamera.GetUniversalAdditionalCameraData().renderType = _originalRenderType; _originalUICamera.clearFlags = _originalClearFlags; }
            foreach (var entry in _canvases) if (entry.canvas && entry.canvas.worldCamera == _boundUI) entry.canvas.worldCamera = entry.original;
            _canvases.Clear(); _originalUICamera = null; _boundBase = _boundUI = null; _boundStack = null;
            _boundBaseData = _boundUIData = null; _boundBaseRenderer = _boundUIRenderer = null;
        }
        // 매 프레임 호출된다. 할당 없이 연결 상태만 비교하고, 달라졌을 때만 전체 바인딩을 다시 수행한다.
        private bool CameraBindingChanged(UIManager ui)
        {
            if (!(GraphicsSettings.currentRenderPipeline is UniversalRenderPipelineAsset)) return true;
            var camera = ui.UICamera;
            if (!camera || camera != _boundUI || !camera.isActiveAndEnabled || !_boundUIData) return true;
            var uiRenderer = _boundUIData.scriptableRenderer;
            if (uiRenderer == null || !ReferenceEquals(uiRenderer, _boundUIRenderer)) return true;
            if (mainCamera != _boundBase) return true;
            if (!mainCamera) return _requiredBase || _boundUIData.renderType != CameraRenderType.Base;
            if (!_boundBaseData || _boundBaseData.renderType != CameraRenderType.Base) return true;
            if (_boundUIData.renderType != CameraRenderType.Overlay || camera.clearFlags != CameraClearFlags.Depth) return true;
            var baseRenderer = _boundBaseData.scriptableRenderer;
            if (baseRenderer == null || !ReferenceEquals(baseRenderer, _boundBaseRenderer)) return true;
            var stack = _boundBaseData.cameraStack;
            if (stack == null || !ReferenceEquals(stack, _boundStack)) return true;
            int found = 0;
            for (int i = 0; i < stack.Count; i++)
            {
                var item = stack[i];
                if (!item) return true;
                if (item == camera) found++;
            }
            return found != 1;
        }
        // 새 인스턴스는 계층 크기로 감지한다. 크기가 그대로인 변경(기존 객체에 Canvas 추가, renderMode 변경)은 주기 점검이 잡는다.
        private bool CanvasScanDue(UIManager ui) => ui.transform.hierarchyCount != _boundHierarchyCount || Time.unscaledTime >= _nextCanvasScan;
        private void LateUpdate()
        {
            if (!_init || _shutdown) return;
            if (!_manager) { _init = false; return; }
            try
            {
                if (CameraBindingChanged(_manager)) _CameraSetting(_manager);
                else if (CanvasScanDue(_manager)) BindCanvases(_manager, _boundUI);
            }
            catch (Exception exception)
            { _init = false; LastInitializationError = exception; DetachCamera(); Debug.LogWarning("[UIManagerCreater] Camera reconnect failed: " + exception.Message); }
        }
        //추가 종료
        //수정 종료
    }
}
