# JJEvol Effects UI Adapter — local validation candidate

`com.jjevol.effects.ui@0.1.0-pre.4`, Unity 6000.3.9f1. Optional original
`jjevol.Effect.Renderers.ToastMessageEffectRenderer` and
`jjevol.Effect.EffectIconBehaviour`. This is not a migration of all Effect/UI
features or an external release.

Requires Effects Core, UI Addressables, uGUI/TMP 2.0.0 and UniTask 2.5.11.
UI Addressables currently brings UI Core, general Resources Addressables,
Audio Core and Input System transitively. Adapter Runtime has no direct
Audio/Economy/Runner dependency. Economy, Runner, Managed Addressables and
Audio/Effect SDK providers are not required by the minimal consumer.
SDK 4.0.1 and UniTask commit f213ff497e4ff462a77319cf677cf20cc0860ca9 were used.

The two original scripts and exact .meta/GUIDs moved from Effects
`Integrations~` to this Runtime assembly. Recover their previous bytes from
STEP13 commit deb457593c1ddf08be887b5f6adbcaa1e967c90a or the unchanged STEP12
Snapshot. Do not activate a second copy with the same GUID. No third-party
SDK source/binary or original product Prefab/art is bundled.

## Prefab and data

Place ToastMessageEffectRenderer on the Effect prefab root with an actual
Animator/Controller and configured `_playStateName`. Wire `iconSprite`,
`messageText`, `characterTexture`, `skillNameText`, `_animator` in the Inspector.
AddressableImage must have the game-owned Atlas key; `SetData(icon,message)`
selects a Sprite **name inside that Atlas**, not a new Addressables key.
`SetCharacterData(key,skill)` accepts the existing Texture2D/Sprite SDK key.
The same image component should have one Adapter owner.

EffectManager already recognizes IEffectRenderer on the prefab root; no
global factory or UI Manager API change is required. Choose the normal
Resources prefab provider or, if installed, the existing
AddressablesEffectPrefabProvider before loading. Play/PlayAsync is unchanged.
After obtaining a handle, use its Toast renderer to set message/character data.
Data can also be set before calling the renderer's Play; Play does not cancel
prepared image requests. Empty inputs clear the prior image. StopAndClear
cancels image requests, returns their UI leases and stops Animator time.

Toast preserves the existing state-name/animation behaviour: `animationIndex`
and SetSkin do not select other states/skins, SetSorting remains the original
unsupported UI operation, and content controls the actual Animator clip loop.
The renderer loop argument suppresses automatic completion. Missing Animator
or empty state uses the original immediate completion fallback; this does not
prove an animation ran. State-loop/5-second timeout fallbacks remain, with
paused time excluded. Renderer completion is separate from EffectRequest.callBack,
which Core invokes when returning a handle, including explicit Despawn.

A looping Toast under a deactivated parent stays owned by its caller and Core
restarts it on reactivation, but the renderer's own OnDisable has already
cleared its data, so call SetData/SetCharacterData again. A non-loop Toast
ends as Interrupted with the deactivation.

## Icon behaviour and lifetime

Attach EffectIconBehaviour to the Effect prefab, wire `_iconImage` and its
Atlas key. `EffectRequest.icon` remains a Sprite name. Begin retires the prior
run, clears the previous Sprite and starts the real UI Atlas load with a
per-run cancellation token. It validates owner RequestVersion, Atlas key,
requested Sprite name and returned Sprite identity/name. A foreign nonnull
Sprite cannot satisfy the load. Missing names/failure terminate IsFinished
without claiming success; the new read-only LoadSucceeded indicates the
current successful selection. No optional icon is terminal with false success.

An image that was never activated defers its load until its first activation
(`IsLoadDeferred`). This is not a failure: the Sprite name stays selected, no
warning is logged, IsFinished stays false, and the run judges the load that
starts on activation. Toast icon and character images follow the same rule.
Retiring the run or replacing the Toast data clears the deferred selection.

Core automatically calls End and disables a behaviour after IsFinished.
Therefore a successfully loaded image remains visible after that automatic
End while the Effect request is active. A small request-version observer
continues until Stop/Despawn/owner disable/destroy and then cancels/returns the
image. Pending-load End retires immediately. Use handle Stop/Despawn for
Effect shutdown, not a successful-load End alone. A pool reuse starts a fresh
run even if the MonoBehaviour component was previously recycled/disabled. A
looping request under a deactivated parent retires the image and loads it again
on reactivation.

UI components own actual SDK leases and native Sprite clones. The Adapter
uses existing SetAtlasSprite/LoadAtlasAsync/LoadSpriteAsync operations rather
than implementing another cache/loader. Canceling a playback does not mean a
pending SDK operation has already finished; eventual native Handle cleanup
must be awaited. Prefab lease/pool retention remains Effect Core's policy.

## Validation and limits

Tests live under this package Tests with isolated Editor/Runtime asmdefs.
The validation fixture setup is explicit and restricted to the new isolated
STEP14 AdapterHost. It authors independent native Controller/Prefab/Atlas/
Texture/WAV assets and imports installed uGUI TMP essentials; it never imports
product content or runs Managed Sync. Positive loading uses the actual SDK
Fast Mode catalog. Controlled delayed/failure providers only cover negative
timing and delegate asset input to actual native fixtures.

Installation is in the Framework Docs/Guide/Installation.md, validation scope in
Docs/Guide/Verification.md, and original paths and hashes in
Docs/EffectUIExtraction/TransferManifest.json.
Player/device, built bundles/Remote Catalog, original Prefab compatibility,
product art quality and other Vendor/UI adapters are not validated here.
