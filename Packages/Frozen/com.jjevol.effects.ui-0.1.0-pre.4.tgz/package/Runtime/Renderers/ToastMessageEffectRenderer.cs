using System;
using System.Collections;
//�߰�
using System.Threading;
using Cysharp.Threading.Tasks;
//�߰� ����
using TMPro;
using UnityEngine;

namespace jjevol.Effect.Renderers
{
    public sealed class ToastMessageEffectRenderer : MonoBehaviour, IEffectRenderer
    {
        [Header("UI")]
        [SerializeField] private AddressableImage iconSprite;
        [SerializeField] private TMP_Text messageText;
        [SerializeField] private AddressableTexture characterTexture;
        [SerializeField] private TMP_Text skillNameText;

        [Header("Animation")]
        [SerializeField] private Animator _animator;
        [SerializeField] private string _playStateName = "";

        private bool _useUnscaledTime;
        private Coroutine _waitCo;
        //�߰�
        private int _playVersion, _iconVersion, _characterVersion;
        private bool _isPaused;
        private CancellationTokenSource _iconCTS, _characterCTS;
        //�߰� ����

        public Transform Root => transform;

        //����
        public void SetData(string icon, string message)
        {
            int version = ++_iconVersion;
            Cancel(ref _iconCTS);
            if (messageText != null) messageText.text = message ?? string.Empty;
            if (iconSprite == null) return;
            if (!Application.isPlaying) { iconSprite.SetSprite(icon ?? string.Empty); return; }

            ClearIcon();
            if (string.IsNullOrEmpty(icon)) return;
            string key = iconSprite.atlasKey;
            // Atomic selection does not start a second unowned load for the same Atlas key.
            iconSprite.SetAtlasSprite(key, icon);
            _iconCTS = CancellationTokenSource.CreateLinkedTokenSource(this.GetCancellationTokenOnDestroy());
            LoadIconAsync(key, icon, version, _iconCTS.Token).Forget();
        }
        //���� ����

        //����
        public void SetCharacterData(string characterTextureKey, string skillName)
        {
            int version = ++_characterVersion;
            Cancel(ref _characterCTS);
            if (skillNameText != null) skillNameText.text = skillName ?? string.Empty;
            if (characterTexture == null) return;
            if (!Application.isPlaying) { characterTexture.SetSprite(characterTextureKey); return; }

            ClearCharacter();
            if (string.IsNullOrEmpty(characterTextureKey)) return;
            _characterCTS = CancellationTokenSource.CreateLinkedTokenSource(this.GetCancellationTokenOnDestroy());
            LoadCharacterAsync(characterTextureKey, version, _characterCTS.Token).Forget();
        }
        //���� ����

        public void SetSorting(string layer, int order)
        {
            // UI �佺Ʈ ����Ʈ�� ���� Sorting ó�� ����.
            // �ʿ��ϸ� ������ ���� Canvas/SortingGroup �������� Ȯ��.
        }

        public void SetPaused(bool paused)
        {
            //�߰�
            _isPaused = paused;
            //�߰� ����
            if (_animator != null)
                _animator.speed = paused ? 0f : 1f;
        }

        public void SetUnscaledTime(bool unscaled)
        {
            _useUnscaledTime = unscaled;

            if (_animator != null)
            {
                _animator.updateMode = unscaled
                    ? AnimatorUpdateMode.UnscaledTime
                    : AnimatorUpdateMode.Normal;
            }
        }

        public void SetSkin(int skinIndex)
        {
        }

        public void Play(int animationIndex, bool loop, Action onComplete)
        {
            //�߰�
            int version = ++_playVersion;
            _isPaused = false;
            //�߰� ����
            if (_waitCo != null)
            {
                StopCoroutine(_waitCo);
                _waitCo = null;
            }

            if (_animator == null)
            {
                onComplete?.Invoke();
                return;
            }

            if (string.IsNullOrEmpty(_playStateName))
            {
                Debug.LogWarning($"[{nameof(ToastMessageEffectRenderer)}] Play State Name�� ��� �ֽ��ϴ�. Animator State �̸��� �����ؾ� �մϴ�.");
                onComplete?.Invoke();
                return;
            }

            _animator.enabled = true;
            _animator.speed = 1f;

            if (!string.IsNullOrEmpty(_playStateName))
            {
                _animator.Play(_playStateName, 0, 0f);
                _animator.Update(0f);
            }

            if (!loop)
                //����
                _waitCo = StartCoroutine(Co_WaitAnimationComplete(onComplete, version));
                //���� ����
        }

        //����
        public void StopAndClear()
        {
            ++_playVersion;
            ++_iconVersion;
            ++_characterVersion;
            Cancel(ref _iconCTS);
            Cancel(ref _characterCTS);
            if (_waitCo != null)
            {
                StopCoroutine(_waitCo);
                _waitCo = null;
            }
            if (_animator != null) _animator.speed = 0f;
            if (Application.isPlaying) { ClearIcon(); ClearCharacter(); }
        }
        //���� ����

        //�߰�
        private void OnDisable() => StopAndClear();
        private void OnDestroy() => StopAndClear();
        private static void Cancel(ref CancellationTokenSource source)
        {
            var previous = source;
            source = null;
            if (previous == null) return;
            previous.Cancel();
            previous.Dispose();
        }
        private void ClearIcon()
        {
            if (!iconSprite) return;
            iconSprite.LoadAtlasAsync(string.Empty).Forget();
            iconSprite.SetAtlasSprite(iconSprite.atlasKey, string.Empty);
        }
        private void ClearCharacter()
        {
            if (!characterTexture) return;
            characterTexture.LoadSpriteAsync(string.Empty).Forget();
            characterTexture.SetSprite(string.Empty);
        }
        private async UniTaskVoid LoadIconAsync(string key, string icon, int version, CancellationToken token)
        {
            try
            {
                await iconSprite.LoadAtlasAsync(key, token);
                if (token.IsCancellationRequested || !this || version != _iconVersion) return;
                if (iconSprite.IsLoadDeferred)
                {
                    // A never-activated image loads on its first activation; judge that load, not the empty Sprite.
                    await UniTask.WaitWhile(() => iconSprite && iconSprite.IsLoadDeferred, cancellationToken: token);
                    if (token.IsCancellationRequested || !this || version != _iconVersion) return;
                    if (iconSprite) await iconSprite.LoadAtlasAsync(key, token);
                    if (token.IsCancellationRequested || !this || version != _iconVersion) return;
                }
                string expected = icon.Replace("(Clone)", string.Empty);
                if (iconSprite.atlasKey != key || iconSprite.spriteName != expected || !iconSprite.sprite ||
                    iconSprite.sprite.name.Replace("(Clone)", string.Empty) != expected)
                {
                    ClearIcon();
                    Debug.LogWarning("[ToastMessageEffectRenderer] Icon load failed for the current request.");
                }
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested || !this || version != _iconVersion) { /* Expected when this data request is retired. */ }
            catch (Exception exception)
            {
                if (!this || version != _iconVersion) return;
                ClearIcon();
                Debug.LogWarning("[ToastMessageEffectRenderer] Icon load failed: " + exception.GetType().Name);
            }
        }
        private async UniTaskVoid LoadCharacterAsync(string key, int version, CancellationToken token)
        {
            try
            {
                await characterTexture.LoadSpriteAsync(key, token);
                if (token.IsCancellationRequested || !this || version != _characterVersion) return;
                if (characterTexture.IsLoadDeferred)
                {
                    // A never-activated image loads on its first activation; judge that load, not the empty Sprite.
                    await UniTask.WaitWhile(() => characterTexture && characterTexture.IsLoadDeferred, cancellationToken: token);
                    if (token.IsCancellationRequested || !this || version != _characterVersion) return;
                    if (characterTexture) await characterTexture.LoadSpriteAsync(key, token);
                    if (token.IsCancellationRequested || !this || version != _characterVersion) return;
                }
                if (characterTexture.spriteKey != key || !characterTexture.sprite)
                    Debug.LogWarning("[ToastMessageEffectRenderer] Character load failed for the current request.");
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested || !this || version != _characterVersion) { /* Expected when this data request is retired. */ }
            catch (Exception exception)
            {
                if (!this || version != _characterVersion) return;
                ClearCharacter();
                Debug.LogWarning("[ToastMessageEffectRenderer] Character load failed: " + exception.GetType().Name);
            }
        }
        //�߰� ����

        //����
        private IEnumerator Co_WaitAnimationComplete(Action onComplete, int version)
        {
            if (_animator == null)
            {
                onComplete?.Invoke();
                yield break;
            }

            const int layer = 0;

            yield return null;

            float elapsed = 0f;
            float timeout = 5f;

            while (_animator != null && version == _playVersion)
            {
                if (_isPaused) { yield return null; continue; }
                var state = _animator.GetCurrentAnimatorStateInfo(layer);

                if (state.IsName(_playStateName) && !_animator.IsInTransition(layer))
                {
                    if (state.loop)
                    {
                        Debug.LogWarning($"[{nameof(ToastMessageEffectRenderer)}] {_playStateName} Animator State�� Loop�Դϴ�. ����� State�� �����ؾ� �ڵ� ȸ���˴ϴ�.");
                        break;
                    }

                    if (state.normalizedTime >= 1f)
                        break;
                }

                elapsed += _useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
                if (elapsed >= timeout)
                {
                    Debug.LogWarning($"[{nameof(ToastMessageEffectRenderer)}] Animator �Ϸ� ��� Ÿ�Ӿƿ�. state={state.fullPathHash}, playStateName={_playStateName}");
                    break;
                }

                yield return null;
            }

            if (version != _playVersion) yield break;
            _waitCo = null;
            onComplete?.Invoke();
        }
        //���� ����

        private static string FormatMultiplierValue(decimal value)
        {
            if (value == decimal.Truncate(value))
                return ((int)value).ToString();

            return value.ToString("0.##");
        }
    }
}