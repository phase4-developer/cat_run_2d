﻿using Cysharp.Threading.Tasks;
//추가
using System;
using System.Threading;
//추가 종료
using UnityEngine;
namespace jjevol.Effect
{
    public class EffectIconBehaviour : MonoBehaviour, IEffectBehaviour
    {
        public bool IsFinished { get; private set; }
        [SerializeField] private AddressableImage _iconImage;
        //추가
        public bool LoadSucceeded { get; private set; }
        private int _runVersion, _handleVersion;
        private EffectHandle _handle;
        private CancellationTokenSource _runCTS;
        //추가 종료

        //수정
        public void Begin(EffectHandle handle)
        {
            Retire();
            IsFinished = false;
            LoadSucceeded = false;
            _handle = handle;
            if (!handle) { IsFinished = true; return; }
            _handleVersion = handle.RequestVersion;
            _runCTS = CancellationTokenSource.CreateLinkedTokenSource(this.GetCancellationTokenOnDestroy());
            ObserveOwnerAsync(_runVersion, _runCTS.Token).Forget();
            BeginAsync(handle).Forget();
        }
        //수정 종료

        //수정
        private async UniTaskVoid BeginAsync(EffectHandle handle)
        {
            int version = _runVersion;
            var token = _runCTS.Token;
            var req = handle.Request;
            try
            {
                if (!string.IsNullOrEmpty(req.icon) && _iconImage != null)
                {
                    string key = _iconImage.atlasKey;
                    _iconImage.SetAtlasSprite(key, req.icon);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
                    Debug.Log($"[EffectIconBehaviour] icon:{req.icon}, object:{name}");
#endif
                    await _iconImage.LoadAtlasAsync(key, token);
                    if (!Current(version)) return;
                    if (_iconImage.IsLoadDeferred)
                    {
                        // 활성화된 적 없는 Image는 첫 활성화 때 로드한다. 실패가 아니므로 그 로드의 결과로 판정한다.
                        await UniTask.WaitWhile(() => _iconImage && _iconImage.IsLoadDeferred, cancellationToken: token);
                        if (!Current(version)) return;
                        if (_iconImage) await _iconImage.LoadAtlasAsync(key, token);
                        if (!Current(version)) return;
                    }
                    string expected = req.icon.Replace("(Clone)", string.Empty);
                    LoadSucceeded = _iconImage.atlasKey == key && _iconImage.spriteName == expected &&
                        _iconImage.sprite && _iconImage.sprite.name.Replace("(Clone)", string.Empty) == expected;
                    if (!LoadSucceeded)
                    {
                        ClearImage();
                        Debug.LogWarning("[EffectIconBehaviour] Icon load failed for the current request.");
                    }
                }
                if (Current(version)) IsFinished = true;
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested || !Current(version)) { /* Retirement owns cancellation and image return. */ }
            catch (Exception exception)
            {
                if (!Current(version)) return;
                ClearImage();
                LoadSucceeded = false;
                IsFinished = true;
                Debug.LogWarning("[EffectIconBehaviour] Icon load failed: " + exception.GetType().Name);
            }
        }
        //수정 종료

        //수정
        public void Tick(float dt) { if (!OwnerCurrent()) Retire(); }
        public void End()
        {
            // Effect Core also calls End when a finished loading behaviour is recycled.
            // Keep its displayed image while that Effect request is still active.
            if (!IsFinished || !OwnerCurrent()) Retire();
        }
        //수정 종료

        //추가
        private bool OwnerCurrent() => this && _handle && _handle.RequestVersion == _handleVersion && _handle.gameObject.activeInHierarchy;
        private bool Current(int version) => version == _runVersion && OwnerCurrent();
        private async UniTaskVoid ObserveOwnerAsync(int version, CancellationToken token)
        {
            bool canceled = await UniTask.WaitUntil(() => !OwnerCurrent(), cancellationToken: token).SuppressCancellationThrow();
            if (!canceled && version == _runVersion) Retire();
        }
        private void ClearImage()
        {
            if (!_iconImage) return;
            _iconImage.LoadAtlasAsync(string.Empty).Forget();
            _iconImage.SetAtlasSprite(_iconImage.atlasKey, string.Empty);
        }
        private void Retire()
        {
            ++_runVersion;
            var source = _runCTS;
            _runCTS = null;
            _handle = null;
            if (source != null) { source.Cancel(); source.Dispose(); }
            if (Application.isPlaying) ClearImage();
            IsFinished = true;
            LoadSucceeded = false;
        }
        private void OnDisable() { if (!gameObject.activeInHierarchy) Retire(); }
        private void OnDestroy() => Retire();
        //추가 종료
    }
}
