using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.U2D;
using PackageInfo=UnityEditor.PackageManager.PackageInfo;

namespace jjevol.Effect.UI.Tests
{
    public sealed class AdapterCompatibilityTests
    {
        [OneTimeSetUp]public void Setup()=>AdapterFixtureSetup.Prepare();
        [Test]public void OriginalScriptGuidsPublicMethodsAndSerializedSlotsArePreserved()
        {
            Assert.That(AssetDatabase.GUIDToAssetPath("bf65d2bc2816d314caefdfade49e5de4"),Is.EqualTo("Packages/com.jjevol.effects.ui/Runtime/Renderers/ToastMessageEffectRenderer.cs"));
            Assert.That(AssetDatabase.GUIDToAssetPath("503f93d9803c73a41add43a97f0d331d"),Is.EqualTo("Packages/com.jjevol.effects.ui/Runtime/Behaviours/EffectIconBehaviour.cs"));
            foreach(var (name,type) in new[]{("iconSprite",typeof(AddressableImage)),("messageText",typeof(TMP_Text)),("characterTexture",typeof(AddressableTexture)),("skillNameText",typeof(TMP_Text)),("_animator",typeof(Animator)),("_playStateName",typeof(string))})
            {var field=typeof(ToastMessageEffectRenderer).GetField(name,BindingFlags.NonPublic|BindingFlags.Instance);Assert.That(field.FieldType,Is.EqualTo(type));Assert.That(field.IsDefined(typeof(SerializeField)),Is.True);}
            Assert.That(typeof(ToastMessageEffectRenderer).GetMethod("SetData",new[]{typeof(string),typeof(string)}),Is.Not.Null);
            Assert.That(typeof(ToastMessageEffectRenderer).GetMethod("SetCharacterData",new[]{typeof(string),typeof(string)}),Is.Not.Null);
            Assert.That(typeof(IEffectRenderer).IsAssignableFrom(typeof(ToastMessageEffectRenderer)),Is.True);
            Assert.That(typeof(IEffectBehaviour).IsAssignableFrom(typeof(EffectIconBehaviour)),Is.True);
            Assert.That(typeof(EffectIconBehaviour).GetField("_iconImage",BindingFlags.NonPublic|BindingFlags.Instance).FieldType,Is.EqualTo(typeof(AddressableImage)));
            Assert.That(typeof(ToastMessageEffectRenderer).Assembly.GetName().Name,Is.EqualTo("JJEvol.Effects.UI.Runtime"));
        }
        [Test]public void NativePrefabReferencesAnimatorAndAtlasReloadWithoutMissingScripts()
        {
            var toast=AssetDatabase.LoadAssetAtPath<GameObject>(AdapterFixtureSetup.Root+"/Toast.prefab");var renderer=toast.GetComponent<ToastMessageEffectRenderer>();var so=new SerializedObject(renderer);
            foreach(var name in new[]{"iconSprite","messageText","characterTexture","skillNameText","_animator"})Assert.That(so.FindProperty(name).objectReferenceValue,Is.Not.Null,name);
            Assert.That(so.FindProperty("_playStateName").stringValue,Is.EqualTo("Play"));
            Assert.That(toast.GetComponent<Animator>().runtimeAnimatorController.animationClips.Length,Is.GreaterThan(0));
            Assert.That(AssetDatabase.LoadAssetAtPath<SpriteAtlas>(AdapterFixtureSetup.Root+"/Icons.spriteatlasv2").spriteCount,Is.EqualTo(2));
            var icon=AssetDatabase.LoadAssetAtPath<GameObject>(AdapterFixtureSetup.Root+"/Icon.prefab");Assert.That(icon.GetComponent<EffectIconBehaviour>(),Is.Not.Null);
        }
        [Test]public void AdapterDoesNotAddDirectAudioEconomyRunnerOrVendorDependencies()
        {
            var package=PackageInfo.FindForAssembly(typeof(ToastMessageEffectRenderer).Assembly);string json=File.ReadAllText(Path.Combine(package.resolvedPath,"package.json"));
            foreach(string dependency in new[]{"com.jjevol.audio","com.jjevol.economy","com.jjevol.genre.runner","spine","dotween","coffee"})Assert.That(json,Does.Not.Contain('"'+dependency+'"'));
            var direct=typeof(ToastMessageEffectRenderer).Assembly.GetReferencedAssemblies().Select(a=>a.Name).ToArray();
            Assert.That(direct,Does.Not.Contain("JJEvol.Audio.Runtime"));Assert.That(direct,Does.Not.Contain("JJEvol.Economy.Runtime"));
            var core=PackageInfo.FindForAssembly(typeof(EffectHandle).Assembly);Assert.That(File.ReadAllText(Path.Combine(core.resolvedPath,"package.json")),Does.Not.Contain("com.jjevol.effects.ui"));
        }
        [Test]public void ImportedFrameworkGuidsAndAssemblyNamesHaveNoDuplicates()
        {
            var guids=new HashSet<string>();var assemblies=new HashSet<string>();
            foreach(var package in PackageInfo.GetAllRegisteredPackages().Where(p=>p.name.StartsWith("com.jjevol.")||p.name=="com.artress.managed-addressables"))
            foreach(string path in Directory.EnumerateFiles(package.resolvedPath,"*",SearchOption.AllDirectories))
            {
                if(path.Substring(package.resolvedPath.Length).Replace('\\','/').Split('/').Any(p=>p.EndsWith("~")))continue;
                if(path.EndsWith(".meta"))
                {var guid=File.ReadLines(path).FirstOrDefault(l=>l.StartsWith("guid: "));if(guid!=null)Assert.That(guids.Add(guid),Is.True,path);}
                if(path.EndsWith(".asmdef")){var name=JsonUtility.FromJson<Definition>(File.ReadAllText(path)).name;Assert.That(assemblies.Add(name),Is.True,name);}
            }
            Assert.That(guids.Count,Is.GreaterThan(300));Assert.That(assemblies.Count,Is.GreaterThan(30));
        }
        [Serializable]sealed class Definition{public string name;}
    }
}
