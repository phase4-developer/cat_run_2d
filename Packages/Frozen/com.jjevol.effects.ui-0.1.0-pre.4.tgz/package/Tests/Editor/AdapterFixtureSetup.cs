using System;
using System.IO;
using System.Text;
using jjevol.Effect.Renderers;
using TMPro;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.U2D;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.TestTools;
using UnityEngine.U2D;
using Object=UnityEngine.Object;

namespace jjevol.Effect.UI.Tests
{
    public sealed class AdapterFixtureSetup:IPrebuildSetup
    {
        public const string Root="Assets/Step14EffectUIFixtures";
        static void Guard()
        {
            string project=Path.GetFullPath(Path.Combine(Application.dataPath,"..")).Replace('\\','/');
            if(!project.EndsWith("/.local/effects-ui-validation/AdapterHost",StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Explicit test authoring is limited to the new STEP14 AdapterHost");
        }
        public static void ImportTMP()
        {
            Guard();if(Shader.Find("TextMeshPro/Mobile/Distance Field")!=null){EditorApplication.Exit(0);return;}
            var package=UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TMP_Text).Assembly);
            AssetDatabase.ImportPackage(Path.Combine(package.resolvedPath,"Package Resources","TMP Essential Resources.unitypackage"),false);
            double end=EditorApplication.timeSinceStartup+120;
            EditorApplication.CallbackFunction finish=null;
            finish=()=>
            {
                if(Shader.Find("TextMeshPro/Mobile/Distance Field")!=null&&!EditorApplication.isUpdating&&!EditorApplication.isCompiling)
                {EditorApplication.update-=finish;EditorApplication.Exit(0);}
                else if(EditorApplication.timeSinceStartup>end){EditorApplication.update-=finish;Debug.LogError("STEP14 TMP import timeout");EditorApplication.Exit(1);}
            };
            EditorApplication.update+=finish;
        }
        public static void Prepare()=>new AdapterFixtureSetup().Setup();
        static void Field(Object target,string name,Object value)
        {var so=new SerializedObject(target);so.FindProperty(name).objectReferenceValue=value;so.ApplyModifiedPropertiesWithoutUndo();}
        static void ImageSettings(Object target,string key=null)
        {
            var so=new SerializedObject(target);so.FindProperty("m_LoadOnEnable").boolValue=false;
            if(so.FindProperty("m_ShowLoading")!=null)so.FindProperty("m_ShowLoading").boolValue=false;
            if(so.FindProperty("m_FadeColorDuration")!=null)so.FindProperty("m_FadeColorDuration").floatValue=0;
            if(key!=null)so.FindProperty("m_AtlasKey").stringValue=key;
            so.ApplyModifiedPropertiesWithoutUndo();
        }
        public void Setup()
        {
            Guard();
            if(!Shader.Find("TextMeshPro/Mobile/Distance Field"))throw new InvalidOperationException("Import installed TMP resources before tests");
            if(AssetDatabase.IsValidFolder(Root))
            {
                var current=AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(Root+"/Settings.asset");
                if(!current)throw new InvalidOperationException("Incomplete fixture is protected; do not overwrite");
                AddressableAssetSettingsDefaultObject.Settings=current;
                SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(current)));return;
            }
            AssetDatabase.CreateFolder("Assets",Path.GetFileName(Root));
            var settings=AddressableAssetSettings.Create(Root,"Settings",true,true);AddressableAssetSettingsDefaultObject.Settings=settings;
            for(int i=0;i<settings.DataBuilders.Count;i++)if(settings.DataBuilders[i] is BuildScriptFastMode)settings.ActivePlayModeDataBuilderIndex=i;
            void Register(string path,string key)=>settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path),settings.DefaultGroup).address=key;
            var packables=new Object[2];
            foreach(var (name,color,index) in new[]{("icon_red",Color.red,0),("icon_blue",Color.blue,1)})
            {
                var texture=new Texture2D(16,16);var pixels=new Color[256];Array.Fill(pixels,color);texture.SetPixels(pixels);texture.Apply();
                string path=Root+"/"+name+".png";File.WriteAllBytes(path,texture.EncodeToPNG());Object.DestroyImmediate(texture);AssetDatabase.ImportAsset(path);
                var importer=(TextureImporter)AssetImporter.GetAtPath(path);importer.textureType=TextureImporterType.Sprite;importer.spriteImportMode=SpriteImportMode.Single;
                importer.isReadable=true;importer.textureCompression=TextureImporterCompression.Uncompressed;
                importer.SetPlatformTextureSettings(new TextureImporterPlatformSettings{name="Standalone",overridden=true,format=TextureImporterFormat.RGBA32,maxTextureSize=256,textureCompression=TextureImporterCompression.Uncompressed});
                importer.SaveAndReimport();packables[index]=AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            }
            EditorSettings.spritePackerMode=SpritePackerMode.SpriteAtlasV2;
            var atlasSource=new SpriteAtlasAsset();atlasSource.Add(packables);string atlasPath=Root+"/Icons.spriteatlasv2";
            SpriteAtlasAsset.Save(atlasSource,atlasPath);AssetDatabase.ImportAsset(atlasPath);
            var atlasImporter=(SpriteAtlasImporter)AssetImporter.GetAtPath(atlasPath);var textureSettings=atlasImporter.textureSettings;textureSettings.readable=true;textureSettings.generateMipMaps=false;atlasImporter.textureSettings=textureSettings;
            atlasImporter.SetPlatformSettings(new TextureImporterPlatformSettings{name="Standalone",overridden=true,format=TextureImporterFormat.RGBA32,maxTextureSize=256,textureCompression=TextureImporterCompression.Uncompressed});atlasImporter.SaveAndReimport();
            if(AssetDatabase.LoadAssetAtPath<SpriteAtlas>(atlasPath).spriteCount!=2)throw new InvalidOperationException("Real Atlas must have both sprites");Register(atlasPath,"Step14/Atlas");
            foreach(var (name,color) in new[]{("TextureA",Color.red),("TextureB",Color.blue)})
            {
                var texture=new Texture2D(16,16);var pixels=new Color[256];Array.Fill(pixels,color);texture.SetPixels(pixels);texture.Apply();
                string path=Root+"/"+name+".asset";AssetDatabase.CreateAsset(texture,path);Register(path,"Step14/"+name);
            }
            var direct=Sprite.Create(AssetDatabase.LoadAssetAtPath<Texture2D>(Root+"/TextureB.asset"),new Rect(0,0,16,16),new Vector2(.5f,.5f));direct.name="external_blue";
            AssetDatabase.CreateAsset(direct,Root+"/DirectSprite.asset");Register(Root+"/DirectSprite.asset","Step14/DirectSprite");
            var clip=new AnimationClip{name="IndependentToastMotion"};clip.SetCurve("",typeof(Transform),"localPosition.x",AnimationCurve.Linear(0,0,.8f,1));
            AssetDatabase.CreateAsset(clip,Root+"/Toast.anim");var controller=AnimatorController.CreateAnimatorControllerAtPath(Root+"/Toast.controller");
            var state=controller.layers[0].stateMachine.AddState("Play");state.motion=clip;controller.layers[0].stateMachine.defaultState=state;
            GameObject Rect(string name,Transform parent=null){var go=new GameObject(name,typeof(RectTransform));if(parent)go.transform.SetParent(parent,false);return go;}
            foreach(string kind in new[]{"Toast","Icon","DelayedIcon"})
            {
                var root=Rect(kind);root.SetActive(false);var animator=root.AddComponent<Animator>();animator.runtimeAnimatorController=controller;animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
                var icon=Rect("icon",root.transform).AddComponent<AddressableImage>();ImageSettings(icon,kind=="DelayedIcon"?"Step14/DelayedAtlas":"Step14/Atlas");
                if(kind=="Toast")
                {
                    var renderer=root.AddComponent<ToastMessageEffectRenderer>();Field(renderer,"iconSprite",icon);Field(renderer,"_animator",animator);
                    var character=Rect("character",root.transform).AddComponent<AddressableTexture>();ImageSettings(character);Field(renderer,"characterTexture",character);
                    Field(renderer,"messageText",Rect("message",root.transform).AddComponent<TextMeshProUGUI>());Field(renderer,"skillNameText",Rect("skill",root.transform).AddComponent<TextMeshProUGUI>());
                    var so=new SerializedObject(renderer);so.FindProperty("_playStateName").stringValue="Play";so.ApplyModifiedPropertiesWithoutUndo();
                }
                else
                {
                    var renderer=root.AddComponent<AnimatorEffectRenderer>();Field(renderer,"animator",animator);
                    var behaviour=root.AddComponent<EffectIconBehaviour>();Field(behaviour,"_iconImage",icon);
                }
                root.SetActive(true);string path=Root+"/"+kind+".prefab";PrefabUtility.SaveAsPrefabAsset(root,path);Object.DestroyImmediate(root);Register(path,"Step14/"+kind);
            }
            string audio=Root+"/Sound.wav";using(var writer=new BinaryWriter(File.Create(audio)))
            {
                int count=4410;writer.Write(Encoding.ASCII.GetBytes("RIFF"));writer.Write(36+count*2);writer.Write(Encoding.ASCII.GetBytes("WAVEfmt "));writer.Write(16);writer.Write((short)1);writer.Write((short)1);writer.Write(44100);writer.Write(88200);writer.Write((short)2);writer.Write((short)16);writer.Write(Encoding.ASCII.GetBytes("data"));writer.Write(count*2);for(int i=0;i<count;i++)writer.Write((short)(Math.Sin(i*2*Math.PI*330/44100)*2000));
            }
            AssetDatabase.ImportAsset(audio);Register(audio,"Step14/Audio");
            EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();AssetDatabase.Refresh();
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
        }
    }
}
