# Changelog

## 0.1.0-pre.4 - 2026-11-11

- Depends on UI Addressables 0.1.0-pre.6, which brings `com.jjevol.ui.contracts`. No source change.

## 0.1.0-pre.3 - 2026-11-07

- Depends on UI Addressables 0.1.0-pre.4.

## 0.1.0-pre.2 - 2026-11-06

- Icon and character loads no longer fail on never activated images. Deferred loads wait for activation.

Unity tests for this candidate are NOT_RUN.
