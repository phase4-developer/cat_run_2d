using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("JJEvol.Tables.Authoring.Tests.Editor")]

namespace jjevol
{
    /// <summary>How a table maintenance command ended. The value is the process exit code of the -executeMethod entries.</summary>
    public enum TableMaintenanceOutcome
    {
        Completed = 0,
        /// <summary>The request was refused or failed. Nothing changed, or the output transaction was restored.</summary>
        Failed = 1,
        /// <summary>Accepting files whose content changed needs <see cref="TableMaintenanceBatch.AcceptEditedArgument"/>. Nothing changed.</summary>
        NotConfirmed = 2,
        /// <summary>An interrupted build needs <see cref="TableBuilder.Recover"/> (Table Builder 「복구·진단」) first.</summary>
        RecoveryRequired = 3,
        /// <summary>The outputs and record entries were deleted, but a source file was not. Running the same delete again removes what is left.</summary>
        SourcesLeft = 4,
    }

    public sealed class TableMaintenanceResult
    {
        public TableMaintenanceOutcome Outcome { get; }
        public int ExitCode => (int)Outcome;
        public bool Succeeded => Outcome == TableMaintenanceOutcome.Completed;
        /// <summary>Project-relative (or absolute, outside the project) paths this command deleted.</summary>
        public IReadOnlyList<string> DeletedFiles { get; }
        /// <summary>Tables whose entry left the build record.</summary>
        public IReadOnlyList<string> RemovedRecords { get; }
        public string Message { get; }
        internal TableMaintenanceResult(TableMaintenanceOutcome outcome, string message, IEnumerable<string> deleted = null, IEnumerable<string> records = null)
        {
            Outcome = outcome; Message = message ?? "";
            DeletedFiles = Array.AsReadOnly((deleted ?? Array.Empty<string>()).ToArray());
            RemovedRecords = Array.AsReadOnly((records ?? Array.Empty<string>()).ToArray());
        }
        public override string ToString()
        {
            var lines = new List<string> { Outcome + " (exit " + ExitCode + ")" + (Message.Length == 0 ? "" : ": " + Message) };
            if (RemovedRecords.Count != 0) lines.Add("  removed from the build record: " + string.Join(", ", RemovedRecords));
            lines.AddRange(DeletedFiles.Select(f => "  deleted " + f));
            return string.Join("\n", lines);
        }
    }

    /// <summary>What deleting tables will do, before anything is deleted.</summary>
    public sealed class TableDeletePlan
    {
        public IReadOnlyList<string> Tables { get; }
        /// <summary>Source TSV files and their .meta in the input folder.</summary>
        public IReadOnlyList<string> SourceFiles { get; }
        /// <summary>Existing Resources outputs and their .meta. Recorded outputs that are already missing are not listed.</summary>
        public IReadOnlyList<string> OutputFiles { get; }
        /// <summary>Tables whose entry leaves the build record (<c>ProjectSettings/JJEvolTableAuthoring/&lt;hash&gt;.json</c>).</summary>
        public IReadOnlyList<string> Records { get; }
        public IReadOnlyList<TableDiagnostic> Diagnostics { get; }
        public bool IsValid => !RecoveryRequired && Diagnostics.All(d => d.Severity != TableDiagnosticSeverity.Error);
        /// <summary>An interrupted or unfinished build must be recovered first.</summary>
        public bool RecoveryRequired => _recovery || Diagnostics.Any(d => d.Code == "RecoveryRequired");
        private readonly bool _recovery;
        internal readonly TableBuildPlan OutputPlan;
        internal readonly Dictionary<string, string> SourceHashes;
        internal bool Applied { get; set; }
        internal TableDeletePlan(IReadOnlyList<string> tables, List<string> sources, Dictionary<string, string> hashes, List<string> outputs, List<string> records,
            List<TableDiagnostic> diagnostics, TableBuildPlan outputPlan, bool recovery)
        {
            Tables = tables; SourceFiles = sources.AsReadOnly(); SourceHashes = hashes; OutputFiles = outputs.AsReadOnly(); Records = records.AsReadOnly();
            Diagnostics = diagnostics.Concat(outputPlan?.Diagnostics.Where(d => d.Severity == TableDiagnosticSeverity.Error) ?? Array.Empty<TableDiagnostic>()).ToList().AsReadOnly();
            OutputPlan = outputPlan; _recovery = recovery;
        }
        public override string ToString()
        {
            var lines = new List<string> { "tables: " + string.Join(", ", Tables) };
            lines.AddRange(SourceFiles.Select(f => "  source " + f));
            lines.AddRange(OutputFiles.Select(f => "  output " + f));
            if (Records.Count != 0) lines.Add("  build record entries: " + string.Join(", ", Records));
            lines.AddRange(Diagnostics.Select(d => "  " + d));
            return string.Join("\n", lines);
        }
    }

    /// <summary>
    /// Deletes whole tables on an explicit request: the source TSV (and its .meta) in the input folder, the Resources output and its .meta,
    /// and the table's entry in the build record. A normal build never does this; it only warns about a table whose TSV is gone (<c>OrphanedOutput</c>).
    /// The output part runs through the same Remove transaction as Table Builder 「선택 관리 출력 삭제」: an output that differs from its record
    /// is refused, an output that is already missing only leaves the record. Generated code is not per table; the ConsumeTypes definition
    /// is refused here and retired through ID migration.
    /// </summary>
    public static class TableDeletion
    {
        internal const string OrphanHint = "표를 지운 것이면 「표 삭제」(Table Builder 관리·복구 → 출력 등록·정리, 또는 -executeMethod jjevol.TableMaintenanceBatch.DeleteTablesAndExit -jjevolTables <이름>)로 원본·산출물·기록을 함께 정리하세요.";
        private const string ConsumeTypesTable = "ConsumeTypes";

        public static TableDeletePlan Plan(string inputDirectory, string outputDirectory, IEnumerable<string> tables, Action<IReadOnlyList<TableBuildInput>> validate = null)
        {
            var names = (tables ?? throw new ArgumentNullException(nameof(tables))).Select(t => t?.Trim() ?? "").Where(t => t.Length != 0)
                .Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            if (names.Length == 0) throw new ArgumentException("Name at least one table to delete.", nameof(tables));
            foreach (string name in names) TablePaths.Name(name);
            string output = TablePaths.Output(outputDirectory), manifestPath = TablePaths.Manifest(output);
            string input = string.IsNullOrWhiteSpace(inputDirectory) ? null : Path.GetFullPath(inputDirectory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            var diagnostics = new List<TableDiagnostic>();
            if (input != null) { TablePaths.NoReparse(input); TablePaths.Disjoint(input, output); }
            // Without the source folder the TSV would survive and the next folder build would make the table again.
            if (input == null || !Directory.Exists(input))
                diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "InputMissing", "", input ?? "", "원본 폴더가 없습니다. 원본 TSV를 찾을 폴더를 지정하세요(-jjevolTableInput 또는 Table Builder 프로젝트 설정)."));
            if (File.Exists(manifestPath + ".pending"))
                return new TableDeletePlan(names, new List<string>(),new Dictionary<string, string>(), new List<string>(), new List<string>(),
                    new List<TableDiagnostic> { new TableDiagnostic(TableDiagnosticSeverity.Error, "RecoveryRequired", "", TablePaths.Relative(manifestPath), "적용이 끝나지 않은 빌드가 있습니다. 먼저 복구하세요.") }, null, true);
            var basis = TableManifest.Read(manifestPath, output);
            // An unfinished record is recovered first. Nothing is deleted meanwhile, not even a source with no record.
            if (basis.status != "Ready")
                return new TableDeletePlan(names, new List<string>(), new Dictionary<string, string>(), new List<string>(), new List<string>(),
                    new List<TableDiagnostic> { new TableDiagnostic(TableDiagnosticSeverity.Error, "RecoveryRequired", "", TablePaths.Relative(manifestPath), "빌드 기록 상태가 " + basis.status + "입니다. 먼저 복구하세요.") }, null, true);
            var sources = new List<string>(); var hashes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var outputs = new List<string>(); var records = new List<string>();
            string[] sourceFiles = input != null && Directory.Exists(input)
                ? Directory.GetFiles(input).Where(p => new[] { ".tsv", ".txt" }.Contains(Path.GetExtension(p), StringComparer.OrdinalIgnoreCase)).OrderBy(p => p, StringComparer.Ordinal).ToArray()
                : Array.Empty<string>();
            foreach (string name in names)
            {
                void Error(string code, string reason) => diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, code, name, "table delete", reason));
                if (basis.consume != null && string.Equals(name, ConsumeTypesTable, StringComparison.OrdinalIgnoreCase))
                { Error("ConsumeDefinition", "ConsumeTypes는 생성 코드의 정의라 표 삭제로 지우지 않습니다. 관리·복구 → ID 이행의 retire를 쓰세요."); continue; }
                var record = basis.tables.SingleOrDefault(t => string.Equals(t.name, name, StringComparison.OrdinalIgnoreCase));
                string[] matched = sourceFiles.Where(p => string.Equals(Path.GetFileNameWithoutExtension(p), name, StringComparison.OrdinalIgnoreCase)).ToArray();
                string path = record != null ? TablePaths.RecordPath(output, record) : Path.Combine(output, name + ".txt");
                if (record == null && (File.Exists(path) || File.Exists(path + ".meta")))
                { Error("UnmanagedOutput", TablePaths.Relative(path) + "는 빌드 기록에 없는 파일이라 지우지 않습니다. 기록에 없는 파일은 직접 확인한 뒤 지우세요."); continue; }
                if (record == null && matched.Length == 0)
                { Error("UnknownTable", "원본 폴더에도 빌드 기록에도 없는 표입니다."); continue; }
                foreach (string file in matched.SelectMany(p => new[] { p, p + ".meta" }).Where(File.Exists))
                { TablePaths.NoReparse(file); sources.Add(file); hashes[file] = TablePaths.HashFile(file); }
                if (record == null) continue;
                records.Add(record.name);
                outputs.AddRange(new[] { path, path + ".meta" }.Where(File.Exists));
            }
            TableBuildPlan outputPlan = null;
            if (records.Count != 0 && diagnostics.Count == 0)
                outputPlan = TableBuilder.Plan(new TableBuildRequest(Array.Empty<TableInput>(), output, TableAuthoringOptions.UseEncryption, TableBuildOperation.Remove, records, validate: validate));
            return new TableDeletePlan(names, sources, hashes, outputs, records, diagnostics, outputPlan, false);
        }

        /// <summary>Removes the outputs and records through the Remove transaction, then deletes the source files. A plan is applied once.</summary>
        public static TableMaintenanceResult Apply(TableDeletePlan plan)
        {
            if (plan == null) throw new ArgumentNullException(nameof(plan));
            if (plan.Applied) throw new InvalidOperationException("This delete plan was already applied.");
            if (plan.RecoveryRequired) return new TableMaintenanceResult(TableMaintenanceOutcome.RecoveryRequired, Describe(plan));
            if (!plan.IsValid) return new TableMaintenanceResult(TableMaintenanceOutcome.Failed, "삭제를 거절했습니다. 아무것도 바꾸지 않았습니다. " + Describe(plan));
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) throw new InvalidOperationException("Deleting tables requires an idle Editor outside PlayMode/compilation.");
            foreach (var pair in plan.SourceHashes)
                if (TablePaths.HashFile(pair.Key) != pair.Value) return new TableMaintenanceResult(TableMaintenanceOutcome.Failed, Shown(pair.Key) + "이(가) 확인 뒤 바뀌었습니다. 다시 확인하세요. 아무것도 바꾸지 않았습니다.");
            plan.Applied = true;
            var deleted = new List<string>();
            if (plan.OutputPlan != null)
            {
                try { TableBuilder.Prepare(plan.OutputPlan).Apply(); }
                catch (TableBuildRecoveryException e) { return new TableMaintenanceResult(TableMaintenanceOutcome.RecoveryRequired, "산출물 삭제를 복구하지 못했습니다. Table Builder 관리·복구에서 확인하세요. (" + e.Message + ")"); }
                catch (Exception e) { return new TableMaintenanceResult(TableMaintenanceOutcome.Failed, "산출물 삭제가 거절되거나 실패해 이전 상태로 되돌렸습니다. 원본은 지우지 않았습니다. (" + e.GetType().Name + ": " + e.Message + ")"); }
                deleted.AddRange(plan.OutputFiles.Select(Shown));
            }
            try
            {
                foreach (string file in plan.SourceFiles)
                {
                    TablePaths.NoReparse(file);
                    if (TablePaths.HashFile(file) != plan.SourceHashes[file]) throw new IOException(Shown(file) + " changed while the outputs were removed.");
                    File.Delete(file);
                    if (File.Exists(file)) throw new IOException(Shown(file) + " could not be deleted.");
                    deleted.Add(Shown(file));
                }
            }
            catch (Exception e)
            {
                AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
                return new TableMaintenanceResult(TableMaintenanceOutcome.SourcesLeft, "산출물과 기록은 지웠지만 원본 일부를 지우지 못했습니다. 같은 명령을 다시 실행하면 남은 원본만 지웁니다. (" + e.Message + ")", deleted, plan.Records);
            }
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            return new TableMaintenanceResult(TableMaintenanceOutcome.Completed, "", deleted, plan.Records);
        }

        public static TableMaintenanceResult Delete(string inputDirectory, string outputDirectory, IEnumerable<string> tables, Action<IReadOnlyList<TableBuildInput>> validate = null)
            => Apply(Plan(inputDirectory, outputDirectory, tables, validate));

        private static string Describe(TableDeletePlan plan) => string.Join("; ", plan.Diagnostics.Where(d => d.Severity == TableDiagnosticSeverity.Error).Select(d => d.Code + " " + d.TableName + ": " + d.Reason));
        internal static string Shown(string path)
        {
            string full = Path.GetFullPath(path);
            return full.StartsWith(TablePaths.Project + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ? TablePaths.Relative(full) : full;
        }
    }

    /// <summary>
    /// Unattended entries for the Table Builder maintenance actions that otherwise exist only as window buttons.
    /// Folders default to the Table Builder project settings (<c>ProjectSettings/JJEvolTableAuthoringSettings.json</c>),
    /// then <see cref="CommonDataToolSettings.Current"/>. In batch mode the Editor exits with <see cref="TableMaintenanceOutcome"/>.
    /// </summary>
    public static class TableMaintenanceBatch
    {
        public const string TablesArgument = "-jjevolTables";
        public const string InputArgument = "-jjevolTableInput";
        public const string OutputArgument = "-jjevolTableOutput";
        public const string AcceptEditedArgument = "-jjevolTableAcceptEdited";
        private const string LogPrefix = "[JJEvol Table Maintenance] ";

        internal sealed class Options
        {
            public List<string> Tables = new List<string>();
            public string Input, Output;
            public bool AcceptEdited;
        }

        /// <summary>
        /// -executeMethod jjevol.TableMaintenanceBatch.DeleteTablesAndExit -jjevolTables "09_uiResource[,other]"
        ///   [-jjevolTableInput Assets/.../TSV] [-jjevolTableOutput Assets/.../Resources]
        /// Deletes each table's source TSV, Resources output and build record entry (<see cref="TableDeletion"/>).
        /// </summary>
        public static void DeleteTablesAndExit()
        {
            TableMaintenanceResult result;
            try
            {
                var options = ParseCommandLine(Environment.GetCommandLineArgs());
                if (options.Tables.Count == 0) throw new ArgumentException(TablesArgument + " \"name[,name]\" is required.");
                // As TableBuilder.Build does: the saved encryption setting registers the decoder that reads the remaining tables.
                TableEncryptionSetup.Apply(TableAuthoringProjectSettings.Read());
                var plan = TableDeletion.Plan(InputOf(options), OutputOf(options), options.Tables);
                Debug.Log(LogPrefix + "Delete plan\n" + plan);
                result = TableDeletion.Apply(plan);
            }
            catch (Exception error) { result = Unexpected(error); }
            Exit(Log(result));
        }

        /// <summary>
        /// -executeMethod jjevol.TableMaintenanceBatch.AcceptCurrentFilesAndExit [-jjevolTableOutput Assets/.../Resources] [-jjevolTableAcceptEdited]
        /// The window's 「현재 파일을 새 기준으로 인정」. Without <see cref="AcceptEditedArgument"/> it accepts only missing outputs
        /// (their entries leave the record); a file whose content changed is refused with <see cref="TableMaintenanceOutcome.NotConfirmed"/>,
        /// since accepting it is only right after a person confirmed it matches the TSV.
        /// </summary>
        public static void AcceptCurrentFilesAndExit()
        {
            TableMaintenanceResult result;
            try
            {
                var options = ParseCommandLine(Environment.GetCommandLineArgs());
                // -executeMethod runs before the delayed registration, so apply the saved encryption setting as DeleteTablesAndExit does.
                TableEncryptionSetup.Apply(TableAuthoringProjectSettings.Read());
                result = AcceptCurrentFiles(OutputOf(options), options.AcceptEdited);
            }
            catch (Exception error) { result = Unexpected(error); }
            Exit(Log(result));
        }

        public static TableMaintenanceResult AcceptCurrentFiles(string outputDirectory, bool acceptEdited)
        {
            string manifest = TableBuilder.GetManifestPath(outputDirectory);
            if (File.Exists(manifest + ".pending"))
                return new TableMaintenanceResult(TableMaintenanceOutcome.RecoveryRequired, "적용이 끝나지 않은 빌드가 있습니다(" + TablePaths.Relative(manifest) + ".pending). 먼저 복구하세요.");
            var differences = TableBuilder.GetFileDifferences(outputDirectory);
            if (differences.Count == 0)
            {
                // Accepting changes only the record. A table that matches its record but cannot be read (codec or key changed) is not fixed by it.
                var status = TableBuilder.GetStatus(outputDirectory);
                if (status.State != TableBuildState.Ready)
                    return new TableMaintenanceResult(TableMaintenanceOutcome.Failed, "기록과 다른 파일은 없지만 상태가 " + status + "입니다. 기준 인정으로 풀 수 없습니다. 바꾸지 않았습니다.");
                string output = TablePaths.Output(outputDirectory);
                var unreadable = TableManifest.Read(manifest, output).tables.Where(record =>
                {
                    try { return !TableHash.MatchesPlain(record.plainHash, TableFiles.ReadApplied(TablePaths.RecordPath(output, record), record, TableRuntimeOptions.DecryptBytes).RuntimeText); }
                    catch { return true; }
                }).Select(record => record.name).ToArray();
                return unreadable.Length == 0
                    ? new TableMaintenanceResult(TableMaintenanceOutcome.Completed, "기록과 다른 파일이 없습니다. 바꾸지 않았습니다.")
                    : new TableMaintenanceResult(TableMaintenanceOutcome.Failed, "파일은 기록과 같지만 지금 복호화 설정으로 읽을 수 없는 표가 있습니다: " + string.Join(", ", unreadable) + ". 기준 인정으로 풀 수 없습니다. 암호화 설정·키를 확인하세요. 바꾸지 않았습니다.");
            }
            foreach (var difference in differences) Debug.Log(LogPrefix + "difference " + difference);
            var edited = differences.Where(d => d.Hash != "missing").ToArray();
            if (!acceptEdited && edited.Length != 0)
                return new TableMaintenanceResult(TableMaintenanceOutcome.NotConfirmed, "내용이 바뀐 파일은 TSV와 같은지 사람이 확인한 뒤 " + AcceptEditedArgument + "로만 인정합니다. 바꾸지 않았습니다: " + string.Join("; ", edited.Select(d => d.ToString())));
            var before = TableBuilder.GetManagedNames(outputDirectory);
            try { TableBuilder.AcceptCurrentFiles(outputDirectory, differences); }
            catch (Exception e) { return new TableMaintenanceResult(TableMaintenanceOutcome.Failed, e.GetType().Name + ": " + e.Message); }
            var after = TableBuilder.GetManagedNames(outputDirectory);
            return new TableMaintenanceResult(TableMaintenanceOutcome.Completed, "현재 파일을 새 기준으로 기록했습니다. 파일은 바꾸지 않았습니다.", null, before.Except(after, StringComparer.OrdinalIgnoreCase));
        }

        internal static Options ParseCommandLine(IReadOnlyList<string> args)
        {
            var options = new Options();
            string Value(ref int index, string name) => index + 1 < args.Count && !args[index + 1].StartsWith("-", StringComparison.Ordinal) ? args[++index] : throw new ArgumentException(name + " needs a value.");
            for (int index = 0; index < (args?.Count ?? 0); ++index)
            {
                string arg = args[index];
                if (string.Equals(arg, TablesArgument, StringComparison.OrdinalIgnoreCase))
                    options.Tables.AddRange(Value(ref index, TablesArgument).Split(',').Select(t => t.Trim()).Where(t => t.Length != 0));
                else if (string.Equals(arg, InputArgument, StringComparison.OrdinalIgnoreCase)) options.Input = Value(ref index, InputArgument);
                else if (string.Equals(arg, OutputArgument, StringComparison.OrdinalIgnoreCase)) options.Output = Value(ref index, OutputArgument);
                else if (string.Equals(arg, AcceptEditedArgument, StringComparison.OrdinalIgnoreCase)) options.AcceptEdited = true;
            }
            return options;
        }

        private static string InputOf(Options options) => !string.IsNullOrWhiteSpace(options.Input) ? options.Input : TableAuthoringProjectSettings.Read().Input;
        private static string OutputOf(Options options) => !string.IsNullOrWhiteSpace(options.Output) ? options.Output : TableAuthoringProjectSettings.Read().Output;

        private static TableMaintenanceResult Unexpected(Exception error)
        {
            Debug.LogException(error);
            return new TableMaintenanceResult(TableMaintenanceOutcome.Failed, error.GetType().Name + ": " + error.Message);
        }

        private static TableMaintenanceResult Log(TableMaintenanceResult result)
        {
            if (result.Succeeded) Debug.Log(LogPrefix + result);
            else Debug.LogError(LogPrefix + result);
            return result;
        }

        private static void Exit(TableMaintenanceResult result)
        {
            if (Application.isBatchMode) EditorApplication.Exit(result.ExitCode);
        }
    }
}
