namespace jjevol
{
    public interface ICommonDataToolSettings
    {
        string TableInputDirectory { get; }
        string TableOutputDirectory { get; }
        string LocalizationInputDirectory { get; }
        string LocalizationOutputDirectory { get; }
        string LocalizationSpreadsheet { get; }
        /// <summary>The project's Localization sheets as <c>Name=gid</c>, comma-separated (for example <c>ui=0,msg=1</c>).
        /// Sheet Import and its batch entry start from it. Empty by default, so existing implementations need no change.</summary>
        string LocalizationSheets => string.Empty;
    }
    public static class CommonDataToolSettings
    {
        private sealed class Defaults : ICommonDataToolSettings
        {
            public string TableInputDirectory => "Assets/GameData/Table/TSV";
            public string TableOutputDirectory => "Assets/GameData/Table/Resources";
            public string LocalizationInputDirectory => "Assets/GameData/Localization/Csv";
            public string LocalizationOutputDirectory => "Assets/GameData/Localization/Tables";
            public string LocalizationSpreadsheet => string.Empty;
        }
        public static ICommonDataToolSettings Current { get; set; } = new Defaults();
    }
}
