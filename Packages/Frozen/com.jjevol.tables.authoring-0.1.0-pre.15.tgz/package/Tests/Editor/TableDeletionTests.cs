using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TableDeletionTests
    {
        private const string Table = "key\tlabel\nx\told\n";
        private string _root, _input, _output;
        private string Source(string table) => _input + "/" + table + ".tsv";
        private string Output(string table) => _output + "/" + table + ".txt";
        private string Manifest => TableBuilder.GetManifestPath(_output);

        [SetUp] public void Setup()
        {
            _root = "Assets/JJEvolStepTableDelete_" + Guid.NewGuid().ToString("N"); _input = _root + "/TSV"; _output = _root + "/Resources/Tables";
            TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null; TableAuthoringOptions.ValidateTables = null;
            Directory.CreateDirectory(_input);
            File.WriteAllText(Source("a"), Table); File.WriteAllText(Source("b"), Table.Replace("old", "other"));
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        }
        [TearDown] public void Cleanup()
        {
            TableQaFailureEvidence.Capture(_root, _output);
            PipelineValidation.ForgetFixtureMetadata(_root); AssetDatabase.Refresh(); if (AssetDatabase.IsValidFolder(_root)) AssetDatabase.DeleteAsset(_root);
        }
        private TableBuildPlan FolderPlan() => TableBuilder.Plan(new TableBuildRequest(TableBuilder.ReadDirectory(_input), _output, false, catalogDirectory: _input));
        private TableBuildResult BuildFolder() => TableBuilder.Prepare(FolderPlan()).Apply();
        private static void Gone(params string[] paths) { foreach (string path in paths) Assert.That(File.Exists(path), Is.False, path); }

        [Test] public void DeleteRemovesSourceOutputAndRecordTogether()
        {
            BuildFolder();
            byte[] other = File.ReadAllBytes(Output("b"));
            Assert.That(File.Exists(Source("a") + ".meta"), Is.True, "The source fixture lives under Assets, so it has a .meta to delete.");
            var result = TableDeletion.Delete(_input, _output, new[] { "a" });
            Assert.That(result.Outcome, Is.EqualTo(TableMaintenanceOutcome.Completed), result.ToString());
            Assert.That(result.ExitCode, Is.EqualTo(0));
            Gone(Source("a"), Source("a") + ".meta", Output("a"), Output("a") + ".meta");
            Assert.That(result.RemovedRecords, Is.EqualTo(new[] { "a" }));
            Assert.That(TableBuilder.GetManagedNames(_output), Is.EqualTo(new[] { "b" }));
            Assert.That(File.ReadAllBytes(Output("b")), Is.EqualTo(other));
            Assert.That(File.Exists(Manifest + ".pending"), Is.False);
            Assert.That(TableBuilder.GetFileDifferences(_output), Is.Empty);
            Assert.That(TableBuilder.GetStatus(_output).State, Is.EqualTo(TableBuildState.Ready));
            var next = FolderPlan();
            Assert.That(next.IsValid, Is.True, string.Join("\n", next.Diagnostics));
            Assert.That(next.Diagnostics.Any(d => d.Code == "OrphanedOutput"), Is.False);
        }

        [Test] public void OutputsDeletedByHandOnlyLeaveTheRecord()
        {
            BuildFolder();
            // The reported case: TSV, output and .meta removed by hand. A build refuses, and only an explicit delete clears the record.
            foreach (string path in new[] { Source("a"), Source("a") + ".meta", Output("a"), Output("a") + ".meta" }) File.Delete(path);
            var blocked = FolderPlan();
            Assert.That(blocked.Diagnostics.Where(d => d.Severity == TableDiagnosticSeverity.Error).Select(d => d.Code), Does.Contain("ManagedConflict"));
            Assert.That(blocked.Diagnostics.First(d => d.Code == "ManagedConflict").Reason, Does.Contain("표 삭제"));
            var plan = TableDeletion.Plan(_input, _output, new[] { "a" });
            Assert.That(plan.IsValid, Is.True, plan.ToString());
            Assert.That(plan.SourceFiles, Is.Empty); Assert.That(plan.OutputFiles, Is.Empty); Assert.That(plan.Records, Is.EqualTo(new[] { "a" }));
            var result = TableDeletion.Apply(plan);
            Assert.That(result.Succeeded, Is.True, result.ToString());
            Assert.That(TableBuilder.GetManagedNames(_output), Is.EqualTo(new[] { "b" }));
            Assert.That(FolderPlan().IsValid, Is.True);
            Assert.Throws<InvalidOperationException>(() => TableDeletion.Apply(plan), "A plan is applied once.");
        }

        [Test] public void AnOutputThatDiffersFromItsRecordIsNotDeleted()
        {
            BuildFolder();
            File.AppendAllText(Output("a"), "y\tedited\n");
            var result = TableDeletion.Delete(_input, _output, new[] { "a" });
            Assert.That(result.Outcome, Is.EqualTo(TableMaintenanceOutcome.Failed));
            Assert.That(result.Message, Does.Contain("ManagedConflict"));
            Assert.That(File.Exists(Output("a")), Is.True); Assert.That(File.Exists(Source("a")), Is.True);
            Assert.That(TableBuilder.GetManagedNames(_output), Is.EquivalentTo(new[] { "a", "b" }));
        }

        [Test] public void UnknownNamesAndUnrecordedOutputsAreRefused()
        {
            BuildFolder();
            Assert.That(TableDeletion.Plan(_input, _output, new[] { "missing" }).Diagnostics.Select(d => d.Code), Does.Contain("UnknownTable"));
            File.WriteAllText(Output("foreign"), Table);
            var result = TableDeletion.Delete(_input, _output, new[] { "foreign", "a" });
            Assert.That(result.Outcome, Is.EqualTo(TableMaintenanceOutcome.Failed));
            Assert.That(result.Message, Does.Contain("UnmanagedOutput"));
            Assert.That(File.Exists(Output("foreign")), Is.True);
            Assert.That(File.Exists(Source("a")), Is.True, "One refused name stops the whole request.");
            Assert.That(TableBuilder.GetManagedNames(_output), Is.EquivalentTo(new[] { "a", "b" }));
            Assert.Throws<ArgumentException>(() => TableDeletion.Plan(_input, _output, new[] { " " }));
            Assert.Throws<ArgumentException>(() => TableDeletion.Plan(_input, _output, new[] { "../a" }));
        }

        [Test] public void AFolderBuildWarnsAboutATableWhoseSourceIsGone()
        {
            BuildFolder();
            File.Delete(Source("a")); File.Delete(Source("a") + ".meta");
            var plan = FolderPlan();
            Assert.That(plan.IsValid, Is.True, string.Join("\n", plan.Diagnostics));
            var warning = plan.Diagnostics.Single(d => d.Code == "OrphanedOutput");
            Assert.That(warning.Severity, Is.EqualTo(TableDiagnosticSeverity.Warning));
            Assert.That(warning.TableName, Is.EqualTo("a")); Assert.That(warning.Reason, Does.Contain("표 삭제"));
            var result = TableBuilder.Prepare(plan).Apply();
            Assert.That(result.OrphanedTables, Is.EqualTo(new[] { "a" }));
            Assert.That(File.Exists(Output("a")), Is.True, "A build still never deletes on its own.");
            // A plan that is not a folder build has no complete source list, so it does not guess.
            Assert.That(TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("b", Table.Replace("old", "other")) }, _output, false)).Diagnostics.Any(d => d.Code == "OrphanedOutput"), Is.False);
            var deleted = TableDeletion.Delete(_input, _output, new[] { "a" });
            Assert.That(deleted.Succeeded, Is.True, deleted.ToString());
            Gone(Output("a"), Output("a") + ".meta");
        }

        [Test] public void UnattendedAcceptTakesMissingOutputsAndNeedsConfirmationForEdits()
        {
            BuildFolder();
            Assert.That(TableMaintenanceBatch.AcceptCurrentFiles(_output, false).Outcome, Is.EqualTo(TableMaintenanceOutcome.Completed));
            File.Delete(Output("a")); File.Delete(Output("a") + ".meta");
            File.AppendAllText(Output("b"), "y\tedited\n");
            var refused = TableMaintenanceBatch.AcceptCurrentFiles(_output, false);
            Assert.That(refused.Outcome, Is.EqualTo(TableMaintenanceOutcome.NotConfirmed)); Assert.That(refused.ExitCode, Is.EqualTo(2));
            Assert.That(TableBuilder.GetManagedNames(_output), Is.EquivalentTo(new[] { "a", "b" }), "Nothing is accepted while one file needs confirmation.");
            var accepted = TableMaintenanceBatch.AcceptCurrentFiles(_output, true);
            Assert.That(accepted.Outcome, Is.EqualTo(TableMaintenanceOutcome.Completed), accepted.ToString());
            Assert.That(accepted.RemovedRecords, Is.EqualTo(new[] { "a" }));
            Assert.That(TableBuilder.GetFileDifferences(_output), Is.Empty);
        }

        [Test] public void ARequestThatListsOnlySomeInputsDoesNotCallTheOthersOrphaned()
        {
            BuildFolder();
            // A ConsumeTypes-only or selected request passes the folder as catalog with fewer inputs; the folder decides.
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromFile(Path.GetFullPath(Source("a"))) }, _output, false, catalogDirectory: _input));
            Assert.That(plan.IsValid, Is.True, string.Join("\n", plan.Diagnostics));
            Assert.That(plan.Diagnostics.Any(d => d.Code == "OrphanedOutput"), Is.False);
        }

        [Test] public void AMissingSourceFolderIsRefused()
        {
            BuildFolder();
            var plan = TableDeletion.Plan(_root + "/NoSuchFolder", _output, new[] { "a" });
            Assert.That(plan.IsValid, Is.False); Assert.That(plan.Diagnostics.Select(d => d.Code), Does.Contain("InputMissing"));
            Assert.That(TableDeletion.Apply(plan).Outcome, Is.EqualTo(TableMaintenanceOutcome.Failed));
            Assert.That(File.Exists(Output("a")), Is.True);
        }

        [Test] public void ARecordedOutputWithoutItsMetaIsDeleted()
        {
            BuildFolder();
            File.Delete(Output("a") + ".meta");
            var result = TableDeletion.Delete(_input, _output, new[] { "a" });
            Assert.That(result.Succeeded, Is.True, result.ToString());
            Gone(Output("a"), Output("a") + ".meta", Source("a"));
        }

        [Test] public void RemoveNeedsNoEncoderAndStillReadsTheEncryptedTablesLeft()
        {
            TableAuthoringOptions.EncryptBytes = bytes => bytes.Reverse().ToArray(); TableRuntimeOptions.DecryptBytes = bytes => bytes.Reverse().ToArray();
            TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(TableBuilder.ReadDirectory(_input), _output, true, catalogDirectory: _input))).Apply();
            TableAuthoringOptions.EncryptBytes = null;
            bool encrypted = TableAuthoringOptions.UseEncryption;
            try
            {
                TableAuthoringOptions.UseEncryption = true;
                var result = TableDeletion.Delete(_input, _output, new[] { "a" });
                Assert.That(result.Succeeded, Is.True, result.ToString());
                Assert.That(TableBuilder.GetManagedNames(_output), Is.EqualTo(new[] { "b" }));
            }
            finally { TableAuthoringOptions.UseEncryption = encrypted; TableRuntimeOptions.DecryptBytes = null; }
        }

        [Test] public void ConsumeTypesWithoutGeneratedCodeIsAnOrdinarySourceName()
        {
            BuildFolder();
            File.WriteAllText(Source("ConsumeTypes"), "typeId\tcodeName\n1\tGold\n");
            var plan = TableDeletion.Plan(_input, _output, new[] { "ConsumeTypes" });
            // Without generated code ConsumeTypes is only a source file with no record, so deleting it is allowed.
            Assert.That(plan.IsValid, Is.True, plan.ToString());
            Assert.That(plan.Records, Is.Empty);
        }

        [Test] public void AnUnfinishedRecordStopsTheDeleteWithRecoveryRequired()
        {
            BuildFolder();
            File.WriteAllText(Source("c"), Table);
            File.WriteAllText(Manifest, File.ReadAllText(Manifest).Replace("\"status\": \"Ready\"", "\"status\": \"Applying\""));
            var result = TableDeletion.Delete(_input, _output, new[] { "c" });
            Assert.That(result.Outcome, Is.EqualTo(TableMaintenanceOutcome.RecoveryRequired), result.ToString());
            Assert.That(result.ExitCode, Is.EqualTo(3));
            Assert.That(File.Exists(Source("c")), Is.True, "Nothing is deleted while the record needs recovery.");
        }

        [Test] public void UnattendedAcceptDoesNotReportAnUnreadableTableAsFine()
        {
            TableAuthoringOptions.EncryptBytes = bytes => bytes.Reverse().ToArray(); TableRuntimeOptions.DecryptBytes = bytes => bytes.Reverse().ToArray();
            try
            {
                TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(TableBuilder.ReadDirectory(_input), _output, true, catalogDirectory: _input))).Apply();
                Assert.That(TableMaintenanceBatch.AcceptCurrentFiles(_output, false).Outcome, Is.EqualTo(TableMaintenanceOutcome.Completed));
                TableRuntimeOptions.DecryptBytes = bytes => bytes; // A changed key: the files still match the record, but cannot be read.
                var result = TableMaintenanceBatch.AcceptCurrentFiles(_output, true);
                Assert.That(result.Outcome, Is.EqualTo(TableMaintenanceOutcome.Failed), result.ToString());
                Assert.That(result.Message, Does.Contain("a").And.Contain("b"));
            }
            finally { TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null; }
        }

        [Test] public void CommandLineArgumentsAreParsed()
        {
            var options = TableMaintenanceBatch.ParseCommandLine(new[] { "Unity.exe", "-JJEVOLTABLES", "a, b,,", "-jjevolTables", "c", "-jjevolTableInput", "Assets/T", "-jjevolTableOutput", "Assets/R", "-jjevolTableAcceptEdited" });
            Assert.That(options.Tables, Is.EqualTo(new[] { "a", "b", "c" }));
            Assert.That(options.Input, Is.EqualTo("Assets/T")); Assert.That(options.Output, Is.EqualTo("Assets/R")); Assert.That(options.AcceptEdited, Is.True);
            Assert.That(TableMaintenanceBatch.ParseCommandLine(new[] { "Unity.exe" }).AcceptEdited, Is.False);
            Assert.Throws<ArgumentException>(() => TableMaintenanceBatch.ParseCommandLine(new[] { "-jjevolTables" }));
            Assert.Throws<ArgumentException>(() => TableMaintenanceBatch.ParseCommandLine(new[] { "-jjevolTableOutput", "-jjevolTableAcceptEdited" }));
        }

        [Test] public void UnattendedAcceptOfOnlyMissingOutputsNeedsNoFlag()
        {
            BuildFolder();
            File.Delete(Output("a")); File.Delete(Output("a") + ".meta");
            var accepted = TableMaintenanceBatch.AcceptCurrentFiles(_output, false);
            Assert.That(accepted.Outcome, Is.EqualTo(TableMaintenanceOutcome.Completed), accepted.ToString());
            Assert.That(TableBuilder.GetManagedNames(_output), Is.EqualTo(new[] { "b" }));
        }
    }
}
