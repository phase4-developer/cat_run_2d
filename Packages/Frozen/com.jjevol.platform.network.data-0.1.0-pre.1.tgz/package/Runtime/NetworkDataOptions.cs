using System;
using System.Collections.Generic;
using jjevol;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network.Data
{
    /// <summary>What a response applies to the repository. Passed to the steps added with <see cref="NetworkDataOptions.AddStep"/>.</summary>
    public sealed class NetworkDataApplyContext
    {
        public DataRepository Repository { get; }
        public NetworkRequest Request { get; }
        public NetworkResult Result { get; }
        /// <summary>The object to apply: the updated-data object when the response has one, otherwise the whole success data.</summary>
        public JObject Data { get; }
        /// <summary>The request's DataKeys that the repository has registered.</summary>
        public string[] TargetKeys { get; }
        /// <summary>True applies with ImportJson (replace), false with UpdateJson (merge).</summary>
        public bool Replace { get; }

        internal NetworkDataApplyContext(DataRepository repository, NetworkRequest request, NetworkResult result, JObject data, string[] targetKeys, bool replace)
        {
            Repository = repository;
            Request = request;
            Result = result;
            Data = data;
            TargetKeys = targetKeys;
            Replace = replace;
        }
    }

    /// <summary>Keys that did not line up between a response, its request and the repository.</summary>
    public sealed class NetworkDataUnmatchedKeys
    {
        public NetworkRequest Request { get; }
        /// <summary>Keys in the applied data that the request did not name in DataKeys (ignored keys left out).</summary>
        public IReadOnlyList<string> NotRequested { get; }
        /// <summary>DataKeys of the request that the repository has not registered. They are not applied.</summary>
        public IReadOnlyList<string> NotRegistered { get; }
        public bool IsEmpty => NotRequested.Count == 0 && NotRegistered.Count == 0;

        internal NetworkDataUnmatchedKeys(NetworkRequest request, IReadOnlyList<string> notRequested, IReadOnlyList<string> notRegistered)
        {
            Request = request;
            NotRequested = notRequested;
            NotRegistered = notRegistered;
        }

        public override string ToString()
            => "Network data keys do not match for " + Request?.Name
               + (NotRequested.Count > 0 ? ". In the response but not in DataKeys: " + string.Join(", ", NotRequested) : string.Empty)
               + (NotRegistered.Count > 0 ? ". In DataKeys but not registered: " + string.Join(", ", NotRegistered) : string.Empty) + ".";
    }

    /// <summary>Options for <see cref="NetworkDataBinding"/>.</summary>
    public sealed class NetworkDataOptions
    {
        private readonly List<Func<NetworkDataApplyContext, bool>> _steps = new List<Func<NetworkDataApplyContext, bool>>();

        /// <summary>Key of the updated-data object inside the success data. When absent, the whole success data is applied. Null always applies the whole data.</summary>
        public string UpdatedDataKey { get; set; } = "updatedData";

        /// <summary>Response keys that are never reported as unmatched.</summary>
        public HashSet<string> IgnoredKeys { get; } = new HashSet<string>(StringComparer.Ordinal) { "rewards", "timeStamp" };

        /// <summary>Logs unmatched keys as warnings. On by default in the Editor only.</summary>
        public bool LogUnmatchedKeys { get; set; }
#if UNITY_EDITOR
            = true;
#endif

        /// <summary>Raised for every applied response whose keys do not line up.</summary>
        public event Action<NetworkDataUnmatchedKeys> UnmatchedKeys;

        internal IReadOnlyList<Func<NetworkDataApplyContext, bool>> Steps => _steps;

        /// <summary>
        /// Adds a step that runs before the default apply, in the order added. A step that returns true has applied
        /// the response itself, and the default apply and later steps are skipped. Example: confirm a resource
        /// reservation with ResourceService.ApplyServerResponse. A throw ends the request as ApplyFailed.
        /// </summary>
        public NetworkDataOptions AddStep(Func<NetworkDataApplyContext, bool> step)
        {
            _steps.Add(step ?? throw new ArgumentNullException(nameof(step)));
            return this;
        }

        internal void Report(NetworkDataUnmatchedKeys unmatched)
        {
            if (LogUnmatchedKeys) UnityEngine.Debug.LogWarning(unmatched.ToString());
            // A diagnostic listener never fails the request.
            try { UnmatchedKeys?.Invoke(unmatched); }
            catch (Exception exception) { UnityEngine.Debug.LogException(exception); }
        }
    }
}
