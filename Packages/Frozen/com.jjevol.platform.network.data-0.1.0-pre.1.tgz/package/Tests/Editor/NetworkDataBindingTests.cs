using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using jjevol;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Network.Data.Tests
{
    /// <summary>Synthetic container: an object of text values under its own key. Server only, never saved.</summary>
    internal class TextContainer : DataContainer
    {
        public TextContainer(string key) : base(key, new Dictionary<string, string>(StringComparer.Ordinal)) { }
        public string Read(string id) => ((Dictionary<string, string>)State).TryGetValue(id, out string value) ? value : null;
        public int Count => ((Dictionary<string, string>)State).Count;

        protected override StateChange ParseState(JObject data, bool replace)
        {
            var current = (Dictionary<string, string>)State;
            var next = replace ? new Dictionary<string, string>(StringComparer.Ordinal) : new Dictionary<string, string>(current, StringComparer.Ordinal);
            if (!(data[DataKey] is JObject values)) throw new InvalidDataException("Expected an object: " + DataKey);
            foreach (var pair in values)
            {
                if (pair.Value.Type != JTokenType.String) throw new InvalidDataException("Expected text: " + pair.Key);
                next[pair.Key] = pair.Value.Value<string>();
            }
            IEnumerable<string> changed = next.Keys.Union(current.Keys)
                .Where(key => !current.TryGetValue(key, out string before) || !next.TryGetValue(key, out string after) || before != after);
            return new StateChange(next, changed);
        }

        protected override JObject WriteState(object state)
        {
            var values = new JObject();
            foreach (var pair in ((Dictionary<string, string>)state).OrderBy(pair => pair.Key, StringComparer.Ordinal)) values[pair.Key] = pair.Value;
            return new JObject { [DataKey] = values };
        }
    }

    internal sealed class SourceContainer : TextContainer, INetworkDataSource
    {
        public NetworkRequest[] Requests;
        public SourceContainer(string key) : base(key) { }
        public IEnumerable<NetworkRequest> CreateLoadRequests() => Requests;
    }

    internal sealed class DataRequest : NetworkRequest
    {
        private readonly string _name;
        public DataRequest(string name, bool replace, params string[] keys)
        {
            _name = name;
            DataKeys = keys;
            ReplaceData = replace;
            Route = NetworkRoute.Local;
        }
        public override string Name => _name;
    }

    /// <summary>Answers every request with the scripted data for its name.</summary>
    internal sealed class ScriptedLocal : INetworkLocalService
    {
        public readonly Dictionary<string, JObject> Responses = new Dictionary<string, JObject>(StringComparer.Ordinal);
        public readonly List<string> Calls = new List<string>();
        public bool CanHandle(NetworkRequest request) => true;
        public Task<JObject> HandleAsync(NetworkCall call, CancellationToken cancellationToken)
        {
            Calls.Add(call.Request.Name);
            return Task.FromResult(Responses.TryGetValue(call.Request.Name, out JObject data) ? (JObject)data.DeepClone() : new JObject());
        }
    }

    public sealed class NetworkDataBindingTests
    {
        private SynchronizationContext _context;
        private ScriptedLocal _local;
        private DataRepository _repository;
        private TextContainer _mails, _options;
        private NetworkDataOptions _bindingOptions;
        private readonly List<NetworkDataUnmatchedKeys> _unmatched = new List<NetworkDataUnmatchedKeys>();

        [SetUp]
        public void SetUp()
        {
            // Completed tasks continue inline so each test runs synchronously.
            _context = SynchronizationContext.Current;
            SynchronizationContext.SetSynchronizationContext(null);
            NetworkManager.ClearAll();
            _local = new ScriptedLocal();
            NetworkManager.SetLocalService(_local);
            _repository = new DataRepository("network-data:" + Guid.NewGuid().ToString("N"));
            _mails = new TextContainer("userMails");
            _options = new TextContainer("gameOptions");
            _repository.Register(_mails, saveLocal: false);
            _repository.Register(_options, saveLocal: false);
            _unmatched.Clear();
            _bindingOptions = new NetworkDataOptions { LogUnmatchedKeys = false };
            _bindingOptions.UnmatchedKeys += _unmatched.Add;
            NetworkDataBinding.Connect(_repository, _bindingOptions);
        }

        [TearDown]
        public void TearDown()
        {
            NetworkDataBinding.Disconnect();
            NetworkManager.ClearAll();
            _repository.Dispose();
            SynchronizationContext.SetSynchronizationContext(_context);
        }

        private NetworkResult Send(NetworkRequest request, JObject response)
        {
            _local.Responses[request.Name] = response;
            NetworkResult? received = null;
            NetworkManager.Post(request, result => received = result);
            Assert.IsTrue(received.HasValue, "The callback runs.");
            return received.Value;
        }

        [Test]
        public void UpdateAppliesOnlyTheRequestedKeysBeforeTheCallback()
        {
            string seenInCallback = null;
            _local.Responses["claimMail"] = JObject.Parse("{\"userMails\":{\"m1\":\"gift\"},\"gameOptions\":{\"sound\":\"off\"},\"timeStamp\":5}");
            NetworkManager.Post(new DataRequest("claimMail", false, "userMails"), _ => seenInCallback = _mails.Read("m1"));

            Assert.AreEqual("gift", seenInCallback, "The repository changes before the callback.");
            Assert.AreEqual(0, _options.Count, "Keys outside DataKeys are not applied.");
            Assert.AreEqual(1, _unmatched.Count);
            CollectionAssert.AreEqual(new[] { "gameOptions" }, _unmatched[0].NotRequested.ToArray(), "Ignored keys are not reported.");

            Send(new DataRequest("claimMail2", false, "userMails"), JObject.Parse("{\"userMails\":{\"m2\":\"coin\"}}"));
            Assert.AreEqual("gift", _mails.Read("m1"), "UpdateJson merges.");
            Assert.AreEqual("coin", _mails.Read("m2"));
        }

        [Test]
        public void ReplaceUsesImportJson()
        {
            _repository.UpdateJson(JObject.Parse("{\"userMails\":{\"old\":\"x\"}}"), "userMails");
            NetworkResult result = Send(new DataRequest("loadMails", true, "userMails"), JObject.Parse("{\"userMails\":{\"new\":\"y\"}}"));
            Assert.IsTrue(result.Success);
            Assert.IsNull(_mails.Read("old"));
            Assert.AreEqual("y", _mails.Read("new"));
        }

        [Test]
        public void UpdatedDataObjectIsPreferred()
        {
            Send(new DataRequest("claimMail", false, "userMails"),
                JObject.Parse("{\"updatedData\":{\"userMails\":{\"m1\":\"gift\"}},\"rewards\":[{\"id\":1}],\"userMails\":{\"m1\":\"wrong\"}}"));
            Assert.AreEqual("gift", _mails.Read("m1"));
            Assert.AreEqual(0, _unmatched.Count);

            _bindingOptions.UpdatedDataKey = "changed";
            Send(new DataRequest("claimMail2", false, "userMails"), JObject.Parse("{\"changed\":{\"userMails\":{\"m2\":\"coin\"}}}"));
            Assert.AreEqual("coin", _mails.Read("m2"));
        }

        [Test]
        public void RequestsWithoutDataKeysApplyNothing()
        {
            NetworkResult result = Send(new DataRequest("ranking", false), JObject.Parse("{\"userMails\":{\"m1\":\"gift\"},\"rank\":3}"));
            Assert.IsTrue(result.Success);
            Assert.AreEqual(0, _mails.Count);
            Assert.AreEqual(0, _unmatched.Count, "A plain reply is not a data change.");

            Send(new DataRequest("ranking2", false), JObject.Parse("{\"updatedData\":{\"userMails\":{\"m1\":\"gift\"}}}"));
            Assert.AreEqual(0, _mails.Count);
            CollectionAssert.AreEqual(new[] { "userMails" }, _unmatched.Single().NotRequested.ToArray(), "An updated-data object without DataKeys is reported.");
        }

        [Test]
        public void UnregisteredKeysAreReportedAndSkipped()
        {
            NetworkResult result = Send(new DataRequest("claimMail", true, "userMails", "userWealth"),
                JObject.Parse("{\"userMails\":{\"m1\":\"gift\"},\"userWealth\":{\"gold\":\"3\"}}"));
            Assert.IsTrue(result.Success);
            Assert.AreEqual("gift", _mails.Read("m1"));
            CollectionAssert.AreEqual(new[] { "userWealth" }, _unmatched.Single().NotRegistered.ToArray());
            Assert.AreEqual(0, _unmatched.Single().NotRequested.Count);
            StringAssert.Contains("userWealth", _unmatched.Single().ToString());
        }

        [Test]
        public void InvalidDataEndsTheRequestAsApplyFailed()
        {
            _repository.UpdateJson(JObject.Parse("{\"userMails\":{\"keep\":\"x\"}}"), "userMails");
            LogAssert.Expect(LogType.Exception, new Regex("Missing replacement container"));
            NetworkResult missing = Send(new DataRequest("loadAll", true, "userMails", "gameOptions"), JObject.Parse("{\"userMails\":{}}"));
            Assert.AreEqual(NetworkFailure.ApplyFailed, missing.Failure);
            Assert.AreEqual("x", _mails.Read("keep"), "Nothing is applied when one target fails.");

            LogAssert.Expect(LogType.Exception, new Regex("Expected text"));
            NetworkResult invalid = Send(new DataRequest("claimMail", false, "userMails"), JObject.Parse("{\"userMails\":{\"m1\":7}}"));
            Assert.AreEqual(NetworkFailure.ApplyFailed, invalid.Failure);
            Assert.IsNull(_mails.Read("m1"));
        }

        [Test]
        public void StepsRunBeforeTheDefaultApply()
        {
            var seen = new List<NetworkDataApplyContext>();
            bool handle = true;
            _bindingOptions.AddStep(context => { seen.Add(context); return handle && context.Request.Name == "buyItem"; });

            Send(new DataRequest("buyItem", false, "userMails", "userWealth"), JObject.Parse("{\"userMails\":{\"m1\":\"gift\"}}"));
            Assert.AreEqual(0, _mails.Count, "A step that handled the response skips the default apply.");
            NetworkDataApplyContext first = seen.Single();
            Assert.AreSame(_repository, first.Repository);
            CollectionAssert.AreEqual(new[] { "userMails" }, first.TargetKeys, "Steps see only registered keys.");
            Assert.IsFalse(first.Replace);
            Assert.AreEqual("gift", first.Data["userMails"]["m1"].Value<string>());

            handle = false;
            Send(new DataRequest("claimMail", false, "userMails"), JObject.Parse("{\"userMails\":{\"m2\":\"coin\"}}"));
            Assert.AreEqual("coin", _mails.Read("m2"), "A step that returned false leaves the default apply.");

            _bindingOptions.AddStep(context => throw new InvalidOperationException("reservation mismatch"));
            LogAssert.Expect(LogType.Exception, new Regex("reservation mismatch"));
            Assert.AreEqual(NetworkFailure.ApplyFailed, Send(new DataRequest("claimMail3", false, "userMails"), JObject.Parse("{\"userMails\":{\"m3\":\"x\"}}")).Failure);
        }

        [Test]
        public void LoadAllQueuesEverySource()
        {
            var repository = new DataRepository("network-data:" + Guid.NewGuid().ToString("N"));
            try
            {
                var shared = new DataRequest("loadUser", true, "userMails", "userQuests");
                var mails = new SourceContainer("userMails") { Requests = new NetworkRequest[] { shared } };
                var quests = new SourceContainer("userQuests") { Requests = new NetworkRequest[] { shared, null } };
                var shop = new SourceContainer("shopItems") { Requests = new NetworkRequest[] { new DataRequest("loadShop", true, "shopItems") } };
                repository.Register(mails, saveLocal: false);
                repository.Register(new TextContainer("gameOptions"));
                repository.Register(quests, saveLocal: false);
                repository.Register(shop, saveLocal: false);
                NetworkDataBinding.Connect(repository, _bindingOptions);
                _local.Responses["loadUser"] = JObject.Parse("{\"userMails\":{\"m1\":\"gift\"},\"userQuests\":{\"q1\":\"done\"}}");
                _local.Responses["loadShop"] = JObject.Parse("{\"shopItems\":{\"s1\":\"sword\"}}");

                NetworkBatch completedBatch = null;
                NetworkBatch batch = NetworkDataBinding.LoadAll(repository, done => completedBatch = done);
                Assert.AreSame(batch, completedBatch);
                Assert.IsTrue(batch.Success);
                CollectionAssert.AreEqual(new[] { "loadUser", "loadShop" }, _local.Calls, "Registration order, shared requests once.");
                Assert.AreEqual("gift", mails.Read("m1"));
                Assert.AreEqual("done", quests.Read("q1"));
                Assert.AreEqual("sword", shop.Read("s1"));
            }
            finally
            {
                NetworkDataBinding.Disconnect(repository);
                repository.Dispose();
            }
        }

        [Test]
        public void DisconnectRemovesTheApplier()
        {
            var other = new DataRepository("network-data:" + Guid.NewGuid().ToString("N"));
            try
            {
                NetworkDataBinding.Disconnect(other);
                Assert.AreSame(_repository, NetworkDataBinding.Repository, "Another repository does not disconnect this one.");
            }
            finally { other.Dispose(); }

            NetworkDataBinding.Disconnect(_repository);
            Assert.IsNull(NetworkDataBinding.Repository);
            Send(new DataRequest("claimMail", false, "userMails"), JObject.Parse("{\"userMails\":{\"m1\":\"gift\"}}"));
            Assert.AreEqual(0, _mails.Count);
            Assert.IsFalse(NetworkDataBinding.Apply(_repository, new DataRequest("x", false, "userMails"), NetworkResult.Failed(NetworkFailure.Rejected)));
            Assert.IsTrue(NetworkDataBinding.Apply(_repository, new DataRequest("x", false, "userMails"), NetworkResult.Succeeded(JObject.Parse("{\"userMails\":{\"m1\":\"gift\"}}"))));
            Assert.AreEqual("gift", _mails.Read("m1"));
        }

        [Test]
        public void EnteringPlayModeDropsTheConnectedRepository()
        {
            System.Reflection.MethodInfo reset = typeof(NetworkDataBinding).GetMethod("ResetOnLoad",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
            Assert.IsNotNull(reset);
            var attribute = (RuntimeInitializeOnLoadMethodAttribute)Attribute.GetCustomAttribute(reset, typeof(RuntimeInitializeOnLoadMethodAttribute));
            Assert.IsNotNull(attribute);
            Assert.AreEqual(RuntimeInitializeLoadType.SubsystemRegistration, attribute.loadType);

            Assert.AreSame(_repository, NetworkDataBinding.Repository);
            reset.Invoke(null, null);
            Assert.IsNull(NetworkDataBinding.Repository);
            Assert.IsNull(NetworkDataBinding.Options);
        }
    }
}
