# Changelog

## 0.1.0-pre.1 - 2026-11-08

- First candidate. `NetworkDataBinding` (`Connect`, `Disconnect`, `Apply`, `LoadAll`), `NetworkDataOptions` (`UpdatedDataKey`, `IgnoredKeys`, `LogUnmatchedKeys`, `UnmatchedKeys`, `AddStep`), `NetworkDataApplyContext`, `NetworkDataUnmatchedKeys`, `INetworkDataSource`.
- Success data is applied before the request callback with `ImportJson` when the request has `ReplaceData`, otherwise `UpdateJson`, using the request's `DataKeys`. A failed apply ends the request as `ApplyFailed`.
- `Repository` and `Options` are cleared at `SubsystemRegistration`, so entering Play Mode with Domain Reload off does not keep a disposed repository.

Unity EditMode tests passed on Hosts/NetworkValidationHost (job network-host-2, candidate abd61a5). The Editor tests passed in an offline .NET runner.
