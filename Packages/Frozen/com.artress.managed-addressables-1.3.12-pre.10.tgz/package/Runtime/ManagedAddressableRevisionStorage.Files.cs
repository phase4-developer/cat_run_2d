using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Networking;

namespace Artress.ManagedAddressables
{
    public sealed partial class ManagedAddressableRevisionStorage
    {
        private static bool IsSha(string value) => value != null && value.Length == 64 && value.All(Uri.IsHexDigit);
        private static bool SameSha(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        private static string Sha(byte[] bytes)
        {
            using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }
        private static string ShaFile(string path, CancellationToken token)
        {
            RejectReparse(path);
            using (var stream = File.OpenRead(path))
            using (var hash = SHA256.Create())
            {
                var buffer = new byte[1024 * 1024]; int read;
                while ((read = stream.Read(buffer, 0, buffer.Length)) > 0)
                { token.ThrowIfCancellationRequested(); hash.TransformBlock(buffer, 0, read, null, 0); }
                token.ThrowIfCancellationRequested(); hash.TransformFinalBlock(Array.Empty<byte>(), 0, 0);
                return BitConverter.ToString(hash.Hash).Replace("-", "").ToLowerInvariant();
            }
        }
        private static Task<string> ShaFileAsync(string path, CancellationToken token)
            => Task.Run(() => ShaFile(path, token), token);
        private static Task<string> ShaBytesAsync(byte[] bytes, CancellationToken token)
            => Task.Run(() => { token.ThrowIfCancellationRequested(); return Sha(bytes); }, token);

        // Pure file I/O only. Awaiting callers retain Unity's main-thread context;
        // no Unity API, known-file table, counters, or Session state runs here.
        private static Task CopyFileAsync(string source, string temporary, CancellationToken token)
            => Task.Run(() =>
            {
                RejectReparse(source); RejectReparse(temporary);
                using (var input = File.OpenRead(source))
                using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] buffer = new byte[1024 * 1024]; int count;
                    while ((count = input.Read(buffer, 0, buffer.Length)) != 0)
                    { token.ThrowIfCancellationRequested(); output.Write(buffer, 0, count); }
                    token.ThrowIfCancellationRequested(); output.Flush(true);
                }
            }, token);

        private static Task FlushFileAsync(string path, CancellationToken token)
            => Task.Run(() =>
            {
                token.ThrowIfCancellationRequested(); RejectReparse(path);
                using (var file = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) file.Flush(true);
                token.ThrowIfCancellationRequested();
            }, token);
        private string MetadataDirectory(string publisherSha)
        {
            Require(IsSha(publisherSha), "InvalidPublisherShaPath");
            return Path.Combine(root, "revisions", publisherSha.ToLowerInvariant());
        }
        private string BlobPath(string sha)
        {
            Require(IsSha(sha), "InvalidBundleShaPath");
            return Path.Combine(root, "blobs", target, sha.ToLowerInvariant() + ".bundle");
        }
        private string NewTemporary() => Path.Combine(root, "tmp", "t-" + Guid.NewGuid().ToString("N") + ".tmp");
        private void EnsureDirectories()
        {
            foreach (string path in new[] { root, Path.Combine(root, "revisions"), Path.Combine(root, "blobs"), Path.Combine(root, "blobs", target), Path.Combine(root, "tmp") })
            { RejectReparse(path); Directory.CreateDirectory(path); RejectReparse(path); ExcludeFromBackup(path); }
        }
        private void EnsureSpace(long bytes)
        {
            Require(bytes >= 0, "StorageCapacityOverflow");
            long available = AvailableSpace();
            if (available < bytes) throw new IOException("InsufficientOwnedRevisionSpace: required=" + bytes + ", available=" + available);
        }
        private static bool ExistsAtSize(string path, long bytes)
        {
            RejectReparse(path);
            return File.Exists(path) && new FileInfo(path).Length == bytes;
        }
        private void WriteImmutable(string path, byte[] bytes)
        {
            RejectReparse(Path.GetDirectoryName(path)); RejectReparse(path);
            if (File.Exists(path))
            { Require(SameSha(ShaFile(path, CancellationToken.None), Sha(bytes)), "ImmutableRevisionMetadataAlreadyDifferent"); return; }
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            { stream.Write(bytes, 0, bytes.Length); stream.Flush(true); }
            ExcludeFromBackup(path);
        }

        private async Task WriteMetadataAsync(string path, byte[] bytes, bool repairConfirmed, CancellationToken token)
        {
            RejectReparse(Path.GetDirectoryName(path)); RejectReparse(path);
            if (File.Exists(path) && SameSha(await ShaFileAsync(path, token), await ShaBytesAsync(bytes, token))) return;
            // The normal path may heal an interrupted UNCONFIRMED metadata write,
            // never the current confirmation. Recovery is explicitly same-anchor.
            string publisherSha = Path.GetFileName(Path.GetDirectoryName(path));
            var pointer = ReadPointerIfPresent(out _);
            Require(repairConfirmed || pointer == null || !SameSha(pointer.publisherSha256, publisherSha), "ConfirmedMetadataRequiresRepair");
            string temporary = NewTemporary();
            try
            {
                await Task.Run(() =>
                {
                    token.ThrowIfCancellationRequested();
                    using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    { output.Write(bytes, 0, bytes.Length); token.ThrowIfCancellationRequested(); output.Flush(true); }
                }, token);
                token.ThrowIfCancellationRequested(); Directory.CreateDirectory(Path.GetDirectoryName(path));
                if (File.Exists(path)) File.Replace(temporary, path, null); else File.Move(temporary, path);
                ExcludeFromBackup(path);
            }
            finally { DeleteTemporary(temporary); }
        }
        private async Task ReceiveAsync(string sourcePath, string temporary, string expectedSha, long expectedBytes, CancellationToken token)
        {
            Require(IsSha(expectedSha), "ExpectedFileShaRequired");
            Exception last = null;
            for (int attempt = 0; attempt <= retries; attempt++)
            {
                token.ThrowIfCancellationRequested();
                last = null;
                try
                {
                    if (File.Exists(temporary)) File.Delete(temporary);
                    if (!Uri.TryCreate(sourcePath, UriKind.Absolute, out var source) || source.IsFile)
                    {
                        string path = source != null && source.IsFile ? source.LocalPath : sourcePath;
                        Require(Path.IsPathRooted(path) && File.Exists(path), "RevisionFileSourceMissing");
                        long length = new FileInfo(path).Length; EnsureSpace(length);
                        await CopyFileAsync(path, temporary, token);
                    }
                    else
                    {
                        // Android packaged assets are not filesystem files. UWR is Unity's
                        // supported APK/jar reader; permit only this app's StreamingAssets.
                        bool packagedJar = source.Scheme == "jar" && Application.platform == RuntimePlatform.Android &&
                            sourcePath.StartsWith(Application.streamingAssetsPath.TrimEnd('/') + "/", StringComparison.Ordinal);
                        Require(ManagedRevisionTransport.Allows(source) || packagedJar, "UnsupportedRevisionDownloadScheme: " + ManagedRevisionTransport.PlainHttpRefused);
                        using (var request = UnityWebRequest.Get(source.AbsoluteUri))
                        {
                            request.timeout = 0; request.downloadHandler = new DownloadHandlerFile(temporary);
                            // Preserve the caller's existing SDK request customization (e.g. auth); never replace it.
                            Addressables.ResourceManager.WebRequestOverride?.Invoke(request);
                            var operation = request.SendWebRequest(); ulong lastBytes = 0; float lastProgress = Time.realtimeSinceStartup; bool checkedResponseSpace = false;
                            while (!operation.isDone)
                            {
                                if (token.IsCancellationRequested)
                                { request.Abort(); while (!operation.isDone) await Task.Yield(); token.ThrowIfCancellationRequested(); }
                                if (!checkedResponseSpace && long.TryParse(request.GetResponseHeader("Content-Length"), out long length) && length > 0)
                                { EnsureSpace(Math.Max(0, length - (long)request.downloadedBytes)); checkedResponseSpace = true; }
                                if (request.downloadedBytes != lastBytes) { lastBytes = request.downloadedBytes; lastProgress = Time.realtimeSinceStartup; }
                                else if (stallTimeout > 0 && Time.realtimeSinceStartup - lastProgress >= stallTimeout)
                                { request.Abort(); while (!operation.isDone) await Task.Yield(); throw new TimeoutException("Revision download stalled: " + ManagedRevisionTransport.Displayed(source)); }
                                await Task.Yield();
                            }
                            Require(request.result == UnityWebRequest.Result.Success, "RevisionDownloadFailed: " + ManagedRevisionTransport.WithoutQuery(request.error));
                        }
                        if (expectedBytes > 0) Require(new FileInfo(temporary).Length == expectedBytes, "DownloadedRevisionLengthMismatch");
                    }
                    token.ThrowIfCancellationRequested();
                    if (expectedBytes > 0) Require(new FileInfo(temporary).Length == expectedBytes, "DownloadedRevisionLengthMismatch");
                    Require(SameSha(await ShaFileAsync(temporary, token), expectedSha), "DownloadedRevisionShaMismatch");
                    // Request disposal closes DownloadHandlerFile before the explicit
                    // durable flush. An unsupported/failed flush is a failed prepare.
                    await FlushFileAsync(temporary, token);
                    ExcludeFromBackup(temporary);
                    return;
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception error) { last = error; }
                finally { if (last != null && File.Exists(temporary)) File.Delete(temporary); }
            }
            throw new IOException("Revision file could not be downloaded and verified.", last);
        }
        private void DeleteTemporary(string path)
        {
            if (!string.IsNullOrEmpty(path) && Path.GetDirectoryName(path) == Path.Combine(root, "tmp") && File.Exists(path))
            { RejectReparse(path); File.Delete(path); }
        }
        private static void Require(bool value, string error) { if (!value) throw new InvalidDataException(error); }
    }
}
