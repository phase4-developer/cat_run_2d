using System;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;

namespace Artress.ManagedAddressables
{
    public sealed partial class ManagedAddressableRevisionSession
    {
        private ManagedRevisionApplication applicationContext;
        private ManagedRevisionPublisher applicationPublisher;

        /// <summary>
        /// Starts before Revision consumers. Chooses by trusted deployment metadata,
        /// then verifies availability. Only an empty namespace can install its first A.
        /// A missing pointer in a nonempty namespace remains ambiguous Boot recovery,
        /// except verified residue of this app's durable Copying marker. CommitStarted
        /// without a pointer always remains in Boot and returns a distinct reason code.
        /// The app owns its packaged trust anchor and Save compatibility release checks.
        /// Validation must release diagnostic handles; gameplay starts only after Success.
        /// </summary>
        public async Task<ManagedRevisionResult> OpenForApplicationAsync(IResourceLocator actualBootLocator,
            ManagedRevisionApplication application, ManagedRevisionApplyCallbacks callbacks,
            CancellationToken cancellationToken = default)
        {
            EnterOperation();
            ManagedRevisionFiles confirmed = null;
            CatalogLease candidate = null;
            bool began = false, tryingPackaged = false, commitInvoked = false;
            ManagedRevisionReasonCode reasonCode = ManagedRevisionReasonCode.None;
            ManagedRevisionCommitOutcome? outcome = null;
            try
            {
                if (application == null) throw new ArgumentNullException(nameof(application));
                if (callbacks == null) throw new ArgumentNullException(nameof(callbacks));
                BeginOwnedBoot(actualBootLocator, callbacks.ValidateRevision, cancellationToken);
                began = true;
                applicationContext = application;
                confirmed = await ownedStorage.ReadConfirmedMetadataAsync(cancellationToken);
                applicationPublisher = await ownedStorage.ReadPublisherAsync(application.PackagedRevision, cancellationToken);
                bool installPackaged = application.SelectPackaged(confirmed?.Publisher,
                    confirmed?.PublisherSha256, applicationPublisher);
                if (confirmed == null)
                {
                    reasonCode = await ownedStorage.BeginInitialInstallAsync(application.PackagedRevision, applicationPublisher, cancellationToken);
                    if (reasonCode != ManagedRevisionReasonCode.None) throw new InvalidOperationException("InitialInstallCommitRequiresManualRecovery");
                }
                LastConfirmedRevision = confirmed?.Revision;
                if (!installPackaged)
                {
                    await ownedStorage.VerifyAsync(confirmed, false, cancellationToken);
                    await ownedStorage.CleanupApplicationStartupAsync(confirmed, Array.Empty<string>(), cancellationToken);
                    LogStartupCleanupWarning();
                    candidate = await LoadOwnedCatalogAsync(confirmed, false, cancellationToken);
                    await RegisterStartupLeaseAsync(candidate, true, callbacks, cancellationToken);
                    candidate = null;
                    State = ManagedRevisionState.Ready;
                    revisionConsumersSuspended = false;
                    return new ManagedRevisionResult(true);
                }

                tryingPackaged = true;
                var files = await ownedStorage.PrepareCatalogAsync(application.PackagedRevision, cancellationToken);
                candidate = await LoadOwnedCatalogAsync(files, true, cancellationToken);
                // Preserve the old confirmation and the fully prepared candidate. If
                // the old files are unavailable, the existing conservative GC skips.
                if (confirmed != null)
                {
                    await ownedStorage.CleanupApplicationStartupAsync(confirmed, new[] { files.PublisherSha256 }, cancellationToken);
                    LogStartupCleanupWarning();
                }
                await RegisterStartupLeaseAsync(candidate, false, callbacks, cancellationToken);
                cancellationToken.ThrowIfCancellationRequested();
                commitInvoked = true;
                var commit = await ownedStorage.CommitConfirmedAsync(files, cancellationToken);
                outcome = commit.Outcome;
                if (outcome == ManagedRevisionCommitOutcome.Uncertain)
                    throw new InvalidOperationException("PackagedConfirmationUncertain:" + commit.Error);
                if (outcome != ManagedRevisionCommitOutcome.Confirmed)
                    throw new InvalidOperationException("PackagedConfirmationUnchanged:" + commit.Error);
                if (confirmed == null) LogStartupCleanupWarning();
                active = candidate;
                prepared = null;
                LastConfirmedRevision = candidate.Revision;
                candidate = null;
                State = ManagedRevisionState.Ready;
                revisionConsumersSuspended = false;
                return new ManagedRevisionResult(true, commitOutcome: outcome);
            }
            catch (Exception error)
            {
                if (!began) return new ManagedRevisionResult(false, error.ToString());
                if (outcome == ManagedRevisionCommitOutcome.Confirmed)
                    return FailAfterConfirmedCommit(candidate ?? active, error);
                revisionConsumersSuspended = true;
                State = ManagedRevisionState.RecoveryRequired;
                if (tryingPackaged && confirmed != null &&
                    confirmed.Publisher.compatibilityFamily == applicationPublisher.compatibilityFamily &&
                    (!commitInvoked || outcome == ManagedRevisionCommitOutcome.Unchanged))
                {
                    try
                    {
                        RequireBoundary(await callbacks.StopRevisionConsumers(CancellationToken.None));
                        RemoveStartupLease(candidate);
                        candidate = null;
                        var observed = await ownedStorage.ReadConfirmedMetadataAsync(CancellationToken.None);
                        if (observed == null || string.IsNullOrEmpty(confirmed.ConfirmedPointerSha256) ||
                            observed.ConfirmedPointerSha256 != confirmed.ConfirmedPointerSha256)
                            throw new InvalidOperationException("ConfirmationChangedDuringPackagedFailure");
                        await ownedStorage.VerifyAsync(confirmed, true, CancellationToken.None);
                        candidate = await LoadOwnedCatalogAsync(confirmed, false, CancellationToken.None);
                        await RegisterStartupLeaseAsync(candidate, true, callbacks, CancellationToken.None);
                        candidate = null;
                        LastConfirmedRevision = confirmed.Revision;
                        State = ManagedRevisionState.Ready;
                        revisionConsumersSuspended = false;
                        // A compatible older B is legal after A' failed. The next
                        // startup may retry A' based on metadata, never file loss.
                        return new ManagedRevisionResult(true, "PackagedRevisionNotApplied:" + error,
                            recovered: true, commitOutcome: outcome);
                    }
                    catch (Exception recovery) { error = new AggregateException(error, recovery); }
                }
                else if (!tryingPackaged && confirmed != null)
                    error = await RevalidateFailedOpenAsync(confirmed, error);
                if (active != null) Addressables.RemoveResourceLocator(active.Locator);
                if (prepared != null) Addressables.RemoveResourceLocator(prepared.Locator);
                if (reasonCode == ManagedRevisionReasonCode.None) reasonCode = ownedStorage?.InitialInstallRecoveryReason() ?? ManagedRevisionReasonCode.None;
                return new ManagedRevisionResult(false, error.ToString(), false, true, 0,
                    commitInvoked && !outcome.HasValue ? ManagedRevisionCommitOutcome.Uncertain : outcome, false, reasonCode);
            }
            finally
            {
                if (candidate != null && !ReferenceEquals(candidate, active) && !ReferenceEquals(candidate, prepared))
                    candidate.Release();
                busy = false;
            }
        }

        private void BeginOwnedBoot(IResourceLocator actualBootLocator,
            Func<ManagedAddressableRevision, CancellationToken, Task<bool>> validate, CancellationToken token)
        {
            if (State != ManagedRevisionState.Created) throw new InvalidOperationException("SessionAlreadyOpened");
            if (actualBootLocator == null || !IsRegistered(actualBootLocator))
                throw new InvalidOperationException("BootLocatorNotRegistered");
            if (validate == null) throw new ArgumentNullException(nameof(validate));
            if (owner != null && owner != this) throw new InvalidOperationException("AnotherRevisionSessionOwnsTheRegistry");
            token.ThrowIfCancellationRequested();
            ownedStorage ??= new ManagedAddressableRevisionStorage();
            owner = this;
            ownedFlow = true;
            revisionConsumersSuspended = true;
            bootLocator = actualBootLocator;
            State = ManagedRevisionState.Booting;
        }

        private async Task RegisterStartupLeaseAsync(CatalogLease lease, bool isConfirmed,
            ManagedRevisionApplyCallbacks callbacks, CancellationToken token)
        {
            RequireOwnedNoConflicts(lease);
            if (isConfirmed) active = lease; else prepared = lease;
            InstallOwnedTransform();
            if (!IsRegistered(bootLocator) || !ReferenceEquals(Addressables.InternalIdTransformFunc, ownedTransform))
                throw new InvalidOperationException("BootOrTransformChangedDuringApplicationStartup");
            Addressables.AddResourceLocator(lease.Locator);
            if (!await callbacks.ValidateRevision(lease.Revision, token))
                throw new InvalidOperationException(isConfirmed ? "ConfirmedRevisionValidationFailed" : "PackagedRevisionValidationFailed");
            token.ThrowIfCancellationRequested();
            if (!IsRegistered(lease.Locator) || !IsRegistered(bootLocator) ||
                !ReferenceEquals(Addressables.InternalIdTransformFunc, ownedTransform))
                throw new InvalidOperationException("OwnedRevisionRegistryChangedDuringApplicationValidation");
            RequireOwnedNoConflicts(lease);
        }

        private void RemoveStartupLease(CatalogLease lease)
        {
            if (lease == null) return;
            if (ownedTransform != null && !ReferenceEquals(Addressables.InternalIdTransformFunc, ownedTransform))
                throw new InvalidOperationException("RevisionTransformChangedOutsideSession");
            Addressables.RemoveResourceLocator(lease.Locator);
            if (ReferenceEquals(active, lease)) active = null;
            if (ReferenceEquals(prepared, lease)) prepared = null;
            lease.Release();
        }
    }
}
