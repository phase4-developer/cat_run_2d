using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.ResourceManagement.ResourceLocations;

[assembly: InternalsVisibleTo("Artress.ManagedAddressables.Editor")]
[assembly: InternalsVisibleTo("Artress.ManagedAddressables.Runtime.Tests")]

namespace Artress.ManagedAddressables
{
    /// <summary>
    /// The URL schemes the Revision path fetches: HTTPS always, plain http only with
    /// Allow Development HTTP in the Project Config. That is the one switch: the Editor
    /// reads the Config, and the Player build step ships this marker to development
    /// builds. A non-development Player refuses http whatever it ships.
    /// </summary>
    internal static class ManagedRevisionTransport
    {
        internal const string DevelopmentHttpMarkerFolder = "ArtressManagedRevisionHttp";
        internal const string DevelopmentHttpMarkerFile = "enabled";
        internal const string PlainHttpRefused = "Plain http needs Allow Development HTTP in the Project Config and a development build.";
        internal static bool? TestOverride;
#if !UNITY_EDITOR
        private static bool? markerPresent;
#endif

        // For logs and errors only. Stored and requested URLs stay byte-exact; a signed query is a credential.
        internal static string Displayed(Uri uri) => uri.GetComponents(UriComponents.SchemeAndServer | UriComponents.Path, UriFormat.UriEscaped);

        // UnityWebRequest.error is free-form text from the platform network stack, so it may quote the URL.
        internal static string WithoutQuery(string text) => string.IsNullOrEmpty(text) ? text : Regex.Replace(text, @"\?[^\s""'<>]*", string.Empty);

        internal static bool Allows(Uri uri) => uri.Scheme == Uri.UriSchemeHttps || (uri.Scheme == Uri.UriSchemeHttp && DevelopmentHttpAllowed());

        private static bool DevelopmentHttpAllowed()
        {
            if (TestOverride.HasValue) return TestOverride.Value;
#if UNITY_EDITOR
            // Same path as ManagedAddressableProjectConfig.DefaultAssetPath; Runtime cannot see the Editor type.
            var config = UnityEditor.AssetDatabase.LoadMainAssetAtPath("Assets/ArtressManagedAddressables/ManagedAddressableProjectConfig.asset");
            if (config == null) return false;
            using (var serialized = new UnityEditor.SerializedObject(config))
                return serialized.FindProperty("allowDevelopmentHttp")?.boolValue == true;
#else
            if (!Debug.isDebugBuild) return false;
            if (!markerPresent.HasValue) markerPresent = MarkerPresent();
            return markerPresent.Value;
#endif
        }

#if !UNITY_EDITOR
        private static bool MarkerPresent()
        {
#if UNITY_ANDROID
            // StreamingAssets live inside the APK, and this check must stay synchronous.
            using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
            using (var assets = activity.Call<AndroidJavaObject>("getAssets"))
            {
                try
                {
                    using (var stream = assets.Call<AndroidJavaObject>("open", DevelopmentHttpMarkerFolder + "/" + DevelopmentHttpMarkerFile)) stream.Call("close");
                    return true;
                }
                catch (AndroidJavaException) { return false; }
            }
#else
            return File.Exists(Path.Combine(Application.streamingAssetsPath, DevelopmentHttpMarkerFolder, DevelopmentHttpMarkerFile));
#endif
        }
#endif
    }

    /// <summary>
    /// Immutable revision metadata. A publisher SHA supplied by the trusted Revision API
    /// binds the publisher, catalog and bundle files; an SDK build hash is only optional
    /// metadata consistency checking. Production API trust/availability is caller-owned.
    /// Catalogs must come from the validated Boot/Revision split build route. Arbitrary
    /// catalogs bypassing its Address/GUID/Locale identity checks are not supported.
    /// </summary>
    public sealed class ManagedAddressableRevision
    {
        public string RevisionId { get; }
        public string CatalogPath { get; }
        public string ExpectedBuildResultHash { get; }
        public string PublisherPath { get; }
        public string ExpectedPublisherSha256 { get; }
        public string Target { get; }
        /// <summary>Explicit, read-only StreamingAssets bundle source for packaged installation; empty for remote revisions.</summary>
        public string PackagedBundleRoot { get; } = string.Empty;

        public bool HasTrustedPublisher => PublisherPath.Length != 0;

        internal ManagedAddressableRevision(string revisionId, string catalogPath, string expectedBuildResultHash = null)
            : this(revisionId, catalogPath, expectedBuildResultHash, false) { }

        private ManagedAddressableRevision(string revisionId, string catalogPath, string expectedBuildResultHash, bool packaged)
        {
            if (string.IsNullOrWhiteSpace(revisionId))
                throw new ArgumentException("A caller-confirmed revision ID is required.", nameof(revisionId));
            if (string.IsNullOrWhiteSpace(catalogPath) || !Uri.TryCreate(catalogPath, UriKind.Absolute, out Uri uri))
                throw new ArgumentException("An absolute, revision-pinned catalog path is required.", nameof(catalogPath));
            if (uri.Scheme != Uri.UriSchemeFile && !(packaged && uri.Scheme == "jar") && !ManagedRevisionTransport.Allows(uri))
                throw new ArgumentException("Only file and HTTPS catalog paths are supported. " + ManagedRevisionTransport.PlainHttpRefused, nameof(catalogPath));
            if (!uri.AbsolutePath.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Private revision preparation requires an SDK JSON catalog.", nameof(catalogPath));

            RevisionId = revisionId;
            CatalogPath = uri.IsFile ? Path.GetFullPath(uri.LocalPath) : uri.AbsoluteUri;
            ExpectedBuildResultHash = expectedBuildResultHash ?? string.Empty;
            PublisherPath = ExpectedPublisherSha256 = Target = string.Empty;
        }

        public ManagedAddressableRevision(string revisionId, string catalogPath, string publisherPath,
            string expectedPublisherSha256, string target, string expectedBuildResultHash = null)
            : this(revisionId, catalogPath, publisherPath, expectedPublisherSha256, target, expectedBuildResultHash, null) { }

        private ManagedAddressableRevision(string revisionId, string catalogPath, string publisherPath,
            string expectedPublisherSha256, string target, string expectedBuildResultHash, string packagedBundleRoot)
            : this(revisionId, catalogPath, expectedBuildResultHash, packagedBundleRoot != null)
        {
            if (!Uri.TryCreate(publisherPath, UriKind.Absolute, out Uri uri) ||
                (uri.Scheme != Uri.UriSchemeFile && !(packagedBundleRoot != null && uri.Scheme == "jar") && !ManagedRevisionTransport.Allows(uri)))
                throw new ArgumentException("An absolute publisher file or HTTPS path is required. " + ManagedRevisionTransport.PlainHttpRefused, nameof(publisherPath));
            if (expectedPublisherSha256 == null || expectedPublisherSha256.Length != 64)
                throw new ArgumentException("A trusted publisher SHA-256 is required.", nameof(expectedPublisherSha256));
            foreach (char character in expectedPublisherSha256)
                if (!Uri.IsHexDigit(character))
                    throw new ArgumentException("A trusted publisher SHA-256 is required.", nameof(expectedPublisherSha256));
            if (string.IsNullOrWhiteSpace(target)) throw new ArgumentException("A publisher target is required.", nameof(target));
            PublisherPath = uri.IsFile ? Path.GetFullPath(uri.LocalPath) : uri.AbsoluteUri;
            ExpectedPublisherSha256 = expectedPublisherSha256.ToLowerInvariant();
            Target = target;
            if (packagedBundleRoot != null)
            {
                if (!Uri.TryCreate(packagedBundleRoot, UriKind.Absolute, out Uri root) ||
                    (root.Scheme != Uri.UriSchemeFile && root.Scheme != "jar"))
                    throw new ArgumentException("An explicit StreamingAssets file/jar bundle root is required.", nameof(packagedBundleRoot));
                PackagedBundleRoot = root.AbsoluteUri.TrimEnd('/');
            }
        }

        /// <summary>
        /// The app supplies its trusted packaged publisher anchor. Storage additionally requires
        /// all three sources to be inside this app's StreamingAssets. Catalog bytes/SDK IDs are not patched.
        /// </summary>
        public static ManagedAddressableRevision CreatePackaged(string revisionId, string catalogPath, string publisherPath,
            string expectedPublisherSha256, string target, string packagedBundleRoot, string expectedBuildResultHash = null)
        {
            if (string.IsNullOrWhiteSpace(packagedBundleRoot)) throw new ArgumentNullException(nameof(packagedBundleRoot));
            return new ManagedAddressableRevision(revisionId, catalogPath, publisherPath, expectedPublisherSha256,
                target, expectedBuildResultHash, packagedBundleRoot);
        }
    }

    /// <summary>
    /// Trusted application deployment scope and its immutable packaged default. The
    /// deployment authority assigns sequences to app and remote revisions alike.
    /// This is not a Save compatibility check or a remote signature/trust service.
    /// </summary>
    public sealed class ManagedRevisionApplication
    {
        public string ProductId { get; }
        public string Channel { get; }
        public string AuthorityId { get; }
        public ManagedAddressableRevision PackagedRevision { get; }

        public ManagedRevisionApplication(string productId, string channel, string authorityId,
            ManagedAddressableRevision packagedRevision)
        {
            if (string.IsNullOrWhiteSpace(productId) || string.IsNullOrWhiteSpace(channel) || string.IsNullOrWhiteSpace(authorityId))
                throw new ArgumentException("Trusted product, channel and deployment authority are required.");
            if (packagedRevision == null || !packagedRevision.HasTrustedPublisher || packagedRevision.PackagedBundleRoot.Length == 0)
                throw new ArgumentException("An anchored packaged Revision is required.", nameof(packagedRevision));
            ProductId = productId; Channel = channel; AuthorityId = authorityId; PackagedRevision = packagedRevision;
        }

        internal void RequireScope(ManagedRevisionPublisher publisher)
        {
            if (publisher == null || string.IsNullOrWhiteSpace(publisher.compatibilityFamily) || publisher.deploymentSequence <= 0 ||
                publisher.productId != ProductId || publisher.channel != Channel || publisher.authorityId != AuthorityId ||
                publisher.target != PackagedRevision.Target)
                throw new InvalidOperationException("RevisionDeploymentMetadataMissingOrScopeMismatch");
        }

        internal bool SelectPackaged(ManagedRevisionPublisher confirmed, string confirmedPublisherSha,
            ManagedRevisionPublisher packaged)
        {
            RequireScope(packaged);
            if (confirmed == null) return true;
            RequireScope(confirmed);
            if (confirmed.compatibilityFamily != packaged.compatibilityFamily) return true;
            if (confirmed.deploymentSequence != packaged.deploymentSequence)
                return packaged.deploymentSequence > confirmed.deploymentSequence;
            if (!string.Equals(confirmedPublisherSha, PackagedRevision.ExpectedPublisherSha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("AmbiguousEqualDeploymentSequence");
            return false;
        }

        internal void RequireRemoteCandidate(ManagedRevisionPublisher candidate, ManagedRevisionPublisher confirmed,
            ManagedRevisionPublisher packaged)
        {
            RequireScope(candidate); RequireScope(confirmed); RequireScope(packaged);
            if (candidate.compatibilityFamily != packaged.compatibilityFamily ||
                candidate.deploymentSequence <= Math.Max(confirmed.deploymentSequence, packaged.deploymentSequence))
                throw new InvalidOperationException("RevisionCandidateMustAdvanceCurrentApplicationDeployment");
        }
    }

    /// <summary>
    /// Caller evidence for Revision-owned leases, instances, scenes and direct SDK
    /// operations only. Boot/Localization owners may remain alive. Reuse their existing
    /// owners' release/unload methods; this session does not count or release them.
    /// UnloadCompleted means actual completion, not a frame delay. Unreported consumers
    /// cannot be discovered by this assertion.
    /// </summary>
    public sealed class ManagedRevisionBoundary
    {
        public int OwnedHandles { get; }
        public int OwnedInstances { get; }
        public int OwnedScenes { get; }
        public int OwnedInFlightOperations { get; }
        public bool UnloadCompleted { get; }
        public string Evidence { get; }

        public bool IsReady => OwnedHandles == 0 && OwnedInstances == 0 && OwnedScenes == 0 &&
            OwnedInFlightOperations == 0 && UnloadCompleted && !string.IsNullOrWhiteSpace(Evidence);

        public ManagedRevisionBoundary(int ownedHandles, int ownedInstances, int ownedScenes,
            int ownedInFlightOperations, bool unloadCompleted, string evidence)
        {
            if (ownedHandles < 0 || ownedInstances < 0 || ownedScenes < 0 || ownedInFlightOperations < 0)
                throw new ArgumentOutOfRangeException(nameof(ownedHandles), "Owner counts cannot be negative.");
            OwnedHandles = ownedHandles;
            OwnedInstances = ownedInstances;
            OwnedScenes = ownedScenes;
            OwnedInFlightOperations = ownedInFlightOperations;
            UnloadCompleted = unloadCompleted;
            Evidence = evidence ?? string.Empty;
        }
    }

    public enum ManagedRevisionState
    {
        Created,
        Booting,
        Ready,
        Preparing,
        Prepared,
        Applying,
        RecoveryRequired,
        Closed
    }

    /// <summary>Validation runs in the loading boundary and must not resume gameplay.</summary>
    public sealed class ManagedRevisionApplyCallbacks
    {
        public Func<CancellationToken, Task<ManagedRevisionBoundary>> StopRevisionConsumers { get; }
        public Func<ManagedAddressableRevision, CancellationToken, Task<bool>> ValidateRevision { get; }

        public ManagedRevisionApplyCallbacks(Func<CancellationToken, Task<ManagedRevisionBoundary>> stopRevisionConsumers,
            Func<ManagedAddressableRevision, CancellationToken, Task<bool>> validateRevision)
        {
            StopRevisionConsumers = stopRevisionConsumers ?? throw new ArgumentNullException(nameof(stopRevisionConsumers));
            ValidateRevision = validateRevision ?? throw new ArgumentNullException(nameof(validateRevision));
        }
    }

    public enum ManagedRevisionCommitOutcome { Confirmed, Unchanged, Uncertain }

    public enum ManagedRevisionReasonCode
    {
        None = 0,
        /// <summary>The first-install commit window was entered but no readable confirmation exists. Remain in Boot; never auto-reset.</summary>
        InitialInstallCommitStartedWithoutPointer = 1
    }

    /// <summary>Publisher schema 1. SDKHash/CRC are SDK identity metadata, not file SHA-256.</summary>
    [Serializable]
    public sealed class ManagedRevisionPublisherBundle
    {
        public string fileName, fileSha256, sdkBundleName, sdkHash;
        public long bytes;
        public uint crc;
    }

    [Serializable]
    public sealed class ManagedRevisionPublisher
    {
        public int schemaVersion = 1;
        public string revisionId, target, catalogFile, catalogSha256;
        public string productId, channel, authorityId, compatibilityFamily;
        public long deploymentSequence;
        public long catalogBytes;
        public ManagedRevisionPublisherBundle[] bundles;
    }

    // Session/Storage transfer objects are assembly-private. They do not own SDK handles,
    // register locators, or implement a second ownership/refcount system.
    internal sealed class ManagedRevisionFiles
    {
        public ManagedAddressableRevision Revision;
        public ManagedRevisionPublisher Publisher;
        public string PublisherSha256, CatalogLocalPath, MetadataDirectory;
        public ManagedRevisionBundleBinding[] Bindings = Array.Empty<ManagedRevisionBundleBinding>();
        public string ConfirmedPointerSha256;
        // Set only by the same-anchor recovery path; ordinary Prepare cannot replace
        // a file referenced by the confirmed pointer.
        internal bool RepairConfirmed;
    }

    internal sealed class ManagedRevisionBundleBinding
    {
        public IResourceLocation Location;
        public string CanonicalUri, LocalPath;
        public ManagedRevisionPublisherBundle Bundle;
    }

    internal sealed class ManagedRevisionCommitResult
    {
        public ManagedRevisionCommitOutcome Outcome;
        public string Error;
    }

    public sealed class ManagedRevisionResult
    {
        public bool Success { get; }
        public bool RecoveredLastConfirmed { get; }
        public bool RecoveryRequired { get; }
        /// <summary>Apply was postponed before locator/confirmation replacement. Resume A or retry at a safe boundary.</summary>
        public bool Deferred { get; }
        public ManagedRevisionReasonCode ReasonCode { get; }
        /// <summary>Exact loaded names which caused bundle-residue deferral. Empty for a caller boundary deferral.</summary>
        public IReadOnlyList<string> RemainingBundleNames { get; } = Array.Empty<string>();
        public string Error { get; }
        public long DownloadedBytes { get; }
        /// <summary>Null when no commit was attempted, including loading an existing confirmed pointer.</summary>
        public ManagedRevisionCommitOutcome? CommitOutcome { get; }

        internal ManagedRevisionResult(bool success, string error = null, bool recovered = false,
            bool recoveryRequired = false, long downloadedBytes = 0, ManagedRevisionCommitOutcome? commitOutcome = null)
            : this(success, error, recovered, recoveryRequired, downloadedBytes, commitOutcome, false) { }

        internal ManagedRevisionResult(bool success, string error, bool recovered,
            bool recoveryRequired, long downloadedBytes, ManagedRevisionCommitOutcome? commitOutcome, bool deferred)
            : this(success, error, recovered, recoveryRequired, downloadedBytes, commitOutcome, deferred, ManagedRevisionReasonCode.None) { }

        internal ManagedRevisionResult(bool success, string error, bool recovered,
            bool recoveryRequired, long downloadedBytes, ManagedRevisionCommitOutcome? commitOutcome, bool deferred, ManagedRevisionReasonCode reasonCode)
        {
            Success = success;
            Error = error ?? string.Empty;
            RecoveredLastConfirmed = recovered;
            RecoveryRequired = recoveryRequired;
            DownloadedBytes = downloadedBytes;
            CommitOutcome = commitOutcome;
            Deferred = deferred;
            ReasonCode = reasonCode;
        }

        internal ManagedRevisionResult(string[] remainingBundleNames)
            : this(false, "RevisionBundlesStillLoaded:" + string.Join(",", remainingBundleNames), false, false, 0, null, true, ManagedRevisionReasonCode.None)
        {
            RemainingBundleNames = Array.AsReadOnly((string[])remainingBundleNames.Clone());
        }
    }
}
