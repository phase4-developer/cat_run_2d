using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Networking;

namespace Artress.ManagedAddressables
{
    public sealed partial class ManagedAddressableRevisionStorage
    {
        private string InitialInstallPath => Path.Combine(root, "initial-install.json");
        [Serializable] private sealed class InitialInstall { public int schemaVersion; public string publisherSha256, phase; }

        // This single, user-approved marker is not a confirmation or journal. It is
        // created before any payload write in an empty namespace (known tmp/t-*.tmp
        // leftovers of an unpublished write are the only user-approved exception).
        internal Task<ManagedRevisionReasonCode> BeginInitialInstallAsync(ManagedAddressableRevision packaged, ManagedRevisionPublisher publisher, CancellationToken token)
        {
            Enter();
            try
            {
                token.ThrowIfCancellationRequested(); ValidatePackagedSources(packaged);
                Require(!File.Exists(PointerPath), "FirstInstallRequiresMissingPointer");
                string[] inventory = OwnedLeafFiles(root, token).ToArray();
                if (!File.Exists(InitialInstallPath))
                {
                    Require(inventory.All(IsInitialInstallTemporary), "ConfirmedPointerMissingInNonEmptyStore");
                    string temporary = NewTemporary();
                    try
                    {
                        WriteImmutable(temporary, Encoding.UTF8.GetBytes(JsonUtility.ToJson(new InitialInstall { schemaVersion = 1, publisherSha256 = packaged.ExpectedPublisherSha256, phase = "Copying" })));
                        File.Move(temporary, InitialInstallPath); ExcludeFromBackup(InitialInstallPath);
                    }
                    finally { DeleteTemporary(temporary); }
                    return Task.FromResult(ManagedRevisionReasonCode.None);
                }
                var marker = JsonUtility.FromJson<InitialInstall>(File.ReadAllText(InitialInstallPath));
                Require(marker != null && marker.schemaVersion == 1 && IsSha(marker.publisherSha256) &&
                    (marker.phase == "Copying" || marker.phase == "CommitStarted"), "InitialInstallMarkerMalformed");
                if (marker.phase == "CommitStarted") return Task.FromResult(ManagedRevisionReasonCode.InitialInstallCommitStartedWithoutPointer);
                Require(SameSha(marker.publisherSha256, packaged.ExpectedPublisherSha256), "InitialInstallMarkerDoesNotMatchPackagedA");
                string metadata = MetadataDirectory(packaged.ExpectedPublisherSha256);
                string storedPublisher = Path.Combine(metadata, "publisher.json");
                ManagedRevisionPublisher observed = null;
                if (File.Exists(storedPublisher))
                {
                    byte[] bytes = File.ReadAllBytes(storedPublisher);
                    Require(SameSha(Sha(bytes), packaged.ExpectedPublisherSha256), "InitialInstallPublisherUntrusted");
                    observed = ParsePublisher(bytes, packaged.RevisionId);
                    Require(JsonUtility.ToJson(observed) == JsonUtility.ToJson(publisher), "InitialInstallPublisherChanged");
                }
                var allowedBlobs = new HashSet<string>(observed == null ? Array.Empty<string>() : observed.bundles.Select(row => BlobPath(row.fileSha256)), StringComparer.Ordinal);
                foreach (string file in inventory)
                {
                    bool meta = Path.GetDirectoryName(file) == metadata && (Path.GetFileName(file) == "catalog.json" || Path.GetFileName(file) == "publisher.json");
                    bool temporary = IsInitialInstallTemporary(file);
                    Require(file == InitialInstallPath || meta || temporary || allowedBlobs.Contains(file), "InitialInstallResidueAmbiguous");
                }
                // Only the three owned trees, after validating EVERY leaf. Keep the
                // durable marker until exact confirmation ACK (including on failure).
                // Keep the publisher while ANY blob remains, including if resetting
                // Copying itself is interrupted. Otherwise the next retry is ambiguous.
                foreach (string tree in new[] { "blobs", "tmp", "revisions" })
                    foreach (string file in inventory.Where(f => f.StartsWith(Path.Combine(root, tree) + Path.DirectorySeparatorChar, StringComparison.Ordinal)))
                    { token.ThrowIfCancellationRequested(); File.Delete(file); }
                known.Clear();
                return Task.FromResult(ManagedRevisionReasonCode.None);
            }
            finally { busy = false; }
        }

        // The user-approved empty-store exception is only a direct tmp/t-*.tmp leaf.
        // RejectReparse is applied by both inventory callers before this classification.
        private bool IsInitialInstallTemporary(string file)
        {
            string name = Path.GetFileName(file);
            return Path.GetDirectoryName(file) == Path.Combine(root, "tmp") &&
                name.StartsWith("t-", StringComparison.Ordinal) && name.EndsWith(".tmp", StringComparison.Ordinal);
        }

        private static IEnumerable<string> OwnedLeafFiles(string start, CancellationToken token)
        {
            var pending = new Stack<string>(); pending.Push(start);
            while (pending.Count != 0)
            {
                token.ThrowIfCancellationRequested(); string directory = pending.Pop(); RejectReparse(directory);
                foreach (string file in Directory.GetFiles(directory)) { RejectReparse(file); yield return file; }
                foreach (string child in Directory.GetDirectories(directory)) { RejectReparse(child); pending.Push(child); }
            }
        }

        private void RemoveInitialInstallMarker()
        {
            try { RejectReparse(InitialInstallPath); if (File.Exists(InitialInstallPath)) File.Delete(InitialInstallPath); }
            catch (Exception error) { LastCleanupWarning = "Initial install marker cleanup: " + error; }
        }

        private void MarkInitialInstallCommitStarted(string publisherSha)
        {
            RejectReparse(InitialInstallPath);
            if (!File.Exists(InitialInstallPath)) return; // Only the first install has a marker.
            var marker = JsonUtility.FromJson<InitialInstall>(File.ReadAllText(InitialInstallPath));
            Require(marker != null && marker.schemaVersion == 1 && marker.phase == "Copying" && SameSha(marker.publisherSha256, publisherSha), "InitialInstallCommitMarkerInvalid");
            marker.phase = "CommitStarted";
            byte[] desired = Encoding.UTF8.GetBytes(JsonUtility.ToJson(marker)); string temporary = NewTemporary();
            try
            {
                WriteImmutable(temporary, desired); // Flush(true), before pointer replacement starts.
                File.Replace(temporary, InitialInstallPath, null); ExcludeFromBackup(InitialInstallPath);
                Require(Equal(File.ReadAllBytes(InitialInstallPath), desired), "InitialInstallCommitMarkerReadbackMismatch");
            }
            finally { DeleteTemporary(temporary); }
        }

        internal ManagedRevisionReasonCode InitialInstallRecoveryReason()
        {
            try
            {
                if (File.Exists(PointerPath) || !File.Exists(InitialInstallPath)) return ManagedRevisionReasonCode.None;
                RejectReparse(InitialInstallPath);
                var marker = JsonUtility.FromJson<InitialInstall>(File.ReadAllText(InitialInstallPath));
                return marker != null && marker.schemaVersion == 1 && IsSha(marker.publisherSha256) && marker.phase == "CommitStarted"
                    ? ManagedRevisionReasonCode.InitialInstallCommitStartedWithoutPointer : ManagedRevisionReasonCode.None;
            }
            catch { return ManagedRevisionReasonCode.None; } // Preserve the primary malformed/unreadable-file failure.
        }

        private static string PackagedBundleSource(string bundleRoot, string fileName)
            => PackagedSourcePath(bundleRoot).TrimEnd('/', '\\') + (bundleRoot.StartsWith("jar:", StringComparison.Ordinal) ? "/" + Uri.EscapeDataString(fileName) : Path.DirectorySeparatorChar + fileName);

        private static string PackagedSourcePath(string packagedPath)
        {
            string streaming = Application.streamingAssetsPath.TrimEnd('/', '\\');
            if (Uri.TryCreate(packagedPath, UriKind.Absolute, out var source) && source.Scheme == "jar")
            {
                Require(Application.platform == RuntimePlatform.Android && packagedPath.StartsWith(streaming + "/", StringComparison.Ordinal) &&
                    !packagedPath.Split('/').Any(part => Uri.UnescapeDataString(part) == ".."), "PackagedSourceMustBeApplicationStreamingAssets");
                return packagedPath;
            }
            Require(source == null || source.IsFile, "PackagedSourceMustBeApplicationStreamingAssets");
            string path = source != null && source.IsFile ? source.LocalPath : packagedPath;
            string absolute = Path.GetFullPath(path).TrimEnd('/', '\\');
            string expected = Path.GetFullPath(streaming).TrimEnd('/', '\\') + Path.DirectorySeparatorChar;
            var comparison = Application.platform == RuntimePlatform.WindowsEditor || Application.platform == RuntimePlatform.WindowsPlayer ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
            Require(absolute.StartsWith(expected, comparison), "PackagedSourceMustBeApplicationStreamingAssets");
            RejectReparse(absolute);
            return absolute;
        }

        private static void ValidatePackagedSources(ManagedAddressableRevision revision)
        {
            if (string.IsNullOrEmpty(revision.PackagedBundleRoot)) return;
            PackagedSourcePath(revision.CatalogPath); PackagedSourcePath(revision.PublisherPath); PackagedSourcePath(revision.PackagedBundleRoot);
        }
        // Read the small, explicitly anchored publisher before choosing A'/B. This does
        // not copy a Catalog, create a revision directory, or change confirmation.
        internal async Task<ManagedRevisionPublisher> ReadPublisherAsync(ManagedAddressableRevision revision, CancellationToken token)
        {
            Enter();
            try
            {
                Require(revision != null && revision.Target == target && IsSha(revision.ExpectedPublisherSha256) &&
                    !string.IsNullOrWhiteSpace(revision.PublisherPath), "TrustedRevisionPublisherAnchorRequired");
                ValidatePackagedSources(revision);
                byte[] bytes = await ReadPublisherBytesAsync(revision.PublisherPath, token);
                Require(SameSha(await ShaBytesAsync(bytes, token), revision.ExpectedPublisherSha256), "PublisherShaMismatch");
                return ParsePublisher(bytes, revision.RevisionId);
            }
            finally { busy = false; }
        }

        // Selection must remain possible with no free disk space. A publisher is
        // small trusted metadata, so reading it must not create a download file.
        private async Task<byte[]> ReadPublisherBytesAsync(string path, CancellationToken token)
        {
            if (!Uri.TryCreate(path, UriKind.Absolute, out var source) || source.IsFile)
            { token.ThrowIfCancellationRequested(); return File.ReadAllBytes(source != null && source.IsFile ? source.LocalPath : path); }
            bool jar = source.Scheme == "jar" && Application.platform == RuntimePlatform.Android && path.StartsWith(Application.streamingAssetsPath.TrimEnd('/') + "/", StringComparison.Ordinal);
            Require(ManagedRevisionTransport.Allows(source) || jar, "UnsupportedPublisherReadScheme: " + ManagedRevisionTransport.PlainHttpRefused);
            Exception last = null;
            for (int attempt = 0; attempt <= retries; attempt++)
            {
                token.ThrowIfCancellationRequested();
                try
                {
                    using (var request = UnityWebRequest.Get(source.AbsoluteUri))
                    {
                        Addressables.ResourceManager.WebRequestOverride?.Invoke(request);
                        var operation = request.SendWebRequest(); ulong lastBytes = 0; float progress = Time.realtimeSinceStartup;
                        while (!operation.isDone)
                        {
                            if (token.IsCancellationRequested) { request.Abort(); while (!operation.isDone) await Task.Yield(); token.ThrowIfCancellationRequested(); }
                            if (request.downloadedBytes != lastBytes) { lastBytes = request.downloadedBytes; progress = Time.realtimeSinceStartup; }
                            else if (stallTimeout > 0 && Time.realtimeSinceStartup - progress >= stallTimeout)
                            { request.Abort(); while (!operation.isDone) await Task.Yield(); throw new TimeoutException("Publisher read stalled."); }
                            await Task.Yield();
                        }
                        Require(request.result == UnityWebRequest.Result.Success, "PublisherReadFailed: " + ManagedRevisionTransport.WithoutQuery(request.error));
                        token.ThrowIfCancellationRequested(); return request.downloadHandler.data;
                    }
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception error) { last = error; }
            }
            throw new IOException("Publisher could not be read.", last);
        }

        // A missing pointer with any non-temporary leaf is ambiguous. Only direct
        // tmp/t-*.tmp leaves may precede the first atomically published marker.
        internal Task<bool> IsEmptyForFirstInstallAsync(CancellationToken token)
        {
            Enter();
            try
            {
                token.ThrowIfCancellationRequested();
                var pending = new Stack<string>(); pending.Push(root);
                while (pending.Count != 0)
                {
                    token.ThrowIfCancellationRequested(); string directory = pending.Pop(); RejectReparse(directory);
                    foreach (string file in Directory.EnumerateFiles(directory, "*", SearchOption.TopDirectoryOnly))
                    { RejectReparse(file); if (!IsInitialInstallTemporary(file)) return Task.FromResult(false); }
                    foreach (string child in Directory.EnumerateDirectories(directory, "*", SearchOption.TopDirectoryOnly))
                    { RejectReparse(child); pending.Push(child); }
                }
                return Task.FromResult(true);
            }
            finally { busy = false; }
        }
    }
}
