using Artress.ManagedAddressables;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

namespace Artress.ManagedAddressables.Editor
{
    // What Allow Development HTTP changed in Player Settings for one build. Null means left as it was.
    internal sealed class ManagedDevelopmentHttpChange
    {
        public InsecureHttpOption? insecureHttpBefore;

        internal static ManagedDevelopmentHttpChange Capture() => new ManagedDevelopmentHttpChange
        {
            insecureHttpBefore = PlayerSettings.insecureHttpOption == InsecureHttpOption.NotAllowed ? InsecureHttpOption.NotAllowed : (InsecureHttpOption?)null
        };

        internal void Apply()
        {
            if (insecureHttpBefore.HasValue) PlayerSettings.insecureHttpOption = InsecureHttpOption.DevelopmentOnly;
        }

        internal void Restore()
        {
            if (insecureHttpBefore.HasValue) PlayerSettings.insecureHttpOption = insecureHttpBefore.Value;
        }
    }

    internal static partial class ManagedAddressableBuildExporter
    {
        private sealed class PlayerLinkSnapshot
        {
            public string path;
            public byte[] bytes;
            public byte[] meta;
            public string bootReceiptPath;
            public bool sdkStageVerified;
            public string packagedRevisionSha256;
            public ManagedDevelopmentHttpChange developmentHttp;
        }
        private static PlayerLinkSnapshot pendingPlayerLink;
        private static string PendingPlayerPath => Path.Combine("Library", "ArtressManagedAddressablesSplit", "pending_player_link.json");

        internal static void PrepareSplitPlayerBuild(ManagedAddressableProjectConfig config, BuildPlayerContext context)
        {
            if (context == null) throw new BuildFailedException("Split Boot automatic creation requires the official BuildPlayerContext.");
            RequireDevelopmentHttpOnlyInDevelopmentBuilds(config, context.BuildPlayerOptions.options);
            RequireNoPendingSplitSettings();
            ValidateSplitPlayerScenes(context.BuildPlayerOptions.scenes);
            RequirePackagedRevisionLink(config);
            if (File.Exists(PendingPlayerPath)) throw new BuildFailedException("An interrupted Split Player build has pending SDK link.xml restoration. Use Restore Interrupted Player Build Metadata before retrying; no new build was started.");
            var report = ValidateSplitBuild(config, ManagedGroupBuildRole.Boot);
            if (!report.CanBuild) throw new BuildFailedException(report.ToString());
            var settings = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration();
            string path = (settings.ConfigFolder + "/link.xml").Replace('\\', '/');
            if (!path.StartsWith("Assets/", StringComparison.Ordinal)) throw new BuildFailedException("SDK Player link.xml must be a restorable Assets path: " + path);
            // SDK order1 imports link.xml. Its postprocessor's FindAssetEntry reads this
            // derived cache without saving or marking authoring data dirty. Evaluate it
            // before the first plan/scope capture so the same SDK read cannot stale Boot.
            // Standalone Preview/Sync paths retain their existing behavior.
            _ = settings.currentHash;
            string configPath = AssetDatabase.GetAssetPath(config);
            var result = BuildSplitContent(config, ManagedGroupBuildRole.Boot, context);
            if (!result.success) throw new BuildFailedException(result.error);
            config = ReloadSplitConfigAfterSdk(configPath);
            string packagedSha = PreparePackagedRevisionForPlayer(config, context, result.splitReceiptPath);
            pendingPlayerLink = new PlayerLinkSnapshot { path = path, bytes = File.Exists(path) ? File.ReadAllBytes(path) : null,
                meta = File.Exists(path + ".meta") ? File.ReadAllBytes(path + ".meta") : null, bootReceiptPath = result.splitReceiptPath, packagedRevisionSha256 = packagedSha,
                developmentHttp = config.allowDevelopmentHttp ? ManagedDevelopmentHttpChange.Capture() : null };
            // This is a bounded cleanup for this one synchronous build, including failed builds
            // where Unity does not call IPostprocessBuildWithReport. No global SDK watcher is added.
            // Registered first, so a failure in any step below still restores.
            EditorApplication.delayCall += FinishSplitPackagingWhenIdle;
            // Recorded before it is applied, so an interrupted build can always put it back.
            WriteSplitJson(PendingPlayerPath, pendingPlayerLink);
            if (pendingPlayerLink.developmentHttp != null)
            {
                context.AddAdditionalPathToStreamingAssets(WriteDevelopmentHttpMarker(), ManagedRevisionTransport.DevelopmentHttpMarkerFolder);
                pendingPlayerLink.developmentHttp.Apply();
            }
        }

        internal static void RequireDevelopmentHttpOnlyInDevelopmentBuilds(ManagedAddressableProjectConfig config, BuildOptions options)
        {
            if (config.allowDevelopmentHttp && (options & BuildOptions.Development) == 0)
                throw new BuildFailedException("Allow Development HTTP is on and this is a release build. Turn it off in the Project Config, or make a Development Build. Release Players never use plain http.");
        }

        private static string WriteDevelopmentHttpMarker()
        {
            string directory = Path.GetFullPath(Path.Combine("Library", "ArtressManagedAddressablesSplit", ManagedRevisionTransport.DevelopmentHttpMarkerFolder));
            Directory.CreateDirectory(directory);
            File.WriteAllText(Path.Combine(directory, ManagedRevisionTransport.DevelopmentHttpMarkerFile), string.Empty);
            return directory;
        }

        // SDK builders may unload unused editor assets, and a caller's stack reference does not keep a persistent asset loaded.
        internal static ManagedAddressableProjectConfig ReloadSplitConfigAfterSdk(string configPath)
        {
            var config = string.IsNullOrEmpty(configPath) ? null : AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(configPath);
            if (config == null) throw new BuildFailedException("Project Config could not be reloaded after the Boot SDK build: " + configPath);
            return config;
        }

        internal static void ValidateSplitPlayerScenes(IEnumerable<string> actualScenes)
        {
            string Normalize(string path) => string.IsNullOrWhiteSpace(path) ? "<empty>" : Path.GetFullPath(path.Trim()).Replace('\\', '/');
            var actual = (actualScenes ?? Enumerable.Empty<string>()).Select(Normalize).ToArray();
            var validated = EditorBuildSettings.scenes.Where(scene => scene.enabled).Select(scene => Normalize(scene.path)).ToArray();
            var comparer = UnityEngine.Application.platform == UnityEngine.RuntimePlatform.WindowsEditor ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal;
            if (!actual.SequenceEqual(validated, comparer))
                throw new BuildFailedException("BootstrapSplit Player Scene 입력이 콘텐츠 검증에 사용한 enabled EditorBuildSettings Scene 목록과 다릅니다. 현재는 같은 Scene 목록과 순서의 공식 Player Build를 지원합니다. 활성 Scene 입력을 확인하고 다시 빌드하세요. SDK Boot 제작은 시작하지 않았습니다.\nValidated: " + string.Join(" | ", validated) + "\nActual: " + string.Join(" | ", actual));
        }

        internal static void VerifySplitPlayerBuild(ManagedAddressableProjectConfig config)
        {
            try
            {
                if (pendingPlayerLink == null) throw new BuildFailedException("Split Player order0 Boot preparation did not run in this build context.");
                var report = ValidatePlayerStaging(config);
                if (!report.CanBuild) throw new BuildFailedException(report.ToString());
                if (!string.IsNullOrEmpty(pendingPlayerLink.packagedRevisionSha256) &&
                    ValidatePackagedRevision(config.packagedRevisionMetadataPath, config.packagedRevisionMetadataSha256) != pendingPlayerLink.packagedRevisionSha256)
                    throw new BuildFailedException("Packaged Revision changed during this Player build.");
                string packagedCompatibility = string.IsNullOrEmpty(pendingPlayerLink.packagedRevisionSha256) ? null :
                    ValidatePackagedRevisionAgainstBoot(config, pendingPlayerLink.bootReceiptPath);
                pendingPlayerLink.sdkStageVerified = true;
                WriteSplitJson(PendingPlayerPath, pendingPlayerLink);
                WriteSplitJson(Path.Combine(Path.GetDirectoryName(pendingPlayerLink.bootReceiptPath), "player_packaging_receipt.json"), new
                {
                    schemaVersion = 1, mode = "BootstrapSplit", bootReceiptPath = pendingPlayerLink.bootReceiptPath,
                    bootReceiptSha256 = SplitFileHash(pendingPlayerLink.bootReceiptPath), sdkOrder1StageVerified = true,
                    sdkPlayerSetting = "DoNotBuildWithPlayer", editorOnlyMetadata = true,
                    packagedRevisionSha256 = pendingPlayerLink.packagedRevisionSha256,
                    packagedRevisionStreamingRoot = string.IsNullOrEmpty(pendingPlayerLink.packagedRevisionSha256) ? null : PackagedRevisionStreamingRoot,
                    packagedBootCompatibility = packagedCompatibility
                });
            }
            catch { RestoreInterruptedPlayerBuildMetadata(); throw; }
        }

        private static void FinishSplitPackagingWhenIdle()
        {
            if (BuildPipeline.isBuildingPlayer) { EditorApplication.delayCall += FinishSplitPackagingWhenIdle; return; }
            if (pendingPlayerLink != null) RestoreInterruptedPlayerBuildMetadata();
        }

        internal static void FinishSplitPlayerBuild(BuildReport report)
        {
            if (pendingPlayerLink == null) return;
#if UNITY_IOS
            if (pendingPlayerLink.developmentHttp != null && report.summary.platform == BuildTarget.iOS) AllowIosHttp(Path.Combine(report.summary.outputPath, "Info.plist"));
#endif
            string receipt = Path.Combine(Path.GetDirectoryName(pendingPlayerLink.bootReceiptPath), "player_build_result.json");
            WriteSplitJson(receipt, new { result = report.summary.result.ToString(), outputPath = report.summary.outputPath,
                platform = report.summary.platform.ToString(), errors = report.summary.totalErrors, sdkStageVerified = pendingPlayerLink.sdkStageVerified });
            RestoreInterruptedPlayerBuildMetadata();
        }

#if UNITY_IOS
        // The ATS exception lives in the generated Xcode project, so nothing in the Unity project needs restoring.
        private static void AllowIosHttp(string infoPlist)
        {
            if (!File.Exists(infoPlist)) return;
            var plist = new UnityEditor.iOS.Xcode.PlistDocument();
            plist.ReadFromFile(infoPlist);
            var transport = plist.root.values.TryGetValue("NSAppTransportSecurity", out var existing) ? existing.AsDict() : plist.root.CreateDict("NSAppTransportSecurity");
            transport.SetBoolean("NSAllowsArbitraryLoads", true);
            plist.WriteToFile(infoPlist);
        }
#endif

        public static void RestoreInterruptedPlayerBuildMetadata()
        {
            var snapshot = pendingPlayerLink ?? (File.Exists(PendingPlayerPath) ? JsonConvert.DeserializeObject<PlayerLinkSnapshot>(File.ReadAllText(PendingPlayerPath)) : null);
            if (snapshot == null) return;
            snapshot.developmentHttp?.Restore();
            var settings = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration();
            string expected = settings == null ? "" : (settings.ConfigFolder + "/link.xml").Replace('\\', '/');
            if (snapshot.path != expected || !snapshot.path.StartsWith("Assets/", StringComparison.Ordinal)) throw new InvalidOperationException("Pending metadata target differs from the active SDK Settings; restore it using its original owner.");
            if (snapshot.bytes == null) { if (File.Exists(snapshot.path)) File.Delete(snapshot.path); }
            else File.WriteAllBytes(snapshot.path, snapshot.bytes);
            if (snapshot.meta == null) { if (File.Exists(snapshot.path + ".meta")) File.Delete(snapshot.path + ".meta"); }
            else File.WriteAllBytes(snapshot.path + ".meta", snapshot.meta);
            if (snapshot.bytes != null) AssetDatabase.ImportAsset(snapshot.path, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
            if ((snapshot.bytes == null ? File.Exists(snapshot.path) : !File.ReadAllBytes(snapshot.path).AsSpan().SequenceEqual(snapshot.bytes)) ||
                (snapshot.meta == null ? File.Exists(snapshot.path + ".meta") : !File.ReadAllBytes(snapshot.path + ".meta").AsSpan().SequenceEqual(snapshot.meta)))
                throw new InvalidOperationException("SDK Player link.xml restoration is uncertain; pending receipt is retained.");
            pendingPlayerLink = null;
            File.Delete(PendingPlayerPath);
        }
    }

    // Runs before the official SDK processor so Boot content is on stage when it copies StreamingAssets.
    internal sealed class ManagedBootstrapSplitPlayerBootGuard : BuildPlayerProcessor
    {
        public override int callbackOrder => 0;
        public override void PrepareForBuild(BuildPlayerContext context)
        {
            var config = ManagedAddressableBuildExporter.LoadConfig();
            if (config != null) ManagedAddressableBuildExporter.PrepareSplitPlayerBuild(config, context);
        }
    }

    // The official SDK processor runs at order1. Its DoNot setting skips content rebuilding,
    // still registers SDK BuildPath for StreamingAssets and imports its generated link.xml.
    internal sealed class ManagedBootstrapSplitPlayerStageGuard : BuildPlayerProcessor
    {
        public override int callbackOrder => 2;
        public override void PrepareForBuild(BuildPlayerContext context)
        {
            var config = ManagedAddressableBuildExporter.LoadConfig();
            if (config != null) ManagedAddressableBuildExporter.VerifySplitPlayerBuild(config);
        }
    }

    internal sealed class ManagedBootstrapSplitPlayerCleanup : IPostprocessBuildWithReport
    {
        public int callbackOrder => int.MaxValue;
        public void OnPostprocessBuild(BuildReport report) => ManagedAddressableBuildExporter.FinishSplitPlayerBuild(report);
    }
}
