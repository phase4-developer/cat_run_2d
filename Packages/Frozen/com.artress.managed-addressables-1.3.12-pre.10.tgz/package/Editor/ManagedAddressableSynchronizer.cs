using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedAddressableSyncReport
    {
        public int createdGroups;
        public int removedGroups;
        public int addedEntries;
        public int movedEntries;
        public int changedAddresses;
        public int preservedAddresses;
        public int removedEntries;
        public int invalidPaths;
        public int normalizedBundleIdentityGroups;
        public readonly List<string> messages = new List<string>();

        internal ManagedAddressableSyncReport Copy()
        {
            var result = new ManagedAddressableSyncReport
            {
                createdGroups = createdGroups, removedGroups = removedGroups, addedEntries = addedEntries,
                movedEntries = movedEntries, changedAddresses = changedAddresses, preservedAddresses = preservedAddresses,
                removedEntries = removedEntries, invalidPaths = invalidPaths, normalizedBundleIdentityGroups = normalizedBundleIdentityGroups
            };
            result.messages.AddRange(messages);
            return result;
        }

        public override string ToString()
        {
            return $"CreatedGroups:{createdGroups}, RemovedGroups:{removedGroups}, AddedEntries:{addedEntries}, MovedEntries:{movedEntries}, ChangedAddresses:{changedAddresses}, PreservedAddresses:{preservedAddresses}, RemovedEntries:{removedEntries}, InvalidPaths:{invalidPaths}, NormalizedBundleIdentityGroups:{normalizedBundleIdentityGroups}\n" + string.Join("\n", messages);
        }
    }

    internal static partial class ManagedAddressableSynchronizer
    {
        public static ManagedAddressableSyncReport CleanupEmptyGroups(ManagedAddressableProjectConfig config, bool dryRun)
        {
            if (config == null)
                throw new ArgumentNullException(nameof(config));
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating || BuildPipeline.isBuildingPlayer || ManagedAddressableBuildExporter.BuildInProgress)
                throw new InvalidOperationException("Play 또는 빌드/컴파일 중에는 그룹을 정리할 수 없습니다.");

            ManagedAddressableSyncReport report = new ManagedAddressableSyncReport();
            AddressableAssetSettings settings = ReadSettingsWithoutMigration();
            if (settings == null)
            {
                report.messages.Add("Addressables Settings가 없습니다.");
                return report;
            }

            string defaultGroupGuid = new SerializedObject(settings).FindProperty("m_DefaultGroup")?.stringValue;
            List<AddressableAssetGroup> candidates = new List<AddressableAssetGroup>();
            foreach (AddressableAssetGroup group in settings.groups)
            {
                if (group == null || !config.OwnsGroup(group) || group.Guid == defaultGroupGuid || group.ReadOnly || group.HasSchema<PlayerDataGroupSchema>() || group.entries.Count != 0)
                    continue;

                // RemoveGroup also deletes schema assets, so shared schemas must be preserved.
                if (group.Schemas.Any(schema => schema != null && settings.groups.Any(other => other != null && other != group && other.Schemas.Contains(schema))))
                {
                    report.messages.Add("[Keep Shared Schema Group] " + group.Name);
                    continue;
                }

                candidates.Add(group);
            }

            if (!dryRun && candidates.Count > 0 && config.backupBeforeApply)
                BackupSettings(config, settings);

            foreach (AddressableAssetGroup group in candidates)
            {
                string groupName = group.Name;
                if (!dryRun)
                    settings.RemoveGroup(group);
                report.removedGroups++;
                report.messages.Add((dryRun ? "[Remove Empty Group] " : "[Removed Empty Group] ") + groupName);
            }

            if (!dryRun && report.removedGroups > 0)
                AssetDatabase.SaveAssets();

            return report;
        }

        private static void ApplySyncPlan(ManagedAddressableProjectConfig config, AddressableAssetSettings settings, ManagedAddressableSyncPlan plan, List<AddressableAssetGroup> affectedGroups)
        {
            if (plan.createSettings)
            {
                settings = ManagedAddressablePreset.GetOrCreateSettings();
                if (settings == null) throw new InvalidOperationException("Addressables Settings could not be created.");
                ManagedAddressablePreset.ApplyInitialSettings(settings, config);
            }
            foreach (ManagedAddressableSyncPlan.GroupAddition addition in plan.groups)
            {
                AddressableAssetGroup group = settings.CreateGroup(addition.name, false, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
                ManagedAddressablePreset.ApplyGroup(settings, group, addition.delivery, addition.bundleMode);
                affectedGroups.Add(group);
                if (config.ownedGroupGuids == null) config.ownedGroupGuids = new List<string>();
                string groupAssetGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
                if (!config.ownedGroupGuids.Contains(groupAssetGuid)) config.ownedGroupGuids.Add(groupAssetGuid);
            }
            if (plan.ownedGroupGuidsAfter != null) config.ownedGroupGuids = new List<string>(plan.ownedGroupGuidsAfter);
            foreach (ManagedAddressableSyncPlan.GroupPolicyChange policy in plan.policies)
            {
                AddressableAssetGroup group = settings.groups.First(g => g != null && AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(g)) == policy.assetGuid);
                BundledAssetGroupSchema schema = group.GetSchema<BundledAssetGroupSchema>();
                schema.UseAssetBundleCache = true;
                schema.UseAssetBundleCrc = true;
                schema.UseAssetBundleCrcForCachedBundles = false;
                schema.AssetBundledCacheClearBehavior = BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache;
                AssetDatabase.SaveAssetIfDirty(schema);
            }
            if (plan.buildRoles != null)
            {
                config.groupBuildRoles = plan.buildRoles.CopyRoles();
                config.requiredBootKeys = plan.buildRoles.keys.ToList();
                if (settings.BuildAddressablesWithPlayerBuild != AddressableAssetSettings.PlayerBuildOption.DoNotBuildWithPlayer)
                {
                    settings.BuildAddressablesWithPlayerBuild = AddressableAssetSettings.PlayerBuildOption.DoNotBuildWithPlayer;
                    EditorUtility.SetDirty(settings);
                    AssetDatabase.SaveAssetIfDirty(settings);
                }
            }
            if (plan.HasReleaseMetadata) config.revisionRelease = plan.CopyReleaseMetadata();
            if (plan.groups.Count > 0 || plan.ownedGroupGuidsAfter != null || plan.buildRoles != null || plan.HasReleaseMetadata)
            {
                EditorUtility.SetDirty(config);
                if (EditorUtility.IsPersistent(config)) AssetDatabase.SaveAssetIfDirty(config);
            }
            foreach (ManagedAddressableSyncPlan.EntryChange change in plan.entries)
            {
                if (change.remove) { settings.RemoveAssetEntry(change.guid, false); continue; }
                AddressableAssetGroup target = FindGroup(settings, change.groupName);
                if (target == null) throw new InvalidOperationException("Planned Group was not created: " + change.groupName);
                AddressableAssetEntry entry = settings.FindAssetEntry(change.guid);
                if (entry == null || entry.parentGroup != target) entry = settings.CreateOrMoveEntry(change.guid, target, false, false);
                if (entry == null) throw new InvalidOperationException("Planned Entry could not be registered: " + change.guid);
                if (!string.Equals(entry.address, change.address, StringComparison.Ordinal)) entry.SetAddress(change.address, false);
            }
            if (plan.createSettings || plan.groups.Count > 0 || plan.entries.Count > 0 || plan.policies.Count > 0)
            {
                settings.SetDirty(AddressableAssetSettings.ModificationEvent.BatchModification, null, true, true);
                AssetDatabase.SaveAssetIfDirty(settings);
                foreach (AddressableAssetGroup group in affectedGroups.Distinct())
                {
                    AssetDatabase.SaveAssetIfDirty(group);
                    // Existing schema assets belong to the official Inspector and are not saved here.
                    if (plan.createSettings || plan.groups.Any(g => string.Equals(g.name, group.Name, StringComparison.OrdinalIgnoreCase)))
                        foreach (AddressableAssetGroupSchema schema in group.Schemas.Where(s => s != null)) AssetDatabase.SaveAssetIfDirty(schema);
                }
            }
        }

        private static ManagedCategoryRule FindBestRule(IEnumerable<ManagedCategoryRule> rules, string relativePath)
        {
            string normalizedPath = Normalize(relativePath);
            foreach (ManagedCategoryRule rule in rules)
            {
                string prefix = Normalize(rule.relativePath);
                if (normalizedPath.Equals(prefix, StringComparison.OrdinalIgnoreCase) || normalizedPath.StartsWith(prefix + "/", StringComparison.OrdinalIgnoreCase))
                    return rule;
            }
            return null;
        }

        private static ManagedCategoryRule CreateDefaultRule(string deliveryFolder, string category)
        {
            ManagedDeliveryMode delivery = ManagedAddressablePathRules.ResolveDelivery(deliveryFolder, ManagedDeliveryMode.Remote);
            string defaultGroupName = delivery == ManagedDeliveryMode.Local ? category : "Remote_" + category;
            return new ManagedCategoryRule
            {
                relativePath = deliveryFolder + "/" + category,
                delivery = delivery,
                groupStrategy = ManagedGroupStrategy.ReservedFolder,
                groupNamePattern = defaultGroupName,
                bundleMode = BundledAssetGroupSchema.BundlePackingMode.PackTogether
            };
        }

        private static AddressableAssetGroup FindGroup(AddressableAssetSettings settings, string name)
        {
            return settings.groups.FirstOrDefault(group => group != null && string.Equals(group.Name, name, StringComparison.OrdinalIgnoreCase));
        }

        private static bool IsManagedAssetFile(string path)
        {
            if (Path.GetFileName(path).Equals("LightingData.asset", StringComparison.OrdinalIgnoreCase))
                return false;

            string extension = Path.GetExtension(path);
            if (extension.Equals(".meta", StringComparison.OrdinalIgnoreCase) || extension.Equals(".cs", StringComparison.OrdinalIgnoreCase) || extension.Equals(".asmdef", StringComparison.OrdinalIgnoreCase) || extension.Equals(".asmref", StringComparison.OrdinalIgnoreCase))
                return false;

            string normalized = path.Replace('\\', '/');
            return normalized.IndexOf("/Editor/", StringComparison.OrdinalIgnoreCase) < 0;
        }

        private static string Normalize(string value)
        {
            return (value ?? string.Empty).Replace('\\', '/').Trim('/');
        }

        private static void BackupSettings(ManagedAddressableProjectConfig config, AddressableAssetSettings settings)
        {
            string source = Path.GetDirectoryName(AssetDatabase.GetAssetPath(settings));
            if (string.IsNullOrEmpty(source) || !Directory.Exists(source))
                return;

            string destination = Path.Combine(config.backupRoot, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            CopyDirectory(source, destination);
        }

        private static void CopyDirectory(string source, string destination)
        {
            Directory.CreateDirectory(destination);
            foreach (string file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            {
                string relative = file.Substring(source.Length).TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string target = Path.Combine(destination, relative);
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                File.Copy(file, target, true);
            }
        }
    }
}
