using System.Collections.Generic;
using UnityEditor;
using UnityEngine.AddressableAssets;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedBuildExportResult
    {
        public bool success;
        public string outputDirectory;
        public string splitReceiptPath;
        public string error;
        public readonly List<string> warnings = new List<string>();
    }

    internal static partial class ManagedAddressableBuildExporter
    {
        // True while a purpose content build owns the SDK settings overlay.
        internal static bool BuildInProgress { get; set; }

        internal static string AddressablesVersion => UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(Addressables).Assembly)?.version ?? string.Empty;

        internal static ManagedAddressableProjectConfig LoadConfig()
        {
            return AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ManagedAddressableProjectConfig.DefaultAssetPath);
        }

        private static string GetBuildOutputRoot(ManagedAddressableProjectConfig config)
        {
            return string.IsNullOrWhiteSpace(config.buildOutputRoot) ? "ServerData" : config.buildOutputRoot.Trim();
        }
    }
}
