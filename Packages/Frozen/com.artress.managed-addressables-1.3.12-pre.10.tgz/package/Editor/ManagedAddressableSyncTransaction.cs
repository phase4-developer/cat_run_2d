using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    // Recovery covers Addressables settings/groups/schemas.
    // Build and deployment are separate operations.
    internal sealed class ManagedAddressableSyncTransaction : IDisposable
    {
        private readonly string[] roots;
        private readonly Dictionary<string, byte[]> files = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<UnityEngine.Object, string> objects = new Dictionary<UnityEngine.Object, string>();
        private readonly HashSet<string> directories = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly AddressableAssetSettings previousSettings;
        private bool complete;

        internal ManagedAddressableSyncTransaction(AddressableAssetSettings settings, IEnumerable<AddressableAssetGroup> affectedGroups = null,
            UnityEngine.Object config = null, IEnumerable<UnityEditor.AddressableAssets.Settings.GroupSchemas.BundledAssetGroupSchema> affectedSchemas = null)
        {
            previousSettings = settings;
            roots = new[] { settings == null ? AddressableAssetSettingsDefaultObject.kDefaultConfigFolder : Path.GetDirectoryName(AssetDatabase.GetAssetPath(settings)).Replace('\\', '/') };
            foreach (string root in roots)
            {
                if (!root.StartsWith("Assets/", StringComparison.Ordinal)) throw new InvalidOperationException("Settings must be writable assets under Assets: " + root);
                CaptureFile(root + ".meta");
                if (!Directory.Exists(root)) continue;
                directories.Add(root);
                foreach (string directory in Directory.GetDirectories(root, "*", SearchOption.AllDirectories)) directories.Add(directory.Replace('\\', '/'));
                foreach (string file in Directory.GetFiles(root, "*", SearchOption.AllDirectories)) CaptureFile(file);
            }
            CaptureFile("ProjectSettings/EditorBuildSettings.asset");
            CaptureObject(settings);
            CaptureObject(config);
            if (affectedSchemas != null) foreach (var schema in affectedSchemas) CaptureObject(schema);
            if (settings != null)
                foreach (AddressableAssetGroup group in (affectedGroups ?? settings.groups).Where(g => g != null).Distinct())
                {
                    CaptureObject(group);
                }
        }

        private void CaptureFile(string path)
        {
            path = path.Replace('\\', '/');
            if (File.Exists(path)) files[path] = File.ReadAllBytes(path);
        }

        private void CaptureObject(UnityEngine.Object value)
        {
            if (value == null || objects.ContainsKey(value)) return;
            string path = AssetDatabase.GetAssetPath(value);
            if (!string.IsNullOrEmpty(path))
            {
                if (!path.StartsWith("Assets/", StringComparison.Ordinal)) throw new InvalidOperationException("Settings/Group/Schema must be writable assets under Assets: " + path);
                CaptureFile(path);
                CaptureFile(path + ".meta");
            }
            objects.Add(value, EditorJsonUtility.ToJson(value));
        }

        internal void Complete() { complete = true; }

        internal void Restore()
        {
            complete = true;
            // This method runs synchronously on the Editor thread; no import happens during file restoration.
            AssetDatabase.StartAssetEditing();
            try
            {
                foreach (string root in roots)
                {
                    if (Directory.Exists(root))
                        foreach (string file in Directory.GetFiles(root, "*", SearchOption.AllDirectories))
                            if (!files.ContainsKey(file.Replace('\\', '/'))) File.Delete(file);
                    if (!files.ContainsKey(root + ".meta") && File.Exists(root + ".meta")) File.Delete(root + ".meta");
                }
                foreach (var pair in files)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(pair.Key));
                    File.WriteAllBytes(pair.Key, pair.Value);
                }
                foreach (var pair in objects)
                    if (pair.Key != null) EditorJsonUtility.FromJsonOverwrite(pair.Value, pair.Key);
                foreach (string root in roots)
                    if (Directory.Exists(root))
                        foreach (string directory in Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Append(root).OrderByDescending(p => p.Length))
                            if (!directories.Contains(directory.Replace('\\', '/')) && Directory.GetFileSystemEntries(directory).Length == 0) Directory.Delete(directory);
            }
            finally { AssetDatabase.StopAssetEditing(); }
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            // Avoid persisting a new global DefaultObject when creation was rolled back.
            if (previousSettings == null)
            {
                EditorBuildSettings.RemoveConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName);
                typeof(AddressableAssetSettingsDefaultObject).GetField("s_DefaultSettingsObject", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic)?.SetValue(null, null);
            }
        }

        public void Dispose()
        {
            if (!complete) Restore();
        }
    }
}
