using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Artress.ManagedAddressables.Editor
{
    internal static partial class ManagedAddressableSynchronizer
    {
        public static ManagedAddressableSyncPlan CreateRevisionReleasePlan(ManagedAddressableProjectConfig config, ManagedRevisionReleaseMetadata release)
        {
            CheckSyncState(config);
            ValidateSyncPaths(config);
            var settings = ReadSettingsWithoutMigration();
            var next = release?.Copy();
            var blocked = new List<string>();
            var warnings = new List<string>();
            var changes = new List<ManagedAddressableSyncChange>();
            try { ManagedAddressableBuildExporter.ValidateReleaseMetadata(next); }
            catch (Exception error) { blocked.Add(error.Message); }
            string before = JsonConvert.SerializeObject(config.revisionRelease), after = JsonConvert.SerializeObject(next);
            if (before != after) changes.Add(new ManagedAddressableSyncChange("Global", "Project Config", "revisionRelease", before, after));
            if (blocked.Count == 0) warnings.AddRange(ManagedAddressableBuildExporter.RevisionSequenceWarnings(config, next));
            warnings.Add("Release metadata only. No Group adoption, SDK setting, packaging link or sequence allocation is performed.");
            return new ManagedAddressableSyncPlan(SyncFingerprint(config, settings), false,
                new List<ManagedAddressableSyncPlan.GroupAddition>(), new List<ManagedAddressableSyncPlan.EntryChange>(),
                changes, blocked, CustomPlanReport(changes, blocked, warnings), warnings,
                releaseMetadata: changes.Count == 0 ? null : next);
        }
    }
}
