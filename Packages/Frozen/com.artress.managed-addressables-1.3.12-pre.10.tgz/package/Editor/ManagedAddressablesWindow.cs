using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    public sealed partial class ManagedAddressablesWindow : EditorWindow
    {
        private ManagedAddressableProjectConfig config;
        private SerializedObject serializedConfig;
        private Vector2 scroll;
        private bool showAdvanced;
        private bool showResult = true;
        private float resultPanelHeight = 180f;
        private string resultText = string.Empty;
        private bool buildInProgress;
        private ManagedAddressableSyncPlan reviewedSyncPlan;
        private bool reviewedAddressRebuild;
        private AddressableAssetGroup ownershipCandidate;

        [MenuItem("Tools/Artress/Managed Addressables/Open Control Center", priority = 1)]
        public static void Open()
        {
            GetWindow<ManagedAddressablesWindow>("Managed Addressables");
        }

        [MenuItem("Tools/Artress/Managed Addressables/Remove Empty Groups", priority = 20)]
        private static void OpenEmptyGroupCleanup()
        {
            GetWindow<ManagedAddressablesWindow>("Managed Addressables").RunEmptyGroupCleanup(false);
        }

        [MenuItem("Tools/Artress/Managed Addressables/Remove Empty Groups", true)]
        private static bool CanCleanupEmptyGroups()
        {
            return !EditorApplication.isPlayingOrWillChangePlaymode && !EditorApplication.isCompiling && !EditorApplication.isUpdating && !BuildPipeline.isBuildingPlayer && !ManagedAddressableBuildExporter.BuildInProgress;
        }

        private void OnEnable()
        {
            minSize = new Vector2(900f, 720f);
            resultPanelHeight = Mathf.Clamp(resultPanelHeight, 140f, 280f);
            LoadConfig();
        }

        private void OnGUI()
        {
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("Artress Managed Addressables", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Preview에서 등록·주소·신규 그룹과 최초 Settings의 예정 변경을 확인한 뒤 같은 계획을 Apply합니다. 기존 Group schema·Profile·Global 수동 설정은 유지합니다.", MessageType.Info);

            if (config == null)
            {
                DrawCreateConfig();
                return;
            }

            serializedConfig.Update();
            float footerReserve = showResult ? resultPanelHeight + 72f : 58f;
            float scrollHeight = Mathf.Max(260f, position.height - footerReserve);
            scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.Height(scrollHeight));

            DrawOneClickSection();
            EditorGUILayout.Space(10f);
            DrawFolderRuleSection();
            EditorGUILayout.Space(10f);
            DrawNamingSection();
            EditorGUILayout.Space(10f);
            DrawCategorySection();
            EditorGUILayout.Space(10f);
            DrawOwnershipSection();
            EditorGUILayout.Space(10f);
            DrawBuildSection();
            EditorGUILayout.Space(10f);
            DrawAdvancedSection();

            EditorGUILayout.EndScrollView();
            serializedConfig.ApplyModifiedProperties();
            EditorGUILayout.Space(6f);
            DrawResultSection();
        }

        private void DrawResultSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            showResult = EditorGUILayout.Foldout(showResult, "Result", true);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Copy", GUILayout.Width(72f)))
                EditorGUIUtility.systemCopyBuffer = resultText ?? string.Empty;
            if (GUILayout.Button("Clear", GUILayout.Width(72f)))
                resultText = string.Empty;
            EditorGUILayout.EndHorizontal();

            if (showResult)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Panel Height", GUILayout.Width(78f));
                resultPanelHeight = EditorGUILayout.Slider(resultPanelHeight, 140f, 280f);
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.TextArea(resultText ?? string.Empty, GUILayout.Height(resultPanelHeight));
            }

            EditorGUILayout.EndVertical();
        }

        private void DrawCreateConfig()
        {
            EditorGUILayout.HelpBox("설정 에셋이 없습니다. 아래 버튼으로 기본 설정을 생성하고 폴더 구조를 자동 탐색합니다.", MessageType.Warning);
            if (GUILayout.Button("CREATE CONFIG / PREVIEW", GUILayout.Height(42f)))
                CreateConfigAndInitialize();
        }

        private void DrawOneClickSection()
        {
            EditorGUILayout.LabelField("Project Setup", EditorStyles.boldLabel);
            DefaultAsset selectedRoot = (DefaultAsset)EditorGUILayout.ObjectField("Content Root", config.contentRootFolder, typeof(DefaultAsset), false);
            if (selectedRoot != config.contentRootFolder)
            {
                string path = selectedRoot != null ? AssetDatabase.GetAssetPath(selectedRoot) : string.Empty;
                if (string.IsNullOrEmpty(path) || AssetDatabase.IsValidFolder(path))
                    config.SetContentRoot(path);
            }
            EditorGUILayout.LabelField("Resolved Path", config.ContentRootPath);

            if (GUILayout.Button("Auto Detect Root"))
                ShowContentRootMenu();

            EditorGUI.BeginDisabledGroup(reviewedSyncPlan == null || reviewedAddressRebuild || !reviewedSyncPlan.CanApply);
            if (GUILayout.Button("APPLY REVIEWED PLAN", GUILayout.Height(44f)))
                InitializeAndSync();
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Preview Sync"))
                RunPreview();
            if (GUILayout.Button("Validate"))
                RunValidate();
            EditorGUILayout.EndHorizontal();

            EditorGUI.BeginDisabledGroup(buildInProgress || !CanCleanupEmptyGroups());
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Preview Empty Groups"))
                RunEmptyGroupCleanup(true);
            if (GUILayout.Button("Remove Empty Groups"))
                RunEmptyGroupCleanup(false);
            EditorGUILayout.EndHorizontal();
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.HelpBox("Entry가 없는 그룹만 정리합니다. 기본 그룹, 읽기 전용 그룹, 내장 데이터 그룹과 스키마를 공유하는 그룹은 유지합니다. 폴더 Entry가 있으면 빈 그룹으로 처리하지 않습니다.", MessageType.None);
        }

        private void DrawFolderRuleSection()
        {
            EditorGUILayout.LabelField("Folder Bundle Rule", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("updateFolderName"), new GUIContent("Reserved Update Folder"));
            EditorGUILayout.HelpBox("<Delivery>/<Category>의 일반 파일은 카테고리 기본 Bundle로 묶고, <Delivery>/<Category>/Update/<BundleKey> 하위 파일은 BundleKey별 Bundle로 분리합니다. Update와 BundleKey는 Address 이름 계산에서 제외됩니다.", MessageType.None);
        }

        private void DrawNamingSection()
        {
            EditorGUILayout.LabelField("Address Naming", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("pathSeparator"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("ignorePathPrefixes"), true);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("preserveExistingAddressesOnSync"), new GUIContent("Preserve Existing On Sync"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("includeExtension"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("ensureUnique"));
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.HelpBox("일반 Sync는 기존 Address를 유지하고 새 Entry 또는 빈 Address만 현재 주소 생성 규칙으로 생성합니다. Update/<BundleKey>는 Address에서 제외됩니다. 예: Remote/Character/Update/1.0.1/Char_6.prefab → Char_6", MessageType.None);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Preview Address Rebuild"))
                RunAddressRebuildPreview();
            if (GUILayout.Button("REBUILD ADDRESSES"))
                RunAddressRebuild();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawCategorySection()
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Category / Bundle Policy", EditorStyles.boldLabel);
            if (GUILayout.Button("Detect New Categories", GUILayout.Width(160f)))
            {
                config.categoryRules = ManagedAddressableCategoryDiscovery.Discover(config.ContentRootPath, config.categoryRules);
                EditorUtility.SetDirty(config);
                serializedConfig.Update();
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.HelpBox("새 카테고리만 병합하고 같은 경로의 기존 Rule은 유지합니다. 기본 Rule은 ReservedFolder + Pack Together입니다. 특수한 카테고리만 Advanced Rule로 변경하세요.", MessageType.None);
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("categoryRules"), true);
        }

        private void DrawOwnershipSection()
        {
            EditorGUILayout.LabelField("Explicit JJEvol Group Ownership", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("기존 Group은 이름이나 폴더 규칙으로 자동 채택하지 않습니다. 업그레이드 전 생성한 Group도 아래에서 명시 채택해야 JJEvol 등록/정책 수정 대상이 됩니다. 채택·해제·미존재 참조 정리는 Preview 후 위 APPLY REVIEWED PLAN으로 적용합니다.", MessageType.Info);
            ownershipCandidate = (AddressableAssetGroup)EditorGUILayout.ObjectField("Group to adopt", ownershipCandidate, typeof(AddressableAssetGroup), false);
            EditorGUI.BeginDisabledGroup(ownershipCandidate == null || buildInProgress);
            if (GUILayout.Button("Preview Group Adoption"))
                RunCustomPreview(() => ManagedAddressableSynchronizer.CreateOwnershipPlan(config, new[] { ownershipCandidate }));
            EditorGUI.EndDisabledGroup();
            foreach (string guid in (config.ownedGroupGuids ?? new List<string>()).ToArray())
            {
                string path = AssetDatabase.GUIDToAssetPath(guid ?? string.Empty);
                AddressableAssetGroup group = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(path);
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField(new GUIContent(group != null ? group.Name : "Missing Group (reference retained)", guid ?? "<null>"));
                if (GUILayout.Button("Preview Release", GUILayout.Width(130f)))
                    RunCustomPreview(() => ManagedAddressableSynchronizer.CreateOwnershipPlan(config, releaseGroupGuids: new[] { guid }));
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("Preview Missing Ownership Cleanup"))
                RunCustomPreview(() => ManagedAddressableSynchronizer.CreateOwnershipPlan(config, removeMissing: true));
        }

        private void RunCustomPreview(Func<ManagedAddressableSyncPlan> create)
        {
            try
            {
                serializedConfig.ApplyModifiedProperties();
                reviewedSyncPlan = create();
                reviewedAddressRebuild = false;
                resultText = reviewedSyncPlan.Report.ToString();
            }
            catch (Exception error) { reviewedSyncPlan = null; resultText = error.ToString(); }
        }

        private void DrawBuildSection()
        {
            EditorGUILayout.LabelField("Addressable Build / Export", EditorStyles.boldLabel);
            DrawSplitRoleSection();
            DrawPackagedRevisionSection();
            EditorGUILayout.HelpBox("Boot/Revision 빌드는 매번 Player Content를 정리하고 Clean Full Snapshot으로 제작합니다. Unity Content Update는 사용하지 않습니다.", MessageType.None);
            EditorGUI.BeginDisabledGroup(buildInProgress);
            if (GUILayout.Button("Preview Owned Remote Cache / CRC Policy"))
                RunCustomPreview(() => ManagedAddressableSynchronizer.CreateRevisionBuildPlan(config));
            if (GUILayout.Button(buildInProgress ? "ADDRESSABLE BUILDING..." : "BUILD SDK REVISION CONTENT", GUILayout.Height(36f)))
                QueueBuild(ManagedGroupBuildRole.Revision);
            EditorGUI.EndDisabledGroup();
        }

        private void QueueBuild(ManagedGroupBuildRole purpose)
        {
            if (buildInProgress) return;

            serializedConfig.ApplyModifiedProperties();
            if (purpose == ManagedGroupBuildRole.Revision)
            {
                var release = ManagedAddressableBuildExporter.ValidateRevisionReleasePrebuild(config);
                if (!release.CanBuild) { resultText = release.ToString(); return; }
                if (HasUnappliedReleaseDraft()) { resultText = "Release draft가 저장되지 않았습니다. Preview Release Metadata → APPLY REVIEWED PLAN 또는 Reload Release Draft 후 다시 Preview하세요."; return; }
            }
            if (reviewedSplitBuildPlan == null || reviewedSplitBuildPlan.purpose != purpose)
            {
                resultText = "Preview the matching Boot/Revision build plan before building.";
                return;
            }
            buildInProgress = true;
            resultText = "Addressable build started...";
            Repaint();

            EditorApplication.delayCall += RunBuildDeferred;
        }

        private void RunBuildDeferred()
        {
            if (this == null) return;

            try
            {
                ManagedBuildExportResult build = ManagedAddressableBuildExporter.BuildReviewedSplitContent(config, reviewedSplitBuildPlan);
                if (build.success && reviewedSplitBuildPlan?.purpose == ManagedGroupBuildRole.Revision)
                    packagedReceiptDraft = build.splitReceiptPath;
                resultText = build.success
                    ? "Addressable build completed.\nOutput: " + build.outputDirectory + "\nSplit receipt: " + build.splitReceiptPath + (build.warnings.Count > 0 ? "\nDetails:\n" + string.Join("\n", build.warnings) : string.Empty)
                    : "Addressable build failed.\n" + build.error;
            }
            catch (Exception ex)
            {
                resultText = "Addressable build failed.\n" + ex;
            }
            finally
            {
                buildInProgress = false;
                reviewedSplitBuildPlan = null;
                Repaint();
            }
        }

        private void DrawAdvancedSection()
        {
            showAdvanced = EditorGUILayout.Foldout(showAdvanced, "Advanced", true);
            if (!showAdvanced)
                return;

            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("buildOutputRoot"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("profileName"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("autoRegister"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("createGroupIfMissing"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("backupBeforeApply"));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("backupRoot"));
            EditorGUI.indentLevel--;
        }

        private void InitializeAndSync()
        {
            try
            {
                serializedConfig.ApplyModifiedProperties();
                if (reviewedSyncPlan == null || reviewedAddressRebuild) throw new InvalidOperationException("Preview Sync를 먼저 실행하세요.");
                ManagedAddressableSyncReport report = ManagedAddressableSynchronizer.ApplyPlan(config, reviewedSyncPlan);
                reviewedSyncPlan = null;
                serializedConfig.Update();
                List<string> errors = ManagedAddressableValidator.Validate(config);
                resultText = report + (errors.Count == 0 ? "\nValidation: PASS" : "\nValidation:\n" + string.Join("\n", errors));
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
        }

        private void RunPreview()
        {
            try
            {
                serializedConfig.ApplyModifiedProperties();
                reviewedSyncPlan = ManagedAddressableSynchronizer.CreatePlan(config);
                reviewedAddressRebuild = false;
                resultText = reviewedSyncPlan.Report.ToString();
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
        }

        private void RunEmptyGroupCleanup(bool preview)
        {
            try
            {
                if (buildInProgress || !CanCleanupEmptyGroups()) return;

                serializedConfig?.ApplyModifiedProperties();
                ManagedAddressableSyncReport report = ManagedAddressableSynchronizer.CleanupEmptyGroups(config, true);
                resultText = "Empty Group Preview: " + report.removedGroups + "\n" + string.Join("\n", report.messages);
                showResult = true;
                if (preview || report.removedGroups == 0) return;

                if (!EditorUtility.DisplayDialog("Remove Empty Groups", resultText + "\n\n위 빈 그룹을 삭제합니다. 계속할까요?", "Remove", "Cancel"))
                    return;

                report = ManagedAddressableSynchronizer.CleanupEmptyGroups(config, false);
                resultText = "Removed Empty Groups: " + report.removedGroups + "\n" + string.Join("\n", report.messages);
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
            finally
            {
                Repaint();
            }
        }

        private void RunAddressRebuildPreview()
        {
            try
            {
                serializedConfig.ApplyModifiedProperties();
                reviewedSyncPlan = ManagedAddressableSynchronizer.CreatePlan(config, true);
                reviewedAddressRebuild = true;
                resultText = reviewedSyncPlan.Report.ToString();
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
        }

        private void RunAddressRebuild()
        {
            if (!EditorUtility.DisplayDialog("Rebuild Addresses", "관리 대상의 기존 Address를 모두 재계산합니다. Address를 참조하는 코드와 프리팹에 영향이 있을 수 있습니다. 계속할까요?", "Rebuild", "Cancel"))
                return;

            try
            {
                serializedConfig.ApplyModifiedProperties();
                if (reviewedSyncPlan == null || !reviewedAddressRebuild) throw new InvalidOperationException("Preview Address Rebuild를 먼저 실행하세요.");
                resultText = ManagedAddressableSynchronizer.ApplyPlan(config, reviewedSyncPlan).ToString();
                reviewedSyncPlan = null;
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
        }

        private void RunValidate()
        {
            List<string> errors = ManagedAddressableValidator.Validate(config);
            resultText = errors.Count == 0 ? "Validation: PASS" : string.Join("\n", errors);
        }

        private void LoadConfig()
        {
            reviewedSyncPlan = null;
            config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ManagedAddressableProjectConfig.DefaultAssetPath);
            if (config != null)
                serializedConfig = new SerializedObject(config);
        }

        private void CreateConfigAndInitialize()
        {
            List<ManagedFolderCandidate> candidates = ManagedContentRootDiscovery.FindCandidates();
            if (candidates.Count <= 1)
            {
                string rootPath = candidates.Count == 1 ? candidates[0].path : "Assets/Addressables";
                config = CreateConfig(rootPath);
                serializedConfig = new SerializedObject(config);
                EnsureContentFolders(config.ContentRootPath);
                RunPreview();
                return;
            }

            GenericMenu menu = new GenericMenu();
            foreach (ManagedFolderCandidate candidate in candidates)
            {
                string path = candidate.path;
                menu.AddItem(new GUIContent(path + "  (" + candidate.reason + ")"), false, () =>
                {
                    config = CreateConfig(path);
                    serializedConfig = new SerializedObject(config);
                    EnsureContentFolders(config.ContentRootPath);
                    RunPreview();
                    Repaint();
                });
            }
            menu.ShowAsContext();
        }

        private ManagedAddressableProjectConfig CreateConfig(string rootPath)
        {
            string directory = Path.GetDirectoryName(ManagedAddressableProjectConfig.DefaultAssetPath).Replace('\\', '/');
            EnsureAssetFolder(directory);

            ManagedAddressableProjectConfig created = CreateInstance<ManagedAddressableProjectConfig>();
            created.SetContentRoot(rootPath);
            created.categoryRules = ManagedAddressableCategoryDiscovery.Discover(created.ContentRootPath);
            AssetDatabase.CreateAsset(created, ManagedAddressableProjectConfig.DefaultAssetPath);
            AssetDatabase.SaveAssetIfDirty(created);
            return created;
        }

        private void ShowContentRootMenu()
        {
            List<ManagedFolderCandidate> candidates = ManagedContentRootDiscovery.FindCandidates();
            if (candidates.Count == 0)
            {
                config.SetContentRoot("Assets/Addressables");
                EditorUtility.SetDirty(config);
                serializedConfig.Update();
                return;
            }

            GenericMenu menu = new GenericMenu();
            foreach (ManagedFolderCandidate candidate in candidates)
            {
                string path = candidate.path;
                menu.AddItem(new GUIContent(path + "  (" + candidate.reason + ")"), string.Equals(config.ContentRootPath, path, StringComparison.OrdinalIgnoreCase), () =>
                {
                    config.SetContentRoot(path);
                    EditorUtility.SetDirty(config);
                    serializedConfig.Update();
                    Repaint();
                });
            }
            menu.ShowAsContext();
        }

        private static void EnsureContentFolders(string contentRoot)
        {
            if (string.IsNullOrWhiteSpace(contentRoot))
                return;

            Directory.CreateDirectory(contentRoot);
            Directory.CreateDirectory(Path.Combine(contentRoot, "Local"));
            Directory.CreateDirectory(Path.Combine(contentRoot, "Remote"));
            AssetDatabase.Refresh();
        }

        private static void EnsureAssetFolder(string path)
        {
            string[] parts = path.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }
}
