using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    public sealed partial class ManagedAddressablesWindow
    {
        private ManagedAddressableProjectConfig roleDraftConfig;
        private List<ManagedGroupBuildRoleSetting> roleDraft;
        private string bootKeyDraft;
        private AddressableAssetGroup roleCandidate;
        private readonly HashSet<string> roleAdoptions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private ManagedSplitBuildPlan reviewedSplitBuildPlan;
        private ManagedSplitSettingsRestorePlan reviewedSettingsRestorePlan;

        private void LoadBuildRoleDraft()
        {
            roleDraftConfig = config;
            roleDraft = (config.groupBuildRoles ?? new List<ManagedGroupBuildRoleSetting>()).Where(r => r != null).Select(r => r.Copy()).ToList();
            roleAdoptions.Clear();
            foreach (var row in roleDraft) roleAdoptions.Add(row.groupAssetGuid);
            bootKeyDraft = string.Join("\n", config.requiredBootKeys ?? new List<string>());
        }

        private void SuggestBuildRoles()
        {
            try
            {
                var keys = (bootKeyDraft ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                var suggestion = ManagedAddressableSynchronizer.SuggestBuildRoles(config, roleDraft, keys);
                var added = suggestion.roles.Where(row => !roleDraft.Any(old => old.groupAssetGuid == row.groupAssetGuid)).ToList();
                roleDraft = suggestion.roles;
                foreach (var row in added) roleAdoptions.Add(row.groupAssetGuid);
                bootKeyDraft = string.Join("\n", suggestion.bootKeys);
                resultText = "Local folders are Boot and Remote folders are Revision. Review the draft, then Preview Build Roles.";
                if (suggestion.undecidedGroups.Count > 0) resultText += "\nAdd these Groups by hand: " + string.Join(", ", suggestion.undecidedGroups);
            }
            catch (Exception error) { resultText = error.Message; }
        }

        private void DrawSplitRoleSection()
        {
            if (roleDraftConfig != config || roleDraft == null) LoadBuildRoleDraft();
            EditorGUILayout.HelpBox("역할과 수정 권한은 별개입니다. Preview Build Roles에서 역할 변경과 필요한 채택을 함께 검토합니다. 신규 채택을 끄면 해당 Group의 임시 Include/경로 변경이 필요한 빌드는 차단됩니다. Group/Entry/schema/Profile은 이 계획에서 바꾸지 않습니다. 공식 Split Player Build는 Boot를 자동 제작합니다.", MessageType.Info);
            for (int i = 0; i < roleDraft.Count; i++)
            {
                var row = roleDraft[i];
                EditorGUILayout.BeginHorizontal();
                string path = AssetDatabase.GUIDToAssetPath(row.groupAssetGuid);
                EditorGUILayout.LabelField((string.IsNullOrEmpty(path) ? "Missing GUID: " + row.groupAssetGuid : path), EditorStyles.wordWrappedLabel, GUILayout.MinWidth(180));
                row.role = (ManagedGroupBuildRole)EditorGUILayout.EnumPopup(row.role, GUILayout.Width(105));
                row.useForSharedBundles = GUILayout.Toggle(row.useForSharedBundles, "Shared target", GUILayout.Width(105));
                bool remove = GUILayout.Button("Remove", GUILayout.Width(65));
                EditorGUILayout.EndHorizontal();
                bool owned = config.ownedGroupGuids?.Any(g => string.Equals(g, row.groupAssetGuid, StringComparison.OrdinalIgnoreCase)) == true;
                if (owned) EditorGUILayout.LabelField("Explicitly owned (release through Preview Group Adoption)");
                else
                {
                    bool selected = EditorGUILayout.ToggleLeft("Adopt for temporary Boot/Revision writes", roleAdoptions.Contains(row.groupAssetGuid));
                    if (selected) roleAdoptions.Add(row.groupAssetGuid); else roleAdoptions.Remove(row.groupAssetGuid);
                }
                if (remove) { roleDraft.RemoveAt(i); break; }
            }
            EditorGUILayout.BeginHorizontal();
            roleCandidate = (AddressableAssetGroup)EditorGUILayout.ObjectField("Explicit role Group", roleCandidate, typeof(AddressableAssetGroup), false);
            if (GUILayout.Button("Add Role Row", GUILayout.Width(110)) && roleCandidate != null)
            {
                string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(roleCandidate));
                if (!roleDraft.Any(r => r.groupAssetGuid == guid)) { roleDraft.Add(new ManagedGroupBuildRoleSetting { groupAssetGuid = guid }); roleAdoptions.Add(guid); }
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.LabelField("Required Boot keys (one exact key per line)");
            bootKeyDraft = EditorGUILayout.TextArea(bootKeyDraft ?? "", GUILayout.MinHeight(42));
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Preview Build Roles"))
                RunCustomPreview(() => ManagedAddressableSynchronizer.CreateBuildRolePlan(config, roleDraft, (bootKeyDraft ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries), roleAdoptions));
            if (GUILayout.Button("Suggest Roles from Folders")) SuggestBuildRoles();
            if (GUILayout.Button("Reload Role Draft")) LoadBuildRoleDraft();
            EditorGUILayout.EndHorizontal();
            EditorGUI.BeginDisabledGroup(buildInProgress);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Preview Player Boot Build")) PreviewSplitBuild(ManagedGroupBuildRole.Boot);
            if (GUILayout.Button("Preview Revision Build")) PreviewSplitBuild(ManagedGroupBuildRole.Revision);
            EditorGUILayout.EndHorizontal();
            if (GUILayout.Button("BUILD PLAYER BOOT CONTENT", GUILayout.Height(36))) QueueBuild(ManagedGroupBuildRole.Boot);
            if (GUILayout.Button("Validate Player Staging")) resultText = ManagedAddressableBuildExporter.ValidatePlayerStaging(config).ToString();
            if (GUILayout.Button("Preview Interrupted Split Build Settings"))
            {
                reviewedSettingsRestorePlan = ManagedAddressableBuildExporter.CreateInterruptedSplitSettingsRestorePlan();
                resultText = reviewedSettingsRestorePlan.ToString();
            }
            if (GUILayout.Button("Restore Interrupted Split Build Settings"))
            {
                try { ManagedAddressableBuildExporter.RestoreInterruptedSplitBuildSettings(reviewedSettingsRestorePlan); reviewedSettingsRestorePlan = null; resultText = "Split settings restored and raw/effective verified."; }
                catch (Exception error) { resultText = error.ToString(); }
            }
            if (GUILayout.Button("Restore Interrupted Player Build Metadata"))
            {
                try { ManagedAddressableBuildExporter.RestoreInterruptedPlayerBuildMetadata(); resultText = "Pending SDK Player metadata restoration completed."; }
                catch (Exception error) { resultText = error.ToString(); }
            }
            EditorGUI.EndDisabledGroup();
        }

        private void PreviewSplitBuild(ManagedGroupBuildRole purpose)
        {
            serializedConfig.ApplyModifiedProperties();
            reviewedSplitBuildPlan = ManagedAddressableBuildExporter.CreateSplitBuildPlan(config, purpose);
            if (purpose == ManagedGroupBuildRole.Revision)
            {
                var release = ManagedAddressableBuildExporter.ValidateRevisionReleasePrebuild(config);
                reviewedSplitBuildPlan.report.warnings.AddRange(release.Warnings);
                if (HasUnappliedReleaseDraft()) reviewedSplitBuildPlan.report.errors.Add("Release draft가 저장된 Config와 다릅니다. Preview Release Metadata → APPLY REVIEWED PLAN 또는 Reload Release Draft 후 빌드하세요.");
            }
            resultText = reviewedSplitBuildPlan.ToString();
        }

        private bool HasUnappliedReleaseDraft() => packagedDraftConfig == config && packagedReleaseDraft != null &&
            JsonUtility.ToJson(packagedReleaseDraft) != JsonUtility.ToJson(config.revisionRelease);
    }
}
