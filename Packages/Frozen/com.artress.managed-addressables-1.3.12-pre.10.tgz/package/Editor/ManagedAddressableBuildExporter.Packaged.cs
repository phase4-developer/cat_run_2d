using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Artress.ManagedAddressables;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    [Serializable]
    internal sealed class ManagedPackagedRevisionFile
    {
        public string path, sha256;
        public long bytes;
        [NonSerialized] internal string source;
    }

    [Serializable]
    internal sealed class ManagedPackagedRevisionAnchor
    {
        public int schemaVersion = 1;
        public string revisionId, target, publisherSha256, productId, channel, authorityId, compatibilityFamily;
        public long deploymentSequence;
        public string catalogRelativePath = "catalog.json", publisherRelativePath = "publisher.json", bundleRelativeRoot = "bundles";
        public string sourceRevisionReceiptSha256, sourceBootReceiptSha256;
        public List<ManagedPackagedRevisionFile> files;
    }

    internal sealed class ManagedPackagedRevisionPlan
    {
        internal string configJson, configFileSha, receiptPath, receiptSha, outputDirectory, publisherJson, anchorJson, anchorSha, playerVersion;
        internal string sourceBootReceiptPath, sourceBootReceiptSha;
        internal string PayloadDirectory => Path.Combine(outputDirectory, "Payload");
        internal ManagedRevisionReleaseMetadata release;
        internal ManagedPackagedRevisionAnchor anchor;
        internal readonly List<string> errors = new List<string>();
        internal readonly List<string> changes = new List<string>();
        public bool CanApply => errors.Count == 0;
        public IReadOnlyList<string> Errors => errors.AsReadOnly();
        public IReadOnlyList<string> Changes => changes.AsReadOnly();
        public override string ToString() => string.Join("\n", changes.Concat(errors.Select(error => "[Blocked] " + error)));
    }

    internal static partial class ManagedAddressableBuildExporter
    {
        internal const string PackagedRevisionStreamingRoot = "ArtressManagedRevision";

        // Consumes a prior, fully verified SDK Revision build. No SDK build, Catalog
        // mutation, Group adoption, Profile edit or authority/sequence generation.
        public static ManagedPackagedRevisionPlan CreatePackagedRevisionPlan(ManagedAddressableProjectConfig config,
            string revisionReceiptPath, ManagedRevisionReleaseMetadata release)
            => CreatePackagedRevisionPlan(config, revisionReceiptPath, release, null);

        public static ManagedPackagedRevisionPlan CreatePackagedRevisionPlan(ManagedAddressableProjectConfig config,
            string revisionReceiptPath, ManagedRevisionReleaseMetadata release, string sourcePairedBootReceiptPath)
        {
            var plan = new ManagedPackagedRevisionPlan();
            try
            {
                if (config == null ||
                    string.IsNullOrEmpty(AssetDatabase.GetAssetPath(config)) || EditorUtility.IsDirty(config))
                    throw new InvalidOperationException("Packaged A requires a clean persistent Project Config.");
                plan.configJson = EditorJsonUtility.ToJson(config); plan.release = release?.Copy();
                plan.configFileSha = SplitFileHash(AssetDatabase.GetAssetPath(config));
                plan.playerVersion = PlayerSettings.bundleVersion;
                plan.receiptPath = Path.GetFullPath(revisionReceiptPath); plan.receiptSha = SplitFileHash(plan.receiptPath);
                var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(plan.receiptPath));
                if (receipt == null || !receipt.complete || !receipt.rawSettingsRestored || !receipt.effectiveSettingsRestored ||
                    receipt.purpose != "Revision" || receipt.catalogFormat != "json" || receipt.platform != EditorUserBuildSettings.activeBuildTarget.ToString() ||
                    receipt.bundles == null || receipt.bundles.Count == 0 || SplitFileHash(receipt.catalogPath) != receipt.catalogSha256)
                    throw new InvalidOperationException("A complete, restored current-platform Revision receipt and its exact SDK files are required.");
                RequirePackagedReceiptFacts(receipt, "Revision");
                if (!string.IsNullOrWhiteSpace(sourcePairedBootReceiptPath))
                {
                    plan.sourceBootReceiptPath = Path.GetFullPath(sourcePairedBootReceiptPath); plan.sourceBootReceiptSha = SplitFileHash(plan.sourceBootReceiptPath);
                    var paired = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(plan.sourceBootReceiptPath));
                    RequirePackagedReceiptFacts(paired, "Boot");
                    if (!SamePackagedValidationGeneration(receipt, paired))
                        throw new InvalidOperationException("The source Boot receipt is not the Revision's actual validation generation. Supply its original paired Boot receipt; unrelated scopes cannot be substituted.");
                    ValidatePackagedBootFacts(receipt, paired, null);
                }
                var publisher = new ManagedRevisionPublisher
                {
                    revisionId = receipt.stamp, target = receipt.platform, catalogFile = "catalog.json",
                    catalogSha256 = receipt.catalogSha256, catalogBytes = new FileInfo(receipt.catalogPath).Length,
                    bundles = receipt.bundles.Select(bundle => new ManagedRevisionPublisherBundle
                    {
                        fileName = Path.GetFileName(bundle.filePath), fileSha256 = bundle.sha256,
                        bytes = new FileInfo(bundle.filePath).Length, sdkBundleName = bundle.bundleName, sdkHash = bundle.hash, crc = bundle.crc
                    }).OrderBy(row => row.fileName, StringComparer.Ordinal).ToArray()
                };
                ApplyReleaseMetadata(publisher, plan.release);
                if (publisher.bundles.Select(row => row.fileName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != publisher.bundles.Length ||
                    publisher.bundles.Any(row => string.IsNullOrWhiteSpace(row.fileName) || row.fileName == "." || row.fileName == ".." || row.bytes <= 0 ||
                        row.fileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || row.sdkHash == null || row.sdkHash.Length != 32 || !Hash128.Parse(row.sdkHash).isValid))
                    throw new InvalidOperationException("Packaged publisher Bundle identity/filenames are ambiguous or invalid.");
                var files = new List<ManagedPackagedRevisionFile> { new ManagedPackagedRevisionFile { path = "catalog.json", source = receipt.catalogPath,
                    sha256 = receipt.catalogSha256, bytes = publisher.catalogBytes } };
                foreach (var row in publisher.bundles)
                {
                    var bundle = receipt.bundles.Single(value => Path.GetFileName(value.filePath) == row.fileName);
                    if (SplitFileHash(bundle.filePath) != row.fileSha256) throw new InvalidOperationException("Actual SDK Bundle SHA differs from the verified receipt: " + bundle.filePath);
                    files.Add(new ManagedPackagedRevisionFile { path = "bundles/" + row.fileName, source = bundle.filePath, sha256 = row.fileSha256, bytes = row.bytes });
                }
                plan.publisherJson = JsonUtility.ToJson(publisher, true);
                byte[] publisherBytes = new UTF8Encoding(false).GetBytes(plan.publisherJson);
                files.Add(new ManagedPackagedRevisionFile { path = "publisher.json", sha256 = SplitBytesHash(publisherBytes), bytes = publisherBytes.LongLength });
                plan.anchor = new ManagedPackagedRevisionAnchor { revisionId = publisher.revisionId, target = publisher.target,
                    publisherSha256 = SplitBytesHash(publisherBytes), productId = publisher.productId, channel = publisher.channel,
                    authorityId = publisher.authorityId, compatibilityFamily = publisher.compatibilityFamily, deploymentSequence = publisher.deploymentSequence, files = files,
                    sourceRevisionReceiptSha256 = plan.receiptSha, sourceBootReceiptSha256 = plan.sourceBootReceiptSha };
                plan.anchorJson = JsonUtility.ToJson(plan.anchor, true); plan.anchorSha = SplitBytesHash(new UTF8Encoding(false).GetBytes(plan.anchorJson));
                plan.outputDirectory = Path.Combine(SplitOutputRoot(config), "packaged", DateTime.UtcNow.ToString("yyyyMMdd") + "-" + Guid.NewGuid().ToString("N").Substring(0, 16));
                foreach (string path in files.Select(file => Path.Combine(plan.PayloadDirectory, file.path)).Concat(new[] {
                    Path.Combine(plan.PayloadDirectory, "packaged_revision.json"), Path.Combine(plan.outputDirectory, "Proof", "Revision.json"), Path.Combine(plan.outputDirectory, "Proof", "Boot.json") }))
                    if (Application.platform == RuntimePlatform.WindowsEditor && Path.GetFullPath(path).Length >= 260)
                        throw new InvalidOperationException("Packaged output path exceeds the Windows path budget; shorten buildOutputRoot: " + path);
                plan.changes.Add("[SDK] Reuse verified Revision receipt " + plan.receiptPath + " / SHA256 " + plan.receiptSha + "; new content builds: 0.");
                plan.changes.Add("[Release] product=" + publisher.productId + "; platform=" + publisher.target + "; channel=" + publisher.channel + "; authority=" + publisher.authorityId + "; family=" + publisher.compatibilityFamily + "; deploymentSequence=" + publisher.deploymentSequence + ". No sequence is allocated by the Editor.");
                plan.changes.Add("[Publisher] SHA256 " + plan.anchor.publisherSha256 + "; Catalog bytes/URI remain unchanged. All required SDK Bundle files are included.");
                foreach (var file in files) plan.changes.Add("[Create only] " + Path.Combine(plan.PayloadDirectory, file.path) + " / " + file.bytes + " bytes / SHA256 " + file.sha256);
                plan.changes.Add("[Proof only / outside app payload] Exact Revision receipt SHA " + plan.receiptSha + (plan.sourceBootReceiptSha == null ? "; no original paired Boot supplied. Current Boot must be the same validation generation or this combination is blocked." : "; original paired Boot SHA " + plan.sourceBootReceiptSha));
                plan.changes.Add("[Config] revisionRelease -> reviewed values; packagedRevisionMetadataPath -> " + ProjectRelativePackagedPath(Path.Combine(plan.PayloadDirectory, "packaged_revision.json")) + "; packagedRevisionMetadataSha256 -> " + plan.anchorSha);
                plan.changes.Add("[Player] Official Split Player packaging adds this exact payload to StreamingAssets/" + PackagedRevisionStreamingRoot + ". Runtime must copy/verify to owned storage before confirmation; no direct StreamingAssets fallback.");
            }
            catch (Exception error) { plan.errors.Add(error.Message); }
            return plan;
        }

        public static string ApplyPackagedRevisionPlan(ManagedAddressableProjectConfig config, ManagedPackagedRevisionPlan plan)
        {
            if (plan == null || !plan.CanApply || config == null || EditorUtility.IsDirty(config) || EditorJsonUtility.ToJson(config) != plan.configJson ||
                SplitFileHash(AssetDatabase.GetAssetPath(config)) != plan.configFileSha ||
                plan.anchor.target != EditorUserBuildSettings.activeBuildTarget.ToString() || plan.playerVersion != PlayerSettings.bundleVersion ||
                JsonUtility.ToJson(plan.anchor, true) != plan.anchorJson || SplitFileHash(plan.receiptPath) != plan.receiptSha ||
                (plan.sourceBootReceiptPath != null && SplitFileHash(plan.sourceBootReceiptPath) != plan.sourceBootReceiptSha) || Directory.Exists(plan.outputDirectory))
                throw new InvalidOperationException("Packaged A plan is stale/blocked or its create-only output exists. Preview again; no files were copied.");
            foreach (var file in plan.anchor.files.Where(file => file.source != null))
                if (new FileInfo(file.source).Length != file.bytes || SplitFileHash(file.source) != file.sha256)
                    throw new InvalidOperationException("Packaged A source changed after Preview: " + file.source);
            Directory.CreateDirectory(plan.outputDirectory);
            string proof = Path.Combine(plan.outputDirectory, "Proof"); Directory.CreateDirectory(proof);
            File.Copy(plan.receiptPath, Path.Combine(proof, "Revision.json"), false);
            if (plan.sourceBootReceiptPath != null) File.Copy(plan.sourceBootReceiptPath, Path.Combine(proof, "Boot.json"), false);
            foreach (var file in plan.anchor.files)
            {
                string path = Path.Combine(plan.PayloadDirectory, file.path); Directory.CreateDirectory(Path.GetDirectoryName(path));
                if (file.source != null) File.Copy(file.source, path, false);
                else using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { byte[] bytes = new UTF8Encoding(false).GetBytes(plan.publisherJson); stream.Write(bytes, 0, bytes.Length); }
                if (new FileInfo(path).Length != file.bytes || SplitFileHash(path) != file.sha256) throw new IOException("Packaged A copy failed exact verification: " + path);
            }
            string metadata = Path.Combine(plan.PayloadDirectory, "packaged_revision.json");
            using (var stream = new FileStream(metadata, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) writer.Write(plan.anchorJson);
            // Validate all bytes before linking Config. An incomplete create-only output
            // remains unreferenced evidence, never an accepted packaged source.
            string sha = SplitFileHash(metadata);
            if (sha != plan.anchorSha) throw new IOException("Packaged A anchor differs from the reviewed SHA.");
            ValidatePackagedRevision(metadata, sha);
            string configPath = AssetDatabase.GetAssetPath(config); byte[] configBytes = File.ReadAllBytes(configPath);
            try
            {
                config.revisionRelease = plan.release.Copy(); config.packagedRevisionMetadataPath = ProjectRelativePackagedPath(metadata); config.packagedRevisionMetadataSha256 = sha;
                EditorUtility.SetDirty(config); AssetDatabase.SaveAssetIfDirty(config);
                if (EditorUtility.IsDirty(config)) throw new IOException("Packaged A Config link was not saved.");
            }
            catch (Exception error)
            {
                try
                {
                    File.WriteAllBytes(configPath, configBytes); EditorJsonUtility.FromJsonOverwrite(plan.configJson, config); EditorUtility.ClearDirty(config);
                    if (!File.ReadAllBytes(configPath).SequenceEqual(configBytes) || EditorJsonUtility.ToJson(config) != plan.configJson)
                        throw new IOException("Original Config restoration is uncertain.");
                }
                catch (Exception restore) { throw new AggregateException("Packaged A Config link failed and could not be restored; this output must not be packaged.", error, restore); }
                throw;
            }
            return metadata;
        }

        private static string SplitBytesHash(byte[] bytes)
        {
            using (var hash = System.Security.Cryptography.SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }

        private static string ValidatePackagedRevision(string metadataPath, string expectedSha)
        {
            if (string.IsNullOrWhiteSpace(metadataPath) || string.IsNullOrWhiteSpace(expectedSha) || SplitFileHash(metadataPath) != expectedSha)
                throw new InvalidOperationException("Packaged Revision anchor is missing or differs from the reviewed SHA.");
            var anchor = JsonUtility.FromJson<ManagedPackagedRevisionAnchor>(File.ReadAllText(metadataPath));
            if (anchor == null || anchor.schemaVersion != 1 || anchor.target != EditorUserBuildSettings.activeBuildTarget.ToString() ||
                anchor.catalogRelativePath != "catalog.json" || anchor.publisherRelativePath != "publisher.json" || anchor.bundleRelativeRoot != "bundles" || anchor.files == null)
                throw new InvalidOperationException("Packaged Revision anchor/target/path contract mismatch.");
            string root = Path.GetDirectoryName(Path.GetFullPath(metadataPath));
            var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(Path.Combine(root, "publisher.json")));
            if (publisher == null || anchor.publisherSha256 != SplitFileHash(Path.Combine(root, "publisher.json")) || publisher.target != anchor.target || publisher.revisionId != anchor.revisionId ||
                publisher.productId != anchor.productId || publisher.channel != anchor.channel || publisher.authorityId != anchor.authorityId || publisher.compatibilityFamily != anchor.compatibilityFamily || publisher.deploymentSequence != anchor.deploymentSequence)
                throw new InvalidOperationException("Packaged Revision publisher/anchor identity mismatch.");
            ApplyReleaseMetadata(new ManagedRevisionPublisher(), new ManagedRevisionReleaseMetadata { productId = anchor.productId, channel = anchor.channel, authorityId = anchor.authorityId, compatibilityFamily = anchor.compatibilityFamily, deploymentSequence = anchor.deploymentSequence });
            var expected = new Dictionary<string, (string sha, long bytes)>(StringComparer.Ordinal) {
                ["catalog.json"] = (publisher.catalogSha256, publisher.catalogBytes), ["publisher.json"] = (anchor.publisherSha256, new FileInfo(Path.Combine(root, "publisher.json")).Length) };
            foreach (var row in publisher.bundles) expected.Add("bundles/" + row.fileName, (row.fileSha256, row.bytes));
            if (anchor.files.Count != expected.Count || anchor.files.Select(file => file.path).Distinct(StringComparer.Ordinal).Count() != expected.Count)
                throw new InvalidOperationException("Packaged Revision inventory is incomplete/ambiguous.");
            foreach (var file in anchor.files)
            {
                if (file == null || !expected.TryGetValue(file.path, out var value) || value.sha != file.sha256 || value.bytes <= 0 || file.bytes != value.bytes || file.path.Split('/').Any(part => part == "..") || Path.IsPathRooted(file.path))
                    throw new InvalidOperationException("Packaged Revision inventory path/SHA mismatch.");
                string path = Path.Combine(root, file.path);
                if (new FileInfo(path).Length != file.bytes || SplitFileHash(path) != file.sha256) throw new IOException("Packaged Revision payload differs: " + path);
            }
            var actual = Directory.GetFiles(root, "*", SearchOption.AllDirectories).Select(path => path.Substring(root.Length + 1).Replace('\\', '/')).OrderBy(path => path, StringComparer.Ordinal);
            if (!actual.SequenceEqual(expected.Keys.Append("packaged_revision.json").OrderBy(path => path, StringComparer.Ordinal)))
                throw new InvalidOperationException("Packaged Revision payload contains unreviewed files.");
            ReadPackagedReceiptProof(metadataPath, anchor.sourceRevisionReceiptSha256, "Revision");
            if (!string.IsNullOrEmpty(anchor.sourceBootReceiptSha256)) ReadPackagedReceiptProof(metadataPath, anchor.sourceBootReceiptSha256, "Boot");
            return expectedSha;
        }

        internal static string ProjectRelativePackagedPath(string path)
        {
            string root = Path.GetFullPath(".").TrimEnd('/', '\\') + Path.DirectorySeparatorChar;
            string absolute = Path.GetFullPath(path);
            var comparison = Application.platform == RuntimePlatform.WindowsEditor ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
            if (!absolute.StartsWith(root, comparison)) throw new InvalidOperationException("New packaged output must be inside the project: " + path);
            return absolute.Substring(root.Length).Replace('\\', '/');
        }

        internal static void RequirePackagedRevisionLink(ManagedAddressableProjectConfig config)
        {
            if (config == null || string.IsNullOrWhiteSpace(config.packagedRevisionMetadataPath) || string.IsNullOrWhiteSpace(config.packagedRevisionMetadataSha256))
                throw new InvalidOperationException("BootstrapSplit Player에는 앱 포함 A가 필수입니다. Control Center > App Included Revision > Preview Packaged Revision A / APPLY REVIEWED PACKAGED A에서 연결하세요. 생산 우회 옵션은 없습니다.");
        }

        public static string PreparePackagedRevisionForPlayer(ManagedAddressableProjectConfig config, BuildPlayerContext context, string currentBootReceiptPath)
        {
            if (context == null || config == null)
                throw new InvalidOperationException("Packaged Revision staging requires a Project Config and the official Player build context.");
            RequirePackagedRevisionLink(config);
            var stage = ValidatePlayerStaging(config);
            if (!stage.CanBuild) throw new InvalidOperationException(stage.ToString());
            if (string.IsNullOrWhiteSpace(currentBootReceiptPath) || SplitFileHash(currentBootReceiptPath) != SplitFileHash(SplitStagePointer()))
                throw new InvalidOperationException("The supplied Boot receipt is not the actual current verified SDK stage. No packaged Revision was registered.");
            string sha = ValidatePackagedRevision(config.packagedRevisionMetadataPath, config.packagedRevisionMetadataSha256);
            ValidatePackagedRevisionAgainstBoot(config, currentBootReceiptPath);
            string destination = Path.Combine(Application.streamingAssetsPath, PackagedRevisionStreamingRoot);
            if (Directory.Exists(destination) || File.Exists(destination)) throw new InvalidOperationException("Existing StreamingAssets conflicts with the explicitly packaged Revision root: " + destination);
            context.AddAdditionalPathToStreamingAssets(Path.GetDirectoryName(Path.GetFullPath(config.packagedRevisionMetadataPath)), PackagedRevisionStreamingRoot);
            return sha;
        }

        private static ManagedSplitBuildReceipt ReadPackagedReceiptProof(string metadataPath, string expectedSha, string purpose)
        {
            string path = Path.Combine(Path.GetDirectoryName(Path.GetDirectoryName(Path.GetFullPath(metadataPath))), "Proof", purpose + ".json");
            if (string.IsNullOrEmpty(expectedSha) || SplitFileHash(path) != expectedSha)
                throw new InvalidOperationException("Packaged source receipt proof is missing or changed: " + purpose);
            var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(path)); RequirePackagedReceiptFacts(receipt, purpose); return receipt;
        }

        private static void RequirePackagedReceiptFacts(ManagedSplitBuildReceipt receipt, string purpose)
        {
            if (receipt == null || receipt.schemaVersion != 1 || receipt.mode != "BootstrapSplit" || !receipt.complete || !receipt.rawSettingsRestored || !receipt.effectiveSettingsRestored ||
                receipt.purpose != purpose || receipt.catalogFormat != (purpose == "Boot" ? "binary" : "json") ||
                string.IsNullOrWhiteSpace(receipt.contentFingerprint) || string.IsNullOrWhiteSpace(receipt.configAssetGuid) || string.IsNullOrWhiteSpace(receipt.settingsAssetGuid) ||
                string.IsNullOrWhiteSpace(receipt.effectiveInput) || string.IsNullOrWhiteSpace(receipt.catalogSha256) || string.IsNullOrWhiteSpace(receipt.addressablesVersion) || string.IsNullOrWhiteSpace(receipt.unityVersion) ||
                receipt.keys == null || receipt.commonLabels == null || receipt.exclusiveRoleKeys == null || receipt.bundles == null || receipt.bundles.Count == 0 ||
                receipt.bundles.Any(bundle => bundle == null || string.IsNullOrEmpty(bundle.bundleName) || string.IsNullOrEmpty(bundle.sha256)))
                throw new InvalidOperationException("Receipt facts are insufficient to verify this Boot/Revision combination. Rebuild Revision against the current Boot: " + purpose);
        }

        private static bool SamePackagedValidationGeneration(ManagedSplitBuildReceipt a, ManagedSplitBuildReceipt b) =>
            a.contentFingerprint == b.contentFingerprint && a.configAssetGuid == b.configAssetGuid && a.settingsAssetGuid == b.settingsAssetGuid &&
            a.effectiveInput == b.effectiveInput && a.platform == b.platform && a.unityVersion == b.unityVersion && a.addressablesVersion == b.addressablesVersion;

        internal static string ValidatePackagedBootFacts(ManagedSplitBuildReceipt revision, ManagedSplitBuildReceipt currentBoot, ManagedSplitBuildReceipt sourcePairedBoot)
        {
            RequirePackagedReceiptFacts(revision, "Revision"); RequirePackagedReceiptFacts(currentBoot, "Boot");
            var common = new HashSet<string>(revision.commonLabels.Intersect(currentBoot.commonLabels, StringComparer.Ordinal), StringComparer.Ordinal);
            var unproven = revision.keys.Intersect(currentBoot.keys, StringComparer.Ordinal).Where(key => !common.Contains(key)).OrderBy(key => key, StringComparer.Ordinal).ToArray();
            if (unproven.Length != 0)
                throw new InvalidOperationException("공유 label로 증명되지 않은 키 교집합으로 해당 Boot/Revision 혼용을 검증할 수 없습니다. 현재 Boot 기준 Revision 재제작이 필요합니다: " + string.Join(", ", unproven));
            if (SamePackagedValidationGeneration(revision, currentBoot)) return "SameValidationGeneration";
            if (sourcePairedBoot != null)
            {
                RequirePackagedReceiptFacts(sourcePairedBoot, "Boot");
                string Bundle(ManagedSplitBundleReceipt bundle) => JsonConvert.SerializeObject(new { bundle.bundleName, bundle.hash, bundle.crc, bundle.sourceHash, bundle.sourceCrc, bundle.sha256, fileName = Path.GetFileName(bundle.filePath) });
                if (SamePackagedValidationGeneration(revision, sourcePairedBoot) && sourcePairedBoot.platform == currentBoot.platform &&
                    sourcePairedBoot.unityVersion == currentBoot.unityVersion && sourcePairedBoot.addressablesVersion == currentBoot.addressablesVersion &&
                    sourcePairedBoot.catalogSha256 == currentBoot.catalogSha256 &&
                    sourcePairedBoot.bundles.Select(Bundle).OrderBy(value => value, StringComparer.Ordinal).SequenceEqual(currentBoot.bundles.Select(Bundle).OrderBy(value => value, StringComparer.Ordinal)))
                    return "UnchangedPairedBootContent";
            }
            throw new InvalidOperationException("검증 세대가 다르며 원래 짝 Boot의 Catalog/Bundle 동일성 증거가 없어 해당 혼용을 검증할 수 없습니다. 현재 Boot 기준 Revision 재제작이 필요합니다.");
        }

        private static string ValidatePackagedRevisionAgainstBoot(ManagedAddressableProjectConfig config, string currentBootReceiptPath)
        {
            var anchor = JsonUtility.FromJson<ManagedPackagedRevisionAnchor>(File.ReadAllText(config.packagedRevisionMetadataPath));
            var revision = ReadPackagedReceiptProof(config.packagedRevisionMetadataPath, anchor.sourceRevisionReceiptSha256, "Revision");
            var paired = string.IsNullOrEmpty(anchor.sourceBootReceiptSha256) ? null : ReadPackagedReceiptProof(config.packagedRevisionMetadataPath, anchor.sourceBootReceiptSha256, "Boot");
            return ValidatePackagedBootFacts(revision, JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(currentBootReceiptPath)), paired);
        }
    }
}
