using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor
{
    internal static partial class ManagedAddressableSynchronizer
    {
        // Ownership is an explicit asset-GUID list. Names, roots and schema values never confer ownership.
        internal static List<string> OwnershipWarnings(ManagedAddressableProjectConfig config, AddressableAssetSettings settings)
        {
            var warnings = new List<string>();
            if (config.ownedGroupGuids == null || config.ownedGroupGuids.Count == 0)
                warnings.Add("No Groups have been explicitly adopted. Existing previously generated Groups stay external until an ownership Preview/Apply; their registration policies will not be reapplied.");
            foreach (string guid in config.ownedGroupGuids ?? new List<string>())
            {
                string path = AssetDatabase.GUIDToAssetPath(guid ?? string.Empty);
                AddressableAssetGroup group = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(path);
                if (group == null) warnings.Add("Missing owned Group GUID: " + (guid ?? "<null>") + ". Preserved; select explicit missing-ownership cleanup to remove it.");
                else if (settings == null || !settings.groups.Contains(group))
                    warnings.Add("Owned Group is outside the selected Settings: " + group.Name + " / " + guid + ". Preserved and not modified.");
            }
            return warnings;
        }

        public static ManagedAddressableSyncPlan CreateOwnershipPlan(ManagedAddressableProjectConfig config,
            IEnumerable<AddressableAssetGroup> adoptGroups = null, IEnumerable<string> releaseGroupGuids = null, bool removeMissing = false)
        {
            CheckSyncState(config);
            ValidateSyncPaths(config);
            AddressableAssetSettings settings = AddressableAssetSettingsDefaultObject.Settings;
            var before = new List<string>(config.ownedGroupGuids ?? new List<string>());
            var after = new List<string>(before);
            var changes = new List<ManagedAddressableSyncChange>();
            foreach (AddressableAssetGroup group in adoptGroups ?? Array.Empty<AddressableAssetGroup>())
            {
                if (group == null || settings == null || !settings.groups.Contains(group))
                    throw new InvalidOperationException("Adoption must select an existing Group in the current Settings.");
                string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
                if (string.IsNullOrEmpty(guid)) throw new InvalidOperationException("Save the Group asset before adopting it: " + group.Name);
                if (after.Any(value => string.Equals(value, guid, StringComparison.OrdinalIgnoreCase))) continue;
                after.Add(guid);
                changes.Add(new ManagedAddressableSyncChange("Group", group.Name, "Config ownership (asset GUID)", "external: " + guid, "explicitly owned: " + guid));
            }
            foreach (string guid in releaseGroupGuids ?? Array.Empty<string>())
            {
                if (after.RemoveAll(value => string.Equals(value, guid, StringComparison.OrdinalIgnoreCase)) == 0) continue;
                changes.Add(new ManagedAddressableSyncChange("Group", guid ?? "<null>", "Config ownership", "owned", "released; Group/Entry/schema unchanged"));
            }
            if (removeMissing)
            {
                foreach (string guid in after.ToArray())
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid ?? string.Empty);
                    if (!string.IsNullOrEmpty(path) && AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(path) != null) continue;
                    after.Remove(guid);
                    changes.Add(new ManagedAddressableSyncChange("Group", guid ?? "<null>", "Missing ownership reference", "retained", "explicitly removed from Config only"));
                }
            }
            List<string> warnings = OwnershipWarnings(config, settings);
            var report = CustomPlanReport(changes, new List<string>(), warnings);
            report.messages.Add("[Ownership] This plan changes only Config ownership. Group GUIDs, entries, addresses, schemas, Profiles and Global settings are unchanged.");
            return new ManagedAddressableSyncPlan(SyncFingerprint(config, settings), false,
                new List<ManagedAddressableSyncPlan.GroupAddition>(), new List<ManagedAddressableSyncPlan.EntryChange>(),
                changes, new List<string>(), report, warnings, changes.Count == 0 ? null : after);
        }

        public static ManagedAddressableSyncPlan CreateRevisionBuildPlan(ManagedAddressableProjectConfig config)
        {
            CheckSyncState(config);
            ValidateSyncPaths(config);
            AddressableAssetSettings settings = AddressableAssetSettingsDefaultObject.Settings;
            var changes = new List<ManagedAddressableSyncChange>();
            var blocked = new List<string>();
            var warnings = OwnershipWarnings(config, settings);
            var policies = new List<ManagedAddressableSyncPlan.GroupPolicyChange>();
            if (settings == null) blocked.Add("Create and review Addressables Settings before configuring a Revision deployment.");
            else foreach (AddressableAssetGroup group in settings.groups.Where(g => g != null && config.OwnsGroup(g)))
            {
                BundledAssetGroupSchema schema = group.GetSchema<BundledAssetGroupSchema>();
                if (schema == null || !schema.IncludeInBuild || !IsHttpPath(schema.LoadPath.GetValue(settings))) continue;
                if (schema.UseDefaultSchemaSettings)
                {
                    warnings.Add("Owned Group uses SDK default schema settings: " + group.Name + ". No overrides are changed; configure an explicit override in the official Inspector if needed.");
                    continue;
                }
                bool differs = !schema.UseAssetBundleCache || !schema.UseAssetBundleCrc || schema.UseAssetBundleCrcForCachedBundles ||
                    schema.AssetBundledCacheClearBehavior != BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache;
                if (!differs) continue;
                if (group.ReadOnly) { blocked.Add("Revision policy would modify a read-only owned Group: " + group.Name); continue; }
                if ((schema.Group != null && schema.Group != group) || settings.groups.Any(other => other != null && other != group && other.Schemas.Any(s => s == schema || (s != null && AssetDatabase.GetAssetPath(s) == AssetDatabase.GetAssetPath(schema)))))
                {
                    blocked.Add("Revision policy schema is shared with another Group: " + group.Name + ". Separate the schema explicitly in the official Inspector; Sync will not alter the other Group.");
                    continue;
                }
                AddPolicyDiff(changes, group.Name, "UseAssetBundleCache", schema.UseAssetBundleCache, true);
                AddPolicyDiff(changes, group.Name, "UseAssetBundleCrc", schema.UseAssetBundleCrc, true);
                AddPolicyDiff(changes, group.Name, "UseAssetBundleCrcForCachedBundles", schema.UseAssetBundleCrcForCachedBundles, false);
                if (schema.AssetBundledCacheClearBehavior != BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache)
                    changes.Add(new ManagedAddressableSyncChange("Group", group.Name, "AssetBundledCacheClearBehavior", schema.AssetBundledCacheClearBehavior.ToString(), BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache.ToString()));
                policies.Add(new ManagedAddressableSyncPlan.GroupPolicyChange(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group))));
            }
            var report = CustomPlanReport(changes, blocked, warnings);
            report.messages.Add("[Revision Policy] Explicitly owned HTTP(S) Groups only: cache enabled, CRC enabled excluding cached, retain other versions. Local Groups, filenames, paths, Profiles and Global settings are preserved.");
            return new ManagedAddressableSyncPlan(SyncFingerprint(config, settings), false,
                new List<ManagedAddressableSyncPlan.GroupAddition>(), new List<ManagedAddressableSyncPlan.EntryChange>(),
                changes, blocked, report, warnings, policies: policies);
        }

        private static void AddPolicyDiff(List<ManagedAddressableSyncChange> changes, string group, string property, bool before, bool after)
        {
            if (before != after) changes.Add(new ManagedAddressableSyncChange("Group", group, property, before.ToString(), after.ToString()));
        }

        internal static bool IsHttpPath(string path) => Uri.TryCreate(path, UriKind.Absolute, out Uri uri) && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);

        private static ManagedAddressableSyncReport CustomPlanReport(List<ManagedAddressableSyncChange> changes, List<string> blocked, List<string> warnings)
        {
            var report = new ManagedAddressableSyncReport();
            foreach (string scope in new[] { "Group", "Entry", "Profile", "Global" }) report.messages.Add("[Planned " + scope + " Changes] " + changes.Count(c => c.scope == scope));
            report.messages.AddRange(changes.Select(c => c.ToString()));
            report.messages.AddRange(warnings.Select(w => "[Warning] " + w));
            report.messages.AddRange(blocked.Select(b => "[Blocked] " + b));
            return report;
        }
    }
}
