using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using Artress.ManagedAddressables;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    internal static partial class ManagedAddressableBuildExporter
    {
        internal static void ValidateReleaseMetadata(ManagedRevisionReleaseMetadata release) => ApplyReleaseMetadata(new ManagedRevisionPublisher(), release);

        public static ManagedSplitBuildReport ValidateRevisionReleasePrebuild(ManagedAddressableProjectConfig config)
        {
            var report = new ManagedSplitBuildReport();
            try
            {
                if (config == null) throw new InvalidOperationException("Select a Project Config.");
                ValidateReleaseMetadata(config.revisionRelease);
                report.warnings.AddRange(RevisionSequenceWarnings(config, config.revisionRelease));
            }
            catch (Exception error) { report.errors.Add("Revision 빌드 전 Control Center의 Release Metadata에서 명시 값을 Preview/Apply하세요. " + error.Message); }
            return report;
        }

        internal static IEnumerable<string> RevisionSequenceWarnings(ManagedAddressableProjectConfig config, ManagedRevisionReleaseMetadata release)
        {
            var warnings = new List<string>();
            if (config == null || release == null) return warnings;
            try
            {
                string root = Path.Combine(SplitOutputRoot(config), "revision");
                long previous = 0;
                if (Directory.Exists(root)) foreach (string path in Directory.GetFiles(root, "split_build_receipt.json", SearchOption.AllDirectories))
                {
                    var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(path));
                    if (receipt == null || !receipt.complete || receipt.purpose != "Revision" || string.IsNullOrEmpty(receipt.publisherPath) || !File.Exists(receipt.publisherPath) || SplitFileHash(receipt.publisherPath) != receipt.publisherSha256) continue;
                    var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(receipt.publisherPath));
                    if (publisher != null && publisher.productId == release.productId && publisher.channel == release.channel && publisher.authorityId == release.authorityId && publisher.compatibilityFamily == release.compatibilityFamily)
                        previous = Math.Max(previous, publisher.deploymentSequence);
                }
                if (previous > 0 && release.deploymentSequence <= previous)
                    warnings.Add("Deployment sequence " + release.deploymentSequence + " is not above a previous completed receipt's sequence " + previous + " in this output. Server authority remains canonical; build is not blocked and no sequence is allocated.");
            }
            catch (Exception error) { warnings.Add("Previous release sequence could not be checked: " + error.Message); }
            return warnings;
        }

        internal static string MostRecentRevisionReceipt(ManagedAddressableProjectConfig config)
        {
            try
            {
                string root = Path.Combine(SplitOutputRoot(config), "revision");
                return Directory.Exists(root) ? Directory.GetFiles(root, "split_build_receipt.json", SearchOption.AllDirectories)
                    .OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault(path =>
                    {
                        try { var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(path)); return receipt != null && receipt.complete && receipt.rawSettingsRestored && receipt.effectiveSettingsRestored && receipt.purpose == "Revision"; }
                        catch { return false; }
                    }) : null;
            }
            catch { return null; }
        }

        // The existing Split inspectors are the producer authority for keys, physical layout,
        // SDK Bundle options and file SHA. No second Catalog parser or ownership database.
        private static void WriteRevisionPublisher(ManagedSplitBuildReceipt receipt, ManagedRevisionReleaseMetadata release)
        {
            if (!receipt.complete || !receipt.rawSettingsRestored || !receipt.effectiveSettingsRestored || receipt.purpose != ManagedGroupBuildRole.Revision.ToString() || receipt.catalogFormat != "json")
                throw new InvalidOperationException("Only a fully verified/restored Revision build can emit a publisher.");
            var rows = receipt.bundles.Select(bundle => new ManagedRevisionPublisherBundle
            {
                fileName = Path.GetFileName(bundle.filePath), fileSha256 = bundle.sha256,
                bytes = new FileInfo(bundle.filePath).Length, sdkBundleName = bundle.bundleName, sdkHash = bundle.hash, crc = bundle.crc
            }).OrderBy(row => row.fileName, StringComparer.Ordinal).ToArray();
            if (rows.Length == 0 || rows.Select(row => row.fileName).Distinct(StringComparer.Ordinal).Count() != rows.Length ||
                rows.Select(row => row.sdkBundleName + "|" + row.sdkHash).Distinct(StringComparer.Ordinal).Count() != rows.Length)
                throw new InvalidOperationException("Publisher cannot bind ambiguous Bundle filenames/SDK identities.");
            var publisher = new ManagedRevisionPublisher
            {
                schemaVersion = 1, revisionId = receipt.stamp, target = receipt.platform,
                catalogFile = Path.GetFileName(receipt.catalogPath), catalogSha256 = receipt.catalogSha256,
                catalogBytes = new FileInfo(receipt.catalogPath).Length, bundles = rows
            };
            ApplyReleaseMetadata(publisher, release);
            string json = JsonUtility.ToJson(publisher, true);
            string path = Path.Combine(Path.GetDirectoryName(receipt.catalogPath), "revision_publisher.json");
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) writer.Write(json);
            receipt.publisherPath = path; receipt.publisherSha256 = SplitFileHash(path);
        }

        private static void ApplyReleaseMetadata(ManagedRevisionPublisher publisher, ManagedRevisionReleaseMetadata release)
        {
            if (release == null || release.deploymentSequence <= 0 ||
                new[] { release.productId, release.channel, release.authorityId, release.compatibilityFamily }.Any(string.IsNullOrWhiteSpace))
                throw new InvalidOperationException("A Revision publisher requires explicit productId/channel/authorityId/compatibilityFamily and a positive deploymentSequence from the same deployment authority.");
            publisher.productId = release.productId; publisher.channel = release.channel;
            publisher.authorityId = release.authorityId; publisher.compatibilityFamily = release.compatibilityFamily;
            publisher.deploymentSequence = release.deploymentSequence;
        }
    }
}
