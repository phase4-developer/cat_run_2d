using System;
using UnityEditor;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    public sealed partial class ManagedAddressablesWindow
    {
        private ManagedAddressableProjectConfig packagedDraftConfig;
        private ManagedRevisionReleaseMetadata packagedReleaseDraft;
        private string packagedReceiptDraft;
        private string packagedSourceBootReceiptDraft;
        private ManagedPackagedRevisionPlan reviewedPackagedPlan;

        private void DrawPackagedRevisionSection()
        {
            if (packagedDraftConfig != config || packagedReleaseDraft == null)
            {
                packagedDraftConfig = config;
                packagedReleaseDraft = config.revisionRelease?.Copy() ?? new ManagedRevisionReleaseMetadata();
                packagedReceiptDraft = ManagedAddressableBuildExporter.MostRecentRevisionReceipt(config);
            }
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Release Metadata (before Revision build)", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("같은 배포 주체가 원격 Revision과 앱 포함 A에 부여한 값을 입력합니다. 순번은 자동 생성하지 않습니다. 검증된 Revision receipt의 실제 Catalog/Bundle을 변경 없이 포함하며 SDK 콘텐츠 재빌드는 수행하지 않습니다. Save 호환성은 제품 출시 검증의 책임입니다.", MessageType.Info);
            packagedReleaseDraft.productId = EditorGUILayout.TextField("Product ID", packagedReleaseDraft.productId);
            packagedReleaseDraft.channel = EditorGUILayout.TextField("Channel", packagedReleaseDraft.channel);
            packagedReleaseDraft.authorityId = EditorGUILayout.TextField("Deployment authority", packagedReleaseDraft.authorityId);
            packagedReleaseDraft.compatibilityFamily = EditorGUILayout.TextField("Compatibility family", packagedReleaseDraft.compatibilityFamily);
            packagedReleaseDraft.deploymentSequence = EditorGUILayout.LongField("Deployment sequence", packagedReleaseDraft.deploymentSequence);
            if (GUILayout.Button("Preview Release Metadata"))
                RunCustomPreview(() => ManagedAddressableSynchronizer.CreateRevisionReleasePlan(config, packagedReleaseDraft));
            if (GUILayout.Button("Reload Release Draft")) packagedReleaseDraft = config.revisionRelease?.Copy() ?? new ManagedRevisionReleaseMetadata();
            EditorGUILayout.HelpBox("Revision 빌드 전에 Release Metadata를 Preview → APPLY REVIEWED PLAN으로 저장합니다. 순번이 이전 완료 산출물 이하이면 경고하며 자동 증가시키지 않습니다.", MessageType.Info);
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("allowDevelopmentHttp"), new GUIContent("Allow Development HTTP"));
            EditorGUILayout.LabelField("App Included Revision A", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal();
            packagedReceiptDraft = EditorGUILayout.TextField("Verified Revision receipt", packagedReceiptDraft);
            if (GUILayout.Button("Select", GUILayout.Width(65)))
            {
                string selected = EditorUtility.OpenFilePanel("Verified split_build_receipt.json", "", "json");
                if (!string.IsNullOrEmpty(selected)) packagedReceiptDraft = selected;
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            packagedSourceBootReceiptDraft = EditorGUILayout.TextField("Original paired Boot receipt", packagedSourceBootReceiptDraft);
            if (GUILayout.Button("Select", GUILayout.Width(65)))
            {
                string selected = EditorUtility.OpenFilePanel("Original paired Boot split_build_receipt.json", "", "json");
                if (!string.IsNullOrEmpty(selected)) packagedSourceBootReceiptDraft = selected;
            }
            EditorGUILayout.EndHorizontal();
            EditorGUI.BeginDisabledGroup(buildInProgress);
            if (GUILayout.Button("Preview Packaged Revision A"))
            {
                reviewedPackagedPlan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, packagedReceiptDraft, packagedReleaseDraft, packagedSourceBootReceiptDraft);
                resultText = reviewedPackagedPlan.ToString();
            }
            if (GUILayout.Button("APPLY REVIEWED PACKAGED A"))
            {
                try
                {
                    // Edits to the visible draft require a new review too.
                    if (reviewedPackagedPlan == null || JsonUtility.ToJson(packagedReleaseDraft) != JsonUtility.ToJson(reviewedPackagedPlan.release) ||
                        string.IsNullOrWhiteSpace(packagedReceiptDraft) || System.IO.Path.GetFullPath(packagedReceiptDraft) != reviewedPackagedPlan.receiptPath ||
                        (string.IsNullOrWhiteSpace(packagedSourceBootReceiptDraft) ? null : System.IO.Path.GetFullPath(packagedSourceBootReceiptDraft)) != reviewedPackagedPlan.sourceBootReceiptPath)
                        throw new InvalidOperationException("Packaged A draft changed. Preview again.");
                    resultText = "Packaged Revision created and linked: " + ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, reviewedPackagedPlan);
                    serializedConfig.Update(); reviewedPackagedPlan = null;
                }
                catch (Exception error) { resultText = error.ToString(); }
            }
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.LabelField("Player packaged anchor", config.packagedRevisionMetadataPath ?? "(none)", EditorStyles.wordWrappedLabel);
        }
    }
}
