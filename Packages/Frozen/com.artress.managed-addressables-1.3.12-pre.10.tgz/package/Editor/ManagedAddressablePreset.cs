using System;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine.ResourceManagement.ResourceProviders;

namespace Artress.ManagedAddressables.Editor
{
    internal static class ManagedAddressablePreset
    {
        private const string DuplicateAssetIsolationGroupName = "Duplicate Asset Isolation";

        public static AddressableAssetSettings GetOrCreateSettings()
        {
            return AddressableAssetSettingsDefaultObject.GetSettings(true);
        }

        public static int ApplyGlobal(AddressableAssetSettings settings, ManagedAddressableProjectConfig config)
        {
            ApplySettingsValues(settings, config);
            int normalizedBundleIdentityGroups = ApplyProjectIndependentBundleIdentity(settings);
            ApplyStableLocalCompatibilityGroups(settings);
            EditorUtility.SetDirty(settings);
            return normalizedBundleIdentityGroups;
        }

        internal static void ApplyInitialSettings(AddressableAssetSettings settings, ManagedAddressableProjectConfig config)
        {
            // SDK-created default and Analyze Groups remain externally owned, even during
            // initial Settings creation. Only explicit new registration Groups get a baseline.
            ApplySettingsValues(settings, config);
            EditorUtility.SetDirty(settings);
        }

        private static void ApplySettingsValues(AddressableAssetSettings settings, ManagedAddressableProjectConfig config)
        {
            ManagedAddressableProfileUtility.EnsureProfile(settings, config);
            settings.BuildRemoteCatalog = true;
            settings.DisableCatalogUpdateOnStartup = true;
            settings.UniqueBundleIds = true;
            settings.NonRecursiveBuilding = false;
            settings.ContiguousBundles = true;
            settings.OptimizeCatalogSize = false;
            settings.IgnoreUnsupportedFilesInBuild = false;
            settings.MaxConcurrentWebRequests = 3;
            settings.CatalogRequestsTimeout = 0;
            settings.OverridePlayerVersion = "[UnityEditor.PlayerSettings.bundleVersion]";
            settings.BuiltInBundleNaming = BuiltInBundleNaming.DefaultGroupGuid;
            settings.MonoScriptBundleNaming = MonoScriptBundleNaming.DefaultGroupGuid;
            settings.RemoteCatalogBuildPath.SetVariableByName(settings, ManagedAddressableProfileUtility.RemoteBuildPath);
            settings.RemoteCatalogLoadPath.SetVariableByName(settings, ManagedAddressableProfileUtility.RemoteLoadPath);

            int packedModeIndex = ManagedAddressableReflection.FindPackedModeBuilderIndex(settings);
            if (packedModeIndex >= 0)
                settings.ActivePlayerDataBuilderIndex = packedModeIndex;

            SetBuildWithPlayerDisabled(settings);
        }

        internal static bool IsStableLocalCompatibilityGroup(AddressableAssetSettings settings, AddressableAssetGroup group)
        {
            if (settings == null || group == null)
                return false;

            if (ReferenceEquals(settings.DefaultGroup, group))
                return true;

            string groupName = group.Name ?? string.Empty;
            if (string.Equals(groupName, DuplicateAssetIsolationGroupName, StringComparison.OrdinalIgnoreCase))
                return true;
            if (!groupName.StartsWith(DuplicateAssetIsolationGroupName, StringComparison.OrdinalIgnoreCase))
                return false;

            string suffix = groupName.Substring(DuplicateAssetIsolationGroupName.Length);
            if (suffix.Length == 0)
                return true;

            foreach (char value in suffix)
            {
                if (!char.IsDigit(value))
                    return false;
            }

            return true;
        }

        public static bool ApplyGroup(AddressableAssetSettings settings, AddressableAssetGroup group, ManagedDeliveryMode delivery, BundledAssetGroupSchema.BundlePackingMode bundleMode, bool repairSharedSchemas = true)
        {
            bool repairedSharedSchemas = repairSharedSchemas && EnsureUniqueGroupSchemas(settings, group);
            BundledAssetGroupSchema bundled = group.GetSchema<BundledAssetGroupSchema>() ?? group.AddSchema<BundledAssetGroupSchema>(false);
            ContentUpdateGroupSchema update = group.GetSchema<ContentUpdateGroupSchema>() ?? group.AddSchema<ContentUpdateGroupSchema>(false);
            bool remote = delivery != ManagedDeliveryMode.Local;

            bundled.UseDefaultSchemaSettings = false;
            bundled.BuildPath.SetVariableByName(settings, remote ? ManagedAddressableProfileUtility.RemoteBuildPath : ManagedAddressableProfileUtility.LocalBuildPath);
            bundled.LoadPath.SetVariableByName(settings, remote ? ManagedAddressableProfileUtility.RemoteLoadPath : ManagedAddressableProfileUtility.LocalLoadPath);
            bundled.Compression = BundledAssetGroupSchema.BundleCompressionMode.LZ4;
            bundled.BundleMode = bundleMode;
            bundled.InternalIdNamingMode = BundledAssetGroupSchema.AssetNamingMode.FullPath;
            bundled.IncludeAddressInCatalog = true;
            bundled.IncludeGUIDInCatalog = true;
            bundled.IncludeLabelsInCatalog = true;
            bundled.IncludeInBuild = true;
            // Same policy as CreateRevisionBuildPlan: a Revision Bundle needs the SDK cache Hash and keeps other versions.
            bundled.UseAssetBundleCache = remote;
            bundled.UseAssetBundleCrc = remote;
            bundled.UseAssetBundleCrcForCachedBundles = false;
            bundled.AssetBundledCacheClearBehavior = BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache;
            bundled.UseUnityWebRequestForLocalBundles = false;
            bundled.ForceUniqueProvider = false;
            bundled.Timeout = 0;
            bundled.RedirectLimit = -1;
            bundled.RetryCount = 0;
            bundled.ChunkedTransfer = false;
            bundled.AssetLoadMode = AssetLoadMode.RequestedAssetAndDependencies;
            ApplyBundleIdentity(bundled);
            update.StaticContent = !remote;

            EditorUtility.SetDirty(bundled);
            EditorUtility.SetDirty(update);
            EditorUtility.SetDirty(group);
            return repairedSharedSchemas;
        }

        public static int ApplyProjectIndependentBundleIdentity(AddressableAssetSettings settings)
        {
            int changedGroups = 0;
            foreach (AddressableAssetGroup group in settings.groups)
            {
                if (group == null)
                    continue;

                BundledAssetGroupSchema bundled = group.GetSchema<BundledAssetGroupSchema>();
                if (bundled == null || !ApplyBundleIdentity(bundled))
                    continue;

                EditorUtility.SetDirty(group);
                changedGroups++;
            }

            return changedGroups;
        }

        private static void ApplyStableLocalCompatibilityGroups(AddressableAssetSettings settings)
        {
            foreach (AddressableAssetGroup group in settings.groups)
            {
                if (!IsStableLocalCompatibilityGroup(settings, group))
                    continue;

                BundledAssetGroupSchema bundled = group.GetSchema<BundledAssetGroupSchema>();
                if (bundled == null)
                    continue;

                bool changed = false;
                if (bundled.UseAssetBundleCache)
                {
                    bundled.UseAssetBundleCache = false;
                    changed = true;
                }
                if (bundled.UseAssetBundleCrc)
                {
                    bundled.UseAssetBundleCrc = false;
                    changed = true;
                }
                if (bundled.UseAssetBundleCrcForCachedBundles)
                {
                    bundled.UseAssetBundleCrcForCachedBundles = false;
                    changed = true;
                }
                if (bundled.UseUnityWebRequestForLocalBundles)
                {
                    bundled.UseUnityWebRequestForLocalBundles = false;
                    changed = true;
                }

                if (!changed)
                    continue;

                EditorUtility.SetDirty(bundled);
                EditorUtility.SetDirty(group);
            }
        }

        private static bool ApplyBundleIdentity(BundledAssetGroupSchema bundled)
        {
            bool changed = false;
            if (bundled.BundleNaming != BundledAssetGroupSchema.BundleNamingStyle.NoHash)
            {
                bundled.BundleNaming = BundledAssetGroupSchema.BundleNamingStyle.NoHash;
                changed = true;
            }

            if (bundled.InternalBundleIdMode != BundledAssetGroupSchema.BundleInternalIdMode.GroupGuid)
            {
                bundled.InternalBundleIdMode = BundledAssetGroupSchema.BundleInternalIdMode.GroupGuid;
                changed = true;
            }

            if (changed)
                EditorUtility.SetDirty(bundled);
            return changed;
        }

        private static bool EnsureUniqueGroupSchemas(AddressableAssetSettings settings, AddressableAssetGroup group)
        {
            if (settings == null || group == null)
                return false;

            BundledAssetGroupSchema bundled = group.GetSchema<BundledAssetGroupSchema>();
            ContentUpdateGroupSchema update = group.GetSchema<ContentUpdateGroupSchema>();
            bool bundledShared = IsSchemaShared(settings, group, bundled);
            bool updateShared = IsSchemaShared(settings, group, update);

            if (!bundledShared && !updateShared)
                return false;

            if (bundled != null)
                group.RemoveSchema<BundledAssetGroupSchema>(false);
            if (update != null)
                group.RemoveSchema<ContentUpdateGroupSchema>(false);

            group.AddSchema<BundledAssetGroupSchema>(false);
            group.AddSchema<ContentUpdateGroupSchema>(false);
            EditorUtility.SetDirty(group);
            return true;
        }

        private static bool IsSchemaShared(AddressableAssetSettings settings, AddressableAssetGroup owner, AddressableAssetGroupSchema schema)
        {
            if (schema == null)
                return false;

            if (schema.Group != null && schema.Group != owner)
                return true;

            string schemaPath = AssetDatabase.GetAssetPath(schema);
            foreach (AddressableAssetGroup otherGroup in settings.groups)
            {
                if (otherGroup == null || otherGroup == owner)
                    continue;

                foreach (AddressableAssetGroupSchema otherSchema in otherGroup.Schemas)
                {
                    if (otherSchema == null || otherSchema.GetType() != schema.GetType())
                        continue;
                    if (ReferenceEquals(otherSchema, schema))
                        return true;

                    string otherPath = AssetDatabase.GetAssetPath(otherSchema);
                    if (!string.IsNullOrEmpty(schemaPath) && string.Equals(schemaPath, otherPath, StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }

            return false;
        }

        private static void SetBuildWithPlayerDisabled(AddressableAssetSettings settings)
        {
            object current = ManagedAddressableReflection.GetMember(settings, "BuildAddressablesWithPlayerBuild");
            if (current == null || !current.GetType().IsEnum)
                return;

            Type enumType = current.GetType();
            foreach (string name in Enum.GetNames(enumType))
            {
                if (name.IndexOf("DoNot", StringComparison.OrdinalIgnoreCase) >= 0 || name.IndexOf("Disabled", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ManagedAddressableReflection.SetMember(settings, "BuildAddressablesWithPlayerBuild", Enum.Parse(enumType, name));
                    return;
                }
            }
        }
    }
}
