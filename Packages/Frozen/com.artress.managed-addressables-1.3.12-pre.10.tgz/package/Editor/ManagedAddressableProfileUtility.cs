using System.Collections.Generic;
using UnityEditor.AddressableAssets.Settings;

namespace Artress.ManagedAddressables.Editor
{
    internal static class ManagedAddressableProfileUtility
    {
        public const string BuildTarget = "BuildTarget";
        public const string BuildVersion = "BuildVersion";
        public const string LocalBuildPath = "Local.BuildPath";
        public const string LocalLoadPath = "Local.LoadPath";
        public const string RemoteBuildPath = "Remote.BuildPath";
        public const string RemoteLoadPath = "Remote.LoadPath";

        // The SDK's own unset value. It is not a URL, so Revision validation blocks until the project sets its HTTPS root.
        private const string UnsetRemoteLoadPath = "<undefined>";

        internal static Dictionary<string, string> InitialValues(ManagedAddressableProjectConfig config)
        {
            string root = string.IsNullOrWhiteSpace(config.buildOutputRoot) ? "ServerData" : config.buildOutputRoot.Trim().TrimEnd('/', '\\').Replace('\\', '/');
            return new Dictionary<string, string>
            {
                { BuildTarget, "[UnityEditor.EditorUserBuildSettings.activeBuildTarget]" },
                { BuildVersion, "[UnityEditor.PlayerSettings.bundleVersion]" },
                { LocalBuildPath, "[UnityEngine.AddressableAssets.Addressables.BuildPath]/[BuildTarget]" },
                { LocalLoadPath, "{UnityEngine.AddressableAssets.Addressables.RuntimePath}/[BuildTarget]" },
                { RemoteBuildPath, root + "/[BuildTarget]/[BuildVersion]" },
                { RemoteLoadPath, UnsetRemoteLoadPath }
            };
        }

        public static string EnsureProfile(AddressableAssetSettings settings, ManagedAddressableProjectConfig config)
        {
            AddressableAssetProfileSettings profiles = settings.profileSettings;
            string name = string.IsNullOrWhiteSpace(config.profileName) ? "Artress Managed" : config.profileName.Trim();
            string profileId = profiles.GetProfileId(name);

            if (string.IsNullOrEmpty(profileId))
                profileId = profiles.AddProfile(name, settings.activeProfileId);

            foreach (KeyValuePair<string, string> pair in InitialValues(config))
            {
                EnsureVariable(profiles, pair.Key, pair.Value);
                if (profiles.GetValueByName(profileId, pair.Key) != pair.Value) profiles.SetValue(profileId, pair.Key, pair.Value);
            }

            settings.activeProfileId = profileId;
            return profileId;
        }

        private static void EnsureVariable(AddressableAssetProfileSettings profiles, string name, string defaultValue)
        {
            List<string> names = profiles.GetVariableNames();
            if (!names.Contains(name))
                profiles.CreateValue(name, defaultValue);
        }
    }
}
