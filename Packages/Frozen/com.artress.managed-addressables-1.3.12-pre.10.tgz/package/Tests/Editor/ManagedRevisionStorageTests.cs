using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // File-contract unit tests use opaque bytes. Actual UnityFS/SDK Catalog integration is separate.
    [Platform("Win")]
    public sealed class ManagedRevisionStorageTests
    {
        private ManagedAddressableRevisionStorage store;
        private string root, input;
        private static readonly BindingFlags Hidden = BindingFlags.Instance | BindingFlags.NonPublic;
        private static string Sha(byte[] bytes) { using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        private static object Field(object value, string name) => value.GetType().GetField(name).GetValue(value);
        private static object Property(object value, string name) => value.GetType().GetProperty(name, Hidden).GetValue(value);
        // Await the fault without blocking Unity's main synchronization context.
        // ThrowsAsync previously required an exact exception type; preserve it.
        private static async Task<T> ThrowsExactlyAsync<T>(Func<Task> action) where T : Exception
        {
            try { await action(); }
            catch (Exception error)
            {
                Assert.That(error, Is.TypeOf<T>());
                return (T)error;
            }
            Assert.Fail("Expected exception " + typeof(T).FullName + ", but the operation completed without an exception.");
            return null;
        }

        // Only former CatchAsync sites accept derived exception types.
        private static async Task<T> CatchDerivedAsync<T>(Func<Task> action) where T : Exception
        {
            try { await action(); }
            catch (Exception error)
            {
                Assert.That(error, Is.InstanceOf<T>());
                return (T)error;
            }
            Assert.Fail("Expected exception " + typeof(T).FullName + ", but the operation completed without an exception.");
            return null;
        }

        private static async Task<object> Call(object value, string method, params object[] args)
        {
            Task operation;
            try { operation = (Task)value.GetType().GetMethod(method, Hidden).Invoke(value, args); }
            catch (TargetInvocationException error) when (error.InnerException != null)
            { ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
            await operation;
            return operation.GetType().GetProperty("Result")?.GetValue(operation);
        }
        [SetUp] public void SetUp()
        {
            string id = Guid.NewGuid().ToString("N"); store = new ManagedAddressableRevisionStorage("StorageQA_" + id, 0);
            root = (string)Property(store, "RootDirectory"); input = Path.Combine(Application.temporaryCachePath, "StorageInput_" + id); Directory.CreateDirectory(input);
        }
        [TearDown] public void TearDown()
        {
            string app = Path.GetFullPath(Application.persistentDataPath).TrimEnd('/', '\\') + Path.DirectorySeparatorChar;
            Assert.That(Path.GetFullPath(root).StartsWith(app, StringComparison.OrdinalIgnoreCase), Is.True);
            Assert.That(Path.GetFullPath(input).StartsWith(Path.GetFullPath(Application.temporaryCachePath).TrimEnd('/', '\\') + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase), Is.True);
            if (Directory.Exists(root)) Directory.Delete(root, true);
            if (Directory.Exists(input)) Directory.Delete(input, true);
        }
        private ManagedAddressableRevision Source(string id)
        {
            string directory = Path.Combine(input, id); Directory.CreateDirectory(directory);
            byte[] bundle = Encoding.UTF8.GetBytes("opaque bundle " + id), catalog = Encoding.UTF8.GetBytes("opaque SDK-owned catalog " + id);
            File.WriteAllBytes(Path.Combine(directory, "content.bundle"), bundle); File.WriteAllBytes(Path.Combine(directory, "catalog.json"), catalog);
            var publisher = new ManagedRevisionPublisher { revisionId = id, target = "StandaloneWindows64", catalogFile = "catalog.json", catalogSha256 = Sha(catalog), catalogBytes = catalog.Length,
                productId = "product", channel = "test", authorityId = "test-authority", compatibilityFamily = "F", deploymentSequence = 1,
                bundles = new[] { new ManagedRevisionPublisherBundle { fileName = "content.bundle", fileSha256 = Sha(bundle), bytes = bundle.Length, sdkBundleName = "opaque-" + id, sdkHash = "11111111111111111111111111111111", crc = 0 } } };
            byte[] metadata = Encoding.UTF8.GetBytes(JsonUtility.ToJson(publisher)); string publisherPath = Path.Combine(directory, "publisher.json"); File.WriteAllBytes(publisherPath, metadata);
            return new ManagedAddressableRevision(id, Path.Combine(directory, "catalog.json"), publisherPath, Sha(metadata), "StandaloneWindows64");
        }
        private async Task<object> Prepare(ManagedAddressableRevision revision)
        {
            object files = await Call(store, "PrepareCatalogAsync", revision, CancellationToken.None);
            await PrepareBindings(files, revision);
            return files;
        }
        private async Task PrepareBindings(object files, ManagedAddressableRevision revision, string originalId = null)
        {
            var pub = (ManagedRevisionPublisher)Field(files, "Publisher"); Type type = store.GetType().Assembly.GetType("Artress.ManagedAddressables.ManagedRevisionBundleBinding", true);
            Array bindings = Array.CreateInstance(type, pub.bundles.Length);
            for (int i = 0; i < pub.bundles.Length; i++)
            {
                var row = pub.bundles[i]; string path = Path.Combine(Path.GetDirectoryName(revision.CatalogPath), row.fileName);
                var location = new ResourceLocationBase(row.fileName, originalId ?? path, typeof(AssetBundleProvider).FullName, typeof(IAssetBundleResource))
                { Data = new AssetBundleRequestOptions { BundleName = row.sdkBundleName, Hash = row.sdkHash, Crc = row.crc, BundleSize = row.bytes } };
                object binding = Activator.CreateInstance(type); type.GetField("Location").SetValue(binding, location); type.GetField("CanonicalUri").SetValue(binding, new Uri(path).AbsoluteUri); type.GetField("Bundle").SetValue(binding, row); bindings.SetValue(binding, i);
            }
            await Call(store, "PrepareBundlesAsync", files, bindings, true, CancellationToken.None);
        }
        private async Task<ManagedRevisionCommitOutcome> Commit(object files)
            => (ManagedRevisionCommitOutcome)Field(await Call(store, "CommitConfirmedAsync", files, CancellationToken.None), "Outcome");

        private ManagedAddressableRevision DeploymentSource(string id, long sequence)
        {
            var source = Source(id);
            var p = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(source.PublisherPath));
            p.productId = "product"; p.channel = "test"; p.authorityId = "test-authority"; p.compatibilityFamily = "F"; p.deploymentSequence = sequence;
            byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(p)); File.WriteAllBytes(source.PublisherPath, bytes);
            return new ManagedAddressableRevision(id, source.CatalogPath, source.PublisherPath, Sha(bytes), p.target);
        }

        [Test] public void NamespaceCannotEscapeApplicationStorage()
        {
            Assert.Throws<ArgumentException>(() => new ManagedAddressableRevisionStorage("../other"));
            Assert.Throws<ArgumentException>(() => new ManagedAddressableRevisionStorage(Path.GetTempPath()));
        }
        [Test] public async Task PublisherShaMismatchDoesNotCreateConfirmation()
        {
            var source = Source("A"); File.AppendAllText(source.PublisherPath, "tampered");
            await ThrowsExactlyAsync<IOException>(async () => await Call(store, "PrepareCatalogAsync", source, CancellationToken.None));
            Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.False);
            await Task.CompletedTask;
        }
        [Test] public async Task ConfirmedRoundTripUsesOwnedBytesWithoutSources()
        {
            object files = await Prepare(Source("A")); Assert.That(await Commit(files), Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            Directory.Delete(input, true);
            object read = await Call(store, "ReadConfirmedAsync", CancellationToken.None);
            Assert.That(((ManagedAddressableRevision)Field(read, "Revision")).RevisionId, Is.EqualTo("A"));
            Assert.That((int)Property(store, "LastBundleShaChecks"), Is.Zero);
            Assert.That((int)Property(store, "LastCatalogShaChecks"), Is.Zero);
        }
        [Test] public async Task MissingPointerRequiresRecoveryWithoutImplicitSeed()
        {
            await ThrowsExactlyAsync<FileNotFoundException>(async () => await Call(store, "ReadConfirmedAsync", CancellationToken.None));
            Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.False);
        }
        [Test] public async Task DeclaredCapacityPreflightRejectsBeforeCatalogAndPreservesA()
        {
            object a = await Prepare(Source("A")); await Commit(a); byte[] before = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            var source = Source("B"); var metadata = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(source.PublisherPath));
            metadata.bundles[0].bytes = long.MaxValue / 4; byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(metadata)); File.WriteAllBytes(source.PublisherPath, bytes);
            var declared = new ManagedAddressableRevision("B", source.CatalogPath, source.PublisherPath, Sha(bytes), "StandaloneWindows64");
            var error = await ThrowsExactlyAsync<IOException>(async () => await Call(store, "PrepareCatalogAsync", declared, CancellationToken.None));
            Assert.That(error.Message, Does.Contain("InsufficientOwnedRevisionSpace"));
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(before));
        }
        [Test] public async Task ActualDirectoryWritePreconditionFailurePreservesAAndDoesNotLeaveStoreBusy()
        {
            object a = await Prepare(Source("A")); await Commit(a); byte[] before = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            string temp = Path.Combine(root, "tmp"); Directory.Delete(temp, false); File.WriteAllText(temp, "own actual filesystem blocker");
            try { await ThrowsExactlyAsync<IOException>(async () => await Call(store, "PrepareCatalogAsync", Source("B"), CancellationToken.None)); }
            finally { File.Delete(temp); Directory.CreateDirectory(temp); }
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(before));
            Assert.That(await Prepare(Source("C")), Is.Not.Null);
        }
        [Test] public async Task BootIsLightweightAndErrorVerificationDetectsEqualLengthCorruption()
        {
            object files = await Prepare(Source("A")); Assert.That(await Commit(files), Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            var publisher = (ManagedRevisionPublisher)Field(files, "Publisher"); string blob = Path.Combine(root, "blobs/StandaloneWindows64", publisher.bundles[0].fileSha256 + ".bundle");
            byte[] corrupt = File.ReadAllBytes(blob); corrupt[0] ^= 1; File.WriteAllBytes(blob, corrupt);
            object read = await Call(store, "ReadConfirmedAsync", CancellationToken.None);
            Assert.That((int)Property(store, "LastBundleShaChecks"), Is.Zero);
            await ThrowsExactlyAsync<InvalidDataException>(async () => await Call(store, "VerifyAsync", read, true, CancellationToken.None));
            Assert.That((int)Property(store, "LastBundleShaChecks"), Is.EqualTo(1));
        }
        [Test] public async Task CatalogBootIsLightweightAndErrorVerificationDetectsEqualLengthCorruption()
        {
            object files = await Prepare(Source("A")); Assert.That(await Commit(files), Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            string catalog = (string)Field(files, "CatalogLocalPath"); byte[] corrupt = File.ReadAllBytes(catalog); corrupt[0] ^= 1; File.WriteAllBytes(catalog, corrupt);
            object read = await Call(store, "ReadConfirmedAsync", CancellationToken.None);
            Assert.That((int)Property(store, "LastCatalogShaChecks"), Is.Zero);
            Assert.That((int)Property(store, "LastBundleShaChecks"), Is.Zero);
            await ThrowsExactlyAsync<InvalidDataException>(async () => await Call(store, "VerifyAsync", read, true, CancellationToken.None));
            Assert.That((int)Property(store, "LastCatalogShaChecks"), Is.EqualTo(1));
        }
        [TestCase("catalogBytes")]
        [TestCase("productId")]
        [TestCase("compatibilityFamily")]
        [TestCase("deploymentSequence")]
        public async Task PublisherWithoutRequiredFieldIsRejected(string field)
        {
            var source = Source("A"); var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(source.PublisherPath));
            var member = typeof(ManagedRevisionPublisher).GetField(field); member.SetValue(publisher, member.FieldType == typeof(long) ? (object)0L : null);
            byte[] metadata = Encoding.UTF8.GetBytes(JsonUtility.ToJson(publisher)); File.WriteAllBytes(source.PublisherPath, metadata);
            source = new ManagedAddressableRevision("A", source.CatalogPath, source.PublisherPath, Sha(metadata), "StandaloneWindows64");
            var error = await CatchDerivedAsync<Exception>(async () => await Call(store, "PrepareCatalogAsync", source, CancellationToken.None));
            Assert.That(error.Message, Does.Contain("PublisherHeaderMismatch"));
            Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.False);
        }
        [Test] public async Task MissingConfirmedBundleDoesNotSelectAnOlderRevision()
        {
            object a = await Prepare(Source("A")); await Commit(a); object b = await Prepare(Source("B")); await Commit(b);
            byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json")); var pub = (ManagedRevisionPublisher)Field(b, "Publisher"); File.Delete(Path.Combine(root, "blobs/StandaloneWindows64", pub.bundles[0].fileSha256 + ".bundle"));
            await ThrowsExactlyAsync<InvalidDataException>(async () => await Call(store, "ReadConfirmedAsync", CancellationToken.None));
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
        }
        [Test] public async Task LockedPointerReturnsUnchangedAndPreservesA()
        {
            object a = await Prepare(Source("A")); await Commit(a); object b = await Prepare(Source("B"));
            string path = Path.Combine(root, "confirmed.json"); byte[] before = File.ReadAllBytes(path);
            using (var locked = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                Assert.That(await Commit(b), Is.EqualTo(ManagedRevisionCommitOutcome.Unchanged));
            Assert.That(File.ReadAllBytes(path), Is.EqualTo(before));
        }
        [Test] public async Task UnexpectedPointerBytesAreUncertainAndNeverRewritten()
        {
            object a = await Prepare(Source("A")); await Commit(a); object b = await Prepare(Source("B"));
            string path = Path.Combine(root, "confirmed.json"); byte[] unexpected = Encoding.UTF8.GetBytes("unexpected actual pointer"); File.WriteAllBytes(path, unexpected);
            Assert.That(await Commit(b), Is.EqualTo(ManagedRevisionCommitOutcome.Uncertain));
            Assert.That(File.ReadAllBytes(path), Is.EqualTo(unexpected));
        }
        [Test] public async Task UnreadablePointerReturnsUncertainWithoutClaimingAcknowledgement()
        {
            object a = await Prepare(Source("A")); await Commit(a); object b = await Prepare(Source("B"));
            using (var locked = new FileStream(Path.Combine(root, "confirmed.json"), FileMode.Open, FileAccess.Read, FileShare.None))
                Assert.That(await Commit(b), Is.EqualTo(ManagedRevisionCommitOutcome.Uncertain));
        }
        [Test] public async Task CandidateVerificationFailureReturnsUnchangedOnlyWithExactOldPointer()
        {
            object a = await Prepare(Source("A")); await Commit(a); object b = await Prepare(Source("B"));
            byte[] before = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            var publisher = (ManagedRevisionPublisher)Field(b, "Publisher"); File.Delete(Path.Combine(root, "blobs/StandaloneWindows64", publisher.bundles[0].fileSha256 + ".bundle"));
            Assert.That(await Commit(b), Is.EqualTo(ManagedRevisionCommitOutcome.Unchanged));
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(before));
        }
        [Test] public async Task CleanupKeepsConfirmedAndExplicitPreparedFilesAndRemovesOnlyOwnedGarbage()
        {
            object a = await Prepare(Source("A")); await Commit(a); object b = await Prepare(Source("B")); await Commit(b); object c = await Prepare(Source("C"));
            string pointer = Path.Combine(root, "confirmed.json"); byte[] before = File.ReadAllBytes(pointer);
            string temporary = Path.Combine(root, "tmp", "t-" + Guid.NewGuid().ToString("N") + ".tmp"); File.WriteAllText(temporary, "interrupted");
            await Call(store, "CleanupApplicationStartupAsync", b, new[] { (string)Field(c, "PublisherSha256") }, CancellationToken.None);
            var rows = new[] { a, b, c }.Select(f => ((ManagedRevisionPublisher)Field(f, "Publisher")).bundles[0]).ToArray();
            Assert.That(File.Exists(Path.Combine(root, "blobs/StandaloneWindows64", rows[0].fileSha256 + ".bundle")), Is.False);
            Assert.That(rows.Skip(1).All(row => File.Exists(Path.Combine(root, "blobs/StandaloneWindows64", row.fileSha256 + ".bundle"))), Is.True);
            Assert.That(File.Exists(temporary), Is.False); Assert.That(File.ReadAllBytes(pointer), Is.EqualTo(before));
            Assert.That(Directory.Exists((string)Field(a, "MetadataDirectory")), Is.False);
            Assert.That(Directory.Exists((string)Field(b, "MetadataDirectory")), Is.True);
            Assert.That(Directory.Exists((string)Field(c, "MetadataDirectory")), Is.True);
        }
        [Test] public async Task AmbiguousBlobInventorySkipsDeletionAndKeepsConfirmation()
        {
            object a = await Prepare(Source("A")); await Commit(a); object b = await Prepare(Source("B")); await Commit(b);
            string sentinel = Path.Combine(root, "blobs/StandaloneWindows64/sentinel.user"); File.WriteAllText(sentinel, "preserve");
            await Call(store, "CleanupApplicationStartupAsync", b, Array.Empty<string>(), CancellationToken.None);
            Assert.That((string)Property(store, "LastCleanupWarning"), Does.Contain("Ambiguous"));
            Assert.That(Directory.GetFiles(Path.Combine(root, "blobs/StandaloneWindows64"), "*.bundle").Length, Is.EqualTo(2));
            Assert.That(File.ReadAllText(sentinel), Is.EqualTo("preserve"));
        }

        [Test] public async Task ApplicationCleanupKeepsHighestPartialPublisherWithoutConfirmingIt()
        {
            object a = await Prepare(DeploymentSource("A", 10)); await Commit(a);
            object b = await Prepare(DeploymentSource("B", 20));
            object c = await Call(store, "PrepareCatalogAsync", DeploymentSource("C", 30), CancellationToken.None);
            byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            await Call(store, "CleanupApplicationStartupAsync", a, Array.Empty<string>(), CancellationToken.None);
            Assert.That(Directory.Exists((string)Field(b, "MetadataDirectory")), Is.False);
            Assert.That(Directory.Exists((string)Field(c, "MetadataDirectory")), Is.True);
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
            var read = await Call(store, "ReadConfirmedAsync", CancellationToken.None);
            Assert.That(((ManagedAddressableRevision)Field(read, "Revision")).RevisionId, Is.EqualTo("A"));
            Assert.That((string)Property(store, "LastCleanupWarning"), Is.Empty);
        }

        [Test] public async Task InterruptedMetadataWriteLeavesThePublisherAndCleanupStillRuns()
        {
            object a = await Prepare(DeploymentSource("A", 10)); await Commit(a);
            object old = await Prepare(DeploymentSource("Old", 5));
            var interrupted = DeploymentSource("B", 20);
            string directory = Path.Combine(root, "revisions", interrupted.ExpectedPublisherSha256), catalog = Path.Combine(directory, "catalog.json");
            Directory.CreateDirectory(catalog); // Actual move failure on the second metadata write.
            await CatchDerivedAsync<Exception>(async () => await Call(store, "PrepareCatalogAsync", interrupted, CancellationToken.None));
            Directory.Delete(catalog, false);
            Assert.That(File.Exists(Path.Combine(directory, "publisher.json")), Is.True);
            await Call(store, "CleanupApplicationStartupAsync", a, Array.Empty<string>(), CancellationToken.None);
            Assert.That((string)Property(store, "LastCleanupWarning"), Is.Empty);
            Assert.That(Directory.Exists((string)Field(old, "MetadataDirectory")), Is.False);
            Assert.That(Directory.Exists(directory), Is.True, "The partial candidate is the highest deployment and is kept.");
        }

        [Test] public async Task CatalogWithoutPublisherIsRemovedAndDoesNotStopCleanup()
        {
            object a = await Prepare(DeploymentSource("A", 10)); await Commit(a);
            object old = await Prepare(DeploymentSource("Old", 5));
            string orphan = Path.Combine(root, "revisions", new string('a', 64)); Directory.CreateDirectory(orphan);
            File.WriteAllText(Path.Combine(orphan, "catalog.json"), "interrupted");
            await Call(store, "CleanupApplicationStartupAsync", a, Array.Empty<string>(), CancellationToken.None);
            Assert.That((string)Property(store, "LastCleanupWarning"), Is.Empty);
            Assert.That(Directory.Exists(orphan), Is.False);
            Assert.That(Directory.Exists((string)Field(old, "MetadataDirectory")), Is.False);
        }

        [Test] public async Task UnreadableCandidatePublisherSkipsAllUnconfirmedCleanup()
        {
            object a = await Prepare(DeploymentSource("A", 10)); await Commit(a);
            object b = await Prepare(DeploymentSource("B", 20));
            string unknown = Path.Combine(root, "revisions", new string('a', 64)); Directory.CreateDirectory(unknown);
            File.WriteAllText(Path.Combine(unknown, "publisher.json"), "interrupted or corrupted");
            await Call(store, "CleanupApplicationStartupAsync", a, Array.Empty<string>(), CancellationToken.None);
            Assert.That((string)Property(store, "LastCleanupWarning"), Does.Contain("StoredPublisherShaMismatch"));
            Assert.That(Directory.Exists((string)Field(b, "MetadataDirectory")), Is.True);
            Assert.That(Directory.GetFiles(Path.Combine(root, "blobs/StandaloneWindows64")).Length, Is.EqualTo(2));
        }

        [Test] public async Task TiedHighestCandidateAnchorsSkipCleanupInsteadOfGuessing()
        {
            object a = await Prepare(DeploymentSource("A", 10)); await Commit(a);
            object b = await Prepare(DeploymentSource("B", 20)); object c = await Prepare(DeploymentSource("C", 20));
            await Call(store, "CleanupApplicationStartupAsync", a, Array.Empty<string>(), CancellationToken.None);
            Assert.That((string)Property(store, "LastCleanupWarning"), Does.Contain("AmbiguousHighestPrepared"));
            Assert.That(Directory.Exists((string)Field(b, "MetadataDirectory")), Is.True);
            Assert.That(Directory.Exists((string)Field(c, "MetadataDirectory")), Is.True);
        }

        [Test] public async Task UnconfirmedCorruptBlobAndPartialMetadataAreReacquiredWithoutChangingA()
        {
            object a = await Prepare(Source("A")); await Commit(a); byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            var source = Source("B"); object b = await Prepare(source);
            var row = ((ManagedRevisionPublisher)Field(b, "Publisher")).bundles[0];
            string blob = Path.Combine(root, "blobs/StandaloneWindows64", row.fileSha256 + ".bundle");
            byte[] corrupt = File.ReadAllBytes(blob); corrupt[0] ^= 1; File.WriteAllBytes(blob, corrupt);
            File.WriteAllText((string)Field(b, "CatalogLocalPath"), "partial");
            await Prepare(source);
            Assert.That(Sha(File.ReadAllBytes(blob)), Is.EqualTo(row.fileSha256));
            Assert.That(File.ReadAllBytes((string)Field(b, "CatalogLocalPath")), Is.EqualTo(File.ReadAllBytes(source.CatalogPath)));
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
        }

        [TestCase(false)]
        [TestCase(true)]
        public async Task StoredPublisherCorruptionWithCatalogIsHealedOnlyForUnconfirmedMetadata(bool confirmed)
        {
            object a = await Prepare(Source("A")); await Commit(a);
            byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            var source = Source(confirmed ? "A" : "B"); object files = confirmed ? a : await Prepare(source);
            string publisher = Path.Combine((string)Field(files, "MetadataDirectory"), "publisher.json");
            string catalog = (string)Field(files, "CatalogLocalPath"); byte[] beforeCatalog = File.ReadAllBytes(catalog);
            byte[] corrupt = File.ReadAllBytes(publisher); corrupt[0] ^= 1; File.WriteAllBytes(publisher, corrupt);
            Assert.That(File.Exists(catalog), Is.True, "The existing Catalog must enter the stored-metadata branch");
            if (confirmed)
            {
                var failure = await ThrowsExactlyAsync<InvalidDataException>(async () => await Prepare(source));
                Assert.That(failure.Message, Does.Contain("StoredPublisherShaMismatch"));
                Assert.That(File.ReadAllBytes(publisher), Is.EqualTo(corrupt), "Ordinary preparation cannot repair confirmation");
            }
            else
            {
                await Prepare(source);
                Assert.That(File.ReadAllBytes(publisher), Is.EqualTo(File.ReadAllBytes(source.PublisherPath)));
            }
            Assert.That(File.ReadAllBytes(catalog), Is.EqualTo(beforeCatalog));
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
        }

        [Test] public async Task OrdinaryPrepareCannotOverwriteACorruptConfirmedBlob()
        {
            var source = Source("A"); object a = await Prepare(source); await Commit(a);
            var row = ((ManagedRevisionPublisher)Field(a, "Publisher")).bundles[0];
            string blob = Path.Combine(root, "blobs/StandaloneWindows64", row.fileSha256 + ".bundle");
            byte[] corrupt = File.ReadAllBytes(blob); corrupt[0] ^= 1; File.WriteAllBytes(blob, corrupt);
            var error = await ThrowsExactlyAsync<InvalidDataException>(async () => await Prepare(source));
            Assert.That(error.Message, Does.Contain("ConfirmedBundleRequiresRepair"));
            Assert.That(File.ReadAllBytes(blob), Is.EqualTo(corrupt));
        }

        [TestCase("publisher", false)]
        [TestCase("catalog", false)]
        [TestCase("bundle", false)]
        [TestCase("publisher", true)]
        [TestCase("catalog", true)]
        [TestCase("bundle", true)]
        public async Task SameAnchorRepairRecreatesMissingOrCorruptFilesWithoutWritingPointer(string missing, bool corrupt)
        {
            var source = Source("A"); object a = await Prepare(source); await Commit(a);
            byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            var row = ((ManagedRevisionPublisher)Field(a, "Publisher")).bundles[0];
            string blob = Path.Combine(root, "blobs/StandaloneWindows64", row.fileSha256 + ".bundle");
            string lost = missing == "publisher" ? Path.Combine((string)Field(a, "MetadataDirectory"), "publisher.json") :
                missing == "catalog" ? (string)Field(a, "CatalogLocalPath") : blob;
            if (corrupt) { byte[] bytes = File.ReadAllBytes(lost); bytes[0] ^= 1; File.WriteAllBytes(lost, bytes); }
            else File.Delete(lost);
            object repair = await Call(store, "PrepareConfirmedRepairAsync", source, CancellationToken.None);
            await PrepareBindings(repair, source);
            await Call(store, "VerifyAsync", repair, true, CancellationToken.None);
            store.GetType().GetMethod("RequireRepairPointerUnchanged", Hidden).Invoke(store, new[] { repair });
            Assert.That(File.Exists(lost), Is.True);
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
        }

        [Test] public async Task RepairRejectsAnotherPublisherEvenWhenConfirmedMetadataIsMissing()
        {
            object a = await Prepare(Source("A")); await Commit(a);
            byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            File.Delete(Path.Combine((string)Field(a, "MetadataDirectory"), "publisher.json"));
            var error = await ThrowsExactlyAsync<InvalidDataException>(async () => await Call(store, "PrepareConfirmedRepairAsync", Source("B"), CancellationToken.None));
            Assert.That(error.Message, Does.Contain("RepairMustMatchConfirmedPublisher"));
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
        }

        [TestCase("missing")]
        [TestCase("malformed")]
        [TestCase("unreadable")]
        public async Task RepairNeverInfersConfirmationFromMetadataWhenThePointerCannotBeRead(string failure)
        {
            var source = Source("A"); object files = await Prepare(source); await Commit(files);
            string pointer = Path.Combine(root, "confirmed.json");
            if (failure == "missing") File.Delete(pointer);
            if (failure == "malformed") File.WriteAllText(pointer, "{}");
            byte[] before = File.Exists(pointer) ? File.ReadAllBytes(pointer) : null;
            using (var held = failure == "unreadable" ? new FileStream(pointer, FileMode.Open, FileAccess.Read, FileShare.None) : null)
                await CatchDerivedAsync<Exception>(async () => await Call(store, "PrepareConfirmedRepairAsync", source, CancellationToken.None));
            Assert.That(File.Exists(pointer) ? File.ReadAllBytes(pointer) : null, Is.EqualTo(before));
            Assert.That(File.Exists((string)Field(files, "CatalogLocalPath")), Is.True);
        }

        [Test] public async Task FileAcquisitionUsesTheBoundCanonicalUriInsteadOfOriginalInternalId()
        {
            var source = Source("A"); object files = await Call(store, "PrepareCatalogAsync", source, CancellationToken.None);
            await PrepareBindings(files, source, "http://127.0.0.1:1/must-not-be-used.bundle");
            Assert.That((long)Property(store, "LastDownloadedBytes"), Is.Zero);
            Assert.That((long)Property(store, "LastCopiedBytes"), Is.GreaterThan(0));
        }

        [Test] public async Task CancelledPreparationReturnsBusyOwnershipBeforeAnotherOperation()
        {
            var source = Source("A"); using (var cancellation = new CancellationTokenSource())
            {
                cancellation.Cancel();
                await ThrowsExactlyAsync<OperationCanceledException>(async () => await Call(store, "PrepareCatalogAsync", source, cancellation.Token));
            }
            Assert.That(await Prepare(source), Is.Not.Null);
        }

        [TestCase("uncertain")]
        [TestCase("late-collision")]
        [TestCase("boundary-throw")]
        [TestCase("boundary-cancel")]
        public async Task RealStoreApplyPreservesConfirmationAcrossGuardFailures(string failure)
        {
            bool lateCandidateCollision = failure == "late-collision";
            bool boundaryFailure = failure == "boundary-throw" || failure == "boundary-cancel";
            object filesA = await Prepare(Source("A")); await Commit(filesA);
            object filesB = await Prepare(Source("B"));
            var session = new ManagedAddressableRevisionSession(store);
            var boot = new ResourceLocationMap("uncertain-boot", 0);
            var a = new ResourceLocationMap("uncertain-A", 0); var b = new ResourceLocationMap("uncertain-B", 0);
            var foreign = new ResourceLocationMap("external-B-only", 0);
            var bOnly = new ResourceLocationBase("B-only", "B-only", "unused-unit-provider", typeof(object));
            b.Add("B-only", bOnly); foreign.Add("B-only", bOnly);
            Type type = typeof(ManagedAddressableRevisionSession), leaseType = type.GetNestedType("CatalogLease", BindingFlags.NonPublic);
            var owner = type.GetField("owner", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.That(owner.GetValue(null), Is.Null);
            object active = Activator.CreateInstance(leaseType, true), candidate = Activator.CreateInstance(leaseType, true);
            foreach (var pair in new[] { new { Lease = active, Files = filesA, Locator = a }, new { Lease = candidate, Files = filesB, Locator = b } })
            {
                leaseType.GetField("Files").SetValue(pair.Lease, pair.Files);
                leaseType.GetField("Revision").SetValue(pair.Lease, Field(pair.Files, "Revision"));
                leaseType.GetField("Locator").SetValue(pair.Lease, pair.Locator);
            }
            var previousTransform = Addressables.InternalIdTransformFunc;
            Func<IResourceLocation, string> transform = location => previousTransform == null ? location.InternalId : previousTransform(location);
            foreach (var pair in new[] { new { Name = "active", Value = active }, new { Name = "prepared", Value = candidate },
                new { Name = "bootLocator", Value = (object)boot }, new { Name = "ownedFlow", Value = (object)true },
                new { Name = "ownedTransform", Value = (object)transform }, new { Name = "previousTransform", Value = (object)previousTransform } })
                type.GetField(pair.Name, Hidden).SetValue(session, pair.Value);
            type.GetField("<State>k__BackingField", Hidden).SetValue(session, ManagedRevisionState.Prepared);
            type.GetField("<LastConfirmedRevision>k__BackingField", Hidden).SetValue(session, Field(filesA, "Revision"));
            owner.SetValue(null, session); Addressables.InternalIdTransformFunc = transform;
            Addressables.AddResourceLocator(boot); Addressables.AddResourceLocator(a);
            byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json"));
            try
            {
                ManagedRevisionResult result;
                int stops = 0, validatedA = 0, validatedB = 0;
                var originalLocators = Addressables.ResourceLocators.ToArray();
                using (var cancellation = new CancellationTokenSource())
                using (var locked = failure == "uncertain" ? new FileStream(Path.Combine(root, "confirmed.json"), FileMode.Open, FileAccess.Read, FileShare.None) : null)
                    result = await session.ApplyAsync(new ManagedRevisionApplyCallbacks(
                        token =>
                        {
                            if (++stops == 1 && lateCandidateCollision) Addressables.AddResourceLocator(foreign);
                            if (failure == "boundary-cancel") { cancellation.Cancel(); token.ThrowIfCancellationRequested(); }
                            if (failure == "boundary-throw") throw new InvalidOperationException("Caller boundary failed before readiness");
                            return Task.FromResult(new ManagedRevisionBoundary(0, 0, 0, 0, true, "opaque file test has no SDK consumers"));
                        },
                        (revision, token) => { if (revision.RevisionId == "A") validatedA++; else validatedB++; return Task.FromResult(true); }), cancellation.Token);
                if (boundaryFailure)
                {
                    Assert.That(result.Success, Is.False); Assert.That(result.Deferred, Is.True);
                    Assert.That(result.RecoveryRequired, Is.False); Assert.That(result.CommitOutcome, Is.Null);
                    Assert.That(session.State, Is.EqualTo(ManagedRevisionState.Prepared)); Assert.That(session.CanStartConsumers, Is.False);
                    Assert.That(session.ActiveRevision.RevisionId, Is.EqualTo("A")); Assert.That(session.PreparedRevision.RevisionId, Is.EqualTo("B"));
                    Assert.That(validatedA + validatedB, Is.Zero); Assert.That(stops, Is.EqualTo(1));
                    Assert.That(Addressables.ResourceLocators.ToArray(), Is.EqualTo(originalLocators));
                    Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
                    Assert.That(session.ResumeCurrentRevision().Success, Is.True);
                    Assert.That(session.CanStartConsumers, Is.True); Assert.That(session.PreparedRevision.RevisionId, Is.EqualTo("B"));
                }
                else if (lateCandidateCollision)
                {
                    Assert.That(validatedB, Is.Zero, "External B key must be rejected before B registration/validation");
                    Assert.That(validatedA, Is.EqualTo(1));
                    Assert.That(result.CommitOutcome, Is.Null);
                    Assert.That(result.RecoveredLastConfirmed, Is.True);
                    Assert.That(session.CanStartConsumers, Is.True);
                    Assert.That(Addressables.ResourceLocators.Any(l => ReferenceEquals(l, a)), Is.True);
                    Assert.That(Addressables.ResourceLocators.Any(l => ReferenceEquals(l, b)), Is.False);
                    Assert.That(Addressables.ResourceLocators.Any(l => ReferenceEquals(l, foreign)), Is.True);
                }
                else
                {
                    Assert.That(result.CommitOutcome, Is.EqualTo(ManagedRevisionCommitOutcome.Uncertain));
                    Assert.That(result.RecoveryRequired, Is.True);
                    Assert.That(result.RecoveredLastConfirmed, Is.False);
                    Assert.That(session.CanStartConsumers, Is.False);
                    Assert.That(Addressables.ResourceLocators.Any(l => ReferenceEquals(l, a) || ReferenceEquals(l, b)), Is.False);
                }
                Assert.That(Addressables.ResourceLocators.Any(l => ReferenceEquals(l, boot)), Is.True);
                Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
            }
            finally
            {
                await session.CloseAsync(token => Task.FromResult(new ManagedRevisionBoundary(0, 0, 0, 0, true, "test cleanup")));
                Addressables.RemoveResourceLocator(boot); Addressables.RemoveResourceLocator(a); Addressables.RemoveResourceLocator(b);
                Addressables.RemoveResourceLocator(foreign);
                Addressables.InternalIdTransformFunc = previousTransform; owner.SetValue(null, null);
            }
        }
    }
}
