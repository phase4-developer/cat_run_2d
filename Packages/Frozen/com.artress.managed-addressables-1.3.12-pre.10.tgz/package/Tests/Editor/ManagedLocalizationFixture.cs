#if MANAGED_TESTS_LOCALIZATION
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEditor.Localization;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // Official Localization authoring inside a split fixture: Locale and basic table in Boot, optional table in Revision.
    internal sealed class ManagedLocalizationFixture : IDisposable
    {
        private readonly string activePath, instancePath;
        private readonly LocalizationSettings instance;

        internal ManagedLocalizationFixture()
        {
            var active = LocalizationEditorSettings.ActiveLocalizationSettings;
            instance = LocalizationSettings.HasSettings ? LocalizationSettings.Instance : null;
            activePath = active == null ? null : AssetDatabase.GetAssetPath(active);
            instancePath = instance == null ? null : AssetDatabase.GetAssetPath(instance);
        }

        public void Dispose()
        {
            LocalizationEditorSettings.ActiveLocalizationSettings = string.IsNullOrEmpty(activePath) ? null : AssetDatabase.LoadAssetAtPath<LocalizationSettings>(activePath);
            LocalizationSettings.Instance = string.IsNullOrEmpty(instancePath) ? instance : AssetDatabase.LoadAssetAtPath<LocalizationSettings>(instancePath);
        }

        internal void AddTo(ManagedBootstrapSplitFixture f)
        {
            var settings = f.Settings;
            var existing = new HashSet<string>(settings.groups.Where(g => g != null).Select(ManagedBootstrapSplitFixture.GuidOf), StringComparer.Ordinal);
            string root = f.Root + "/Localization";
            Directory.CreateDirectory(root + "/Boot");
            Directory.CreateDirectory(root + "/Revision");
            AssetDatabase.Refresh();
            var localization = ScriptableObject.CreateInstance<LocalizationSettings>();
            AssetDatabase.CreateAsset(localization, root + "/LocalizationSettings.asset");
            LocalizationEditorSettings.ActiveLocalizationSettings = localization;
            LocalizationSettings.Instance = localization;
            var locale = Locale.CreateLocale("en");
            AssetDatabase.CreateAsset(locale, root + "/English.asset");
            LocalizationEditorSettings.AddLocale(locale);
            string unique = AssetDatabase.AssetPathToGUID(f.Root);
            var boot = LocalizationEditorSettings.CreateStringTableCollection("Basic_" + unique, root + "/Boot", new[] { locale });
            var revision = LocalizationEditorSettings.CreateStringTableCollection("Game_" + unique, root + "/Revision", new[] { locale });
            var bootTable = boot.StringTables.Single(t => t.LocaleIdentifier.Code == "en");
            var revisionTable = revision.StringTables.Single(t => t.LocaleIdentifier.Code == "en");
            bootTable.AddEntry("message", "BOOT");
            revisionTable.AddEntry("message", "GAME");
            foreach (var value in new UnityEngine.Object[] { bootTable, revisionTable, boot.SharedData, revision.SharedData, localization }) EditorUtility.SetDirty(value);

            var bootGroup = Group(settings, "QA Boot Localization", false);
            var revisionGroup = Group(settings, "QA Revision Localization", true);
            foreach (var asset in new UnityEngine.Object[] { locale, bootTable, boot.SharedData }) Move(settings, asset, bootGroup);
            foreach (var asset in new UnityEngine.Object[] { revisionTable, revision.SharedData }) Move(settings, asset, revisionGroup);

            // Every Group Localization created, including its empty scaffolds, is an explicit fixture input.
            foreach (var group in settings.groups.Where(g => g != null && !existing.Contains(ManagedBootstrapSplitFixture.GuidOf(g))))
            {
                string guid = ManagedBootstrapSplitFixture.GuidOf(group);
                f.Config.groupBuildRoles.Add(new ManagedGroupBuildRoleSetting { groupAssetGuid = guid,
                    role = group == revisionGroup ? ManagedGroupBuildRole.Revision : ManagedGroupBuildRole.Boot });
                if (!f.Config.ownedGroupGuids.Contains(guid)) f.Config.ownedGroupGuids.Add(guid);
            }
            AssetDatabase.SaveAssets();
        }

        private static AddressableAssetGroup Group(AddressableAssetSettings settings, string name, bool remote)
        {
            var group = settings.CreateGroup(name, false, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
            var schema = group.GetSchema<BundledAssetGroupSchema>();
            schema.UseDefaultSchemaSettings = false;
            schema.BundleMode = BundledAssetGroupSchema.BundlePackingMode.PackTogether;
            schema.BuildPath.SetVariableByName(settings, remote ? AddressableAssetSettings.kRemoteBuildPath : AddressableAssetSettings.kLocalBuildPath);
            schema.LoadPath.SetVariableByName(settings, remote ? AddressableAssetSettings.kRemoteLoadPath : AddressableAssetSettings.kLocalLoadPath);
            return group;
        }

        private static void Move(AddressableAssetSettings settings, UnityEngine.Object asset, AddressableAssetGroup target) =>
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(asset)), target, false, false);
    }
}
#endif
