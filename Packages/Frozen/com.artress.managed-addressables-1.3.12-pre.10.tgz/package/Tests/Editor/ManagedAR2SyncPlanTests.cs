using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedAR2SyncPlanTests
    {
        private string root;
        private AddressableAssetSettings settings;
        private AddressableAssetSettings previous;
        private ManagedAddressableProjectConfig config;
        private static readonly FieldInfo DefaultField = typeof(AddressableAssetSettingsDefaultObject).GetField("s_DefaultSettingsObject", BindingFlags.Static | BindingFlags.NonPublic);

        [SetUp]
        public void SetUp()
        {
            previous = AddressableAssetSettingsDefaultObject.Settings;
            ManagedFrameworkHostTests.ImportCallback(previous, false);
            root = "Assets/ManagedAR2Plan_" + Guid.NewGuid().ToString("N");
            Directory.CreateDirectory(root + "/Content");
            AssetDatabase.Refresh();
            settings = AddressableAssetSettings.Create(root + "/Settings", "Settings", false, true);
            DefaultField.SetValue(null, settings);
            settings.CreateGroup("Default", true, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
            config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.SetContentRoot(root + "/Content");
            config.backupBeforeApply = false;
            // An explicitly initialized Managed baseline is separate from Sync.
            ManagedAddressablePreset.ApplyGlobal(settings, config);
            AssetDatabase.SaveAssets();
        }

        [TearDown]
        public void TearDown()
        {
            ManagedFrameworkHostTests.ImportCallback(settings, false);
            DefaultField.SetValue(null, previous);
            if (config != null && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(config))) UnityEngine.Object.DestroyImmediate(config);
            AssetDatabase.DeleteAsset(root);
            ManagedFrameworkHostTests.ImportCallback(previous, true);
        }

        private string Text(string relative)
        {
            string path = root + "/" + relative + ".txt";
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, "neutral AR2 registration fixture");
            AssetDatabase.Refresh();
            return path;
        }

        private AddressableAssetEntry Entry(string path) => settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(path));
        private AddressableAssetGroup Group(string name, bool readOnly = false) => settings.CreateGroup(name, false, readOnly, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
        private Dictionary<string, string> Files() => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(p => p.Replace('\\', '/'), p => Convert.ToBase64String(File.ReadAllBytes(p)));

        [Test]
        public void ReviewedPlanCreatesOnlyNewGroupAndEntriesWithMatchingReport()
        {
            string path = Text("Content/Remote/UI/Item");
            var external = Group("Duplicate Asset Isolation");
            var externalSchema = external.GetSchema<BundledAssetGroupSchema>();
            externalSchema.BundleNaming = BundledAssetGroupSchema.BundleNamingStyle.AppendHash;
            externalSchema.UseAssetBundleCache = true;
            string manualProfile = settings.profileSettings.AddProfile("Official Profile", settings.activeProfileId);
            settings.activeProfileId = manualProfile;
            settings.profileSettings.SetValue(manualProfile, ManagedAddressableProfileUtility.RemoteLoadPath, "https://neutral.invalid/manual");
            settings.BuildRemoteCatalog = false;
            AssetDatabase.SaveAssets();
            string externalBefore = EditorJsonUtility.ToJson(externalSchema);
            string profileBefore = JsonUtility.ToJson(settings.profileSettings);
            var before = Files();
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges));
            CollectionAssert.AreEquivalent(before, Files(), "Preview must preserve bytes.");
            Assert.IsTrue(plan.Changes.Any(c => c.scope == "Group" && c.property == "BundleMode"));
            Assert.IsTrue(plan.Changes.Any(c => c.scope == "Entry" && c.property == "Address"));
            Assert.IsFalse(plan.Changes.Any(c => c.scope == "Profile"));
            Assert.IsFalse(plan.Changes.Any(c => c.scope == "Global"));
            ManagedAddressableSyncReport result = ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreEqual(plan.Report.ToString(), result.ToString());
            Assert.AreEqual("Remote_UI", Entry(path).parentGroup.Name);
            Assert.AreEqual("Item", Entry(path).address);
            Assert.AreEqual(BundledAssetGroupSchema.BundlePackingMode.PackTogether, Entry(path).parentGroup.GetSchema<BundledAssetGroupSchema>().BundleMode);
            Assert.AreEqual(externalBefore, EditorJsonUtility.ToJson(externalSchema));
            Assert.AreEqual(profileBefore, JsonUtility.ToJson(settings.profileSettings));
            Assert.AreEqual(manualProfile, settings.activeProfileId);
            Assert.IsFalse(settings.BuildRemoteCatalog);
        }

        [TestCase("config")]
        [TestCase("address")]
        [TestCase("schema")]
        [TestCase("unimported-content")]
        public void StalePlanRejectsBeforeAnyWrite(string changed)
        {
            string path = Text("Content/Local/UI/Item");
            ManagedAddressableSynchronizer.Sync(config, false);
            var plan = ManagedAddressableSynchronizer.CreatePlan(config, true);
            switch (changed)
            {
                case "config": config.pathSeparator = "-"; break;
                case "address": Entry(path).SetAddress("official.key", false); break;
                case "schema": Entry(path).parentGroup.GetSchema<BundledAssetGroupSchema>().UseAssetBundleCache = true; break;
                case "unimported-content": File.AppendAllText(path, "\nchanged without import"); break;
            }
            var before = Files();
            string semantic = EditorJsonUtility.ToJson(settings);
            InvalidOperationException error = Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(config, plan));
            StringAssert.Contains("stale", error.Message);
            CollectionAssert.AreEquivalent(before, Files());
            Assert.AreEqual(semantic, EditorJsonUtility.ToJson(settings));
        }

        [Test]
        public void RepeatedApplyHasNoSemanticFileDirtyOrModificationChanges()
        {
            string path = Text("Content/Local/UI/Item");
            ManagedAddressableSynchronizer.Sync(config, false);
            string guid = Entry(path).guid;
            string groupGuid = Entry(path).parentGroup.Guid;
            string settingsBefore = EditorJsonUtility.ToJson(settings);
            string groupBefore = EditorJsonUtility.ToJson(Entry(path).parentGroup);
            var before = Files();
            var dirtyBefore = settings.groups.Where(g => g != null).Cast<UnityEngine.Object>().Concat(new UnityEngine.Object[] { settings }).ToDictionary(o => o, EditorUtility.IsDirty);
            var events = new List<string>();
            Action<AddressableAssetSettings, AddressableAssetSettings.ModificationEvent, object> callback = (sender, change, data) => { if (sender == settings) events.Add(change.ToString()); };
            AddressableAssetSettings.OnModificationGlobal += callback;
            try
            {
                var plan = ManagedAddressableSynchronizer.CreatePlan(config);
                Assert.IsFalse(plan.HasChanges, plan.Report.ToString());
                Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges));
                ManagedAddressableSynchronizer.ApplyPlan(config, plan);
                ManagedAddressableSynchronizer.Sync(config, false);
            }
            finally { AddressableAssetSettings.OnModificationGlobal -= callback; }
            Assert.AreEqual(settingsBefore, EditorJsonUtility.ToJson(settings));
            Assert.AreEqual(groupBefore, EditorJsonUtility.ToJson(Entry(path).parentGroup));
            Assert.AreEqual(guid, Entry(path).guid);
            Assert.AreEqual(groupGuid, Entry(path).parentGroup.Guid);
            CollectionAssert.AreEquivalent(before, Files());
            CollectionAssert.IsEmpty(events);
            foreach (var pair in dirtyBefore) Assert.AreEqual(pair.Value, EditorUtility.IsDirty(pair.Key), pair.Key.name);
        }

        [Test]
        public void ExistingManualSchemaAndReadOnlyExternalGroupArePreservedWhileRegistering()
        {
            string path = Text("Content/Local/UI/New");
            var target = Group("UI");
            var schema = target.GetSchema<BundledAssetGroupSchema>();
            schema.BundleMode = BundledAssetGroupSchema.BundlePackingMode.PackSeparately;
            schema.Compression = BundledAssetGroupSchema.BundleCompressionMode.Uncompressed;
            schema.InternalIdNamingMode = BundledAssetGroupSchema.AssetNamingMode.GUID;
            schema.UseAssetBundleCache = true;
            var external = Group("Official ReadOnly", true);
            ManagedAR2G2IntegrationTests.ExplicitlyOwnGroupForFixture(config, target);
            AssetDatabase.SaveAssets();
            string before = EditorJsonUtility.ToJson(schema);
            string externalBefore = EditorJsonUtility.ToJson(external);
            string schemaPath = AssetDatabase.GetAssetPath(schema);
            byte[] schemaBytes = File.ReadAllBytes(schemaPath);
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsFalse(plan.Changes.Any(c => c.scope == "Group"));
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreSame(target, Entry(path).parentGroup);
            Assert.AreEqual(before, EditorJsonUtility.ToJson(schema));
            Assert.AreEqual(externalBefore, EditorJsonUtility.ToJson(external));
            CollectionAssert.AreEqual(schemaBytes, File.ReadAllBytes(schemaPath));
        }

        [Test]
        public void PublicSdkCreationBlocksUnrelatedDirtyAssetBeforeAnyWrite()
        {
            Text("Content/Local/UI/Item");
            var unrelated = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            string assetPath = root + "/Unrelated.asset";
            AssetDatabase.CreateAsset(unrelated, assetPath);
            AssetDatabase.SaveAssets();
            unrelated.buildOutputRoot = "UserUnsavedValue";
            EditorUtility.SetDirty(unrelated);
            var before = Files();
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsFalse(plan.CanApply);
            Assert.IsTrue(plan.BlockedChanges.Any(b => b.Contains(assetPath)));
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(config, plan));
            CollectionAssert.AreEquivalent(before, Files());
            Assert.IsTrue(EditorUtility.IsDirty(unrelated));
            Assert.AreEqual("UserUnsavedValue", unrelated.buildOutputRoot);
            Assert.IsNull(settings.FindGroup("UI"));
        }

        [Test]
        public void DirtyExternalAssetIntroducedAfterPreviewAlsoBlocksPublicSdkSave()
        {
            Text("Content/Local/UI/Item");
            var unrelated = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            string assetPath = root + "/Unrelated.asset";
            AssetDatabase.CreateAsset(unrelated, assetPath);
            AssetDatabase.SaveAssets();
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsTrue(plan.CanApply);
            unrelated.buildOutputRoot = "LaterUserEdit";
            EditorUtility.SetDirty(unrelated);
            var before = Files();
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(config, plan));
            CollectionAssert.AreEquivalent(before, Files());
            Assert.IsTrue(EditorUtility.IsDirty(unrelated));
            Assert.IsNull(settings.FindGroup("UI"));
        }

        [Test]
        public void DirtyAffectedGroupCanMoveReviewedEntryWhilePreservingItsPublishedKey()
        {
            string path = Text("Content/Local/UI/Existing");
            Text("Content/Local/UI/New");
            var source = Group("Legacy");
            ManagedAR2G2IntegrationTests.ExplicitlyOwnGroupForFixture(config, source);
            var entry = settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), source, false, false);
            entry.SetAddress("published.key", false);
            entry.SetLabel("published-label", true, true, false);
            EditorUtility.SetDirty(source);
            Assert.IsTrue(EditorUtility.IsDirty(source));
            string sourceGuid = source.Guid;
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges));
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreEqual("UI", Entry(path).parentGroup.Name);
            Assert.AreEqual("published.key", Entry(path).address);
            CollectionAssert.Contains(Entry(path).labels, "published-label");
            Assert.AreEqual(sourceGuid, source.Guid);
        }

        [Test]
        public void MissingPathVariableIsBlockedWithoutChangingAnyProfile()
        {
            Text("Content/Remote/UI/Item");
            settings.profileSettings.RemoveValue(settings.profileSettings.GetProfileDataByName(ManagedAddressableProfileUtility.RemoteLoadPath).Id);
            AssetDatabase.SaveAssets();
            string profileBefore = JsonUtility.ToJson(settings.profileSettings);
            var before = Files();
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsFalse(plan.CanApply);
            Assert.IsTrue(plan.BlockedChanges.Any(b => b.Contains(ManagedAddressableProfileUtility.RemoteLoadPath)));
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(config, plan));
            Assert.AreEqual(profileBefore, JsonUtility.ToJson(settings.profileSettings));
            CollectionAssert.AreEquivalent(before, Files());
        }

        [Test]
        public void MissingSettingsPreviewListsInitialGlobalAndProfileFieldsWithoutCreatingAssets()
        {
            Text("Content/Local/UI/Item");
            AssetDatabase.SaveAssets();
            var before = Files();
            EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName, out AddressableAssetSettingsDefaultObject originalWrapper);
            EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName, out AddressableAssetSettings originalLegacy);
            EditorBuildSettings.RemoveConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName);
            EditorBuildSettings.RemoveConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName);
            DefaultField.SetValue(null, null);
            try
            {
                var plan = ManagedAddressableSynchronizer.CreatePlan(config);
                Assert.IsNull(AddressableAssetSettingsDefaultObject.Settings);
                Assert.IsTrue(plan.Changes.Any(c => c.scope == "Global" && c.property == "DisableCatalogUpdateOnStartup"));
                Assert.IsTrue(plan.Changes.Any(c => c.scope == "Profile" && c.property == ManagedAddressableProfileUtility.RemoteLoadPath));
                CollectionAssert.AreEquivalent(before, Files());
            }
            finally
            {
                if (originalLegacy != null) EditorBuildSettings.AddConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName, originalLegacy, true);
                if (originalWrapper != null) EditorBuildSettings.AddConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName, originalWrapper, true);
                DefaultField.SetValue(null, settings);
            }
        }

        [Test]
        public void LegacySettingsMappingIsRejectedBeforeSdkGetterMigrationOrSave()
        {
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName, out AddressableAssetSettingsDefaultObject originalWrapper);
            EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName, out AddressableAssetSettings originalLegacy);
            try
            {
                EditorBuildSettings.RemoveConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName);
                EditorBuildSettings.AddConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName, settings, true);
                DefaultField.SetValue(null, null);
                settings.BuildRemoteCatalog = !settings.BuildRemoteCatalog;
                EditorUtility.SetDirty(settings);
                string settingsBefore = EditorJsonUtility.ToJson(settings);
                bool dirtyBefore = EditorUtility.IsDirty(settings);
                var before = Files();
                const string buildSettings = "ProjectSettings/EditorBuildSettings.asset";
                string buildSettingsBefore = File.Exists(buildSettings) ? Convert.ToBase64String(File.ReadAllBytes(buildSettings)) : "absent";
                InvalidOperationException preview = Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.Sync(config, true));
                StringAssert.Contains("explicit migration", preview.Message);
                InvalidOperationException apply = Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(config, plan));
                StringAssert.Contains("official Addressables tools", apply.Message);
                Assert.IsFalse(EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName, out AddressableAssetSettingsDefaultObject rejectedWrapper));
                Assert.IsTrue(EditorBuildSettings.TryGetConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName, out AddressableAssetSettings retainedLegacy));
                Assert.AreSame(settings, retainedLegacy);
                Assert.IsNull(DefaultField.GetValue(null), "Preview/Apply must not invoke the SDK migration getter.");
                Assert.AreEqual(settingsBefore, EditorJsonUtility.ToJson(settings));
                Assert.AreEqual(dirtyBefore, EditorUtility.IsDirty(settings));
                CollectionAssert.AreEquivalent(before, Files());
                Assert.AreEqual(buildSettingsBefore, File.Exists(buildSettings) ? Convert.ToBase64String(File.ReadAllBytes(buildSettings)) : "absent");
            }
            finally
            {
                EditorBuildSettings.RemoveConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName);
                if (originalLegacy != null) EditorBuildSettings.AddConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigAssetName, originalLegacy, true);
                if (originalWrapper != null) EditorBuildSettings.AddConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName, originalWrapper, true);
                DefaultField.SetValue(null, settings);
            }
        }

        [Test]
        public void UnownedOptionalSpineNamedGroupIsPreservedWithoutBlockingSync()
        {
            string outside = Text("Outside/Keep");
            var spine = Group("SpineShader");
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(outside), spine, false, false).SetAddress("published.keep", false);
            Text("Content/Local/UI/New");
            AssetDatabase.SaveAssets();
            var before = Files();
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges));
            CollectionAssert.AreEquivalent(before, Files(), "Preview must not repair an unowned optional SDK group.");
            string externalBefore = EditorJsonUtility.ToJson(spine);
            string schemaBefore = EditorJsonUtility.ToJson(spine.GetSchema<BundledAssetGroupSchema>());
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            Assert.AreEqual(externalBefore, EditorJsonUtility.ToJson(spine));
            Assert.AreEqual(schemaBefore, EditorJsonUtility.ToJson(spine.GetSchema<BundledAssetGroupSchema>()));
            CollectionAssert.DoesNotContain(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(spine)));
            Assert.AreEqual("published.keep", Entry(outside).address);
            Assert.IsNotNull(settings.FindGroup("UI"));
        }
    }
}
