using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using NUnit.Framework;
using UnityEditor.AddressableAssets.Build;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedRT2PublisherIntegrationTests
    {
        private static string Sha(string path)
        {
            using (var stream = File.OpenRead(path)) using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        [Test]
        public void ActualProductionArtifactsEmitPublisherUsingTheSameTwoSdkBuilds()
        {
            var built = new List<AddressablesPlayerBuildResult>();
            Action<AddressableAssetBuildResult> capture = result =>
            {
                if (result is AddressablesPlayerBuildResult player) built.Add(player);
            };
            using (var f = new ManagedBootstrapSplitFixture())
            {
                ManagedBuildExportResult bootBuild, revisionBuild;
                BuildScript.buildCompleted += capture;
                try { (bootBuild, revisionBuild) = ManagedBootstrapSplitIntegrationTests.BuildAndCheckProductionArtifacts(f); }
                finally { BuildScript.buildCompleted -= capture; }
                var boot = ManagedBootstrapSplitIntegrationTests.ReadReceipt(bootBuild);
                var revision = ManagedBootstrapSplitIntegrationTests.ReadReceipt(revisionBuild);

                Assert.AreEqual(2, built.Count, "Exactly the original Boot and Revision SDK builds are allowed.");
                Assert.IsTrue(built.All(result => string.IsNullOrEmpty(result.Error)));
                Assert.IsTrue(boot.complete && boot.rawSettingsRestored && boot.effectiveSettingsRestored);
                Assert.IsTrue(string.IsNullOrEmpty(boot.publisherPath) && string.IsNullOrEmpty(boot.publisherSha256));
                Assert.IsFalse(File.Exists(Path.Combine(Path.GetDirectoryName(boot.catalogPath), "revision_publisher.json")), "Boot is not a Revision publisher.");
                Assert.IsTrue(revision.complete && revision.rawSettingsRestored && revision.effectiveSettingsRestored);
                Assert.IsFalse(string.IsNullOrWhiteSpace(revision.publisherPath));
                Assert.AreEqual(Sha(revision.publisherPath), revision.publisherSha256.ToLowerInvariant());
                var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(revision.publisherPath));
                Assert.AreEqual(1, publisher.schemaVersion);
                Assert.AreEqual(revision.stamp, publisher.revisionId);
                Assert.AreEqual(revision.platform, publisher.target);
                Assert.AreEqual(Path.GetFileName(revision.catalogPath), publisher.catalogFile);
                Assert.AreEqual(Sha(revision.catalogPath), publisher.catalogSha256.ToLowerInvariant());
                Assert.AreEqual(new FileInfo(revision.catalogPath).Length, publisher.catalogBytes);
                Assert.AreEqual(revision.bundles.Count, publisher.bundles.Length);
                foreach (var row in publisher.bundles)
                {
                    var archived = revision.bundles.Single(bundle => bundle.bundleName == row.sdkBundleName);
                    var sdk = built[1].AssetBundleBuildResults.Single(bundle => bundle.InternalBundleName == row.sdkBundleName);
                    Assert.AreEqual(Path.GetFileName(archived.filePath), row.fileName);
                    Assert.AreEqual(new FileInfo(archived.filePath).Length, row.bytes);
                    Assert.AreEqual(Sha(archived.filePath), row.fileSha256.ToLowerInvariant());
                    Assert.AreEqual(sdk.Hash.ToString().ToLowerInvariant(), row.sdkHash.ToLowerInvariant());
                    Assert.AreEqual(sdk.Crc, row.crc);
                }
            }
        }
    }
}
