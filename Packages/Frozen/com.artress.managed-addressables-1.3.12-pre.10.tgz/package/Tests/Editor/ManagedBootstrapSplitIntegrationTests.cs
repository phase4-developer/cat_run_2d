using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEditor.Build;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedBootstrapSplitIntegrationTests
    {
        private static void Ready(ManagedBootstrapSplitFixture f)
        {
            var settings = f.Settings;
            f.Config.allowDevelopmentHttp = true; // The QA server is plain http on loopback.
            f.Config.revisionRelease = new ManagedRevisionReleaseMetadata { productId = "qa-product", channel = "qa", authorityId = "qa-authority", compatibilityFamily = "F", deploymentSequence = 10 };
            settings.OverridePlayerVersion = "production1-fixed";
            settings.profileSettings.SetValue(settings.activeProfileId, AddressableAssetSettings.kRemoteBuildPath, f.Config.buildOutputRoot + "/[BuildTarget]");
            settings.profileSettings.SetValue(settings.activeProfileId, AddressableAssetSettings.kRemoteLoadPath, "http://127.0.0.1:19843/production1");
            settings.RemoteCatalogBuildPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteBuildPath);
            settings.RemoteCatalogLoadPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteLoadPath);
            var remote = f.Revision.GetSchema<BundledAssetGroupSchema>();
            remote.BuildPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteBuildPath);
            remote.LoadPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteLoadPath);
            remote.UseAssetBundleCache = true;
            remote.UseAssetBundleCrc = true;
            remote.UseAssetBundleCrcForCachedBundles = false;
            remote.AssetBundledCacheClearBehavior = BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache;
            EditorUtility.SetDirty(remote);
            f.Save();
            var plan = f.RolePlan();
            Assert.IsTrue(plan.CanApply, plan.Report.ToString());
            ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
            f.Save();
        }

        [Test]
        public void MissingContributingRoleReportsActualGroupNameGuidAndWhereToAssignIt()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                f.Config.groupBuildRoles.RemoveAll(r => r.groupAssetGuid == ManagedBootstrapSplitFixture.GuidOf(f.Revision));
                f.Save();
                var before = f.Files();
                var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                Assert.IsFalse(report.CanBuild);
                string errors = string.Join("\n", report.Errors);
                StringAssert.Contains(f.Revision.Name, errors);
                StringAssert.Contains(ManagedBootstrapSplitFixture.GuidOf(f.Revision), errors);
                Assert.IsTrue(errors.Contains("groupBuildRoles") || errors.Contains("Build Roles") || errors.Contains("역할"), errors);
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [Test]
        public void LostRoleListBlocksTheBuildWithoutWriting()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                f.Config.groupBuildRoles.Clear();
                f.Save();
                var before = f.Files();
                var built = ManagedAddressableBuildExporter.BuildBootContent(f.Config);
                Assert.IsFalse(built.success);
                Assert.IsNotEmpty(built.error);
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [Test]
        public void SyncCreatedRemoteGroupNeedsOnlyItsHttpsRootForRevision()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                string directory = f.Root + "/Content/Remote/UI";
                Directory.CreateDirectory(directory);
                File.WriteAllText(directory + "/Item.txt", "SYNC_CREATED_REMOTE");
                AssetDatabase.Refresh();
                f.Config.autoRegister = true;
                f.Settings.profileSettings.SetValue(f.Settings.activeProfileId, AddressableAssetSettings.kRemoteLoadPath, "<undefined>");
                f.Save();
                ManagedAddressableSynchronizer.Sync(f.Config, false);
                var created = f.Settings.FindGroup("Remote_UI");
                var schema = created.GetSchema<BundledAssetGroupSchema>();
                Assert.IsTrue(schema.UseAssetBundleCache); Assert.IsTrue(schema.UseAssetBundleCrc); Assert.IsFalse(schema.UseAssetBundleCrcForCachedBundles);
                Assert.IsFalse(schema.UseDefaultSchemaSettings);
                Assert.AreEqual(BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache, schema.AssetBundledCacheClearBehavior);
                var roles = f.Roles();
                roles.Add(new ManagedGroupBuildRoleSetting { groupAssetGuid = ManagedBootstrapSplitFixture.GuidOf(created), role = ManagedGroupBuildRole.Revision });
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, ManagedAddressableSynchronizer.CreateBuildRolePlan(f.Config, roles, new[] { ManagedBootstrapSplitFixture.BootKey }));
                f.Save();
                var unset = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Revision);
                Assert.IsFalse(unset.CanBuild);
                Assert.IsTrue(unset.Errors.All(error => error.Contains("HTTPS root")), unset.ToString());
                f.Settings.profileSettings.SetValue(f.Settings.activeProfileId, AddressableAssetSettings.kRemoteLoadPath, "https://cdn.example.invalid/game");
                f.Save();
                var ready = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Revision);
                Assert.IsTrue(ready.CanBuild, ready.ToString());
                Assert.IsFalse(ManagedAddressableSynchronizer.CreateRevisionBuildPlan(f.Config).HasChanges);
            }
        }

        [Test]
        public void PlainHttpLoadPathFailsValidationUntilTheDevelopmentSettingIsOn()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                Assert.IsTrue(ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Revision).CanBuild);
                f.Config.allowDevelopmentHttp = false;
                f.Save();
                StringAssert.Contains("Allow Development HTTP", ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Revision).ToString());
                StringAssert.Contains("Allow Development HTTP", ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot).ToString());
            }
        }

        [Test]
        public void ReleaseBuildWithDevelopmentHttpOnFailsBeforeAnyWork()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                f.Config.allowDevelopmentHttp = true;
                var error = Assert.Throws<BuildFailedException>(() => ManagedAddressableBuildExporter.RequireDevelopmentHttpOnlyInDevelopmentBuilds(f.Config, BuildOptions.None));
                StringAssert.Contains("Allow Development HTTP", error.Message);
                Assert.DoesNotThrow(() => ManagedAddressableBuildExporter.RequireDevelopmentHttpOnlyInDevelopmentBuilds(f.Config, BuildOptions.Development));
                f.Config.allowDevelopmentHttp = false;
                Assert.DoesNotThrow(() => ManagedAddressableBuildExporter.RequireDevelopmentHttpOnlyInDevelopmentBuilds(f.Config, BuildOptions.None));
            }
        }

        [Test]
        public void BootGroupWithoutSdkCacheAndCrcPassesTheCatalogCheck()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                var schema = f.Boot.GetSchema<BundledAssetGroupSchema>();
                schema.UseAssetBundleCache = false; // What Sync gives a Local Group.
                schema.UseAssetBundleCrc = false;
                EditorUtility.SetDirty(schema);
                f.Save();
                var built = ManagedAddressableBuildExporter.BuildBootContent(f.Config);
                f.Reload();
                Assert.IsTrue(built.success, built.error);
                Assert.IsTrue(ReadReceipt(built).bundles.All(bundle => bundle.hash == "" && bundle.crc == 0));
            }
        }

        [TestCase(InsecureHttpOption.NotAllowed, InsecureHttpOption.DevelopmentOnly)]
        [TestCase(InsecureHttpOption.DevelopmentOnly, InsecureHttpOption.DevelopmentOnly)]
        [TestCase(InsecureHttpOption.AlwaysAllowed, InsecureHttpOption.AlwaysAllowed)]
        public void DevelopmentHttpChangeOnlyTouchesAndRestoresWhatItChanged(InsecureHttpOption project, InsecureHttpOption duringBuild)
        {
            var original = PlayerSettings.insecureHttpOption;
            try
            {
                PlayerSettings.insecureHttpOption = project;
                var change = ManagedDevelopmentHttpChange.Capture();
                change.Apply();
                Assert.AreEqual(duringBuild, PlayerSettings.insecureHttpOption);
                change.Restore();
                Assert.AreEqual(project, PlayerSettings.insecureHttpOption);
            }
            finally { PlayerSettings.insecureHttpOption = original; }
        }

        [Test]
        public void RevisionGroupWithoutSdkCacheIdentityIsBlockedBeforeBuilding()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                var schema = f.Revision.GetSchema<BundledAssetGroupSchema>();
                Assert.IsTrue(ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Revision).CanBuild);
                schema.UseAssetBundleCache = false;
                EditorUtility.SetDirty(schema);
                f.Save();
                string report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Revision).ToString();
                StringAssert.Contains("AssetBundle Cache", report);
            }
        }

        [Test]
        public void TemporaryWritesRequireExplicitOwnershipRatherThanRoleBasedAdoption()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                f.Config.ownedGroupGuids.Remove(ManagedBootstrapSplitFixture.GuidOf(f.Revision));
                f.Save();
                var before = f.Files();
                var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                Assert.IsFalse(report.CanBuild, "Excluding the unowned Revision Group would write IncludeInBuild.");
                Assert.IsFalse(f.Config.ownedGroupGuids.Contains(ManagedBootstrapSplitFixture.GuidOf(f.Revision)));
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [Test]
        public void CommonLocaleLabelNameAloneDoesNotBlockAValidRoleBuild()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                f.Settings.AddLabel("Locale-en");
                f.Boot.entries.Single().SetLabel("Locale-en", true, false, false);
                f.Revision.entries.Single().SetLabel("Locale-en", true, false, false);
                f.Save();
                var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                Assert.IsTrue(report.CanBuild, report.ToString());
                TestContext.WriteLine("Common label on neutral assets only; actual Locale/table identity conflicts are separate Host coverage.");
            }
        }

        [TestCase(true)]
        [TestCase(false)]
        public void ActualLocalizationIdentityConflictsAreDifferentFromACommonLabel(bool duplicateLocale)
        {
#if MANAGED_TESTS_LOCALIZATION
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                using (var localization = new ManagedLocalizationFixture())
                {
                    localization.AddTo(f);
                    foreach (var group in f.Settings.groups.Where(g => g != null))
                    {
                        var role = f.Config.groupBuildRoles.Single(r => r.groupAssetGuid == ManagedBootstrapSplitFixture.GuidOf(group));
                        var schema = group.GetSchema<BundledAssetGroupSchema>();
                        if (schema == null || role.role != ManagedGroupBuildRole.Revision) continue;
                        schema.UseAssetBundleCache = true;
                        schema.UseAssetBundleCrc = true;
                        schema.UseAssetBundleCrcForCachedBundles = false;
                        schema.AssetBundledCacheClearBehavior = BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache;
                        EditorUtility.SetDirty(schema);
                    }
                    f.Save();
                    var valid = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                    Assert.IsTrue(valid.CanBuild, "Official boot Locale and separate StringTable Collections must be accepted: " + valid);
                    string typeName = duplicateLocale ? "UnityEngine.Localization.Locale" : "UnityEngine.Localization.Tables.StringTable";
                    var source = f.Settings.groups.Where(g => g != null && f.Config.groupBuildRoles.Any(r =>
                            r.groupAssetGuid == ManagedBootstrapSplitFixture.GuidOf(g) && r.role == ManagedGroupBuildRole.Boot))
                        .SelectMany(g => g.entries).Select(e => AssetDatabase.LoadMainAssetAtPath(e.AssetPath))
                        .Single(o => o != null && o.GetType().FullName == typeName);
                    var clone = Object.Instantiate(source);
                    string path = f.Root + "/Content/ActualIdentityConflict.asset";
                    AssetDatabase.CreateAsset(clone, path);
                    var entry = f.Settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), duplicateLocale ? f.Boot : f.Revision, false, false);
                    entry.SetAddress("qa.production1.actual-identity-conflict", false);
                    f.Save();
                    var before = f.Files();
                    var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                    Assert.IsFalse(report.CanBuild);
                    string errors = string.Join("\n", report.Errors);
                    StringAssert.Contains(duplicateLocale ? "Locale assets" : "Collection", errors);
                    ManagedBootstrapSplitFixture.Same(before, f.Files());
                    TestContext.WriteLine(duplicateLocale ? "Real different Locale assets with the same Identifier were rejected" :
                        "Real different StringTables with identical SharedData Collection GUID and LocaleIdentifier were rejected");
                }
            }
#else
            Assert.Ignore("Optional Unity Localization SDK is not installed; this case is NOT_RUN.");
#endif
        }

        [Test]
        public void SdkAutomaticContentBuildIsRejectedInsteadOfSilentlyChanged()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                f.Settings.BuildAddressablesWithPlayerBuild = AddressableAssetSettings.PlayerBuildOption.BuildWithPlayer;
                f.Save();
                var before = f.Files();
                var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                Assert.IsFalse(report.CanBuild);
                Assert.AreEqual(AddressableAssetSettings.PlayerBuildOption.BuildWithPlayer, f.Settings.BuildAddressablesWithPlayerBuild);
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [Test]
        public void ReviewedPurposePlanUsesShortUniqueOutputAndRejectsChangedInputBeforeSdkBuild()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                var before = f.Files();
                var plan = ManagedAddressableBuildExporter.CreateSplitBuildPlan(f.Config, ManagedGroupBuildRole.Boot);
                var other = ManagedAddressableBuildExporter.CreateSplitBuildPlan(f.Config, ManagedGroupBuildRole.Boot);
                Assert.IsTrue(plan.CanBuild, plan.Report.ToString());
                Assert.IsTrue(other.CanBuild, other.Report.ToString());
                StringAssert.IsMatch("^[0-9]{8}-[0-9a-f]{16}$", plan.stamp);
                Assert.AreNotEqual(plan.outputDirectory, other.outputDirectory);
                Assert.IsFalse(Directory.Exists(plan.outputDirectory));
                ManagedBootstrapSplitFixture.Same(before, f.Files());
                f.Config.requiredBootKeys.Add("unreviewed.required.key");
                f.Save();
                var changed = f.Files();
                int sdkCalls = 0;
                Action<AddressableAssetBuildResult> capture = _ => sdkCalls++;
                ManagedBuildExportResult result;
                BuildScript.buildCompleted += capture;
                try { result = ManagedAddressableBuildExporter.BuildReviewedSplitContent(f.Config, plan); }
                finally { BuildScript.buildCompleted -= capture; }
                f.PreserveBuild("Stale-Reviewed-Plan", result);
                Assert.IsFalse(result.success);
                StringAssert.Contains("stale", result.error.ToLowerInvariant());
                Assert.AreEqual(0, sdkCalls);
                Assert.IsFalse(Directory.Exists(plan.outputDirectory));
                ManagedBootstrapSplitFixture.Same(changed, f.Files());
            }
        }

        [Test]
        public void ActualSdkSnapshotWithLongDestinationIsRejectedBeforeAnyCopyAndRestoresSettings()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                var initial = ManagedAddressableBuildExporter.CreateSplitBuildPlan(f.Config, ManagedGroupBuildRole.Boot);
                Assert.IsTrue(initial.CanBuild, initial.Report.ToString());
                int padding = 185 - Path.GetFullPath(initial.outputDirectory).Length - 1;
                Assert.Greater(padding, 0, "This Windows regression requires the approved short isolated Host path.");
                f.Config.buildOutputRoot += "/" + new string('l', padding);
                f.Save();
                var plan = ManagedAddressableBuildExporter.CreateSplitBuildPlan(f.Config, ManagedGroupBuildRole.Boot);
                Assert.IsTrue(plan.CanBuild, plan.Report.ToString());
                Assert.AreEqual(185, Path.GetFullPath(plan.outputDirectory).Length);
                var before = f.Files();
                string effective = f.GroupState(f.Boot) + f.GroupState(f.Revision) + f.Settings.CatalogProviderType.FullName;
                AddressablesPlayerBuildResult captured = null;
                Action<AddressableAssetBuildResult> capture = result => { if (result is AddressablesPlayerBuildResult player) captured = player; };
                ManagedBuildExportResult built;
                BuildScript.buildCompleted += capture;
                try { built = ManagedAddressableBuildExporter.BuildReviewedSplitContent(f.Config, plan); }
                finally { BuildScript.buildCompleted -= capture; }
                f.PreserveBuild("Expected-Long-Path-Rejection", built);
                f.Reload();
                Assert.IsNotNull(captured, "The official SDK succeeds before the snapshot path guard is exercised.");
                Assert.IsTrue(string.IsNullOrEmpty(captured.Error), captured.Error);
                Assert.IsFalse(built.success);
                StringAssert.Contains("path limit", built.error);
                StringAssert.Contains("Shorten buildOutputRoot", built.error);
                StringAssert.Contains("No snapshot files were copied", built.error);
                Assert.IsFalse(built.error.Contains("DirectoryNotFoundException"), built.error);
                var receipt = ReadReceipt(built);
                Assert.IsFalse(receipt.complete);
                Assert.IsTrue(receipt.rawSettingsRestored && receipt.effectiveSettingsRestored);
                Assert.IsFalse(Directory.Exists(receipt.runtimeDirectory), "All destination paths must be checked before copying even the first snapshot file.");
                var destinations = Directory.GetFiles(Addressables.BuildPath, "*", SearchOption.AllDirectories)
                    .Select(p => Path.GetFullPath(Path.Combine(receipt.runtimeDirectory, p.Substring(Addressables.BuildPath.Length).TrimStart('/', '\\')))).ToArray();
                Assert.IsTrue(destinations.Any(p => p.Length >= 260));
                f.PreserveObservation("Actual-Long-Destinations", new PathEvidence { paths = destinations, lengths = destinations.Select(p => p.Length).ToArray() });
                Assert.AreEqual(effective, f.GroupState(f.Boot) + f.GroupState(f.Revision) + f.Settings.CatalogProviderType.FullName);
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [Serializable]
        private sealed class PathEvidence { public string[] paths; public int[] lengths; }

        [TestCase(false, ManagedGroupBuildRole.Boot)]
        [TestCase(true, ManagedGroupBuildRole.Boot)]
        [TestCase(false, ManagedGroupBuildRole.Revision)]
        [TestCase(true, ManagedGroupBuildRole.Revision)]
        public void ActualSdkFailureAndExceptionRestoreRawAndEffectiveSettings(bool throws, ManagedGroupBuildRole purpose)
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                bool customProviders = !throws && purpose == ManagedGroupBuildRole.Boot;
                if (customProviders)
                {
                    // Explicit fixture authoring through the SDK; these two own Groups are
                    // saved before capture. Production restoration must not broadcast setters.
                    f.Settings.BundledAssetProviderType = new UnityEngine.ResourceManagement.Util.SerializedType { Value = typeof(CustomBundledProvider) };
                    f.Settings.AssetBundleProviderType = new UnityEngine.ResourceManagement.Util.SerializedType { Value = typeof(CustomBundleProvider) };
                    var foreign = f.Settings.CreateGroup("QA external unchanged Boot", false, false, false, null,
                        typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
                    var schema = foreign.GetSchema<BundledAssetGroupSchema>();
                    schema.UseDefaultSchemaSettings = false;
                    schema.IncludeInBuild = true;
                    schema.BundledAssetProviderType = new UnityEngine.ResourceManagement.Util.SerializedType { Value = typeof(BundledAssetProvider) };
                    schema.AssetBundleProviderType = new UnityEngine.ResourceManagement.Util.SerializedType { Value = typeof(AssetBundleProvider) };
                    f.Config.groupBuildRoles.Add(new ManagedGroupBuildRoleSetting { groupAssetGuid = ManagedBootstrapSplitFixture.GuidOf(foreign), role = ManagedGroupBuildRole.Boot });
                    Assert.IsFalse(f.Config.OwnsGroup(foreign), "An explicit role must not imply write ownership.");
                }
                var builder = ScriptableObject.CreateInstance<ManagedBootstrapSplitFaultBuilder>();
                builder.throwException = throws;
                AssetDatabase.CreateAsset(builder, f.Root + "/FaultBuilder.asset");
                Assert.IsTrue(f.Settings.AddDataBuilder(builder));
                f.Settings.ActivePlayerDataBuilderIndex = f.Settings.DataBuilders.Count - 1;
                f.Save();
                var ready = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, purpose);
                Assert.IsTrue(ready.CanBuild, ready.ToString());
                var before = f.Files();
                string settingsJsonBefore = EditorJsonUtility.ToJson(f.Settings);
                var groupStatesBefore = f.Settings.groups.Where(g => g != null).ToDictionary(ManagedBootstrapSplitFixture.GuidOf, f.GroupState);
                var dirtyBefore = ObserveDirtyInputs(f);
                f.PreserveObservation("Before-Dirty-Inputs", new DirtyEvidence { items = dirtyBefore });
                Assert.IsFalse(dirtyBefore.Any(i => i.dirty), "The SDK build must start from explicitly saved inputs.");
                f.PreserveObservation("Before-Global-Providers", new ProviderEvidence { custom = customProviders, settingsJson = settingsJsonBefore,
                    bundledType = f.Settings.BundledAssetProviderType.Value?.AssemblyQualifiedName, bundleType = f.Settings.AssetBundleProviderType.Value?.AssemblyQualifiedName });
                f.PreserveTree("Before-Input-Assets", f.Root);
                string provider = f.Settings.CatalogProviderType.FullName;
                bool json = f.Settings.EnableJsonCatalog, remote = f.Settings.BuildRemoteCatalog;
                string symbols = PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.Standalone);
                var includes = f.Settings.groups.Where(g => g != null && g.GetSchema<BundledAssetGroupSchema>() != null)
                    .ToDictionary(ManagedBootstrapSplitFixture.GuidOf, g => g.GetSchema<BundledAssetGroupSchema>().IncludeInBuild);
                ManagedBootstrapSplitFaultBuilder.Calls = 0;
                ManagedBootstrapSplitFaultBuilder.Last = null;
                if (!throws)
                {
                    LogAssert.Expect(LogType.Error, ManagedBootstrapSplitFaultBuilder.ErrorMarker);
                    LogAssert.Expect(LogType.Error, new Regex("Addressable content build failure \\(duration : .*\\)"));
                }
                var result = purpose == ManagedGroupBuildRole.Boot
                    ? ManagedAddressableBuildExporter.BuildBootContent(f.Config)
                    : ManagedAddressableBuildExporter.BuildRevisionContent(f.Config);
                f.PreserveBuild("Intentional-" + (throws ? "Exception" : "SdkError") + "-" + purpose, result);
                f.Reload();
                var dirtyAfter = ObserveDirtyInputs(f);
                f.PreserveObservation("After-Dirty-Inputs", new DirtyEvidence { items = dirtyAfter });
                f.PreserveObservation("After-Global-Providers", new ProviderEvidence { custom = customProviders, settingsJson = EditorJsonUtility.ToJson(f.Settings),
                    bundledType = f.Settings.BundledAssetProviderType.Value?.AssemblyQualifiedName, bundleType = f.Settings.AssetBundleProviderType.Value?.AssemblyQualifiedName });
                f.PreserveObservation("Actual-Sdk-During", ManagedBootstrapSplitFaultBuilder.Last);
                f.PreserveObservation("After-Effective", new ManagedBootstrapSplitFaultBuilder.Observation { providerType = f.Settings.CatalogProviderType.FullName,
                    json = f.Settings.EnableJsonCatalog, remote = f.Settings.BuildRemoteCatalog,
                    updateDisabled = f.Settings.DisableCatalogUpdateOnStartup,
                    groups = f.Settings.groups.Where(g => g != null).Select(g => new ManagedBootstrapSplitFaultBuilder.GroupObservation
                        { guid = ManagedBootstrapSplitFixture.GuidOf(g), name = g.Name, includeInBuild = g.IncludeInBuild }).ToList() });
                Assert.IsFalse(result.success);
                StringAssert.Contains(throws ? ManagedBootstrapSplitFaultBuilder.ExceptionMarker : ManagedBootstrapSplitFaultBuilder.ErrorMarker, result.error);
                Assert.AreEqual(1, ManagedBootstrapSplitFaultBuilder.Calls, "The actual SDK builder boundary must be reached.");
                Assert.IsNotNull(ManagedBootstrapSplitFaultBuilder.Last);
                Assert.AreEqual(purpose == ManagedGroupBuildRole.Revision, ManagedBootstrapSplitFaultBuilder.Last.json);
                Assert.AreEqual(purpose == ManagedGroupBuildRole.Revision, ManagedBootstrapSplitFaultBuilder.Last.remote);
                Assert.AreEqual(provider, f.Settings.CatalogProviderType.FullName);
                Assert.AreEqual(json, f.Settings.EnableJsonCatalog);
                Assert.AreEqual(remote, f.Settings.BuildRemoteCatalog);
                CollectionAssert.AreEqual(dirtyBefore.Select(i => i.path), dirtyAfter.Select(i => i.path));
                foreach (var item in dirtyAfter) Assert.IsFalse(item.dirty, "Restored input remains dirty: " + item.path);
                Assert.AreEqual(settingsJsonBefore, EditorJsonUtility.ToJson(f.Settings), "SDK deserialization must not retain provider backfill in the restored input.");
                if (customProviders)
                {
                    Assert.AreEqual(typeof(CustomBundledProvider), f.Settings.BundledAssetProviderType.Value);
                    Assert.AreEqual(typeof(CustomBundleProvider), f.Settings.AssetBundleProviderType.Value);
                }
                foreach (var group in f.Settings.groups.Where(g => g != null))
                    Assert.AreEqual(groupStatesBefore[ManagedBootstrapSplitFixture.GuidOf(group)], f.GroupState(group), "No restoration setter may propagate provider choices to schemas.");
                Assert.AreEqual(symbols, PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.Standalone));
                foreach (var group in f.Settings.groups.Where(g => g != null && g.GetSchema<BundledAssetGroupSchema>() != null))
                    Assert.AreEqual(includes[ManagedBootstrapSplitFixture.GuidOf(group)], group.GetSchema<BundledAssetGroupSchema>().IncludeInBuild);
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        public sealed class CustomBundledProvider : BundledAssetProvider { }
        public sealed class CustomBundleProvider : AssetBundleProvider { }
        [Serializable]
        private sealed class ProviderEvidence { public bool custom; public string settingsJson, bundledType, bundleType; }
        [Serializable] private sealed class DirtyEvidence { public DirtyInput[] items; }
        [Serializable] private sealed class DirtyInput { public string path, kind, groupGuid; public bool configOwnsGroup, dirty; }
        private static DirtyInput[] ObserveDirtyInputs(ManagedBootstrapSplitFixture f)
        {
            var groups = f.Settings.groups.Where(g => g != null).ToArray();
            var objects = groups.SelectMany(g => g.Schemas.Cast<Object>().Append(g)).Append(f.Settings).Append(f.Config).Where(o => o != null).Distinct();
            return objects.Select(o =>
            {
                var owner = groups.FirstOrDefault(g => g == o || g.Schemas.Any(s => s == o));
                return new DirtyInput { path = AssetDatabase.GetAssetPath(o), kind = o.GetType().FullName,
                    groupGuid = owner == null ? null : ManagedBootstrapSplitFixture.GuidOf(owner),
                    configOwnsGroup = owner != null && f.Config.OwnsGroup(owner), dirty = EditorUtility.IsDirty(o) };
            }).OrderBy(i => i.path, StringComparer.Ordinal).ToArray();
        }

        [Test]
        public void ActualProductionArtifactsMatchSdkKeysBundleOptionsAndRejectRevisionStaging()
        {
            using (var f = new ManagedBootstrapSplitFixture()) BuildAndCheckProductionArtifacts(f);
        }

        // One real Boot and one real Revision SDK build with every artifact check. Needs the Revision Host marker.
        internal static (ManagedBuildExportResult boot, ManagedBuildExportResult revision) BuildAndCheckProductionArtifacts(ManagedBootstrapSplitFixture f)
        {
            Ready(f);
            AddHostPrefab(f, f.Boot, "BootPrefab", "BOOT");
            AddHostPrefab(f, f.Revision, "GamePrefab", "A");
            f.Save();
            var before = f.Files();
            f.PreserveTree("Before-Input-Assets", f.Root);
            var reviewedBoot = ManagedAddressableBuildExporter.CreateSplitBuildPlan(f.Config, ManagedGroupBuildRole.Boot);
            Assert.IsTrue(reviewedBoot.CanBuild, reviewedBoot.Report.ToString());
            f.PreserveObservation("Before-Reviewed-Sdk-Input-Components", ObserveInputComponents(f));
            AddressablesPlayerBuildResult captured = null;
            Action<AddressableAssetBuildResult> capture = result => { if (result is AddressablesPlayerBuildResult player) captured = player; };
            ManagedBuildExportResult boot;
            BuildScript.buildCompleted += capture;
            try { boot = ManagedAddressableBuildExporter.BuildReviewedSplitContent(f.Config, reviewedBoot); }
            finally { BuildScript.buildCompleted -= capture; }
            f.PreserveBuild("Normal-Boot", boot);
            f.Reload();
            f.PreserveObservation("After-Reviewed-Sdk-Input-Components", ObserveInputComponents(f));
            Assert.IsTrue(boot.success, boot.error);
            Assert.IsNotNull(captured, "Official SDK result must correspond to this production build.");
            var bootReceipt = ReadReceipt(boot);
            Assert.AreEqual("Boot", bootReceipt.purpose);
            Assert.AreEqual("binary", bootReceipt.catalogFormat);
            Assert.IsTrue(bootReceipt.rawSettingsRestored && bootReceipt.effectiveSettingsRestored && bootReceipt.complete);
            ManagedBootstrapSplitFixture.Same(before, f.Files());
            var bootStage = ManagedAddressableBuildExporter.ValidatePlayerStaging(f.Config);
            f.PreserveObservation("Actual-Boot-Staging", new StageEvidence { canBuild = bootStage.CanBuild,
                errors = bootStage.Errors.ToArray(), warnings = bootStage.Warnings.ToArray(),
                expectedFingerprint = bootReceipt.inputFingerprint,
                actualFingerprint = ManagedAddressableBuildExporter.SplitFingerprint(f.Config, f.Settings),
                expectedEffective = bootReceipt.effectiveInput,
                actualEffective = ManagedBootstrapSplitSettingsScope.Effective(f.Settings),
                expectedIdentity = bootReceipt.configAssetGuid + "|" + bootReceipt.settingsAssetGuid + "|" + bootReceipt.platform + "|" + bootReceipt.appVersion + "|" + bootReceipt.unityVersion + "|" + bootReceipt.addressablesVersion,
                actualIdentity = AssetDatabase.AssetPathToGUID(f.ConfigPath) + "|" + AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(f.Settings)) + "|" + EditorUserBuildSettings.activeBuildTarget + "|" + PlayerSettings.bundleVersion + "|" + Application.unityVersion + "|" + ManagedAddressableBuildExporter.AddressablesVersion,
                expectedFiles = bootReceipt.runtimeFiles.ToArray(),
                actualFiles = Directory.GetFiles(Addressables.BuildPath, "*", SearchOption.AllDirectories).Select(p => new ManagedSplitFileStamp
                    { path = p.Substring(Addressables.BuildPath.Length).TrimStart('/', '\\').Replace('\\', '/'), sha256 = ManagedAddressableBuildExporter.SplitFileHash(p) }).OrderBy(p => p.path, StringComparer.Ordinal).ToArray() });
            Assert.IsTrue(bootStage.CanBuild, bootStage.ToString());

            // The actual binary SDK provider is independent of the production binary inspection adapter.
            InitializeSdkForBinaryInspection(f, bootReceipt, "Artifact");
            InspectBinaryBoot(f, bootReceipt.catalogPath);

            captured = null;
            ManagedBuildExportResult revision;
            BuildScript.buildCompleted += capture;
            try { revision = ManagedAddressableBuildExporter.BuildRevisionContent(f.Config); }
            finally { BuildScript.buildCompleted -= capture; }
            f.PreserveBuild("Normal-Revision", revision);
            f.Reload();
            Assert.IsTrue(revision.success, revision.error);
            Assert.IsNotNull(captured);
            var revisionReceipt = ReadReceipt(revision);
            Assert.AreEqual("Revision", revisionReceipt.purpose);
            Assert.AreEqual("json", revisionReceipt.catalogFormat);
            Assert.IsTrue(revisionReceipt.rawSettingsRestored && revisionReceipt.effectiveSettingsRestored && revisionReceipt.complete);
            var catalog = JsonUtility.FromJson<JsonContentCatalogData>(File.ReadAllText(revisionReceipt.catalogPath));
            Assert.IsNotNull(catalog);
            var locator = catalog.CreateLocator();
            Assert.IsFalse(locator.Locate(ManagedBootstrapSplitFixture.BootKey, null, out _));
            Assert.IsFalse(locator.Locate(f.Boot.entries.First(e => e.address == ManagedBootstrapSplitFixture.BootKey).guid, null, out _));
            Assert.IsTrue(locator.Locate(ManagedBootstrapSplitFixture.RevisionKey, typeof(TextAsset), out _));
            foreach (var location in locator.AllLocations.Distinct().Where(l => l.Data is AssetBundleRequestOptions && l.InternalId.StartsWith("http", StringComparison.OrdinalIgnoreCase)))
            {
                var options = (AssetBundleRequestOptions)location.Data;
                Assert.IsTrue(Hash128.Parse(options.Hash).isValid);
                var source = captured.AssetBundleBuildResults.Single(b => b.InternalBundleName == options.BundleName);
                Assert.AreEqual(source.Hash.ToString(), options.Hash);
                Assert.AreEqual(source.Crc, options.Crc);
                Assert.IsFalse(options.ClearOtherCachedVersionsWhenLoaded);
            }
            ManagedBootstrapSplitFixture.Same(before, f.Files());
            var stale = ManagedAddressableBuildExporter.ValidatePlayerStaging(f.Config);
            f.PreserveObservation("Actual-Revision-Stage-Rejection", new ValidationEvidence { canBuild = stale.CanBuild,
                errors = stale.Errors.ToArray(), warnings = stale.Warnings.ToArray() });
            Assert.IsFalse(stale.CanBuild, "Revision SDK output must not be accepted as the Player default Boot stage.");
            return (boot, revision);
        }

        [Test]
        public void ActualSdkFolderKeysRespectParentOnlyFlagsAndTheOppositeRoleIsAbsent()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Ready(f);
                const string bootFolderKey = "qa.production1.boot-folder";
                const string revisionFolderKey = "qa.production1.revision-folder";
                AddFolder(f, f.Boot, "BootFolder", bootFolderKey);
                AddFolder(f, f.Revision, "RevisionFolder", revisionFolderKey);
                f.Save();
                var before = f.Files();
                f.PreserveTree("Before-Input-Assets", f.Root);
                var built = ManagedAddressableBuildExporter.BuildBootContent(f.Config);
                f.PreserveBuild("Normal-Folder-Boot", built);
                f.Reload();
                Assert.IsTrue(built.success, built.error);
                var receipt = ReadReceipt(built);
                InitializeSdkForBinaryInspection(f, receipt, "Folder");
                var existing = Addressables.ResourceLocators.ToArray();
                var load = Addressables.LoadContentCatalogAsync(new Uri(Path.GetFullPath(receipt.catalogPath)).AbsoluteUri, false);
                IResourceLocator locator = null;
                try
                {
                    locator = load.WaitForCompletion();
                    f.PreserveObservation("Actual-Sdk-Folder-Catalog-Load", new SdkEvidence { status = load.Status.ToString(),
                        error = load.OperationException?.ToString(), providers = ProviderNames(),
                        runtimeDataPath = SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, ""), actualRuntimePath = Addressables.RuntimePath });
                    Assert.AreEqual(AsyncOperationStatus.Succeeded, load.Status, load.OperationException?.ToString());
                    Assert.IsNotNull(locator);
                    Assert.IsTrue(locator.Locate(bootFolderKey, typeof(TextAsset), out var locations));
                    Assert.AreEqual(2, locations.Count, "The SDK parent folder key must resolve both actual children.");
                    Assert.IsFalse(locator.Locate(revisionFolderKey, null, out _));
                    var entries = new List<AddressableAssetEntry>();
                    f.Boot.GatherAllAssets(entries, true, true, false);
                    var children = entries.Where(e => !AssetDatabase.IsValidFolder(e.AssetPath) && e.ParentFolderAddress == bootFolderKey).ToArray();
                    Assert.AreEqual(2, children.Length);
                    foreach (var child in children)
                    {
                        Assert.AreNotEqual(bootFolderKey, child.address);
                        Assert.IsFalse(locator.Locate(child.address, null, out _), "Individual child Address was explicitly excluded by the SDK schema: " + child.address);
                        Assert.IsTrue(locator.Locate(child.guid, typeof(TextAsset), out _), "The independent GUID key remains enabled.");
                    }
                    f.PreserveObservation("Actual-Sdk-Folder-Keys", new FolderEvidence
                    {
                        bootFolderKey = bootFolderKey, revisionFolderKey = revisionFolderKey,
                        keys = locator.Keys.Select(k => k.ToString()).ToArray(),
                        children = children.Select(e => new FolderChildEvidence { address = e.address, guid = e.guid, parent = e.ParentFolderAddress }).ToArray(),
                        includeParent = f.Boot.GetSchema<BundledAssetGroupSchema>().IncludeFolderKeysInCatalog,
                        individualAddresses = f.Boot.GetSchema<BundledAssetGroupSchema>().IncludeAddressesForFolderChildren
                    });
                }
                finally
                {
                    if (locator != null) Addressables.RemoveResourceLocator(locator);
                    if (load.IsValid()) Addressables.Release(load);
                    foreach (var extra in Addressables.ResourceLocators.Where(l => !existing.Contains(l)).ToArray()) Addressables.RemoveResourceLocator(extra);
                }
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [Serializable]
        private sealed class InputComponents
        {
            public string configJson, settingsJson;
            public InputObject[] groupsAndSchemas;
            public InputFile[] files;
        }
        [Serializable] private sealed class InputObject { public string path, guid, json; }
        [Serializable] private sealed class InputFile { public string path, sha256, dependencyHash; }
        private static InputComponents ObserveInputComponents(ManagedBootstrapSplitFixture f)
        {
            var objects = f.Settings.groups.Where(g => g != null).SelectMany(g => g.Schemas.Cast<Object>().Append(g))
                .Where(o => o != null).OrderBy(AssetDatabase.GetAssetPath, StringComparer.Ordinal).ToArray();
            var files = Directory.GetFiles(f.Root, "*", SearchOption.AllDirectories).Select(p => p.Replace('\\', '/'))
                .Concat(new[] { "ProjectSettings/EditorBuildSettings.asset" })
                .Concat(AssetDatabase.GetAllAssetPaths().Where(p => p.StartsWith("Assets/", StringComparison.Ordinal) && p.Contains("/Resources/") && !AssetDatabase.IsValidFolder(p)))
                .Concat(EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path))
                .Concat(PlayerSettings.GetPreloadedAssets().Where(o => o != null).Select(AssetDatabase.GetAssetPath))
                .Where(File.Exists).Distinct().OrderBy(p => p, StringComparer.Ordinal).ToArray();
            return new InputComponents
            {
                configJson = EditorJsonUtility.ToJson(f.Config), settingsJson = EditorJsonUtility.ToJson(f.Settings),
                groupsAndSchemas = objects.Select(o => new InputObject { path = AssetDatabase.GetAssetPath(o), guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(o)), json = EditorJsonUtility.ToJson(o) }).ToArray(),
                files = files.Select(p => new InputFile { path = p, sha256 = ManagedAddressableBuildExporter.SplitFileHash(p),
                    dependencyHash = p.StartsWith("Assets/", StringComparison.Ordinal) && !p.EndsWith(".meta", StringComparison.Ordinal) ? AssetDatabase.GetAssetDependencyHash(p).ToString() : null }).ToArray()
            };
        }
        [Serializable]
        private sealed class StageEvidence
        {
            public bool canBuild;
            public string[] errors, warnings;
            public string expectedFingerprint, actualFingerprint, expectedEffective, actualEffective, expectedIdentity, actualIdentity;
            public ManagedSplitFileStamp[] expectedFiles, actualFiles;
        }
        [Serializable]
        private sealed class SdkEvidence { public string status, error, runtimeDataPath, actualRuntimePath; public string[] providers; }
        private static string[] ProviderNames() => Addressables.ResourceManager.ResourceProviders.Select(p => p.GetType().FullName + "|" + p.ProviderId).ToArray();
        private static void InitializeSdkForBinaryInspection(ManagedBootstrapSplitFixture f, ManagedSplitBuildReceipt receipt, string label)
        {
            string previous = SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, "");
            string input = Path.GetFullPath(Path.Combine(receipt.runtimeDirectory, "settings.json"));
            f.PreserveObservation(label + "-Sdk-Before-Initialize", new SdkEvidence { providers = ProviderNames(), runtimeDataPath = previous, actualRuntimePath = Addressables.RuntimePath });
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, input);
            var initialized = Addressables.InitializeAsync(false);
            try
            {
                var locator = initialized.WaitForCompletion();
                f.PreserveObservation(label + "-Sdk-Initialize", new SdkEvidence { status = initialized.Status.ToString(),
                    error = initialized.OperationException?.ToString(), providers = ProviderNames(), runtimeDataPath = input, actualRuntimePath = Addressables.RuntimePath });
                Assert.IsNotNull(locator, initialized.OperationException?.ToString());
                Assert.AreEqual(AsyncOperationStatus.Succeeded, initialized.Status, initialized.OperationException?.ToString());
            }
            finally
            {
                if (initialized.IsValid()) Addressables.Release(initialized);
                if (string.IsNullOrEmpty(previous)) SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
                else SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, previous);
            }
        }
        [Serializable]
        private sealed class ValidationEvidence { public bool canBuild; public string[] errors, warnings; }
        [Serializable]
        private sealed class FolderEvidence
        {
            public string bootFolderKey, revisionFolderKey;
            public string[] keys;
            public FolderChildEvidence[] children;
            public bool includeParent, individualAddresses;
        }
        [Serializable]
        private sealed class FolderChildEvidence { public string address, guid, parent; }

        private static void AddFolder(ManagedBootstrapSplitFixture f, AddressableAssetGroup group, string name, string address)
        {
            string path = f.Root + "/Content/" + name;
            Directory.CreateDirectory(path);
            File.WriteAllText(path + "/First.txt", "FOLDER_FIRST");
            File.WriteAllText(path + "/Second.txt", "FOLDER_SECOND");
            AssetDatabase.Refresh();
            f.Settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), group, false, false).SetAddress(address, false);
            var schema = group.GetSchema<BundledAssetGroupSchema>();
            schema.IncludeFolderKeysInCatalog = true;
            schema.IncludeAddressesForFolderChildren = false;
            EditorUtility.SetDirty(schema);
        }

        internal static ManagedSplitBuildReceipt ReadReceipt(ManagedBuildExportResult result)
        {
            Assert.IsNotEmpty(result.splitReceiptPath);
            Assert.IsTrue(File.Exists(result.splitReceiptPath));
            var receipt = JsonUtility.FromJson<ManagedSplitBuildReceipt>(File.ReadAllText(result.splitReceiptPath));
            Assert.IsNotNull(receipt);
            return receipt;
        }

        private static void InspectBinaryBoot(ManagedBootstrapSplitFixture f, string path)
        {
            var before = Addressables.ResourceLocators.ToArray();
            var load = Addressables.LoadContentCatalogAsync(new Uri(Path.GetFullPath(path)).AbsoluteUri, false);
            IResourceLocator locator = null;
            try
            {
                locator = load.WaitForCompletion();
                Assert.AreEqual(AsyncOperationStatus.Succeeded, load.Status);
                Assert.IsNotNull(locator);
                Assert.IsTrue(locator.Locate(ManagedBootstrapSplitFixture.BootKey, typeof(TextAsset), out _));
                Assert.IsFalse(locator.Locate(ManagedBootstrapSplitFixture.RevisionKey, null, out _));
                Assert.IsFalse(locator.Locate(f.Revision.entries.First(e => e.address == ManagedBootstrapSplitFixture.RevisionKey).guid, null, out _));
                TestContext.WriteLine("Actual binary SDK provider read succeeded; binary inspection adapter SDK version: " +
                    UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(Addressables).Assembly)?.version);
            }
            finally
            {
                if (locator != null) Addressables.RemoveResourceLocator(locator);
                if (load.IsValid()) Addressables.Release(load);
                foreach (var extra in Addressables.ResourceLocators.Where(l => !before.Contains(l)).ToArray()) Addressables.RemoveResourceLocator(extra);
            }
        }

        private static void AddHostPrefab(ManagedBootstrapSplitFixture f, AddressableAssetGroup group, string name, string revision)
        {
            var marker = Type.GetType("Artress.ManagedAddressables.HostFixture.ManagedHostMarker, Artress.ManagedAddressables.HostFixture");
            if (marker == null) Assert.Ignore("Needs the Revision Host marker from Tests/Fixtures~; this case is NOT_RUN.");
            var go = new GameObject(name);
            try
            {
                var component = go.AddComponent(marker);
                var serialized = new SerializedObject(component);
                serialized.FindProperty("revision").stringValue = revision;
                serialized.FindProperty("dependency").objectReferenceValue = AssetDatabase.LoadAssetAtPath<TextAsset>(f.Root + "/Content/Boot.txt");
                serialized.ApplyModifiedPropertiesWithoutUndo();
                string path = f.Root + "/Content/" + name + ".prefab";
                PrefabUtility.SaveAsPrefabAsset(go, path);
                var entry = f.Settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), group, false, false);
                entry.SetAddress("qa.production1." + name.ToLowerInvariant(), false);
            }
            finally { Object.DestroyImmediate(go); }
        }

    }
}
