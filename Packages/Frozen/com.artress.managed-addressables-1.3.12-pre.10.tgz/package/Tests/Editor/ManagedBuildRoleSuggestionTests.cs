using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedBuildRoleSuggestionTests
    {
        private static void Content(ManagedBootstrapSplitFixture f, params string[] paths)
        {
            foreach (string path in paths)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(f.Root + "/Content/" + path));
                File.WriteAllText(f.Root + "/Content/" + path, path);
            }
            AssetDatabase.Refresh();
            f.Config.autoRegister = true;
            f.Save();
            ManagedAddressableSynchronizer.Sync(f.Config, false);
        }

        private static ManagedGroupBuildRoleSetting Row(ManagedBuildRoleSuggestion suggestion, ManagedBootstrapSplitFixture f, string group) =>
            suggestion.roles.Single(r => r.groupAssetGuid == ManagedBootstrapSplitFixture.GuidOf(f.Settings.FindGroup(group)));

        [Test]
        public void FoldersDecideRolesSharedTargetsAndBootKeys()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Content(f, "Local/Core/Intro.txt", "Remote/Game/Level.txt");
                f.Settings.CreateGroup("Empty", false, false, false, null);
                var before = EditorJsonUtility.ToJson(f.Config);

                var suggestion = ManagedAddressableSynchronizer.SuggestBuildRoles(f.Config, null, null);

                Assert.AreEqual(ManagedGroupBuildRole.Boot, Row(suggestion, f, "Core").role);
                Assert.AreEqual(ManagedGroupBuildRole.Revision, Row(suggestion, f, "Remote_Game").role);
                Assert.AreEqual(ManagedGroupBuildRole.Boot, Row(suggestion, f, "Empty").role, "An empty Group cannot put content in the wrong catalog.");
                Assert.IsTrue(Row(suggestion, f, "Core").useForSharedBundles);
                Assert.IsTrue(Row(suggestion, f, "Remote_Game").useForSharedBundles);
                Assert.IsFalse(Row(suggestion, f, "Empty").useForSharedBundles);
                CollectionAssert.AreEquivalent(new[] { "Intro" }, suggestion.bootKeys);
                CollectionAssert.AreEquivalent(new[] { "QA explicit Boot", "QA explicit Revision" }, suggestion.undecidedGroups, "Entries outside Local and Remote are not guessed.");
                Assert.AreEqual(before, EditorJsonUtility.ToJson(f.Config), "A suggestion writes nothing.");
            }
        }

        [Test]
        public void DraftRowsAndKeysKeepTheDevelopersChoice()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Content(f, "Local/Core/Intro.txt", "Remote/Game/Level.txt");
                string core = ManagedBootstrapSplitFixture.GuidOf(f.Settings.FindGroup("Core"));
                var draft = new List<ManagedGroupBuildRoleSetting> { new ManagedGroupBuildRoleSetting { groupAssetGuid = core, role = ManagedGroupBuildRole.Revision, useForSharedBundles = true } };

                var suggestion = ManagedAddressableSynchronizer.SuggestBuildRoles(f.Config, draft, new[] { "Chosen" });

                Assert.AreEqual(ManagedGroupBuildRole.Revision, Row(suggestion, f, "Core").role);
                Assert.IsFalse(Row(suggestion, f, "Remote_Game").useForSharedBundles, "One shared target per role.");
                CollectionAssert.AreEqual(new[] { "Chosen" }, suggestion.bootKeys);
            }
        }

        [Test]
        public void AddressesLeftOutOfTheCatalogAreNotSuggestedAsBootKeys()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Content(f, "Local/Core/Intro.txt", "Remote/Game/Level.txt");
                f.Settings.FindGroup("Core").GetSchema<BundledAssetGroupSchema>().IncludeAddressInCatalog = false;

                Assert.IsEmpty(ManagedAddressableSynchronizer.SuggestBuildRoles(f.Config, null, null).bootKeys);
            }
        }

        [Test]
        public void GroupMixingLocalAndRemoteStaysUndecided()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Content(f, "Local/Core/Intro.txt", "Remote/Game/Level.txt");
                var level = f.Settings.FindGroup("Remote_Game").entries.Single();
                f.Settings.MoveEntry(level, f.Settings.FindGroup("Core"));

                var suggestion = ManagedAddressableSynchronizer.SuggestBuildRoles(f.Config, null, null);

                CollectionAssert.Contains(suggestion.undecidedGroups, "Core");
            }
        }
    }
}
