using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEditor.Build;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // Independent contract assertions. The planner or build implementation is not copied.
    public sealed class ManagedBootstrapSplitAuthoringTests
    {
        [Test]
        public void RolePreviewHasNoWritesAndApplyChangesOnlyReviewedConfigMetadata()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var before = f.Files();
                var settings = EditorJsonUtility.ToJson(f.Settings);
                var boot = f.GroupState(f.Boot);
                var revision = f.GroupState(f.Revision);
                var ownership = f.Config.ownedGroupGuids.ToArray();
                var plan = f.RolePlan();
                Assert.IsTrue(plan.CanApply, plan.Report.ToString());
                Assert.IsTrue(plan.HasChanges);
                ManagedBootstrapSplitFixture.Same(before, f.Files());
                Assert.IsFalse(EditorUtility.IsDirty(f.Config));
                Assert.IsFalse(EditorUtility.IsDirty(f.Settings));
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                Assert.AreEqual(2, f.Config.groupBuildRoles.Count);
                CollectionAssert.AreEqual(new[] { ManagedBootstrapSplitFixture.BootKey }, f.Config.requiredBootKeys);
                CollectionAssert.AreEqual(ownership, f.Config.ownedGroupGuids);
                Assert.AreEqual(settings, EditorJsonUtility.ToJson(f.Settings));
                Assert.AreEqual(boot, f.GroupState(f.Boot));
                Assert.AreEqual(revision, f.GroupState(f.Revision));
                f.AssertOriginalEntries();
                ManagedBootstrapSplitFixture.Same(before, f.Files(), f.ConfigPath);
            }
        }

        [Test]
        public void RoleAdoptionCanBeExplicitlyDisabledPreservingExternalGroups()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                f.Config.ownedGroupGuids.Clear();
                f.Save();
                var boot = f.GroupState(f.Boot);
                var revision = f.GroupState(f.Revision);
                var plan = ManagedAddressableSynchronizer.CreateBuildRolePlan(f.Config,
                    f.Roles(), new[] { ManagedBootstrapSplitFixture.BootKey }, Array.Empty<string>());
                Assert.IsTrue(plan.CanApply, plan.Report.ToString());
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                Assert.IsEmpty(f.Config.ownedGroupGuids);
                Assert.AreEqual(boot, f.GroupState(f.Boot));
                Assert.AreEqual(revision, f.GroupState(f.Revision));
            }
        }

        [Test]
        public void ApplyingTheSameRolePlanAgainIsANoOp()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, f.RolePlan());
                var before = f.Files();
                var plan = f.RolePlan();
                Assert.IsTrue(plan.CanApply, plan.Report.ToString());
                Assert.IsFalse(plan.HasChanges);
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [Test]
        public void ConfigEditAfterRolePreviewIsRejectedBeforeWritingAnything()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var plan = f.RolePlan();
                f.Config.requiredBootKeys.Add("external.unreviewed.key");
                f.Save();
                var before = f.Files();
                Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan));
                ManagedBootstrapSplitFixture.Same(before, f.Files());
                CollectionAssert.Contains(f.Config.requiredBootKeys, "external.unreviewed.key");
            }
        }

        [Test]
        public void ExternalSchemaEditAfterRolePreviewIsPreservedAndPlanIsRejected()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var plan = f.RolePlan();
                f.Revision.GetSchema<BundledAssetGroupSchema>().BundleMode = BundledAssetGroupSchema.BundlePackingMode.PackSeparately;
                EditorUtility.SetDirty(f.Revision.GetSchema<BundledAssetGroupSchema>());
                f.Save();
                var before = f.Files();
                Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan));
                ManagedBootstrapSplitFixture.Same(before, f.Files());
                Assert.AreEqual(BundledAssetGroupSchema.BundlePackingMode.PackSeparately,
                    f.Revision.GetSchema<BundledAssetGroupSchema>().BundleMode);
            }
        }

        [Test]
        public void RolePlanSelectsDoNotBuildWithPlayerAsAReviewedChange()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                f.Settings.BuildAddressablesWithPlayerBuild = AddressableAssetSettings.PlayerBuildOption.BuildWithPlayer;
                f.Save();
                var before = f.Files();
                var plan = f.RolePlan();
                Assert.IsTrue(plan.CanApply, plan.Report.ToString());
                Assert.IsTrue(plan.Changes.Any(c => c.property.Contains("BuildAddressablesWithPlayerBuild")),
                    "The SDK player-build policy must be an explicit change.");
                ManagedBootstrapSplitFixture.Same(before, f.Files());
                Assert.AreEqual(AddressableAssetSettings.PlayerBuildOption.BuildWithPlayer, f.Settings.BuildAddressablesWithPlayerBuild);
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                Assert.AreEqual(AddressableAssetSettings.PlayerBuildOption.DoNotBuildWithPlayer, f.Settings.BuildAddressablesWithPlayerBuild);
                f.AssertOriginalEntries();
            }
        }

        [Test]
        public void ReviewedPlayerBuildDefaultIsSavedToTheSettingsAssetOnDisk()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                f.Settings.BuildAddressablesWithPlayerBuild = AddressableAssetSettings.PlayerBuildOption.BuildWithPlayer;
                f.Save();
                string path = AssetDatabase.GetAssetPath(f.Settings);
                const string key = "m_BuildAddressablesWithPlayerBuild: ";
                StringAssert.Contains(key + "1", File.ReadAllText(path), "The fixture must start from a saved BuildWithPlayer value.");
                Assert.IsFalse(EditorUtility.IsDirty(f.Settings), "The SDK setter does not mark Settings dirty; the case needs a clean asset.");
                var plan = f.RolePlan();
                Assert.IsTrue(plan.CanApply, plan.Report.ToString());
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                Assert.IsFalse(EditorUtility.IsDirty(f.Settings), "The reviewed policy must not be left unsaved.");
                StringAssert.Contains(key + "2", File.ReadAllText(path), "DoNotBuildWithPlayer must survive an Editor restart.");
                f.AssertOriginalEntries();
            }
        }

        [Test]
        public void BootSdkConfigReloadReturnsThePersistentAssetAndRejectsALostOne()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                string path = AssetDatabase.GetAssetPath(f.Config);
                var reloaded = ManagedAddressableBuildExporter.ReloadSplitConfigAfterSdk(path);
                Assert.IsNotNull(reloaded);
                Assert.IsTrue(EditorUtility.IsPersistent(reloaded));
                Assert.AreEqual(path, AssetDatabase.GetAssetPath(reloaded));
                Assert.Throws<BuildFailedException>(() => ManagedAddressableBuildExporter.ReloadSplitConfigAfterSdk(""));
                Assert.Throws<BuildFailedException>(() => ManagedAddressableBuildExporter.ReloadSplitConfigAfterSdk(path + ".missing"));
            }
        }

        [Test]
        public void PlayerBuildReloadsConfigBetweenTheBootSdkBuildAndPackagedStaging()
        {
            // The full path needs a real Player build; stage 10 runs it. This pins the order the defect broke.
            string root = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(ManagedAddressableSynchronizer).Assembly).resolvedPath;
            string source = File.ReadAllText(Path.Combine(root, "Editor/ManagedBootstrapSplitPlayerBuild.cs"));
            int build = source.IndexOf("BuildSplitContent(config, ManagedGroupBuildRole.Boot, context)", StringComparison.Ordinal);
            int reload = source.IndexOf("config = ReloadSplitConfigAfterSdk(configPath)", StringComparison.Ordinal);
            int staging = source.IndexOf("PreparePackagedRevisionForPlayer(config, context", StringComparison.Ordinal);
            Assert.Greater(build, 0, "Boot SDK build call not found.");
            Assert.Greater(reload, build, "Config must be reloaded after the Boot SDK build.");
            Assert.Greater(staging, reload, "Packaged staging must use the reloaded Config.");
        }

        [Test]
        public void PlayerRestoreIsRegisteredBeforeTheStepsThatCanFail()
        {
            string root = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(ManagedAddressableSynchronizer).Assembly).resolvedPath;
            string source = File.ReadAllText(Path.Combine(root, "Editor/ManagedBootstrapSplitPlayerBuild.cs"));
            int restore = source.IndexOf("EditorApplication.delayCall += FinishSplitPackagingWhenIdle", StringComparison.Ordinal);
            Assert.Greater(restore, 0, "Restore registration not found.");
            Assert.Less(restore, source.IndexOf("WriteSplitJson(PendingPlayerPath, pendingPlayerLink)", StringComparison.Ordinal));
            Assert.Less(restore, source.IndexOf("WriteDevelopmentHttpMarker()", StringComparison.Ordinal));
        }
    }

    internal sealed class ManagedBootstrapSplitFixture : IDisposable
    {
        internal const string BootKey = "qa.production1.boot";
        internal const string RevisionKey = "qa.production1.game";
        private static readonly FieldInfo Default = typeof(AddressableAssetSettingsDefaultObject)
            .GetField("s_DefaultSettingsObject", BindingFlags.Static | BindingFlags.NonPublic);
        private readonly AddressableAssetSettings previous;
        private readonly string bootAssetGuid, revisionAssetGuid;
        private string evidenceDirectory;
        internal string Root { get; }
        internal string Output { get; }
        internal string ConfigPath => Root + "/Config.asset";
        internal AddressableAssetSettings Settings { get; private set; }
        internal ManagedAddressableProjectConfig Config { get; private set; }
        internal AddressableAssetGroup Boot { get; private set; }
        internal AddressableAssetGroup Revision { get; private set; }
        private string bootGroupGuid, revisionGroupGuid;

        internal ManagedBootstrapSplitFixture()
        {
            previous = AddressableAssetSettingsDefaultObject.Settings;
            // Reuse the existing fixture-only SDK import callback isolation. No production adapter is replaced.
            ManagedFrameworkHostTests.ImportCallback(previous, false);
            string id = Guid.NewGuid().ToString("N");
            Root = "Assets/ManagedBootstrapSplitQA_" + id;
            Output = "P1/q_" + id.Substring(0, 8);
            Directory.CreateDirectory(Root + "/Content");
            Directory.CreateDirectory(Output);
            AssetDatabase.Refresh();
            Settings = AddressableAssetSettings.Create(Root + "/Settings", "Settings", false, true);
            Settings.BuildAddressablesWithPlayerBuild = AddressableAssetSettings.PlayerBuildOption.DoNotBuildWithPlayer;
            Default.SetValue(null, Settings);
            Boot = Group("QA explicit Boot", true);
            Revision = Group("QA explicit Revision", false);
            bootGroupGuid = GuidOf(Boot);
            revisionGroupGuid = GuidOf(Revision);
            File.WriteAllText(Root + "/Content/Boot.txt", "PRODUCTION1_BOOT_STABLE");
            File.WriteAllText(Root + "/Content/Game.txt", "PRODUCTION1_GAME_A");
            AssetDatabase.Refresh();
            bootAssetGuid = AssetDatabase.AssetPathToGUID(Root + "/Content/Boot.txt");
            revisionAssetGuid = AssetDatabase.AssetPathToGUID(Root + "/Content/Game.txt");
            Settings.CreateOrMoveEntry(bootAssetGuid, Boot, false, false).SetAddress(BootKey, false);
            Settings.CreateOrMoveEntry(revisionAssetGuid, Revision, false, false).SetAddress(RevisionKey, false);
            Config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            Config.SetContentRoot(Root + "/Content");
            Config.autoRegister = false;
            Config.backupBeforeApply = false;
            Config.buildOutputRoot = Output;
            Config.ownedGroupGuids.Add(GuidOf(Boot));
            Config.ownedGroupGuids.Add(GuidOf(Revision));
            AssetDatabase.CreateAsset(Config, ConfigPath);
            Save();
        }

        private AddressableAssetGroup Group(string name, bool isDefault)
        {
            var group = Settings.CreateGroup(name, isDefault, false, false, null,
                typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
            var schema = group.GetSchema<BundledAssetGroupSchema>();
            schema.UseDefaultSchemaSettings = false;
            schema.BuildPath.SetVariableByName(Settings, AddressableAssetSettings.kLocalBuildPath);
            schema.LoadPath.SetVariableByName(Settings, AddressableAssetSettings.kLocalLoadPath);
            return group;
        }

        internal static string GuidOf(AddressableAssetGroup group) => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
        internal List<ManagedGroupBuildRoleSetting> Roles() => new List<ManagedGroupBuildRoleSetting>
        {
            new ManagedGroupBuildRoleSetting { groupAssetGuid = GuidOf(Boot), role = ManagedGroupBuildRole.Boot, useForSharedBundles = true },
            new ManagedGroupBuildRoleSetting { groupAssetGuid = GuidOf(Revision), role = ManagedGroupBuildRole.Revision, useForSharedBundles = true }
        };
        internal ManagedAddressableSyncPlan RolePlan() => ManagedAddressableSynchronizer.CreateBuildRolePlan(Config, Roles(), new[] { BootKey });
        internal void Save()
        {
            EditorUtility.SetDirty(Settings);
            if (Config != null) EditorUtility.SetDirty(Config);
            AssetDatabase.SaveAssets();
        }
        internal void Reload()
        {
            Settings = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(Root + "/Settings/Settings.asset");
            Config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ConfigPath);
            Boot = AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(AssetDatabase.GUIDToAssetPath(bootGroupGuid));
            Revision = AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(AssetDatabase.GUIDToAssetPath(revisionGroupGuid));
            Assert.IsNotNull(Settings); Assert.IsNotNull(Config); Assert.IsNotNull(Boot); Assert.IsNotNull(Revision);
            Default.SetValue(null, Settings);
        }
        private string EvidenceDirectory
        {
            get
            {
                string root = Environment.GetEnvironmentVariable("AR2_QA_ROOT");
                if (string.IsNullOrWhiteSpace(root)) return null;
                if (evidenceDirectory == null)
                {
                    string name = System.Text.RegularExpressions.Regex.Replace(TestContext.CurrentContext.Test.ID, "[^a-zA-Z0-9_.-]", "_");
                    string tag = Path.GetFileName(Root);
                    evidenceDirectory = Path.Combine(root, "Evidence", Environment.GetEnvironmentVariable("AR2_RUN_LABEL") ?? "manual", "c" + name + "_" + tag.Substring(tag.Length - 8));
                    if (Directory.Exists(evidenceDirectory)) throw new IOException("Preserve previous case evidence: " + evidenceDirectory);
                    Directory.CreateDirectory(evidenceDirectory);
                    using (var stream = new FileStream(Path.Combine(evidenceDirectory, "Case.json"), FileMode.CreateNew, FileAccess.Write))
                    using (var writer = new StreamWriter(stream)) writer.Write(JsonUtility.ToJson(new CaseEvidence
                    { id = TestContext.CurrentContext.Test.ID, name = TestContext.CurrentContext.Test.FullName, assetsRoot = Root, outputRoot = Output }, true));
                }
                return evidenceDirectory;
            }
        }
        internal void PreserveTree(string label, string source)
        {
            string evidence = EvidenceDirectory;
            if (evidence == null) return;
            string target = Path.Combine(evidence, label);
            if (Directory.Exists(target) || File.Exists(target)) throw new IOException("Preserve original raw evidence: " + target);
            Directory.CreateDirectory(target);
            if (Directory.Exists(source)) foreach (string path in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            {
                string destination = Path.Combine(target, path.Substring(source.Length).TrimStart('/', '\\'));
                Directory.CreateDirectory(Path.GetDirectoryName(destination));
                File.Copy(path, destination, false);
            }
        }
        internal void PreserveObservation(string label, object value)
        {
            string evidence = EvidenceDirectory;
            if (evidence == null) return;
            using (var stream = new FileStream(Path.Combine(evidence, label + ".json"), FileMode.CreateNew, FileAccess.Write))
            using (var writer = new StreamWriter(stream)) writer.Write(JsonUtility.ToJson(value, true));
        }
        internal void PreserveBuild(string label, ManagedBuildExportResult result)
        {
            PreserveObservation(label + "-Result", new BuildEvidence { success = result.success, error = result.error,
                outputDirectory = result.outputDirectory, receiptPath = result.splitReceiptPath,
                warnings = result.warnings.ToArray() });
            if (!string.IsNullOrWhiteSpace(result.outputDirectory) && Directory.Exists(result.outputDirectory)) PreserveTree(label + "-Artifacts", result.outputDirectory);
        }
        [Serializable]
        private sealed class CaseEvidence { public string id, name, assetsRoot, outputRoot; }
        [Serializable]
        private sealed class BuildEvidence
        {
            public bool success;
            public string error, outputDirectory, receiptPath;
            public string[] warnings;
        }
        internal string GroupState(AddressableAssetGroup group) => EditorJsonUtility.ToJson(group) + "\n" +
            string.Join("\n", group.Schemas.Where(s => s != null).OrderBy(s => AssetDatabase.GetAssetPath(s)).Select(s => EditorJsonUtility.ToJson(s)));
        internal Dictionary<string, string> Files() => Directory.GetFiles(Root, "*", SearchOption.AllDirectories)
            .ToDictionary(p => p.Replace('\\', '/'), p => Convert.ToBase64String(File.ReadAllBytes(p)));
        internal static void Same(Dictionary<string, string> before, Dictionary<string, string> after, string except = null)
        {
            CollectionAssert.AreEquivalent(before.Keys, after.Keys);
            foreach (var file in before) if (file.Key != except) Assert.AreEqual(file.Value, after[file.Key], file.Key);
        }
        internal void AssertOriginalEntries()
        {
            Assert.AreEqual(bootAssetGuid, Boot.entries.Single().guid);
            Assert.AreEqual(BootKey, Boot.entries.Single().address);
            Assert.AreEqual(revisionAssetGuid, Revision.entries.Single().guid);
            Assert.AreEqual(RevisionKey, Revision.entries.Single().address);
        }
        public void Dispose()
        {
            try { PreserveTree("Final-Input-Assets", Root); }
            finally
            {
                ManagedFrameworkHostTests.ImportCallback(Settings, false);
                Default.SetValue(null, previous);
                AssetDatabase.DeleteAsset(Root);
                ManagedFrameworkHostTests.ImportCallback(previous, true);
            }
            // Own dedicated SDK output is retained as evidence; no shared cache/staging deletion.
        }
    }
}
