using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Reflection;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // The receipt/file boundary uses opaque bytes here. Independent QA consumes an
    // actual, previously verified SDK receipt without rebuilding its content.
    public sealed class ManagedPackagedRevisionAuthoringTests
    {
        private string asset, output, receiptPath, catalogPath, bundlePath;
        private ManagedAddressableProjectConfig config;
        private static string Sha(string path) { using (var hash = SHA256.Create()) using (var file = File.OpenRead(path)) return BitConverter.ToString(hash.ComputeHash(file)).Replace("-", "").ToLowerInvariant(); }
        [SetUp] public void SetUp()
        {
            string id = Guid.NewGuid().ToString("N").Substring(0, 8); asset = "Assets/PackagedQA_" + id + ".asset";
            output = Path.GetFullPath("P2/q_" + id); Directory.CreateDirectory(output);
            config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.buildOutputRoot = "P2/q_" + id;
            AssetDatabase.CreateAsset(config, asset); AssetDatabase.SaveAssetIfDirty(config);
            catalogPath = Path.Combine(output, "source-catalog.json"); bundlePath = Path.Combine(output, "content.bundle");
            File.WriteAllText(catalogPath, "opaque SDK receipt contract catalog", new UTF8Encoding(false)); File.WriteAllText(bundlePath, "opaque UnityFS boundary", new UTF8Encoding(false));
            receiptPath = Path.Combine(output, "source-receipt.json");
            var receipt = new ManagedSplitBuildReceipt { complete = true, rawSettingsRestored = true, effectiveSettingsRestored = true,
                purpose = "Revision", catalogFormat = "json", platform = EditorUserBuildSettings.activeBuildTarget.ToString(), stamp = "explicit-fixture-id",
                inputFingerprint = new string('a', 64), contentFingerprint = new string('a', 64), effectiveInput = "opaque matching validated settings", configAssetGuid = AssetDatabase.AssetPathToGUID(asset),
                settingsAssetGuid = new string('b', 32), unityVersion = Application.unityVersion, addressablesVersion = ManagedAddressableBuildExporter.AddressablesVersion,
                keys = new List<string> { "revision.only" }, exclusiveRoleKeys = new List<string> { "revision.only" },
                catalogPath = catalogPath, catalogSha256 = Sha(catalogPath), bundles = new List<ManagedSplitBundleReceipt> { new ManagedSplitBundleReceipt {
                    filePath = bundlePath, sha256 = Sha(bundlePath), bundleName = "sdk-bundle-name", hash = "11111111111111111111111111111111", crc = 17 } } };
            File.WriteAllText(receiptPath, JsonUtility.ToJson(receipt), new UTF8Encoding(false));
        }
        [TearDown] public void TearDown()
        {
            if (config != null) AssetDatabase.DeleteAsset(asset);
            string expected = Path.GetFullPath("P2").TrimEnd('/', '\\') + Path.DirectorySeparatorChar;
            Assert.That(Path.GetFullPath(output).StartsWith(expected, StringComparison.OrdinalIgnoreCase), Is.True);
            if (Directory.Exists(output)) Directory.Delete(output, true);
        }
        private static ManagedRevisionReleaseMetadata Release() => new ManagedRevisionReleaseMetadata
            { productId = "product", channel = "fixture", authorityId = "same-deployer", compatibilityFamily = "F", deploymentSequence = 20 };

        [Test] public void PreviewIsReadOnlyAndApplyPublishesExplicitMetadataWithoutSdkBuild()
        {
            byte[] configBytes = File.ReadAllBytes(asset), catalog = File.ReadAllBytes(catalogPath), bundle = File.ReadAllBytes(bundlePath);
            var plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, receiptPath, Release());
            Assert.That(plan.CanApply, Is.True, plan.ToString()); Assert.That(Directory.Exists(plan.outputDirectory), Is.False);
            Assert.That(File.ReadAllBytes(asset), Is.EqualTo(configBytes)); Assert.That(EditorUtility.IsDirty(config), Is.False);
            string metadata = ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, plan);
            var anchor = JsonUtility.FromJson<ManagedPackagedRevisionAnchor>(File.ReadAllText(metadata));
            var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(Path.Combine(Path.GetDirectoryName(metadata), "publisher.json")));
            Assert.That(anchor.deploymentSequence, Is.EqualTo(20)); Assert.That(publisher.authorityId, Is.EqualTo("same-deployer"));
            Assert.That(anchor.publisherSha256, Is.EqualTo(Sha(Path.Combine(Path.GetDirectoryName(metadata), "publisher.json"))));
            Assert.That(config.packagedRevisionMetadataSha256, Is.EqualTo(Sha(metadata)));
            Assert.IsFalse(Path.IsPathRooted(config.packagedRevisionMetadataPath));
            Assert.AreEqual(Path.GetFullPath(metadata), Path.GetFullPath(config.packagedRevisionMetadataPath));
            Assert.That(File.ReadAllBytes(Path.Combine(Path.GetDirectoryName(metadata), "catalog.json")), Is.EqualTo(catalog));
            Assert.That(File.ReadAllBytes(Path.Combine(Path.GetDirectoryName(metadata), "bundles/content.bundle")), Is.EqualTo(bundle));
            Assert.That(File.ReadAllBytes(catalogPath), Is.EqualTo(catalog)); Assert.That(File.ReadAllBytes(bundlePath), Is.EqualTo(bundle));
        }
        [Test] public void MissingAuthoritySequenceIsNotGeneratedOrInferredFromRevisionId()
        {
            var release = Release(); release.deploymentSequence = 0;
            var plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, receiptPath, release);
            Assert.That(plan.CanApply, Is.False); Assert.That(plan.ToString(), Does.Contain("positive deploymentSequence"));
            Assert.That(string.IsNullOrEmpty(config.packagedRevisionMetadataPath), Is.True);
        }
        [Test] public void ChangedSourceAfterPreviewIsRejectedBeforeAnyOutput()
        {
            var plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, receiptPath, Release()); Assert.That(plan.CanApply, Is.True, plan.ToString());
            File.AppendAllText(bundlePath, "different");
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, plan));
            Assert.That(Directory.Exists(plan.outputDirectory), Is.False); Assert.That(string.IsNullOrEmpty(config.packagedRevisionMetadataPath), Is.True);
        }
        [Test] public void ConfigChangeAndRepeatedApplyCannotReuseReviewedOutput()
        {
            var plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, receiptPath, Release());
            config.revisionRelease = Release(); config.revisionRelease.deploymentSequence = 21; EditorUtility.SetDirty(config); AssetDatabase.SaveAssetIfDirty(config);
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, plan));
            plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, receiptPath, Release());
            ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, plan);
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, plan));
        }
        [Test] public void PublisherIsNotWrittenWithoutReleaseMetadata()
        {
            var receipt = JsonUtility.FromJson<ManagedSplitBuildReceipt>(File.ReadAllText(receiptPath));
            var write = typeof(ManagedAddressableBuildExporter).GetMethod("WriteRevisionPublisher", BindingFlags.Static | BindingFlags.NonPublic);
            var error = Assert.Throws<TargetInvocationException>(() => write.Invoke(null, new object[] { receipt, null }));
            Assert.That(error.InnerException, Is.TypeOf<InvalidOperationException>());
            Assert.That(File.Exists(Path.Combine(Path.GetDirectoryName(receipt.catalogPath), "revision_publisher.json")), Is.False);
        }

        private ManagedSplitBuildReceipt RevisionFacts() => JsonUtility.FromJson<ManagedSplitBuildReceipt>(File.ReadAllText(receiptPath));
        private ManagedSplitBuildReceipt BootFacts()
        {
            var boot = RevisionFacts(); boot.purpose = "Boot"; boot.catalogFormat = "binary";
            boot.keys = new List<string> { "boot.only" }; boot.exclusiveRoleKeys = new List<string>(boot.keys); return boot;
        }

        [Test] public void ProvenCommonLabelIsAllowedWithinOneValidationGeneration()
        {
            var revision = RevisionFacts(); var boot = BootFacts();
            revision.keys.Add("Locale-en"); boot.keys.Add("Locale-en"); revision.commonLabels.Add("Locale-en"); boot.commonLabels.Add("Locale-en");
            Assert.That(ManagedAddressableBuildExporter.ValidatePackagedBootFacts(revision, boot, null), Is.EqualTo("SameValidationGeneration"));
        }
        [TestCase(true)] [TestCase(false)] public void UnprovenKeyIntersectionOrGenerationIsNotSilentlyAccepted(bool unprovenKey)
        {
            var revision = RevisionFacts(); var boot = BootFacts();
            if (unprovenKey) { boot.keys.Add("revision.only"); revision.commonLabels.Add("revision.only"); }
            else boot.contentFingerprint = new string('c', 64);
            var error = Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ValidatePackagedBootFacts(revision, boot, null));
            Assert.That(error.Message, Does.Contain(unprovenKey ? "공유 label" : "검증 세대"));
        }
        [TestCase("same")] [TestCase("catalog")] [TestCase("bundleSha")] [TestCase("sdkCrc")] [TestCase("sourceGeneration")]
        public void CrossGenerationRequiresTheActualPairedBootAndExactCatalogBundleEvidence(string change)
        {
            var revision = RevisionFacts(); var original = BootFacts(); var current = BootFacts(); current.contentFingerprint = new string('c', 64);
            if (change == "catalog") current.catalogSha256 = new string('d', 64);
            if (change == "bundleSha") current.bundles[0].sha256 = new string('d', 64);
            if (change == "sdkCrc") current.bundles[0].crc++;
            if (change == "sourceGeneration") original.contentFingerprint = new string('e', 64);
            if (change == "same") Assert.That(ManagedAddressableBuildExporter.ValidatePackagedBootFacts(revision, current, original), Is.EqualTo("UnchangedPairedBootContent"));
            else Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ValidatePackagedBootFacts(revision, current, original));
        }
        [Test] public void RawReceiptProofIsExactAndExcludedFromTheAppPayload()
        {
            string bootPath = Path.Combine(output, "source-boot-receipt.json"); File.WriteAllText(bootPath, JsonUtility.ToJson(BootFacts()), new UTF8Encoding(false));
            byte[] revisionRaw = File.ReadAllBytes(receiptPath), bootRaw = File.ReadAllBytes(bootPath);
            var plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, receiptPath, Release(), bootPath);
            Assert.That(plan.CanApply, Is.True, plan.ToString()); string metadata = ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, plan);
            Assert.That(Path.GetDirectoryName(metadata), Is.EqualTo(plan.PayloadDirectory));
            Assert.That(File.ReadAllBytes(Path.Combine(plan.outputDirectory, "Proof/Revision.json")), Is.EqualTo(revisionRaw));
            Assert.That(File.ReadAllBytes(Path.Combine(plan.outputDirectory, "Proof/Boot.json")), Is.EqualTo(bootRaw));
            Assert.That(Directory.Exists(Path.Combine(plan.PayloadDirectory, "Proof")), Is.False);
        }

        [Test]
        public void ReceiptsFromOneContentGenerationMatchEvenWhenPlayerInputsDiffer()
        {
            var revision = RevisionFacts(); var boot = BootFacts();
            boot.inputFingerprint = new string('c', 64);
            Assert.AreEqual("SameValidationGeneration", ManagedAddressableBuildExporter.ValidatePackagedBootFacts(revision, boot, null));
            boot.contentFingerprint = null;
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ValidatePackagedBootFacts(revision, boot, null));
        }

        [Test]
        public void OldAbsoluteAndNewRelativeLinksReadTheSamePayloadAndNeverSkipPackagingSha()
        {
            var plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, receiptPath, Release());
            Assert.IsTrue(plan.CanApply, plan.ToString());
            string metadata = ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, plan);
            var validate = typeof(ManagedAddressableBuildExporter).GetMethod("ValidatePackagedRevision", BindingFlags.Static | BindingFlags.NonPublic);
            foreach (string path in new[] { metadata, config.packagedRevisionMetadataPath })
                Assert.AreEqual(plan.anchorSha, validate.Invoke(null, new object[] { path, plan.anchorSha }));
            File.AppendAllText(Path.Combine(plan.PayloadDirectory, "catalog.json"), "different packaged A");
            var error = Assert.Throws<TargetInvocationException>(() => validate.Invoke(null, new object[] { config.packagedRevisionMetadataPath, plan.anchorSha }));
            Assert.That(error.InnerException, Is.InstanceOf<IOException>());
        }
    }
}
