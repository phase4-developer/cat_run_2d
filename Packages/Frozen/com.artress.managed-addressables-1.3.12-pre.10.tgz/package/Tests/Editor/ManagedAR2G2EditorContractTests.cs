using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.ResourceProviders;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedAR2G2EditorContractTests
    {
        private string root, output;
        private AddressableAssetSettings settings, previous;
        private ManagedAddressableProjectConfig config;
        private static readonly FieldInfo Default = typeof(AddressableAssetSettingsDefaultObject).GetField("s_DefaultSettingsObject", BindingFlags.Static | BindingFlags.NonPublic);

        [Serializable]
        private sealed class MatrixRow
        {
            public bool cache, crc, useCrcForCachedBundle;
            public string noHashFilename, sourceHash, catalogHash;
            public uint sourceCrc, catalogCrc;
        }

        [Serializable]
        private sealed class MatrixEvidence { public List<MatrixRow> rows; }

        [SetUp]
        public void Setup()
        {
            previous = AddressableAssetSettingsDefaultObject.Settings;
            ImportCallback(previous, false);
            string id = Guid.NewGuid().ToString("N");
            root = "Assets/ManagedAR2G2Editor_" + id;
            output = "Library/ManagedAR2G2Editor_" + id;
            Directory.CreateDirectory(root + "/Content");
            Directory.CreateDirectory(output);
            AssetDatabase.Refresh();
            settings = AddressableAssetSettings.Create(root + "/Settings", "Settings", true, true);
            Default.SetValue(null, settings);
            config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.SetContentRoot(root + "/Content");
            config.backupBeforeApply = false;
            config.buildOutputRoot = output + "/Remote";
            AssetDatabase.CreateAsset(config, root + "/Config.asset");
            AssetDatabase.SaveAssets();
        }

        [TearDown]
        public void Teardown()
        {
            ImportCallback(settings, false);
            Default.SetValue(null, previous);
            AssetDatabase.DeleteAsset(root);
            ImportCallback(previous, true);
            // Build output remains as immutable, own neutral QA evidence under Library.
        }

        private static void ImportCallback(AddressableAssetSettings target, bool enabled)
        {
            if (target == null) return;
            Type processor = typeof(AddressableAssetSettings).Assembly.GetType("UnityEditor.AddressableAssets.Settings.AddressablesAssetPostProcessor", true);
            object callbacks = processor.GetProperty("OnPostProcess", BindingFlags.Static | BindingFlags.Public).GetValue(null);
            MethodInfo register = callbacks.GetType().GetMethod("Register");
            Delegate callback = Delegate.CreateDelegate(register.GetParameters()[0].ParameterType, target, typeof(AddressableAssetSettings).GetMethod("OnPostprocessAllAssets", BindingFlags.Instance | BindingFlags.NonPublic));
            if (enabled) register.Invoke(callbacks, new object[] { callback, 0 });
            else callbacks.GetType().GetMethod("Unregister").Invoke(callbacks, new object[] { callback });
        }

        private AddressableAssetGroup Group(string name, bool remote = false)
        {
            var group = settings.CreateGroup(name, false, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
            var schema = group.GetSchema<BundledAssetGroupSchema>();
            schema.UseDefaultSchemaSettings = false;
            schema.BuildPath.SetVariableByName(settings, remote ? AddressableAssetSettings.kRemoteBuildPath : AddressableAssetSettings.kLocalBuildPath);
            schema.LoadPath.SetVariableByName(settings, remote ? AddressableAssetSettings.kRemoteLoadPath : AddressableAssetSettings.kLocalLoadPath);
            return group;
        }

        private string Text(string relative, string marker = "NEUTRAL_A")
        {
            string path = root + "/" + relative + ".txt";
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, marker);
            AssetDatabase.Refresh();
            return path;
        }

        private AddressableAssetEntry Register(string path, AddressableAssetGroup group, string key)
        {
            var entry = settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), group, false, false);
            entry.SetAddress(key, false);
            return entry;
        }

        private static Dictionary<string, string> Files(string path) => Directory.Exists(path)
            ? Directory.GetFiles(path, "*", SearchOption.AllDirectories).ToDictionary(p => p.Replace('\\', '/'), p => Convert.ToBase64String(File.ReadAllBytes(p)))
            : new Dictionary<string, string>();

        private void Adopt(params AddressableAssetGroup[] groups)
        {
            var plan = ManagedAddressableSynchronizer.CreateOwnershipPlan(config, groups);
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
        }

        private void SdkRevisionSettings()
        {
            settings.EnableJsonCatalog = true;
            settings.BuildRemoteCatalog = true;
            settings.OverridePlayerVersion = "[UnityEditor.PlayerSettings.bundleVersion]";
            if (!settings.profileSettings.GetVariableNames().Contains("BuildVersion"))
                settings.profileSettings.CreateValue("BuildVersion", "[UnityEditor.PlayerSettings.bundleVersion]");
            settings.profileSettings.SetValue(settings.activeProfileId, AddressableAssetSettings.kRemoteBuildPath, config.buildOutputRoot + "/[BuildTarget]/[BuildVersion]");
            settings.profileSettings.SetValue(settings.activeProfileId, AddressableAssetSettings.kRemoteLoadPath, "http://127.0.0.1:19843/g2-editor/A");
            settings.RemoteCatalogBuildPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteBuildPath);
            settings.RemoteCatalogLoadPath.SetVariableByName(settings, AddressableAssetSettings.kRemoteLoadPath);
            for (int i = 0; i < settings.DataBuilders.Count; i++)
                if (settings.DataBuilders[i] is BuildScriptPackedMode) settings.ActivePlayerDataBuilderIndex = i;
        }

        private string BuildOutput => Path.Combine(config.buildOutputRoot, EditorUserBuildSettings.activeBuildTarget.ToString(), PlayerSettings.bundleVersion);

        private void PreserveOutput(string source, string relative)
        {
            string destination = Path.GetFullPath(Path.Combine(output, relative));
            Assert.IsTrue(destination.StartsWith(Path.GetFullPath(output) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase));
            Assert.IsFalse(Directory.Exists(destination), "Preserve previous build evidence.");
            Directory.CreateDirectory(destination);
            foreach (string path in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            {
                string target = Path.Combine(destination, path.Substring(source.Length).TrimStart('/', '\\'));
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                File.Copy(path, target, false);
            }
        }

        [Test]
        public void AdoptionAndReleaseUseReviewedConfigOnlyPlanWithoutTouchingGroupData()
        {
            var group = Group("SDK owned by another package");
            var entry = Register(Text("Outside/Existing"), group, "published.key");
            entry.SetLabel("official-label", true, true, false);
            AssetDatabase.SaveAssets();
            var before = Files(root + "/Settings");
            string guid = group.Guid;
            var plan = ManagedAddressableSynchronizer.CreateOwnershipPlan(config, new[] { group });
            Assert.IsFalse(config.OwnsGroup(group));
            CollectionAssert.AreEquivalent(before, Files(root + "/Settings"));
            Assert.IsTrue(plan.Changes.Any(c => c.property.Contains("ownership")));
            Assert.AreEqual(plan.Report.ToString(), ManagedAddressableSynchronizer.ApplyPlan(config, plan).ToString());
            Assert.IsTrue(config.OwnsGroup(group));
            Assert.AreEqual(guid, group.Guid);
            Assert.AreEqual("published.key", entry.address);
            CollectionAssert.AreEquivalent(before, Files(root + "/Settings"));
            var again = ManagedAddressableSynchronizer.CreateOwnershipPlan(config, new[] { group });
            Assert.IsFalse(again.HasChanges);
            ManagedAddressableSynchronizer.ApplyPlan(config, again);
            var release = ManagedAddressableSynchronizer.CreateOwnershipPlan(config, releaseGroupGuids: config.ownedGroupGuids.ToArray());
            ManagedAddressableSynchronizer.ApplyPlan(config, release);
            Assert.IsFalse(config.OwnsGroup(group));
            CollectionAssert.AreEquivalent(before, Files(root + "/Settings"));
        }

        [Test]
        public void MissingGuidIsWarningOnlyAndRemovedOnlyByReviewedCleanup()
        {
            string missing = Guid.NewGuid().ToString("N");
            config.ownedGroupGuids.Add(missing);
            EditorUtility.SetDirty(config);
            AssetDatabase.SaveAssetIfDirty(config);
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Assert.IsTrue(plan.CanApply, plan.Report.ToString());
            Assert.IsTrue(plan.Warnings.Any(w => w.Contains(missing)));
            Assert.IsFalse(plan.HasChanges);
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            CollectionAssert.Contains(config.ownedGroupGuids, missing);
            var cleanup = ManagedAddressableSynchronizer.CreateOwnershipPlan(config, removeMissing: true);
            CollectionAssert.Contains(config.ownedGroupGuids, missing);
            ManagedAddressableSynchronizer.ApplyPlan(config, cleanup);
            CollectionAssert.IsEmpty(config.ownedGroupGuids);
        }

        [Test]
        public void ForeignSdkGroupsEntriesProfilesAndNormalSchemasArePreservedAndNotBlocked()
        {
            var group = Group("UI");
            var optional = Group("Localization-String-Tables-English");
            var analyze = Group("Duplicate Asset Isolation");
            string path = Text("Content/Local/UI/Existing");
            Register(path, group, "official.keep");
            Register(Text("Outside/Optional"), optional, "locale.key").SetLabel("Localization", true, true, false);
            Register(Text("Outside/Analyze"), analyze, "fixed.dep");
            string fresh = Text("Content/Local/UI/New");
            settings.profileSettings.SetValue(settings.activeProfileId, AddressableAssetSettings.kRemoteLoadPath, "https://sdk.example.invalid/custom");
            AssetDatabase.SaveAssets();
            var before = Files(root);
            string semantic = EditorJsonUtility.ToJson(settings);
            var plan = ManagedAddressableSynchronizer.CreatePlan(config, true);
            Assert.IsTrue(plan.CanApply, plan.Report.ToString());
            Assert.IsFalse(plan.HasChanges, plan.Report.ToString());
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            CollectionAssert.AreEquivalent(before, Files(root));
            Assert.AreEqual(semantic, EditorJsonUtility.ToJson(settings));
            Assert.AreEqual("official.keep", settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(path)).address);
            Assert.IsNull(settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(fresh)), "An unowned target is not silently adopted.");
            CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config));
        }

        [Test]
        public void OwnedExternalAddressCollisionIsDiagnosedWithoutRejectingPureExternalDuplicates()
        {
            var a = Group("ForeignA");
            var b = Group("ForeignB");
            Register(Text("Outside/A"), a, "shared.collision");
            Register(Text("Outside/B"), b, "shared.collision");
            AssetDatabase.SaveAssets();
            CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config));
            Assert.IsTrue(ManagedAddressableSynchronizer.CreatePlan(config).CanApply);
            Adopt(a);
            var before = Files(root);
            Assert.IsTrue(ManagedAddressableValidator.Validate(config).Any(e => e.Contains("shared.collision")));
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.CreatePlan(config));
            CollectionAssert.AreEquivalent(before, Files(root));
        }

        [Test]
        public void OwnershipPlanRejectsStaleExternalEditsAndNewPreviewKeepsThem()
        {
            var group = Group("Foreign");
            AssetDatabase.SaveAssets();
            var plan = ManagedAddressableSynchronizer.CreateOwnershipPlan(config, new[] { group });
            var schema = group.GetSchema<BundledAssetGroupSchema>();
            schema.Compression = BundledAssetGroupSchema.BundleCompressionMode.Uncompressed;
            AssetDatabase.SaveAssetIfDirty(schema);
            var before = Files(root);
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(config, plan));
            CollectionAssert.AreEquivalent(before, Files(root));
            Adopt(group);
            Assert.AreEqual(BundledAssetGroupSchema.BundleCompressionMode.Uncompressed, schema.Compression);
        }

        [Test]
        public void ExplicitCacheCrcPolicyTouchesOnlyOwnedRemoteGroupAndRepeatsWithoutEvents()
        {
            SdkRevisionSettings();
            var owned = Group("OwnedRemote", true);
            var foreign = Group("ForeignRemote", true);
            var local = Group("OwnedLocal");
            foreach (var group in new[] { owned, foreign, local })
            {
                var schema = group.GetSchema<BundledAssetGroupSchema>();
                schema.UseAssetBundleCache = false; schema.UseAssetBundleCrc = false;
            }
            AssetDatabase.SaveAssets();
            Adopt(owned, local);
            string foreignBefore = EditorJsonUtility.ToJson(foreign.GetSchema<BundledAssetGroupSchema>());
            string localBefore = EditorJsonUtility.ToJson(local.GetSchema<BundledAssetGroupSchema>());
            string profiles = JsonUtility.ToJson(settings.profileSettings);
            var plan = ManagedAddressableSynchronizer.CreateRevisionBuildPlan(config);
            Assert.IsTrue(plan.CanApply, plan.Report.ToString());
            Assert.IsTrue(plan.Changes.All(c => c.scope == "Group" && c.target == owned.Name));
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            var target = owned.GetSchema<BundledAssetGroupSchema>();
            Assert.IsTrue(target.UseAssetBundleCache); Assert.IsTrue(target.UseAssetBundleCrc); Assert.IsFalse(target.UseAssetBundleCrcForCachedBundles);
            Assert.AreEqual(foreignBefore, EditorJsonUtility.ToJson(foreign.GetSchema<BundledAssetGroupSchema>()));
            Assert.AreEqual(localBefore, EditorJsonUtility.ToJson(local.GetSchema<BundledAssetGroupSchema>()));
            Assert.AreEqual(profiles, JsonUtility.ToJson(settings.profileSettings));
            int events = 0;
            Action<AddressableAssetSettings, AddressableAssetSettings.ModificationEvent, object> observe = (s, e, o) => { if (s == settings) events++; };
            AddressableAssetSettings.OnModificationGlobal += observe;
            try { var repeat = ManagedAddressableSynchronizer.CreateRevisionBuildPlan(config); Assert.IsFalse(repeat.HasChanges); ManagedAddressableSynchronizer.ApplyPlan(config, repeat); }
            finally { AddressableAssetSettings.OnModificationGlobal -= observe; }
            Assert.AreEqual(0, events);
        }

        [Test]
        public void FailedNewGroupApplyRestoresConfigOwnershipAndGroupFiles()
        {
            Text("Content/Local/UI/New");
            AssetDatabase.SaveAssets();
            var before = Files(root);
            var ownership = config.ownedGroupGuids.ToArray();
            var plan = ManagedAddressableSynchronizer.CreatePlan(config);
            Action<AddressableAssetSettings, AddressableAssetSettings.ModificationEvent, object> fail = null;
            fail = (sender, change, data) =>
            {
                if (sender == settings && change == AddressableAssetSettings.ModificationEvent.BatchModification)
                {
                    AddressableAssetSettings.OnModificationGlobal -= fail;
                    throw new InvalidOperationException("Synthetic failure after new Group ownership was recorded");
                }
            };
            AddressableAssetSettings.OnModificationGlobal += fail;
            try { Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(config, plan)); }
            finally { AddressableAssetSettings.OnModificationGlobal -= fail; }
            CollectionAssert.AreEqual(ownership, config.ownedGroupGuids);
            CollectionAssert.AreEquivalent(before, Files(root));
            Assert.IsNull(settings.FindGroup("UI"));
        }

        [Test, Category("AR2G2AuthoringBuild")]
        public void SdkCacheAndCrcFlagsControlActualCatalogFieldsIndependentlyOfNoHash()
        {
            SdkRevisionSettings();
            var remote = Group("Remote_UI", true);
            Register(Text("Content/Remote/UI/Item"), remote, "shared");
            var schema = remote.GetSchema<BundledAssetGroupSchema>();
            schema.BundleNaming = BundledAssetGroupSchema.BundleNamingStyle.NoHash;
            schema.InternalBundleIdMode = BundledAssetGroupSchema.BundleInternalIdMode.GroupGuid;
            schema.AssetBundledCacheClearBehavior = BundledAssetGroupSchema.CacheClearBehavior.ClearWhenSpaceIsNeededInCache;
            var records = new List<MatrixRow>();
            string filename = null;
            foreach (bool cache in new[] { false, true })
            foreach (bool crc in new[] { false, true })
            {
                schema.UseAssetBundleCache = cache; schema.UseAssetBundleCrc = crc; schema.UseAssetBundleCrcForCachedBundles = false;
                AssetDatabase.SaveAssets();
                AddressableAssetSettings.BuildPlayerContent(out AddressablesPlayerBuildResult built);
                Assert.IsTrue(string.IsNullOrEmpty(built.Error), built.Error);
                var info = built.AssetBundleBuildResults.Single(b => b.SourceAssetGroup == remote);
                string catalog = Directory.GetFiles(BuildOutput, "catalog*.json").Single();
                var data = JsonUtility.FromJson<JsonContentCatalogData>(File.ReadAllText(catalog));
                var location = data.CreateLocator().AllLocations.Distinct().Single(l => l.Data is AssetBundleRequestOptions o && o.BundleName == info.InternalBundleName);
                var options = (AssetBundleRequestOptions)location.Data;
                if (cache) { Assert.AreEqual(info.Hash, options.Hash); Assert.IsTrue(Hash128.Parse(options.Hash).isValid); }
                else Assert.IsTrue(string.IsNullOrEmpty(options.Hash));
                Assert.AreEqual(crc ? info.Crc : 0u, options.Crc);
                Assert.IsFalse(options.UseCrcForCachedBundle);
                string actualFilename = Path.GetFileName(new Uri(location.InternalId).AbsolutePath);
                if (filename == null) filename = actualFilename;
                Assert.AreEqual(filename, actualFilename, "NoHash filename policy is independent from Catalog cache Hash.");
                records.Add(new MatrixRow { cache = cache, crc = crc, noHashFilename = actualFilename, sourceHash = info.Hash, sourceCrc = info.Crc, catalogHash = options.Hash, catalogCrc = options.Crc, useCrcForCachedBundle = options.UseCrcForCachedBundle });
                PreserveOutput(BuildOutput, "Matrix/cache-" + cache + "-crc-" + crc);
            }
            File.WriteAllText(output + "/sdk-cache-crc-matrix.json", JsonUtility.ToJson(new MatrixEvidence { rows = records }, true));
            TestContext.WriteLine("AR2_G2_CACHE_CRC_MATRIX=" + Path.GetFullPath(output + "/sdk-cache-crc-matrix.json"));
        }

    }
}
