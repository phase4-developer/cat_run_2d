using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // The guide's steps from an empty project to a Windows Player, on the Revision Host from Tests/Fixtures~.
    // Its Config and content stay in the Host for the Player, so run this case alone and last.
    public sealed class ManagedOfficialChainTests
    {
        private const string Root = "Assets/ManagedChain", Content = Root + "/Content", ScenePath = Root + "/Chain.unity";
        private const string MarkerType = "Artress.ManagedAddressables.HostFixture.ManagedHostMarker, Artress.ManagedAddressables.HostFixture";
        private const string DriverType = "Artress.ManagedAddressables.HostFixture.ManagedChainPlayerDriver, Artress.ManagedAddressables.HostFixture";

        private static string Sha(string path)
        {
            using (var stream = File.OpenRead(path)) using (var hash = SHA256.Create())
                return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        private static void Apply(ManagedAddressableProjectConfig config, ManagedAddressableSyncPlan plan)
        {
            Assert.IsTrue(plan.CanApply, plan.Report.ToString());
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            AssetDatabase.SaveAssets();
        }

        private static TextAsset Text(string path, string value)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, value);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
            return AssetDatabase.LoadAssetAtPath<TextAsset>(path);
        }

        private static void MarkerPrefab(string path, string revision, TextAsset dependency)
        {
            var go = new GameObject(Path.GetFileNameWithoutExtension(path));
            try
            {
                var serialized = new SerializedObject(go.AddComponent(Type.GetType(MarkerType)));
                serialized.FindProperty("revision").stringValue = revision;
                serialized.FindProperty("dependency").objectReferenceValue = dependency;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                Assert.IsNotNull(PrefabUtility.SaveAsPrefabAsset(go, path));
            }
            finally { UnityEngine.Object.DestroyImmediate(go); }
        }

        [Test]
        public void GuideStepsBuildAPlayerWithItsPackagedRevision()
        {
            string player = Environment.GetEnvironmentVariable("MANAGED_CHAIN_PLAYER");
            if (string.IsNullOrWhiteSpace(player)) Assert.Ignore("Builds a Windows Player; run through Tests/Fixtures~/Run-RevisionHost.ps1. NOT_RUN.");
            Assert.IsNotNull(Type.GetType(MarkerType), "The Revision Host fixture is required.");
            Assert.IsNotNull(Type.GetType(DriverType), "The Revision Host fixture is required.");
            Assert.IsFalse(File.Exists(ManagedAddressableProjectConfig.DefaultAssetPath), "Use a fresh Revision Host.");
            Assert.AreEqual(BuildTarget.StandaloneWindows64, EditorUserBuildSettings.activeBuildTarget);

            PlayerSettings.companyName = "JJEvolFrameworkQA";
            PlayerSettings.productName = Environment.GetEnvironmentVariable("MANAGED_CHAIN_PRODUCT") ?? "ManagedChain";

            // Scenes are part of the content fingerprint, so they come before any content build.
            Directory.CreateDirectory(Root);
            AssetDatabase.Refresh();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            new GameObject("Chain").AddComponent(Type.GetType(DriverType));
            Assert.IsTrue(EditorSceneManager.SaveScene(scene, ScenePath));
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Guide 1: game folders, then a Config over them.
            var bootText = Text(Content + "/Local/Core/ChainBootText.txt", "BOOT");
            var gameRules = Text(Content + "/Remote/Game/ChainGameRules.txt", "A");
            MarkerPrefab(Content + "/Local/Core/ChainBootPrefab.prefab", "BOOT", bootText);
            MarkerPrefab(Content + "/Remote/Game/ChainGamePrefab.prefab", "A", gameRules);
            Directory.CreateDirectory(Path.GetDirectoryName(ManagedAddressableProjectConfig.DefaultAssetPath));
            AssetDatabase.Refresh();
            var config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.buildOutputRoot = "C";
            AssetDatabase.CreateAsset(config, ManagedAddressableProjectConfig.DefaultAssetPath);
            config.SetContentRoot(Content);
            config.autoRegister = true;
            config.createGroupIfMissing = true;
            AssetDatabase.SaveAssets();

            // Guide 2-3: Preview Sync, Apply, then the real HTTPS root.
            Apply(config, ManagedAddressableSynchronizer.CreatePlan(config));
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            Assert.IsNotNull(settings, "The first Sync creates SDK Settings.");
            settings.profileSettings.SetValue(settings.activeProfileId, AddressableAssetSettings.kRemoteLoadPath, "https://cdn.example.invalid/chain");
            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets();

            // Guide 4: roles, release metadata, Revision, packaged A.
            var suggestion = ManagedAddressableSynchronizer.SuggestBuildRoles(config, null, null);
            Assert.IsEmpty(suggestion.undecidedGroups);
            Apply(config, ManagedAddressableSynchronizer.CreateBuildRolePlan(config, suggestion.roles, suggestion.bootKeys));
            var release = new ManagedRevisionReleaseMetadata { productId = "framework.chain", channel = "qa", authorityId = "framework-qa", compatibilityFamily = "F", deploymentSequence = 1 };
            Apply(config, ManagedAddressableSynchronizer.CreateRevisionReleasePlan(config, release));
            var revisionPlan = ManagedAddressableBuildExporter.CreateSplitBuildPlan(config, ManagedGroupBuildRole.Revision);
            Assert.IsTrue(revisionPlan.CanBuild, revisionPlan.Report.ToString());
            var revision = ManagedAddressableBuildExporter.BuildReviewedSplitContent(config, revisionPlan);
            Assert.IsTrue(revision.success, revision.error);
            config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ManagedAddressableProjectConfig.DefaultAssetPath);
            var packagedPlan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, revision.splitReceiptPath, release);
            Assert.IsTrue(packagedPlan.CanApply, packagedPlan.ToString());
            string metadata = ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, packagedPlan);

            // Guide 6: the official Player Build makes Boot itself and adds the packaged A.
            AssetDatabase.SaveAssets();
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = new[] { ScenePath }, locationPathName = player,
                target = BuildTarget.StandaloneWindows64, targetGroup = BuildTargetGroup.Standalone, options = BuildOptions.None
            });
            Assert.AreEqual(BuildResult.Succeeded, report.summary.result, string.Join("\n", report.steps.SelectMany(step => step.messages).Where(m => m.type != LogType.Log).Select(m => m.content)));

            string data = Path.Combine(Path.GetDirectoryName(player), Path.GetFileNameWithoutExtension(player) + "_Data", "StreamingAssets");
            Assert.IsTrue(Directory.Exists(Path.Combine(data, "aa")), "The Player must contain the Boot content.");
            string staged = Path.Combine(data, ManagedAddressableBuildExporter.PackagedRevisionStreamingRoot);
            string source = Path.GetDirectoryName(metadata);
            Assert.AreEqual(Sha(metadata), Sha(Path.Combine(staged, "packaged_revision.json")));
            foreach (var file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
                Assert.AreEqual(Sha(file), Sha(Path.Combine(staged, file.Substring(source.Length + 1))), "Player copy differs: " + file);
        }
    }
}
