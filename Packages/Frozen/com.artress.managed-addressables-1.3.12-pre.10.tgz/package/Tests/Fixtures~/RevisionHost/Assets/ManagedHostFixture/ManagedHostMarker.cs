using UnityEngine;

namespace Artress.ManagedAddressables.HostFixture
{
    // A runtime script in a Player assembly, so SDK builds produce a real MonoScript bundle and a cross-asset dependency.
    public sealed class ManagedHostMarker : MonoBehaviour
    {
        public string revision;
        public TextAsset dependency;
    }
}
