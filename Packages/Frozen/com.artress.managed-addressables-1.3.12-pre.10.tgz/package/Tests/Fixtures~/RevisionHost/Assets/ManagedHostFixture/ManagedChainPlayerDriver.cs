using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.Networking;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace Artress.ManagedAddressables.HostFixture
{
    // First start of a real Player: Boot, then the packaged Revision A through the production Session, offline.
    // The second start of the same Player must reuse what the first one confirmed.
    public sealed class ManagedChainPlayerDriver : MonoBehaviour
    {
        public const string BootKey = "ChainBootText", GamePrefabKey = "ChainGamePrefab";

        [Serializable]
        private sealed class Anchor
        {
            public string revisionId, target, publisherSha256, productId, channel, authorityId;
            public string catalogRelativePath, publisherRelativePath, bundleRelativeRoot;
        }

        [Serializable]
        private sealed class Result
        {
            public bool success, closed;
            public string error, revisionId, commitOutcome, bootText, gameMarker, gameDependency, persistentDataPath;
            public int httpRequests;
        }

        private readonly Result result = new Result();
        private readonly HashSet<string> revisionBundles = new HashSet<string>(StringComparer.Ordinal);
        private HashSet<string> bootBundles;
        private GameObject instance;
        private AsyncOperationHandle<GameObject> prefab;

        private static void Require(bool value, string why) { if (!value) throw new InvalidOperationException(why); }
        private static string Arg(string name)
        {
            var args = Environment.GetCommandLineArgs();
            int index = Array.IndexOf(args, name);
            return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
        }
        private static async Task Done(AsyncOperationHandle handle) { while (!handle.IsDone) await Task.Yield(); }

        private async Task LoadGame(bool keep)
        {
            var loaded = Addressables.LoadAssetAsync<GameObject>(GamePrefabKey);
            await Done(loaded);
            try
            {
                Require(loaded.Status == AsyncOperationStatus.Succeeded, "Game prefab failed: " + loaded.OperationException);
                var marker = loaded.Result.GetComponent<ManagedHostMarker>();
                Require(marker != null && marker.revision == "A" && marker.dependency != null && marker.dependency.text == "A", "Game prefab content changed");
                result.gameMarker = marker.revision;
                result.gameDependency = marker.dependency.text;
                foreach (var bundle in AssetBundle.GetAllLoadedAssetBundles()) if (!bootBundles.Contains(bundle.name)) revisionBundles.Add(bundle.name);
                if (keep) { prefab = loaded; instance = Instantiate(loaded.Result); loaded = default; }
            }
            finally { if (loaded.IsValid()) Addressables.Release(loaded); }
        }

        private async Task<bool> Validate(ManagedAddressableRevision revision, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            await LoadGame(false);
            return true;
        }

        private async Task<ManagedRevisionBoundary> Stop(CancellationToken token)
        {
            if (instance != null) { Destroy(instance); await Task.Yield(); instance = null; }
            if (prefab.IsValid()) Addressables.Release(prefab);
            prefab = default;
            double started = Time.realtimeSinceStartupAsDouble;
            while (AssetBundle.GetAllLoadedAssetBundles().Any(bundle => revisionBundles.Contains(bundle.name)))
            {
                Require(Time.realtimeSinceStartupAsDouble - started < 5, "Revision bundles did not unload");
                await Task.Yield();
            }
            token.ThrowIfCancellationRequested();
            return new ManagedRevisionBoundary(0, 0, 0, 0, true, "Driver released its prefab and the Revision bundles unloaded.");
        }

        private static string StreamingPath(params string[] parts) =>
            Path.GetFullPath(Path.Combine(new[] { Application.streamingAssetsPath, "ArtressManagedRevision" }.Concat(parts).ToArray()));

        private async Task Run()
        {
            Action<UnityWebRequest> previousOverride = Addressables.WebRequestOverride;
            Addressables.WebRequestOverride = request =>
            {
                previousOverride?.Invoke(request);
                if (request.url.StartsWith("http", StringComparison.OrdinalIgnoreCase)) result.httpRequests++;
            };
            var initialize = Addressables.InitializeAsync(false);
            await Done(initialize);
            Require(initialize.Status == AsyncOperationStatus.Succeeded, "SDK Boot failed: " + initialize.OperationException);
            IResourceLocator bootLocator = initialize.Result;
            Addressables.Release(initialize);

            var boot = Addressables.LoadAssetAsync<TextAsset>(BootKey);
            await Done(boot);
            Require(boot.Status == AsyncOperationStatus.Succeeded, "Boot text failed: " + boot.OperationException);
            result.bootText = boot.Result.text;
            Require(result.bootText == "BOOT", "Boot text changed");
            bootBundles = new HashSet<string>(AssetBundle.GetAllLoadedAssetBundles().Select(bundle => bundle.name), StringComparer.Ordinal);

            var anchor = JsonUtility.FromJson<Anchor>(File.ReadAllText(StreamingPath("packaged_revision.json")));
            var packaged = ManagedAddressableRevision.CreatePackaged(anchor.revisionId,
                new Uri(StreamingPath(anchor.catalogRelativePath)).AbsoluteUri, new Uri(StreamingPath(anchor.publisherRelativePath)).AbsoluteUri,
                anchor.publisherSha256, anchor.target, new Uri(StreamingPath(anchor.bundleRelativeRoot) + Path.DirectorySeparatorChar).AbsoluteUri);
            var application = new ManagedRevisionApplication(anchor.productId, anchor.channel, anchor.authorityId, packaged);
            var session = new ManagedAddressableRevisionSession(new ManagedAddressableRevisionStorage("ManagedChain", 0, 30));
            var opened = await session.OpenForApplicationAsync(bootLocator, application, new ManagedRevisionApplyCallbacks(Stop, Validate));
            Require(opened.Success, "Open failed: " + opened.Error);
            result.commitOutcome = opened.CommitOutcome?.ToString();
            result.revisionId = session.ActiveRevision?.RevisionId;
            Require(result.revisionId == anchor.revisionId, "The packaged Revision is not active");
            await LoadGame(true);
            var close = await session.CloseAsync(Stop);
            Require(close.Success, "Close failed: " + close.Error);
            result.closed = true;
            Addressables.Release(boot);
            Addressables.WebRequestOverride = previousOverride;
            Require(result.httpRequests == 0, "The offline packaged start made an http request");
            result.success = true;
        }

        private async void Start()
        {
            try { result.persistentDataPath = Application.persistentDataPath; await Run(); }
            catch (Exception error) { result.error = error.ToString(); }
            string path = Arg("-chainResult");
            if (!string.IsNullOrEmpty(path)) File.WriteAllText(path, JsonUtility.ToJson(result, true));
            Application.Quit(result.success ? 0 : 1);
        }
    }
}
