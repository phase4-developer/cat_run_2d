# Builds a disposable Unity project around one package and runs what needs a real SDK build or Player.
# Nothing here depends on this machine: pass -Unity and -WorkRoot where they differ.
param(
    [string]$Package = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),   # .tgz or package folder
    [string]$Unity = 'C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe',
    [string]$WorkRoot = (Join-Path ([IO.Path]::GetTempPath()) ('rh-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))),
    [int]$UnitySeconds = 1800,
    [int]$PlayerSeconds = 120
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (!(Test-Path -LiteralPath $Unity)) { throw "Unity not found: $Unity" }
if (!(Test-Path -LiteralPath $Package)) { throw "Package not found: $Package" }
if (Test-Path -LiteralPath $WorkRoot) { throw "Use a new work folder: $WorkRoot" }
if (Get-Process -Name Unity -ErrorAction SilentlyContinue) { throw 'Another Unity is running. Close it first.' }

$WorkRoot = [IO.Path]::GetFullPath($WorkRoot)
$hostRoot = Join-Path $WorkRoot 'H'
$results = Join-Path $WorkRoot 'R'
New-Item -ItemType Directory -Path $results -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'RevisionHost') -Destination $hostRoot -Recurse
New-Item -ItemType Directory -Path (Join-Path $hostRoot 'Packages') -Force | Out-Null
$packagePath = [IO.Path]::GetFullPath($Package).Replace('\', '/')
$manifest = [ordered]@{
    dependencies = [ordered]@{
        'com.unity.addressables'           = '4.0.1'
        'com.unity.localization'           = '1.5.12'
        'com.unity.test-framework'         = '1.6.0'
        'com.unity.nuget.newtonsoft-json'  = '3.2.2'
        'com.unity.modules.imgui'          = '1.0.0'
        'com.artress.managed-addressables' = "file:$packagePath"
    }
    testables = @('com.artress.managed-addressables')
}
[IO.File]::WriteAllText((Join-Path $hostRoot 'Packages/manifest.json'), ($manifest | ConvertTo-Json -Depth 4))

function Invoke-Unity([string]$Name, [string[]]$Arguments) {
    $log = Join-Path $results "$Name.log"
    $xml = Join-Path $results "$Name.xml"
    $all = @('-batchmode', '-nographics', '-job-worker-count', '2', '-buildTarget', 'Win64', '-projectPath', $hostRoot,
        '-logFile', $log, '-runTests', '-testResults', $xml) + $Arguments
    $process = Start-Process -FilePath $Unity -ArgumentList ($all | ForEach-Object { '"' + $_ + '"' }) -WindowStyle Hidden -PassThru
    if (!$process.WaitForExit($UnitySeconds * 1000)) { $process.Kill(); throw "Unity timed out: $log" }
    if (!(Test-Path -LiteralPath $xml)) { throw "No test results (exit $($process.ExitCode)): $log" }
    [xml]$report = Get-Content -LiteralPath $xml -Raw
    $run = $report.'test-run'
    $row = [ordered]@{ Name = $Name; Total = [int]$run.total; Passed = [int]$run.passed; Failed = [int]$run.failed; Skipped = [int]$run.skipped; Exit = $process.ExitCode
        NotPassed = @($report.SelectNodes('//test-case[@result!="Passed"]') | ForEach-Object { $_.result + ': ' + $_.fullname }) }
    Write-Host ("{0}: {1} passed, {2} failed, {3} skipped of {4}" -f $Name, $row.Passed, $row.Failed, $row.Skipped, $row.Total)
    return $row
}

function Invoke-Player([string]$Exe, [string]$Name) {
    $json = Join-Path $results "$Name.json"
    $process = Start-Process -FilePath $Exe -ArgumentList @('-batchmode', '-nographics', '-logFile', ('"' + (Join-Path $results "$Name.log") + '"'), '-chainResult', ('"' + $json + '"')) -WindowStyle Hidden -PassThru
    if (!$process.WaitForExit($PlayerSeconds * 1000)) { $process.Kill(); throw "Player timed out: $Name" }
    if (!(Test-Path -LiteralPath $json)) { throw "Player wrote no result (exit $($process.ExitCode)): $Name" }
    $result = Get-Content -LiteralPath $json -Raw | ConvertFrom-Json
    if (!$result.success) { throw "Player failed: $Name / $($result.error)" }
    return $result
}

$summary = [ordered]@{ Package = $packagePath; PackageSha256 = $null; Unity = (Get-Item -LiteralPath $Unity).VersionInfo.ProductVersion; Runs = @(); Player = $null; Status = 'FAIL' }
if (Test-Path -LiteralPath $Package -PathType Leaf) { $summary.PackageSha256 = (Get-FileHash -LiteralPath $Package -Algorithm SHA256).Hash }
$summaryPath = Join-Path $results 'summary.json'
try {
    $summary.Runs += Invoke-Unity 'editor' @('-testPlatform', 'EditMode', '-assemblyNames', 'Artress.ManagedAddressables.Editor.Tests', '-testFilter', '!Artress.ManagedAddressables.Editor.Tests.ManagedFrameworkRestartTests')
    $summary.Runs += Invoke-Unity 'runtime' @('-testPlatform', 'PlayMode', '-assemblyNames', 'Artress.ManagedAddressables.Runtime.Tests')

    $exe = Join-Path $WorkRoot 'P/P.exe'
    $env:MANAGED_CHAIN_PLAYER = $exe
    $env:MANAGED_CHAIN_PRODUCT = 'ManagedChain-' + (Split-Path -Leaf $WorkRoot)
    $summary.Runs += Invoke-Unity 'chain' @('-testPlatform', 'EditMode', '-testFilter', 'Artress.ManagedAddressables.Editor.Tests.ManagedOfficialChainTests')
    if (@($summary.Runs | Where-Object { $_.Failed -ne 0 -or $_.Exit -ne 0 -or $_.Passed -eq 0 }).Count) { throw 'Unity runs failed.' }
    # Only the chain case may skip in the editor run: a skipped SDK case means the Host lost its fixture.
    $chainCase = 'Skipped: Artress.ManagedAddressables.Editor.Tests.ManagedOfficialChainTests.GuideStepsBuildAPlayerWithItsPackagedRevision'
    $allowed = @{ editor = @($chainCase); runtime = @(); chain = @() }
    foreach ($run in $summary.Runs) {
        $unexpected = @($run.NotPassed | Where-Object { $allowed[$run.Name] -notcontains $_ })
        if ($unexpected.Count) { throw "$($run.Name) did not run: $($unexpected -join '; ')" }
    }

    $first = Invoke-Player $exe 'first'
    if ($first.commitOutcome -ne 'Confirmed') { throw "First start did not confirm A: $($first.commitOutcome)" }
    $second = Invoke-Player $exe 'second'
    # A reinstall would report Confirmed again; only a reused Revision has no commit outcome.
    if ($second.revisionId -ne $first.revisionId -or $second.commitOutcome) { throw "Second start did not reuse the confirmed Revision: $($second.commitOutcome)" }
    $summary.Player = [ordered]@{ First = $first; Second = $second }
    $summary.Status = 'PASS'
}
finally {
    [IO.File]::WriteAllText($summaryPath, ($summary | ConvertTo-Json -Depth 6))
}
Write-Host "PASS: $summaryPath"
