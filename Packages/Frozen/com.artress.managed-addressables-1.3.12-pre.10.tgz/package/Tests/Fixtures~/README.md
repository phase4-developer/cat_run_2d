# Revision Host

Unity does not compile this folder. It holds a small project template and one script that runs the checks a normal test Host cannot.

```powershell
powershell -ExecutionPolicy Bypass -File Tests/Fixtures~/Run-RevisionHost.ps1 -Package <candidate.tgz> -WorkRoot <short-new-folder>
```

Without `-Package` it uses this package folder. Without `-WorkRoot` it uses a new temp folder. Keep the work path short on Windows; SDK output hits the 260-character limit. Close other Unity Editors first.

The script makes `H` (the Host), `P` (the Player) and `R` (logs and results) in the work folder, then runs:

| Step | What it proves |
|---|---|
| `editor` | All Editor tests except the restart case, with Localization and the Host marker present, so the real SDK cases run instead of skipping |
| `runtime` | All PlayMode tests |
| `chain` | `ManagedOfficialChainTests`: Sync, roles, release, Revision, packaged A and the official Player build, all from an empty project |
| `first` | A real Player starts offline, copies A to app storage and confirms it |
| `second` | The same Player starts again on the confirmed Revision |

`R/summary.json` records the package SHA-256, the counts and the Player results. The work folder is disposable.

Android, iOS, remote update over HTTPS and Vendor adapters are outside this run. `ManagedFrameworkRestartTests` needs two Unity processes and the Runner packages, so it stays on `Hosts/ManagedAddressablesValidationHost`.
