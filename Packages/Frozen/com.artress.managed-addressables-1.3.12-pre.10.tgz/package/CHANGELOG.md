# Changelog

## 1.3.12-pre.10

Internal candidate. On a fresh Revision Host with Unity 6000.3.9f1: Editor 204 of 205, PlayMode 56 of 56, official chain 1 of 1, and a Windows Mono Player that confirmed its packaged A offline and reused it on the next start. The one Editor case left is the chain, which runs on its own. On the existing Hosts: restart across two processes and core 14 of 14. Android, iOS, Vendor adapters, remote update, the Windows regression table, frame timing and IL2CPP are NOT_RUN.

### Removed

- `ManagedAddressableRevisionSession.OpenAsync`. `OpenForApplicationAsync` is the one start entry.
- The public `ManagedAddressableRevision` constructor without a publisher. It is internal now.
- `generateBuildLayout` on the Project Config. Split builds always turn Build Layout on.
- Packaged receipts without `contentFingerprint`. Rebuild the Revision.

### Added

- `Suggest Roles from Folders` in Control Center. It fills the Build Roles draft from Local and Remote folders and writes nothing.

### Fixed

- A rejected `OpenForApplicationAsync` argument no longer leaves the Session in recovery.

## 1.3.12-pre.9

Internal candidate. pre.10 replaced it.

### Removed

- Runtime: `ManagedAddressablesBootstrap`, `ManagedAddressableContentInstaller`, `ManagedAddressableStorage`, `ManagedAddressableCatalogService`, `ManagedAddressableRuntimeSettings`, the manifest and progress models, `ManagedAddressableHashUtility`.
- Session: the `Obsolete` `OpenAsync` and `ApplyAsync` overloads.
- Editor: `ManagedContentBuildMode` and the ExistingWorkflow route, including `Build` and the non-Split Revision build; artifact deployment and store; the remote change report; seed settings and `managed_addressable_manifest.json`; localization repair; legacy config migration; `RemoteSeeded` delivery; the Spine prefab generator and `ManagedSpineShaderDependencies`; `Candidates~/WindowsLocal`.

### Fixed

- The Boot Catalog check rejected any Group with SDK cache off, which includes every Local Group from Sync. The official Player build failed on projects made by the guide.

### Added

- `allowDevelopmentHttp` on the Project Config for plain http in Development Builds.
- `Tests/Fixtures~/Run-RevisionHost.ps1` and `ManagedOfficialChainTests`. They replace the pre.8 fixture record and run from any folder.

### Changed

- `LegacyAddressNaming` is now `ManagedAddressNaming`. The address rule is unchanged.
- The new Profile `Remote.LoadPath` default is `<undefined>` instead of the Installer folder, and the `Storage` variable is gone.
- Sync-created Remote Groups now default to SDK cache and CRC on and keep other versions, which Revision requires.
- Plain http Revision URLs fail by default.
- Publishers require deployment metadata and `catalogBytes`; the exporter always writes them.
- `CreateBuildRolePlan` drops the mode and Player defaults parameters and always plans `DoNotBuildWithPlayer`.
- Revision metadata writes the publisher before the Catalog, and startup cleanup removes a Catalog with no publisher.
- Displayed URLs and download errors omit the query string.
