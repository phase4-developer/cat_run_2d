# Artress Managed Addressables

**현재 상태: 1.3.12-pre.10 내부 후보. 공식 릴리스가 아니다.** Editor·PlayMode 시험, 공식 SDK 사슬, Windows Mono Player의 첫 실행과 재실행을 통과했다. Android, iOS, Vendor 어댑터, 원격 갱신은 NOT_RUN이다. 검증 기록은 Framework `Snapshots/20261107-managed-addressables-pre10/manifest.json`에 있다. AR2-04, 소비 게임 적용, 공식 릴리스는 HOLD다.

## 패키지 구조

콘텐츠 경로는 BootstrapSplit 하나다. 앱에 포함되는 Boot 전용 Binary Catalog와, 앱이 소유한 저장소에서 여는 Revision JSON Catalog로 나뉜다.

| 영역 | 역할 |
|---|---|
| Runtime | `ManagedAddressableRevisionSession`, `ManagedAddressableRevisionStorage`, Revision 모델 |
| Editor 등록 | 폴더 규칙으로 Group·Address를 Preview·Apply하는 Sync와 Control Center |
| Editor 제작 | Boot/Revision Split 빌드, publisher 기록, 앱 포함 A 연결, Player 빌드 연계 |

`OpenForApplicationAsync` 성공 뒤에만 Revision을 소비한다. [Runtime 계약](Documentation~/AR2-Runtime2.md)과 [사용 가이드](Documentation~/ManagedAddressablesGuide.md)를 함께 본다.

## 제작 흐름

Control Center(`Tools/Artress/Managed Addressables/Open Control Center`)에서 Preview를 검토한 뒤 같은 계획을 Apply한다. Sync가 만든 Remote Group은 Revision schema 조건을 이미 갖췄다. 시작 전에 Profile의 `Remote.LoadPath`를 실제 HTTPS 루트로 지정한다.

1. `Preview Build Roles`에서 Group 역할, shared 대상, 필수 Boot Key, `Adopt for temporary Boot/Revision writes`를 함께 검토하고 `APPLY REVIEWED PLAN`으로 적용한다. 채택을 끄면 필요한 빌드가 차단되고 ReadOnly Group은 우회하지 않는다. 기존 채택 해제는 `Preview Group Adoption`을 사용한다. 이 계획은 SDK `DoNotBuildWithPlayer`도 함께 설정한다.
2. `Release Metadata (before Revision build)`의 Product ID, Channel, Authority, Compatibility family, 양수 sequence를 `Preview Release Metadata` → `APPLY REVIEWED PLAN`으로 저장한다. 서버가 정한 순번을 사용하며 자동 생성하지 않는다. 없으면 Revision 계획이 차단된다.
3. `Preview Revision Build` → `BUILD SDK REVISION CONTENT`로 제작한다. 최근 완료 receipt가 앱 포함 A 입력의 기본값이다.
4. `Preview Packaged Revision A` → `APPLY REVIEWED PACKAGED A`로 연결한다. Config 외에 Catalog, Bundle, publisher, anchor와 원문 proof 산출물이 빌드 머신의 해당 경로에 있어야 한다.
5. 공식 Player Build가 Boot를 자동 제작하고 실제 staging을 검증한다. 앱 포함 A는 필수이며 끄는 옵션은 없다.

Project Config가 있는 프로젝트의 모든 Player 빌드는 이 흐름을 탄다. 역할이나 앱 포함 A가 없으면 빌드가 실패한다.

## 개발용 http

Revision URL은 HTTPS가 기본이다. 로컬 시험 서버처럼 평문 http가 필요하면 Control Center의 `Allow Development HTTP`(`ManagedAddressableProjectConfig.allowDevelopmentHttp`)를 켠다. 기본값은 꺼짐이다.

- **꺼짐:** http URL은 Editor 검증과 Runtime Revision·Storage 검사에서 실패한다.
- **켜짐:** Development Build만 허용한다. Player 빌드 단계가 `PlayerSettings.insecureHttpOption`이 `NotAllowed`일 때 그 빌드 동안만 `DevelopmentOnly`로 바꾸고 끝나면 되돌린다. iOS는 생성된 Xcode `Info.plist`에 ATS 예외를 추가한다. StreamingAssets 표식으로 Runtime이 같은 설정을 읽는다.
- **Release 빌드:** 켠 채로 빌드하면 명확한 오류로 실패한다. Release Player는 표식과 관계없이 http를 거부한다.

이 설정이 바꾸는 Player Settings는 Player 빌드에만 적용된다. Editor Play 모드는 프로젝트의 `insecureHttpOption`을 그대로 쓴다.

## 중단 복구

중단된 Split 임시 설정 기록이 있으면 Boot, Revision, Player 제작을 시작 전에 차단한다. `Preview Interrupted Split Build Settings`로 원본, 기록 임시, 현재 SHA와 충돌을 확인한 뒤 `Restore Interrupted Split Build Settings`를 실행한다. `Restore Interrupted Player Build Metadata`는 별도로 link.xml과 개발용 http가 바꾼 Player Settings를 복원한다.

충돌로 자동 복원이 차단되거나 `.next` 파일만 남았으면 수동으로 해결한다. `Library/ArtressManagedAddressablesSplit/pending_split_settings.json`과 같은 경로의 `.next` 중 존재하는 파일을 먼저 백업하고, 기록된 값과 현재 Settings, Group, schema, Profile을 소유자와 확인해 해결한 뒤 해당 pending 파일만 삭제하고 다시 Preview한다. 삭제만으로 설정이 복원되지는 않는다.

Runtime 시작 정리에서 읽을 수 없는 미확정 publisher나 모호한 파일 관계가 있으면 해당 회차 정리를 생략하고 `LastCleanupWarning`을 남긴다. 같은 후보가 남아 있으면 이후 시작에서도 정리가 생략될 수 있다. publisher가 없는 Catalog는 보존 관계가 없으므로 정리한다.

## 알려진 한계

- **디스크 반영:** Bundle과 metadata는 `FileStream.Flush(true)` 호출 뒤 최종 위치로 옮기고 그 뒤에 포인터를 기록한다. Windows Mono에서는 디스크 반영 실패가 호출자에게 감지되지 않는다. 전원 차단 내구성은 확인하지 않았다.
- **앱 교체:** 최초 복사가 중단된 뒤 다른 앱 A로 교체되면 `InitialInstallMarkerDoesNotMatchPackagedA`로 Boot 복구에 남는다. 전용 ReasonCode는 없다.
- **플랫폼:** Android, iOS 실기기, iOS native link, 물리 ENOSPC, 운영 HTTPS, 제품 Save 호환성은 NOT_RUN이다.
