# AR2 Runtime 계약

**현재 상태: 1.3.12-pre.10 내부 후보. 공식 릴리스가 아니다.** Editor·PlayMode 시험, 공식 SDK 사슬, Windows Mono Player의 첫 실행과 재실행을 통과했다. Android, iOS, Vendor 어댑터, 원격 갱신은 NOT_RUN이다. 아래의 실측값은 pre.8 기록이며 이 후보로 승계하지 않는다. 이 후보의 검증 기록은 Framework `Snapshots/20261107-managed-addressables-pre10/manifest.json`에 있다. AR2-04, 소비 게임 적용, 공식 릴리스는 HOLD다.

Revision URL은 HTTPS만 허용한다. 평문 http는 Project Config의 `allowDevelopmentHttp`를 켠 Development Build에서만 허용하며 Release Player는 거부한다. 표시되는 URL과 다운로드 오류에서는 query를 제거하고, 저장·요청 URL은 바이트 그대로 유지한다.

## pre.8 추가 API와 미확정 범위

- `ManagedRevisionResult.Deferred`: Locator/포인터 교체 전에 보류됐음을 나타낸다. 호출자의 소비자 정리 callback이 시작된 뒤 완료 경계를 반환하기 전에 예외나 취소로 끝나도 `true`다. A·준비 B·포인터를 유지하며 오류 문자열을 해석하지 않아도 된다. callback 시작 전 입력 오류까지 보류로 분류하지 않는다.
- `IReadOnlyList<string> ManagedRevisionResult.RemainingBundleNames`: R2를 보류시킨 실제 로드 이름의 변경 불가능한 목록이다. 호출자 Boundary 미완료로 보류됐을 때는 비어 있다.
- `ManagedRevisionResult ResumeCurrentRevision()`: `Prepared`이고 소비자가 정지됐으며 A·Boot Locator와 Transform이 유지된 경우만 허용한다. 준비 B·A·포인터는 그대로 두고 `CanStartConsumers=true`로 바꾼다. 호출자가 정리한 게임 상태를 다시 만드는 책임은 호출자에게 있다. 이후 `DiscardPrepared` 또는 새 안전 경계의 Apply가 가능하다. Applying/Recovery에서는 거부한다.
- `Task<ManagedRevisionResult> RepairConfirmedAsync(ManagedAddressableRevision trustedRevision, CancellationToken cancellationToken = default)`: Recovery 상태에서 읽을 수 있는 포인터와 같은 신뢰 publisher SHA만 복구한다. 누락·손상 publisher/Catalog/Bundle만 재취득하며 포인터 바이트, Locator 등록, 게임 소비자를 바꾸지 않는다. 성공 뒤 `CloseAsync` → 새 Session → 정상 Open으로 SDK 검증한다.
- `ManagedRevisionResult.ReasonCode`: `ManagedRevisionReasonCode.None=0`, `InitialInstallCommitStartedWithoutPointer=1`. 후자는 최초 설치의 확정 구간이 시작됐으나 포인터가 없어서 자동 재시도를 거부한 Boot 복구 사유다.

R0 실제 Windows Player에서 일반/MonoScripts Bundle의 실제 이름에는 `.bundle`이 붙고 publisher/options 이름에는 없었다. 이후 사용자 결정으로 R2는 **Addressables 4.0.1 전용 `sdkBundleName + ".bundle"`과 실제 이름의 Ordinal 정확 일치**만 사용한다. 부분 일치·추가 추정은 하지 않으며 다른 SDK는 명시적으로 거부한다. 정확 버전의 asmdef Version Define을 사용하고 Player에서 빈 문자열인 `Addressables.Version`에 의존하지 않는다. 이름 관측에서 Handle 해제 뒤 일반 Bundle이 1프레임/2.1964ms에 사라졌다는 결과는 해당 실행의 관측이며, 소비자 0 증명이나 다른 플랫폼의 해제 상한이 아니다. Android·iOS 이름 규칙은 NOT_RUN이다.

R2는 Boundary 완료 뒤 A의 file SHA 중 B에 없는 Bundle만 조사한다. B에서 삭제된 Bundle도 포함하고 동일 SHA 공유 Bundle은 제외한다. 실제 loaded 이름을 100ms 관측 예산과 10ms 간격의 비동기 대기로 확인한다. Unity 스케줄링 때문에 실제 경과 시간은 예산을 넘을 수 있다. 이 값은 R0 한 실행의 해제 관측에 여유를 둔 보류 정책이며, 모든 환경에서 언로드가 100ms 이내 끝난다는 보장이 아니다. 남아 있으면 A Locator·포인터·준비 B를 유지한 채 `Deferred`와 이름을 반환한다. 통과는 기존 Boundary의 보조 확인이며 `UnloadAsync(false)` 등으로 남을 수 있는 A 객체가 0임을 증명하지 않는다. 미지원 SDK는 소비자 정지 전에 명시적으로 거부한다.

같은 측정의 대용량 Bundle 이름 소멸은 A 0.2593ms, B 0.2064ms, 각 1프레임이었고 Apply B는 보류 없이 끝났다. R2의 100ms는 보류 정책이며 언로드 지연의 보편 상한이 아니다. 관측 Bundle이 빨리 사라져 대기는 거의 쓰이지 않았으므로 느린 기기에서의 충분성은 판단하지 않는다.

## SDK와 Session

기본 Catalog는 제작 검증을 통과한 Boot 전용 Binary / Remote OFF다. 게임 콘텐츠는 별도 Revision JSON Catalog다. 기존 Split 제작의 Address/GUID/Locale identity 검사를 전제로 하며, 단순 label 교집합으로 Boot/Revision을 충돌 처리하지 않는다. 이 제작 검사를 우회한 임의 Catalog의 Boot 충돌 안전성까지 보장하지 않는다.

SDK/Boot 초기화 Owner는 `Addressables.InitializeAsync`가 반환한 실제 등록 `IResourceLocator`를 Session에 전달한다. Session은 SDK를 다시 초기화하거나 Locator ID로 기본 Catalog를 채택·교체하지 않는다. `ManagedAddressableRevisionSession(ManagedAddressableRevisionStorage)`와 `OpenForApplicationAsync`를 사용한다.

`PrepareAsync`는 신뢰된 publisher SHA를 공급한 정확한 Revision의 Catalog·파일을 준비한다. B Locator를 일반 registry에 노출하지 않고 A를 유지한다. SDK Catalog 해석은 Session에서 한 번 수행하고 Store는 그 실제 Location 결합을 사용한다.

새 `ApplyAsync(ManagedRevisionApplyCallbacks, CancellationToken)`의 순서는 다음과 같다.

1. 호출자가 Revision 요청·Lease/Scope·Instance·Scene을 정리하고 실제 완료 경계를 반환한다. 직접 SDK Handle도 호출자가 해제한다. Boot/Localization과 다른 Owner는 이 수에 포함하지 않는다.
2. 미완료 경계는 `Deferred`로 전환을 보류한다. A Locator·포인터와 준비 B를 유지한다. 로딩 경계를 닫은 채 재시도하거나 `ResumeCurrentRevision()` 성공 뒤 호출자가 A 게임 상태를 재구성한다.
3. B 로컬 검증 callback은 검증만 수행하고 진단 Handle을 해제한다. 게임플레이를 시작하지 않는다.
4. 모든 필수 파일과 확정 포인터 기록·정확 readback ACK가 확인돼야 성공한다. ACK 뒤 예외로 A를 재확정하지 않는다.
5. 호출자가 성공 결과를 받은 뒤 게임플레이를 재개한다. 실패 후 A 재진입은 A 파일·정리·typed 검증이 성공한 조건에서만 허용한다. 불명확한 기록이나 확정본 손상은 Boot 복구 경로다.

`CloseAsync`는 실제 보유한 Session Revision Locator와 소유 operation만 해제한다. 게임 소비자의 모든 자원을 대신 추적하거나 전역 consumer 0을 요구하지 않는다. SDK Catalog update를 이 Session과 동시에 운영하지 않는다.

## 저장·신뢰·정리

앱 소유 namespace에 불변 Catalog/publisher, SHA-256 공유 Bundle, 최소 confirmed 포인터를 보존한다. SDK Bundle cache를 정본으로 사용하지 않는다. SDK BundleName/Hash/CRC와 파일 SHA는 별개다. 검증된 정확 Location만 로컬 파일로 변환하고 다른 Location에는 이전 Transform을 보존한다. 필수 파일이 없으면 원격 URL로 조용히 대체하지 않는다.

publisher 자체의 SHA는 기존 HTTPS Revision API 등 신뢰된 호출자 계약에서 공급한다. 운영 API가 없는 내부 시험은 고정 신뢰 앵커를 사용하며 운영 연동 PASS로 보고하지 않는다. 새 서버·서명 시스템은 포함하지 않는다. publisher는 실제 Catalog 길이와 배포 metadata를 포함해야 하며 없으면 거부한다.

다운로드는 temp → 길이/SHA 확인 → 디스크 반영 요청 → 불변 파일 배치 순서다. metadata도 temp 기록·디스크 반영 뒤 원자적으로 이동한다. 큰 파일 SHA·복사와 payload flush만 순수 파일 I/O Worker에서 수행하며 Unity API와 Session/Storage 상태는 Unity 호출 context에 둔다. 작은 포인터·표시 파일의 기록/ACK는 동기 구간이다. 정상 부팅은 존재/크기 중심으로 검사하며 오류·로드 실패 등 필요한 경우 전체 SHA를 재검증한다. 확정 전 다운로드 SHA 확인은 생략하지 않는다. 기존 확정본과 추가·임시 공간을 고려하고, 선제 공간 검사와 실제 IO 오류를 구분한다. **R7 한계:** Bundle과 metadata는 `FileStream.Flush(true)` 호출 뒤 최종 위치로 옮기고 그 뒤에 포인터를 기록한다. 그러나 Windows Mono에서는 `Flush(true)`의 디스크 반영 실패가 호출자에게 감지되지 않는다. 호출이 예외 없이 끝나도 디스크 반영 성공을 뜻하지 않는다. 실행으로 확인한 것은 이 호출 순서이며 전원 차단 내구성이 아니다. 물리 전원 차단, IL2CPP, 모바일은 NOT_RUN이다. 디렉터리 항목과 장치 캐시의 내구성도 보장하지 않는다.

정리는 다음 앱 시작의 Revision 소비 전에 수행한다. `OpenForApplicationAsync`는 확정본과 동일 product/channel/authority/family에서 더 높은 순번의 유효 publisher 중 최고 하나를 보존한다. publisher가 있다는 사실은 준비 완료나 다음 부팅의 자동 활성화를 뜻하지 않는다. publisher 읽기/SHA 또는 파일 관계가 모호하면 해당 회차 미확정 정리를 생략하고 `LastCleanupWarning`을 남긴다. Session 시작의 정리 뒤 경고가 남으면 `Debug.LogWarning`으로도 알린다. Bundle 정리 뒤 불필요 metadata도 정리하며 플레이 중 GC는 하지 않는다. `OpenAsync`의 명시 보존 목록도 유지한다. Prepare 재사용에는 호출자의 신뢰 publisher SHA와 전체 필수 파일을 다시 검증한다. 손상된 미확정 전용 Bundle은 재취득하지만 확정본이 참조한 파일은 Repair 외 경로에서 교체하지 않는다. 미확정 publisher/Catalog의 `InvalidDataException`도 같은 재취득 경계로 처리하며 확정 metadata는 Repair 외 경로에서 덮어쓰지 않는다. Save, StreamingAssets와 다른 저장 영역은 정리 대상이 아니다.

metadata는 publisher, Catalog 순서로 기록하고 삭제는 그 반대로 한다. 따라서 중단돼도 Catalog만 남지 않는다. publisher 없이 Catalog만 있는 디렉터리는 보존 관계가 없으므로 정리한다.

읽을 수 없는 후보가 그대로 남으면 매 시작마다 같은 이유로 정리가 생략되어 디스크 회수가 계속 지연될 수 있다. 이 한계를 숨겨 정리 완료로 보고하거나 후보를 추측해 자동 삭제하지 않는다. 경고의 원인과 보존된 파일을 확인해야 하며 확정본·Save를 초기화하는 기능은 이번 범위에 없다.

Windows는 앱 데이터 하위, Android는 내부 filesDir, iOS는 Foundation Application Support와 재다운로드 파일 백업 제외를 사용한다. 모바일 C# 컴파일은 실제 native link·APK 접근·보존·파일 교체·실기기 검증을 대신하지 않는다. 프로세스 중단과 실제 전원 차단의 보장도 구분한다.


## 앱 포함 A와 업데이트 선택

`ManagedAddressableRevision.CreatePackaged`로 명시한 StreamingAssets Catalog/publisher/Bundle root와 신뢰 publisher SHA를 전달한다. `ManagedRevisionApplication(productId, channel, authorityId, packagedRevision)`을 구성하고 `OpenForApplicationAsync(actualBootLocator, application, callbacks, cancellationToken)`을 호출한다. Boot SDK 초기화는 호출자가 한 번 수행하고 실제 등록 Locator 객체를 전달한다. callbacks는 기존 검증·소비자 정리 계약이며 게임 진입 callback이 아니다. Success 뒤만 게임을 시작한다.

Publisher schema1은 `productId`, `channel`, `authorityId`, `compatibilityFamily`, `deploymentSequence`(양의 long)를 필수로 포함한다. 플랫폼은 `target`이다. 동일 배포 주체가 서버·앱 양쪽 순번을 부여해야 하며 Runtime/Editor가 날짜·ID·빌드 횟수로 순번을 생성하지 않는다. 운영 API가 없는 검증에서는 같은 주체의 고정 fixture를 쓰고 운영 연동은 NOT_RUN으로 둔다.

| 상태 | Startup 결과 |
|---|---|
| 포인터 없음·소유 namespace 파일 없음 | 앱 포함 A를 복사·길이/SHA 검증·SDK 로컬 검증한 뒤 확정 ACK |
| 포인터 없음·검증된 동일 A의 `Copying` 잔재 | 아래 한정 조건을 모두 확인한 뒤 앱 포함 A부터 재시도 |
| 포인터 없음·`CommitStarted` 표시 | 사유 코드 `InitialInstallCommitStartedWithoutPointer`와 함께 Boot 복구. 자동 재시도하지 않음 |
| 포인터 없음·그 밖의 파일 존재 | 모호한 Boot 복구. 기존 확정본 포인터 손실을 최초 설치로 재분류하지 않음 |
| 필수 metadata/도메인/authority 모호 | 임의 선택 없이 Boot 복구 |
| 같은 family에서 확정 B 순번이 큼 | B 선택. B 파일 부재·손상은 Boot이며 A 강등 이유가 아님 |
| 같은 family에서 앱 A′ 순번이 큼 | A′ 준비·검증·ACK 후 선택 |
| B family가 새 앱과 다름 | A′ 선택 시도. 비호환 B 실행 금지 |
| 같은 family·순번인데 publisher SHA가 다름 | 모호한 Boot 복구 |

A′ 적용이 실패하고 이전 포인터가 정확히 유지됐으며 B가 호환·full SHA·SDK typed 검증에 통과하면 B로 실행한다. 이 경우 B가 앱 포함 A′보다 오래돼도 합법이며 다음 Startup에서 A′를 다시 시도할 수 있다. 저장 결과 불명확·ACK 후 실패에는 B로 임의 롤백하지 않는다. 선택은 metadata로 먼저 정하며 파일 가용성을 다른 Revision 선택 사유로 쓰지 않는다. Startup 이후 새 remote Prepare는 같은 도메인/family에서 확정본과 앱 포함 baseline보다 높은 순번을 요구한다.

원본 StreamingAssets는 보존하고 실행은 검증된 앱 소유 SHA 파일을 사용한다. 최초 `initial-install.json`의 현재 앱 포함 publisher SHA와 `Copying` 상태는 자기 `tmp/t-*.tmp`에 먼저 기록·디스크 반영한 뒤 원자적 이동으로 배치한다. 빈 저장소 판정에는 자기 `tmp` 바로 아래의 이 이름 패턴에 맞는 임시 파일 잔재만 허용하며, 그 밖의 파일이 있으면 최초 설치로 추정하지 않고 복구 경로로 둔다. 다음 실행에서 포인터가 없고 SHA가 같은 표시가 있으며, 다른 Revision metadata가 없고, 모든 blob이 그 publisher 소유임을 확인한 경우만 잔재를 blob → tmp → metadata 순으로 정리하고 A를 재시도한다. publisher가 없으면 blob도 없어야 한다.

포인터 쓰기 전 같은 표시 파일을 `CommitStarted`로 디스크 반영하고 정확 readback한다. 이 상태에서 포인터가 없으면 ACK 전후를 입증할 수 없으므로 자동 초기화하지 않는다. ACK 뒤 표시 파일을 지우며 삭제 실패는 경고로 남기고 포인터가 있는 다음 시작에서 재시도한다. 이 작은 확정 구간의 중단까지 자동 재시작을 보장하지 않는다. AR2-04 공통 복구 화면에는 필요한 경우 사용자가 앱 데이터 초기화나 재설치를 선택하도록 안내할 경로가 필요하다. 이번 구현에 Save 삭제·자동 초기화·별도 Journal은 없다. 공간 사전검사, 실제 복사 I/O, 물리 ENOSPC는 검증 결과에서 구분한다. StreamingAssets 직접 실행 fallback은 승인·구현하지 않았다.

## 최소 제작 연결과 후속 gate

명시 release metadata와 완료된 SDK Revision receipt로 packaged plan을 Preview하고 같은 입력·SHA를 다시 확인해 Apply한다. 새 출력은 create-only이며 검증 완료 전 Config에 연결하지 않는다. 과거 Revision과 현재 Boot는 기존 키/세대/원짝 Boot 바이트 증거로만 조합하며, 증거 없는 혼용은 새 파서를 추가하지 않고 거부한다. 공식 Player build context에는 Payload만 포함하고 원 Proof 영수증은 Editor 산출물로 보존한다. 현재 Config·Scene·appVersion이 달라지면 기존 stale 검사를 우회하지 않는다.

E2 중단 설정은 기존 `Preview Interrupted Split Build Settings` → `Restore Interrupted Split Build Settings`에서 원본·기록된 임시 상태·현재 파일을 비교한다. 충돌하거나 `.next`만 남아 자동 복원할 수 없으면 Preview의 안내대로 **pending 파일 백업 → 설정 직접 확인 → pending 파일 삭제** 순서로 수동 해결한다. 대상은 `Library/ArtressManagedAddressablesSplit/pending_split_settings.json`과 `Library/ArtressManagedAddressablesSplit/pending_split_settings.json.next` 중 존재하는 파일이다. 먼저 별도 위치에 백업하고, Settings/Group/schema/Profile을 소유자와 확인·수동 해결한 뒤 해당 기록만 삭제하고 다시 Preview한다. pending 삭제는 설정 복원이 아니며 새 버튼·자동 폐기·충돌 덮어쓰기는 없다.

실제 게임 Save 호환성은 제품 출시 검증이다. 콘텐츠 ID 포함만으로 Save 호환성을 선언하지 않고 Runtime에 범용 Save 검사기·마이그레이션 엔진을 추가하지 않는다. AR2-04·모바일 제품 수락·외부 게임·Automation·공식 릴리스는 별도 gate다. 이번 지시서의 승인된 로컬 구간 커밋은 후보 검증 및 이 gate의 대체물이 아니다.
