# JJEvol Managed Addressables 사용 가이드

문서 기준: 2026-11-07 / `1.3.12-pre.10`. 신규 게임의 제작·운영 안내 정본이다. 정식 릴리스나 제품 적용 완료 선언은 아니다. Windows Mono Player까지 이 가이드의 순서로 검증했다. Android, iOS, 원격 갱신은 NOT_RUN이다.

Managed는 개발자가 정한 폴더 규칙을 Addressables Group, Address, Bundle 제작 설정으로 연결하는 도구다. 콘텐츠 경로는 BootstrapSplit 하나다. 앱에 포함되는 Boot Catalog와, 앱이 소유한 저장소에서 여는 Revision Catalog로 나뉜다.

## 1. Quick Start

### 설치 전제

- 프로젝트가 선택한 고정 패키지와 의존성을 먼저 확인한다. package.json은 Unity 최소 선언 `2022.3`, Addressables `4.0.1`, Newtonsoft JSON `3.2.2`, IMGUI 모듈을 요구한다. 실제 검증 환경은 Unity `6000.3.9f1`이다.
- Managed, 일반 자산 로더 `com.jjevol.resources.addressables`, UI 소비자 `com.jjevol.ui.addressables`는 역할이 다르다. Managed 설치가 로더와 UI의 자동 연결까지 완료하지는 않는다.

### 최소 구성 순서

1. 게임별 Root를 정한다. 예: `Assets/Game/Addressables`. 기존 Art와 Prefab 원본은 유지하고 이 Root 아래에 독립 로딩할 최종 자산만 둔다.
2. `Local/UI`, `Remote/Gameplay` 등 필요한 Category 폴더를 만든다.
3. `Tools/Artress/Managed Addressables/Open Control Center`를 열고 `CREATE CONFIG / PREVIEW`로 Config를 만든다. 기본 위치는 `Assets/ArtressManagedAddressables/ManagedAddressableProjectConfig.asset`이다. 기존 Config는 덮어쓰지 않는다.
4. Content Root와 Resolved Path가 의도한 게임 폴더인지 확인한다.
5. `Preview Sync` → `APPLY REVIEWED PLAN` → `Validate` 순으로 진행한다.
6. 작은 자산 한 개를 등록하고 Groups에서 GUID, Entry, Address, Group을 확인한다. 소비자가 같은 Key로 로드·사용·반환하는 것을 확인한 뒤 범위를 넓힌다.

| 옵션 | 권고 값과 의미 |
|---|---|
| `contentRootFolder` / `ContentRootPath` | 게임 Root. 유효한 폴더 참조가 문자열 경로보다 우선 |
| `categoryRules` | ReservedFolder, PackTogether, enabled=true |
| `autoRegister`, `createGroupIfMissing` | true. 명시 Sync 시 등록·Group 생성 옵션이며 시작 시 자동 등록이 아님 |
| `preserveExistingAddressesOnSync` | true |
| `includeExtension`, `ensureUnique`, `pathSeparator` | false / false / `_`. 기본 ignorePathPrefixes=`Texture` |
| `allowDevelopmentHttp` | false. 6절 참고 |
| `backupBeforeApply`, `backupRoot` | true / `Library/ArtressManagedAddressablesBackup` |

## 2. Folder / Address / Group 규칙

```text
<Content Root>/
  Local/<Category>/.../Asset.ext
  Remote/<Category>/.../Asset.ext
  Remote/<Category>/Update/<BundleKey>/.../Asset.ext
```

| 개념 | 사용 방법 |
|---|---|
| Delivery | Local은 앱 포함 콘텐츠, Remote는 원격 콘텐츠. 다른 폴더 이름은 Sync가 거부 |
| Category | 기본 Group 단위. 기본 Local Group=`Category`, Remote Group=`Remote_Category`. 명시한 groupNamePattern이 우선 |
| Update/BundleKey | ReservedFolder 전략에서 Category 바로 아래에 사용. Group=`기본Group_BundleKey`. Address 후보에서는 Update/BundleKey를 제외 |
| BundleKey | 개발자가 정하는 제작 묶음. Unity Content Update 명령이나 서버 Revision이 아님 |

기본 ReservedFolder, 확장자 제외, `_`, ignorePathPrefixes=`Texture`에서 **새 등록** 예:

| Root 뒤 파일 경로 | Group | 신규 Address 후보 |
|---|---|---|
| `Local/UI/Home.prefab` | `UI` | `Home` |
| `Local/UI/UI_Home.prefab` | `UI` | `UI_Home` |
| `Remote/Character/Enemies/Boss.prefab` | `Remote_Character` | `Enemies_Boss` |
| `Remote/Character/Update/Pack02/Enemies/Boss.prefab` | `Remote_Character_Pack02` | `Enemies_Boss` |
| `Remote/Texture/Icon/Coin.png` | `Remote_Texture` | `Coin` |

Category의 UI가 Key에 자동으로 붙지는 않는다. Texture 예는 Category 자체가 ignore 대상이므로 파일명만 남는다. 주소 규칙의 구현은 `ManagedAddressNaming`이다.

일반 Sync는 GUID로 기존 Entry를 찾고, 계산 Group으로 옮긴 뒤 기존 비어 있지 않은 Address를 보존한다. `.meta`와 GUID를 유지한 이동·재명명은 Key 유지와 함께 가능하다. 명시적 Address Rebuild는 다른 작업이므로 예상 Key diff를 확인한다. 다른 자산에 `.meta`를 복사해 GUID를 재사용하지 않는다.

원본 Art는 Root 밖에 유지할 수 있다. Root 안 Prefab이 밖 원본을 참조할 수 있으며 실제 Bundle 포함과 공유 의존성은 SDK 빌드 결과에서 확인한다.

## 3. Control Center 등록 절차

1. 대상 게임, 타깃, 앱 버전과 Config의 Root, 규칙을 확인한다.
2. `Preview Sync`로 신규 등록, Group 이동, Address 변경·유지 계획을 검토한다. Preview는 Settings와 Entry를 바꾸지 않는다.
3. `APPLY REVIEWED PLAN`을 실행한다. 검토 뒤 입력이 바뀌면 다시 Preview해야 한다.
4. 결과 메시지와 실제 Groups, Entry, Schema를 확인하고 `Validate`를 실행한다.
5. 작은 자산을 실제 소비자 Key로 획득·사용·반환한다.

기존 Group은 이름이나 폴더로 자동 채택하지 않는다. 등록·정책 수정 대상으로 삼으려면 `Preview Group Adoption`으로 명시 채택한다. Sync가 새로 만든 Group은 자동으로 채택 목록에 들어간다.

Settings가 없는 최초 Sync는 Profile, Group baseline을 만든다. 새 Profile의 `Remote.LoadPath` 기본값은 미설정(`<undefined>`)이다. **Revision 빌드 전에 이 값을 실제 HTTPS 루트로 바꿔야 한다.** 바꾸기 전에는 Revision 검증이 차단한다. Validate는 Key 중복과 경로를 검사하는 기능이며 이전 앱과 새 Revision의 호환성 검증이 아니다.

## 4. Boot / Revision 제작

1. `Suggest Roles from Folders`를 누르면 Local 폴더 Group은 Boot, Remote 폴더 Group은 Revision으로 초안이 채워진다. shared 대상과 필수 Boot Key도 함께 채워지고, 이미 적은 행은 그대로 둔다. 폴더로 판단할 수 없는 Group은 결과 메시지에 나오므로 직접 추가한다.
2. `Preview Build Roles`에서 초안을 검토하고 `APPLY REVIEWED PLAN`으로 적용한다. SDK `DoNotBuildWithPlayer`가 함께 설정된다.
3. Sync가 만든 Remote Group은 Revision이 요구하는 cache, CRC, 다른 버전 보존 설정을 이미 갖췄다. 기존 Group을 채택했다면 `Preview Owned Remote Cache / CRC Policy`로 맞춘다.
4. `Release Metadata`를 Preview·Apply한다. 순번은 서버가 정하며 자동 생성하지 않는다.
5. `Preview Revision Build` → `BUILD SDK REVISION CONTENT`. 산출물은 빌드마다 새 stamp 폴더에 쌓이고 `revision_publisher.json`과 그 SHA-256이 나온다.
6. `Preview Packaged Revision A` → `APPLY REVIEWED PACKAGED A`로 앱 포함 A를 연결한다.
7. 공식 Player Build를 실행한다. Boot를 자동 제작하고 staging을 검증한다. `BUILD PLAYER BOOT CONTENT`는 진단용이다.

Boot에는 HTTP 경로를 쓸 수 없다. Revision에는 고정 HTTPS 루트가 필요하다. 제작 중 Settings, Group, schema는 임시로 바뀌고 끝나면 복원되며, 복원을 확인할 수 없으면 그 빌드는 실패한다.

Project Config가 있는 프로젝트의 모든 Player 빌드는 이 경로를 탄다. 역할이나 앱 포함 A가 없으면 빌드가 실패한다.

Player Scene 목록, Resources, 앱 버전이 바뀌면 앱 포함 A를 만든 Revision의 입력도 바뀐다. 이때 Player 빌드는 실패하므로 5번의 Revision부터 다시 만든다.

## 5. 콘텐츠 변경과 배포

| 변경 | 제작 작업 | 주의 |
|---|---|---|
| 이미지, Prefab 등 내용 수정 | GUID와 Key 유지, Sync 후 새 Revision | 같은 Key·경로·Bundle 배치·의존성 조건만 시험됨 |
| 신규 리소스 | 새 GUID, Entry, Key 등록 후 실제 소비 확인 | 신규 Key의 원격 갱신은 미검증 |
| Prefab의 신규 Material, Texture 참조 | 새 자원의 실제 Bundle 의존성 확인 | 신규 의존성 그래프는 미검증 |
| 이동, 재명명 | meta와 GUID 보존, Key 유지 확인 | Bundle 내부 경로가 바뀔 수 있음 |
| Group, Bundle 구성 변경 | 예상 Group과 의존성 확인 | 재편성은 미검증 |

Local 콘텐츠, 앱 코드, 직렬화 타입이 바뀌면 Player를 함께 제작한다. 서버는 앱 버전과 플랫폼별로 호환되는 Revision을 선택한다. Revision은 전체 파일이 산출되는 Full Snapshot이며 Unity Content Update를 쓰지 않는다. 게임 서버 URL과 인증은 게임의 서버 연동이 소유한다.

앱 시작과 교체 절차는 [Runtime 계약](AR2-Runtime2.md)이 정본이다. 요약하면 다음과 같다.

1. 앱이 SDK Boot를 초기화하고 실제 등록된 Locator를 받는다.
2. `ManagedAddressableRevision.CreatePackaged`와 `ManagedRevisionApplication`을 구성해 `OpenForApplicationAsync`를 호출한다.
3. 성공한 뒤에만 Revision 소비자를 시작한다.
4. 새 Revision은 `PrepareAsync`로 준비하고, 안전 시점에 `ApplyAsync`로 교체한다.

## 6. 개발용 http

기본은 HTTPS만 허용한다. 로컬 시험 서버에 평문 http가 필요하면 Control Center의 `Allow Development HTTP`를 켠다.

| 상태 | 동작 |
|---|---|
| 꺼짐 | http Revision URL은 Editor 검증과 Runtime 검사에서 실패 |
| 켜짐, Development Build | `insecureHttpOption`이 `NotAllowed`이면 빌드 동안 `DevelopmentOnly`로 바꾸고 되돌림. iOS는 Xcode `Info.plist`에 ATS 예외 추가 |
| 켜짐, Release Build | 시작 단계에서 빌드 실패 |

Release Player는 어떤 경우에도 http를 거부한다. 이 설정이 바꾸는 Player Settings는 Player 빌드에만 적용되며, Editor Play 모드는 프로젝트의 `insecureHttpOption`을 그대로 쓴다.

## 7. 문제 발생 시 확인 순서

1. 단계부터 구분한다. Config 저장과 Preview, Sync와 Validate, Boot·Revision 제작, 앱 포함 A 연결, Player 빌드, Runtime Open, Prepare, Apply 중 어디서 실패했는지 기록한다.
2. 게임, 타깃, 앱 버전, 고정 패키지, Revision을 확인한다. Key → GUID → AssetPath → Entry Group을 확인한다.
3. 제작 문제면 Preview 결과와 receipt를 확인한다. 기존 Key를 일괄 재발급하거나 Group과 meta를 삭제·재생성해 맞추지 않는다.
4. 중단된 빌드는 `Preview Interrupted Split Build Settings`와 `Restore Interrupted Player Build Metadata`로 복원한다.
5. Runtime 문제면 `ManagedRevisionResult`의 `Error`, `RecoveryRequired`, `Deferred`, `ReasonCode`와 `LastCleanupWarning`을 확인한다. 확인할 수 없는 결과를 성공으로 처리하지 않는다.

## 8. 구현 참조

[ProjectConfig](../Editor/ManagedAddressableProjectConfig.cs), [Window](../Editor/ManagedAddressablesWindow.cs), [PathRules](../Editor/ManagedAddressablePathRules.cs), [Naming](../Editor/ManagedAddressNaming.cs), [Preset](../Editor/ManagedAddressablePreset.cs), [Split build](../Editor/ManagedAddressableBuildExporter.Split.cs), [Player build](../Editor/ManagedBootstrapSplitPlayerBuild.cs), [Session](../Runtime/ManagedAddressableRevisionSession.cs), [Storage](../Runtime/ManagedAddressableRevisionStorage.cs).

감사 근거는 Framework checkout의 `Docs/AddressablesAudit/`에 있다.
