# G2 follow-up contract alignment

Internal candidate 1.3.12-pre.3, tested scope and unresolved conditions reported separately in Framework `Docs/AddressablesAudit/AR2-G2-Contract/`. Unity 6000.3.9f1 / Addressables 4.0.1 is the validation environment. This document is a usage contract, not a platform PASS or consumer migration approval. AR2-04 remains HOLD.

## Explicit Group ownership

`ManagedAddressableProjectConfig.ownedGroupGuids` records Group asset GUIDs and defaults to an empty list. Existing installations have no ownership records and must explicitly preview adoption of their intended Groups; group names, content roots and schema shapes never imply ownership. Adoption only changes the ownership record, not Group schemas, entries or addresses.

The Control Center provides Group selection with `Preview Group Adoption`, `Preview Group Release` and `Preview Missing Ownership Cleanup`. Inspect changes, then use `APPLY REVIEWED PLAN`. Missing/deleted Group GUIDs remain visible as warnings, without blocking Sync/Build solely because of the missing reference. Cleanup is explicit. New Group creation previews registration into the ownership list. Changes to inputs or settings invalidate the old plan.

External Groups, Profiles and schemas remain under their existing owners. Official SDK/Localization naming, packing and labels are not automatically rewritten or rejected because they differ from former consolidation rules. Actual deployment hazards are still validated.

## SDK Revision content production

`BUILD SDK REVISION CONTENT` uses the official SDK build output through the BootstrapSplit route. Since pre.9 this is the only content route.

`Preview Owned Remote Cache/CRC Policy` shows the explicit changes for owned Remote Groups: bundle cache on, CRC on, CRC checking of cached bundles off, retaining other cached versions. Apply the reviewed plan before building. Existing Local Groups and external settings are not normalized. The Split build sets JSON Catalog temporarily; the Remote path must be a fixed HTTPS root, and the build reports a missing requirement instead of rewriting the default Profile.

SDK 4.0.1 writes a bundle Hash when bundle caching is enabled and writes its CRC according to the CRC setting. NoHash is the filename policy and is independent of the internal Catalog Hash. CRC=0 alone is not an unconditional invalid-content rule. The Revision Runtime continues to require valid nonzero remote bundle Hashes. Existing deployed content is not migrated by this setting change.

## Initial selection and direct SDK calls

Runtime Profile expressions can affect the default Remote Catalog URL, not just Bundle URLs. They do not independently isolate the default persistent Catalog cache namespace. A first-launch expression evaluating to A can still select a same-name cached B Catalog when automatic updating is disabled. Changing a backing static property after its value was evaluated also does not rewrite existing SDK locations. A distinct PlayerVersion/runtime-settings experiment is not proof that changing a descriptor in one fixed Player solves the same cache collision.

The existing Session boot implementation requires supplying the confirmed descriptor and suspending every ordinary consumer, including Localization, before SDK initialization; call `OpenForApplicationAsync`, validate the selected content, then permit direct SDK consumption. The Session does not intercept arbitrary SDK calls made before that boundary. Profile expressions alone do not replace this contract or promise offline selection of a particular revision. **The user did not accept that boundary as the final startup solution: the first direct SDK request must select confirmed A even before Open.** A minimal official boot design review is separate from this implementation, and unconditional initial-selection acceptance remains unmet until that design is approved and verified.

After successful opening, private B preparation must keep ordinary direct requests on A and B-only keys invisible until the explicit safe apply boundary. All owners must finish their asset/scene/request cleanup before applying B. Conditional A re-entry and RecoveryRequired retain the original session contract; arbitrary gameplay restoration is not promised.

No new boot architecture, independent Catalog/Bundle engine, replicated ResourceManager, global SDK watcher or consumer-package migration is introduced. Actual observed direct-call stages, catalog/hash/cache identities, original failures, regression results and NOT_RUN Player/platform scope must be read from the fixed candidate's evidence.
