# Framework candidate 1.3.12-pre.10

Current status: internal candidate, not an official release. On a fresh Revision Host, the Editor and PlayMode tests pass, the official SDK chain builds a Windows Mono Player, and that Player confirms its packaged A offline and reuses it on the next start. Android, iOS, Vendor adapters, remote update, the Windows regression table, frame timing and IL2CPP are NOT_RUN. AR2-04, consumer games and official release remain HOLD.

This candidate removes the legacy content system. BootstrapSplit is the only path: a Boot binary Catalog packaged with the app and Revision JSON Catalogs in the app-owned store. Removed: Bootstrap, ContentInstaller, Storage, CatalogService, RuntimeSettings, the manifest models and MD5 utility, the ExistingWorkflow mode, artifact deployment, seed output, the remote change report, the Spine prefab generator and shader dependency helper, `Candidates~/WindowsLocal`, and the Obsolete `OpenAsync` and `ApplyAsync` stubs. There are no compatibility shims and no migration. Shipped games stay on their framework version. Revision classes, serialized Revision fields and their GUIDs are unchanged.

Behaviour changes on the Revision path:

- Publishers must carry deployment metadata and `catalogBytes`. The exporter always writes them, and a Revision plan without release metadata is blocked.
- Plain http fails by default. `allowDevelopmentHttp` on the Project Config allows it in Development Builds; a release Player build with it on fails.
- Build Roles always plans `DoNotBuildWithPlayer`.
- Every Player build in a project with a Project Config goes through the Split path.
- Metadata writes put the publisher first, so an interruption can no longer stop startup cleanup, and cleanup removes a Catalog that has no publisher.
- Displayed URLs and download errors no longer carry the query string. Stored and requested URLs stay byte-exact.

`Tests/Fixtures~` holds the Revision Host template and `Run-RevisionHost.ps1`. They run the Editor and PlayMode tests, the official SDK chain and a Windows Player on a fresh project in any folder.

## Preserved limits

The initial-install marker is restricted to a verified empty-origin installation. Its `Copying` and `CommitStarted` phases distinguish retryable same-A residue from an ambiguous missing pointer after commit began. The latter returns `ManagedRevisionReasonCode.InitialInstallCommitStartedWithoutPointer` and stays in Boot recovery. No Save deletion or automatic reset is provided. AR2-04 must supply a recovery-screen path for manual app-data initialization or reinstallation.

For a Split settings conflict or a remaining `.next` file, Preview instructs the owner to back up the pending files, resolve the Settings, Group, schema and Profile state by hand, then remove only those pending files and Preview again. Removing a record does not restore Settings.

Bundles and metadata are moved to their final location after `FileStream.Flush(true)`, and the pointer is written after that. On Windows Mono a disk flush failure is not detected by the caller. Execution confirmed the call order in pre.8, not durability across power loss.

R2 matches `sdkBundleName + ".bundle"` exactly and case-sensitively for Addressables 4.0.1 only; other SDKs are rejected. Android and iOS naming remain NOT_RUN.

## History

pre.8 added deferred-A resumption, startup preservation of one eligible unconfirmed publisher, atomic persistence, same-confirmed-revision repair, previewed role adoption and required packaged A. Its validation record is `Docs/AddressablesAudit/AR2-Runtime2-Fix/CompletionReport.md`. pre.7 added packaged-A copying and metadata-based selection. pre.5 and pre.6 added the Session and app-owned store. pre.4 added BootstrapSplit, then as an opt-in beside the now removed route. pre.3 added the explicit Group ownership list. See [Runtime contract](Documentation~/AR2-Runtime2.md) and [G2 contract](Documentation~/AR2-G2-ContractAlignment.md).

2026-10-29: Mobile UPM 1.3.11 is the baseline. Package name, namespaces and original assembly definitions remain. User authorship was confirmed directly on 2026-10-29 in `JJEvolAutomation/SourceOwnership.md`. No public redistribution license has been assigned. This extraction grants no rights to external SDKs, commercial assets or company content.

## Authoring contract

Install alone does not initialize a project or change Profiles, Groups, keys or Bundle output settings. Review and apply the exact plan. Existing Settings preserve Profiles, Global values and external Group schemas. Only explicitly owned Groups can be changed; newly created Groups preview their ownership registration. Stale plans fail before writes. Legal official SDK naming, packing and cache choices are not rejected merely for differing from package defaults.

Preview plans Group, Entry, Profile and Global changes without creating Settings. Apply consumes that same in-memory plan and rechecks drift before backup and writes. Empty plans avoid transaction, save, refresh and notification. Public SDK creation can save unrelated dirty assets, so this path rejects affected external pending edits before writes. The scoped rollback does not cover process termination, disk failure or builds. Backup destinations must stay in dedicated project-local folders outside Assets, Packages and ProjectSettings.

Source-contract tests do not establish that a real content build, Player or remote update succeeded.
