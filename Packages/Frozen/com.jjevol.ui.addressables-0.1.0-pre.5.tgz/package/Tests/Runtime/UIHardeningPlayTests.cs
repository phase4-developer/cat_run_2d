using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using jjevol.Audio;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.EventSystems;
using UnityEngine.TestTools;
using UnityEngine.U2D;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace jjevol.UI.Tests
{
    public sealed partial class UIAddressablePlayTests
    {
        private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;

        private static T Get<T>(object target, string field) => (T)target.GetType().GetField(field, Private).GetValue(target);
        private static bool IsCanceled(Task task) => task.IsCanceled || task.Exception?.GetBaseException() is OperationCanceledException;
        private static int MeshVertices(Image image)
        {
            using var mesh = new VertexHelper();
            image.GetType().GetMethod("OnPopulateMesh", Private, null, new[] { typeof(VertexHelper) }, null).Invoke(image, new object[] { mesh });
            return mesh.currentVertCount;
        }
        private static void ResetSoundWarnings()
        {
            typeof(UIManager).Assembly.GetType("jjevol.UISoundPlayback").GetMethod("ResetState", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, null);
        }
        private IEnumerator LoadedAtlas(Action<SpriteAtlas> received)
        {
            var source = Addressables.LoadAssetAsync<SpriteAtlas>("Step11/Atlas"); _assets.Add(source);
            yield return Done(source.Task);
            received(source.Result);
        }
        private AddressableLoadingView LocalView(string prefabKey)
        {
            var view = New("local loading", typeof(RectTransform)).AddComponent<AddressableLoadingView>();
            view.loadingPrefabKey = prefabKey;
            return view;
        }
        private AddressableImage NewImage(string name) => New(name, typeof(RectTransform)).AddComponent<AddressableImage>();
        private AddressableTexture NewTexture(string name) => New(name, typeof(RectTransform)).AddComponent<AddressableTexture>();
        private void InstallGlobalLoading()
        {
            var template = New("global loading template", typeof(RectTransform)).AddComponent<AddressableLoadingView>();
            var pool = New("global loading pool", typeof(RectTransform));
            var service = new AddressableLoadingViewService(template, pool.transform, 1, 0f);
            typeof(UIManager).GetProperty(nameof(UIManager.AddressableLoadingViews)).SetValue(_manager, service);
        }

        // U1
        [UnityTest]
        public IEnumerator ThrowingButtonSoundWarnsOnceAndDoesNotBreakTheClick()
        {
            ResetSoundWarnings();
            var go = New("silent button", typeof(RectTransform), typeof(Image), typeof(Button));
            Set(go.AddComponent<UIButtonSound>(), "soundKey", "step11/failing");
            int clicks = 0;
            go.GetComponent<Button>().onClick.AddListener(() => clicks++);
            var pointer = new PointerEventData(New("events", typeof(EventSystem)).GetComponent<EventSystem>()) { button = PointerEventData.InputButton.Left };
            void Throw(AudioEvents.PlayUI value) => throw new InvalidOperationException("synthetic sound failure");
            AudioEvents.UiRequested += Throw;
            try
            {
                LogAssert.Expect(LogType.Warning, new Regex(@"\[UISound\].*step11/failing"));
                ExecuteEvents.Execute(go, pointer, ExecuteEvents.pointerClickHandler);
                ExecuteEvents.Execute(go, pointer, ExecuteEvents.pointerClickHandler);
                Assert.That(clicks, Is.EqualTo(2));
                LogAssert.NoUnexpectedReceived();
            }
            finally { AudioEvents.UiRequested -= Throw; }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ThrowingSoundSubscriberDoesNotInterruptPopupClose()
        {
            ResetSoundWarnings();
            var popup = _manager.SpawnUIPopupAsync("YesNoPopup").AsTask(); yield return Done(popup);
            Set(popup.Result, "closeSoundKey", "step11/close");
            void Throw(AudioEvents.PlaySfx value) => throw new InvalidOperationException("synthetic sound failure");
            AudioEvents.SfxRequested += Throw;
            try
            {
                LogAssert.Expect(LogType.Warning, new Regex(@"\[UISound\].*synthetic sound failure"));
                var wait = popup.Result.CloseWait().AsTask();
                popup.Result.OnClickCloseBtn();
                yield return Done(wait);
                Assert.That(wait.Result, Is.True);
            }
            finally { AudioEvents.SfxRequested -= Throw; }
        }

        // U2
        [UnityTest]
        public IEnumerator ReplacedPooledScreenRequestIsHiddenInsteadOfLeftVisible()
        {
            var prefab = Addressables.LoadAssetAsync<GameObject>("UIScreen_IntroScreen"); _assets.Add(prefab); yield return Done(prefab.Task);
            var type = "77711";
            var provider = Gate("UIScreen_77711", prefab.Result);
            var stale = _manager.screenManager.SpawnUIScreenAsync(type).AsTask(); yield return Until(() => provider.Pending.Count == 1);
            var current = _manager.screenManager.SpawnUIScreenAsync("LobbyScreen").AsTask(); yield return Done(current);
            provider.Finish(); yield return Done(stale);
            Assert.That(stale.Result, Is.Null);
            Assert.That(_manager.screenManager.CurrentScreen, Is.SameAs(current.Result));
            Assert.That(_manager.screenManager.screenPool[type].IsVisible, Is.False, "A replaced pooled request must not leave a ghost screen.");
            Assert.That(current.Result.IsVisible, Is.True);
        }

        [UnityTest]
        public IEnumerator ReplacedDisposableScreenRequestReleasesOnlyItsOwnInstance()
        {
            var prefab = Addressables.LoadAssetAsync<GameObject>("UIScreen_IntroScreen"); _assets.Add(prefab); yield return Done(prefab.Task);
            var type = "77712";
            var provider = Gate("UIScreen_77712", prefab.Result);
            var kept = _manager.screenManager.SpawnUIScreenAsync("LobbyScreen").AsTask(); yield return Done(kept);
            int released = _instances.Released;
            var stale = _manager.screenManager.SpawnUIScreenAsync(type, null, false).AsTask(); yield return Until(() => provider.Pending.Count == 1);
            var current = _manager.screenManager.SpawnUIScreenAsync("LobbyScreen").AsTask(); yield return Done(current);
            provider.Finish(); yield return Done(stale);
            yield return Until(() => _instances.Released == released + 1);
            Assert.That(_manager.screenManager.screenPool.ContainsKey(type), Is.False);
            Assert.That(kept.Result != null, Is.True, "The pooled current screen must survive.");
            Assert.That(_manager.screenManager.CurrentScreen, Is.SameAs(kept.Result));
        }

        // U3
        private IEnumerator SpawnThrough(GateProvider provider, string type, Action<UIPopup> received)
        {
            var spawn = _manager.SpawnUIPopupAsync(type).AsTask();
            float end = Time.realtimeSinceStartup + 8;
            while (!spawn.IsCompleted && Time.realtimeSinceStartup < end) { provider.Finish(); yield return null; }
            yield return Done(spawn);
            received(spawn.Result);
        }

        [UnityTest]
        public IEnumerator ReopeningDuringACloseTransitionCreatesANewPopup()
        {
            var template = New("transition popup", typeof(RectTransform), typeof(CanvasGroup));
            template.SetActive(false);
            template.AddComponent<UIFixtureTransition>();
            template.AddComponent<UIPopup>();
            var type = "77713";
            var provider = Gate("UIPopup_77713", template);
            UIPopup first = null, second = null;
            yield return SpawnThrough(provider, type, popup => first = popup);
            var wait = first.CloseWait().AsTask();
            first.ClosePopup();
            Assert.That(first.IsOpen, Is.False);
            Assert.That(first.IsTransitioning, Is.True);
            yield return SpawnThrough(provider, type, popup => second = popup);
            Assert.That(second, Is.Not.SameAs(first), "A closing popup is not a duplicate of the reopen request.");
            Assert.That(second.IsOpen, Is.True);
            Assert.That(_manager.popupManager.GetTopPopup(), Is.SameAs(second));
            first.GetComponent<UIFixtureTransition>().FinishHide();
            yield return Done(wait);
            Assert.That(wait.Result, Is.True);
            Assert.That(_manager.popupManager.ActivePopups, Is.EquivalentTo(new[] { second }));
            second.ClosePopup();
            second.GetComponent<UIFixtureTransition>().FinishHide();
        }

        [UnityTest]
        public IEnumerator CloseWaitAfterTheCloseReturnsTheStoredResult()
        {
            var popup = _manager.SpawnUIPopupAsync("YesNoPopup").AsTask(); yield return Done(popup);
            popup.Result.ClosePopup(false);
            var late = popup.Result.CloseWait().AsTask();
            Assert.That(late.IsCompleted, Is.True, "A closed popup can never complete a new waiter.");
            Assert.That(late.Result, Is.False);
            yield return null;
            var afterDestroy = popup.Result.CloseWait().AsTask();
            Assert.That(afterDestroy.IsCompleted, Is.True);
            Assert.That(afterDestroy.Result, Is.False);
        }

        [UnityTest]
        public IEnumerator CloseWaitAfterADestroyWithoutResultIsCanceled()
        {
            var popup = _manager.SpawnUIPopupAsync("YesNoPopup").AsTask(); yield return Done(popup);
            _manager.popupManager.DestroyAllImmediately();
            var late = popup.Result.CloseWait().AsTask();
            Assert.That(late.IsCompleted, Is.True);
            Assert.That(IsCanceled(late), Is.True);
            yield return null;
        }

        // U4
        [UnityTest]
        public IEnumerator NeverActivatedImageDefersItsLoadUntilEnabled()
        {
            var go = New("inactive image", typeof(RectTransform)); go.SetActive(false);
            var image = go.AddComponent<AddressableImage>();
            Set(image, "m_LoadOnEnable", false);
            image.SetAtlasSprite("Step11/Atlas", "step11_red");
            yield return null; yield return null;
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Atlas"), Is.Zero, "OnDestroy never runs here, so a lease could not be returned.");
            go.SetActive(true);
            yield return Until(() => image.sprite != null);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Atlas"), Is.EqualTo(1));
        }

        [UnityTest]
        public IEnumerator NeverActivatedComponentsDestroyedWithoutLeases()
        {
            var imageObject = New("inactive atlas", typeof(RectTransform)); imageObject.SetActive(false);
            imageObject.AddComponent<AddressableImage>().SetAtlasSprite("Step11/Atlas", "step11_red");
            var textureObject = New("inactive texture", typeof(RectTransform)); textureObject.SetActive(false);
            var texture = textureObject.AddComponent<AddressableTexture>();
            yield return Done(texture.LoadSpriteAsync("Step11/Texture").AsTask());
            Assert.That(texture.spriteKey, Is.EqualTo("Step11/Texture"));
            Object.Destroy(imageObject); Object.Destroy(textureObject);
            yield return null; yield return null;
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Atlas"), Is.Zero);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Texture"), Is.Zero);
        }

        [UnityTest]
        public IEnumerator IsLoadDeferredReportsOnlyALoadWaitingForFirstActivation()
        {
            var plainObject = New("same key only", typeof(RectTransform)); plainObject.SetActive(false);
            var plain = plainObject.AddComponent<AddressableImage>();
            Set(plain, "m_LoadOnEnable", false); Set(plain, "m_AtlasKey", "Step11/Atlas");
            plain.SetAtlasSprite("Step11/Atlas", "step11_red");
            Assert.That(plain.IsLoadDeferred, Is.False, "The same key only records the name.");
            plainObject.SetActive(true);
            yield return null; yield return null;
            Assert.That(plain.sprite, Is.Null, "Load On Enable is off and nothing was deferred.");
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Atlas"), Is.Zero);

            var imageObject = New("deferred image", typeof(RectTransform)); imageObject.SetActive(false);
            var image = imageObject.AddComponent<AddressableImage>();
            Set(image, "m_LoadOnEnable", false); Set(image, "m_AtlasKey", "Step11/Atlas");
            image.SetAtlasSprite("Step11/Atlas", "step11_red");
            yield return Done(image.LoadAtlasAsync("Step11/Atlas").AsTask());
            Assert.That(image.IsLoadDeferred, Is.True);
            image.atlasKey = "Step11/Atlas";
            Assert.That(image.IsLoadDeferred, Is.True, "Setting the same key must keep the deferred load.");
            imageObject.SetActive(true);
            Assert.That(image.IsLoadDeferred, Is.False);
            yield return Until(() => image.sprite != null);

            var textureObject = New("deferred texture", typeof(RectTransform)); textureObject.SetActive(false);
            var texture = textureObject.AddComponent<AddressableTexture>();
            Set(texture, "m_LoadOnEnable", false);
            yield return Done(texture.LoadSpriteAsync("Step11/Texture").AsTask());
            Assert.That(texture.IsLoadDeferred, Is.True);
            texture.spriteKey = "Step11/Texture";
            Assert.That(texture.IsLoadDeferred, Is.True, "Setting the same key must keep the deferred load.");
            textureObject.SetActive(true);
            Assert.That(texture.IsLoadDeferred, Is.False);
            yield return Until(() => texture.sprite != null);
        }

        // I1
        [UnityTest]
        public IEnumerator SlowLoadingPrefabDoesNotDelayImages()
        {
            var source = Addressables.LoadAssetAsync<GameObject>("Step11/loading"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/slow-loading", source.Result);
            var image = NewImage("image with slow loading");
            Set(image, "m_ShowLoading", true); Set(image, "m_LoadingView", LocalView("Step11/slow-loading"));
            var texture = NewTexture("texture with slow loading");
            Set(texture, "m_LoadingView", LocalView("Step11/slow-loading"));
            image.SetAtlasSprite("Step11/Atlas", "step11_red");
            texture.spriteKey = "Step11/Texture";
            yield return Until(() => image.sprite != null && texture.sprite != null);
            Assert.That(provider.Pending, Is.Not.Empty, "The images finished while the loading Prefab was still pending.");
        }

        [UnityTest]
        public IEnumerator FailedLoadingPrefabOnlyWarnsAndTheImageStillLoads()
        {
            LogAssert.ignoreFailingMessages = true;
            try
            {
                LogAssert.Expect(LogType.Warning, new Regex("Loading display failed"));
                var image = NewImage("image with broken loading");
                Set(image, "m_ShowLoading", true); Set(image, "m_LoadingView", LocalView("Step11/missing-loading"));
                image.SetAtlasSprite("Step11/Atlas", "step11_red");
                yield return Until(() => image.sprite != null);
            }
            finally { LogAssert.ignoreFailingMessages = false; }
        }

        // I2
        [UnityTest]
        public IEnumerator ShowLoadingIsTheOnlySwitchForGlobalLoading()
        {
            SpriteAtlas atlas = null; yield return LoadedAtlas(value => atlas = value);
            var off = Gate("Step11/gated-off", atlas); var on = Gate("Step11/gated-on", atlas);
            InstallGlobalLoading();
            var quiet = NewImage("show loading off");
            var shown = NewImage("show loading on"); Set(shown, "m_ShowLoading", true);
            quiet.SetAtlasSprite("Step11/gated-off", "step11_red");
            shown.SetAtlasSprite("Step11/gated-on", "step11_red");
            yield return Until(() => off.Pending.Count == 1 && on.Pending.Count == 1);
            yield return Until(() => shown.transform.childCount == 1);
            Assert.That(quiet.transform.childCount, Is.Zero, "Show Loading off must also silence the global loading.");
            off.Finish(); on.Finish();
            yield return Until(() => quiet.sprite != null && shown.sprite != null);
            yield return Until(() => shown.transform.childCount == 0);
        }

        // I3
        [UnityTest]
        public IEnumerator TextureKeepsAColorChangedByCode()
        {
            var image = NewTexture("colored texture");
            yield return Done(image.LoadSpriteAsync("Step11/Texture").AsTask());
            image.color = Color.red;
            image.gameObject.SetActive(false); image.gameObject.SetActive(true);
            Assert.That(image.color, Is.EqualTo(Color.red), "Disabling must not restore an Awake-time color.");
            image.spriteKey = "Step11/Texture";
            Assert.That(image.color, Is.EqualTo(Color.red));
            yield return Done(image.LoadSpriteAsync("Step11/DirectSprite").AsTask());
            Assert.That(image.color, Is.EqualTo(Color.red), "Completing a load must not restore an Awake-time color.");
            Assert.That(image.originColor, Is.EqualTo(Color.red));
            image.alpha = .25f;
            Assert.That(image.color.a, Is.EqualTo(.25f).Within(.001f));
            Assert.That(image.alpha, Is.EqualTo(.25f).Within(.001f));
        }

        [UnityTest]
        public IEnumerator LoadingColorReturnsToTheColorAtLoadStart()
        {
            var source = Addressables.LoadAssetAsync<Texture2D>("Step11/Texture"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/tinted-texture", source.Result);
            var image = NewTexture("tinted texture");
            Set(image, "m_LoadingView", LocalView(string.Empty));
            Set(image, "m_LoadingColor", Color.green);
            Set(image, "m_FadeColorDuration", 0f);
            image.color = Color.red;
            var load = image.LoadSpriteAsync("Step11/tinted-texture").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            Assert.That(image.color, Is.EqualTo(Color.green));
            Assert.That(image.originColor, Is.EqualTo(Color.red));
            image.alpha = .5f;
            Assert.That(image.color, Is.EqualTo(Color.green), "Changing the base color must not touch the visible loading color.");
            provider.Finish(); yield return Done(load);
            Assert.That(image.color, Is.EqualTo(new Color(1f, 0f, 0f, .5f)));
        }

        private AddressableTexture TintedTexture(string name)
        {
            var image = NewTexture(name);
            Set(image, "m_LoadingView", LocalView(string.Empty));
            Set(image, "m_LoadingColor", Color.green);
            Set(image, "m_FadeColorDuration", 0f);
            image.color = Color.red;
            return image;
        }

        [UnityTest]
        public IEnumerator WaiterResumesAfterTheLoadingColorIsRestored()
        {
            var source = Addressables.LoadAssetAsync<Texture2D>("Step11/Texture"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/waited-texture", source.Result);
            var image = TintedTexture("waited texture");
            var first = image.LoadSpriteAsync("Step11/waited-texture").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            var resumed = Color.clear;
            async UniTask PaintAfterWait()
            {
                await image.LoadSpriteAsync("Step11/waited-texture");
                resumed = image.color;
                image.color = Color.blue;
            }
            var waiter = PaintAfterWait().AsTask();
            provider.Finish(); yield return Done(Task.WhenAll(first, waiter));
            Assert.That(resumed, Is.EqualTo(Color.red), "The load must be cleaned up before its waiter resumes.");
            Assert.That(image.color, Is.EqualTo(Color.blue), "Cleanup must not overwrite a color set by the resumed waiter.");
        }

        [UnityTest]
        public IEnumerator WaiterOfACanceledLoadResumesAfterTheLoadingColorIsRestored()
        {
            var source = Addressables.LoadAssetAsync<Texture2D>("Step11/Texture"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/canceled-texture", source.Result);
            var image = TintedTexture("canceled texture");
            var first = image.LoadSpriteAsync("Step11/canceled-texture").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            var resumed = Color.clear;
            async UniTask PaintAfterWait()
            {
                await image.LoadSpriteAsync("Step11/canceled-texture");
                resumed = image.color;
                image.color = Color.blue;
            }
            var waiter = PaintAfterWait().AsTask();
            image.gameObject.SetActive(false);
            yield return Until(() => waiter.IsCompleted);
            Assert.That(resumed, Is.EqualTo(Color.red));
            Assert.That(image.color, Is.EqualTo(Color.blue));
            provider.Finish(); yield return Done(first);
        }

        // I4
        [UnityTest]
        public IEnumerator LoadWithoutLoadingDisplaySkipsTheColorAnimation()
        {
            var image = NewTexture("no loading animation");
            Set(image, "m_FadeColorDuration", 30f);
            Set(image, "m_LoadingColor", Color.green);
            image.color = Color.red;
            yield return Done(image.LoadSpriteAsync("Step11/Texture").AsTask());
            Assert.That(image.sprite, Is.Not.Null);
            Assert.That(image.color, Is.EqualTo(Color.red), "No loading display was shown, so no color animation may run.");
        }

        // I5
        [UnityTest]
        public IEnumerator HiddenGraphicStillDrawsAnAssignedSprite()
        {
            var direct = Addressables.LoadAssetAsync<Sprite>("Step11/DirectSprite"); _assets.Add(direct); yield return Done(direct.Task);
            var image = NewImage("assigned sprite");
            Assert.That(MeshVertices(image), Is.Zero, "An empty AddressableImage must not draw the default white rectangle.");
            image.sprite = direct.Result;
            Assert.That(MeshVertices(image), Is.GreaterThan(0));
            image.sprite = null;
            Assert.That(MeshVertices(image), Is.Zero);
        }

        [UnityTest]
        public IEnumerator PreviousSpriteStaysDrawnWhileTheNextAtlasLoads()
        {
            SpriteAtlas atlas = null; yield return LoadedAtlas(value => atlas = value);
            var provider = Gate("Step11/next-atlas", atlas);
            var image = NewImage("atlas swap");
            image.SetAtlasSprite("Step11/Atlas", "step11_red"); yield return Until(() => image.sprite != null);
            image.SetAtlasSprite("Step11/next-atlas", "step11_blue");
            yield return Until(() => provider.Pending.Count == 1);
            Assert.That(image.sprite, Is.Not.Null);
            Assert.That(MeshVertices(image), Is.GreaterThan(0), "The previous Sprite must stay visible during the swap.");
            provider.Finish();
            yield return Until(() => image.sprite != null && image.sprite.name.StartsWith("step11_blue", StringComparison.Ordinal));
        }

        // I6
        [UnityTest]
        public IEnumerator SameKeyCallWaitsForTheLoadInProgress()
        {
            SpriteAtlas atlas = null; yield return LoadedAtlas(value => atlas = value);
            var atlasGate = Gate("Step11/shared-atlas", atlas);
            var source = Addressables.LoadAssetAsync<Texture2D>("Step11/Texture"); _assets.Add(source); yield return Done(source.Task);
            var textureGate = Gate("Step11/shared-texture", source.Result);
            var image = NewImage("shared atlas"); image.SetSprite("step11_red");
            var texture = NewTexture("shared texture");
            var firstImage = image.LoadAtlasAsync("Step11/shared-atlas").AsTask();
            var firstTexture = texture.LoadSpriteAsync("Step11/shared-texture").AsTask();
            yield return Until(() => atlasGate.Pending.Count == 1 && textureGate.Pending.Count == 1);
            var secondImage = image.LoadAtlasAsync("Step11/shared-atlas").AsTask();
            var secondTexture = texture.LoadSpriteAsync("Step11/shared-texture").AsTask();
            yield return null;
            Assert.That(secondImage.IsCompleted, Is.False, "The call must not return before the load it shares.");
            Assert.That(secondTexture.IsCompleted, Is.False);
            atlasGate.Finish(); textureGate.Finish();
            yield return Done(Task.WhenAll(firstImage, firstTexture, secondImage, secondTexture));
            Assert.That(image.sprite, Is.Not.Null); Assert.That(texture.sprite, Is.Not.Null);
            Assert.That(atlasGate.Loads, Is.EqualTo(1)); Assert.That(textureGate.Loads, Is.EqualTo(1));
        }

        [UnityTest]
        public IEnumerator WaitingCallerCanCancelOnlyItsOwnWait()
        {
            SpriteAtlas atlas = null; yield return LoadedAtlas(value => atlas = value);
            var provider = Gate("Step11/cancel-wait", atlas);
            var image = NewImage("cancel wait"); image.SetSprite("step11_red");
            var first = image.LoadAtlasAsync("Step11/cancel-wait").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            using var token = new CancellationTokenSource();
            var waiter = image.LoadAtlasAsync("Step11/cancel-wait", token.Token).AsTask();
            token.Cancel();
            yield return Until(() => waiter.IsCompleted);
            Assert.That(IsCanceled(waiter), Is.True);
            Assert.That(first.IsCompleted, Is.False);
            provider.Finish(); yield return Done(first);
            Assert.That(image.sprite, Is.Not.Null);
        }

        [UnityTest]
        public IEnumerator LoadAtlasAsyncUpdatesTheKeyUsedOnReactivation()
        {
            SpriteAtlas atlas = null; yield return LoadedAtlas(value => atlas = value);
            var provider = Gate("Step11/second-atlas", atlas);
            var image = NewImage("atlas key");
            image.SetAtlasSprite("Step11/Atlas", "step11_red"); yield return Until(() => image.sprite != null);
            var load = image.LoadAtlasAsync("Step11/second-atlas").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            provider.Finish(); yield return Done(load);
            Assert.That(image.atlasKey, Is.EqualTo("Step11/second-atlas"));
            image.gameObject.SetActive(false); image.gameObject.SetActive(true);
            yield return null; yield return null;
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/second-atlas"), Is.EqualTo(1));
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Atlas"), Is.Zero, "Reactivation must not return to the previous Atlas.");
        }

        [UnityTest]
        public IEnumerator RequestingTheShownKeyCancelsTheLoadInProgress()
        {
            var source = Addressables.LoadAssetAsync<Texture2D>("Step11/Texture"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/abandoned-texture", source.Result);
            var image = NewTexture("latest wins");
            yield return Done(image.LoadSpriteAsync("Step11/DirectSprite").AsTask());
            Sprite shown = image.sprite;
            var abandoned = image.LoadSpriteAsync("Step11/abandoned-texture").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            yield return Done(image.LoadSpriteAsync("Step11/DirectSprite").AsTask());
            provider.Finish(); yield return Done(abandoned); yield return null;
            Assert.That(image.sprite, Is.SameAs(shown));
            Assert.That(image.spriteKey, Is.EqualTo("Step11/DirectSprite"));
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/abandoned-texture"), Is.Zero);
        }

        [UnityTest]
        public IEnumerator SettingTheShownKeyCancelsTheLoadInProgress()
        {
            SpriteAtlas atlas = null; yield return LoadedAtlas(value => atlas = value);
            var atlasGate = Gate("Step11/abandoned-atlas", atlas);
            var source = Addressables.LoadAssetAsync<Texture2D>("Step11/Texture"); _assets.Add(source); yield return Done(source.Task);
            var textureGate = Gate("Step11/set-abandoned-texture", source.Result);
            var image = NewImage("shown atlas key");
            image.SetAtlasSprite("Step11/Atlas", "step11_red"); yield return Until(() => image.sprite != null);
            var texture = NewTexture("shown texture key");
            yield return Done(texture.LoadSpriteAsync("Step11/DirectSprite").AsTask());
            Sprite shownImage = image.sprite, shownTexture = texture.sprite;
            var abandonedImage = image.LoadAtlasAsync("Step11/abandoned-atlas").AsTask();
            var abandonedTexture = texture.LoadSpriteAsync("Step11/set-abandoned-texture").AsTask();
            yield return Until(() => atlasGate.Pending.Count == 1 && textureGate.Pending.Count == 1);
            image.atlasKey = "Step11/Atlas";
            texture.spriteKey = "Step11/DirectSprite";
            atlasGate.Finish(); textureGate.Finish();
            yield return Done(Task.WhenAll(abandonedImage, abandonedTexture)); yield return null;
            Assert.That(image.sprite, Is.SameAs(shownImage));
            Assert.That(texture.sprite, Is.SameAs(shownTexture));
            Assert.That(image.atlasKey, Is.EqualTo("Step11/Atlas"));
            Assert.That(texture.spriteKey, Is.EqualTo("Step11/DirectSprite"));
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/abandoned-atlas"), Is.Zero);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/set-abandoned-texture"), Is.Zero);
        }

        [UnityTest]
        public IEnumerator FirstCallerCancellationEndsTheLoadForItsWaiters()
        {
            SpriteAtlas atlas = null; yield return LoadedAtlas(value => atlas = value);
            var provider = Gate("Step11/first-cancel", atlas);
            var image = NewImage("first caller cancel"); image.SetSprite("step11_red");
            using var token = new CancellationTokenSource();
            var first = image.LoadAtlasAsync("Step11/first-cancel", token.Token).AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            var waiter = image.LoadAtlasAsync("Step11/first-cancel").AsTask();
            token.Cancel();
            provider.Finish();
            yield return Until(() => first.IsCompleted && waiter.IsCompleted);
            Assert.That(waiter.IsCompletedSuccessfully, Is.True, "The waiter returns without an exception.");
            yield return null; yield return null;
            Assert.That(image.sprite, Is.Null, "The caller that started the load owns its cancellation.");
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/first-cancel"), Is.Zero);
        }

        // I7
        [UnityTest]
        public IEnumerator RuntimeCreatedSpritesUseAFullRectMesh()
        {
            var texture = new Texture2D(64, 64, TextureFormat.RGBA32, false);
            var pixels = new Color32[64 * 64];
            for (int y = 24; y < 40; y++) for (int x = 24; x < 40; x++) pixels[y * 64 + x] = new Color32(255, 255, 255, 255);
            texture.SetPixels32(pixels); texture.Apply();
            try
            {
                var provider = Gate("Step11/sparse-texture", texture);
                var image = NewTexture("full rect");
                var load = image.LoadSpriteAsync("Step11/sparse-texture").AsTask();
                yield return Until(() => provider.Pending.Count == 1);
                provider.Finish(); yield return Done(load);
                Assert.That(image.sprite.vertices.Length, Is.EqualTo(4));
                Assert.That(image.sprite.rect.size, Is.EqualTo(new Vector2(64, 64)));
            }
            finally { Object.Destroy(texture); }
        }

        // I8
        [UnityTest]
        public IEnumerator ChangeEventsFireOnlyWhenANewSpriteIsApplied()
        {
            var image = NewImage("image changes"); int imageChanges = 0;
            image.OnChangeSprite += () => imageChanges++;
            image.SetAtlasSprite("Step11/Atlas", "step11_red"); yield return Until(() => image.sprite != null);
            Assert.That(imageChanges, Is.EqualTo(1));
            image.gameObject.SetActive(false); image.gameObject.SetActive(true); yield return null;
            Assert.That(imageChanges, Is.EqualTo(1), "Reapplying the shown Sprite is not a change.");
            image.SetSprite("step11_missing");
            Assert.That(image.sprite, Is.Null);
            Assert.That(imageChanges, Is.EqualTo(1), "A missing Sprite applies nothing.");
            image.SetSprite("step11_blue");
            Assert.That(imageChanges, Is.EqualTo(2));

            var texture = NewTexture("texture changes"); int textureChanges = 0;
            texture.OnChangeSprite += () => textureChanges++;
            yield return Done(texture.LoadSpriteAsync("Step11/Texture").AsTask());
            yield return Done(texture.LoadSpriteAsync("Step11/Texture").AsTask());
            Assert.That(textureChanges, Is.EqualTo(1));
            yield return Done(texture.LoadSpriteAsync(string.Empty).AsTask());
            Assert.That(textureChanges, Is.EqualTo(1));
        }

        // LD1
        [UnityTest]
        public IEnumerator LoadingSessionsShareOneScreenUntilTheLastIsDisposed()
        {
            int created = _instances.Created, released = _instances.Released;
            var firstTask = _manager.AcquireLoadingAsync("Step11/loading").AsTask();
            var secondTask = _manager.AcquireLoadingAsync("Step11/loading").AsTask();
            yield return Done(Task.WhenAll(firstTask, secondTask));
            var first = firstTask.Result; var second = secondTask.Result;
            Assert.That(_instances.Created - created, Is.EqualTo(1));
            Assert.That(first.IsActive, Is.True);
            first.Dispose(); first.Dispose();
            yield return null;
            Assert.That(_instances.Released, Is.EqualTo(released), "One owner's Dispose must not close another owner's loading.");
            Assert.That(second.IsActive, Is.True);
            second.Dispose();
            yield return Until(() => _instances.Released == released + 1);
            var again = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(again);
            Assert.That(_instances.Created - created, Is.EqualTo(2), "A closed loading must be created again.");
            again.Result.Dispose();
        }

        [UnityTest]
        public IEnumerator DifferentLoadingKeyWarnsAndSharesTheShownScreen()
        {
            var source = Addressables.LoadAssetAsync<GameObject>("Step11/loading"); _assets.Add(source); yield return Done(source.Task);
            var unused = Gate("Step11/other-loading", source.Result);
            int created = _instances.Created;
            var first = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(first);
            LogAssert.Expect(LogType.Warning, new Regex(@"\[UIManager\] Loading key differs"));
            var second = _manager.AcquireLoadingAsync("Step11/other-loading").AsTask(); yield return Done(second);
            Assert.That(_instances.Created - created, Is.EqualTo(1));
            Assert.That(unused.Loads, Is.Zero);
            first.Result.Dispose(); second.Result.Dispose();
        }

        [UnityTest]
        public IEnumerator HideLoadingUIForceClosesEverySession()
        {
            int released = _instances.Released;
            var first = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(first);
            var second = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(second);
            _manager.HideLoadingUI();
            Assert.That(first.Result.IsActive, Is.False);
            Assert.That(second.Result.IsActive, Is.False);
            yield return Until(() => _instances.Released == released + 1);
            first.Result.Report(.5f); first.Result.SetMessage("ignored"); first.Result.Dispose(); second.Result.Dispose();
            yield return null;
            Assert.That(_instances.Released, Is.EqualTo(released + 1));
        }

        [UnityTest]
        public IEnumerator ShowLoadingCallerKeepsTheScreenAfterSessionsEnd()
        {
            int released = _instances.Released;
            var shown = _manager.ShowLoadingUIAsync("Step11/loading").AsTask(); yield return Done(shown);
            var session = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(session);
            session.Result.Dispose();
            yield return null;
            Assert.That(_instances.Released, Is.EqualTo(released), "ShowLoadingUIAsync keeps its contract: only HideLoadingUI ends it.");
            _manager.HideLoadingUI();
            yield return Until(() => _instances.Released == released + 1);
        }

        [UnityTest]
        public IEnumerator LateShowLoadingFailureKeepsTheNewerShowOwnership()
        {
            var source = Addressables.LoadAssetAsync<GameObject>("Step11/loading"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/failing-loading", source.Result);
            LogAssert.ignoreFailingMessages = true;
            try
            {
                var stale = _manager.ShowLoadingUIAsync("Step11/failing-loading").AsTask();
                yield return Until(() => provider.Pending.Count == 1);
                _manager.HideLoadingUI();
                var shown = _manager.ShowLoadingUIAsync("Step11/loading").AsTask(); yield return Done(shown);
                foreach (var handle in provider.Pending.ToArray()) handle.Complete<GameObject>(null, false, new InvalidOperationException("synthetic loading failure"));
                provider.Pending.Clear();
                yield return Until(() => stale.IsCompleted);
                Assert.That(stale.IsFaulted, Is.True);
                yield return null;
                int released = _instances.Released;
                var session = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(session);
                session.Result.Dispose();
                yield return null;
                Assert.That(_instances.Released, Is.EqualTo(released), "The closed call's failure must not clear the newer call's ownership.");
                _manager.HideLoadingUI();
                yield return Until(() => _instances.Released == released + 1);
            }
            finally { LogAssert.ignoreFailingMessages = false; }
        }

        [UnityTest]
        public IEnumerator CanceledSessionReleasesOnlyItsOwnClaim()
        {
            var source = Addressables.LoadAssetAsync<GameObject>("Step11/loading"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/gated-loading", source.Result);
            int created = _instances.Created, released = _instances.Released;
            using var token = new CancellationTokenSource();
            var canceled = _manager.AcquireLoadingAsync("Step11/gated-loading", token.Token).AsTask();
            var kept = _manager.AcquireLoadingAsync("Step11/gated-loading").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            token.Cancel();
            yield return Until(() => canceled.IsCompleted);
            Assert.That(IsCanceled(canceled), Is.True);
            provider.Finish(); yield return Done(kept);
            Assert.That(kept.Result.IsActive, Is.True);
            Assert.That(_instances.Created - created, Is.EqualTo(1));
            Assert.That(_instances.Released, Is.EqualTo(released));
            kept.Result.Dispose();
            yield return Until(() => _instances.Released == released + 1);
        }

        [UnityTest]
        public IEnumerator CanceledOnlySessionReturnsTheLateInstance()
        {
            var source = Addressables.LoadAssetAsync<GameObject>("Step11/loading"); _assets.Add(source); yield return Done(source.Task);
            var provider = Gate("Step11/abandoned-loading", source.Result);
            int released = _instances.Released;
            using var token = new CancellationTokenSource();
            var canceled = _manager.AcquireLoadingAsync("Step11/abandoned-loading", token.Token).AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            token.Cancel();
            yield return Until(() => canceled.IsCompleted);
            provider.Finish();
            yield return Until(() => _instances.Released == released + 1);
            var next = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(next);
            Assert.That(next.Result.IsActive, Is.True, "The canceled claim must not block a later loading.");
            next.Result.Dispose();
        }

        [UnityTest]
        public IEnumerator SessionsReportTheLowestProgressAndAMessageToTheView()
        {
            var template = New("progress loading", typeof(RectTransform));
            template.AddComponent<UIFixtureProgressView>();
            var provider = Gate("Step11/progress-loading", template);
            var firstTask = _manager.AcquireLoadingAsync("Step11/progress-loading").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            provider.Finish(); yield return Done(firstTask);
            var secondTask = _manager.AcquireLoadingAsync("Step11/progress-loading").AsTask(); yield return Done(secondTask);
            var first = firstTask.Result; var second = secondTask.Result;
            var view = Get<GameObject>(_manager, "_currentLoadingUI").GetComponent<UIFixtureProgressView>();
            first.Report(.75f);
            Assert.That(view.Progress, Is.EqualTo(.75f).Within(.001f), "A session that has not reported does not pull the bar down.");
            second.Report(.25f);
            Assert.That(view.Progress, Is.EqualTo(.25f).Within(.001f));
            second.SetMessage("downloading");
            Assert.That(view.Message, Is.EqualTo("downloading"));
            second.Report(float.NaN);
            second.Report(7f);
            Assert.That(second.Progress, Is.EqualTo(1f));
            Assert.That(view.Progress, Is.EqualTo(.75f).Within(.001f));
            second.Dispose();
            first.Report(.5f);
            Assert.That(view.Progress, Is.EqualTo(.5f).Within(.001f));
            ((IProgress<float>)first).Report(.6f);
            Assert.That(view.Progress, Is.EqualTo(.6f).Within(.001f));
            first.Dispose();
        }

        [UnityTest]
        public IEnumerator SessionIgnoresALoadingPrefabWithoutAView()
        {
            var session = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(session);
            Assert.DoesNotThrow(() => { session.Result.Report(.5f); session.Result.SetMessage("no view"); });
            Assert.That(session.Result.Progress, Is.EqualTo(.5f));
            session.Result.Dispose();
        }

        [UnityTest]
        public IEnumerator AcquireRejectsAnEmptyKeyAndACanceledToken()
        {
            var empty = _manager.AcquireLoadingAsync(string.Empty).AsTask();
            yield return Until(() => empty.IsCompleted);
            Assert.That(empty.IsFaulted, Is.True);
            using var token = new CancellationTokenSource(); token.Cancel();
            var canceled = _manager.AcquireLoadingAsync("Step11/loading", token.Token).AsTask();
            yield return Until(() => canceled.IsCompleted);
            Assert.That(IsCanceled(canceled), Is.True);
        }

        [UnityTest]
        public IEnumerator ManagerReinitializationClosesLoadingSessions()
        {
            var session = _manager.AcquireLoadingAsync("Step11/loading").AsTask(); yield return Done(session);
            _manager.Init();
            Assert.That(session.Result.IsActive, Is.False);
            session.Result.Dispose();
            yield return null;
        }
    }
}
