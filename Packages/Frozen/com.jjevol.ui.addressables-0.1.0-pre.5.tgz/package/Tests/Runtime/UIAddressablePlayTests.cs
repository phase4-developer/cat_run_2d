using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using jjevol.Audio;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Object=UnityEngine.Object;

namespace jjevol.UI.Tests
{
    [PrebuildSetup("jjevol.UI.Tests.UIFixtureSetup"),PostBuildCleanup("jjevol.UI.Tests.UIFixtureSetup")]
    public sealed partial class UIAddressablePlayTests
    {
        private sealed class Instances : IInstanceProvider
        {
            public readonly IInstanceProvider Inner;
            public readonly HashSet<GameObject> Live=new();
            public int Created,Released;
            public Instances(IInstanceProvider inner)=>Inner=inner;
            public GameObject ProvideInstance(ResourceManager rm, AsyncOperationHandle<GameObject> handle, InstantiationParameters parameters)
            { var instance=Inner.ProvideInstance(rm,handle,parameters); Live.Add(instance); Created++; return instance; }
            public void ReleaseInstance(ResourceManager rm,GameObject instance)
            { Live.Remove(instance); Released++; Inner.ReleaseInstance(rm,instance); }
        }
        private sealed class GateProvider : ResourceProviderBase
        {
            private readonly Object _asset;
            private readonly string _id="step11-gate-"+Guid.NewGuid().ToString("N");
            public override string ProviderId=>_id;
            public readonly List<ProvideHandle> Pending=new();
            public int Loads,Releases;
            public GateProvider(Object asset)=>_asset=asset;
            public override void Provide(ProvideHandle handle){Loads++;Pending.Add(handle);}
            public void Finish(Object asset=null){foreach(var handle in Pending.ToArray())handle.Complete(asset ? asset : _asset,true,null);Pending.Clear();}
            public override void Release(IResourceLocation location,object asset)=>Releases++;
        }
        private readonly List<GameObject> _objects=new();
        private readonly List<GateProvider> _gates=new();
        private readonly List<AsyncOperationHandle> _assets=new();
        private readonly List<IResourceLocator> _locators=new();
        private Instances _instances;
        private UIManager _manager;
        private AsyncOperationHandle<GameObject> _managerHandle;

        [UnitySetUp]
        public IEnumerator Setup()
        {
            UIFixtureHud.OnInit=null;
            UIManager.applicationIsQuitting=false; AddressablesManager.applicationIsQuitting=false;
            var init=Addressables.InitializeAsync(); yield return Done(init.Task);
            _instances=new Instances(Addressables.InstanceProvider); SetInstanceProvider(_instances);
            _=AddressablesManager.Instance;
            _managerHandle=Addressables.InstantiateAsync("Step11/Manager"); yield return Done(_managerHandle.Task);
            _manager=_managerHandle.Result.GetComponent<UIManager>();
            Assert.That(_manager.screenManager,Is.Not.Null);
        }
        [UnityTearDown]
        public IEnumerator Cleanup()
        {
            UIFixtureHud.OnInit=null;
            foreach(var gate in _gates) gate.Finish(); yield return null; yield return null;
            foreach(var go in _instances.Live.ToArray()) Addressables.ReleaseInstance(go);
            foreach(var go in _objects)if(go)Object.Destroy(go); _objects.Clear();
            if(AddressablesManager.HasInstance) Object.Destroy(AddressablesManager.Instance.gameObject);
            yield return null; yield return null; yield return null;
            foreach(var asset in _assets)if(asset.IsValid())Addressables.Release(asset); _assets.Clear();
            foreach(var locator in _locators) Addressables.RemoveResourceLocator(locator); _locators.Clear();
            foreach(var gate in _gates) Addressables.ResourceManager.ResourceProviders.Remove(gate); _gates.Clear();
            SetInstanceProvider(_instances.Inner);
            UINavigationOptions.ScreenPolicy=null; UINavigationOptions.PopupPolicy=null; UINavigationOptions.ConfigureTransitions=null;
        }
        private static IEnumerator Done(Task task)
        {
            float end=Time.realtimeSinceStartup+8;
            while(!task.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;
            Assert.That(task.IsCompleted,Is.True,"SDK operation timed out.");
            if(task.IsFaulted)throw task.Exception.InnerException;
        }
        private static void SetInstanceProvider(IInstanceProvider provider)
        {
            // Test-only instrumentation of the verified SDK 4.0.1 implementation; original provider still creates/releases every instance.
            var implementation=typeof(Addressables).GetProperty("s_Addressables",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);
            implementation.GetType().GetProperty("InstanceProvider").SetValue(implementation,provider);
        }
        private static IEnumerator Until(Func<bool> condition)
        { float end=Time.realtimeSinceStartup+8; while(!condition()&&Time.realtimeSinceStartup<end)yield return null; Assert.That(condition(),Is.True,"Condition timed out."); }
        private GameObject New(string name,params Type[] components){var go=new GameObject(name,components);_objects.Add(go);return go;}
        private static void Set(object target,string field,object value)=>target.GetType().GetField(field,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(target,value);
        private GateProvider Gate(string key,Object asset)
        {
            var provider=new GateProvider(asset);_gates.Add(provider);Addressables.ResourceManager.ResourceProviders.Add(provider);
            var locator=new ResourceLocationMap("step11-locator-"+Guid.NewGuid().ToString("N"));
            locator.Add(key,new ResourceLocationBase(key,key,provider.ProviderId,asset.GetType())); Addressables.AddResourceLocator(locator);_locators.Add(locator);return provider;
        }
        private sealed class ScreenData : IScreenData { }

        [UnityTest]
        public IEnumerator RealSdkScreenHistoryPopupCloseAndHudDataWork()
        {
            var firstData=new ScreenData();
            var first=_manager.screenManager.SpawnUIScreenAsync("IntroScreen",firstData).AsTask();yield return Done(first);
            Assert.That(first.Result.IsVisible,Is.True);
            var next=_manager.screenManager.SpawnUIScreenAsync("LobbyScreen",new ScreenData()).AsTask();yield return Done(next);
            Assert.That(first.Result.IsVisible,Is.False);
            var back=_manager.screenManager.PrevUIScreen().AsTask();yield return Done(back);
            Assert.That(back.Result,Is.SameAs(first.Result));Assert.That(back.Result.screenData,Is.SameAs(firstData));
            var hud=_manager.hudManager.CachingHudAsync(new List<string>{"MainMenuHud"}).AsTask();yield return Done(hud);
            var parameters=new List<UIHudParameter>{new(){key="fixture",value="7"}};
            _manager.hudManager.ShowHuds(new List<UIHudRequest>{new(){hudType="MainMenuHud",parameters=parameters}},back.Result);
            var actual=(UIFixtureHud)_manager.hudManager.hudPool["MainMenuHud"];
            Assert.That(actual.IsVisible,Is.True);Assert.That(actual.LastScreenData,Is.SameAs(firstData));Assert.That(actual.LastParameters,Is.SameAs(parameters));
            var popup=_manager.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);
            var closed=popup.Result.CloseWait().AsTask();popup.Result.ClosePopup();yield return Done(closed);
            Assert.That(closed.Result,Is.True);Assert.That(_manager.popupManager.ActivePopups,Is.Empty);
        }

        [UnityTest]
        public IEnumerator ParallelScreenCachingMustNotInstantiateOrPoolTheSameScreenTwice()
        {
            int before=_instances.Created;
            var types=new List<string>{"IntroScreen"};
            var a=_manager.screenManager.CachingScreenAsync(types).AsTask();var b=_manager.screenManager.CachingScreenAsync(types).AsTask();
            yield return Done(Task.WhenAll(a,b));
            Assert.That(_instances.Created-before,Is.EqualTo(1));Assert.That(_manager.screenManager.screenPool.Count,Is.EqualTo(1));
        }

        [UnityTest]
        public IEnumerator DestroyManagerReturnsEveryDirectSdkInstance()
        {
            yield return Done(_manager.screenManager.SpawnUIScreenAsync("IntroScreen").AsTask());
            yield return Done(_manager.SpawnUIPopupAsync("YesNoPopup").AsTask());
            yield return Done(_manager.hudManager.CachingHudAsync(new List<string>{"MainMenuHud"}).AsTask());
            yield return Done(_manager.ShowLoadingUIAsync("Step11/loading").AsTask());
            Addressables.ReleaseInstance(_managerHandle);
            yield return null;yield return null;yield return null;
            Assert.That(_instances.Released,Is.EqualTo(_instances.Created),"Destroyed children still require their own SDK instance handle return.");
        }

        [UnityTest]
        public IEnumerator RuntimeAtlasSpritesAreDestroyedWhenChangedAndReleased()
        {
            var go=New("atlas image",typeof(RectTransform));var image=go.AddComponent<AddressableImage>();
            image.SetAtlasSprite("Step11/Atlas","step11_red");yield return Until(()=>image.sprite!=null);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Atlas"),Is.EqualTo(1));
            Sprite old=image.sprite;image.SetSprite("step11_blue");yield return null;
            Assert.That(image.sprite,Is.Not.Null);Assert.That(old==null,Is.True,"SpriteAtlas.GetSprite clones must be destroyed, not just overwritten.");
            Sprite current=image.sprite;Object.Destroy(go);yield return null;yield return null;
            Assert.That(current==null,Is.True);Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Atlas"),Is.Zero);
        }

        [UnityTest]
        public IEnumerator ClearingAHiddenTextureAndReloadingTheSameKeyDoesNotAddAReference()
        {
            var go=New("texture image",typeof(RectTransform));var image=go.AddComponent<AddressableTexture>();
            image.spriteKey="Step11/Texture";yield return Until(()=>image.sprite!=null);
            Sprite old=image.sprite;Set(image,"m_ClearSpriteOnDisable",true);
            go.SetActive(false);go.SetActive(true);yield return Until(()=>image.sprite!=null);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Texture"),Is.EqualTo(1));
            Assert.That(old==null||old==image.sprite,Is.True,"Replaced runtime Sprite must be returned.");
            Sprite current=image.sprite;Object.Destroy(go);yield return null;yield return null;
            Assert.That(current==null,Is.True);Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Texture"),Is.Zero);
        }

        [UnityTest]
        public IEnumerator TextureAndSingleSpriteSourcesUseTheActualCatalog()
        {
            var image=New("single source",typeof(RectTransform)).AddComponent<AddressableTexture>();
            yield return Done(image.LoadSpriteAsync("Step11/Texture").AsTask());Assert.That(image.sprite,Is.Not.Null);
            yield return Done(image.LoadSpriteAsync("Step11/Sprite").AsTask());Assert.That(image.sprite,Is.Not.Null);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Texture"),Is.Zero);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Sprite"),Is.EqualTo(1));
            yield return Done(image.LoadSpriteAsync("Step11/DirectSprite").AsTask());Assert.That(image.sprite,Is.Not.Null);
            Assert.That(typeof(AddressableTexture).GetField("_runtimeCreatedSprite",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(image),Is.Null,"A supplied Sprite must not be treated as a texture-created Sprite.");
        }

        [UnityTest]
        public IEnumerator HideBeforeLoadingCompletesDoesNotRetainAnUnwantedLoadingInstance()
        {
            var source=Addressables.LoadAssetAsync<GameObject>("Step11/loading");_assets.Add(source);yield return Done(source.Task);
            var provider=Gate("Step11/delayed-loading",source.Result);
            var view=New("loading view",typeof(RectTransform)).AddComponent<AddressableLoadingView>();
            Set(view,"m_KeepInstance",false);view.loadingPrefabKey="Step11/delayed-loading";
            var show=view.ShowAsync().AsTask();view.Hide();provider.Finish();yield return Done(show);yield return null;yield return null;
            Assert.That(view.IsShowing,Is.False);Assert.That(view.GetComponentsInChildren<RectTransform>(true).Length,Is.EqualTo(1));
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/delayed-loading"),Is.Zero);Assert.That(provider.Releases,Is.EqualTo(provider.Loads));
        }

        [UnityTest]
        public IEnumerator ButtonLockRoutesNormalSoftAndHardLocksWithoutDuplicateClicks()
        {
            var go=New("actual button",typeof(RectTransform),typeof(Image),typeof(Button));var buttonLock=go.AddComponent<UIButtonLock>();var sound=go.AddComponent<UIButtonSound>();
            Set(sound,"soundKey","step11/button");Set(buttonLock,"lockedSoundKey","step11/locked");
            int normal=0,locked=0,audio=0;
            go.GetComponent<Button>().onClick.AddListener(()=>normal++);buttonLock.onLockedClick.AddListener(()=>locked++);
            void Heard(AudioEvents.PlayUI value)=>audio++;
            AudioEvents.UiRequested+=Heard;
            var events=New("event system",typeof(EventSystem)).GetComponent<EventSystem>();
            var pointer=new PointerEventData(events){button=PointerEventData.InputButton.Left};
            void Click()=>ExecuteEvents.Execute(go,pointer,ExecuteEvents.pointerClickHandler);
            try
            {
                for(int i=0;i<6;i++){go.SetActive(false);go.SetActive(true);}
                Click();Assert.That(normal,Is.EqualTo(1));
                buttonLock.SetState(UIButtonLockState.SoftLock);Click();Assert.That(locked,Is.EqualTo(1));
                buttonLock.SetState(UIButtonLockState.HardLock);Click();Assert.That(locked,Is.EqualTo(1));Assert.That(normal,Is.EqualTo(1));
                Assert.That(audio,Is.EqualTo(2));
            }
            finally{AudioEvents.UiRequested-=Heard;}
            yield return null;
        }

        [UnityTest]
        public IEnumerator DuplicatePopupAndCloseWaitObserversShareOneResultAndReleaseOnce()
        {
            var first=_manager.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(first);
            var repeated=_manager.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(repeated);
            Assert.That(repeated.Result,Is.SameAs(first.Result));
            var a=first.Result.CloseWait().AsTask();var b=first.Result.CloseWait().AsTask();int before=_instances.Released;
            first.Result.ClosePopup();first.Result.ClosePopup();yield return null;yield return null;
            Assert.That(a.IsCompleted,Is.True,"The first CloseWait observer must not be orphaned by the second.");
            Assert.That(b.IsCompleted,Is.True);Assert.That(a.Result&&b.Result,Is.True);Assert.That(_instances.Released-before,Is.EqualTo(1));
        }

        [UnityTest]
        public IEnumerator PendingScreenSceneUnloadReleasesTheLateSdkInstance()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIScreen_IntroScreen");_assets.Add(prefab);yield return Done(prefab.Task);
            var provider=Gate("UIScreen_77701",prefab.Result);
            var scene=SceneManager.CreateScene("Step11PendingScene");var root=New("scene UI root",typeof(RectTransform));SceneManager.MoveGameObjectToScene(root,scene);
            var screens=new UIScreenManager(root.transform);var pending=screens.SpawnUIScreenAsync("77701").AsTask();
            yield return Until(()=>provider.Pending.Count==1);yield return SceneManager.UnloadSceneAsync(scene);provider.Finish();yield return Done(pending);
            yield return null;yield return null;Assert.That(pending.Result,Is.Null);Assert.That(provider.Releases,Is.EqualTo(provider.Loads));screens.Dispose();
        }

        [UnityTest]
        public IEnumerator ForceCloseCancelsInflightAndQueuedPopupsBeforeLateCompletion()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIPopup_YesNoPopup");_assets.Add(prefab);yield return Done(prefab.Task);
            var provider=Gate("UIPopup_77702",prefab.Result);
            var first=_manager.SpawnUIPopupAsync("77702").SuppressCancellationThrow().AsTask();yield return Until(()=>provider.Pending.Count==1);
            var queued=_manager.SpawnUIPopupAsync("YesNoPopup").SuppressCancellationThrow().AsTask();_manager.popupManager.ForceCloseAllPopups();provider.Finish();
            yield return Until(()=>first.IsCompleted&&queued.IsCompleted);yield return null;yield return null;
            Assert.That(first.Result.IsCanceled,Is.True,"The API's UniTask must report in-flight cancellation.");Assert.That(queued.Result.IsCanceled,Is.True,"The API's UniTask must report queued cancellation.");Assert.That(_manager.popupManager.ActivePopups,Is.Empty);
            Assert.That(_manager.blockerCounter.IsEnable(),Is.False);Assert.That(provider.Releases,Is.EqualTo(provider.Loads));
        }

        [UnityTest]
        public IEnumerator DisableEnableManagerStartsNewManagersWithoutAdoptingRetiredScreens()
        {
            var first=_manager.screenManager.SpawnUIScreenAsync("IntroScreen").AsTask();yield return Done(first);var retired=first.Result;
            _manager.gameObject.SetActive(false);_manager.gameObject.SetActive(true);
            var next=_manager.screenManager.SpawnUIScreenAsync("IntroScreen").AsTask();yield return Done(next);yield return null;
            Assert.That(retired==null,Is.True);Assert.That(next.Result,Is.Not.Null);Assert.That(next.Result.IsVisible,Is.True);
            Assert.That(_manager.screenManager.CurrentScreen,Is.SameAs(next.Result));
        }

        [UnityTest]
        public IEnumerator ParallelHudAndLoadingRequestsShareTheirOwnSdkInstance()
        {
            int before=_instances.Created;
            var a=_manager.hudManager.CachingHudAsync(new(){"MainMenuHud"}).AsTask();var b=_manager.hudManager.CachingHudAsync(new(){"MainMenuHud"}).AsTask();
            yield return Done(Task.WhenAll(a,b));Assert.That(_instances.Created-before,Is.EqualTo(1));
            before=_instances.Created;var x=_manager.ShowLoadingUIAsync("Step11/loading").AsTask();var y=_manager.ShowLoadingUIAsync("Step11/loading").AsTask();
            yield return Done(Task.WhenAll(x,y));Assert.That(x.Result,Is.SameAs(y.Result));Assert.That(_instances.Created-before,Is.EqualTo(1));_manager.HideLoadingUI();_manager.HideLoadingUI();
        }

        [UnityTest]
        public IEnumerator HudMissingComponentReturnsItsSdkInstanceAndCanRetry()
        {
            var invalid=Addressables.LoadAssetAsync<GameObject>("Step11/loading");_assets.Add(invalid);yield return Done(invalid.Task);
            var valid=Addressables.LoadAssetAsync<GameObject>("UIHud_MainMenuHud");_assets.Add(valid);yield return Done(valid.Task);
            var type="77801";
            var provider=Gate("UIHud_77801",invalid.Result);
            var root=New("missing component HUD root",typeof(RectTransform),typeof(Canvas));
            var manager=new UIHudManager(root.transform,90,140);
            int created=_instances.Created,released=_instances.Released;
            try
            {
                LogAssert.Expect(LogType.Warning,"[UIHudManager] Load Failed: UIHud_77801 / The HUD prefab must contain UIHudBase.");
                var failed=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>provider.Pending.Count==1);
                provider.Finish();yield return Done(failed);
                yield return Until(()=>_instances.Released-released==1&&provider.Releases==1&&root.transform.childCount==0);
                Assert.That(manager.hudPool,Is.Empty);Assert.That(root.transform.childCount,Is.Zero);

                var retry=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>provider.Pending.Count==1);
                provider.Finish(valid.Result);yield return Done(retry);
                var hud=(UIFixtureHud)manager.hudPool[type];Assert.That(hud.IsVisible,Is.False);Assert.That(hud.InitCount,Is.EqualTo(1));
                yield return Done(manager.CachingHudAsync(new(){type}).AsTask());
                Assert.That(manager.hudPool[type],Is.SameAs(hud));Assert.That(hud.InitCount,Is.EqualTo(1));
                Assert.That(_instances.Created-created,Is.EqualTo(2));
                manager.Dispose();manager.Dispose();
                yield return Until(()=>_instances.Released-released==2&&provider.Releases==provider.Loads&&root.transform.childCount==0);
                Assert.That(root.transform.childCount,Is.Zero);
            }
            finally{manager.Dispose();}
        }

        [UnityTest]
        public IEnumerator HudInitExceptionAndCancellationReturnEveryInstanceBeforeSuccessfulRetry()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIHud_MainMenuHud");_assets.Add(prefab);yield return Done(prefab.Task);
            var type="77802";
            var provider=Gate("UIHud_77802",prefab.Result);
            var root=New("throwing HUD root",typeof(RectTransform),typeof(Canvas));
            var manager=new UIHudManager(root.transform,90,140);
            int created=_instances.Created,released=_instances.Released,failures=0;
            try
            {
                foreach(var failure in new Exception[]{new InvalidOperationException("synthetic HUD Init failure"),new OperationCanceledException("synthetic HUD Init cancellation")})
                {
                    UIFixtureHud.OnInit=_=>throw failure;
                    LogAssert.Expect(LogType.Warning,"[UIHudManager] Load Failed: UIHud_77802 / "+failure.Message);
                    var failed=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>provider.Pending.Count==1);
                    provider.Finish();yield return Done(failed);failures++;
                    yield return Until(()=>_instances.Released-released==failures&&provider.Releases==failures&&root.transform.childCount==0);
                    Assert.That(failed.IsCanceled,Is.False,"HUD initialization failures retain the warning-and-completion contract.");
                    Assert.That(manager.hudPool,Is.Empty);Assert.That(root.transform.childCount,Is.Zero);
                }
                UIFixtureHud.OnInit=null;
                var retry=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>provider.Pending.Count==1);
                provider.Finish();yield return Done(retry);
                Assert.That(((UIFixtureHud)manager.hudPool[type]).InitCount,Is.EqualTo(1));
                manager.Dispose();
                yield return Until(()=>_instances.Released-released==3&&provider.Releases==provider.Loads&&root.transform.childCount==0);
                Assert.That(_instances.Created-created,Is.EqualTo(3));
            }
            finally{UIFixtureHud.OnInit=null;manager.Dispose();}
        }

        [UnityTest]
        public IEnumerator HudInvalidatedInsideInitIsNotPublishedAfterTrimOrDispose()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIHud_MainMenuHud");_assets.Add(prefab);yield return Done(prefab.Task);
            for(int scenario=0;scenario<2;scenario++)
            {
                var type=(77803+scenario).ToString();
                var provider=Gate("UIHud_"+type,prefab.Result);
                var root=New("reentrant HUD Init root",typeof(RectTransform),typeof(Canvas));
                var manager=new UIHudManager(root.transform,90,140);
                int created=_instances.Created,released=_instances.Released;
                try
                {
                    UIFixtureHud.OnInit=_=>{if(scenario==0)manager.ReleaseUnusedHuds(null);else manager.Dispose();};
                    var pending=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>provider.Pending.Count==1);
                    provider.Finish();yield return Done(pending);UIFixtureHud.OnInit=null;
                    yield return Until(()=>_instances.Released-released==1&&provider.Releases==provider.Loads&&root.transform.childCount==0);
                    Assert.That(manager.hudPool,Is.Empty);Assert.That(root.transform.childCount,Is.Zero);
                    manager.Dispose();yield return null;yield return null;
                    Assert.That(_instances.Created-created,Is.EqualTo(1));Assert.That(_instances.Released-released,Is.EqualTo(1));
                }
                finally{UIFixtureHud.OnInit=null;manager.Dispose();}
            }
        }

        [UnityTest]
        public IEnumerator HudInvalidatedByHideCallbackIsReturnedWithoutEnteringThePool()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIHud_MainMenuHud");_assets.Add(prefab);yield return Done(prefab.Task);
            var type="77805";
            var provider=Gate("UIHud_77805",prefab.Result);
            var root=New("reentrant HUD Hide root",typeof(RectTransform),typeof(Canvas));
            var manager=new UIHudManager(root.transform,90,140);
            int created=_instances.Created,released=_instances.Released;
            try
            {
                UIFixtureHud.OnInit=hud=>hud.onHide.AddListener(_=>manager.ReleaseUnusedHuds(null));
                var pending=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>provider.Pending.Count==1);
                provider.Finish();yield return Done(pending);UIFixtureHud.OnInit=null;
                yield return Until(()=>_instances.Released-released==1&&provider.Releases==provider.Loads&&root.transform.childCount==0);
                Assert.That(manager.hudPool,Is.Empty);Assert.That(root.transform.childCount,Is.Zero);
                manager.Dispose();yield return null;yield return null;
                Assert.That(_instances.Created-created,Is.EqualTo(1));Assert.That(_instances.Released-released,Is.EqualTo(1));
            }
            finally{UIFixtureHud.OnInit=null;manager.Dispose();}
        }

        [UnityTest]
        public IEnumerator RetiredHudWaiterCannotRemoveAReplacementPendingLoad()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIHud_MainMenuHud");_assets.Add(prefab);yield return Done(prefab.Task);
            var type="77806";
            var firstProvider=Gate("UIHud_77806",prefab.Result);
            var root=New("overlapping HUD generations",typeof(RectTransform),typeof(Canvas));
            var manager=new UIHudManager(root.transform,90,140);
            int created=_instances.Created,released=_instances.Released;
            try
            {
                var retired=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>firstProvider.Pending.Count==1);
                manager.ReleaseUnusedHuds(null);
                Addressables.RemoveResourceLocator(_locators[^1]);
                var nextProvider=Gate("UIHud_77806",prefab.Result);
                var next=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>nextProvider.Pending.Count==1);
                firstProvider.Finish();yield return Done(retired);
                yield return Until(()=>_instances.Released-released==1&&firstProvider.Releases==1&&root.transform.childCount==0);
                Assert.That(manager.hudPool,Is.Empty);
                var shared=manager.CachingHudAsync(new(){type}).AsTask();
                nextProvider.Finish();yield return Done(Task.WhenAll(next,shared));
                Assert.That(manager.hudPool.Count,Is.EqualTo(1));Assert.That(((UIFixtureHud)manager.hudPool[type]).InitCount,Is.EqualTo(1));
                Assert.That(_instances.Created-created,Is.EqualTo(2),"Only the retired request and the shared replacement may instantiate.");
                manager.ReleaseUnusedHuds(null);manager.Dispose();
                yield return Until(()=>_instances.Released-released==2&&nextProvider.Releases==nextProvider.Loads&&root.transform.childCount==0);
                Assert.That(root.transform.childCount,Is.Zero);
            }
            finally{manager.Dispose();}
        }

        [UnityTest]
        public IEnumerator HudDisposedDuringLoadReturnsTheLateSdkInstanceOnlyOnce()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIHud_MainMenuHud");_assets.Add(prefab);yield return Done(prefab.Task);
            var type="77807";
            var provider=Gate("UIHud_77807",prefab.Result);
            var root=New("disposed pending HUD root",typeof(RectTransform),typeof(Canvas));
            var manager=new UIHudManager(root.transform,90,140);
            int created=_instances.Created,released=_instances.Released;
            try
            {
                var pending=manager.CachingHudAsync(new(){type}).AsTask();yield return Until(()=>provider.Pending.Count==1);
                manager.Dispose();manager.Dispose();provider.Finish();yield return Done(pending);
                yield return Until(()=>_instances.Released-released==1&&provider.Releases==provider.Loads&&root.transform.childCount==0);
                yield return Done(manager.CachingHudAsync(new(){type}).AsTask());yield return null;yield return null;
                Assert.That(manager.hudPool,Is.Empty);Assert.That(root.transform.childCount,Is.Zero);
                Assert.That(_instances.Created-created,Is.EqualTo(1));Assert.That(_instances.Released-released,Is.EqualTo(1));
            }
            finally{manager.Dispose();}
        }

        [UnityTest]
        public IEnumerator HudFailureCanRetryImmediatelyInsideItsAwaitContinuation()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIHud_MainMenuHud");_assets.Add(prefab);yield return Done(prefab.Task);
            var type="77808";
            var failedProvider=Gate("UIHud_77808",prefab.Result);
            GateProvider retryProvider=null;
            var root=New("immediate HUD retry root",typeof(RectTransform),typeof(Canvas));
            var manager=new UIHudManager(root.transform,90,140);
            int created=_instances.Created,released=_instances.Released;
            async UniTask CacheAndRetry()
            {
                await manager.CachingHudAsync(new(){type});
                UIFixtureHud.OnInit=null;
                Addressables.RemoveResourceLocator(_locators[^1]);
                retryProvider=Gate("UIHud_77808",prefab.Result);
                await manager.CachingHudAsync(new(){type});
            }
            try
            {
                UIFixtureHud.OnInit=_=>throw new InvalidOperationException("synthetic immediate HUD retry failure");
                LogAssert.Expect(LogType.Warning,"[UIHudManager] Load Failed: UIHud_77808 / synthetic immediate HUD retry failure");
                var chained=CacheAndRetry().AsTask();yield return Until(()=>failedProvider.Pending.Count==1);
                failedProvider.Finish();yield return Until(()=>retryProvider!=null);
                Assert.That(chained.IsCompleted,Is.False,"The retry must start a fresh load rather than observe the completed failed request.");
                yield return Until(()=>retryProvider.Pending.Count==1);
                retryProvider.Finish();yield return Done(chained);
                Assert.That(manager.hudPool.Count,Is.EqualTo(1));
                Assert.That(((UIFixtureHud)manager.hudPool[type]).InitCount,Is.EqualTo(1));
                Assert.That(_instances.Created-created,Is.EqualTo(2));
                manager.Dispose();
                yield return Until(()=>_instances.Released-released==2&&failedProvider.Releases==failedProvider.Loads&&retryProvider.Releases==retryProvider.Loads&&root.transform.childCount==0);
            }
            finally{UIFixtureHud.OnInit=null;manager.Dispose();}
        }

        [UnityTest]
        public IEnumerator RapidTextureChangeAndDestroyDuringLoadReturnEveryAcquisition()
        {
            var source=Addressables.LoadAssetAsync<Texture2D>("Step11/Texture");_assets.Add(source);yield return Done(source.Task);
            var provider=Gate("Step11/delayed-texture",source.Result);
            var image=New("rapid image",typeof(RectTransform)).AddComponent<AddressableTexture>();var old=image.LoadSpriteAsync("Step11/delayed-texture").AsTask();
            yield return Until(()=>provider.Pending.Count==1);image.spriteKey="Step11/Texture";yield return Until(()=>image.sprite!=null);
            Sprite shown=image.sprite;provider.Finish();yield return Done(old);yield return null;
            Assert.That(image.sprite,Is.SameAs(shown));Assert.That(AddressablesManager.Instance.GetRefCount("Step11/delayed-texture"),Is.Zero);
            var pending=image.LoadSpriteAsync("Step11/delayed-texture").AsTask();yield return Until(()=>provider.Pending.Count==1);Object.Destroy(image.gameObject);yield return null;provider.Finish();yield return Done(pending);yield return null;
            Assert.That(provider.Releases,Is.EqualTo(provider.Loads));Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Texture"),Is.Zero);
        }

        [UnityTest]
        public IEnumerator OldImageLeaseCannotReleaseAnAcquisitionFromAReplacementManager()
        {
            var image=New("old manager image",typeof(RectTransform)).AddComponent<AddressableTexture>();yield return Done(image.LoadSpriteAsync("Step11/Texture").AsTask());
            Object.Destroy(AddressablesManager.Instance.gameObject);yield return null;_=AddressablesManager.Instance;
            var fresh=AddressablesManager.LoadAssetAsync<Texture2D>("Step11/Texture").AsTask();yield return Done(fresh);
            Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Texture"),Is.EqualTo(1));
            Object.Destroy(image.gameObject);yield return null;yield return null;Assert.That(AddressablesManager.Instance.GetRefCount("Step11/Texture"),Is.EqualTo(1));
            AddressablesManager.ReleaseAsset("Step11/Texture");
        }

        [UnityTest]
        public IEnumerator LoadingViewPoolHonorsDelayedCancelReuseAndDispose()
        {
            var prefab=New("local loading template",typeof(RectTransform)).AddComponent<AddressableLoadingView>();
            var pool=New("loading pool",typeof(RectTransform));var target=New("target",typeof(RectTransform)).GetComponent<RectTransform>();
            var service=new AddressableLoadingViewService(prefab,pool.transform,1,.03f);
            try
            {
                var early=service.Acquire(target);early.Release();early.Release();yield return new WaitForSecondsRealtime(.06f);
                Assert.That(target.childCount,Is.Zero);
                var first=service.Acquire(target);yield return new WaitForSecondsRealtime(.06f);Assert.That(target.childCount,Is.EqualTo(1));
                first.Release();yield return null;yield return null;Assert.That(target.childCount,Is.Zero);
                var second=service.Acquire(target);yield return new WaitForSecondsRealtime(.06f);Assert.That(target.childCount,Is.EqualTo(1));
                service.Dispose();second.Dispose();yield return null;yield return null;Assert.That(target.childCount,Is.Zero);
            }
            finally{service.Dispose();}
        }

        [UnityTest]
        public IEnumerator FiftyActualPopupCreateCloseCyclesBalanceEveryInstance()
        {
            int created=_instances.Created,released=_instances.Released;
            for(int i=0;i<50;i++)
            {
                var popup=_manager.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);
                var wait=popup.Result.CloseWait().AsTask();popup.Result.ClosePopup();yield return Done(wait);yield return null;
                Assert.That(_manager.popupManager.ActivePopups,Is.Empty);
            }
            yield return null;yield return null;
            Assert.That(_instances.Created-created,Is.EqualTo(50));Assert.That(_instances.Released-released,Is.EqualTo(50));
        }
    }
}
