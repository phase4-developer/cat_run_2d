using UnityEngine;
using UnityEngine.Events;

namespace jjevol.UI.Tests
{
    /// <summary>Hide가 시험에서 끝낼 때까지 진행 중으로 남는 전환.</summary>
    public sealed class UIFixtureTransition : MonoBehaviour, IUITransition
    {
        public bool IsTransitioning { get; private set; }
        public CanvasGroup TargetCanvasGroup => GetComponent<CanvasGroup>();
        public UnityEvent ShowCompleted { get; } = new();
        public UnityEvent HideCompleted { get; } = new();
        public void OnWindowAdded() => ShowCompleted.Invoke();
        public void OnWindowRemove() => IsTransitioning = true;
        public void ForceStopTransition() => IsTransitioning = false;
        public void FinishHide()
        {
            IsTransitioning = false;
            HideCompleted.Invoke();
        }
    }

    public sealed class UIFixtureProgressView : MonoBehaviour, IUILoadingProgressView
    {
        public float Progress = -1f;
        public string Message;
        public void SetProgress(float progress01) => Progress = progress01;
        public void SetMessage(string message) => Message = message;
    }
}
