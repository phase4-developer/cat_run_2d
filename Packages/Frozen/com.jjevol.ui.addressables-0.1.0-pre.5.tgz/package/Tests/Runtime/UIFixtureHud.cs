using System;
using System.Collections.Generic;
namespace jjevol.UI.Tests
{
    public sealed class UIFixtureHud : UIHudBase
    {
        public static Action<UIFixtureHud> OnInit;
        public int InitCount, DrawCount;
        public IScreenData LastScreenData;
        public IPopupData LastPopupData;
        public List<UIHudParameter> LastParameters;
        public override void Init() { InitCount++; OnInit?.Invoke(this); }
        protected override void _DrawContents() => DrawCount++;
        public override void ApplyInspectorParams(List<UIHudParameter> parameters) => LastParameters=parameters;
        public override void ApplyRuntimeData(IScreenData screenData, IPopupData popupData) { LastScreenData=screenData; LastPopupData=popupData; }
    }
}
