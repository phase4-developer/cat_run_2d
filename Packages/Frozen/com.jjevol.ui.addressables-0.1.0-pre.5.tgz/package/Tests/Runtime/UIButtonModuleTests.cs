using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using jjevol.Audio;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace jjevol.UI.Tests
{
    public sealed class UIButtonModuleTests
    {
        private const float ShortDelay=.02f;
        private readonly List<GameObject> _objects=new();
        private EventSystem _events;

        [SetUp]public void Setup()=>_events=New("event system",typeof(EventSystem)).GetComponent<EventSystem>();
        [UnityTearDown]public IEnumerator Cleanup(){foreach(var go in _objects)if(go)Object.Destroy(go);_objects.Clear();yield return null;}

        private GameObject New(string name,params Type[] components){var go=new GameObject(name,components);_objects.Add(go);return go;}
        private Button NewButton(string name)=>New(name,typeof(RectTransform),typeof(Image),typeof(Button)).GetComponent<Button>();
        private PointerEventData Pointer(PointerEventData.InputButton button=PointerEventData.InputButton.Left)=>new(_events){button=button};
        private static void Click(GameObject target,PointerEventData pointer)=>ExecuteEvents.Execute(target,pointer,ExecuteEvents.pointerClickHandler);
        private static void Set(object target,string field,object value)=>target.GetType().GetField(field,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(target,value);
        private static IEnumerator Until(Func<bool> condition)
        { float end=Time.realtimeSinceStartup+8; while(!condition()&&Time.realtimeSinceStartup<end)yield return null; Assert.That(condition(),Is.True,"Condition timed out."); }
        private static IEnumerator Wait(float seconds)
        { float end=Time.realtimeSinceStartup+seconds; while(Time.realtimeSinceStartup<end)yield return null; }
        private static void Listening(List<string> keys,Action body)
        {
            void Heard(AudioEvents.PlayUI value)=>keys.Add(value.key);
            AudioEvents.UiRequested+=Heard;
            try{body();}
            finally{AudioEvents.UiRequested-=Heard;}
        }
        private (Button button,UIButtonHoldRepeat hold) HoldButton()
        {
            var button=NewButton("hold button");var hold=button.gameObject.AddComponent<UIButtonHoldRepeat>();
            Set(hold,"holdDelay",ShortDelay);Set(hold,"repeatInterval",ShortDelay);
            return(button,hold);
        }

        // UIButtonLock
        [TestCase(UIButtonLockState.SoftLock)]
        [TestCase(UIButtonLockState.HardLock)]
        public void LockTurnsTheButtonOffAndNormalRestoresIt(UIButtonLockState state)
        {
            var button=NewButton("button");var buttonLock=button.gameObject.AddComponent<UIButtonLock>();
            int clicks=0;button.onClick.AddListener(()=>clicks++);

            buttonLock.SetState(state);
            Assert.That(buttonLock.State,Is.EqualTo(state));Assert.That(button.interactable,Is.False);
            Click(button.gameObject,Pointer());Assert.That(clicks,Is.Zero);

            buttonLock.SetState(UIButtonLockState.Normal);
            Assert.That(button.interactable,Is.True);
            Click(button.gameObject,Pointer());Assert.That(clicks,Is.EqualTo(1));
        }

        [Test]
        public void SoftLockedClickAnswersOnceAndNeverReachesOnClick()
        {
            var button=NewButton("soft locked");var buttonLock=button.gameObject.AddComponent<UIButtonLock>();
            Set(buttonLock,"lockedSoundKey","step11/locked");
            int clicks=0,locked=0;button.onClick.AddListener(()=>clicks++);buttonLock.onLockedClick.AddListener(()=>locked++);
            buttonLock.SetState(UIButtonLockState.SoftLock);
            var heard=new List<string>();

            Listening(heard,()=>Click(button.gameObject,Pointer()));
            Assert.That(locked,Is.EqualTo(1));Assert.That(clicks,Is.Zero);Assert.That(heard,Is.EqualTo(new[]{"step11/locked"}));

            Listening(heard,()=>Click(button.gameObject,Pointer(PointerEventData.InputButton.Right)));
            Assert.That(locked,Is.EqualTo(1),"Only the left button is a click.");Assert.That(heard.Count,Is.EqualTo(1));
        }

        [Test]
        public void HardLockedClickInvokesNothing()
        {
            var button=NewButton("hard locked");var buttonLock=button.gameObject.AddComponent<UIButtonLock>();
            Set(buttonLock,"lockedSoundKey","step11/locked");
            int clicks=0,locked=0;button.onClick.AddListener(()=>clicks++);buttonLock.onLockedClick.AddListener(()=>locked++);
            buttonLock.SetState(UIButtonLockState.HardLock);
            var heard=new List<string>();

            Listening(heard,()=>Click(button.gameObject,Pointer()));

            Assert.That(locked,Is.Zero);Assert.That(clicks,Is.Zero);Assert.That(heard,Is.Empty);
        }

        [Test]
        public void StateChangedFiresOnlyOnAChange()
        {
            var buttonLock=NewButton("watched").gameObject.AddComponent<UIButtonLock>();
            var seen=new List<UIButtonLockState>();buttonLock.StateChanged+=seen.Add;

            buttonLock.SetState(UIButtonLockState.Normal);
            buttonLock.SetState(UIButtonLockState.SoftLock);buttonLock.SetState(UIButtonLockState.SoftLock);
            buttonLock.SetState(UIButtonLockState.HardLock);
            buttonLock.SetState(UIButtonLockState.Normal);buttonLock.SetState(UIButtonLockState.Normal);

            Assert.That(seen,Is.EqualTo(new[]{UIButtonLockState.SoftLock,UIButtonLockState.HardLock,UIButtonLockState.Normal}));
        }

        // Follows the path a pointer input module takes: raycast, then handler lookup, then the click. This stops short of a
        // physical input device: no input module runs and no real press happens, so a device or module problem would not show here.
        [UnityTest]
        public IEnumerator SoftLockedButtonIsStillHitAndStillOwnsTheClick()
        {
            var canvas=New("canvas",typeof(Canvas),typeof(GraphicRaycaster)).GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;
            var button=NewButton("locked under canvas");button.transform.SetParent(canvas.transform,false);
            var rect=(RectTransform)button.transform;rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=Vector2.zero;rect.offsetMax=Vector2.zero;
            var buttonLock=button.gameObject.AddComponent<UIButtonLock>();buttonLock.SetState(UIButtonLockState.SoftLock);
            int clicks=0,locked=0;button.onClick.AddListener(()=>clicks++);buttonLock.onLockedClick.AddListener(()=>locked++);
            var pointer=Pointer();pointer.position=new Vector2(Screen.width*.5f,Screen.height*.5f);
            var hits=new List<RaycastResult>();

            yield return Until(()=>{Canvas.ForceUpdateCanvases();hits.Clear();_events.RaycastAll(pointer,hits);return hits.Count>0;});

            Assert.That(button.IsInteractable(),Is.False);Assert.That(hits[0].gameObject,Is.SameAs(button.gameObject));
            var handler=ExecuteEvents.GetEventHandler<IPointerClickHandler>(hits[0].gameObject);
            Assert.That(handler,Is.SameAs(button.gameObject));
            Click(handler,pointer);
            Assert.That(locked,Is.EqualTo(1));Assert.That(clicks,Is.Zero);
        }

        // UIButtonSound
        [Test]
        public void ClickRequestsTheSoundKey()
        {
            var button=NewButton("sounding");Set(button.gameObject.AddComponent<UIButtonSound>(),"soundKey","step11/button");
            var heard=new List<string>();
            Listening(heard,()=>Click(button.gameObject,Pointer()));
            Assert.That(heard,Is.EqualTo(new[]{"step11/button"}));
        }

        [Test]
        public void EmptySoundKeyRequestsNothing()
        {
            var button=NewButton("silent");button.gameObject.AddComponent<UIButtonSound>();
            int clicks=0;button.onClick.AddListener(()=>clicks++);var heard=new List<string>();
            Listening(heard,()=>Click(button.gameObject,Pointer()));
            Assert.That(heard,Is.Empty);Assert.That(clicks,Is.EqualTo(1));
        }

        [Test]
        public void DisabledSoundComponentStaysSilent()
        {
            var button=NewButton("disabled sound");var sound=button.gameObject.AddComponent<UIButtonSound>();Set(sound,"soundKey","step11/button");
            var heard=new List<string>();

            sound.enabled=false;
            Listening(heard,()=>Click(button.gameObject,Pointer()));
            Assert.That(heard,Is.Empty);

            sound.enabled=true;
            Listening(heard,()=>Click(button.gameObject,Pointer()));
            Assert.That(heard.Count,Is.EqualTo(1),"Enabling again must add one listener.");
        }

        // UIButtonStateVisual
        [Test]
        public void VisualRevertsTheOldStateWhenItChangedWhileDisabled()
        {
            var button=NewButton("hidden visual button");var go=button.gameObject;go.SetActive(false);
            var buttonLock=go.AddComponent<UIButtonLock>();var visual=go.AddComponent<UIButtonStateVisual>();
            var softMark=New("hidden soft mark");var price=New("hidden price");softMark.SetActive(false);
            Set(visual,"softLock",new UIButtonVisual{enableObjects=new List<GameObject>{softMark},disableObjects=new List<GameObject>{price}});
            go.SetActive(true);buttonLock.SetState(UIButtonLockState.SoftLock);
            Assert.That(softMark.activeSelf,Is.True);Assert.That(price.activeSelf,Is.False);
            go.SetActive(false);buttonLock.SetState(UIButtonLockState.Normal);go.SetActive(true);
            Assert.That(softMark.activeSelf,Is.False);Assert.That(price.activeSelf,Is.True);
        }
        [Test]
        public void SoftLockObeysANonInteractableCanvasGroup()
        {
            var button=NewButton("grouped button");var buttonLock=button.gameObject.AddComponent<UIButtonLock>();var clicks=0;buttonLock.onLockedClick.AddListener(()=>clicks++);
            buttonLock.SetState(UIButtonLockState.SoftLock);
            var data=new PointerEventData(_events){button=PointerEventData.InputButton.Left};
            var parent=New("group parent",typeof(RectTransform),typeof(CanvasGroup));var group=parent.GetComponent<CanvasGroup>();group.interactable=false;button.transform.SetParent(parent.transform,false);
            ExecuteEvents.Execute(button.gameObject,data,ExecuteEvents.pointerClickHandler);Assert.That(clicks,Is.Zero);
            group.interactable=true;
            ExecuteEvents.Execute(button.gameObject,data,ExecuteEvents.pointerClickHandler);Assert.That(clicks,Is.EqualTo(1));
        }
        [Test]
        public void VisualObjectsFollowTheStateAndRevertWhenItChanges()
        {
            var button=NewButton("visual button");var go=button.gameObject;go.SetActive(false);
            var buttonLock=go.AddComponent<UIButtonLock>();var visual=go.AddComponent<UIButtonStateVisual>();
            var normalMark=New("normal mark");var softMark=New("soft mark");var hardMark=New("hard mark");var price=New("price");
            softMark.SetActive(false);hardMark.SetActive(false);
            Set(visual,"normal",new UIButtonVisual{enableObjects=new List<GameObject>{normalMark}});
            Set(visual,"softLock",new UIButtonVisual{enableObjects=new List<GameObject>{softMark},disableObjects=new List<GameObject>{price}});
            Set(visual,"hardLock",new UIButtonVisual{enableObjects=new List<GameObject>{hardMark}});
            go.SetActive(true);
            void Expect(bool normal,bool soft,bool hard,bool priced)
            {
                Assert.That(normalMark.activeSelf,Is.EqualTo(normal),"normal mark");Assert.That(softMark.activeSelf,Is.EqualTo(soft),"soft mark");
                Assert.That(hardMark.activeSelf,Is.EqualTo(hard),"hard mark");Assert.That(price.activeSelf,Is.EqualTo(priced),"price");
            }

            Expect(true,false,false,true);
            buttonLock.SetState(UIButtonLockState.SoftLock);Expect(false,true,false,false);
            buttonLock.SetState(UIButtonLockState.HardLock);Expect(false,false,true,true);
            buttonLock.SetState(UIButtonLockState.Normal);Expect(true,false,false,true);
        }

        // UIButtonHoldRepeat
        [UnityTest]
        public IEnumerator HoldingRepeatsTheClickUntilThePointerIsUp()
        {
            var(button,hold)=HoldButton();int clicks=0;button.onClick.AddListener(()=>clicks++);var pointer=Pointer();

            hold.OnPointerDown(pointer);
            Assert.That(clicks,Is.Zero,"The hold delay comes first.");
            yield return Until(()=>clicks>=3);

            hold.OnPointerUp(pointer);int stopped=clicks;
            yield return Wait(ShortDelay*5);
            Assert.That(clicks,Is.EqualTo(stopped));
        }

        [UnityTest]
        public IEnumerator LockDuringTheHoldStopsTheRepeatAndTheNativeClick([Values(UIButtonLockState.SoftLock,UIButtonLockState.HardLock)]UIButtonLockState state)
        {
            var(button,hold)=HoldButton();var buttonLock=button.gameObject.AddComponent<UIButtonLock>();
            int clicks=0;button.onClick.AddListener(()=>clicks++);var pointer=Pointer();pointer.eligibleForClick=true;

            hold.OnPointerDown(pointer);
            yield return Until(()=>clicks>=1);
            buttonLock.SetState(state);int stopped=clicks;
            yield return Wait(ShortDelay*5);

            Assert.That(clicks,Is.EqualTo(stopped));
            hold.OnPointerUp(pointer);
            Assert.That(pointer.eligibleForClick,Is.False);
        }

        [UnityTest]
        public IEnumerator ReleaseAfterARepeatSuppressesTheNativeClickButATapKeepsIt()
        {
            var(button,hold)=HoldButton();int clicks=0;button.onClick.AddListener(()=>clicks++);var pointer=Pointer();

            pointer.eligibleForClick=true;
            hold.OnPointerDown(pointer);hold.OnPointerUp(pointer);
            Assert.That(pointer.eligibleForClick,Is.True,"A tap stays a normal click.");Assert.That(clicks,Is.Zero);

            hold.OnPointerDown(pointer);
            yield return Until(()=>clicks>=1);
            hold.OnPointerUp(pointer);
            Assert.That(pointer.eligibleForClick,Is.False,"The repeat already delivered the click.");
        }
    }
}
