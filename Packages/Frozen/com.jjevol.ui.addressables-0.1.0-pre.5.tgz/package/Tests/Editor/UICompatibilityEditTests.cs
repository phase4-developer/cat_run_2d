using System;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.U2D;
using Object=UnityEngine.Object;

namespace jjevol.UI.Tests
{
    public sealed class UICompatibilityEditTests
    {
        private const string ImageInspectorGuid="2f9773e9d680c8547b5fd7a5515bb5e2";
        private const string TextureInspectorGuid="2be2dcb4a2e888f49b82bb10c6ae415a";
        private UIFixtureSetup _fixture;
        [OneTimeSetUp]public void Setup(){_fixture=new UIFixtureSetup();_fixture.Setup();}
        [OneTimeTearDown]public void Cleanup()=>_fixture?.Cleanup();
        [Test]
        public void ResourceNamingRemainsStable()
        {
            Assert.That(UIPopupManager.GetAddressableKey("YesNoPopup"),Is.EqualTo("UIPopup_YesNoPopup"));
            Assert.That(UIAddress.Screen("IntroScreen"),Is.EqualTo("UIScreen_IntroScreen"));Assert.That(UIAddress.Popup("YesNoPopup"),Is.EqualTo("UIPopup_YesNoPopup"));Assert.That(UIAddress.Hud("MainMenuHud"),Is.EqualTo("UIHud_MainMenuHud"));
        }
        [Test]
        public void AddressableImageSerializedSlotsAndFormerNamesArePreserved()
        {
            var go=new GameObject("serialized image",typeof(RectTransform));
            try
            {
                var image=go.AddComponent<AddressableImage>();var so=new SerializedObject(image);
                foreach(var field in new[]{"m_AtlasKey","m_SpriteName","m_LoadOnEnable","m_ReleaseOnDisable","m_ClearSpriteOnDisable","m_ReleaseDelay","m_ShowLoading","m_LoadingView"})Assert.That(so.FindProperty(field),Is.Not.Null,field);
                var info=typeof(AddressableImage).GetField("m_AtlasKey",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic);
                Assert.That(info.GetCustomAttributes(typeof(FormerlySerializedAsAttribute),true).Cast<FormerlySerializedAsAttribute>().Single().oldName,Is.EqualTo("m_AtlasTag"));
            }
            finally{Object.DestroyImmediate(go);}
        }
        [Test]
        public void AddressableTextureSerializedSlotsAndFormerNamesArePreserved()
        {
            var go=new GameObject("serialized texture",typeof(RectTransform));
            try
            {
                var so=new SerializedObject(go.AddComponent<AddressableTexture>());
                foreach(var field in new[]{"m_SpriteKey","m_LoadOnEnable","m_ReleaseOnDisable","m_ClearSpriteOnDisable","m_ReleaseDelay","m_ShowLoading","m_LoadingView","m_LoadingColor","m_FadeColorDuration","m_SkipLoadingForCachedImage"})Assert.That(so.FindProperty(field),Is.Not.Null,field);
                foreach(var pair in new[]{("m_SpriteKey","m_spriteName"),("m_ReleaseDelay","releaseDelay"),("m_ShowLoading","showLoadingCell"),("m_LoadingColor","loadingColor"),("m_FadeColorDuration","fadeColorDuration"),("m_SkipLoadingForCachedImage","skipLoadingAnimationForCachedImage")})
                {
                    var info=typeof(AddressableTexture).GetField(pair.Item1,System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic);
                    Assert.That(info.GetCustomAttributes(typeof(FormerlySerializedAsAttribute),true).Cast<FormerlySerializedAsAttribute>().Single().oldName,Is.EqualTo(pair.Item2));
                }
            }
            finally{Object.DestroyImmediate(go);}
        }
        [Test]
        public void ImageLoadStateAddsNoSerializedData()
        {
            var go=new GameObject("no extra data",typeof(RectTransform));
            try
            {
                foreach(var component in new Component[]{go.AddComponent<AddressableImage>(),new GameObject("texture",typeof(RectTransform)){transform={parent=go.transform}}.AddComponent<AddressableTexture>()})
                    Assert.That(new SerializedObject(component).FindProperty("_load"),Is.Null);
            }
            finally{Object.DestroyImmediate(go);}
        }
        [Test]
        public void DirectSpriteAssignmentsKeepOnlyTheKeyInSerializedData()
        {
            var atlas=AddressableEditorPreviewResolver.LoadSpriteAtlas("Step11/Atlas");
            var picked=AddressableEditorPreviewResolver.GetSpriteFromAtlas(atlas,"step11_red");
            var direct=UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(UnityEditor.AssetDatabase.GUIDToAssetPath(UnityEditor.AddressableAssets.AddressableAssetSettingsDefaultObject.Settings.groups.SelectMany(group=>group.entries).Single(entry=>entry.address=="Step11/DirectSprite").guid));
            var go=new GameObject("direct references",typeof(RectTransform));
            var child=new GameObject("direct texture",typeof(RectTransform));child.transform.SetParent(go.transform,false);
            try
            {
                var image=go.AddComponent<AddressableImage>();var texture=child.AddComponent<AddressableTexture>();
                image.sprite=picked;texture.sprite=direct;
                image.enabled=false;image.enabled=true;texture.enabled=false;texture.enabled=true;
                Assert.That(new SerializedObject(image).FindProperty("m_Sprite").objectReferenceValue,Is.Null,"A Prefab must not keep a direct Sprite reference and its Bundle dependency.");
                Assert.That(new SerializedObject(texture).FindProperty("m_Sprite").objectReferenceValue,Is.Null);
                Assert.That(image.spriteName,Is.EqualTo("step11_red"));
                Assert.That(texture.spriteKey,Is.EqualTo("Step11/DirectSprite"));
            }
            finally{Object.DestroyImmediate(go);if(picked)Object.DestroyImmediate(picked);}
        }
        [Test]
        public void PreviewMeshIsAnInternalEditorHelperSharedByBothComponents()
        {
            var type=typeof(AddressableImage).Assembly.GetType("jjevol.AddressablePreviewMesh");
            Assert.That(type,Is.Not.Null);Assert.That(type.IsNotPublic&&type.IsAbstract&&type.IsSealed,Is.True,"Expected an internal static class.");
            foreach(var component in new[]{typeof(AddressableImage),typeof(AddressableTexture)})
                Assert.That(component.GetMethod("GeneratePreviewSprite",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic),Is.Null);
            var go=new GameObject("preview mesh",typeof(RectTransform));
            var sprite=AddressableEditorPreviewResolver.GetSpriteFromAtlas(AddressableEditorPreviewResolver.LoadSpriteAtlas("Step11/Atlas"),"step11_red");
            using var mesh=new UnityEngine.UI.VertexHelper();
            try
            {
                var image=go.AddComponent<AddressableImage>();image.SetEditorPreviewSprite(sprite);
                typeof(AddressableImage).GetMethod("OnPopulateMesh",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic,null,new[]{typeof(UnityEngine.UI.VertexHelper)},null).Invoke(image,new object[]{mesh});
                Assert.That(mesh.currentVertCount,Is.EqualTo(4));
            }
            finally{Object.DestroyImmediate(go);if(sprite)Object.DestroyImmediate(sprite);}
        }
        [Test]
        public void InspectorsShareOneBaseAndKeepTheirScriptGuids()
        {
            foreach(var pair in new[]{(typeof(AddressableImageInspector),"AddressableImageInspector.cs",ImageInspectorGuid),(typeof(AddressableTextureInspector),"AddressableTextureInspector.cs",TextureInspectorGuid)})
            {
                Assert.That(pair.Item1.BaseType,Is.EqualTo(typeof(AddressableImageInspectorBase)));
                StringAssert.EndsWith(pair.Item2,UnityEditor.AssetDatabase.GUIDToAssetPath(pair.Item3));
            }
        }
        [Test]
        public void InspectorFoldoutsStartCollapsedOnBothComponents()
        {
            foreach(var component in new[]{typeof(AddressableImage),typeof(AddressableTexture)})
            {
                var go=new GameObject("foldouts",typeof(RectTransform));UnityEditor.Editor editor=null;
                try
                {
                    editor=UnityEditor.Editor.CreateEditor(go.AddComponent(component));
                    foreach(var field in new[]{"_showRuntime","_showLoading","_showAdvanced"})
                        Assert.That(typeof(AddressableImageInspectorBase).GetField(field,System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(editor),Is.False,field);
                }
                finally{if(editor)Object.DestroyImmediate(editor);Object.DestroyImmediate(go);}
            }
        }
        [Test]
        public void ResolverReportsWhetherAnAssetIsRegistered()
        {
            Assert.That(AddressableEditorPreviewResolver.IsAddressableAsset(AddressableEditorPreviewResolver.LoadSpriteAtlas("Step11/Atlas")),Is.True);
            Assert.That(AddressableEditorPreviewResolver.IsAddressableAsset(null),Is.False);
            var script=UnityEditor.AssetDatabase.LoadAssetAtPath<MonoScript>(UnityEditor.AssetDatabase.GUIDToAssetPath(ImageInspectorGuid));
            Assert.That(script,Is.Not.Null);
            Assert.That(AddressableEditorPreviewResolver.IsAddressableAsset(script),Is.False,"An unregistered asset would fail at runtime.");
            var memoryOnly=ScriptableObject.CreateInstance<ScriptableObject>();
            try{Assert.That(AddressableEditorPreviewResolver.IsAddressableAsset(memoryOnly),Is.False);}
            finally{Object.DestroyImmediate(memoryOnly);}
        }
        [TestCase(typeof(UINavigationOptions),"ResetState")]
        [TestCase(typeof(UIEvent),"ResetState")]
        [TestCase(typeof(UIManager),"ResetStaticState")]
        public void StaticStateResetsRunAtSubsystemRegistration(Type owner,string name)
        {
            var method=owner.GetMethod(name,System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic);
            Assert.That(method,Is.Not.Null);
            Assert.That(method.GetCustomAttributes(typeof(RuntimeInitializeOnLoadMethodAttribute),false).Cast<RuntimeInitializeOnLoadMethodAttribute>().Single().loadType,Is.EqualTo(RuntimeInitializeLoadType.SubsystemRegistration));
        }
        [Test]
        public void ActualEditorResolverFindsCatalogAtlasAndSpriteNames()
        {
            var atlas=AddressableEditorPreviewResolver.LoadSpriteAtlas("Step11/Atlas");Assert.That(atlas,Is.Not.Null);
            Assert.That(AddressableEditorPreviewResolver.GetSpriteNames(atlas),Is.EquivalentTo(new[]{"step11_red","step11_blue"}));
            var sprite=AddressableEditorPreviewResolver.GetSpriteFromAtlas(atlas,"step11_red(Clone)");
            Assert.That(sprite,Is.Not.Null);Object.DestroyImmediate(sprite);
            Assert.That(UIEditorPreview.ResolveAtlas,Is.Not.Null);Assert.That(UIEditorPreview.LoadSpriteAtlas("Step11/Atlas"),Is.SameAs(atlas));
        }
        [Test]
        public void EditorPackageDoesNotRegisterAutomaticPrefabCleanersOrRemovedMenus()
        {
            var assembly = typeof(AddressableImageInspector).Assembly;
            var types = assembly.GetTypes();
            Assert.That(assembly.GetType("jjevol.EditorTools.AddressableUIReferenceCleaner"), Is.Null);
            Assert.That(assembly.GetType("jjevol.EditorTools.AddressableUIReferenceBuildCleaner"), Is.Null);
            Assert.That(types.Any(type => typeof(UnityEditor.Build.IPreprocessBuildWithReport).IsAssignableFrom(type)), Is.False);
            var menus = types.SelectMany(type => type.GetMethods(System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.DeclaredOnly))
                .SelectMany(method => method.GetCustomAttributesData()).Where(attribute => attribute.AttributeType == typeof(MenuItem))
                .Select(attribute => (string)attribute.ConstructorArguments[0].Value);
            Assert.That(menus.Intersect(new[] { "Tools/Addressables/Check Addressable UI Sprite References", "Tools/Addressables/Clear Addressable UI Sprite References" }), Is.Empty);
        }

        [Test]
        public void ImageComponentsSelectTheirOriginalFullInspectors()
        {
            foreach (var pair in new[] { (typeof(AddressableImage), typeof(AddressableImageInspector)), (typeof(AddressableTexture), typeof(AddressableTextureInspector)) })
            {
                var go = new GameObject("inspector selection", typeof(RectTransform));
                UnityEditor.Editor editor = null;
                try
                {
                    var component = go.AddComponent(pair.Item1);
                    editor = UnityEditor.Editor.CreateEditor(component);
                    Assert.That(editor.GetType(), Is.EqualTo(pair.Item2));
                }
                finally { if (editor) Object.DestroyImmediate(editor); Object.DestroyImmediate(go); }
            }
        }

        // An atlas clone is a step11_ sprite that is not a saved asset. Counting by "(Clone)" in the name broke on 6.7.
        private static int Clones() => Resources.FindObjectsOfTypeAll<Sprite>().Count(sprite => sprite.name.StartsWith("step11_", StringComparison.Ordinal) && !EditorUtility.IsPersistent(sprite));
        private static string AtlasSprites() => string.Join(", ", Resources.FindObjectsOfTypeAll<Sprite>().Where(sprite => sprite.name.StartsWith("step11_", StringComparison.Ordinal)).Select(sprite => sprite.name + (EditorUtility.IsPersistent(sprite) ? " [asset]" : " [memory]")));

        [Test]
        public void FullAtlasInspectorKeepsOnePreviewCloneAndReleasesItOnClose()
        {
            var go = new GameObject("full inspector preview", typeof(RectTransform));
            UnityEditor.Editor editor = null;
            try
            {
                var image = go.AddComponent<AddressableImage>();
                image.SetAtlasSprite("Step11/Atlas", "step11_red");
                int before = Clones();
                editor = UnityEditor.Editor.CreateEditor(image);
                for (int i = 0; i < 25; i++) Assert.That(editor.GetInfoString(), Does.StartWith("Image Size:"));
                Assert.That(Clones(), Is.EqualTo(before + 1), AtlasSprites());
                Object.DestroyImmediate(editor);
                Assert.That(Clones(), Is.EqualTo(before), AtlasSprites());
            }
            finally { if (editor) Object.DestroyImmediate(editor); Object.DestroyImmediate(go); }
        }

        [Test]
        public void FullAtlasInspectorSelectionStoresTheNameWithoutADirectSpriteReference()
        {
            var go = new GameObject("inspector picker", typeof(RectTransform));
            UnityEditor.Editor editor = null;
            Sprite selected = null;
            try
            {
                var image = go.AddComponent<AddressableImage>();
                image.SetAtlasSprite("Step11/Atlas", "step11_red");
                editor = UnityEditor.Editor.CreateEditor(image);
                selected = AddressableEditorPreviewResolver.GetSpriteFromAtlas(AddressableEditorPreviewResolver.LoadSpriteAtlas("Step11/Atlas"), "step11_blue");
                typeof(AddressableImageInspector).GetMethod("SelectSprite", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).Invoke(editor, new object[] { selected });
                Assert.That(image.spriteName, Is.EqualTo("step11_blue"));
                Assert.That(new SerializedObject(image).FindProperty("m_Sprite").objectReferenceValue, Is.Null);
            }
            finally { if (selected) Object.DestroyImmediate(selected); if (editor) Object.DestroyImmediate(editor); Object.DestroyImmediate(go); }
        }
        [Test]
        public void EnumeratingAtlasNamesMustNotAccumulateNativeSpriteClones()
        {
            var atlas=AddressableEditorPreviewResolver.LoadSpriteAtlas("Step11/Atlas");
            int before=Clones();for(int i=0;i<25;i++)AddressableEditorPreviewResolver.GetSpriteNames(atlas);
            Assert.That(Clones(), Is.EqualTo(before), AtlasSprites());
        }
        [TestCase(typeof(SpriteSelector))]
        [TestCase(typeof(SpriteSelectorWindow))]
        public void SpriteSelectionToolsReleaseTheirOwnedSpritesAndCheckerTexture(Type selectorType)
        {
            int before = Clones();
            var wizard = ScriptableObject.CreateInstance(selectorType);
            Texture2D checker = null;
            try
            {
                var flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic;
                selectorType.GetField("curAtlas", flags).SetValue(wizard, AddressableEditorPreviewResolver.LoadSpriteAtlas("Step11/Atlas"));
                var populate = selectorType.GetMethod("SetSpritesArray", flags);
                object[] args = populate.GetParameters().Length == 0 ? null : new object[] { true };
                for (int i = 0; i < 25; i++) populate.Invoke(wizard, args);
                Assert.That(Clones(), Is.EqualTo(before + 2), AtlasSprites());
                checker = (Texture2D)selectorType.GetProperty("backdropTexture").GetValue(wizard);
            }
            finally { Object.DestroyImmediate(wizard); }
            Assert.That(Clones(), Is.EqualTo(before), AtlasSprites());
            Assert.That(checker == null, Is.True);
        }
        [Test]
        public void EditorImagePreviewOwnsOnlyItsCurrentAtlasClone()
        {
            int before=Clones();var go=new GameObject("preview owner",typeof(RectTransform));
            try
            {
                var image=go.AddComponent<AddressableImage>();image.SetAtlasSprite("Step11/Atlas","step11_red");
                for(int i=0;i<25;i++)image.RefreshEditorPreview();
                Assert.That(Clones(), Is.EqualTo(before+1), AtlasSprites());
            }
            finally{Object.DestroyImmediate(go);}
            Assert.That(Clones(), Is.EqualTo(before), AtlasSprites());
        }
    }
}
