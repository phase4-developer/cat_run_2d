using System;
using System.IO;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.U2D;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.U2D;
using UnityEngine.UI;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.UI.Tests
{
    public sealed class UIFixtureSetup : IPrebuildSetup, IPostBuildCleanup
    {
        public void Setup()
        {
            string root="Assets/Step11Fixtures_"+Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets",Path.GetFileName(root));
            var prior=AddressableAssetSettingsDefaultObject.Settings;
            SessionState.SetString("Step11PreviousSettings",prior ? AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(prior)) : "");
            SessionState.SetBool("Step11HadDefaultObject",AssetDatabase.IsValidFolder("Assets/AddressableAssetsData"));
            var settings=AddressableAssetSettings.Create(root,"Settings",true,true);
            AddressableAssetSettingsDefaultObject.Settings=settings;
            for(int i=0;i<settings.DataBuilders.Count;i++) if(settings.DataBuilders[i] is BuildScriptFastMode) settings.ActivePlayModeDataBuilderIndex=i;
            void Register(string path,string key) { settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path),settings.DefaultGroup).address=key; }
            GameObject Rect(string name,Transform parent=null) { var go=new GameObject(name,typeof(RectTransform)); if(parent)go.transform.SetParent(parent,false); return go; }
            foreach(var screenType in new[]{"IntroScreen","LobbyScreen"})
            {
                var go=Rect("fixture screen"); var screen=go.AddComponent<UIScreen>(); screen.ScreenType=screenType;
                string path=root+"/"+screenType+".prefab"; PrefabUtility.SaveAsPrefabAsset(go,path); Object.DestroyImmediate(go); Register(path,"UIScreen_"+screenType);
            }
            var popup=Rect("fixture popup"); popup.AddComponent<CanvasGroup>(); popup.AddComponent<UIPopup>();
            string popupPath=root+"/Popup.prefab"; PrefabUtility.SaveAsPrefabAsset(popup,popupPath); Object.DestroyImmediate(popup);
            Register(popupPath,"UIPopup_YesNoPopup");
            var hud=Rect("fixture HUD"); hud.AddComponent<UIFixtureHud>();
            string hudPath=root+"/Hud.prefab"; PrefabUtility.SaveAsPrefabAsset(hud,hudPath); Object.DestroyImmediate(hud); Register(hudPath,"UIHud_MainMenuHud");
            var loading=Rect("fixture loading"); loading.AddComponent<Image>();
            string loadingPath=root+"/Loading.prefab"; PrefabUtility.SaveAsPrefabAsset(loading,loadingPath); Object.DestroyImmediate(loading); Register(loadingPath,"Step11/loading");

            var managerRoot=Rect("fixture UI Manager"); managerRoot.SetActive(false); managerRoot.AddComponent<Canvas>();
            var screenRoot=Rect("screens",managerRoot.transform); var popupRoot=Rect("popups",managerRoot.transform);
            Rect("Backboard",popupRoot.transform).AddComponent<Image>();
            var hudRoot=Rect("HUDs",managerRoot.transform); hudRoot.AddComponent<Canvas>();
            var loadingRoot=Rect("loading",managerRoot.transform); var effects=Rect("effects",managerRoot.transform);
            var manager=managerRoot.AddComponent<UIManager>();
            var so=new SerializedObject(manager);
            foreach(var pair in new[]{("screenRoot",screenRoot), ("popupRoot",popupRoot),("hudRoot",hudRoot),("loadingRoot",loadingRoot),("effectRoot",effects)})
                so.FindProperty(pair.Item1).objectReferenceValue=pair.Item2.transform;
            so.ApplyModifiedPropertiesWithoutUndo(); managerRoot.SetActive(true);
            string managerPath=root+"/Manager.prefab"; PrefabUtility.SaveAsPrefabAsset(managerRoot,managerPath); Object.DestroyImmediate(managerRoot); Register(managerPath,"Step11/Manager");

            foreach(var pair in new[]{("red",Color.red),("blue",Color.blue)})
            {
                var texture=new Texture2D(16,16); var pixels=new Color[256]; Array.Fill(pixels,pair.Item2); texture.SetPixels(pixels); texture.Apply();
                string path=root+"/step11_"+pair.Item1+".png"; File.WriteAllBytes(path,texture.EncodeToPNG()); Object.DestroyImmediate(texture);
                AssetDatabase.ImportAsset(path);
                var importer=(TextureImporter)AssetImporter.GetAtPath(path); importer.textureType=TextureImporterType.Sprite;
                importer.spriteImportMode=SpriteImportMode.Single; importer.textureCompression=TextureImporterCompression.Uncompressed; importer.isReadable=true;
                importer.alphaSource=TextureImporterAlphaSource.FromInput; importer.alphaIsTransparency=true;
                importer.SetPlatformTextureSettings(new TextureImporterPlatformSettings{name="Standalone",overridden=true,format=TextureImporterFormat.RGBA32,maxTextureSize=256,textureCompression=TextureImporterCompression.Uncompressed});
                importer.SaveAndReimport();
            }
            // Author the independent fixture through Unity 6's V2 importer; runtime still consumes SpriteAtlas.
            SessionState.SetInt("Step11PriorPackerMode",(int)EditorSettings.spritePackerMode);
            EditorSettings.spritePackerMode=SpritePackerMode.SpriteAtlasV2;
            var atlasAsset=new SpriteAtlasAsset();
            atlasAsset.Add(new Object[]{AssetDatabase.LoadAssetAtPath<Texture2D>(root+"/step11_red.png"),AssetDatabase.LoadAssetAtPath<Texture2D>(root+"/step11_blue.png")});
            string atlasPath=root+"/Fixture.spriteatlasv2"; SpriteAtlasAsset.Save(atlasAsset,atlasPath); AssetDatabase.ImportAsset(atlasPath);
            var atlasImporter=(SpriteAtlasImporter)AssetImporter.GetAtPath(atlasPath);
            var atlasTexture=atlasImporter.textureSettings; atlasTexture.readable=true; atlasTexture.generateMipMaps=false; atlasImporter.textureSettings=atlasTexture;
            atlasImporter.SetPlatformSettings(new TextureImporterPlatformSettings{name="Standalone",overridden=true,format=TextureImporterFormat.RGBA32,maxTextureSize=256,textureCompression=TextureImporterCompression.Uncompressed});
            atlasImporter.SaveAndReimport();
            var atlas=AssetDatabase.LoadAssetAtPath<SpriteAtlas>(atlasPath);
            if(atlas==null||atlas.spriteCount!=2)throw new InvalidOperationException("The real fixture Atlas must contain both imported sprites.");
            Register(atlasPath,"Step11/Atlas");
            Register(root+"/step11_red.png","Step11/Sprite");
            var plainTexture=new Texture2D(16,16); AssetDatabase.CreateAsset(plainTexture,root+"/Texture.asset"); Register(root+"/Texture.asset","Step11/Texture");
            var directSprite=Sprite.Create(plainTexture,new Rect(0,0,16,16),new Vector2(.5f,.5f));directSprite.name="step11_direct_sprite";
            AssetDatabase.CreateAsset(directSprite,root+"/SingleSprite.asset");Register(root+"/SingleSprite.asset","Step11/DirectSprite");
            EditorUtility.SetDirty(settings); AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
            SessionState.SetString("Step11Root",root);
            SessionState.SetString("Step11PriorRuntimePath",SessionState.GetString(Addressables.kAddressablesRuntimeDataPath,""));
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
        }
        public void Cleanup()
        {
            EditorSettings.spritePackerMode=(SpritePackerMode)SessionState.GetInt("Step11PriorPackerMode",(int)EditorSettings.spritePackerMode);
            string previous=SessionState.GetString("Step11PreviousSettings","");
            AddressableAssetSettingsDefaultObject.Settings=string.IsNullOrEmpty(previous)?null:AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(AssetDatabase.GUIDToAssetPath(previous));
            string runtime=SessionState.GetString("Step11PriorRuntimePath","");
            if(runtime=="")SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);else SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,runtime);
            string root=SessionState.GetString("Step11Root","");
            if(root.StartsWith("Assets/Step11Fixtures_",StringComparison.Ordinal)&&string.Equals(Path.GetDirectoryName(Path.GetFullPath(root)),Path.GetFullPath(Application.dataPath),StringComparison.OrdinalIgnoreCase))AssetDatabase.DeleteAsset(root);
            if(!SessionState.GetBool("Step11HadDefaultObject",false)) { EditorBuildSettings.RemoveConfigObject(AddressableAssetSettingsDefaultObject.kDefaultConfigObjectName); AssetDatabase.DeleteAsset("Assets/AddressableAssetsData"); }
            SessionState.EraseString("Step11Root");
        }
    }
}
