# 현재 기능의 소유 위치

이 폴더의 과거 설명은 STEP11 추출 시점 기록이었다. 현재 구현 위치는 다음과 같다.

- Image/Texture Inspector와 Sprite 선택·preview helper: 같은 패키지의 Editor/. 원본 Inspector 두 개의 meta/GUID와 preview 수명 개선, helper·생성 메뉴를 유지한다. 기본 대체 Inspector와 중복 등록하지 않는다. STEP 06-A에서 일회성 직접 Sprite 참조 Cleaner·Check/Clear 메뉴·자동 Prefab 수정 Prebuild Hook은 제거했다. 수동 Unity 화면 검증은 자동 테스트와 구분한다.
- UITransition: com.jjevol.ui.dotween-pro/Runtime/UITransition.cs. 선택 DOTween Pro 의존성·검증 범위는 해당 패키지 README를 따른다.
- UIManagerCreater: com.jjevol.ui.urp/Runtime/UIManagerCreater.cs. URP 설치·초기화 계약과 검증 범위는 해당 패키지 README를 따른다.

과거 Snapshot과 STEP 보고서는 당시 증거로 보존한다. 이 경로의 예전 설명을 이유로 구현을 다시 복제하지 않는다.
