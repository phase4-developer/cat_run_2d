// UIScreenManager.cs - 네이밍 개선 적용 버전
using System.Collections.Generic;
using UnityEngine;
using Cysharp.Threading.Tasks;
using UnityEngine.AddressableAssets;

namespace jjevol
{
    public class UIScreenManager : IUIReleaseHandle, System.IDisposable
    {
        private readonly Transform _screenParent;
        private readonly UIInstanceOwner _instances;
        private readonly Dictionary<string,UniTaskCompletionSource<UIScreen>> _pending=new();
        private bool _disposed;
        private int _navigationVersion;
        public void Dispose()
        {
            if(_disposed)return;_disposed=true;_navigationVersion++;
            _instances.Dispose();screenPool.Clear();ClearScreenHistory();CurrentScreen=null;
        }
        public UIScreen CurrentScreen { get; private set; }
        public Dictionary<string, UIScreen> screenPool = new();
        private readonly List<string> screenHistory = new();
        private readonly Dictionary<string, IScreenData> screenParams = new();

        public UIScreenManager(Transform screenParent)
        {
            _screenParent = screenParent;
            _instances=new UIInstanceOwner(screenParent);

            UIScreen[] screens = _screenParent.GetComponentsInChildren<UIScreen>(true);

            if (screens != null && screens.Length > 0)
            {
                for (int i = 0, imax = screens.Length; i < imax; i++)
                {
                    if(screens[i].GetComponent<UIInstanceReturnOnDestroy>()||string.IsNullOrEmpty(screens[i].ScreenType))continue;
                    screenPool.Add(screens[i].ScreenType, screens[i]);
                }
            }
        }

        public async UniTask CachingScreenAsync(List<string> screenTypes)
        {
            List<UniTask<UIScreen>> taskList = new List<UniTask<UIScreen>>();

            foreach (var screenType in screenTypes)
            {
                if (string.IsNullOrEmpty(screenType) || !UINavigationOptions.CanOpenScreen(screenType)) continue;

                taskList.Add(GetOrLoadUIScreenAsync(screenType, true));
            }

            UIScreen[] screens = await UniTask.WhenAll(taskList);

            for (int i = 0; i < screens.Length; i++)
            {
                if(screens[i]!=null && screens[i]!=CurrentScreen) screens[i].HideUI();
            }
        }

        public bool IsScreenPooled(UIScreen screen)
        {
            return screenPool.ContainsKey(screen.ScreenType) && screenPool[screen.ScreenType] == screen;
        }

        public void ClearScreenHistory()
        {
            screenHistory.Clear();
            screenParams.Clear();
        }

        public void DestroyScreen(string screenType)
        {
            screenHistory.Remove(screenType);
            screenParams.Remove(screenType);

            if (CurrentScreen != null && CurrentScreen.ScreenType == screenType)
                CurrentScreen = null;

            if (screenPool.TryGetValue(screenType, out var screen))
            {
                screen.HideUI();
                screen.DestroyScreen();
                screenPool.Remove(screenType);
            }
        }

        public void SetCurrentScreen(UIScreen nextScreen, IScreenData data, bool forceTrack = false)
        {
            if (nextScreen == null) return;

            bool isSameScreen = CurrentScreen == nextScreen;

            if (!isSameScreen)
            {
                if (CurrentScreen != null)
                {
                    if (IsScreenPooled(CurrentScreen))
                        CurrentScreen.HideUI();
                    else
                        CurrentScreen.DestroyScreen();
                }

                CurrentScreen = nextScreen;
            }

            if (!isSameScreen || forceTrack)
            {
                UntrackScreen(nextScreen.ScreenType);

                if (nextScreen.EnableHistoryLog)
                {
                    screenHistory.Add(nextScreen.ScreenType);
                    screenParams[nextScreen.ScreenType] = data;
                }
            }
        }

        public void TrackScreen(string screenType, IScreenData data)
        {
            UntrackScreen(screenType);
            screenHistory.Add(screenType);
            screenParams.Add(screenType, data);
        }

        private void UntrackScreen(string screenType)
        {
            screenHistory.Remove(screenType);
            screenParams.Remove(screenType);
        }
        public async UniTask<UIScreen> ChangeUIScreenAsync(string screenType, IScreenData screenData = null, bool isPooling = true)
        {
            int requestVersion=++_navigationVersion;
            if (!UINavigationOptions.CanOpenScreen(screenType)) return null;

            ClearScreenHistory();

            UIScreen targetScreen = await GetOrLoadUIScreenAsync(screenType, isPooling);
            if (targetScreen == null) return null;
            if(_disposed || requestVersion!=_navigationVersion){RetireReplacedScreen(targetScreen);return null;}

            SetCurrentScreen(targetScreen, screenData, true);
            targetScreen.ShowUI(screenData);

            return targetScreen;
        }

        public async UniTask<UIScreen> SpawnUIScreenAsync(string screenType, IScreenData screenData = null, bool isPooling = true)
        {
            int requestVersion=++_navigationVersion;
            if (!UINavigationOptions.CanOpenScreen(screenType)) return null;

            if (CurrentScreen != null && CurrentScreen.ScreenType == screenType)
            {
                if (CurrentScreen.EnableHistoryLog)
                    TrackScreen(CurrentScreen.ScreenType, screenData);

                CurrentScreen.ShowUI(screenData);
                return CurrentScreen;
            }

            UIScreen targetScreen = await GetOrLoadUIScreenAsync(screenType, isPooling);
            if (targetScreen == null) return null;
            if(_disposed || requestVersion!=_navigationVersion){RetireReplacedScreen(targetScreen);return null;}

            SetCurrentScreen(targetScreen, screenData);
            targetScreen.ShowUI(screenData);

            return targetScreen;
        }

        // 대체된 요청의 결과: 풀 인스턴스는 살아 있으므로 숨기고, 이 요청이 만든 일회용 인스턴스만 반환한다.
        private void RetireReplacedScreen(UIScreen screen)
        {
            if(!IsScreenPooled(screen)){Release(screen);return;}
            if(!_disposed&&screen!=CurrentScreen&&screen.IsVisible)screen.HideUI();
        }

        public virtual void Refresh()
        {
            if (CurrentScreen != null)
                CurrentScreen.Refresh();
        }

        public bool IsCanPrev()
        {
            if (screenHistory.Count < 2) return false;
            if (CurrentScreen == null) return false;


            return true;
        }

        public bool TryGetPreviousScreen(out string screenType, out IScreenData screenData)
        {
            screenType = default;
            screenData = null;

            if (CurrentScreen == null)
                return false;

            if (screenHistory.Count == 0)
                return false;

            int prevIndex = screenHistory.Count - 1;

            if (EqualityComparer<string>.Default.Equals(screenHistory[^1], CurrentScreen.ScreenType))
                prevIndex = screenHistory.Count - 2;

            if (prevIndex < 0)
                return false;

            screenType = screenHistory[prevIndex];

            if (screenParams.TryGetValue(screenType, out var data))
                screenData = data;

            return true;
        }

        public async UniTask<UIScreen> PrevUIScreen(bool IsPooling = true)
        {
            if(!TryGetPreviousScreen(out _,out _))return null;
            UntrackScreen(CurrentScreen.ScreenType);

            var prevScreenType = screenHistory[^1];
            var prevParams = screenParams[prevScreenType];

            return await SpawnUIScreenAsync(prevScreenType, prevParams, IsPooling);
        }

        private async UniTask<UIScreen> GetOrLoadUIScreenAsync(string screenType, bool isPooling)
        {
            if(_disposed)return null;
            if(screenPool.TryGetValue(screenType,out var cached)&&cached)return cached;
            if(!isPooling)return await InstantiateUIScreenAsync(screenType);
            if(!_pending.TryGetValue(screenType,out var pending))
            {
                pending=new UniTaskCompletionSource<UIScreen>();_pending.Add(screenType,pending);
                CompleteScreenLoad(screenType,pending).Forget();
            }
            return await pending.Task;
        }
        private async UniTask CompleteScreenLoad(string type,UniTaskCompletionSource<UIScreen> pending)
        {
            try
            {
                var screen=await InstantiateUIScreenAsync(type);
                if(!_disposed&&screen)screenPool[type]=screen;
                pending.TrySetResult(screen);
            }
            catch(System.OperationCanceledException e){pending.TrySetCanceled(e.CancellationToken);}
            catch(System.Exception e){pending.TrySetException(e);}
            finally{if(_pending.TryGetValue(type,out var current)&&ReferenceEquals(current,pending))_pending.Remove(type);}
        }
        private async UniTask<UIScreen> InstantiateUIScreenAsync(string screenType)
        {
            string key = UIAddress.Screen(screenType);

            GameObject newObject = await _instances.InstantiateAsync(key);
            if(!newObject || _disposed)return null;

            if (newObject != null)
            {
                newObject.name = screenType.ToString();

                if (newObject.TryGetComponent<RectTransform>(out var rectTransform))
                {
                    rectTransform.localPosition = Vector3.zero;
                    rectTransform.localScale = Vector3.one;
                    rectTransform.sizeDelta = Vector2.zero;
                }
            }

            var screen = newObject.GetComponent<UIScreen>() ?? newObject.AddComponent<UIScreen>();
            screen.ScreenType = screenType;

            screen.Initialize(this);
            //screen.onDestory.AddListener(ReleaseScreenInstance);

            return screen;
        }

        public void Release(UIBase ui)
        {
            if(ui!=null)_instances.Release(ui.gameObject);
        }

        private void ReleaseScreenInstance(UIBase ui)
        {
            ui.onDestory.RemoveListener(ReleaseScreenInstance);
            if(ui!=null)_instances.Release(ui.gameObject);
        }
    }
}
