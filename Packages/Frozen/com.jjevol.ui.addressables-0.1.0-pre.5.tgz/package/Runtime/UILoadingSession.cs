using System;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// 전체 화면 로딩의 소유권 하나를 나타낸다. 세션이 하나라도 남아 있으면 화면이 유지되고, 마지막 세션의 Dispose가 닫는다.
    /// Report와 SetMessage는 로딩 Prefab의 <see cref="IUILoadingProgressView"/>로 전달되며, View가 없으면 무시된다.
    /// 메인 스레드에서 호출한다.
    /// </summary>
    public sealed class UILoadingSession : IDisposable, IProgress<float>
    {
        private UIManager _owner;

        internal UILoadingSession(UIManager owner, string key)
        {
            _owner = owner;
            Key = key;
        }

        public string Key { get; }

        /// <summary>
        /// false이면 Dispose됐거나 HideLoadingUI, UIManager 재초기화로 닫힌 세션이다. 이후 호출은 아무 일도 하지 않는다.
        /// </summary>
        public bool IsActive => _owner != null;

        public float Progress { get; private set; }

        internal bool HasProgress { get; private set; }

        public void Report(float value)
        {
            if (float.IsNaN(value)) return;

            Progress = Mathf.Clamp01(value);
            HasProgress = true;

            if (_owner != null)
                _owner.PushLoadingProgress();
        }

        public void SetMessage(string message)
        {
            if (_owner != null)
                _owner.PushLoadingMessage(message);
        }

        public void Dispose()
        {
            UIManager owner = _owner;
            _owner = null;

            if (owner != null)
                owner.ReleaseLoadingSession(this);
        }

        internal void Close() => _owner = null;
    }
}
