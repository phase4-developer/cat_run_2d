#if UNITY_EDITOR
using UnityEngine;
using UnityEngine.Sprites;
using UnityEngine.UI;

namespace jjevol
{
    /// <summary>
    /// Edit Mode 프리뷰 Sprite의 메시를 만든다. 비직렬화 프리뷰 전용이며 Image Type은 반영하지 않고 Simple로 그린다.
    /// </summary>
    internal static class AddressablePreviewMesh
    {
        internal static void Populate(VertexHelper vertexHelper, Graphic graphic, Sprite displaySprite, bool preserveAspect)
        {
            vertexHelper.Clear();

            if (displaySprite == null)
                return;

            Vector4 v = GetDrawingDimensions(graphic, displaySprite, preserveAspect);
            Vector4 uv = DataUtility.GetOuterUV(displaySprite);
            Color32 vertexColor = graphic.color;

            vertexHelper.AddVert(new Vector3(v.x, v.y), vertexColor, new Vector2(uv.x, uv.y));
            vertexHelper.AddVert(new Vector3(v.x, v.w), vertexColor, new Vector2(uv.x, uv.w));
            vertexHelper.AddVert(new Vector3(v.z, v.w), vertexColor, new Vector2(uv.z, uv.w));
            vertexHelper.AddVert(new Vector3(v.z, v.y), vertexColor, new Vector2(uv.z, uv.y));

            vertexHelper.AddTriangle(0, 1, 2);
            vertexHelper.AddTriangle(2, 3, 0);
        }

        private static Vector4 GetDrawingDimensions(Graphic graphic, Sprite displaySprite, bool shouldPreserveAspect)
        {
            Rect rect = graphic.GetPixelAdjustedRect();

            Vector4 padding = DataUtility.GetPadding(displaySprite);
            Vector2 spriteSize = new Vector2(displaySprite.rect.width, displaySprite.rect.height);

            if (spriteSize.x <= 0f || spriteSize.y <= 0f)
                return new Vector4(rect.x, rect.y, rect.x + rect.width, rect.y + rect.height);

            if (shouldPreserveAspect)
                PreserveSpriteAspectRatio(ref rect, spriteSize);

            float left = padding.x / spriteSize.x;
            float bottom = padding.y / spriteSize.y;
            float right = (spriteSize.x - padding.z) / spriteSize.x;
            float top = (spriteSize.y - padding.w) / spriteSize.y;

            return new Vector4(
                rect.x + rect.width * left,
                rect.y + rect.height * bottom,
                rect.x + rect.width * right,
                rect.y + rect.height * top
            );
        }

        private static void PreserveSpriteAspectRatio(ref Rect rect, Vector2 spriteSize)
        {
            float spriteRatio = spriteSize.x / spriteSize.y;
            float rectRatio = rect.width / rect.height;

            if (spriteRatio > rectRatio)
            {
                float oldHeight = rect.height;
                rect.height = rect.width * (1.0f / spriteRatio);
                rect.y += (oldHeight - rect.height) * 0.5f;
            }
            else
            {
                float oldWidth = rect.width;
                rect.width = rect.height * spriteRatio;
                rect.x += (oldWidth - rect.width) * 0.5f;
            }
        }
    }
}
#endif
