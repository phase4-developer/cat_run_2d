using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace jjevol
{
    public enum UIButtonLockState
    {
        Normal,
        SoftLock,
        HardLock
    }

    /// <summary>
    /// Locks a Unity Button. Both locks turn the Button off, so <see cref="Button.onClick"/> never runs on a locked
    /// button and game code needs no lock check. A soft lock also answers the click with a sound and <see cref="onLockedClick"/>.
    /// </summary>
    /// <remarks>
    /// Keyboard and gamepad navigation skip a non-interactable Selectable, so a soft lock gives its feedback to pointers only.
    /// </remarks>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Button))]
    public class UIButtonLock : MonoBehaviour, IPointerClickHandler
    {
        [SerializeField] private UIButtonLockState state;

        [Header("Soft Lock Click")]
        [SerializeField] private string lockedSoundKey;
        [SerializeField] private AudioClip lockedClip;
        [SerializeField, Range(0f, 1f)] private float volume = 1f;
        [SerializeField, Range(0.1f, 3f)] private float pitch = 1f;

        public UnityEvent onLockedClick = new UnityEvent();

        private static readonly List<CanvasGroup> Groups = new List<CanvasGroup>();

        private Button _button;

        public UIButtonLockState State => state;
        public event Action<UIButtonLockState> StateChanged;

        private Button Button => _button ? _button : _button = GetComponent<Button>();

        private void Awake() => Button.interactable = state == UIButtonLockState.Normal;

        public void SetState(UIButtonLockState next)
        {
            bool changed = state != next;
            state = next;
            Button.interactable = next == UIButtonLockState.Normal;
            if (changed) StateChanged?.Invoke(next);
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left) return;
            if (state != UIButtonLockState.SoftLock || Button.interactable || !GroupsAllowInteraction()) return;

            UISoundPlayback.PlayUI(lockedClip, lockedSoundKey, volume, pitch);
            onLockedClick.Invoke();
        }

        // The Button is off while locked, so Selectable's own CanvasGroup check cannot answer for a soft lock.
        private bool GroupsAllowInteraction()
        {
            for (var current = transform; current != null; current = current.parent)
            {
                current.GetComponents(Groups);
                foreach (var group in Groups)
                {
                    if (group.enabled && !group.interactable) return false;
                    if (group.ignoreParentGroups) return true;
                }
            }
            return true;
        }
    }
}
