#define UI_ASYNC

using Cysharp.Threading.Tasks;
using jjevol.Effect;


using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.InputSystem;

namespace jjevol
{
    public interface IPreTransitionCheck
    {
        UniTask<bool> PreTransitionRequest();
    }

    public class UITransitionOption
    {
        public bool IsPooling { get; set; } = true;
        public bool CloseAllPopup { get; set; } = true;
        public Action OnComplete { get; set; }

        public UIFaderTransitionOption FaderOption { get; set; }
    }

    public class UIManager : PersistentSingleton<UIManager>
    {
        [SerializeField] private Camera uiCamera;

        [SerializeField] private Transform popupRoot;
        [SerializeField] private Transform screenRoot;
        [SerializeField] private Transform hudRoot;

        [SerializeField] private GameObject blockObject;

        [Header("Effects")]
        [SerializeField] private Canvas effectCanvas;
        [SerializeField] private RectTransform effectRoot;

        [SerializeField] private Transform loadingRoot;

        [Header("Addressable Image Loading")]
        [SerializeField] private bool useGlobalAddressableLoading = true;
        [SerializeField] private AddressableLoadingView addressableLoadingViewPrefab;
        [SerializeField] private int addressableLoadingPrewarmCount = 4;
        [SerializeField] private float addressableLoadingShowDelay = 0.08f;

        private GameObject _currentLoadingUI;
        private UIInstanceOwner _loadingInstances;
        private UniTaskCompletionSource<GameObject> _loadingTask;
        private int _loadingVersion;
        private string _loadingKey;
        // ShowLoadingUIAsync 호출은 세션 없이 화면을 소유하며 HideLoadingUI가 끝낸다.
        private bool _loadingRequested;
        private readonly List<UILoadingSession> _loadingSessions=new();
        private GameObject _loadingViewOwner;
        private IUILoadingProgressView _loadingView;
        private bool _uiInitialized;
        private int _uiVersion;
        private async UniTask<GameObject> CreateLoadingAsync(string key,int version,UIInstanceOwner owner)
        {
            var instance=await owner.InstantiateAsync(key);
            if(version!=_loadingVersion||!this){if(instance)owner.Release(instance);return null;}
            _currentLoadingUI=instance;return instance;
        }
        private async UniTask CompleteLoadingAsync(string key,int version,UIInstanceOwner owner,UniTaskCompletionSource<GameObject> pending)
        {
            GameObject instance=null;Exception failure=null;
            try{instance=await CreateLoadingAsync(key,version,owner);}
            catch(Exception e){failure=e;}
            // 완료된 대기를 먼저 지워 결과를 받은 흐름의 재호출이 새 로드를 시작하게 한다.
            if(ReferenceEquals(_loadingTask,pending))_loadingTask=null;
            if(failure!=null)pending.TrySetException(failure);else pending.TrySetResult(instance);
        }
        private void DisposeManagers()
        {
            _uiVersion++;_isHudRefreshPending=false;
            if(mInputDelay!=null){StopCoroutine(mInputDelay);mInputDelay=null;}
            CloseLoadingSessions();
            _loadingVersion++;_loadingTask=null;_currentLoadingUI=null;_loadingKey=null;_loadingRequested=false;
            _loadingInstances?.Dispose();_loadingInstances=null;
            screenManager?.Dispose();popupManager?.Dispose();hudManager?.Dispose();
            AddressableLoadingViews?.Dispose();AddressableLoadingViews=null;
            blockerCounter.Clear();if(blockObject)blockObject.SetActive(false);
            _uiInitialized=false;
        }
        private void OnDisable(){if(Application.isPlaying)DisposeManagers();}
        private void OnEnable(){if(Application.isPlaying&&_enabled&&!_uiInitialized&&screenRoot&&popupRoot&&hudRoot)Init();}
        public Transform EffectRoot => effectRoot;

        public AddressableLoadingViewService AddressableLoadingViews { get; private set; }

        /// <summary>
        /// 소유자 구분 없이 전체 화면 로딩을 표시한다. 이미 표시 중이면 다른 키는 무시하고 같은 인스턴스를 돌려준다.
        /// 여러 호출자가 함께 쓰는 로딩에는 <see cref="AcquireLoadingAsync"/>를 사용한다.
        /// </summary>
        public async UniTask<GameObject> ShowLoadingUIAsync(string addressableKey)
        {
            var loading=EnsureLoadingAsync(addressableKey);
            _loadingRequested=true;
            int version=_loadingVersion;
            try{return await loading;}
            // 닫힌 뒤 도착한 실패는 그 뒤의 새 표시가 세운 소유를 지우지 않는다.
            catch{if(version==_loadingVersion)_loadingRequested=false;throw;}
        }

        /// <summary>
        /// 전체 화면 로딩을 강제로 닫는다. 소유자와 무관하게 닫으며, 남아 있는 세션도 모두 끝난다.
        /// </summary>
        public void HideLoadingUI()
        {
            CloseLoadingSessions();
            CloseLoading();
        }

        /// <summary>
        /// 전체 화면 로딩의 소유 세션을 얻는다. 세션이 남아 있는 동안 화면이 유지되고 마지막 Dispose가 닫는다.
        /// 표시 중인 로딩과 키가 다르면 경고하고 표시 중인 화면을 공유한다.
        /// 대기 중 HideLoadingUI로 닫히면 비활성 세션을 돌려주고, 토큰 취소는 이 호출의 세션만 끝낸다.
        /// </summary>
        public async UniTask<UILoadingSession> AcquireLoadingAsync(string addressableKey,CancellationToken token=default)
        {
            if(string.IsNullOrEmpty(addressableKey))throw new ArgumentException("A loading key is required.",nameof(addressableKey));
            token.ThrowIfCancellationRequested();
            var loading=EnsureLoadingAsync(addressableKey);
            if(_loadingKey!=addressableKey)Debug.LogWarning($"[UIManager] Loading key differs from the shown loading; sharing it. shown:{_loadingKey}, requested:{addressableKey}");
            var session=new UILoadingSession(this,addressableKey);
            _loadingSessions.Add(session);
            try
            {
                var instance=await loading.AttachExternalCancellation(token);
                if(!instance)session.Dispose();
                return session;
            }
            catch{session.Dispose();throw;}
        }

        private UniTask<GameObject> EnsureLoadingAsync(string key)
        {
            if(_currentLoadingUI)return UniTask.FromResult(_currentLoadingUI);
            if(_loadingInstances==null)throw new InvalidOperationException("Initialize UIManager with a loading root first.");
            var pending=_loadingTask;
            if(pending==null)
            {
                pending=_loadingTask=new UniTaskCompletionSource<GameObject>();
                _loadingKey=key;
                CompleteLoadingAsync(key,_loadingVersion,_loadingInstances,pending).Forget();
            }
            return pending.Task;
        }

        private void CloseLoading()
        {
            _loadingVersion++;_loadingTask=null;_loadingKey=null;_loadingRequested=false;
            if(_currentLoadingUI)_loadingInstances?.Release(_currentLoadingUI);
            _currentLoadingUI=null;
        }

        private void CloseLoadingSessions()
        {
            foreach(var session in _loadingSessions)session.Close();
            _loadingSessions.Clear();
        }

        internal void ReleaseLoadingSession(UILoadingSession session)
        {
            if(!_loadingSessions.Remove(session))return;
            if(_loadingSessions.Count>0)PushLoadingProgress();
            else if(!_loadingRequested)CloseLoading();
        }

        // 세션이 여럿이면 보고한 세션 중 가장 낮은 값을 표시해 모두 끝나기 전에 가득 차지 않게 한다.
        internal void PushLoadingProgress()
        {
            var view=ResolveLoadingView();
            if(view==null)return;
            float progress=1f;bool reported=false;
            foreach(var session in _loadingSessions)
            {
                if(!session.HasProgress)continue;
                reported=true;progress=Mathf.Min(progress,session.Progress);
            }
            if(reported)view.SetProgress(progress);
        }

        internal void PushLoadingMessage(string message)=>ResolveLoadingView()?.SetMessage(message);

        private IUILoadingProgressView ResolveLoadingView()
        {
            if(!_currentLoadingUI)return null;
            if(_loadingViewOwner!=_currentLoadingUI)
            {
                _loadingViewOwner=_currentLoadingUI;
                _loadingView=_currentLoadingUI.GetComponentInChildren<IUILoadingProgressView>(true);
            }
            return _loadingView is UnityEngine.Object view&&!view?null:_loadingView;
        }

        /// <summary>
        /// 특정 대상의 로컬 축을 기준으로 UI 이펙트를 재생한다.
        /// </summary>
        public static EffectHandle PlayUIEffect(string effectName, Transform target, Vector3 localOffset = default)
        {
            if (!HasInstance || !Instance.isActiveAndEnabled || target == null) return null;

            Transform root = null;

            if (Instance.popupManager.ActivePopups.Count == 0)
                root = Instance.screenManager.CurrentScreen?.EffectRoot;

            if (root == null)
                root = Instance.effectRoot;

            EffectRequest effectRequest = EffectRequest.Default;
            effectRequest.effectType = effectName;
            effectRequest.parent = root;

            effectRequest.localPosition = root.InverseTransformPoint(target.TransformPoint(localOffset));

            return EffectManager.Instance.Play(effectRequest);
        }

        public static EffectHandle PlayScreenEffect(string effectName, Transform target, Vector3 localOffset = default)
        {
            if (!HasInstance || !Instance.isActiveAndEnabled || target == null) return null;

            Transform root = null;

            root = Instance.screenManager.CurrentScreen?.EffectRoot;

            if (root == null)
                root = Instance.effectRoot;

            EffectRequest effectRequest = EffectRequest.Default;
            effectRequest.effectType = effectName;
            effectRequest.parent = root;

            effectRequest.localPosition = root.InverseTransformPoint(target.TransformPoint(localOffset));

            return EffectManager.Instance.Play(effectRequest);
        }

        public KeyReferenceCounter blockerCounter { get; private set; } = new();
        public Camera UICamera => uiCamera;

        public UIScreenManager screenManager { get; private set; }
        public UIPopupManager popupManager { get; private set; }
        public UIHudManager hudManager { get; private set; }

        public UIPreTransitionService preTransitionService { get; private set; }

        private Coroutine mInputDelay;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStaticState(){_instance=null;applicationIsQuitting=false;}

        private bool IsCurrentUI(int version) => this && isActiveAndEnabled && version==_uiVersion;
        private bool IsTutorialBackInputBlocked()
        {
            return UINavigationOptions.IsBackInputBlocked?.Invoke() ?? false;
        }

        protected override void InitializeSingleton()
        {
            base.InitializeSingleton();

            if (_enabled)
                Init();
        }

        public virtual void Init()
        {
            DisposeManagers();
            if(loadingRoot)_loadingInstances=new UIInstanceOwner(loadingRoot);
            AddressableLoadingViews?.Dispose();
            AddressableLoadingViews = null;

            if (useGlobalAddressableLoading && addressableLoadingViewPrefab != null && loadingRoot != null)
            {
                AddressableLoadingViews = new AddressableLoadingViewService(
                    addressableLoadingViewPrefab,
                    loadingRoot,
                    addressableLoadingPrewarmCount,
                    addressableLoadingShowDelay);
            }

            screenManager = new UIScreenManager(screenRoot);
            popupManager = new UIPopupManager(popupRoot, EnbaleBlocker, DisableBlocker);
            hudManager = new UIHudManager(hudRoot, 90, 140);

            preTransitionService = new UIPreTransitionService();
            UINavigationOptions.ConfigureTransitions?.Invoke(preTransitionService);
            _uiInitialized=true;
        }

        #region Blocker Control
        private void EnbaleBlocker(string blockKey)
        {
            blockerCounter.Enable(blockKey);
            if (blockObject != null) blockObject.SetActive(blockerCounter.IsEnable());
        }

        private void DisableBlocker(string blockKey)
        {
            blockerCounter.Disable(blockKey);
            if (blockObject != null) blockObject.SetActive(blockerCounter.IsEnable());
        }
        #endregion

        #region HUD Control
        private bool _isHudRefreshPending = false;

        /// <summary>
        /// 새로 열린 UI의 HUD 설정에 맞춰 HUD를 갱신한다.
        /// </summary>
        public void UpdateGlobalHudState(UIBase openedUI)
        {
            UIHudSettings settings = null;

            if (openedUI is UIScreen screen) settings = screen.hudSettings;
            else if (openedUI is UIPopup popup) settings = popup.hudSettings;
            else return;

            switch (settings.displayMode)
            {
                case UIHudDisplayMode.KeepPrevious:
                    return;

                case UIHudDisplayMode.RequireSpecific:
                    hudManager.ShowHuds(settings.requiredHuds, openedUI);
                    break;

                case UIHudDisplayMode.ForceHide:
                    hudManager.HideAll();
                    break;
            }
        }

        public void RefreshGlobalHudState()
        {
            if (_isHudRefreshPending) return;

            _isHudRefreshPending = true;
            _ProcessHudRefreshAsync().Forget();
        }

        private async UniTaskVoid _ProcessHudRefreshAsync()
        {
            int version=_uiVersion;
            await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);
            if(version!=_uiVersion)return;
            _isHudRefreshPending = false;

            if (this == null || popupManager == null || screenManager == null) return;

            var topPopup = popupManager.GetTopPopup();

            if (topPopup != null && topPopup.hudSettings != null && topPopup.hudSettings.displayMode != UIHudDisplayMode.KeepPrevious)
            {
                UpdateGlobalHudState(topPopup);
            }
            else if (screenManager.CurrentScreen != null)
            {
                UpdateGlobalHudState(screenManager.CurrentScreen);
            }
            else
            {
                hudManager.HideAll();
            }
        }
        #endregion

        private bool IsPreTransitionSuccess(UIPreTransitionResult result)
        {
            if (result == null)
                return true;

            if (result.success)
                return true;

            Debug.LogWarning($"[UIManager] UI PreTransition Failed. errorCode:{result.errorCode}");
            return false;
        }

        private async UniTask<bool> RequestScreenPreTransitionAsync(string screenType, IScreenData screenData)
        {
            if (preTransitionService == null)
                return true;

            var result = await preTransitionService.RequestScreenAsync(screenType, screenData);
            return IsPreTransitionSuccess(result);
        }

        private async UniTask<bool> RequestPopupPreTransitionAsync(string popupType, IPopupData popupData)
        {
            if (preTransitionService == null)
                return true;

            var result = await preTransitionService.RequestPopupAsync(popupType, popupData);
            return IsPreTransitionSuccess(result);
        }

        #region FadeScreen
        [SerializeField] private UIFader uiFader;
        public UIFader Fader => uiFader;

        public bool IsFading => uiFader != null && uiFader.IsFading;

        public bool RunUITransition(
            Func<UniTask> midTask,
            Action endAction = null,
            UIFaderTransitionOption faderOption = null)
        {
            if (uiFader == null)
            {
                RunWithoutFaderAsync(midTask, endAction).Forget();
                return true;
            }

            if (uiFader.IsFading)
                return false;

            uiFader.PlayTransitionAsync(
                midTask ?? (async () => await UniTask.Yield()),
                endAction,
                faderOption
            ).Forget();

            return true;
        }

        private async UniTaskVoid RunWithoutFaderAsync(Func<UniTask> midTask, Action endAction)
        {
            int version=_uiVersion;
            if (midTask != null)
                await midTask();

            if(IsCurrentUI(version))endAction?.Invoke();
        }

        public bool FadeInOutScreen(
            Func<UniTask> midTask,
            Action endAction = null,
            Color? color = null,
            float duration = 0.3f)
        {
            Color fadeColor = color ?? Color.black;

            return RunUITransition(
                midTask,
                endAction,
                UIFaderTransitionOption.ColorFade(fadeColor, duration)
            );
        }
        #endregion

        #region Screen
        public bool ChangeUIScreen(
            string screenType,
            IScreenData screenData = null,
            UITransitionOption option = null)
        {
            int uiVersion=_uiVersion;
            if (!UINavigationOptions.CanOpenScreen(screenType)) return false;

            option ??= new UITransitionOption();

            return RunUITransition(async () =>
            {
                bool requestSuccess = await RequestScreenPreTransitionAsync(screenType, screenData);
                if (!requestSuccess || !IsCurrentUI(uiVersion))
                    return;

                if (option.CloseAllPopup)
                    popupManager.ForceCloseAllPopups();

                var shown = await screenManager.ChangeUIScreenAsync(screenType, screenData, option.IsPooling);
                if(shown==null || !IsCurrentUI(uiVersion))return;

                option.OnComplete?.Invoke();
            },
            null,
            option.FaderOption);
        }

        public bool SpawnUIScreen(
            string screenType,
            IScreenData screenData = null,
            UITransitionOption option = null)
        {
            int uiVersion=_uiVersion;
            if (!UINavigationOptions.CanOpenScreen(screenType)) return false;

            option ??= new UITransitionOption();

            return RunUITransition(async () =>
            {
                bool requestSuccess = await RequestScreenPreTransitionAsync(screenType, screenData);
                if (!requestSuccess || !IsCurrentUI(uiVersion))
                    return;

                if (option.CloseAllPopup)
                    popupManager.ForceCloseAllPopups();

                var shown = await screenManager.SpawnUIScreenAsync(screenType, screenData, option.IsPooling);
                if(shown==null || !IsCurrentUI(uiVersion))return;

                option.OnComplete?.Invoke();
            },
            null,
            option.FaderOption);
        }


        public bool PrevUIScreen(UITransitionOption option = null)
        {
            int uiVersion=_uiVersion;
            if (!screenManager.TryGetPreviousScreen(out string prevScreenType, out IScreenData prevScreenData))
                return false;

            option ??= new UITransitionOption();

            return RunUITransition(async () =>
            {
                bool requestSuccess = await RequestScreenPreTransitionAsync(prevScreenType, prevScreenData);
                if (!requestSuccess || !IsCurrentUI(uiVersion))
                    return;

                if (option.CloseAllPopup)
                    popupManager.ForceCloseAllPopups();

                var shown = await screenManager.PrevUIScreen(option.IsPooling);
                if(shown==null || !IsCurrentUI(uiVersion))return;

                option.OnComplete?.Invoke();
            },
            null,
            option.FaderOption);
        }
        #endregion

        #region Popup
        public bool SpawnUIPopup_FadeInOut(
             string popupType,
             IPopupData popupData,
             bool checkSamePopup = true,
             bool doAddToList = true,
             UIFaderTransitionOption faderOption = null)
        {
            int popupVersion=popupManager.RequestVersion;
            int uiVersion=_uiVersion;
            if (!UINavigationOptions.CanOpenPopup(popupType)) return false;

            return RunUITransition(async () =>
            {
                bool requestSuccess = await RequestPopupPreTransitionAsync(popupType, popupData);
            if(popupVersion!=popupManager.RequestVersion)throw new OperationCanceledException();
                if (!requestSuccess || !IsCurrentUI(uiVersion))
                    return;

                await popupManager.RequestPopup(popupType, popupData, checkSamePopup, doAddToList);
            },
            null,
            faderOption);
        }

        public bool CloseUIPopup_FadeInOut(
            UIPopup popup,
            UIFaderTransitionOption faderOption = null)
        {
            return RunUITransition(async () =>
            {
                popup.ClosePopup();
                await UniTask.Yield();
            },
            null,
            faderOption);
        }

        public void SpawnUIPopup(string popupType, IPopupData popupData = null, bool checkSamePopup = true, bool doAddToList = true)
        {
            SpawnUIPopupAsync(popupType, popupData, checkSamePopup, doAddToList).Forget();
        }

        public async UniTask<UIPopup> SpawnUIPopupAsync(string popupType, IPopupData popupData = null, bool checkSamePopup = true, bool doAddToList = true)
        {
            int popupVersion=popupManager.RequestVersion;
            int uiVersion=_uiVersion;
            if (!UINavigationOptions.CanOpenPopup(popupType)) return null;

            bool requestSuccess = await RequestPopupPreTransitionAsync(popupType, popupData);
            if(popupVersion!=popupManager.RequestVersion)throw new OperationCanceledException();
            if (!requestSuccess || !IsCurrentUI(uiVersion))
                return null;

            return await popupManager.RequestPopup(popupType, popupData, checkSamePopup, doAddToList);
        }
        #endregion

        public virtual void Refresh()
        {
            popupManager.Refresh();
            screenManager.Refresh();
        }

        void Update()
        {
            if (IsTutorialBackInputBlocked())
                return;

            if (mInputDelay == null)
            {
                if (Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame)
                {
                    mInputDelay = StartCoroutine(_InputDelay(() => { HandleBackButtonAsync().Forget(); }));
                }
#if UNITY_EDITOR
                if (Keyboard.current != null && Keyboard.current.backspaceKey.wasPressedThisFrame)
                {
                    mInputDelay = StartCoroutine(_InputDelay(() => { HandleBackButtonAsync().Forget(); }));
                }
#endif
            }
        }

        private IEnumerator _InputDelay(Action action)
        {
            action?.Invoke();

            yield return new WaitForSecondsRealtime(0.3f);

            mInputDelay = null;
        }

        public async UniTask HandleBackButtonAsync()
        {
            int uiVersion=_uiVersion;
            if (IsTutorialBackInputBlocked())
                return;

            if (IsFading || blockerCounter.IsEnable())
                return;

            var topPopup = popupManager.GetTopPopup();

            if (topPopup != null)
            {
                if (topPopup.IsTransitioning)
                    return;

                bool canClose=await topPopup.OnBackRequestAsync();
                if (canClose && topPopup && IsCurrentUI(uiVersion))
                {
                    topPopup.ClosePopup();
                }
                return;
            }

            var currentScreen = screenManager.CurrentScreen;
            if (currentScreen != null)
            {
                bool canClose=await currentScreen.OnBackRequestAsync();
                if (canClose && currentScreen && IsCurrentUI(uiVersion))
                {
                    if (screenManager.IsCanPrev())
                        PrevUIScreen();
                    else
                        SpawnExitConfirmPopup();
                }
                return;
            }

            SpawnExitConfirmPopup();
        }

        protected override void OnDestroy()
        {
            DisposeManagers();
            AddressableLoadingViews?.Dispose();
            AddressableLoadingViews = null;

            base.OnDestroy();
        }

        private void SpawnExitConfirmPopup() => RequestExitAsync().Forget();
        private async UniTask RequestExitAsync()
        {
            var confirm = UINavigationOptions.ConfirmExitAsync ?? throw new InvalidOperationException("Configure UINavigationOptions.ConfirmExitAsync for the game's exit confirmation UI.");
            using var lifetime = CancellationTokenSource.CreateLinkedTokenSource(this.GetCancellationTokenOnDestroy());
            void CancelOnSceneChange(UnityEngine.SceneManagement.Scene previous, UnityEngine.SceneManagement.Scene next) => lifetime.Cancel();
            UnityEngine.SceneManagement.SceneManager.activeSceneChanged += CancelOnSceneChange;
            try
            {
                if (!await confirm(lifetime.Token)) return;
                await UniTask.NextFrame(lifetime.Token, cancelImmediately: true);
                Application.Quit();
            }
            catch (OperationCanceledException) { }
            finally { UnityEngine.SceneManagement.SceneManager.activeSceneChanged -= CancelOnSceneChange; }
        }
    }
}
