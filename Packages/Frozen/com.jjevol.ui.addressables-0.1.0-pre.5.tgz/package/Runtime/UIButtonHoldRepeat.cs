using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace jjevol
{
    /// <summary>Repeats a Unity Button's click while it is held. A lock turns the Button off, so it also stops the repeat.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Button))]
    public class UIButtonHoldRepeat : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        [SerializeField, Min(0f)] private float holdDelay = 0.4f;
        [SerializeField, Min(0.01f)] private float repeatInterval = 0.12f;

        private Button _button;
        private bool _isPointerDown;
        private bool _holdStarted;
        private bool _cancelNativeClick;
        private bool _isRepeatPaused;
        private bool _resumeImmediately;
        private int _pointerId = int.MinValue;
        private float _holdTime;
        private float _nextRepeatTime;

        private void Awake() => _button = GetComponent<Button>();

        private void OnDisable()
        {
            _isRepeatPaused = false;
            _resumeImmediately = false;
            ResetPressState();
        }

        private void Update()
        {
            if (!_isPointerDown || _isRepeatPaused) return;

            _holdTime += Time.unscaledDeltaTime;

            if (!CanInvokeClick())
            {
                _cancelNativeClick = true;
                if (_holdStarted) _nextRepeatTime = _holdTime;
                return;
            }

            if (_resumeImmediately && _holdStarted)
            {
                _resumeImmediately = false;
                InvokeClick();
                return;
            }

            if (!_holdStarted)
            {
                if (_holdTime < holdDelay) return;

                _holdStarted = true;
                InvokeClick();
                return;
            }

            if (_holdTime >= _nextRepeatTime) InvokeClick();
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left || !CanInvokeClick()) return;

            _isPointerDown = true;
            _holdStarted = false;
            _cancelNativeClick = false;
            _resumeImmediately = false;
            _pointerId = eventData.pointerId;
            _holdTime = 0f;
            _nextRepeatTime = holdDelay;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (_pointerId != eventData.pointerId) return;

            if (_holdStarted || _cancelNativeClick) eventData.eligibleForClick = false;

            ResetPressState();
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (!_isPointerDown || _pointerId != eventData.pointerId) return;

            _isPointerDown = false;
            _cancelNativeClick = true;
        }

        public void SetRepeatPaused(bool paused, bool resumeImmediately = true)
        {
            _isRepeatPaused = paused;

            if (paused)
            {
                if (_isPointerDown) _cancelNativeClick = true;
                _resumeImmediately = false;
                return;
            }

            if (_isPointerDown && _holdStarted && resumeImmediately) _resumeImmediately = true;
        }

        private bool CanInvokeClick() => _button.isActiveAndEnabled && _button.IsInteractable();

        private void InvokeClick()
        {
            _nextRepeatTime = _holdTime + repeatInterval;
            _button.onClick?.Invoke();
        }

        private void ResetPressState()
        {
            _isPointerDown = false;
            _holdStarted = false;
            _cancelNativeClick = false;
            _resumeImmediately = false;
            _pointerId = int.MinValue;
            _holdTime = 0f;
            _nextRepeatTime = 0f;
        }
    }
}
