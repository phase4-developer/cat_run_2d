using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace jjevol
{
    // Only UI's direct SDK InstantiateAsync handles. This is distinct from general-loader prefab leases/clones.
    internal sealed class UIInstanceOwner : IDisposable
    {
        private readonly Transform _parent;
        private readonly Dictionary<GameObject,AsyncOperationHandle<GameObject>> _instances=new();
        private readonly UIInstanceRootLifetime _rootLifetime;
        private bool _disposed;
        public UIInstanceOwner(Transform parent)
        {
            _parent=parent ? parent : throw new ArgumentNullException(nameof(parent));
            _rootLifetime=parent.GetComponent<UIInstanceRootLifetime>() ?? parent.gameObject.AddComponent<UIInstanceRootLifetime>();
            _rootLifetime.hideFlags=HideFlags.DontSave;
            _rootLifetime.Destroyed+=Dispose;
        }
        public async UniTask<GameObject> InstantiateAsync(string key)
        {
            if(_disposed||!_parent)return null;
            var operation=Addressables.InstantiateAsync(key,_parent);
            GameObject instance;
            try { instance=await operation; }
            catch { if(operation.IsValid())Addressables.Release(operation); throw; }
            if(_disposed||!_parent||!instance)
            {
                if(operation.IsValid())Addressables.ReleaseInstance(operation);
                return null;
            }
            _instances.Add(instance,operation);
            var lifetime=instance.GetComponent<UIInstanceReturnOnDestroy>() ?? instance.AddComponent<UIInstanceReturnOnDestroy>();
            lifetime.hideFlags=HideFlags.DontSave;
            lifetime.Return=()=>Release(instance);
            return instance;
        }
        public void Release(GameObject instance)
        {
            if(ReferenceEquals(instance,null)||!_instances.Remove(instance,out var operation))return;
            if(operation.IsValid())Addressables.ReleaseInstance(operation);
        }
        public void Dispose()
        {
            if(_disposed)return;_disposed=true;
            if(_rootLifetime)_rootLifetime.Destroyed-=Dispose;
            foreach(var operation in _instances.Values)if(operation.IsValid())Addressables.ReleaseInstance(operation);
            _instances.Clear();
        }
    }
    internal sealed class UIInstanceRootLifetime : MonoBehaviour
    {
        internal event Action Destroyed;
        private void OnDestroy(){var callback=Destroyed;Destroyed=null;callback?.Invoke();}
    }
    internal sealed class UIInstanceReturnOnDestroy : MonoBehaviour
    {
        internal Action Return;
        private void OnDestroy(){var callback=Return;Return=null;ReturnAfterFrame(callback).Forget();}
        private static async UniTaskVoid ReturnAfterFrame(Action callback)
        { await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);callback?.Invoke(); }
    }
}
