using Cysharp.Threading.Tasks;
using System;
using System.Threading;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.U2D;
using UnityEngine.UI;

namespace jjevol
{
    [ExecuteAlways]
    public class AddressableImage : Image
    {
        public event Action OnChangeSprite;

        [FormerlySerializedAs("m_AtlasTag")]
        [SerializeField] private string m_AtlasKey;

        [FormerlySerializedAs("m_spriteName")]
        [SerializeField] private string m_SpriteName;

        [Header("Runtime")]
        [SerializeField] private bool m_LoadOnEnable = true;
        [SerializeField] private bool m_ReleaseOnDisable = false;
        [SerializeField] private bool m_ClearSpriteOnDisable = false;
        [SerializeField] private float m_ReleaseDelay = 0f;

        [Header("Loading")]
        [SerializeField] private bool m_ShowLoading = false;
        [SerializeField] private AddressableLoadingView m_LoadingView;

        private readonly AddressableImageLoadState _load = new AddressableImageLoadState();
        private SpriteAtlas _runtimeAtlas;
        private Sprite _ownedRuntimeSprite;
        private string _appliedSpriteName;
        private string _loadedAtlasKey;

        private bool _hideRuntimeGraphic;

#if UNITY_EDITOR
        [NonSerialized] private Sprite _editorPreviewSprite;
        [NonSerialized] private bool _ownsEditorPreviewSprite;
#endif

        /// <summary>
        /// 활성화된 적 없어 로드가 첫 활성화까지 미뤄진 상태다. 이때 sprite가 비어 있는 것은 실패가 아니다.
        /// </summary>
        public bool IsLoadDeferred => _load.IsDeferred;

        public string atlasKey
        {
            get => m_AtlasKey;
            set
            {
                if (m_AtlasKey == value)
                {
                    if (!Application.isPlaying || _load.IsLoading(value))
                        return;

                    if (isActiveAndEnabled && _runtimeAtlas == null && !string.IsNullOrEmpty(m_AtlasKey))
                    {
                        LoadAtlasAsync(m_AtlasKey).Forget();
                        return;
                    }

                    // LoadAtlasAsync와 같은 규칙이다. 현재 키를 다시 넣으면 진행 중인 다른 키의 로드는 버려진다.
                    _load.CancelInProgress();
                    return;
                }

                m_AtlasKey = value;

                if (Application.isPlaying && isActiveAndEnabled)
                    LoadAtlasAsync(m_AtlasKey).Forget();

#if UNITY_EDITOR
                if (!Application.isPlaying)
                    RefreshEditorPreview();
#endif
            }
        }

        public string atlasTag
        {
            get => atlasKey;
            set => atlasKey = value;
        }

        public string spriteName
        {
            get => m_SpriteName;
            set
            {
                string normalizedName = NormalizeSpriteName(value);
                if (m_SpriteName == normalizedName)
                {
                    if (Application.isPlaying && sprite == null)
                    {
                        if (_runtimeAtlas == null && !string.IsNullOrEmpty(m_AtlasKey))
                        {
                            if (!_load.IsLoading(m_AtlasKey))
                                LoadAtlasAsync(m_AtlasKey).Forget();
                        }
                        else
                        {
                            ApplyRuntimeSpriteFromAtlas();
                        }
                    }

                    return;
                }

                m_SpriteName = normalizedName;

                if (Application.isPlaying)
                {
                    if (_runtimeAtlas == null && !string.IsNullOrEmpty(m_AtlasKey))
                    {
                        if (!_load.IsLoading(m_AtlasKey))
                            LoadAtlasAsync(m_AtlasKey).Forget();

                        return;
                    }

                    ApplyRuntimeSpriteFromAtlas();
                }
#if UNITY_EDITOR
                else
                {
                    RefreshEditorPreview();
                }
#endif
            }
        }

        public float alpha
        {
            get => color.a;
            set
            {
                var c = color;
                c.a = value;
                color = c;
            }
        }

        public override Texture mainTexture
        {
            get
            {
#if UNITY_EDITOR
                if (!Application.isPlaying && _editorPreviewSprite != null)
                    return _editorPreviewSprite.texture;
#endif
                return base.mainTexture;
            }
        }

        protected override void Awake()
        {
            base.Awake();

            _load.MarkAwoken();

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                CaptureAndClearSourceSpriteIfNeeded();
                RefreshEditorPreview();
                return;
            }
#endif

            if (sprite != null && string.IsNullOrEmpty(m_SpriteName))
                m_SpriteName = NormalizeSpriteName(sprite.name);
        }

        protected override void OnEnable()
        {
            base.OnEnable();

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                CaptureAndClearSourceSpriteIfNeeded();
                RefreshEditorPreview();
                return;
            }
#endif

            bool deferred = _load.ConsumeDeferred();

            if ((m_LoadOnEnable || deferred) && !string.IsNullOrEmpty(m_AtlasKey))
                LoadAtlasAsync(m_AtlasKey).Forget();
            else if (_runtimeAtlas != null)
                ApplyRuntimeSpriteFromAtlas();
            else
                SetRuntimeGraphicHidden(true);
        }

        protected override void OnDisable()
        {
            _load.Cancel();

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                // 코드로 넣은 Sprite의 키를 잃지 않도록 비우기 전에 기록한다. 직렬화 참조는 남지 않는다.
                CaptureAndClearSourceSpriteIfNeeded();
                base.OnDisable();
                return;
            }
#endif

            if (m_ReleaseOnDisable)
            {
                ReleaseCurrentAtlas();
            }
            else if (m_ClearSpriteOnDisable)
            {
                sprite = null;
            }

            base.OnDisable();
        }

        protected override void OnDestroy()
        {
            _load.Cancel();
#if UNITY_EDITOR
            if(!Application.isPlaying)ClearOwnedEditorPreview();
#endif

            if (Application.isPlaying)
                ReleaseCurrentAtlas();

            base.OnDestroy();
        }

        protected override void OnDidApplyAnimationProperties()
        {
            base.OnDidApplyAnimationProperties();

            if (Application.isPlaying && sprite == null && !string.IsNullOrEmpty(m_SpriteName))
                ApplyRuntimeSpriteFromAtlas();
        }

#if UNITY_EDITOR
        protected override void OnValidate()
        {
            base.OnValidate();

            if (!Application.isPlaying)
            {
                CaptureAndClearSourceSpriteIfNeeded();
                RefreshEditorPreview();
            }
        }
#endif

        protected override void OnPopulateMesh(VertexHelper toFill)
        {
#if UNITY_EDITOR
            if (!Application.isPlaying && _editorPreviewSprite != null)
            {
                AddressablePreviewMesh.Populate(toFill, this, _editorPreviewSprite, preserveAspect);
                return;
            }
#endif

            if (Application.isPlaying && _hideRuntimeGraphic && overrideSprite == null)
            {
                toFill.Clear();
                return;
            }

            base.OnPopulateMesh(toFill);
        }

        public void SetSprite(string name)
        {
            spriteName = name;
        }

        public void SetAtlasSprite(string newAtlasKey, string newSpriteName)
        {
            bool atlasChanged = m_AtlasKey != newAtlasKey;

            m_AtlasKey = newAtlasKey;
            m_SpriteName = NormalizeSpriteName(newSpriteName);

            if (!Application.isPlaying)
            {
#if UNITY_EDITOR
                RefreshEditorPreview();
#endif
                return;
            }

            if (atlasChanged)
                LoadAtlasAsync(m_AtlasKey).Forget();
            else
                ApplyRuntimeSpriteFromAtlas();
        }

        public async UniTask LoadAtlasAsync(string key, CancellationToken externalToken = default)
        {
            if (string.IsNullOrEmpty(key))
            {
                _load.Cancel();
                ReleaseCurrentAtlas();
                return;
            }

            if (_load.IsLoading(key))
            {
                await _load.WaitAsync(externalToken);
                return;
            }

            if (_runtimeAtlas != null && _loadedAtlasKey == key)
            {
                _load.Cancel();
                m_AtlasKey = key;
                ApplyRuntimeSpriteFromAtlas();
                return;
            }

            if (!_load.CanLoadNow)
            {
                m_AtlasKey = key;
                _load.Defer();
                return;
            }

            AddressableImageLoadState.Request request = _load.Begin(key, externalToken);
            CancellationToken token = request.Token;

            // Sprite가 없는 AddressableImage는 기본 흰 사각형을 그리므로, Atlas 적용 전에는 자기 Mesh만 숨긴다.
            // 이전 Sprite가 남아 있는 동안에는 그대로 표시하고, 자식으로 붙는 공용 로딩 뷰도 그대로 표시된다.
            SetRuntimeGraphicHidden(true);

            try
            {
                if (m_ShowLoading && AddressableImageLoadState.HasLoadingProvider(m_LoadingView))
                    _load.ShowLoading(m_LoadingView, rectTransform, token, this);

                var nextLease = await UIAssetOwnership.Acquire<SpriteAtlas>(key, token);
                SpriteAtlas loadedAtlas = nextLease?.Asset;

                if (!_load.IsCurrent(request))
                {
                    UIAssetOwnership.Return(nextLease, m_ReleaseDelay);
                    return;
                }

                if (loadedAtlas == null)
                {
                    Debug.LogWarning($"[AddressableImage] Atlas load failed. key:{key}, object:{name}");
                    return;
                }

                ReleaseCurrentAtlas();

                _load.HoldLease(nextLease);
                _runtimeAtlas = loadedAtlas;
                _loadedAtlasKey = key;
                m_AtlasKey = key;

                ApplyRuntimeSpriteFromAtlas();
            }
            finally
            {
                _load.End(request);
            }
        }

        private void SetRuntimeGraphicHidden(bool hidden)
        {
            if (!Application.isPlaying) return;
            if (_hideRuntimeGraphic == hidden) return;

            _hideRuntimeGraphic = hidden;
            SetVerticesDirty();
        }

        private void ApplyRuntimeSpriteFromAtlas()
        {
            if (!Application.isPlaying)
                return;

            // 같은 Atlas의 같은 이름이 이미 표시 중이면 복제본을 새로 만들지 않고 변경 알림도 내지 않는다.
            string nextSpriteName = NormalizeSpriteName(m_SpriteName);
            if (sprite != null && sprite == _ownedRuntimeSprite && _appliedSpriteName == nextSpriteName)
            {
                SetRuntimeGraphicHidden(false);
                return;
            }

            Sprite nextSprite = GetSpriteFromAtlas(_runtimeAtlas, m_SpriteName);

            //if (nextSprite == null)
            //{
            //    Debug.LogWarning($"[AddressableImage] Sprite not found. AtlasKey:{m_AtlasKey}, LoadedAtlas:{_loadedAtlasKey}, SpriteName:{m_SpriteName}, Object:{name}", this);
            //}

            var previous=_ownedRuntimeSprite;_ownedRuntimeSprite=nextSprite;
            _appliedSpriteName = nextSprite != null ? nextSpriteName : null;
            sprite = nextSprite;
            if(previous && previous!=nextSprite)Destroy(previous);

            SetRuntimeGraphicHidden(nextSprite == null);

            SetAllDirty();

            if (nextSprite != null)
                OnChangeSprite?.Invoke();
        }

        private static Sprite GetSpriteFromAtlas(SpriteAtlas atlas, string spriteName)
        {
            if (atlas == null) return null;
            if (string.IsNullOrEmpty(spriteName)) return null;

            string normalizedName = NormalizeSpriteName(spriteName);
            var result = atlas.GetSprite(normalizedName);

            if (result == null)
                result = atlas.GetSprite($"{normalizedName}(Clone)");

            return result;
        }

        private void ReleaseCurrentAtlas()
        {
            sprite=null;
            if(_ownedRuntimeSprite)Destroy(_ownedRuntimeSprite);_ownedRuntimeSprite=null;
            _appliedSpriteName=null;
            SetRuntimeGraphicHidden(true);
            _load.ReturnLease(m_ReleaseDelay);
            _runtimeAtlas=null;_loadedAtlasKey=string.Empty;
        }

        private static string NormalizeSpriteName(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return value.Replace("(Clone)", string.Empty);
        }

#if UNITY_EDITOR
        public void SetEditorPreviewSprite(Sprite previewSprite)
        {
            if (Application.isPlaying) return;
            if(ReferenceEquals(previewSprite,_editorPreviewSprite))return;

            ClearOwnedEditorPreview();
            _editorPreviewSprite = previewSprite;
            SetVerticesDirty();
            SetMaterialDirty();
        }

        public void RefreshEditorPreview()
        {
            if (Application.isPlaying) return;

            SpriteAtlas atlas = UIEditorPreview.LoadSpriteAtlas(m_AtlasKey);
            ClearOwnedEditorPreview();
            _editorPreviewSprite = UIEditorPreview.GetSpriteFromAtlas(atlas, m_SpriteName);
            _ownsEditorPreviewSprite = _editorPreviewSprite!=null;

            SetVerticesDirty();
            SetMaterialDirty();
        }

        public void ClearSourceSpriteReference()
        {
            if (Application.isPlaying) return;
            if (sprite == null) return;

            sprite = null;
            SetVerticesDirty();
            SetMaterialDirty();
        }

        private void CaptureAndClearSourceSpriteIfNeeded()
        {
            if (Application.isPlaying) return;
            if (sprite == null) return;

            ClearOwnedEditorPreview();
            _editorPreviewSprite = sprite;

            if (string.IsNullOrEmpty(m_SpriteName))
                m_SpriteName = NormalizeSpriteName(sprite.name);

            sprite = null;

            SetVerticesDirty();
            SetMaterialDirty();
        }

        private void ClearOwnedEditorPreview()
        {
            if(_ownsEditorPreviewSprite && _editorPreviewSprite)DestroyImmediate(_editorPreviewSprite);
            _editorPreviewSprite=null;
            _ownsEditorPreviewSprite=false;
        }
#endif
    }
}
