﻿using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

namespace jjevol
{
    public sealed class AddressableLoadingHandle : IDisposable
    {
        private AddressableLoadingViewService _service;
        private AddressableLoadingView _view;
        private RectTransform _target;
        private CancellationTokenSource _showCTS;
        private readonly float _showDelay;
        private bool _released;

        internal AddressableLoadingHandle(AddressableLoadingViewService service, RectTransform target, float showDelay, CancellationToken externalToken)
        {
            _service = service;
            _target = target;
            _showDelay = Mathf.Max(0f, showDelay);
            _showCTS = CancellationTokenSource.CreateLinkedTokenSource(externalToken);
            ShowDelayedAsync(_showCTS.Token).Forget();
        }

        private async UniTaskVoid ShowDelayedAsync(CancellationToken token)
        {
            try
            {
                float elapsed = 0f;

                while (elapsed < _showDelay)
                {
                    token.ThrowIfCancellationRequested();
                    elapsed += Time.unscaledDeltaTime;
                    await UniTask.Yield(PlayerLoopTiming.Update, token);
                }

                token.ThrowIfCancellationRequested();

                AddressableLoadingViewService service = _service;
                RectTransform target = _target;

                if (_released || service == null || target == null)
                    return;

                AddressableLoadingView view = service.AcquireView();
                if (view == null)
                    return;

                if (_released || token.IsCancellationRequested || _service != service || _target != target)
                {
                    service.Release(view);
                    return;
                }

                _view = view;
                await service.ShowAsync(view, target, token);
            }
            catch (OperationCanceledException)
            {
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"[AddressableLoadingHandle] Loading display failed. error:{exception.GetType().Name}");
            }
        }

        public void Release()
        {
            if (_released) return;

            _released = true;

            if (_showCTS != null)
            {
                _showCTS.Cancel();
                _showCTS.Dispose();
                _showCTS = null;
            }

            AddressableLoadingViewService service = _service;
            AddressableLoadingView view = _view;

            _service = null;
            _view = null;
            _target = null;

            service?.Release(view);
        }

        public void Dispose()
        {
            Release();
        }
    }

    public sealed class AddressableLoadingViewService : IDisposable
    {
        private readonly AddressableLoadingView _viewPrefab;
        private readonly Transform _poolRoot;
        private readonly float _showDelay;
        private readonly int _maxPoolCount;
        private readonly Stack<AddressableLoadingView> _pool = new Stack<AddressableLoadingView>();
        private readonly HashSet<AddressableLoadingView> _activeViews = new HashSet<AddressableLoadingView>();
        private readonly HashSet<AddressableLoadingView> _pendingReturnViews = new HashSet<AddressableLoadingView>();

        private bool _disposed;

        public bool IsAvailable => !_disposed && _viewPrefab != null && _poolRoot != null;

        public static bool IsGlobalAvailable
        {
            get
            {
                if (!UIManager.HasInstance) return false;

                UIManager manager = UIManager.Instance;
                return manager != null && manager.AddressableLoadingViews != null && manager.AddressableLoadingViews.IsAvailable;
            }
        }

        public AddressableLoadingViewService(AddressableLoadingView viewPrefab, Transform poolRoot, int prewarmCount, float showDelay)
        {
            _viewPrefab = viewPrefab;
            _poolRoot = poolRoot;
            _showDelay = Mathf.Max(0f, showDelay);

            int safePrewarmCount = Mathf.Max(0, prewarmCount);
            _maxPoolCount = Mathf.Max(1, safePrewarmCount);

            if (!IsAvailable) return;

            for (int i = 0; i < safePrewarmCount; i++)
            {
                AddressableLoadingView view = CreateView();
                if (view != null)
                    _pool.Push(view);
            }
        }

        public static AddressableLoadingHandle AcquireGlobal(RectTransform target, CancellationToken token = default)
        {
            if (target == null) return null;
            if (!UIManager.HasInstance) return null;

            UIManager manager = UIManager.Instance;
            return manager?.AddressableLoadingViews?.Acquire(target, token);
        }

        public AddressableLoadingHandle Acquire(RectTransform target, CancellationToken token = default)
        {
            if (!IsAvailable || target == null)
                return null;

            return new AddressableLoadingHandle(this, target, _showDelay, token);
        }

        internal AddressableLoadingView AcquireView()
        {
            if (!IsAvailable)
                return null;

            AddressableLoadingView view = GetView();
            if (view == null)
                return null;

            view.Hide();
            view.gameObject.SetActive(false);
            _activeViews.Add(view);
            return view;
        }

        internal async UniTask ShowAsync(AddressableLoadingView view, RectTransform target, CancellationToken token)
        {
            if (view == null || target == null || token.IsCancellationRequested)
                return;

            if (!_activeViews.Contains(view))
                return;

            PrepareView(view, target);

            if (token.IsCancellationRequested || !_activeViews.Contains(view))
                return;

            await view.ShowAsync(token);
        }

        internal void Release(AddressableLoadingView view)
        {
            if (view == null) return;
            if (!_activeViews.Remove(view)) return;

            view.Hide();
            view.gameObject.SetActive(false);

            if (_disposed || _poolRoot == null)
            {
                UnityEngine.Object.Destroy(view.gameObject);
                return;
            }

            if (view.transform.parent == _poolRoot)
            {
                ReturnOrDestroy(view);
                return;
            }

            if (_pendingReturnViews.Add(view))
                ReturnToPoolNextFrameAsync(view).Forget();
        }

        private async UniTaskVoid ReturnToPoolNextFrameAsync(AddressableLoadingView view)
        {
            await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);

            _pendingReturnViews.Remove(view);

            if (view == null)
                return;

            if (_disposed || _poolRoot == null)
            {
                UnityEngine.Object.Destroy(view.gameObject);
                return;
            }

            view.transform.SetParent(_poolRoot, false);
            ReturnOrDestroy(view);
        }

        private void ReturnOrDestroy(AddressableLoadingView view)
        {
            if (view == null)
                return;

            if (_disposed || _poolRoot == null || _pool.Count >= _maxPoolCount)
            {
                UnityEngine.Object.Destroy(view.gameObject);
                return;
            }

            _pool.Push(view);
        }

        public void Dispose()
        {
            if (_disposed) return;

            _disposed = true;

            foreach (AddressableLoadingView view in _activeViews)
            {
                if (view != null)
                    UnityEngine.Object.Destroy(view.gameObject);
            }

            _activeViews.Clear();

            foreach (AddressableLoadingView view in _pendingReturnViews)
            {
                if (view != null)
                    UnityEngine.Object.Destroy(view.gameObject);
            }

            _pendingReturnViews.Clear();

            while (_pool.Count > 0)
            {
                AddressableLoadingView view = _pool.Pop();
                if (view != null)
                    UnityEngine.Object.Destroy(view.gameObject);
            }
        }

        private AddressableLoadingView GetView()
        {
            while (_pool.Count > 0)
            {
                AddressableLoadingView pooledView = _pool.Pop();
                if (pooledView != null)
                    return pooledView;
            }

            return CreateView();
        }

        private AddressableLoadingView CreateView()
        {
            if (!IsAvailable)
                return null;

            AddressableLoadingView view = UnityEngine.Object.Instantiate(_viewPrefab, _poolRoot, false);
            view.name = _viewPrefab.name;
            view.Hide();
            view.gameObject.SetActive(false);
            return view;
        }

        private static void PrepareView(AddressableLoadingView view, RectTransform target)
        {
            view.Hide();
            view.gameObject.SetActive(false);

            RectTransform viewRect = view.transform as RectTransform;
            if (viewRect != null)
            {
                viewRect.SetParent(target, false);
                viewRect.anchorMin = Vector2.zero;
                viewRect.anchorMax = Vector2.one;
                viewRect.pivot = new Vector2(0.5f, 0.5f);
                viewRect.anchoredPosition = Vector2.zero;
                viewRect.sizeDelta = Vector2.zero;
                viewRect.localScale = Vector3.one;
            }
            else
            {
                view.transform.SetParent(target, false);
                view.transform.localPosition = Vector3.zero;
                view.transform.localRotation = Quaternion.identity;
                view.transform.localScale = Vector3.one;
            }

            view.transform.SetAsLastSibling();
            view.gameObject.SetActive(true);
        }
    }
}
