using Cysharp.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using UnityEngine;
using UnityEngine.AddressableAssets;

namespace jjevol
{
    [Serializable]
    public struct UIHudParameter
    {
        public string key;   // ��: "TitleKey", "StartIndex", "ShowBackButton"
        public string value; // ��: "UI_SHOP", "1", "true"

        // ���� �� �� ���ϰ� ���� ���� ��ƿ��Ƽ
        public int AsInt() => int.TryParse(value, out int res) ? res : 0;
        public float AsFloat() => float.TryParse(value, out float res) ? res : 0f;
        public bool AsBool() => bool.TryParse(value, out bool res) ? res : false;
    }

    [Serializable]
    public struct UIHudRequest
    {
        [UIAddressId(UIAddress.HudPrefix)] public string hudType;

        public List<UIHudParameter> parameters;
    }

    [Serializable]
    public class UIHudSettings
    {
        public UIHudDisplayMode displayMode = UIHudDisplayMode.KeepPrevious;

        // [����] �ܼ� Enum ����Ʈ�� �ƴ϶� �Ķ���͸� ������ Request ����Ʈ�� ����
        public List<UIHudRequest> requiredHuds = new List<UIHudRequest>();
    }

    public class UIHudManager : IDisposable
    {
        private readonly Transform _hudRoot;
        private readonly UIInstanceOwner _instances;
        private readonly Dictionary<string,UniTaskCompletionSource> _pending=new();
        private bool _disposed;
        private int _loadVersion;
        public void Dispose(){if(_disposed)return;_disposed=true;_loadVersion++;_pending.Clear();_instances.Dispose();hudPool.Clear();ActiveHuds.Clear();}
        private Canvas _hudCanvas;

        private int _screenHudOrder = 90;
        private int _popupHudOrder = 140;

        public Dictionary<string, UIHudBase> hudPool = new();
        public List<UIHudBase> ActiveHuds { get; private set; } = new();

        public UIHudManager(Transform hudRoot,  int screenHudOrder, int popupHudOrder)
        {
            _hudRoot = hudRoot;
            _instances=new UIInstanceOwner(hudRoot);
            _hudCanvas = _hudRoot.GetComponent<Canvas>();

            _screenHudOrder = screenHudOrder;
            _popupHudOrder = popupHudOrder;
        }

        public async UniTask CachingHudAsync(List<string> hudTypes)
        {
            if (_disposed || hudTypes == null || hudTypes.Count == 0) return;

            List<UniTask> loadTasks = new();
            foreach (var type in hudTypes)
            {
                if (string.IsNullOrEmpty(type) || hudPool.ContainsKey(type)) continue;
                if(!_pending.TryGetValue(type,out var pending)){pending=new UniTaskCompletionSource();_pending.Add(type,pending);CompleteHudLoad(type,pending).Forget();}
                loadTasks.Add(pending.Task);
            }
            await UniTask.WhenAll(loadTasks);
        }

        private async UniTask CompleteHudLoad(string type,UniTaskCompletionSource pending)
        {
            Exception failure = null;
            try { await LoadHudInstanceAsync(type); }
            catch (Exception e) { failure = e; }
            // Completion can synchronously reenter CachingHudAsync from an awaiting caller.
            if (_pending.TryGetValue(type, out var current) && ReferenceEquals(current, pending)) _pending.Remove(type);
            if (failure == null) pending.TrySetResult();
            else pending.TrySetException(failure);
        }
        private async UniTask LoadHudInstanceAsync(string type)
        {
            int version=_loadVersion;
            string key = UIAddress.Hud(type);
            GameObject instance = null;
            try
            {
                // [����] ���� HUD���� ������ GlobalHudRoot�� �ڽ����� ������ ������
                instance = await _instances.InstantiateAsync(key);
                if (!instance || _disposed || version != _loadVersion) return;
                if (instance.TryGetComponent<UIHudBase>(out var hudBase))
                {
                    instance.name = type.ToString();
                    hudBase.Init(); // �Ķ���� ���� �ܼ� �ʱ�ȭ�� ȣ��
                    if (!instance || !hudBase || _disposed || version != _loadVersion) return;
                    hudBase.HideUI();
                    if (!instance || !hudBase || _disposed || version != _loadVersion) return;
                    hudPool[type]=hudBase;
                    instance = null; // The pool now owns this SDK instance.
                }
                else throw new InvalidOperationException("The HUD prefab must contain UIHudBase.");
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[UIHudManager] Load Failed: {key} / {e.Message}");
            }
            finally
            {
                _instances.Release(instance);
            }
        }

        public void ReleaseUnusedHuds(List<string> keepTypes)
        {
            _loadVersion++;
            _pending.Clear();
            List<string> keysToRemove = new();
            foreach (var kvp in hudPool)
            {
                if (keepTypes == null || !keepTypes.Contains(kvp.Key))
                {
                    if(kvp.Value)_instances.Release(kvp.Value.gameObject);
                    ActiveHuds.Remove(kvp.Value);
                    keysToRemove.Add(kvp.Key);
                }
            }
            foreach (var key in keysToRemove) hudPool.Remove(key);
        }

        public void ShowHuds(List<UIHudRequest> requests, UIBase targetUI)
        {
            if (requests == null) requests = new List<UIHudRequest>();

            ActiveHuds.Clear();

            HashSet<string> requestTypes = new HashSet<string>();
            foreach (var req in requests) requestTypes.Add(req.hudType);

            // 1. ��Ͽ� ���� HUD ����
            foreach (var kvp in hudPool)
            {
                if (!requestTypes.Contains(kvp.Key))
                {
                    if (kvp.Value.IsVisible) kvp.Value.HideUI();
                }
            }

            // 2. ��Ͽ� �ִ� HUD�� ������� �ѱ�
            foreach (var req in requests)
            {
                if (!string.IsNullOrEmpty(req.hudType) && hudPool.TryGetValue(req.hudType, out var hud))
                {
                    // [�ٽ�] �ν����� �Ķ���� ����
                    hud.ApplyInspectorParams(req.parameters);

                    // [�ٽ�] ��Ÿ�� ������(IScreenData/IPopupData) ����
                    if (targetUI is UIScreen screen)
                        hud.ApplyRuntimeData(screen.screenData, null);
                    else if (targetUI is UIPopup popup)
                        hud.ApplyRuntimeData(null, popup.popupData);

                    if (!hud.IsVisible) hud.ShowUI();
                    else hud.Refresh();

                    // GlobalHudRoot ���ο��� ����Ʈ ������� ���̾��Ű ������ ��������
                    hud.transform.SetAsLastSibling();
                    ActiveHuds.Add(hud);
                }
            }

            if (targetUI is UIScreen) UpdateDepth(_screenHudOrder);
            else if (targetUI is UIPopup) UpdateDepth(_popupHudOrder);
        }

        public void RefreshUI()
        {
            foreach (var hud in hudPool.Values)
            {
                if (hud.IsVisible)
                    hud.Refresh();
            }
        }

        public void SetDrity()
        {
            foreach (var hud in hudPool.Values)
            {
                if (hud.IsVisible)
                    hud.SetDirty();
            }
        }

        public void UpdateDepth(int order)
        {
            if (_hudCanvas == null) return;

            _hudCanvas.sortingOrder = order;
        }

        public void HideAll()
        {
            foreach (var hud in hudPool.Values)
            {
                if (hud.IsVisible) hud.HideUI();
            }
            ActiveHuds.Clear();
        }
    }
}
