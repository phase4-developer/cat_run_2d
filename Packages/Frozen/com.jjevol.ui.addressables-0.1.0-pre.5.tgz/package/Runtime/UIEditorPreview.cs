#if UNITY_EDITOR
using System;
using UnityEngine;
using UnityEngine.U2D;
namespace jjevol
{
    // The Editor assembly owns real AssetDatabase/Addressables resolution.
    public static class UIEditorPreview
    {
        public static Func<string, SpriteAtlas> ResolveAtlas;
        public static Func<SpriteAtlas, string, Sprite> ResolveAtlasSprite;
        public static Func<string, Sprite> ResolveSprite;
        public static Func<UnityEngine.Object, string> ResolveAddress;
        public static SpriteAtlas LoadSpriteAtlas(string key) => ResolveAtlas?.Invoke(key);
        public static Sprite GetSpriteFromAtlas(SpriteAtlas atlas, string name) => ResolveAtlasSprite?.Invoke(atlas, name);
        public static Sprite LoadSprite(string key) => ResolveSprite?.Invoke(key);
        public static string GetAddressOrName(UnityEngine.Object asset) => ResolveAddress?.Invoke(asset) ?? (asset ? asset.name : string.Empty);
    }
}
#endif
