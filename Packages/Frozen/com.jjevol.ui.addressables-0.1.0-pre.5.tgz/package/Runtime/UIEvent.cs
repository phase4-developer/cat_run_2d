using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol
{
    public struct UIEvent
    {
        public UIEventTypes EventType;
        public int Param;
        public string Id;

        /// <param name="eventType">Event type.</param>
        public UIEvent(UIEventTypes eventType)
        {
            EventType = eventType;
            Param = 0;
            Id = null;
        }


        public static event Action<UIEvent> Changed;
        static UIEvent e;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            Changed = null;
            e = default;
        }
        public static void Trigger(UIEventTypes eventType)
        {
            e = new UIEvent(eventType);
            //#if UNITY_EDITOR
            //            Debug.LogWarning("UIEvent : " + eventType);
            //#endif
            Changed?.Invoke(e);
        }

        public static void Trigger(UIEventTypes eventType, int param)
        {
            e = new UIEvent(eventType);
            e.Param = param;

            //#if UNITY_EDITOR
            //           Debug.LogWarning("UIEvent : " + eventType + " screenType : " + screenType);
            //#endif
            Changed?.Invoke(e);
        }

        public static void Trigger(UIEventTypes eventType, string id)
        {
            e = new UIEvent(eventType);
            e.Id = id;
            Changed?.Invoke(e);
        }
    }
}
