using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.AddressableAssets;
using Cysharp.Threading.Tasks;

namespace jjevol
{
    public interface IScreenData
    {
    }

    public class UIScreen : UIBase
    {
        [SerializeField] private bool enableHistoryLog = true;
        [SerializeField] private UIDynamicCanvasBinder canvasBinder;
        [SerializeField] private Transform effectRoot;

        [Header("HUD Settings")]
        public UIHudSettings hudSettings = new UIHudSettings();

        [UIAddressId(UIAddress.ScreenPrefix)] public string ScreenType;

        public Transform EffectRoot => effectRoot;

        public bool EnableHistoryLog => enableHistoryLog;
        public IScreenData screenData { get; private set; }

        protected virtual void Awake()
        {
            if (!canvasBinder) canvasBinder = GetComponent<UIDynamicCanvasBinder>();
        }

        public void ShowUI(IScreenData screenData)
        {
            this.screenData = screenData;

            ShowUI();

            if (canvasBinder) canvasBinder.BindToDynamicOnce();

            if(UIManager.HasInstance)UIManager.Instance.UpdateGlobalHudState(this); // 열릴 때 상태 갱신
        }

        public override void HideUI()
        {
            base.HideUI();
            if(UIManager.HasInstance)UIManager.Instance.RefreshGlobalHudState(); // 닫힐 때 HUD 롤백 예약
        }

        public virtual void DestroyScreen()
        {
            if (m_ReleaseHandle != null)
            {
                m_ReleaseHandle.Release(this);
            }
            else
            {
                Destroy(gameObject);
            }
        }

        public virtual UniTask<bool> OnBackRequestAsync()
        {
            return UniTask.FromResult(true); // 기본은 허용
        }
    }
}