using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    [Serializable]
    public struct UIButtonImageSwap
    {
        [Tooltip("Image, AddressableImage or AddressableTexture.")]
        public Image target;

        [Tooltip("Assigned to a plain Image.")]
        public Sprite sprite;

        [Tooltip("Sprite name for AddressableImage and AddressableTexture.")]
        public string spriteName;

        public void Apply()
        {
            if (target == null) return;

            if (!string.IsNullOrEmpty(spriteName) && target is AddressableImage addressableImage) addressableImage.SetSprite(spriteName);
            else if (!string.IsNullOrEmpty(spriteName) && target is AddressableTexture addressableTexture) addressableTexture.spriteName = spriteName;
            else if (sprite != null) target.sprite = sprite;
        }
    }

    [Serializable]
    public struct UIButtonVisual
    {
        public List<UIButtonImageSwap> imageSwaps;
        public List<GameObject> enableObjects;
        public List<GameObject> disableObjects;

        public void Apply()
        {
            if (imageSwaps != null)
                foreach (var swap in imageSwaps) swap.Apply();
            SetActive(enableObjects, true);
            SetActive(disableObjects, false);
        }

        public void Revert()
        {
            SetActive(enableObjects, false);
            SetActive(disableObjects, true);
        }

        private static void SetActive(List<GameObject> objects, bool active)
        {
            if (objects == null) return;
            foreach (var target in objects)
                if (target != null) target.SetActive(active);
        }
    }

    /// <summary>
    /// Shows a different look per lock state, for buttons that need more than the Button's own Disabled transition.
    /// </summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(UIButtonLock))]
    public class UIButtonStateVisual : MonoBehaviour
    {
        [SerializeField] private UIButtonVisual normal;
        [SerializeField] private UIButtonVisual softLock;
        [SerializeField] private UIButtonVisual hardLock;

        private UIButtonLock _lock;
        private UIButtonLockState? _shown;

        private void Awake() => _lock = GetComponent<UIButtonLock>();

        private void OnEnable()
        {
            _lock.StateChanged += Show;
            Show(_lock.State);
        }

        private void OnDisable()
        {
            _lock.StateChanged -= Show;
        }

        private void Show(UIButtonLockState state)
        {
            if (_shown.HasValue) VisualOf(_shown.Value).Revert();
            VisualOf(state).Apply();
            _shown = state;
        }

        private UIButtonVisual VisualOf(UIButtonLockState state)
        {
            switch (state)
            {
                case UIButtonLockState.SoftLock: return softLock;
                case UIButtonLockState.HardLock: return hardLock;
                default: return normal;
            }
        }
    }
}
