using Cysharp.Threading.Tasks;
using System;
using System.Linq;
using UnityEngine.AddressableAssets;
using System.Threading;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace jjevol
{
    [ExecuteAlways]
    public class AddressableTexture : Image
    {
        public event Action OnChangeSprite;

        [FormerlySerializedAs("m_spriteName")]
        [SerializeField] private string m_SpriteKey;

        [Header("Runtime")]
        [SerializeField] private bool m_LoadOnEnable = true;
        [SerializeField] private bool m_ReleaseOnDisable = false;
        [SerializeField] private bool m_ClearSpriteOnDisable = false;

        [FormerlySerializedAs("releaseDelay")]
        [SerializeField] private float m_ReleaseDelay = 0f;

        [Header("Loading")]
        [FormerlySerializedAs("showLoadingCell")]
        [SerializeField] private bool m_ShowLoading = true;

        [SerializeField] private AddressableLoadingView m_LoadingView;

        [FormerlySerializedAs("loadingColor")]
        [SerializeField] private Color m_LoadingColor = new Color(0, 0, 0, 100f / 255f);

        [FormerlySerializedAs("fadeColorDuration")]
        [SerializeField] private float m_FadeColorDuration = 0.3f;

        [FormerlySerializedAs("skipLoadingAnimationForCachedImage")]
        [SerializeField] private bool m_SkipLoadingForCachedImage = true;

        private readonly AddressableImageLoadState _load = new AddressableImageLoadState();

        // 로딩 색을 실제로 적용한 동안에만 복원할 색을 들고 있다. 그 밖의 정본은 Graphic.color다.
        private Color _originColor;
        private bool _loadingColorApplied;
        private int _colorFadeVersion;
        private string _loadedSpriteKey;
        private Sprite _runtimeCreatedSprite;

        private struct SpriteLoadResult
        {
            public Sprite sprite;
            public bool isRuntimeCreated;
            public IDisposable lease;
        }

#if UNITY_EDITOR
        [NonSerialized] private Sprite _editorPreviewSprite;
#endif

        /// <summary>
        /// 활성화된 적 없어 로드가 첫 활성화까지 미뤄진 상태다. 이때 sprite가 비어 있는 것은 실패가 아니다.
        /// </summary>
        public bool IsLoadDeferred => _load.IsDeferred;

        public string spriteKey
        {
            get => m_SpriteKey;
            set
            {
                if (m_SpriteKey == value)
                {
                    if (!Application.isPlaying || _load.IsLoading(value))
                        return;

                    if (isActiveAndEnabled && sprite == null && !string.IsNullOrEmpty(m_SpriteKey))
                    {
                        LoadSpriteAsync(m_SpriteKey).Forget();
                        return;
                    }

                    // LoadSpriteAsync와 같은 규칙이다. 현재 키를 다시 넣으면 진행 중인 다른 키의 로드는 버려진다.
                    StopLoadingVisual();
                    _load.CancelInProgress();
                    return;
                }

                m_SpriteKey = value;

                if (Application.isPlaying && isActiveAndEnabled)
                    LoadSpriteAsync(m_SpriteKey).Forget();

#if UNITY_EDITOR
                if (!Application.isPlaying)
                    RefreshEditorPreview();
#endif
            }
        }

        public string spriteName
        {
            get => spriteKey;
            set => spriteKey = value;
        }

        public float alpha
        {
            get => originColor.a;
            set
            {
                Color c = originColor;
                c.a = value;
                originColor = c;
            }
        }

        public Color originColor
        {
            get => _loadingColorApplied ? _originColor : color;
            set
            {
                if (_loadingColorApplied)
                    _originColor = value;
                else
                    color = value;
            }
        }

        public Color orginColor
        {
            get => originColor;
            set => originColor = value;
        }

        public override Texture mainTexture
        {
            get
            {
#if UNITY_EDITOR
                if (!Application.isPlaying && _editorPreviewSprite != null)
                    return _editorPreviewSprite.texture;
#endif
                return base.mainTexture;
            }
        }

        protected override void Awake()
        {
            base.Awake();

            _load.MarkAwoken();

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                CaptureAndClearSourceSpriteIfNeeded();
                RefreshEditorPreview();
            }
#endif
        }

        protected override void OnEnable()
        {
            base.OnEnable();

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                CaptureAndClearSourceSpriteIfNeeded();
                RefreshEditorPreview();
                return;
            }
#endif

            bool deferred = _load.ConsumeDeferred();

            if ((m_LoadOnEnable || deferred) && !string.IsNullOrEmpty(m_SpriteKey))
                LoadSpriteAsync(m_SpriteKey).Forget();
        }

        protected override void OnDisable()
        {
            // Cancel이 대기자를 깨우므로 색을 먼저 되돌린다.
            StopLoadingVisual();
            _load.Cancel();

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                // 코드로 넣은 Sprite의 키를 잃지 않도록 비우기 전에 기록한다. 직렬화 참조는 남지 않는다.
                CaptureAndClearSourceSpriteIfNeeded();
                base.OnDisable();
                return;
            }
#endif

            if (m_ReleaseOnDisable)
            {
                ReleaseCurrentSprite();
            }
            else if (m_ClearSpriteOnDisable)
            {
                sprite = null;
            }

            base.OnDisable();
        }

        protected override void OnDestroy()
        {
            StopLoadingVisual();
            _load.Cancel();

            if (Application.isPlaying)
                ReleaseCurrentSprite();

            base.OnDestroy();
        }


        public void SetSprite(string key)
        {
            spriteKey = key;
        }

        public async UniTask LoadSpriteAsync(string key, CancellationToken externalToken = default)
        {
            if (string.IsNullOrEmpty(key))
            {
                StopLoadingVisual();
                _load.Cancel();
                ReleaseCurrentSprite();
                return;
            }

            if (_load.IsLoading(key))
            {
                await _load.WaitAsync(externalToken);
                return;
            }

            if (_loadedSpriteKey == key && sprite != null)
            {
                StopLoadingVisual();
                m_SpriteKey = key;
                _load.Cancel();
                return;
            }

            if (!_load.CanLoadNow)
            {
                m_SpriteKey = key;
                _load.Defer();
                return;
            }

            bool showLoading = m_ShowLoading &&
                               AddressableImageLoadState.HasLoadingProvider(m_LoadingView) &&
                               !(m_SkipLoadingForCachedImage && AddressablesManager.IsLoaded(key));

            // Begin이 교체되는 요청의 대기자를 깨우므로 색을 먼저 되돌린다.
            if (!showLoading)
                StopLoadingVisual();

            AddressableImageLoadState.Request request = _load.Begin(key, externalToken);
            CancellationToken token = request.Token;

            try
            {
                if (showLoading)
                    ShowLoadingVisual(token);

                SpriteLoadResult loadedResult = await LoadDisplaySpriteAsync(key, token);
                Sprite loadedSprite = loadedResult.sprite;

                if (!_load.IsCurrent(request))
                {
                    if (loadedSprite != null)
                    {
                        if (loadedResult.isRuntimeCreated)
                            DestroyRuntimeCreatedSprite(loadedSprite);

                        UIAssetOwnership.Return(loadedResult.lease, m_ReleaseDelay);
                    }

                    return;
                }

                if (loadedSprite == null)
                {
                    Debug.LogWarning($"[AddressableTexture] Texture2D/Sprite load failed. key:{key}, object:{name}");

                    if (showLoading)
                        await HideLoadingVisualAsync(token);

                    return;
                }

                ReleaseCurrentSprite();

                m_SpriteKey = key;
                _load.HoldLease(loadedResult.lease);
                _loadedSpriteKey = key;
                _runtimeCreatedSprite = loadedResult.isRuntimeCreated ? loadedSprite : null;
                sprite = loadedSprite;

                SetAllDirty();
                OnChangeSprite?.Invoke();

                if (showLoading)
                    await HideLoadingVisualAsync(token);
            }
            finally
            {
                // 대기자가 재개된 뒤 색을 덮지 않도록 복원을 End 안에서 완료 전에 끝낸다.
                _load.End(request, showLoading ? StopLoadingVisual : (Action)null);
            }
        }

        private async UniTask<SpriteLoadResult> LoadDisplaySpriteAsync(string key, CancellationToken token)
        {
            // Preserve Texture2D-first behavior, but avoid an invalid typed load when the key only offers Sprite.
            var locations=Addressables.LoadResourceLocationsAsync(key);
            bool texture;
            try
            {
                var available=await locations.ToUniTask(autoReleaseWhenCanceled:false);
                if(token.IsCancellationRequested)return default;
                if(available==null||available.Count==0)throw new InvalidOperationException("No UI image resource location: "+key);
                texture=available.Any(location=>typeof(Texture2D).IsAssignableFrom(location.ResourceType));
            }
            finally{if(locations.IsValid())Addressables.Release(locations);}
            if(texture)
            {
                var lease=await UIAssetOwnership.Acquire<Texture2D>(key,token);
                if(lease==null)return default;
                if(token.IsCancellationRequested){lease.Dispose();return default;}
                Sprite created;
                try{created=CreateSpriteFromTexture(lease.Asset);}catch{lease.Dispose();throw;}
                if(!created){lease.Dispose();return default;}
                return new SpriteLoadResult{sprite=created,isRuntimeCreated=true,lease=lease};
            }
            var spriteLease=await UIAssetOwnership.Acquire<Sprite>(key,token);
            if(spriteLease==null)return default;
            if(token.IsCancellationRequested){spriteLease.Dispose();return default;}
            return new SpriteLoadResult{sprite=spriteLease.Asset,isRuntimeCreated=false,lease=spriteLease};
        }

        private Sprite CreateSpriteFromTexture(Texture2D texture)
        {
            if (texture == null) return null;
            if (texture.width <= 0 || texture.height <= 0) return null;

            // Tight 메시 생성은 큰 텍스처에서 느리고, uGUI는 Use Sprite Mesh를 켜지 않으면 사각형으로 그린다.
            return Sprite.Create(
                texture,
                new Rect(0, 0, texture.width, texture.height),
                new Vector2(0.5f, 0.5f),
                100f,
                0,
                SpriteMeshType.FullRect
            );
        }

        private void DestroyRuntimeCreatedSprite(Sprite targetSprite)
        {
            if (targetSprite == null) return;

#if UNITY_EDITOR
            if (!Application.isPlaying)
                DestroyImmediate(targetSprite);
            else
                Destroy(targetSprite);
#else
    Destroy(targetSprite);
#endif
        }

        private void DestroyRuntimeCreatedSprite()
        {
            if (_runtimeCreatedSprite == null) return;

            DestroyRuntimeCreatedSprite(_runtimeCreatedSprite);
            _runtimeCreatedSprite = null;
        }

        private void ShowLoadingVisual(CancellationToken ct)
        {
            if (!_loadingColorApplied)
            {
                _originColor = color;
                _loadingColorApplied = true;
            }

            _load.ShowLoading(m_LoadingView, rectTransform, ct, this);
            FadeColorAsync(m_LoadingColor, m_FadeColorDuration, ct).Forget();
        }

        private async UniTask HideLoadingVisualAsync(CancellationToken ct)
        {
            _load.HideLoading();
            await FadeColorAsync(_originColor, m_FadeColorDuration, ct);
        }

        private void StopLoadingVisual()
        {
            _load.HideLoading();

            if (!_loadingColorApplied)
                return;

            _colorFadeVersion++;
            _loadingColorApplied = false;
            color = _originColor;
        }

        private async UniTask FadeColorAsync(Color targetColor, float duration, CancellationToken token)
        {
            int version = ++_colorFadeVersion;

            if (duration <= 0f)
            {
                color = targetColor;
                return;
            }

            Color startColor = color;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                if (token.IsCancellationRequested || this == null || version != _colorFadeVersion)
                    return;

                elapsed += Time.unscaledDeltaTime;
                color = Color.Lerp(startColor, targetColor, Mathf.Clamp01(elapsed / duration));
                await UniTask.Yield(PlayerLoopTiming.Update);
            }

            if (token.IsCancellationRequested || this == null || version != _colorFadeVersion)
                return;

            color = targetColor;
        }

        private void ReleaseCurrentSprite()
        {
            sprite=null;DestroyRuntimeCreatedSprite();
            _load.ReturnLease(m_ReleaseDelay);
            _loadedSpriteKey=string.Empty;SetAllDirty();
        }

#if UNITY_EDITOR
        protected override void OnValidate()
        {
            base.OnValidate();

            if (!Application.isPlaying)
            {
                CaptureAndClearSourceSpriteIfNeeded();
                RefreshEditorPreview();
            }
        }

        protected override void OnPopulateMesh(VertexHelper toFill)
        {
            if (!Application.isPlaying && _editorPreviewSprite != null)
            {
                AddressablePreviewMesh.Populate(toFill, this, _editorPreviewSprite, preserveAspect);
                return;
            }
            base.OnPopulateMesh(toFill);
        }

        public void SetEditorPreviewSprite(Sprite previewSprite)
        {
            if (Application.isPlaying) return;

            _editorPreviewSprite = previewSprite;
            SetVerticesDirty();
            SetMaterialDirty();
        }

        public void RefreshEditorPreview()
        {
            if (Application.isPlaying) return;

            _editorPreviewSprite = UIEditorPreview.LoadSprite(m_SpriteKey);

            SetVerticesDirty();
            SetMaterialDirty();
        }

        public void ClearSourceSpriteReference()
        {
            if (Application.isPlaying) return;
            if (sprite == null) return;

            sprite = null;
            SetVerticesDirty();
            SetMaterialDirty();
        }

        private void CaptureAndClearSourceSpriteIfNeeded()
        {
            if (Application.isPlaying) return;
            if (sprite == null) return;

            _editorPreviewSprite = sprite;

            if (string.IsNullOrEmpty(m_SpriteKey))
                m_SpriteKey = UIEditorPreview.GetAddressOrName(sprite);

            sprite = null;

            SetVerticesDirty();
            SetMaterialDirty();
        }
#endif
    }
}
