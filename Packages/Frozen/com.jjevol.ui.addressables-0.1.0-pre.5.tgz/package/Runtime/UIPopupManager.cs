//수정
using Cysharp.Threading.Tasks;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.AddressableAssets;

namespace jjevol
{
    public struct UIPopupRequest
    {
        public string popupType { get; }
        public IPopupData data { get; }

        public bool preventDuplicate { get; }

        public bool addToList { get; }

        public UniTaskCompletionSource<UIPopup> CompletionSource { get; }

        public UIPopupRequest(string popupType, IPopupData data, UniTaskCompletionSource<UIPopup> completionSource = null, bool checkSamePopup = true, bool doAddToList = true)
        {
            this.popupType = popupType;
            preventDuplicate = checkSamePopup;
            addToList = doAddToList;
            this.data = data;
            CompletionSource = completionSource;
        }
    }

    public class UIPopupManager : IUIReleaseHandle, IDisposable
    {
        private readonly Transform _popupParent;
        private readonly UIInstanceOwner _instances;
        private bool _disposed;
        private int _requestVersion;
        internal int RequestVersion=>_requestVersion;
        private UIPopupRequest? _inflightRequest;
        private readonly Action<string> _enableBlocker, _disableBlocker;

        private const string BACKBOARD_NAME = "Backboard";
        private readonly Transform _backboard;

        private readonly List<UIPopup> _activePopupList = new();
        private readonly ConcurrentQueue<UIPopupRequest> _requestQueue = new();

        private CancellationTokenSource _spawnLoopTokenSource;

        private bool _blocked = false;

        private int _spawnedPopupCount = 0;
        public List<UIPopup> ActivePopups => _activePopupList;

        public UIPopup GetTopPopup() =>
            _activePopupList.Count > 0 ? _activePopupList[^1] : null;

        private bool HasAnyPopupWork => _activePopupList.Count > 0 || !_requestQueue.IsEmpty || _spawnedPopupCount > 0;

        public UIPopupManager(Transform popupParent, Action<string> enableBlocker, Action<string> disableBlocker)
        {
            _popupParent = popupParent;
            _instances=new UIInstanceOwner(popupParent);
            _enableBlocker = enableBlocker;
            _disableBlocker = disableBlocker;

            _backboard = _popupParent != null ? _popupParent.Find(BACKBOARD_NAME) : null;

            SetPopupLayerActive(false);

            _spawnLoopTokenSource = new CancellationTokenSource();
            RunSpawnLoop().Forget();
        }

        private void SetPopupLayerActive(bool on)
        {
            if (!_popupParent) return;

            var go = _popupParent.gameObject;
            if (!go.activeSelf)
                go.SetActive(true);

            if (_backboard == null) return;

            bool shouldShowBackboard = on && _activePopupList.Count > 0;

            if (_backboard.gameObject.activeSelf != shouldShowBackboard)
                _backboard.gameObject.SetActive(shouldShowBackboard);
        }

        private void _SetBlocker(bool isBlock)
        {
            if (_blocked == isBlock) return;

            _blocked = isBlock;

            if (isBlock)
                _enableBlocker?.Invoke("PopupManager");
            else
                _disableBlocker?.Invoke("PopupManager");
        }

        public void Dispose()
        {
            if(_disposed)return;_disposed=true;
            CancelQueuedPopupRequests();
            DestroyAllImmediately();
            _instances.Dispose();
            if (_spawnLoopTokenSource != null)
            {
                _spawnLoopTokenSource.Cancel();
                _spawnLoopTokenSource.Dispose();
                _spawnLoopTokenSource = null;
            }

            _SetBlocker(false);
            SetPopupLayerActive(false);
        }

        public async UniTask ClosePopup()
        {
            if (UIManager.Instance.IsFading || UIManager.Instance.blockerCounter.IsEnable())
                return;

            var topPopup = GetTopPopup();

            if (topPopup == null) return;

            if (topPopup.IsTransitioning) return;

            bool canClose = await topPopup.OnBackRequestAsync();

            if (canClose)
                topPopup.ClosePopup();
        }

        private async UniTask<UIPopup> CreatePopupAsync(string popupType, IPopupData data, UniTaskCompletionSource<UIPopup> completionSource = null, bool preventDuplicate = true, bool addToList = true)
        {
            int version=_requestVersion;
            SetPopupLayerActive(true);

            UIPopup current = null, existing = null;

            if (preventDuplicate && addToList)
            {
                current = GetTopPopup();
                existing = FindOpenPopup(popupType, data);
            }

            if (current != null && current == existing)
            {
                return current;
            }
            else if (existing != null)
            {
                MoveToTop(existing);

                return existing;
            }

            var popup = await InstantiatePopupAsync(popupType);
            if(!popup)return null;
            if(_disposed || version!=_requestVersion){Release(popup);return null;}

            MoveToTop(popup);

            if (addToList && !_activePopupList.Contains(popup))
                _activePopupList.Add(popup);

            popup.ShowUI(data);

            UIEvent.Trigger(UIEventTypes.SpawnPopup);

            return popup;
        }

        private async UniTask<UIPopup> InstantiatePopupAsync(string popupType)
        {
            string key = GetAddressableKey(popupType);

            GameObject newObject = await _instances.InstantiateAsync(key);
            if(!newObject || _disposed)return null;

            if (newObject != null)
            {
                newObject.name = popupType.ToString();

                if (newObject.TryGetComponent<RectTransform>(out var rectTransform))
                {
                    rectTransform.localPosition = Vector3.zero;
                    rectTransform.localScale = Vector3.one;
                    rectTransform.sizeDelta = Vector2.zero;
                }
            }

            var popup = newObject.GetComponent<UIPopup>() ?? newObject.AddComponent<UIPopup>();
            popup.PopupType = popupType;

            popup.Initialize(this);

            popup.onHide.AddListener(RemovePopup);

            return popup;
        }

        public static string GetAddressableKey(string popupType)
        {
            return UIAddress.Popup(popupType);
        }

        public void Release(UIBase ui)
        {
            if(ui==null)return;
            ui.onHide.RemoveListener(RemovePopup);
            _instances.Release(ui.gameObject);
        }

        private void RemovePopup(UIBase ui)
        {
            if (ui is UIPopup popup)
            {
                if (_activePopupList.Contains(popup))
                    _activePopupList.Remove(popup);

                var topPopup = GetTopPopup();

                if (topPopup != null)
                    MoveToTop(topPopup);
                else if (!HasAnyPopupWork)
                    SetPopupLayerActive(false);

                UIEvent.Trigger(UIEventTypes.ClosePopup);
            }
        }

        public UniTask<UIPopup> RequestPopup(string popupType, IPopupData popupData, bool checkSamePopup = true, bool doAddToList = true)
        {
            if(_disposed)throw new ObjectDisposedException(nameof(UIPopupManager));
            if (!UINavigationOptions.CanOpenPopup(popupType))
                return UniTask.FromResult<UIPopup>(null);

            var completionSource = new UniTaskCompletionSource<UIPopup>();
            var request = new UIPopupRequest(popupType, popupData, completionSource, checkSamePopup, doAddToList);

            _requestQueue.Enqueue(request);

            return completionSource.Task;
        }

        /// <summary>
        /// Tween/Transition 동작 없이 모든 팝업을 즉시 파괴한다.
        /// 닫기 흐름이 아니라 파괴 흐름이므로 onHide는 호출하지 않는다.
        /// </summary>
        public void DestroyAllImmediately()
        {
            CancelQueuedPopupRequests();

            foreach (var popup in _activePopupList.ToArray())
            {
                if (popup == null)
                    continue;

                popup.DestroyPopupImmediately();
            }

            _activePopupList.Clear();

            _SetBlocker(false);
            SetPopupLayerActive(false);
        }

        /// <summary>
        /// 모든 팝업을 일반 닫기 흐름으로 닫는다.
        /// Transition 중인 팝업은 UIPopup.ClosePopup() 정책에 따라 닫히지 않을 수 있다.
        /// </summary>
        public void CloseAllPopups()
        {
            foreach (var popup in _activePopupList.ToArray())
            {
                if (popup == null)
                    continue;

                popup.ClosePopup(false);
            }
        }

        /// <summary>
        /// 모든 팝업을 Transition 상태와 관계없이 강제로 닫는다.
        /// 화면 전환, 씬 이동처럼 이전 화면 팝업을 반드시 정리해야 하는 상황에서 사용한다.
        /// </summary>
        public void ForceCloseAllPopups(bool cancelQueuedRequests = true)
        {
            if (cancelQueuedRequests)
                CancelQueuedPopupRequests();

            foreach (var popup in _activePopupList.ToArray())
            {
                if (popup == null)
                    continue;

                popup.ForceClosePopup(false);
            }

            _activePopupList.RemoveAll(popup => popup == null);

            if (!HasAnyPopupWork)
            {
                _SetBlocker(false);
                SetPopupLayerActive(false);
            }
        }

        /// <summary>
        /// 아직 생성되지 않은 팝업 요청 큐를 취소한다.
        /// 화면 전환 이후 이전 화면 기준 팝업이 뒤늦게 뜨는 것을 막는다.
        /// </summary>
        private void CancelQueuedPopupRequests()
        {
            _requestVersion++;
            _inflightRequest?.CompletionSource?.TrySetCanceled();
            while (_requestQueue.TryDequeue(out UIPopupRequest request))
            {
                request.CompletionSource?.TrySetCanceled();
            }
        }

        public UIPopup FindPopup(string type, IPopupData datas = null)
        {
            foreach (var popup in _activePopupList)
            {
                if ((popup.PopupType == type && (datas == null || popup.popupData == datas)))
                    return popup;
            }

            return null;
        }

        // 닫히는 중인 팝업은 곧 사라지므로 중복으로 보지 않는다.
        private UIPopup FindOpenPopup(string type, IPopupData datas)
        {
            foreach (var popup in _activePopupList)
            {
                if (popup.IsOpen && popup.PopupType == type && (datas == null || popup.popupData == datas))
                    return popup;
            }

            return null;
        }

        private void MoveToTop(UIPopup popup)
        {
            int index = _activePopupList.IndexOf(popup);
            if (index >= 0 && index != _activePopupList.Count - 1)
            {
                _activePopupList.RemoveAt(index);
                _activePopupList.Add(popup);
            }

            if (_backboard != null)
            {
                if (!_backboard.gameObject.activeSelf)
                    _backboard.gameObject.SetActive(true);

                _backboard.SetAsLastSibling();
            }

            popup.rectTransform.SetAsLastSibling();
        }

        private async UniTaskVoid RunSpawnLoop()
        {
            var ct = _spawnLoopTokenSource.Token;
            try
            {
                while (!ct.IsCancellationRequested && !_disposed && _popupParent)
                {
                    _SetBlocker(!_requestQueue.IsEmpty);
                    SetPopupLayerActive(HasAnyPopupWork);

                    await UniTask.WaitUntil(() => !_requestQueue.IsEmpty, cancellationToken: ct);

                    _SetBlocker(true);
                    SetPopupLayerActive(true);

                    if (_requestQueue.TryDequeue(out var req))
                    {
                        _inflightRequest=req;
                        _spawnedPopupCount++;

                        try
                        {
                            var popup = await CreatePopupAsync(
                                req.popupType, req.data, req.CompletionSource,
                                req.preventDuplicate, req.addToList);

                            if(popup!=null)req.CompletionSource.TrySetResult(popup);else req.CompletionSource.TrySetCanceled();
                        }
                        catch (Exception e)
                        {
                            Debug.LogError($"Popup Spawn Failed: {e}");
                            req.CompletionSource.TrySetException(e);
                        }
                        finally
                        {
                            _inflightRequest=null;
                            _spawnedPopupCount--;

                            if (!HasAnyPopupWork)
                            {
                                _SetBlocker(false);
                                SetPopupLayerActive(false);
                            }
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
            }
        }

        public virtual void Refresh()
        {
            foreach (UIPopup popup in ActivePopups)
                popup.Refresh();
        }
    }
}
//수정 종료
