using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// AddressableImage와 AddressableTexture가 공유하는 로드 상태, 로딩 표시, lease 보유를 묶는다.
    /// 직렬화되지 않으며 Prefab에 어떤 이미지 참조도 남기지 않는다. 표시 규칙은 두 컴포넌트가 정한다.
    /// </summary>
    internal sealed class AddressableImageLoadState
    {
        internal sealed class Request
        {
            internal readonly string Key;
            internal readonly CancellationTokenSource Source;
            internal readonly CancellationToken Token;
            internal readonly UniTaskCompletionSource Completion = new UniTaskCompletionSource();

            internal Request(string key, CancellationToken externalToken)
            {
                Key = key;
                Source = CancellationTokenSource.CreateLinkedTokenSource(externalToken);
                Token = Source.Token;
            }
        }

        private Request _current;
        private bool _awoken;
        private bool _deferred;
        private AddressableLoadingView _shownView;
        private AddressableLoadingHandle _globalHandle;
        private IDisposable _lease;

        /// <summary>
        /// 활성화된 적 없는 객체에서는 OnDestroy가 불리지 않아 lease를 돌려줄 수 없으므로 로드를 시작하지 않는다.
        /// </summary>
        internal bool CanLoadNow => _awoken;

        internal void MarkAwoken() => _awoken = true;

        internal void Defer() => _deferred = true;

        internal bool IsDeferred => _deferred;

        internal bool ConsumeDeferred()
        {
            bool deferred = _deferred;
            _deferred = false;
            return deferred;
        }

        internal bool IsLoading(string key) => _current != null && _current.Key == key;

        internal bool IsCurrent(Request request) => ReferenceEquals(_current, request) && !request.Token.IsCancellationRequested;

        internal Request Begin(string key, CancellationToken externalToken)
        {
            // 취소로 재개된 호출자가 새 로드를 시작했을 수 있다. 그 요청도 이 요청이 대체한다.
            do Cancel();
            while (_current != null);

            _current = new Request(key, externalToken);
            return _current;
        }

        /// <summary>
        /// 요청 마무리. 현재 요청이면 표시를 정리하고 cleanup을 실행한 뒤 대기자를 깨운다.
        /// 대기자는 동기로 재개되므로 완료가 마지막이어야 한다. 교체된 요청은 Cancel이 이미 정리하고 완료했다.
        /// </summary>
        internal void End(Request request, Action cleanup = null)
        {
            if (!ReferenceEquals(_current, request))
                return;

            _current = null;

            try
            {
                request.Source.Dispose();
                HideLoading();
                cleanup?.Invoke();
            }
            finally
            {
                request.Completion.TrySetResult();
            }
        }

        internal void Cancel()
        {
            _deferred = false;

            Request request = _current;
            _current = null;

            // 취소 통지와 대기자는 동기로 재개되어 새 로드를 시작할 수 있으므로 표시를 먼저 끝낸다.
            HideLoading();

            if (request == null)
                return;

            request.Source.Cancel();
            request.Source.Dispose();
            request.Completion.TrySetResult();
        }

        /// <summary>
        /// 진행 중인 요청만 취소한다. 첫 활성화를 기다리는 지연 로드는 유지한다.
        /// </summary>
        internal void CancelInProgress()
        {
            if (_current != null)
                Cancel();
        }

        /// <summary>
        /// 진행 중인 로드가 끝날 때까지 기다린다. 취소는 이 호출의 대기만 끝낸다.
        /// </summary>
        internal UniTask WaitAsync(CancellationToken token)
        {
            return _current == null
                ? UniTask.CompletedTask
                : _current.Completion.Task.AttachExternalCancellation(token);
        }

        internal static bool HasLoadingProvider(AddressableLoadingView view)
        {
            return view != null || AddressableLoadingViewService.IsGlobalAvailable;
        }

        /// <summary>
        /// 로딩 표시를 시작한다. 이미지 로드와 분리돼 있어 기다리지 않으며, 표시 실패는 경고로만 남는다.
        /// </summary>
        internal void ShowLoading(AddressableLoadingView view, RectTransform target, CancellationToken token, UnityEngine.Object context)
        {
            HideLoading();

            if (view != null)
            {
                _shownView = view;
                ShowViewAsync(view, token, context).Forget();
                return;
            }

            _globalHandle = AddressableLoadingViewService.AcquireGlobal(target, token);
        }

        internal void HideLoading()
        {
            AddressableLoadingView view = _shownView;
            _shownView = null;

            if (view != null)
                view.Hide();

            AddressableLoadingHandle handle = _globalHandle;
            _globalHandle = null;
            handle?.Release();
        }

        private static async UniTaskVoid ShowViewAsync(AddressableLoadingView view, CancellationToken token, UnityEngine.Object context)
        {
            try
            {
                await view.ShowAsync(token);
            }
            catch (OperationCanceledException)
            {
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"[AddressableLoadingView] Loading display failed. key:{view.loadingPrefabKey}, error:{exception.GetType().Name}", context);
            }
        }

        internal void HoldLease(IDisposable lease) => _lease = lease;

        internal void ReturnLease(float delay)
        {
            IDisposable lease = _lease;
            _lease = null;
            UIAssetOwnership.Return(lease, delay);
        }
    }
}
