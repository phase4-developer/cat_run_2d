using Cysharp.Threading.Tasks;

using System.Collections.Generic;

namespace jjevol
{
    public enum UIPreTransitionTargetType
    {
        Screen,
        Popup
    }

    public class UIPreTransitionRequest
    {
        public UIPreTransitionTargetType targetType;

        public string screenType;
        public IScreenData screenData;

        public string popupType;
        public IPopupData popupData;

        public bool forced;

        public static UIPreTransitionRequest Screen(string screenType, IScreenData screenData = null, bool forced = false)
        {
            return new UIPreTransitionRequest
            {
                targetType = UIPreTransitionTargetType.Screen,
                screenType = screenType,
                screenData = screenData,
                forced = forced
            };
        }

        public static UIPreTransitionRequest Popup(string popupType, IPopupData popupData = null, bool forced = false)
        {
            return new UIPreTransitionRequest
            {
                targetType = UIPreTransitionTargetType.Popup,
                popupType = popupType,
                popupData = popupData,
                forced = forced
            };
        }
    }

    public class UIPreTransitionResult
    {
        public bool success;
        public string errorCode;

        public static UIPreTransitionResult Success()
        {
            return new UIPreTransitionResult
            {
                success = true,
                errorCode = string.Empty
            };
        }

        public static UIPreTransitionResult Fail(string errorCode)
        {
            return new UIPreTransitionResult
            {
                success = false,
                errorCode = errorCode
            };
        }
    }

    public interface IUIPreTransitionHandler
    {
        bool CanHandle(UIPreTransitionRequest request);
        UniTask<UIPreTransitionResult> RequestAsync(UIPreTransitionRequest request);
    }

    public class UIPreTransitionService
    {
        private readonly List<IUIPreTransitionHandler> handlers = new();

        public void Register(IUIPreTransitionHandler handler)
        {
            if (handler == null)
                return;

            if (handlers.Contains(handler))
                return;

            handlers.Add(handler);
        }

        public async UniTask<UIPreTransitionResult> RequestScreenAsync(string screenType, IScreenData screenData = null, bool forced = false)
        {
            return await RequestAsync(UIPreTransitionRequest.Screen(screenType, screenData, forced));
        }

        public async UniTask<UIPreTransitionResult> RequestPopupAsync(string popupType, IPopupData popupData = null, bool forced = false)
        {
            return await RequestAsync(UIPreTransitionRequest.Popup(popupType, popupData, forced));
        }

        public async UniTask<UIPreTransitionResult> RequestAsync(UIPreTransitionRequest request)
        {
            if (!UINavigationOptions.CanTransition(request))
                return UIPreTransitionResult.Fail(UINavigationOptions.UnsupportedError);

            if (request == null)
                return UIPreTransitionResult.Success();

            for (int i = 0; i < handlers.Count; i++)
            {
                var handler = handlers[i];
                if (handler == null)
                    continue;

                if (!handler.CanHandle(request))
                    continue;

                var result = await handler.RequestAsync(request);

                if (result == null)
                    continue;

                if (!result.success)
                    return result;
            }

            return UIPreTransitionResult.Success();
        }
    }
}
