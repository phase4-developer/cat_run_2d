using System;
using System.Threading;
using Cysharp.Threading.Tasks;
namespace jjevol
{
    public static class UINavigationOptions
    {
        public const string UnsupportedError = "unsupported_ui";
        public static Func<string, bool> ScreenPolicy { get; set; }
        public static Func<string, bool> PopupPolicy { get; set; }
        public static Func<bool> IsBackInputBlocked { get; set; }
        public static Action<UIPreTransitionService> ConfigureTransitions { get; set; }
        public static Func<CancellationToken, UniTask<bool>> ConfirmExitAsync { get; set; }
        [UnityEngine.RuntimeInitializeOnLoadMethod(UnityEngine.RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            ScreenPolicy = null; PopupPolicy = null; IsBackInputBlocked = null; ConfigureTransitions = null; ConfirmExitAsync = null;
        }
        public static bool CanOpenScreen(string type) => ScreenPolicy?.Invoke(type) ?? true;
        public static bool CanOpenPopup(string type) => PopupPolicy?.Invoke(type) ?? true;
        public static bool CanTransition(UIPreTransitionRequest request) => request == null ||
            (request.targetType == UIPreTransitionTargetType.Screen ? CanOpenScreen(request.screenType) : CanOpenPopup(request.popupType));
    }
}
