using System;
using System.Collections.Generic;
using jjevol.Audio;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// 사운드 실패가 입력 처리를 끊지 않게 분리한다. 미등록 키와 구독자 예외는 사운드별로 한 번만 경고한다.
    /// </summary>
    internal static class UISoundPlayback
    {
        private static readonly HashSet<string> Warned = new HashSet<string>();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState() => Warned.Clear();

        internal static void PlayUI(AudioClip clip, string key, float volume, float pitch)
        {
            try
            {
                if (clip != null) AudioEvents.PlayUI.Trigger(clip, volume, pitch);
                else if (!string.IsNullOrEmpty(key)) AudioEvents.PlayUI.Trigger(key, volume, pitch);
            }
            catch (Exception exception) { Warn(clip != null ? clip.name : key, exception); }
        }

        internal static void PlaySfx(string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            try { AudioEvents.PlaySfx.Trigger(key); }
            catch (Exception exception) { Warn(key, exception); }
        }

        private static void Warn(string sound, Exception exception)
        {
            if (Warned.Add(sound))
                Debug.LogWarning($"[UISound] Sound skipped. sound:{sound}, error:{exception.GetType().Name}: {exception.Message}");
        }
    }
}
