using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// Screens, Popups and HUDs are identified by a game-owned string ID. The Addressables address is the prefix plus that ID.
    /// </summary>
    public static class UIAddress
    {
        public const string ScreenPrefix = "UIScreen_";
        public const string PopupPrefix = "UIPopup_";
        public const string HudPrefix = "UIHud_";

        public static string Screen(string id) => ScreenPrefix + id;
        public static string Popup(string id) => PopupPrefix + id;
        public static string Hud(string id) => HudPrefix + id;
    }

    /// <summary>Lets the Inspector choose a UI ID from the Addressables addresses that start with the prefix.</summary>
    public sealed class UIAddressIdAttribute : PropertyAttribute
    {
        public string Prefix { get; }

        public UIAddressIdAttribute(string prefix) => Prefix = prefix;
    }
}
