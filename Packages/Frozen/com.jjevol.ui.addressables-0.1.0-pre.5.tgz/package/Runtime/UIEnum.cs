using System;
namespace jjevol
{
    public enum UIEventTypes
    {
        SpawnPopup,
        ClosePopup,
    }

    public enum UIButtonState
    {
        Disable,
        Enable,
        Cooldown,
        Guarded,
    }

}
