using Cysharp.Threading.Tasks;
using System;
using System.Threading;
using UnityEngine;

namespace jjevol
{
    [DisallowMultipleComponent]
    public sealed class AddressableLoadingView : MonoBehaviour
    {
        [Header("Addressable Loading Prefab")]
        [SerializeField] private string m_LoadingPrefabKey;
        [SerializeField] private Transform m_Parent;
        [SerializeField] private Vector3 m_LocalPosition = Vector3.zero;
        [SerializeField] private Vector3 m_LocalScale = Vector3.one;
        [SerializeField] private bool m_KeepInstance = true;

        [Header("Optional Local Fallback")]
        [SerializeField] private GameObject m_LocalLoadingObject;

        private CancellationTokenSource _cts;
        private GameObject _instance;
        private IDisposable _prefabLease;
        private int _showVersion;
        private string _loadedPrefabKey;

        public string loadingPrefabKey
        {
            get => m_LoadingPrefabKey;
            set => m_LoadingPrefabKey = value;
        }

        public bool IsShowing { get; private set; }

        private Transform Parent => m_Parent != null ? m_Parent : transform;

        public async UniTask ShowAsync(CancellationToken ct = default)
        {
            if(_instance && _loadedPrefabKey!=m_LoadingPrefabKey)ReleaseAddressableInstance();
            IsShowing = true;

            if (m_LocalLoadingObject != null)
                m_LocalLoadingObject.SetActive(true);

            if (_instance != null)
            {
                _instance.SetActive(true);
                return;
            }

            if (string.IsNullOrEmpty(m_LoadingPrefabKey))
                return;

            CancelLoad();

            _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            var token = _cts.Token;
            string requestKey = m_LoadingPrefabKey;
            int version=++_showVersion;

            var lease = await UIAssetOwnership.Acquire<GameObject>(requestKey, token);
            GameObject prefab=lease?.Asset;

            if (token.IsCancellationRequested || version!=_showVersion || !this || (!IsShowing&&!m_KeepInstance))
            {
                if (prefab != null)
                    lease?.Dispose();

                return;
            }

            if (prefab == null)
                return;

            if (!string.IsNullOrEmpty(_loadedPrefabKey) && _loadedPrefabKey != requestKey)
                ReleaseAddressableInstance();

            _prefabLease=lease;
            _loadedPrefabKey = requestKey;
            _instance = Instantiate(prefab, Parent);
            _instance.transform.localPosition = m_LocalPosition;
            _instance.transform.localRotation = Quaternion.identity;
            _instance.transform.localScale = m_LocalScale;
            _instance.SetActive(IsShowing);
        }

        public void Hide()
        {
            IsShowing = false;

            if (m_LocalLoadingObject != null)
                m_LocalLoadingObject.SetActive(false);

            if (_instance != null)
                _instance.SetActive(false);

            if (!m_KeepInstance)
            {
                CancelLoad();
                ReleaseAddressableInstance();
            }
        }

        public void Release()
        {
            CancelLoad();

            IsShowing = false;

            if (m_LocalLoadingObject != null)
                m_LocalLoadingObject.SetActive(false);

            ReleaseAddressableInstance();
        }

        private void ReleaseAddressableInstance()
        {
            var instance=_instance;var lease=_prefabLease;
            _instance=null;_prefabLease=null;_loadedPrefabKey=string.Empty;
            if(instance)Destroy(instance);
            UIAssetOwnership.ReturnAfterDestroyed(instance,lease).Forget();
        }

        private void CancelLoad()
        {
            _showVersion++;
            if (_cts == null) return;

            _cts.Cancel();
            _cts.Dispose();
            _cts = null;
        }

        private void OnDisable()
        {
            Hide();
        }

        private void OnDestroy()
        {
            Release();
        }
    }
}
