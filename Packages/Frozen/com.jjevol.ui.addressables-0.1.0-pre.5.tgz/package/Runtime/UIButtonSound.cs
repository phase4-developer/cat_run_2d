using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    /// <summary>Plays a sound when a Unity Button is clicked. A clip wins over a key.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Button))]
    public class UIButtonSound : MonoBehaviour
    {
        [SerializeField] private string soundKey;
        [SerializeField] private AudioClip clip;
        [SerializeField, Range(0f, 1f)] private float volume = 1f;
        [SerializeField, Range(0.1f, 3f)] private float pitch = 1f;

        private Button _button;

        private void Awake() => _button = GetComponent<Button>();

        private void OnEnable() => _button.onClick.AddListener(Play);

        private void OnDisable() => _button.onClick.RemoveListener(Play);

        private void Play() => UISoundPlayback.PlayUI(clip, soundKey, volume, pitch);
    }
}
