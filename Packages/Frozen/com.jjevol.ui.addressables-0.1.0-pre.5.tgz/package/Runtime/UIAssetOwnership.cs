using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    internal static class UIAssetOwnership
    {
        internal static UniTask<AddressableLease<T>> Acquire<T>(string key,CancellationToken token) where T:UnityEngine.Object
        {
            // Scope captures the already-existing manager generation; never let a later manager return this acquisition.
            _=AddressablesManager.Instance;
            return AddressableScope.Get<T>(key,token);
        }
        internal static void Return(IDisposable lease,float delay=0)
        { if(lease==null)return;if(delay<=0)lease.Dispose();else ReturnDelayed(lease,delay).Forget(); }
        private static async UniTaskVoid ReturnDelayed(IDisposable lease,float delay)
        {
            try { await UniTask.Delay(TimeSpan.FromSeconds(delay),ignoreTimeScale:true,cancellationToken:PlaySession.Token); }
            catch(OperationCanceledException) { }
            finally { lease.Dispose(); }
        }
        internal static async UniTaskVoid ReturnAfterDestroyed(GameObject instance,IDisposable lease)
        {
            if(lease==null)return;
            try
            {
                if(instance)await UniTask.WaitUntil(()=>!instance,cancellationToken:PlaySession.Token);
                await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate,PlaySession.Token);
            }
            catch(OperationCanceledException) { }
            finally { lease.Dispose(); }
        }
    }
}
