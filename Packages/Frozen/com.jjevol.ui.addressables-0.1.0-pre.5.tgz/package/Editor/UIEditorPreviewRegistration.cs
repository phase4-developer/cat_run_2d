using UnityEditor;
namespace jjevol
{
    [InitializeOnLoad]
    internal static class UIEditorPreviewRegistration
    {
        static UIEditorPreviewRegistration()
        {
            UIEditorPreview.ResolveAtlas = AddressableEditorPreviewResolver.LoadSpriteAtlas;
            UIEditorPreview.ResolveAtlasSprite = AddressableEditorPreviewResolver.GetSpriteFromAtlas;
            UIEditorPreview.ResolveSprite = AddressableEditorPreviewResolver.LoadSprite;
            UIEditorPreview.ResolveAddress = AddressableEditorPreviewResolver.GetAddressOrName;
        }
    }
}
