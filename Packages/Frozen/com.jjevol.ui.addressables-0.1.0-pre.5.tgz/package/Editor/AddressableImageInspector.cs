﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.U2D;
using UnityEngine.UI;

namespace jjevol
{
    [CustomEditor(typeof(AddressableImage), true)]
    [CanEditMultipleObjects]
    public class AddressableImageInspector : AddressableImageInspectorBase
    {
        private SerializedProperty m_AtlasKey;
        private SerializedProperty m_SpriteName;

        private GUIContent m_AtlasContent;

        private Sprite _previewSprite;
        private SpriteAtlas _previewAtlas;
        private string _previewName;

        private Sprite GetPreviewSprite(SpriteAtlas atlas, string name)
        {
            if (_previewSprite && _previewAtlas == atlas && _previewName == name) return _previewSprite;
            ClearPreviewSprite();
            _previewAtlas = atlas;
            _previewName = name;
            _previewSprite = AddressableEditorPreviewResolver.GetSpriteFromAtlas(atlas, name);
            return _previewSprite;
        }

        private void ClearPreviewSprite()
        {
            if (_previewSprite) DestroyImmediate(_previewSprite);
            _previewSprite = null;
        }

        protected override void OnDisable()
        {
            ClearPreviewSprite();
            base.OnDisable();
        }

        private const float PickerIconSize = 18f;
        private const float PickerLabelPadding = 2f;

        protected override bool HasSelection => !string.IsNullOrEmpty(m_SpriteName.stringValue);

        protected override void BindKeyProperties()
        {
            m_AtlasContent = new GUIContent("Sprite Atlas");

            m_AtlasKey = serializedObject.FindProperty("m_AtlasKey");
            m_SpriteName = serializedObject.FindProperty("m_SpriteName");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            AtlasGUI();
            SpriteGUI();

            DrawCommonGUI();

            // Edit Mode에서만 직접 Sprite 참조를 제거한다.
            // Play Mode의 m_Sprite는 런타임 표시용 sprite이므로 건드리면 화면 이미지가 깨진다.
            if (!Application.isPlaying && m_Sprite.objectReferenceValue != null)
                m_Sprite.objectReferenceValue = null;

            bool applied = serializedObject.ApplyModifiedProperties();

            if (applied && !Application.isPlaying)
            {
                EditorUtility.SetDirty(target);
                RefreshPreviewTargets();
            }
        }

        private void AtlasGUI()
        {
            SpriteAtlas currentAtlas = AddressableEditorPreviewResolver.LoadSpriteAtlas(m_AtlasKey.stringValue);

            EditorGUI.BeginChangeCheck();

            SpriteAtlas selectedAtlas = EditorGUILayout.ObjectField(
                m_AtlasContent,
                currentAtlas,
                typeof(SpriteAtlas),
                false
            ) as SpriteAtlas;

            if (!EditorGUI.EndChangeCheck())
            {
                DrawAtlasWarning(currentAtlas);
                return;
            }

            if (selectedAtlas != null)
            {
                m_AtlasKey.stringValue = AddressableEditorPreviewResolver.GetAddressOrName(selectedAtlas);

                if (!string.IsNullOrEmpty(m_SpriteName.stringValue))
                {
                    Sprite selectedSprite = AddressableEditorPreviewResolver.GetSpriteFromAtlas(selectedAtlas, m_SpriteName.stringValue);
                    if (selectedSprite == null)
                        m_SpriteName.stringValue = string.Empty;
                    if (selectedSprite) DestroyImmediate(selectedSprite);
                }
            }
            else
            {
                m_AtlasKey.stringValue = string.Empty;
                m_SpriteName.stringValue = string.Empty;
            }

            if (!Application.isPlaying)
                m_Sprite.objectReferenceValue = null;

            DrawAtlasWarning(selectedAtlas);
        }

        private void DrawAtlasWarning(SpriteAtlas currentAtlas)
        {
            DrawUnregisteredWarning(currentAtlas, m_AtlasKey.stringValue);

            if (string.IsNullOrEmpty(m_AtlasKey.stringValue) || currentAtlas != null)
                return;

            EditorGUILayout.HelpBox(
                $"Atlas Key로 에디터 프리뷰 Atlas를 찾지 못했습니다.\nKey: {m_AtlasKey.stringValue}",
                MessageType.Info
            );
        }

        private void SpriteGUI()
        {
            SpriteAtlas atlas = AddressableEditorPreviewResolver.LoadSpriteAtlas(m_AtlasKey.stringValue);
            Sprite currentSprite = GetPreviewSprite(atlas, m_SpriteName.stringValue);

            bool canSelectSprite = atlas != null && atlas.spriteCount > 0;

            Rect rowRect = EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight);
            rowRect = EditorGUI.IndentedRect(rowRect);

            float labelWidth = EditorGUIUtility.labelWidth - PickerLabelPadding;
            if (labelWidth < 60f) labelWidth = 60f;

            Rect buttonRect = new Rect(rowRect.x, rowRect.y, labelWidth, rowRect.height);
            Rect fieldRect = new Rect(
                rowRect.x + labelWidth + PickerLabelPadding,
                rowRect.y,
                rowRect.width - labelWidth - PickerLabelPadding,
                rowRect.height
            );

            using (new EditorGUI.DisabledScope(!canSelectSprite))
            {
                if (GUI.Button(buttonRect, "Sprite", "DropDown"))
                    OpenSpriteSelector(atlas, currentSprite);

                if (GUI.Button(fieldRect, GUIContent.none, EditorStyles.objectField))
                    OpenSpriteSelector(atlas, currentSprite);
            }

            DrawSpritePickerContent(fieldRect, currentSprite);

            if (atlas != null && atlas.spriteCount == 0)
            {
                EditorGUILayout.HelpBox(
                    "선택된 Sprite Atlas 안에 Sprite가 없습니다.",
                    MessageType.Warning
                );
                return;
            }

            if (!string.IsNullOrEmpty(m_SpriteName.stringValue) && currentSprite == null)
            {
                EditorGUILayout.HelpBox(
                    $"Atlas 안에서 Sprite를 찾지 못했습니다.\nAtlas Key: {m_AtlasKey.stringValue}\nSprite Name: {m_SpriteName.stringValue}",
                    MessageType.Warning
                );
            }
        }

        private void OpenSpriteSelector(SpriteAtlas atlas, Sprite currentSprite)
        {
            if (atlas == null || atlas.spriteCount == 0) return;

            SpriteSelector.Show(atlas, currentSprite, SelectSprite);
        }

        private void DrawSpritePickerContent(Rect rect, Sprite sprite)
        {
            Rect innerRect = new Rect(rect.x + 3f, rect.y + 1f, rect.width - 6f, rect.height - 2f);

            if (sprite == null)
            {
                EditorGUI.LabelField(innerRect, "None", EditorStyles.miniLabel);
                return;
            }

            Rect iconRect = new Rect(
                innerRect.x,
                innerRect.y + Mathf.Max(0f, (innerRect.height - PickerIconSize) * 0.5f),
                PickerIconSize,
                PickerIconSize
            );

            Texture texture = AssetPreview.GetMiniThumbnail(sprite);
            if (texture == null)
                texture = AssetPreview.GetAssetPreview(sprite);
            if (texture == null)
                texture = sprite.texture;

            if (texture != null)
                GUI.DrawTexture(iconRect, texture, ScaleMode.ScaleToFit, true);

            Rect labelRect = new Rect(
                iconRect.xMax + 5f,
                rect.y,
                rect.width - PickerIconSize - 12f,
                rect.height
            );

            EditorGUI.LabelField(
                labelRect,
                AddressableEditorPreviewResolver.NormalizeSpriteName(sprite.name),
                EditorStyles.miniLabel
            );
        }

        private void SelectSprite(Sprite sprite)
        {
            serializedObject.Update();

            if (sprite != null)
            {
                string normalizedName = AddressableEditorPreviewResolver.NormalizeSpriteName(sprite.name);
                m_SpriteName.stringValue = normalizedName;

                Image.Type oldType = (Image.Type)m_Type.enumValueIndex;

                if (sprite.border.sqrMagnitude > 0f)
                {
                    m_Type.enumValueIndex = (int)Image.Type.Sliced;
                }
                else if (oldType == Image.Type.Sliced)
                {
                    m_Type.enumValueIndex = (int)Image.Type.Simple;
                }
            }
            else
            {
                m_SpriteName.stringValue = string.Empty;
            }

            // Edit Mode에서만 직접 Sprite 참조를 제거한다.
            // Play Mode에서는 런타임 sprite를 지우면 화면 표시가 깨진다.
            if (!Application.isPlaying)
                m_Sprite.objectReferenceValue = null;

            bool applied = serializedObject.ApplyModifiedProperties();

            if (applied && !Application.isPlaying)
            {
                EditorUtility.SetDirty(target);
                RefreshPreviewTargets();
            }
        }

        protected override void DrawAdvancedFields()
        {
            EditorGUILayout.PropertyField(m_AtlasKey, new GUIContent("Atlas Key"));
            EditorGUILayout.PropertyField(m_SpriteName, new GUIContent("Sprite Name"));
        }

        protected override bool TryGetSpriteBorder(Object targetObject, out bool hasBorder)
        {
            hasBorder = false;

            if (!(targetObject is AddressableImage image)) return false;

            SerializedObject imageObject = new SerializedObject(image);
            string atlasKey = imageObject.FindProperty("m_AtlasKey")?.stringValue;
            string spriteName = imageObject.FindProperty("m_SpriteName")?.stringValue;

            SpriteAtlas atlas = AddressableEditorPreviewResolver.LoadSpriteAtlas(atlasKey);
            Sprite sprite = AddressableEditorPreviewResolver.GetSpriteFromAtlas(atlas, spriteName);

            if (sprite == null) return false;

            hasBorder = sprite.border.sqrMagnitude > 0f;
            DestroyImmediate(sprite);
            return true;
        }

        protected override void RefreshPreviewTargets()
        {
            foreach (Object targetObject in targets)
            {
                if (targetObject is AddressableImage image)
                    image.RefreshEditorPreview();
            }

            SceneView.RepaintAll();
        }

        public override void OnPreviewGUI(Rect rect, GUIStyle background)
        {
            SpriteAtlas atlas = AddressableEditorPreviewResolver.LoadSpriteAtlas(m_AtlasKey.stringValue);
            Sprite sprite = GetPreviewSprite(atlas, m_SpriteName.stringValue);

            if (sprite == null) return;

            SpriteDrawUtility.DrawSprite(sprite, rect, ((Graphic)target).canvasRenderer.GetColor());
        }

        public override string GetInfoString()
        {
            SpriteAtlas atlas = AddressableEditorPreviewResolver.LoadSpriteAtlas(m_AtlasKey.stringValue);
            Sprite sprite = GetPreviewSprite(atlas, m_SpriteName.stringValue);

            int x = sprite != null ? Mathf.RoundToInt(sprite.rect.width) : 0;
            int y = sprite != null ? Mathf.RoundToInt(sprite.rect.height) : 0;

            return $"Image Size: {x}x{y}";
        }
    }
}
#endif
