﻿#if UNITY_EDITOR
using System;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;
using UnityEngine.U2D;

namespace jjevol
{
    public static class AddressableEditorPreviewResolver
    {
        public static string GetAddressOrName(UnityEngine.Object asset)
        {
            if (asset == null) return string.Empty;

            string path = AssetDatabase.GetAssetPath(asset);
            if (!string.IsNullOrEmpty(path))
            {
                string guid = AssetDatabase.AssetPathToGUID(path);
                var entry = FindEntryByGuid(guid);

                if (entry != null && !string.IsNullOrEmpty(entry.address))
                    return entry.address;
            }

            return asset.name;
        }

        /// <summary>
        /// 에셋이 Addressables에 등록돼 있는지 돌려준다. 폴더 항목에 포함된 에셋도 등록으로 본다.
        /// </summary>
        public static bool IsAddressableAsset(UnityEngine.Object asset)
        {
            if (asset == null) return false;

            string path = AssetDatabase.GetAssetPath(asset);
            if (string.IsNullOrEmpty(path)) return false;

            var settings = AddressableAssetSettingsDefaultObject.Settings;
            return settings != null && settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(path), true) != null;
        }

        public static Sprite LoadSprite(string key)
        {
            if (string.IsNullOrEmpty(key)) return null;

            var entry = FindEntryByAddress(key);
            if (entry != null)
            {
                string path = AssetDatabase.GUIDToAssetPath(entry.guid);
                var sprite = LoadSpriteFromPath(path, key);

                if (sprite != null)
                    return sprite;
            }

            foreach (string guid in AssetDatabase.FindAssets(key))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var sprite = LoadSpriteFromPath(path, key);

                if (sprite != null)
                    return sprite;
            }

            return null;
        }

        public static SpriteAtlas LoadSpriteAtlas(string key)
        {
            if (string.IsNullOrEmpty(key)) return null;

            var entry = FindEntryByAddress(key);
            if (entry != null)
            {
                string path = AssetDatabase.GUIDToAssetPath(entry.guid);
                var atlas = AssetDatabase.LoadAssetAtPath<SpriteAtlas>(path);

                if (atlas != null)
                    return atlas;
            }

            foreach (string guid in AssetDatabase.FindAssets($"{key} t:SpriteAtlas"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var atlas = AssetDatabase.LoadAssetAtPath<SpriteAtlas>(path);

                if (atlas != null && atlas.name == key)
                    return atlas;
            }

            foreach (string guid in AssetDatabase.FindAssets("t:SpriteAtlas"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                var atlas = AssetDatabase.LoadAssetAtPath<SpriteAtlas>(path);

                if (atlas == null) continue;
                if (atlas.name == key) return atlas;
                if (atlas.tag == key) return atlas;
            }

            return null;
        }

        public static Sprite GetSpriteFromAtlas(SpriteAtlas atlas, string spriteName)
        {
            if (atlas == null) return null;
            if (string.IsNullOrEmpty(spriteName)) return null;

            string normalizedName = NormalizeSpriteName(spriteName);
            var sprite = atlas.GetSprite(normalizedName);

            if (sprite == null)
                sprite = atlas.GetSprite($"{normalizedName}(Clone)");

            return sprite;
        }

        public static string[] GetSpriteNames(SpriteAtlas atlas)
        {
            if (atlas == null || atlas.spriteCount <= 0)
                return Array.Empty<string>();

            Sprite[] sprites = new Sprite[atlas.spriteCount];
            atlas.GetSprites(sprites);

            var names = sprites
                .Where(sprite => sprite != null)
                .Select(sprite => NormalizeSpriteName(sprite.name))
                .Distinct()
                .OrderBy(name => name)
                .ToArray();
            foreach(var sprite in sprites)if(sprite!=null)UnityEngine.Object.DestroyImmediate(sprite);
            return names;
        }

        public static string NormalizeSpriteName(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return value.Replace("(Clone)", string.Empty);
        }

        private static Sprite LoadSpriteFromPath(string path, string preferredName)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string normalizedName = NormalizeSpriteName(preferredName);

            var mainSprite = AssetDatabase.LoadAssetAtPath<Sprite>(path);
            if (mainSprite != null)
            {
                if (string.IsNullOrEmpty(normalizedName) ||
                    NormalizeSpriteName(mainSprite.name) == normalizedName)
                {
                    return mainSprite;
                }
            }

            var subSprites = AssetDatabase.LoadAllAssetRepresentationsAtPath(path)
                .OfType<Sprite>()
                .ToArray();

            if (subSprites.Length == 0)
                return mainSprite;

            var exact = subSprites.FirstOrDefault(sprite =>
                NormalizeSpriteName(sprite.name) == normalizedName);

            return exact != null ? exact : subSprites[0];
        }

        private static AddressableAssetEntry FindEntryByAddress(string address)
        {
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            if (settings == null || string.IsNullOrEmpty(address)) return null;

            foreach (var group in settings.groups)
            {
                if (group == null) continue;

                foreach (var entry in group.entries)
                {
                    if (entry == null) continue;
                    if (entry.address == address)
                        return entry;
                }
            }

            return null;
        }

        private static AddressableAssetEntry FindEntryByGuid(string guid)
        {
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            if (settings == null || string.IsNullOrEmpty(guid)) return null;

            foreach (var group in settings.groups)
            {
                if (group == null) continue;

                foreach (var entry in group.entries)
                {
                    if (entry == null) continue;
                    if (entry.guid == guid)
                        return entry;
                }
            }

            return null;
        }
    }
}
#endif
