using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using UnityEngine.U2D;
using System.Linq;

public class SpriteSelectorWindow : ScriptableWizard
{
    static public SpriteSelectorWindow instance;

    void OnEnable() { instance = this; }
    void OnDisable()
    {
        if (instance == this) instance = null;
        if (arrSprites != null) foreach (var sprite in arrSprites) if (sprite) DestroyImmediate(sprite);
        arrSprites = null;
        if (mBackdropTex) DestroyImmediate(mBackdropTex);
        mCallback = null;
    }

    Texture2D mBackdropTex;
    public Texture2D backdropTexture
    {
        get
        {
            if (mBackdropTex == null) mBackdropTex = CreateCheckerTex(
                new Color(0.1f, 0.1f, 0.1f, 0.5f),
                new Color(0.2f, 0.2f, 0.2f, 0.5f));
            return mBackdropTex;
        }
    }

    SpriteAtlas curAtlas;
    Sprite[] arrSprites;
    Sprite selectedSprite;

    string str_search;
    Vector2 mPos;
    System.Action<Sprite> mCallback;

    static public void Show(SpriteAtlas atlas, Sprite sprite, System.Action<Sprite> callback)
    {
        if (instance != null)
        {
            instance.Close();
            instance = null;
        }

        SpriteSelectorWindow comp = ScriptableWizard.DisplayWizard<SpriteSelectorWindow>("Select a Sprite");

        comp.curAtlas = atlas;
        comp.selectedSprite = sprite;
        comp.mCallback = callback;
        comp.SetSpritesArray();
    }

    void SetSpritesArray()
    {
        if (curAtlas == null) return;

        if (arrSprites != null) foreach (var sprite in arrSprites) if (sprite) DestroyImmediate(sprite);
        arrSprites = new Sprite[curAtlas.spriteCount];
        curAtlas.GetSprites(arrSprites);
    }

    void OnGUI()
    {
        DrawSpriteSearch();
        DrawSpriteList();
    }

    void DrawSpriteSearch()
    {
        GUILayout.BeginHorizontal();
        str_search = GUILayout.TextField(str_search, GUI.skin.FindStyle("ToolbarSearchTextField"));
        if (GUILayout.Button("", GUI.skin.FindStyle("ToolbarSearchCancelButton")))
        {
            str_search = string.Empty;
            GUI.FocusControl(null);
        }
        GUILayout.EndHorizontal();
    }

    void DrawSpriteList()
    {
        if (curAtlas == null || arrSprites == null) return;

        float size = 80f;
        float padded = size + 20f;
        int columns = Mathf.FloorToInt((EditorGUIUtility.currentViewWidth - 20f) / padded);
        if (columns < 1) columns = 1;

        List<Sprite> _resultSprite = new List<Sprite>(arrSprites);
        if (!string.IsNullOrEmpty(str_search))
        {
            _resultSprite = _resultSprite.Where(s => s.name.Contains(str_search, System.StringComparison.OrdinalIgnoreCase)).ToList();
        }

        mPos = GUILayout.BeginScrollView(mPos);
        int index = 0;

        while (index < _resultSprite.Count)
        {
            GUILayout.BeginHorizontal();
            for (int col = 0; col < columns && index < _resultSprite.Count; ++col)
            {
                GUILayout.BeginVertical(GUILayout.Width(size));
                Rect rect = GUILayoutUtility.GetRect(size, size);
                if (GUI.Button(rect, GUIContent.none))
                {
                    selectedSprite = _resultSprite[index];
                    mCallback?.Invoke(selectedSprite);
                    Close();
                }

                if (Event.current.type == EventType.Repaint)
                {
                    DrawTexture(rect, backdropTexture);
                    DrawSpritePreview(_resultSprite[index], rect);
                }

                GUILayout.Label(_resultSprite[index].name, "ProgressBarBack", GUILayout.Width(size));
                GUILayout.EndVertical();
                index++;
            }
            GUILayout.EndHorizontal();
        }

        GUILayout.EndScrollView();
    }

    void DrawSpritePreview(Sprite sprite, Rect rect)
    {
        if (sprite == null) return;

        Rect uv = sprite.textureRect;
        uv.x /= sprite.texture.width;
        uv.width /= sprite.texture.width;
        uv.y /= sprite.texture.height;
        uv.height /= sprite.texture.height;

        GUI.DrawTextureWithTexCoords(rect, sprite.texture, uv);
    }

    void DrawTexture(Rect rect, Texture tex)
    {
        GUI.BeginGroup(rect);
        for (int y = 0; y < rect.height; y += tex.height)
        {
            for (int x = 0; x < rect.width; x += tex.width)
            {
                GUI.DrawTexture(new Rect(x, y, tex.width, tex.height), tex);
            }
        }
        GUI.EndGroup();
    }

    Texture2D CreateCheckerTex(Color c0, Color c1)
    {
        Texture2D tex = new Texture2D(16, 16);
        tex.name = "CheckerTexture";
        tex.hideFlags = HideFlags.DontSave;

        for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) tex.SetPixel(x, y, c1);
        for (int y = 8; y < 16; y++) for (int x = 0; x < 8; x++) tex.SetPixel(x, y, c0);
        for (int y = 0; y < 8; y++) for (int x = 8; x < 16; x++) tex.SetPixel(x, y, c0);
        for (int y = 8; y < 16; y++) for (int x = 8; x < 16; x++) tex.SetPixel(x, y, c1);

        tex.Apply();
        tex.filterMode = FilterMode.Point;
        return tex;
    }
}
