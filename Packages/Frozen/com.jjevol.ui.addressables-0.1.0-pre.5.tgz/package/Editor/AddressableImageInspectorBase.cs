#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
using UnityEditor.AnimatedValues;
using UnityEditor.UI;
using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    /// <summary>
    /// AddressableImageInspector와 AddressableTextureInspector의 Runtime, Loading, Image Type GUI를 합친다.
    /// Edit Mode의 m_Sprite를 비우는 규칙은 각 Inspector의 OnInspectorGUI가 유지한다.
    /// </summary>
    public abstract class AddressableImageInspectorBase : GraphicEditor
    {
        private static readonly GUIContent LoadOnEnableContent = new GUIContent("Load On Enable", "활성화될 때 저장된 키로 이미지를 로드합니다.");
        private static readonly GUIContent ReleaseOnDisableContent = new GUIContent("Release On Disable", "비활성화될 때 표시를 지우고 lease를 반환합니다. 다시 표시하려면 Load On Enable이 필요합니다.");
        private static readonly GUIContent ClearSpriteOnDisableContent = new GUIContent("Clear Sprite On Disable", "비활성화될 때 표시만 지우고 lease는 유지합니다. Release On Disable이 켜져 있으면 무시됩니다.");
        private static readonly GUIContent ReleaseDelayContent = new GUIContent("Release Delay", "단위: 초(실시간). 이미지를 교체하거나 해제한 뒤 lease 반환을 미루는 시간입니다. 기다리는 동안 참조가 유지됩니다. 0 이하는 즉시 반환합니다.");
        private static readonly GUIContent ShowLoadingContent = new GUIContent("Show Loading", "로드 중 로딩 표시를 켭니다. 이 값이 유일한 스위치이며, 꺼져 있으면 전역 로딩도 표시하지 않습니다.");
        private static readonly GUIContent LoadingViewContent = new GUIContent("Loading View", "이 이미지 전용 로딩 표시입니다. 비어 있으면 UIManager의 전역 로딩 뷰를 사용합니다.");
        private static readonly GUIContent ImageTypeContent = new GUIContent("Image Type");
        private static readonly GUIContent ClockwiseContent = new GUIContent("Clockwise");

        protected SerializedProperty m_Sprite;

        protected SerializedProperty m_Type;
        private SerializedProperty m_FillCenter;
        private SerializedProperty m_FillMethod;
        private SerializedProperty m_FillOrigin;
        private SerializedProperty m_FillClockwise;
        private SerializedProperty m_FillAmount;
        private SerializedProperty m_PreserveAspect;

        private SerializedProperty m_LoadOnEnable;
        private SerializedProperty m_ReleaseOnDisable;
        private SerializedProperty m_ClearSpriteOnDisable;
        private SerializedProperty m_ReleaseDelay;

        private SerializedProperty m_ShowLoading;
        private SerializedProperty m_LoadingView;

        private AnimBool m_ShowType;
        private AnimBool m_ShowSlicedOrTiled;
        private AnimBool m_ShowSliced;
        private AnimBool m_ShowFilled;

        private bool _showRuntime;
        private bool _showLoading;
        private bool _showAdvanced;

        /// <summary>컴포넌트별 키 SerializedProperty를 찾는다. 공통 초기화 전에 호출된다.</summary>
        protected abstract void BindKeyProperties();

        /// <summary>이미지가 선택돼 있어 Image Type GUI를 표시할지 여부다.</summary>
        protected abstract bool HasSelection { get; }

        /// <summary>대상의 선택 이미지를 찾아 border 여부를 돌려준다. 찾지 못하면 false다.</summary>
        protected abstract bool TryGetSpriteBorder(Object targetObject, out bool hasBorder);

        /// <summary>Advanced Foldout 내용. 컴포넌트별 키 필드를 그린다.</summary>
        protected abstract void DrawAdvancedFields();

        /// <summary>Loading Foldout에 추가할 컴포넌트별 필드.</summary>
        protected virtual void DrawLoadingFields() { }

        protected abstract void RefreshPreviewTargets();

        protected override void OnEnable()
        {
            base.OnEnable();

            BindKeyProperties();

            m_Sprite = serializedObject.FindProperty("m_Sprite");

            m_Type = serializedObject.FindProperty("m_Type");
            m_FillCenter = serializedObject.FindProperty("m_FillCenter");
            m_FillMethod = serializedObject.FindProperty("m_FillMethod");
            m_FillOrigin = serializedObject.FindProperty("m_FillOrigin");
            m_FillClockwise = serializedObject.FindProperty("m_FillClockwise");
            m_FillAmount = serializedObject.FindProperty("m_FillAmount");
            m_PreserveAspect = serializedObject.FindProperty("m_PreserveAspect");

            m_LoadOnEnable = serializedObject.FindProperty("m_LoadOnEnable");
            m_ReleaseOnDisable = serializedObject.FindProperty("m_ReleaseOnDisable");
            m_ClearSpriteOnDisable = serializedObject.FindProperty("m_ClearSpriteOnDisable");
            m_ReleaseDelay = serializedObject.FindProperty("m_ReleaseDelay");

            m_ShowLoading = serializedObject.FindProperty("m_ShowLoading");
            m_LoadingView = serializedObject.FindProperty("m_LoadingView");

            Image.Type typeEnum = (Image.Type)m_Type.enumValueIndex;

            m_ShowType = new AnimBool(HasSelection);
            m_ShowType.valueChanged.AddListener(Repaint);

            m_ShowSlicedOrTiled = new AnimBool(!m_Type.hasMultipleDifferentValues && typeEnum == Image.Type.Sliced);
            m_ShowSliced = new AnimBool(!m_Type.hasMultipleDifferentValues && typeEnum == Image.Type.Sliced);
            m_ShowFilled = new AnimBool(!m_Type.hasMultipleDifferentValues && typeEnum == Image.Type.Filled);

            m_ShowSlicedOrTiled.valueChanged.AddListener(Repaint);
            m_ShowSliced.valueChanged.AddListener(Repaint);
            m_ShowFilled.valueChanged.AddListener(Repaint);

            SetShowNativeSize(true);
        }

        protected override void OnDisable()
        {
            m_ShowType?.valueChanged.RemoveListener(Repaint);
            m_ShowSlicedOrTiled?.valueChanged.RemoveListener(Repaint);
            m_ShowSliced?.valueChanged.RemoveListener(Repaint);
            m_ShowFilled?.valueChanged.RemoveListener(Repaint);
            base.OnDisable();
        }

        /// <summary>키 입력 GUI 아래의 공통 영역을 그린다.</summary>
        protected void DrawCommonGUI()
        {
            AppearanceControlsGUI();
            RaycastControlsGUI();
            MaskableControlsGUI();

            m_ShowType.target = HasSelection;

            if (EditorGUILayout.BeginFadeGroup(m_ShowType.faded))
                TypeGUI();

            EditorGUILayout.EndFadeGroup();

            SetShowNativeSize(false);

            if (EditorGUILayout.BeginFadeGroup(m_ShowNativeSize.faded))
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(m_PreserveAspect);
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.EndFadeGroup();

            NativeSizeButtonGUI();

            DrawRuntimeGUI();
            DrawLoadingGUI();
            DrawAdvancedGUI();
        }

        /// <summary>Addressables에 등록되지 않은 이미지를 고른 경우 런타임 실패를 경고한다.</summary>
        protected static void DrawUnregisteredWarning(Object asset, string key)
        {
            if (asset == null || string.IsNullOrEmpty(key) || AddressableEditorPreviewResolver.IsAddressableAsset(asset))
                return;

            EditorGUILayout.HelpBox(
                $"Addressable로 등록되지 않은 에셋입니다. 에디터 프리뷰는 보이지만 런타임 로드는 실패합니다.\nKey: {key}",
                MessageType.Warning
            );
        }

        private void DrawRuntimeGUI()
        {
            _showRuntime = EditorGUILayout.Foldout(_showRuntime, "Runtime", true);
            if (!_showRuntime) return;

            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(m_LoadOnEnable, LoadOnEnableContent);
            EditorGUILayout.PropertyField(m_ReleaseOnDisable, ReleaseOnDisableContent);
            EditorGUILayout.PropertyField(m_ClearSpriteOnDisable, ClearSpriteOnDisableContent);
            EditorGUILayout.PropertyField(m_ReleaseDelay, ReleaseDelayContent);

            if (m_ReleaseOnDisable.boolValue && m_ClearSpriteOnDisable.boolValue)
                EditorGUILayout.HelpBox("Release On Disable이 우선하므로 Clear Sprite On Disable은 적용되지 않습니다.", MessageType.Info);

            EditorGUI.indentLevel--;
        }

        private void DrawLoadingGUI()
        {
            _showLoading = EditorGUILayout.Foldout(_showLoading, "Loading", true);
            if (!_showLoading) return;

            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(m_ShowLoading, ShowLoadingContent);
            EditorGUILayout.PropertyField(m_LoadingView, LoadingViewContent);
            DrawLoadingFields();

            if (m_ShowLoading.boolValue && m_LoadingView.objectReferenceValue == null)
                EditorGUILayout.HelpBox("Loading View가 없으면 UIManager의 전역 로딩 뷰를 사용합니다. 전역 뷰도 없으면 표시되지 않습니다.", MessageType.Info);

            EditorGUI.indentLevel--;
        }

        private void DrawAdvancedGUI()
        {
            _showAdvanced = EditorGUILayout.Foldout(_showAdvanced, "Advanced", true);
            if (!_showAdvanced) return;

            EditorGUI.indentLevel++;
            DrawAdvancedFields();
            EditorGUI.indentLevel--;
        }

        private void TypeGUI()
        {
            EditorGUILayout.PropertyField(m_Type, ImageTypeContent);

            ++EditorGUI.indentLevel;
            {
                Image.Type typeEnum = (Image.Type)m_Type.enumValueIndex;

                bool showSlicedOrTiled = !m_Type.hasMultipleDifferentValues &&
                                         (typeEnum == Image.Type.Sliced || typeEnum == Image.Type.Tiled);

                if (showSlicedOrTiled && targets.Length > 1)
                    showSlicedOrTiled = targets.All(item => TryGetSpriteBorder(item, out bool border) && border);

                m_ShowSlicedOrTiled.target = showSlicedOrTiled;
                m_ShowSliced.target = showSlicedOrTiled && !m_Type.hasMultipleDifferentValues && typeEnum == Image.Type.Sliced;
                m_ShowFilled.target = !m_Type.hasMultipleDifferentValues && typeEnum == Image.Type.Filled;

                bool resolved = TryGetSpriteBorder(target, out bool hasSelectedSpriteBorder);

                if (EditorGUILayout.BeginFadeGroup(m_ShowSlicedOrTiled.faded))
                {
                    if (hasSelectedSpriteBorder)
                        EditorGUILayout.PropertyField(m_FillCenter);
                }

                EditorGUILayout.EndFadeGroup();

                if (EditorGUILayout.BeginFadeGroup(m_ShowSliced.faded))
                {
                    if (resolved && !hasSelectedSpriteBorder)
                        EditorGUILayout.HelpBox("This Image doesn't have a border.", MessageType.Warning);
                }

                EditorGUILayout.EndFadeGroup();

                if (EditorGUILayout.BeginFadeGroup(m_ShowFilled.faded))
                {
                    EditorGUI.BeginChangeCheck();
                    EditorGUILayout.PropertyField(m_FillMethod);

                    if (EditorGUI.EndChangeCheck())
                        m_FillOrigin.intValue = 0;

                    switch ((Image.FillMethod)m_FillMethod.enumValueIndex)
                    {
                        case Image.FillMethod.Horizontal:
                            m_FillOrigin.intValue = (int)(Image.OriginHorizontal)EditorGUILayout.EnumPopup("Fill Origin", (Image.OriginHorizontal)m_FillOrigin.intValue);
                            break;

                        case Image.FillMethod.Vertical:
                            m_FillOrigin.intValue = (int)(Image.OriginVertical)EditorGUILayout.EnumPopup("Fill Origin", (Image.OriginVertical)m_FillOrigin.intValue);
                            break;

                        case Image.FillMethod.Radial90:
                            m_FillOrigin.intValue = (int)(Image.Origin90)EditorGUILayout.EnumPopup("Fill Origin", (Image.Origin90)m_FillOrigin.intValue);
                            break;

                        case Image.FillMethod.Radial180:
                            m_FillOrigin.intValue = (int)(Image.Origin180)EditorGUILayout.EnumPopup("Fill Origin", (Image.Origin180)m_FillOrigin.intValue);
                            break;

                        case Image.FillMethod.Radial360:
                            m_FillOrigin.intValue = (int)(Image.Origin360)EditorGUILayout.EnumPopup("Fill Origin", (Image.Origin360)m_FillOrigin.intValue);
                            break;
                    }

                    EditorGUILayout.PropertyField(m_FillAmount);

                    if ((Image.FillMethod)m_FillMethod.enumValueIndex > Image.FillMethod.Vertical)
                        EditorGUILayout.PropertyField(m_FillClockwise, ClockwiseContent);
                }

                EditorGUILayout.EndFadeGroup();

                if (!m_Type.hasMultipleDifferentValues && typeEnum != Image.Type.Simple)
                    EditorGUILayout.HelpBox("Edit Mode 프리뷰는 Simple로 그립니다. 런타임의 Sliced, Tiled, Filled 결과와 다를 수 있습니다.", MessageType.Info);
            }
            --EditorGUI.indentLevel;
        }

        private void SetShowNativeSize(bool instant)
        {
            Image.Type type = (Image.Type)m_Type.enumValueIndex;
            bool showNativeSize = type == Image.Type.Simple || type == Image.Type.Filled;

            base.SetShowNativeSize(showNativeSize, instant);
        }

        public override bool HasPreviewGUI()
        {
            return true;
        }
    }
}
#endif
