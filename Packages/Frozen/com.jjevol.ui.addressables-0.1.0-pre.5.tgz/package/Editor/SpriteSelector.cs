using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.U2D;
using System;
using System.Linq;

/// <summary>
/// Editor component used to display a list of sprites.
/// </summary>

public class SpriteSelector : ScriptableWizard
{
    static public SpriteSelector instance;

    void OnEnable() { instance = this; }
    void OnDisable()
    {
        if (instance == this) instance = null;
        if (arrSprites != null) foreach (var sprite in arrSprites) if (sprite) DestroyImmediate(sprite);
        arrSprites = null;
        if (mBackdropTex) DestroyImmediate(mBackdropTex);
        mCallback = null;
    }

    public delegate void Callback(Sprite sprite);

    /// 격자무늬 배경
    Texture2D mBackdropTex;
    public Texture2D backdropTexture
    {
        get
        {
            if (mBackdropTex == null) mBackdropTex = CreateCheckerTex(
                new Color(0.1f, 0.1f, 0.1f, 0.5f),
                new Color(0.2f, 0.2f, 0.2f, 0.5f));
            return mBackdropTex;
        }
    }

    SerializedObject mObject;
    SerializedProperty mProperty;

    SpriteAtlas curAtlas, drawAtlas;
    //아틀라스에서 얻어온 복사생성된 Sprite 배열
    Sprite[] arrSprites;
    //선택한 Sprite
    Sprite selectedSprite;

    //아틀라스안에서 스프라이트 검색
    string str_search;
    //Scroll 위치
    Vector2 mPos;
    //Double 클릭 체크용 시간 변수
    float mClickTime = 0f;
    Callback mCallback;

    /// <summary>
    /// Draw the custom wizard.
    /// </summary>
    public void DrawSeparator()
    {
        GUILayout.Space(12f);

        if (Event.current.type == EventType.Repaint)
        {
            Texture2D tex = EditorGUIUtility.whiteTexture;
            Rect rect = GUILayoutUtility.GetLastRect();
            GUI.color = new Color(0f, 0f, 0f, 0.25f);
            GUI.DrawTexture(new Rect(0f, rect.yMin + 6f, Screen.width, 4f), tex);
            GUI.DrawTexture(new Rect(0f, rect.yMin + 6f, Screen.width, 1f), tex);
            GUI.DrawTexture(new Rect(0f, rect.yMin + 9f, Screen.width, 1f), tex);
            GUI.color = Color.white;
        }
    }

    static public void Show(SpriteAtlas atlas, Sprite sprite, Callback callback)
    {
        if (instance != null)
        {
            instance.Close();
            instance = null;
        }

        SpriteSelector comp = ScriptableWizard.DisplayWizard<SpriteSelector>("Select a Sprite");

        comp.curAtlas = atlas;
        comp.selectedSprite = sprite;
        comp.mCallback = callback;
    }

    private static string SetAtlasLabelToSprites(SpriteAtlas atlas, bool add)
    {
        string[] assetLabels = { AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(atlas)) };
        SerializedProperty spPackedSprites = new SerializedObject(atlas).FindProperty("m_PackedSprites");
        Sprite[] sprites = Enumerable.Range(0, spPackedSprites.arraySize)
            .Select(index => spPackedSprites.GetArrayElementAtIndex(index).objectReferenceValue)
            .OfType<Sprite>()
            .ToArray();

        foreach (var s in sprites)
        {
            string[] newLabels = add
                ? AssetDatabase.GetLabels(s).Union(assetLabels).ToArray()
                : AssetDatabase.GetLabels(s).Except(assetLabels).ToArray();
            AssetDatabase.SetLabels(s, newLabels);
        }

        return assetLabels[0];
    }

    /// <summary>
    /// 스프라이트 리스트를 그린다.
    /// </summary>
    void DrawSpriteList()
    {
        if (curAtlas == null)
            return;

        DrawSpriteSearch();

        float size = 80f;
        float padded = size + 10f;
        int screenWidth = (int)EditorGUIUtility.currentViewWidth;
        int columns = Mathf.FloorToInt(screenWidth / padded);
        if (columns < 1) columns = 1;

        int offset = 0;
        int _index = 0;
        Rect rect = new Rect(10f, 0, size, size);
        GUILayout.Space(10f);
        mPos = GUILayout.BeginScrollView(mPos);
        int rows = 1;

        List<Sprite> _resultSprite = new List<Sprite>(arrSprites);


        if (string.IsNullOrEmpty(str_search) == false)
            _resultSprite.RemoveAll(_item => _item.name.Contains(str_search) == false);
        while (offset < _resultSprite.Count)
        {
            GUILayout.BeginHorizontal();
            {
                int col = 0;
                rect.x = 10f;

                for (; offset < _resultSprite.Count; ++offset)
                {
                    if (GUI.Button(rect, ""))
                    {
                        selectedSprite = _resultSprite[_index];
                        DoubleClickEvent();
                    }

                    if (Event.current.type == EventType.Repaint)
                    {
                        DrawTexture(rect, backdropTexture);

                        Rect uv = _resultSprite[_index].textureRect;
                       // uv = ConvertToTexCoords(uv, _resultSprite[_index].rect.width, _resultSprite[_index].rect.height);
                      
                        uv = ConvertToTexCoords(uv, _resultSprite[_index].texture.width, _resultSprite[_index].texture.height);

                        float scaleX = rect.width / uv.width;
                        float scaleY = rect.height / uv.height;

                        float aspect = (scaleY / scaleX);
                        Rect clipRect = rect;
                        if (aspect != 1f)
                        {
                            if (aspect < 1f)
                            {
                                float padding = size * (1f - aspect) * 0.5f;
                                clipRect.xMin += padding;
                                clipRect.xMax -= padding;
                            }
                            else
                            {
                                float padding = size * (1f - 1f / aspect) * 0.5f;
                                clipRect.yMin += padding;
                                clipRect.yMax -= padding;
                            }
                        }

                        GUI.DrawTextureWithTexCoords(clipRect, _resultSprite[_index].texture, uv);

                        if (selectedSprite == _resultSprite[_index])
                        {
                            DrawOutline(rect, new Color(0.4f, 1f, 0f, 1f));
                        }
                    }

                    GUI.backgroundColor = new Color(1f, 1f, 1f, 0.5f);
                    GUI.contentColor = new Color(1f, 1f, 1f, 0.7f);
                    GUI.Label(new Rect(rect.x, rect.y + rect.height, rect.width, 32f), _resultSprite[_index].name.Replace("(Clone)", ""), "ProgressBarBack");
                    GUI.contentColor = Color.white;
                    GUI.backgroundColor = Color.white;
                    _index++;

                    if (++col >= columns)
                    {
                        ++offset;
                        break;
                    }
                    rect.x += padded;
                }
            }
            GUILayout.EndHorizontal();
            GUILayout.Space(padded);
            rect.y += padded + 26;
            ++rows;
        }
        GUILayout.Space(rows * 26);
        GUILayout.EndScrollView();
    }

    void DrawSpriteSearch()
    {
        GUILayout.BeginHorizontal();
        GUIStyle _gUIStyle = GUI.skin.FindStyle("ToolbarSearchTextField");
        _gUIStyle.stretchWidth = true;
        str_search = EditorGUILayout.TextField(str_search, _gUIStyle);
        if (GUILayout.Button("", GUI.skin.FindStyle("ToolbarSearchCancelButton")))
        {
            // Remove focus if cleared
            str_search = string.Empty;
            GUI.FocusControl(null);
        }
        GUILayout.EndHorizontal();
    }
    /// <summary>
    /// 타일 텍스쳐 그리기
    /// </summary>
    /// <param name="rect">그리는 영역</param>
    /// <param name="tex">이미지 텍스쳐</param>
    void DrawTexture(Rect rect, Texture tex)
    {
        GUI.BeginGroup(rect);
        {
            int width = Mathf.RoundToInt(rect.width);
            int height = Mathf.RoundToInt(rect.height);

            for (int y = 0; y < height; y += tex.height)
            {
                for (int x = 0; x < width; x += tex.width)
                {
                    GUI.DrawTexture(new Rect(x, y, tex.width, tex.height), tex);
                }
            }
        }
        GUI.EndGroup();
    }

    /// <summary>
    /// 아웃라인 그리기
    /// </summary>
    /// <param name="rect">그리는 영역</param>
    /// <param name="color">색상</param>
    void DrawOutline(Rect rect, Color color)
    {
        if (Event.current.type == EventType.Repaint)
        {
            Texture2D tex = EditorGUIUtility.whiteTexture;
            GUI.color = color;
            GUI.DrawTexture(new Rect(rect.xMin, rect.yMin, 1f, rect.height), tex);
            GUI.DrawTexture(new Rect(rect.xMax, rect.yMin, 1f, rect.height), tex);
            GUI.DrawTexture(new Rect(rect.xMin, rect.yMin, rect.width, 1f), tex);
            GUI.DrawTexture(new Rect(rect.xMin, rect.yMax, rect.width, 1f), tex);
            GUI.color = Color.white;
        }
    }

    /// <summary>
    /// 체크무늬 텍스쳐 세팅
    /// </summary>
    /// <param name="c0">체크 색상</param>
    /// <param name="c1">체크 색상</param>
    /// <returns></returns>
    Texture2D CreateCheckerTex(Color c0, Color c1)
    {
        Texture2D tex = new Texture2D(16, 16);
        tex.name = "[Generated] Checker Texture";
        tex.hideFlags = HideFlags.DontSave;

        for (int y = 0; y < 8; ++y) for (int x = 0; x < 8; ++x) tex.SetPixel(x, y, c1);
        for (int y = 8; y < 16; ++y) for (int x = 0; x < 8; ++x) tex.SetPixel(x, y, c0);
        for (int y = 0; y < 8; ++y) for (int x = 8; x < 16; ++x) tex.SetPixel(x, y, c0);
        for (int y = 8; y < 16; ++y) for (int x = 8; x < 16; ++x) tex.SetPixel(x, y, c1);

        tex.Apply();
        tex.filterMode = FilterMode.Point;
        return tex;
    }

    Rect ConvertToTexCoords(Rect rect, int width, int height)
    {
        Rect final = rect;

        if (width != 0f && height != 0f)
        {
            final.xMin = rect.xMin / width;
            final.xMax = rect.xMax / width;
            final.yMin = rect.yMin / height;
            final.yMax = rect.yMax / height;
        }
        return final;
    }

    void OnGUI()
    {
        DrawSpriteSelector();
        DrawSpriteList();
    }

    /// <summary>
    /// 스프라이트 선택 GUI를 그린다.
    /// </summary>
    void DrawSpriteSelector()
    {
        if (curAtlas == null)
        {
            GUILayout.BeginHorizontal();
            GUI.enabled = false;
            GUILayout.TextField("Select Atlas");
            GUILayout.EndHorizontal();
        }
        else
        {
            SetSpritesArray();
        }
        GUI.enabled = true;
    }

    /// <summary>
    /// 스프라이트 배열을 세팅한다.
    /// </summary>
    void SetSpritesArray(bool _forced = false)
    {
        //지금 그리고 있는 아틀라스가 없거나 다른경우에 해당 아틀라스에서 스프라이트들을 얻는다.
        if (_forced == true || drawAtlas == null || drawAtlas != curAtlas)
        {
            drawAtlas = curAtlas;
           // arrSprites = new Sprite[curAtlas.spriteCount];

            if (arrSprites != null) foreach (var sprite in arrSprites) if (sprite) DestroyImmediate(sprite);
            arrSprites = new Sprite[curAtlas.spriteCount];
            curAtlas.GetSprites(arrSprites);
        }
    }

    void DoubleClickEvent()
    {
        if (Event.current.button == 0)
        {
            float delta = Time.realtimeSinceStartup - mClickTime;
            mClickTime = Time.realtimeSinceStartup;

            if (selectedSprite != null)// && delta < 0.5f)
            {
                SetSprite(selectedSprite);
                Close();
            }
        }
    }

    void SetSprite(Sprite _spriteName)
    {
        if (mCallback != null)
            mCallback(_spriteName);
    }
}
