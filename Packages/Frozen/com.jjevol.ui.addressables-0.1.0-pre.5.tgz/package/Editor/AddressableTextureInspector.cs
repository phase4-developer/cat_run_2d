﻿#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    [CustomEditor(typeof(AddressableTexture), true)]
    [CanEditMultipleObjects]
    public class AddressableTextureInspector : AddressableImageInspectorBase
    {
        private static readonly GUIContent LoadingColorContent = new GUIContent("Loading Color", "로딩 표시 동안 적용할 색입니다. 로딩이 끝나면 로딩 시작 시점의 색으로 돌아갑니다.");
        private static readonly GUIContent FadeColorDurationContent = new GUIContent("Fade Color Duration", "단위: 초(실시간). 로딩 색으로 바뀌고 돌아오는 시간입니다.");
        private static readonly GUIContent SkipLoadingContent = new GUIContent("Skip Loading For Cached Image", "이미 로드된 키는 로딩 표시와 색 변경을 건너뜁니다.");

        private SerializedProperty m_SpriteKey;

        private SerializedProperty m_LoadingColor;
        private SerializedProperty m_FadeColorDuration;
        private SerializedProperty m_SkipLoadingForCachedImage;

        private GUIContent m_SourceImageContent;

        protected override bool HasSelection => !string.IsNullOrEmpty(m_SpriteKey.stringValue);

        protected override void BindKeyProperties()
        {
            m_SourceImageContent = new GUIContent("Source Image");

            m_SpriteKey = serializedObject.FindProperty("m_SpriteKey");

            m_LoadingColor = serializedObject.FindProperty("m_LoadingColor");
            m_FadeColorDuration = serializedObject.FindProperty("m_FadeColorDuration");
            m_SkipLoadingForCachedImage = serializedObject.FindProperty("m_SkipLoadingForCachedImage");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            bool changed = false;

            EditorGUI.BeginChangeCheck();

            SourceImageGUI();

            DrawCommonGUI();

            if (EditorGUI.EndChangeCheck())
                changed = true;

            // Edit Mode에서만 직접 Sprite 참조를 제거한다.
            // Play Mode의 m_Sprite는 AddressableTexture가 런타임에 표시 중인 실제 Sprite라서 지우면 화면이 깨진다.
            if (!Application.isPlaying && m_Sprite.objectReferenceValue != null)
            {
                m_Sprite.objectReferenceValue = null;
                changed = true;
            }

            if (changed)
            {
                bool applied = serializedObject.ApplyModifiedProperties();

                // 프리팹 저장/에디터 프리뷰 갱신은 Edit Mode에서만 한다.
                // Play Mode에서 SetDirty/RefreshPreviewTargets를 호출하면 실행 중 오브젝트 상태를 건드릴 수 있다.
                if (applied && !Application.isPlaying)
                {
                    EditorUtility.SetDirty(target);
                    RefreshPreviewTargets();
                }
            }
            else
            {
                serializedObject.ApplyModifiedPropertiesWithoutUndo();
            }
        }
        private void SourceImageGUI()
        {
            Sprite currentSprite = AddressableEditorPreviewResolver.LoadSprite(m_SpriteKey.stringValue);

            EditorGUI.BeginChangeCheck();

            Sprite selectedSprite = EditorGUILayout.ObjectField(
                m_SourceImageContent,
                currentSprite,
                typeof(Sprite),
                false
            ) as Sprite;

            if (EditorGUI.EndChangeCheck())
            {
                if (selectedSprite != null)
                    m_SpriteKey.stringValue = AddressableEditorPreviewResolver.GetAddressOrName(selectedSprite);
                else
                    m_SpriteKey.stringValue = string.Empty;

                // Edit Mode에서만 직접 Sprite 참조를 제거한다.
                // Play Mode에서는 현재 표시 중인 런타임 Sprite를 지우면 안 된다.
                if (!Application.isPlaying)
                    m_Sprite.objectReferenceValue = null;
            }

            DrawUnregisteredWarning(currentSprite, m_SpriteKey.stringValue);

            if (!string.IsNullOrEmpty(m_SpriteKey.stringValue) && currentSprite == null)
            {
                EditorGUILayout.HelpBox(
                    $"Sprite Key로 에디터 프리뷰 Sprite를 찾지 못했습니다.\nKey: {m_SpriteKey.stringValue}",
                    MessageType.Info
                );
            }
        }

        protected override void DrawLoadingFields()
        {
            EditorGUILayout.PropertyField(m_LoadingColor, LoadingColorContent);
            EditorGUILayout.PropertyField(m_FadeColorDuration, FadeColorDurationContent);
            EditorGUILayout.PropertyField(m_SkipLoadingForCachedImage, SkipLoadingContent);
        }

        protected override void DrawAdvancedFields()
        {
            EditorGUILayout.PropertyField(m_SpriteKey, new GUIContent("Sprite Key"));
        }

        protected override bool TryGetSpriteBorder(Object targetObject, out bool hasBorder)
        {
            hasBorder = false;

            if (!(targetObject is AddressableTexture texture)) return false;

            Sprite sprite = AddressableEditorPreviewResolver.LoadSprite(texture.spriteKey);

            if (sprite == null) return false;

            hasBorder = sprite.border.sqrMagnitude > 0f;
            return true;
        }

        protected override void RefreshPreviewTargets()
        {
            foreach (var targetObject in targets)
            {
                if (targetObject is AddressableTexture texture)
                    texture.RefreshEditorPreview();
            }

            SceneView.RepaintAll();
        }

        public override void OnPreviewGUI(Rect rect, GUIStyle background)
        {
            Sprite sprite = AddressableEditorPreviewResolver.LoadSprite(m_SpriteKey.stringValue);
            if (sprite == null) return;

            SpriteDrawUtility.DrawSprite(sprite, rect, ((Graphic)target).canvasRenderer.GetColor());
        }

        public override string GetInfoString()
        {
            Sprite sprite = AddressableEditorPreviewResolver.LoadSprite(m_SpriteKey.stringValue);

            int x = sprite != null ? Mathf.RoundToInt(sprite.rect.width) : 0;
            int y = sprite != null ? Mathf.RoundToInt(sprite.rect.height) : 0;

            return $"Image Size: {x}x{y}";
        }
    }
}
#endif
