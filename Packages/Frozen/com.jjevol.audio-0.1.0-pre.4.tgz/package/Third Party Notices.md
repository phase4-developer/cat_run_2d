# Source and dependencies

The source reference is {workspace}/jjevol_library_mobile/Assets/Common/Script/Sound. User confirmation/correction on 2026-10-30 authorizes adapting their Sound system for the Framework and replacing its parent/event/table coupling. Git history records the tracked import at 119635c; this is not proof of first creation or a public redistribution license.

Original transferred class names, serialized field names and script/folder GUIDs are preserved except for the explicitly documented SoundType/table API change. Source and destination hashes are recorded in Framework Docs/AudioExtraction.

No MoreMountains implementation, CodeStage, PathologicalGames, paid Vendor source, company content, clips, mixers or product settings are redistributed. The small owned AudioEvents implementation is not a copied MMEventManager.

Unity engine audio/JSON modules are declared dependencies resolved by Unity. Their terms are separate. This candidate does not assign a public distribution license or establish a company's Unity license eligibility.
