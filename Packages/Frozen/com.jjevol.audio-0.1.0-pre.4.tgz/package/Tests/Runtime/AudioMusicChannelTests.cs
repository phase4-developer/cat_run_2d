using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Audio.Tests
{
    public sealed class AudioMusicChannelTests
    {
        // SlowFade outlasts any frame, so a test can act in the middle of a fade without counting frames.
        private const float Fade = 0.15f, AfterFade = 0.35f, SlowFade = 1f;
        private AudioManager _manager;
        private KeyedProvider _provider;
        private AudioClip _clip, _other;
        private GameObject _listener;
        private readonly List<GameObject> _spawned = new();

        private sealed class KeyedProvider : IAudioClipLeaseProvider
        {
            internal AudioClip Clip;
            internal readonly Dictionary<string, TaskCompletionSource<bool>> Gates = new(StringComparer.Ordinal);
            internal readonly HashSet<string> Missing = new(StringComparer.Ordinal);
            internal int Acquired, Released;
            public Task<AudioClip> LoadClipAsync(AudioTrack track, string key) => Task.FromResult(Clip);
            public async Task<AudioClipLease> AcquireAsync(AudioTrack track, string key, CancellationToken token)
            {
                // Finishes late even after cancellation, to test the manager's final ownership guard.
                if (Gates.TryGetValue(key, out var gate)) await gate.Task;
                if (Missing.Contains(key)) return null;
                Acquired++;
                return new AudioClipLease(Clip, () => Released++);
            }
            internal TaskCompletionSource<bool> Hold(string key) => Gates[key] = new TaskCompletionSource<bool>();
        }

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _clip = AudioClip.Create("music-channel-test", 44100, 1, 44100, false);
            _other = AudioClip.Create("music-channel-other", 44100, 1, 44100, false);
            if (!Object.FindAnyObjectByType<AudioListener>()) _listener = new GameObject("music-channel-listener", typeof(AudioListener));
            var root = new GameObject("music-channel-manager");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.initialPoolSize = 4;
            _provider = new KeyedProvider { Clip = _clip };
            _manager.SetProvider(_provider);
            root.SetActive(true);
            yield return null;
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            foreach (var spawned in _spawned) if (spawned) Object.Destroy(spawned);
            _spawned.Clear();
            if (_manager) Object.Destroy(_manager.gameObject);
            if (_listener) Object.Destroy(_listener);
            yield return null;
            Object.Destroy(_clip); Object.Destroy(_other);
        }
        private static IEnumerator Until(Func<bool> predicate, string message, float seconds = 3f)
        {
            float end = Time.realtimeSinceStartup + seconds;
            while (!predicate() && Time.realtimeSinceStartup < end) yield return null;
            Assert.IsTrue(predicate(), message);
        }
        private int MusicCount
        {
            get
            {
                int count = 0;
                foreach (var playback in _manager.Pool.OnTrack(AudioTrack.Music)) count++;
                return count;
            }
        }

        [UnityTest]
        public IEnumerator PlainRequestStopsThePreviousMusic()
        {
            AudioEvents.PlayMusic.Trigger("first");
            var first = _manager.CurrentMusic;
            Assert.NotNull(first);
            AudioEvents.PlayMusic.Trigger("second", 0.5f);
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(1, _provider.Released);
            Assert.IsTrue(_manager.CurrentMusic.isPlaying);
            Assert.AreEqual(0.5f, _manager.CurrentMusic.volume, 0.0001f);
            yield return null;
        }
        [UnityTest]
        public IEnumerator ClipRequestStopsThePreviousMusic()
        {
            AudioEvents.PlayMusic.Trigger(_clip);
            AudioEvents.PlayMusic.Trigger(_other);
            Assert.AreEqual(1, MusicCount);
            Assert.AreSame(_other, _manager.CurrentMusic.clip);
            yield return null;
        }
        [UnityTest]
        public IEnumerator RepeatingTheSameMusicNeverStacksOrGoesSilent()
        {
            AudioEvents.PlayMusic.Trigger("same");
            AudioEvents.PlayMusic.Trigger("same");
            AudioEvents.PlayMusic.Trigger(_clip);
            AudioEvents.PlayMusic.Trigger(_clip);
            Assert.AreEqual(1, MusicCount);
            Assert.IsTrue(_manager.CurrentMusic.isPlaying);
            yield return null;
        }
        [UnityTest]
        public IEnumerator DebounceCannotDropTheLastOfRapidRequests()
        {
            var gate = _provider.Hold("late");
            AudioEvents.PlayMusic.Trigger("late");
            AudioEvents.PlayMusic.Trigger(_other);
            AudioEvents.PlayMusic.Trigger(_clip);
            gate.SetResult(true);
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreSame(_clip, _manager.CurrentMusic.clip);
        }
        [UnityTest]
        public IEnumerator EmptyRequestLeavesTheCurrentMusicAlone()
        {
            AudioEvents.PlayMusic.Trigger("current");
            var gate = _provider.Hold("pending");
            AudioEvents.PlayMusic.Trigger("pending");
            AudioEvents.PlayMusic.Trigger((string)null);
            AudioEvents.PlayMusic.Trigger((AudioClip)null);
            gate.SetResult(true);
            yield return null;
            yield return null;
            Assert.AreEqual(2, _provider.Acquired, "The empty requests must not cancel the pending music.");
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(1, _provider.Released);
        }
        [UnityTest]
        public IEnumerator FailedLoadKeepsTheCurrentMusic()
        {
            AudioEvents.PlayMusic.Trigger("current");
            var current = _manager.CurrentMusic;
            _provider.Missing.Add("missing");
            AudioEvents.PlayMusic.Trigger("missing");
            yield return null;
            Assert.AreSame(current, _manager.CurrentMusic);
            Assert.IsTrue(current.isPlaying);
            Assert.AreEqual(0, _provider.Released);
        }
        [UnityTest]
        public IEnumerator RunningMusicContinuesUntilTheReplacementIsReady()
        {
            AudioEvents.PlayMusic.Trigger("current");
            var gate = _provider.Hold("next");
            AudioEvents.PlayMusic.Trigger("next");
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(0, _provider.Released);
            gate.SetResult(true);
            yield return null;
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(1, _provider.Released);
        }
        [UnityTest]
        public IEnumerator LateLoadCannotOverrideTheNewerRequest()
        {
            var oldGate = _provider.Hold("old");
            AudioEvents.PlayMusic.Trigger("old");
            AudioEvents.PlayMusic.Trigger("new");
            var winner = _manager.CurrentMusic;
            Assert.NotNull(winner);
            oldGate.SetResult(true);
            yield return null;
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreSame(winner, _manager.CurrentMusic);
            Assert.AreEqual(2, _provider.Acquired);
            Assert.AreEqual(1, _provider.Released, "The late lease must be returned without playing.");
        }
        [UnityTest]
        public IEnumerator EarlierFinishOfASupersededLoadDoesNotPlayEither()
        {
            var oldGate = _provider.Hold("old");
            var newGate = _provider.Hold("new");
            AudioEvents.PlayMusic.Trigger("old");
            AudioEvents.PlayMusic.Trigger("new");
            oldGate.SetResult(true);
            yield return null;
            yield return null;
            Assert.AreEqual(0, MusicCount);
            Assert.AreEqual(1, _provider.Released);
            newGate.SetResult(true);
            yield return null;
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(1, _provider.Released);
        }
        [UnityTest]
        public IEnumerator ClipRequestBeatsAPendingKeyLoad()
        {
            var gate = _provider.Hold("pending");
            AudioEvents.PlayMusic.Trigger("pending");
            AudioEvents.PlayMusic.Trigger(_other);
            gate.SetResult(true);
            yield return null;
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreSame(_other, _manager.CurrentMusic.clip);
            Assert.AreEqual(_provider.Acquired, _provider.Released);
        }
        [UnityTest]
        public IEnumerator CrossfadeEndsWithOnlyTheNewMusicAtFullVolume()
        {
            AudioEvents.PlayMusic.Trigger("first", 0.8f);
            AudioEvents.PlayMusic.Trigger("second", 0.6f, crossfade: Fade);
            var target = _manager.CurrentMusic;
            Assert.AreEqual(2, MusicCount);
            Assert.Less(target.volume, 0.6f);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(1, MusicCount);
            Assert.AreSame(target, _manager.CurrentMusic);
            Assert.AreEqual(0.6f, target.volume, 0.0001f);
            Assert.AreEqual(1, _provider.Released);
        }
        [UnityTest]
        public IEnumerator CrossfadeStartsSilent()
        {
            AudioEvents.PlayMusic.Trigger(_clip, crossfade: Fade);
            Assert.AreEqual(0f, _manager.CurrentMusic.volume, 0.0001f);
            yield return null;
        }
        [UnityTest]
        public IEnumerator RequestDuringCrossfadeLeavesOnlyTheFinalMusic()
        {
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", crossfade: SlowFade);
            var b = _manager.CurrentMusic;
            yield return Until(() => b.volume > 0f, "The first fade must be running.");
            AudioEvents.PlayMusic.Trigger("c", 0.7f, crossfade: Fade);
            var final = _manager.CurrentMusic;
            Assert.AreEqual(3, MusicCount);
            yield return Until(() => MusicCount == 1, "Only the final music may remain.");
            Assert.AreSame(final, _manager.CurrentMusic);
            Assert.AreEqual(0.7f, final.volume, 0.0001f);
            Assert.AreEqual(2, _provider.Released);
        }
        [UnityTest]
        public IEnumerator PlainRequestDuringCrossfadeStopsEveryFadeTarget()
        {
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", crossfade: Fade);
            yield return null;
            AudioEvents.PlayMusic.Trigger("c", 0.7f);
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(2, _provider.Released);
            var final = _manager.CurrentMusic;
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(0.7f, final.volume, 0.0001f, "The cancelled fade must not touch the final music.");
        }
        [UnityTest]
        public IEnumerator ReplacedFadeTargetFadesFromItsCurrentLevel()
        {
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", crossfade: 1f);
            var b = _manager.CurrentMusic;
            yield return new WaitForSecondsRealtime(0.1f);
            float level = b.volume;
            Assert.Greater(level, 0f);
            AudioEvents.PlayMusic.Trigger("c", crossfade: 1f);
            yield return null;
            Assert.LessOrEqual(b.volume, level + 0.0001f, "The old target must not jump back to full volume.");
        }
        [UnityTest]
        public IEnumerator LateLoadDuringCrossfadeCannotJoinTheFade()
        {
            AudioEvents.PlayMusic.Trigger("a");
            var gate = _provider.Hold("slow");
            AudioEvents.PlayMusic.Trigger("slow", crossfade: Fade);
            AudioEvents.PlayMusic.Trigger("fast", 0.5f, crossfade: Fade);
            var final = _manager.CurrentMusic;
            gate.SetResult(true);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(1, MusicCount);
            Assert.AreSame(final, _manager.CurrentMusic);
            Assert.AreEqual(0.5f, final.volume, 0.0001f);
            Assert.AreEqual(2, _provider.Released);
        }
        [UnityTest]
        public IEnumerator PublicCrossfadeSupersedesAndReachesTheSameEnd()
        {
            AudioEvents.PlayMusic.Trigger("a");
            var a = _manager.CurrentMusic;
            var gate = _provider.Hold("slow");
            AudioEvents.PlayMusic.Trigger("slow");
            yield return _manager.CrossfadeMusic(a, "b", Fade, 0.4f);
            gate.SetResult(true);
            yield return null;
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(0.4f, _manager.CurrentMusic.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator PublicCrossfadeWithoutFromStillReplacesTheTrackedMusic()
        {
            AudioEvents.PlayMusic.Trigger("a");
            yield return _manager.CrossfadeMusic(null, "b", Fade);
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(1, _provider.Released);
        }
        [UnityTest]
        public IEnumerator EventReplacesMusicStartedDirectly()
        {
            _manager.Play(_clip, AudioTrack.Music, loop: true, debounce: 0);
            _manager.Play(_other, AudioTrack.Music, loop: true, debounce: 0);
            Assert.AreEqual(2, MusicCount);
            AudioEvents.PlayMusic.Trigger("tracked");
            Assert.AreEqual(1, MusicCount);
            yield return null;
        }
        [UnityTest]
        public IEnumerator CrossfadeEventFadesOutMusicStartedDirectly()
        {
            _manager.Play(_clip, AudioTrack.Music, loop: true, debounce: 0);
            _manager.Play(_other, AudioTrack.Music, loop: true, debounce: 0);
            AudioEvents.PlayMusic.Trigger("tracked", crossfade: Fade);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(1, MusicCount);
        }
        [UnityTest]
        public IEnumerator DirectMusicPlaybackRemainsAdditiveAndUntracked()
        {
            var first = _manager.Play(_clip, AudioTrack.Music, loop: true, debounce: 0);
            var second = _manager.Play(_other, AudioTrack.Music, loop: true, debounce: 0);
            Assert.AreEqual(2, MusicCount);
            Assert.IsTrue(first.isPlaying && second.isPlaying);
            Assert.IsNull(_manager.CurrentMusic);
            yield return null;
        }
        [UnityTest]
        public IEnumerator OtherTracksAreNotClaimed()
        {
            var sfx = _manager.Play(_clip, AudioTrack.Sfx, loop: true, debounce: 0);
            AudioEvents.PlayMusic.Trigger("music");
            Assert.IsTrue(sfx.isPlaying);
            Assert.AreEqual(2, _manager.ActiveSourceCount);
            yield return null;
        }
        [UnityTest]
        public IEnumerator TrackStopClearsPendingFadingAndCurrentMusic()
        {
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", crossfade: Fade);
            var gate = _provider.Hold("pending");
            AudioEvents.PlayMusic.Trigger("pending");
            AudioEvents.StopAllOnTrack.Trigger(AudioTrack.Music);
            Assert.IsNull(_manager.CurrentMusic);
            gate.SetResult(true);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
            Assert.AreEqual(_provider.Acquired, _provider.Released);
        }
        [UnityTest]
        public IEnumerator StopAllDuringCrossfadeEndsTheFade()
        {
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", crossfade: Fade);
            _manager.StopAll();
            var replacement = _manager.Play(_clip, AudioTrack.Music, 0.3f, loop: true, debounce: 0);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(0.3f, replacement.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator StoppingTheFadeTargetRestoresTheMusicItWasReplacing()
        {
            AudioEvents.PlayMusic.Trigger("a", 0.8f);
            var a = _manager.CurrentMusic;
            AudioEvents.PlayMusic.Trigger("b", crossfade: SlowFade);
            var b = _manager.CurrentMusic;
            yield return Until(() => b.volume > 0f, "The fade must be running.");
            Assert.AreEqual(2, MusicCount, "The replaced music is still fading out.");
            _manager.Stop(b);
            yield return Until(() => _manager.CurrentMusic, "The replaced music must become current again.");
            Assert.AreSame(a, _manager.CurrentMusic);
            Assert.AreEqual(0.8f, a.volume, 0.0001f);
            Assert.AreEqual(1, MusicCount);
        }
        [UnityTest]
        public IEnumerator FadeHonorsTrackVolumeChangedMeanwhile()
        {
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", 0.8f, crossfade: Fade);
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(0.4f, _manager.CurrentMusic.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator MutedTrackStaysMutedAcrossReplacement()
        {
            _manager.MuteTrack(AudioTrack.Music);
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", crossfade: Fade);
            Assert.IsTrue(_manager.CurrentMusic.mute);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.IsTrue(_manager.CurrentMusic.mute);
        }
        [UnityTest]
        public IEnumerator CrossfadeKeepsTheRequestedPitch()
        {
            AudioEvents.PlayMusic.Trigger("key", pitch: 1.5f, crossfade: Fade);
            Assert.AreEqual(1.5f, _manager.CurrentMusic.pitch, 0.0001f);
            yield return null;
        }
        [UnityTest]
        public IEnumerator NonExpandingPoolStillEndsWithOneMusic()
        {
            Object.Destroy(_manager.gameObject);
            yield return null;
            var root = new GameObject("music-channel-small-pool");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.initialPoolSize = 1;
            _manager.poolCanExpand = false;
            _manager.SetProvider(_provider);
            root.SetActive(true);
            AudioEvents.PlayMusic.Trigger("a");
            AudioEvents.PlayMusic.Trigger("b", crossfade: Fade);
            yield return new WaitForSecondsRealtime(AfterFade);
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(1f, _manager.CurrentMusic.volume, 0.0001f);
            Assert.AreEqual(1, _provider.Released);
        }

        private AudioEventPlayer Player(string key)
        {
            var root = new GameObject("music-event-player-" + key);
            root.SetActive(false);
            _spawned.Add(root);
            var player = root.AddComponent<AudioEventPlayer>();
            player.SetTrack(AudioEventPlayerTrack.Music);
            player.SetKey(key);
            return player;
        }
        [UnityTest]
        public IEnumerator AutoPlayingPlayersKeepOneMusic()
        {
            Player("first").gameObject.SetActive(true);
            Player("second").gameObject.SetActive(true);
            Player("second").gameObject.SetActive(true);
            yield return null;
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(2, _provider.Released);
        }
        [UnityTest]
        public IEnumerator ReenablingAnAutoPlayerDoesNotAccumulateMusic()
        {
            var player = Player("repeat");
            for (int i = 0; i < 3; i++)
            {
                player.gameObject.SetActive(true);
                yield return null;
                player.gameObject.SetActive(false);
                yield return new WaitForSecondsRealtime(0.15f); // Past the key debounce, which used to hide the stacking.
            }
            Assert.AreEqual(1, MusicCount);
            Assert.AreEqual(3, _provider.Acquired);
            Assert.AreEqual(2, _provider.Released);
        }
        [UnityTest]
        public IEnumerator ManualPlayerCallsKeepOneMusic()
        {
            var player = Player("manual");
            player.Play();
            player.PlayMusic();
            player.PlaySound("other");
            yield return null;
            Assert.AreEqual(1, MusicCount);
        }
    }
}
