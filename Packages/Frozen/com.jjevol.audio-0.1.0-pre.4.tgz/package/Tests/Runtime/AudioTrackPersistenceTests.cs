using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Audio.Tests
{
    /// <summary>Save, restore and AudioSource-path volume. Settings without a mixer asset exercise the whole state path.</summary>
    public sealed class AudioTrackPersistenceTests
    {
        private const string PrefsKey = "jjevol.audio.mixer.settings"; // Stored data: this literal pins the key.
        private AudioManager _manager;
        private AudioMixerSettingsSO _settings;
        private AudioClip _clip;
        private GameObject _listener;
        private string _savedPrefs;

        [SetUp]
        public void SetUp()
        {
            _savedPrefs = PlayerPrefs.HasKey(PrefsKey) ? PlayerPrefs.GetString(PrefsKey) : null;
            PlayerPrefs.DeleteKey(PrefsKey);
            _settings = ScriptableObject.CreateInstance<AudioMixerSettingsSO>();
            _clip = AudioClip.Create("persistence-test", 44100, 1, 44100, false);
            if (!Object.FindAnyObjectByType<AudioListener>()) _listener = new GameObject("persistence-listener", typeof(AudioListener));
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (_manager) Object.Destroy(_manager.gameObject);
            if (_listener) Object.Destroy(_listener);
            yield return null;
            Object.Destroy(_settings); Object.Destroy(_clip);
            if (_savedPrefs == null) PlayerPrefs.DeleteKey(PrefsKey);
            else PlayerPrefs.SetString(PrefsKey, _savedPrefs);
            PlayerPrefs.Save();
        }
        private AudioManager Create(float defaultMusic = 1f)
        {
            var root = new GameObject("persistence-manager");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.mixerSettings = _settings;
            _manager.defaultMusicVolume = defaultMusic;
            root.SetActive(true);
            return _manager;
        }
        private IEnumerator Restart()
        {
            Object.Destroy(_manager.gameObject);
            yield return null;
            Create();
            yield return null;
        }

        [UnityTest]
        public IEnumerator MutedTrackSavedAndRestartedGetsItsVolumeBack()
        {
            _settings.autoSaveOnChange = true;
            Create();
            yield return null;
            _manager.SetTrackVolume(AudioTrack.Music, 0.6f);
            _manager.MuteTrack(AudioTrack.Music);
            yield return Restart();
            Assert.IsFalse(_manager.IsTrackOn(AudioTrack.Music));
            Assert.AreEqual(0.6f, _manager.GetTrackVolume(AudioTrack.Music), 0.0001f);
            _manager.UnmuteTrack(AudioTrack.Music);
            Assert.IsTrue(_manager.IsTrackOn(AudioTrack.Music));
            Assert.AreEqual(0.6f, _manager.GetTrackVolume(AudioTrack.Music), 0.0001f);
            var source = _manager.Play(_clip, AudioTrack.Music, debounce: 0);
            Assert.IsFalse(source.mute);
            Assert.AreEqual(0.6f, source.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator MutedMasterSurvivesRepeatedRestarts()
        {
            _settings.autoSaveOnChange = true;
            Create();
            yield return null;
            _manager.SetTrackVolume(AudioTrack.Master, 0.3f);
            _manager.MuteTrack(AudioTrack.Master);
            yield return Restart();
            yield return Restart();
            Assert.IsFalse(_manager.IsTrackOn(AudioTrack.Master));
            Assert.AreEqual(0.3f, _manager.GetTrackVolume(AudioTrack.Master), 0.0001f);
        }
        [UnityTest]
        public IEnumerator ZeroVolumeIsNotMistakenForOff()
        {
            _settings.autoSaveOnChange = true;
            Create();
            yield return null;
            _manager.SetTrackVolume(AudioTrack.Sfx, 0f);
            yield return Restart();
            Assert.IsTrue(_manager.IsTrackOn(AudioTrack.Sfx));
            Assert.AreEqual(0f, _manager.GetTrackVolume(AudioTrack.Sfx));
        }
        [UnityTest]
        public IEnumerator ExplicitSaveAndLoadUseTheSameState()
        {
            Create();
            yield return null;
            _manager.SetTrackVolume(AudioTrack.Voice, 0.25f);
            _manager.MuteTrack(AudioTrack.Voice);
            _manager.SaveMixerToPrefs();
            _manager.SetTrackVolume(AudioTrack.Voice, 0.9f);
            _manager.UnmuteTrack(AudioTrack.Voice);
            var source = _manager.Play(_clip, AudioTrack.Voice, debounce: 0);
            _manager.LoadMixerFromPrefs();
            Assert.IsFalse(_manager.IsTrackOn(AudioTrack.Voice));
            Assert.AreEqual(0.25f, _manager.GetTrackVolume(AudioTrack.Voice), 0.0001f);
            Assert.IsTrue(source.mute, "A load must reach playing sources.");
            Assert.AreEqual(0.25f, source.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator SavedJsonKeepsTheStoredFormat()
        {
            Create();
            yield return null;
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            _manager.MuteTrack(AudioTrack.Music);
            _manager.SaveMixerToPrefs();
            Assert.AreEqual("{\"master\":1.0,\"masterOn\":true,\"music\":0.5,\"musicOn\":false,\"sfx\":1.0,\"sfxOn\":true,"
                + "\"ui\":1.0,\"uiOn\":true,\"voice\":1.0,\"voiceOn\":true}", PlayerPrefs.GetString(PrefsKey));
        }
        [UnityTest]
        public IEnumerator FirstRunStoresDefaultsAndLaterRunsPreferTheStoredValue()
        {
            Create(0.4f);
            yield return null;
            Assert.IsTrue(_settings.LoadFromPrefs(out var stored));
            Assert.AreEqual(0.4f, stored.music, 0.0001f);
            _settings.SaveToPrefs(new AudioMixerSettingsSO.Snapshot
            {
                master = 1f, masterOn = true, music = 0.7f, musicOn = true,
                sfx = 1f, sfxOn = true, ui = 1f, uiOn = true, voice = 1f, voiceOn = true,
            });
            yield return Restart();
            Assert.AreEqual(0.7f, _manager.GetTrackVolume(AudioTrack.Music), 0.0001f);
        }
        [UnityTest]
        public IEnumerator DisabledAutoLoadLeavesStoredValuesAlone()
        {
            _settings.SaveToPrefs(new AudioMixerSettingsSO.Snapshot { music = 0.2f });
            string stored = PlayerPrefs.GetString(PrefsKey);
            _settings.autoLoadOnStart = false;
            Create(0.9f);
            yield return null;
            Assert.AreEqual(0.9f, _manager.GetTrackVolume(AudioTrack.Music), 0.0001f);
            Assert.IsTrue(_manager.IsTrackOn(AudioTrack.Music));
            Assert.AreEqual(stored, PlayerPrefs.GetString(PrefsKey));
        }
        [UnityTest]
        public IEnumerator SourcePathMultipliesTrackAndMasterOnce()
        {
            Create();
            yield return null;
            var source = _manager.Play(_clip, AudioTrack.Sfx, 0.8f, debounce: 0);
            _manager.SetTrackVolume(AudioTrack.Sfx, 0.5f);
            _manager.SetTrackVolume(AudioTrack.Master, 0.5f);
            Assert.AreEqual(0.2f, source.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator MasterTrackPlaybackAppliesMasterOnce()
        {
            Create();
            yield return null;
            _manager.SetTrackVolume(AudioTrack.Master, 0.5f);
            var source = _manager.Play(_clip, AudioTrack.Master, debounce: 0);
            Assert.AreEqual(0.5f, source.volume, 0.0001f);
        }
    }
}
