using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Audio.Tests
{
    /// <summary>
    /// Needs a mixer asset, which the package does not ship. The validation Host provides
    /// Resources/jjevol-audio-test-mixer-settings: an AudioMixerSettingsSO with every group assigned, and default parameter
    /// names exposed on the matching groups of one mixer. Without that fixture the tests report Ignored, not passed.
    /// </summary>
    [Category("RequiresMixerAsset")]
    public sealed class AudioMixerRouteTests
    {
        private const string Fixture = "jjevol-audio-test-mixer-settings";
        private const string PrefsKey = "jjevol.audio.mixer.settings";
        private AudioManager _manager;
        private AudioMixerSettingsSO _settings;
        private AudioClip _clip;
        private GameObject _listener;
        private string _savedPrefs;

        [SetUp]
        public void SetUp()
        {
            var fixture = Resources.Load<AudioMixerSettingsSO>(Fixture);
            if (!fixture || !fixture.mixer) Assert.Ignore($"Resources/{Fixture} is required.");
            _settings = Object.Instantiate(fixture);
            _settings.autoSaveOnChange = false;
            _savedPrefs = PlayerPrefs.HasKey(PrefsKey) ? PlayerPrefs.GetString(PrefsKey) : null;
            PlayerPrefs.DeleteKey(PrefsKey);
            _clip = AudioClip.Create("mixer-route-test", 44100, 1, 44100, false);
            if (!Object.FindAnyObjectByType<AudioListener>()) _listener = new GameObject("mixer-route-listener", typeof(AudioListener));
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (!_settings) yield break; // Ignored before SetUp took its PlayerPrefs copy.
            if (_manager) Object.Destroy(_manager.gameObject);
            if (_listener) Object.Destroy(_listener);
            yield return null;
            Object.Destroy(_settings); Object.Destroy(_clip);
            if (_savedPrefs == null) PlayerPrefs.DeleteKey(PrefsKey);
            else PlayerPrefs.SetString(PrefsKey, _savedPrefs);
            PlayerPrefs.Save();
        }
        private IEnumerator Create()
        {
            var root = new GameObject("mixer-route-manager");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.mixerSettings = _settings;
            root.SetActive(true);
            yield return null;
        }
        private void AssertParameter(string parameter, float volume01)
        {
            Assert.IsTrue(_settings.mixer.GetFloat(parameter, out var db), parameter);
            Assert.AreEqual(AudioMixerSettingsSO.NormToDb(volume01), db, 0.01f, parameter);
        }

        [UnityTest]
        public IEnumerator ConnectedSourceLeavesBothFactorsToTheMixer()
        {
            yield return Create();
            var source = _manager.Play(_clip, AudioTrack.Music, 0.8f, debounce: 0);
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            _manager.SetTrackVolume(AudioTrack.Master, 0.25f);
            Assert.AreEqual(0.8f, source.volume, 0.0001f);
            AssertParameter(_settings.musicParam, 0.5f);
            AssertParameter(_settings.masterParam, 0.25f);
        }
        [UnityTest]
        public IEnumerator FadeKeepsTheFactorsOnTheMixer()
        {
            yield return Create();
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            AudioEvents.PlayMusic.Trigger(_clip, 0.8f, crossfade: 0.1f);
            yield return new WaitForSecondsRealtime(0.25f);
            Assert.AreEqual(0.8f, _manager.CurrentMusic.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator MissingTrackParameterFallsBackToTheSource()
        {
            _settings.musicParam = "jjevol-audio-test-missing";
            yield return Create();
            var source = _manager.Play(_clip, AudioTrack.Music, 0.8f, debounce: 0);
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            _manager.SetTrackVolume(AudioTrack.Master, 0.25f);
            Assert.AreEqual(0.4f, source.volume, 0.0001f, "Master stays on the mixer.");
        }
        [UnityTest]
        public IEnumerator MissingMasterParameterFallsBackToTheSource()
        {
            _settings.masterParam = "jjevol-audio-test-missing";
            yield return Create();
            var source = _manager.Play(_clip, AudioTrack.Music, 0.8f, debounce: 0);
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            _manager.SetTrackVolume(AudioTrack.Master, 0.25f);
            Assert.AreEqual(0.2f, source.volume, 0.0001f, "The track stays on the mixer.");
        }
        [UnityTest]
        public IEnumerator FallbackGroupKeepsTheTrackFactorOnTheSource()
        {
            _settings.voiceGroup = null;
            yield return Create();
            var source = _manager.Play(_clip, AudioTrack.Voice, 0.8f, debounce: 0);
            Assert.AreSame(_settings.masterGroup, source.outputAudioMixerGroup);
            _manager.SetTrackVolume(AudioTrack.Voice, 0.5f);
            _manager.SetTrackVolume(AudioTrack.Master, 0.25f);
            Assert.AreEqual(0.4f, source.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator OverrideGroupInTheMixerLeavesMasterToTheMixer()
        {
            yield return Create();
            var source = _manager.Play(_clip, AudioTrack.Music, 0.8f, debounce: 0, overrideGroup: _settings.sfxGroup);
            Assert.AreSame(_settings.sfxGroup, source.outputAudioMixerGroup);
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            _manager.SetTrackVolume(AudioTrack.Master, 0.25f);
            Assert.AreEqual(0.4f, source.volume, 0.0001f, "Only the track factor stays on the source.");
        }
        [UnityTest]
        public IEnumerator OverrideNamingTheTracksOwnGroupStaysOnTheMixer()
        {
            yield return Create();
            var source = _manager.Play(_clip, AudioTrack.Music, 0.8f, debounce: 0, overrideGroup: _settings.musicGroup);
            _manager.SetTrackVolume(AudioTrack.Music, 0.5f);
            Assert.AreEqual(0.8f, source.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator MuteReachesTheMixerAndUnmuteRestoresTheVolume()
        {
            yield return Create();
            _manager.SetTrackVolume(AudioTrack.Sfx, 0.5f);
            _manager.MuteTrack(AudioTrack.Sfx);
            Assert.IsTrue(_settings.mixer.GetFloat(_settings.sfxParam, out var muted));
            Assert.AreEqual(-80f, muted, 0.01f);
            Assert.AreEqual(0.5f, _manager.GetTrackVolume(AudioTrack.Sfx), 0.0001f);
            _manager.UnmuteTrack(AudioTrack.Sfx);
            AssertParameter(_settings.sfxParam, 0.5f);
        }
        [UnityTest]
        public IEnumerator MutedTrackSavedAndRestartedGetsItsVolumeBackThroughTheMixer()
        {
            _settings.autoSaveOnChange = true;
            yield return Create();
            _manager.SetTrackVolume(AudioTrack.Music, 0.6f);
            _manager.MuteTrack(AudioTrack.Music);
            Object.Destroy(_manager.gameObject);
            yield return null;
            yield return Create();
            Assert.IsFalse(_manager.IsTrackOn(AudioTrack.Music));
            Assert.AreEqual(0.6f, _manager.GetTrackVolume(AudioTrack.Music), 0.0001f);
            Assert.IsTrue(_settings.mixer.GetFloat(_settings.musicParam, out var muted));
            Assert.AreEqual(-80f, muted, 0.01f);
            _manager.UnmuteTrack(AudioTrack.Music);
            AssertParameter(_settings.musicParam, 0.6f);
        }
        [UnityTest]
        public IEnumerator SaveWritesTheStateNotTheMixerReadback()
        {
            yield return Create();
            _manager.SetTrackVolume(AudioTrack.Music, 0.6f);
            _manager.MuteTrack(AudioTrack.Music);
            _manager.SaveMixerToPrefs();
            Assert.IsTrue(_settings.LoadFromPrefs(out var stored));
            Assert.IsFalse(stored.musicOn);
            Assert.AreEqual(0.6f, stored.music, 0.0001f);
        }
        [UnityTest]
        public IEnumerator StartAppliesTheStateEvenWhenAutoLoadIsOff()
        {
            _settings.autoLoadOnStart = false;
            var root = new GameObject("mixer-route-defaults");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.mixerSettings = _settings;
            _manager.defaultMusicVolume = 0.3f;
            root.SetActive(true);
            // Awake has applied the state and Start has not run: only Start can bring this value back.
            Assert.IsTrue(_settings.mixer.SetFloat(_settings.musicParam, AudioMixerSettingsSO.NormToDb(0.9f)));
            AssertParameter(_settings.musicParam, 0.9f);
            yield return null;
            AssertParameter(_settings.musicParam, 0.3f);
        }
    }
}
