using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Audio.Tests
{
    /// <summary>A consumer holding only IAudioPlayer reaches the same playback, track and music state as AudioManager.</summary>
    public sealed class AudioPlayerInterfaceTests
    {
        private enum Sound { Click }
        private sealed class Provider : IAudioClipLeaseProvider
        {
            internal AudioClip Clip;
            internal string LastKey;
            internal int Released;
            public Task<AudioClip> LoadClipAsync(AudioTrack track, string key) => Task.FromResult(Clip);
            public Task<AudioClipLease> AcquireAsync(AudioTrack track, string key, CancellationToken token)
            {
                LastKey = key;
                return Task.FromResult(new AudioClipLease(Clip, () => Released++));
            }
        }
        private AudioManager _manager;
        private IAudioPlayer _player;
        private Provider _provider;
        private AudioClip _clip;
        private GameObject _listener;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _clip = AudioClip.Create("audio-player-interface-test", 44100, 1, 44100, false);
            if (!Object.FindAnyObjectByType<AudioListener>()) _listener = new GameObject("audio-player-listener", typeof(AudioListener));
            var root = new GameObject("audio-player-manager");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _provider = new Provider { Clip = _clip };
            _manager.SetProvider(_provider);
            root.SetActive(true);
            _player = _manager;
            yield return null;
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (_manager) Object.Destroy(_manager.gameObject);
            if (_listener) Object.Destroy(_listener);
            yield return null;
            Object.Destroy(_clip);
        }

        [UnityTest]
        public IEnumerator ClipPlaybackStartsAndStops()
        {
            var source = _player.Play(_clip, AudioTrack.Sfx, 0.5f, debounce: 0);
            Assert.IsTrue(source.isPlaying);
            Assert.AreEqual(0.5f, source.volume, 0.0001f);
            Assert.AreSame(source, _manager.GetFirstOnTrack(AudioTrack.Sfx));
            _player.Stop(source);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
            yield return null;
        }
        [UnityTest]
        public IEnumerator KeyAndEnumPlaybackUseTheProvider()
        {
            var byKey = _player.PlayAsync("by-key", loop: true, debounce: 0);
            while (!byKey.IsCompleted) yield return null;
            Assert.AreEqual("by-key", _provider.LastKey);
            Assert.IsTrue(byKey.Result.isPlaying);
            AudioKeys.Register(Sound.Click, "by-enum");
            var byEnum = _player.PlayAsync(Sound.Click, AudioTrack.UI, loop: true, debounce: 0);
            while (!byEnum.IsCompleted) yield return null;
            Assert.AreEqual("by-enum", _provider.LastKey);
            Assert.AreEqual(2, _manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator DestroyedSourceReturnsItsLeaseOnTheNextTrackChange()
        {
            var play = _player.PlayAsync("leased", loop: true, debounce: 0);
            while (!play.IsCompleted) yield return null;
            Object.DestroyImmediate(play.Result);
            _player.SetTrackVolume(AudioTrack.Master, 0.5f);
            Assert.AreEqual(1, _provider.Released);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator CallerCancellationCancelsTheTask()
        {
            using var cancellation = new CancellationTokenSource();
            cancellation.Cancel();
            var task = _player.PlayAsync("cancelled", cancellation.Token);
            while (!task.IsCompleted) yield return null;
            Assert.IsTrue(task.IsCanceled);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator TrackStopLeavesOtherTracksAndStopAllEndsThem()
        {
            _player.Play(_clip, AudioTrack.Sfx, loop: true, debounce: 0);
            var voice = _player.Play(_clip, AudioTrack.Voice, loop: true, debounce: 0);
            _player.StopAllOnTrack(AudioTrack.Sfx);
            Assert.AreEqual(1, _manager.ActiveSourceCount);
            Assert.IsTrue(voice.isPlaying);
            _player.StopAll();
            Assert.AreEqual(0, _manager.ActiveSourceCount);
            yield return null;
        }
        [UnityTest]
        public IEnumerator TrackVolumeAndOnReachPlayingSources()
        {
            var source = _player.Play(_clip, AudioTrack.Sfx, loop: true, debounce: 0);
            _player.SetTrackVolume(AudioTrack.Sfx, 0.25f);
            Assert.AreEqual(0.25f, _player.GetTrackVolume(AudioTrack.Sfx));
            Assert.AreEqual(0.25f, source.volume, 0.0001f);
            _player.SetTrackOn(AudioTrack.Sfx, false);
            Assert.IsFalse(_player.IsTrackOn(AudioTrack.Sfx));
            Assert.IsTrue(source.mute);
            yield return null;
        }
        [UnityTest]
        public IEnumerator PlayMusicReplacesTheCurrentMusic()
        {
            var first = _player.PlayMusicAsync("theme", 0.5f);
            while (!first.IsCompleted) yield return null;
            Assert.AreSame(first.Result, _player.CurrentMusic);
            Assert.AreEqual("theme", _provider.LastKey);
            var second = _player.PlayMusicAsync(_clip);
            while (!second.IsCompleted) yield return null;
            Assert.AreSame(second.Result, _player.CurrentMusic);
            Assert.AreEqual(1, _manager.ActiveSourceCount);
            Assert.AreEqual(1, _provider.Released, "Replacing the music returns the first lease.");
        }
        [UnityTest]
        public IEnumerator CrossfadeSetsTheCurrentMusic()
        {
            Assert.IsNull(_player.CurrentMusic);
            yield return _player.CrossfadeMusic(null, "theme", 0.05f, 0.5f);
            Assert.NotNull(_player.CurrentMusic);
            Assert.AreSame(_manager.CurrentMusic, _player.CurrentMusic);
            Assert.AreEqual(0.5f, _player.CurrentMusic.volume, 0.0001f);
        }
    }
}
