using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Audio.Tests
{
    public sealed class AudioPlaybackTests
    {
        private AudioManager _manager;
        private AudioClip _short, _long;
        private GameObject _listener;
        private sealed class CountingProvider : IAudioClipLeaseProvider, IDisposable
        {
            internal AudioClip Clip;
            internal int Acquired, Released;
            internal bool Disposed;
            internal TaskCompletionSource<bool> Gate;
            internal string LastKey;
            public Task<AudioClip> LoadClipAsync(AudioTrack track, string key) => Task.FromResult(Clip);
            public async Task<AudioClipLease> AcquireAsync(AudioTrack track, string key, CancellationToken token)
            {
                LastKey = key;
                // Deliberately finish late, even after cancellation, to test the manager's final ownership guard.
                if (Gate != null) await Gate.Task;
                Acquired++;
                return new AudioClipLease(Clip, () => Released++);
            }
            public void Dispose() => Disposed = true;
        }
        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _short = AudioClip.Create("short-audio-test", 4410, 1, 44100, false);
            _long = AudioClip.Create("long-audio-test", 44100, 1, 44100, false);
            if (!Object.FindAnyObjectByType<AudioListener>()) _listener = new GameObject("audio-test-listener", typeof(AudioListener));
            var root = new GameObject("audio-test-manager");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.initialPoolSize = 1;
            _manager.poolCanExpand = false;
            root.SetActive(true);
            yield return null;
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (_manager) Object.Destroy(_manager.gameObject);
            if (_listener) Object.Destroy(_listener);
            yield return null;
            Object.Destroy(_short); Object.Destroy(_long);
        }
        [UnityTest]
        public IEnumerator SingleShotActuallyPlaysAndReturnsItsSource()
        {
            var source = _manager.Play(_short, debounce: 0);
            Assert.IsTrue(source.isPlaying, "AudioSource must actually start, not only update bookkeeping.");
            yield return new WaitForSecondsRealtime(0.3f);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
            Assert.IsNull(source.clip);
            Assert.IsFalse(source.gameObject.activeSelf);
        }
        [UnityTest]
        public IEnumerator StoppedSourceReuseCannotBeStoppedByAnOldCompletionTimer()
        {
            var first = _manager.Play(_short, debounce: 0);
            yield return null;
            _manager.Stop(first);
            var replacement = _manager.Play(_long, loop: true, debounce: 0);
            Assert.AreSame(first, replacement);
            yield return new WaitForSecondsRealtime(0.25f);
            Assert.IsTrue(replacement.isPlaying);
            Assert.AreEqual(1, _manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator LoopKeepsLeaseUntilIdempotentStop()
        {
            var provider = new CountingProvider { Clip = _short };
            _manager.SetProvider(provider);
            var task = _manager.PlayAsync("loop", loop: true, debounce: 0);
            while (!task.IsCompleted) yield return null;
            yield return new WaitForSecondsRealtime(0.25f);
            Assert.AreEqual(0, provider.Released);
            Assert.IsTrue(task.Result.isPlaying);
            _manager.Stop(task.Result); _manager.Stop(task.Result);
            Assert.AreEqual(1, provider.Released);
        }
        [UnityTest]
        public IEnumerator PoolStealReleasesThePreviousPlaybackExactlyOnce()
        {
            var provider = new CountingProvider { Clip = _long };
            _manager.SetProvider(provider);
            var first = _manager.PlayAsync("first", loop: true, debounce: 0);
            var second = _manager.PlayAsync("second", loop: true, debounce: 0);
            while (!first.IsCompleted || !second.IsCompleted) yield return null;
            Assert.AreSame(first.Result, second.Result);
            Assert.AreEqual(2, provider.Acquired);
            Assert.AreEqual(1, provider.Released);
            _manager.StopAll();
            Assert.AreEqual(2, provider.Released);
        }
        [UnityTest]
        public IEnumerator ClipDebounceAfterLoadingReturnsRejectedLease()
        {
            var provider = new CountingProvider { Clip = _long };
            _manager.SetProvider(provider);
            var first = _manager.PlayAsync("alias-one", loop: true, debounce: 1);
            var rejected = _manager.PlayAsync("alias-two", loop: true, debounce: 1);
            while (!first.IsCompleted || !rejected.IsCompleted) yield return null;
            Assert.IsNull(rejected.Result);
            Assert.AreEqual(2, provider.Acquired);
            Assert.AreEqual(1, provider.Released);
            _manager.StopAll();
            Assert.AreEqual(2, provider.Released);
        }
        [UnityTest]
        public IEnumerator StopAllPreventsALateLoadFromStartingAndReturnsItsLease()
        {
            var provider = new CountingProvider { Clip = _long, Gate = new TaskCompletionSource<bool>() };
            _manager.SetProvider(provider);
            var pending = _manager.PlayAsync("pending", loop: true, debounce: 0);
            _manager.StopAll();
            provider.Gate.SetResult(true);
            while (!pending.IsCompleted) yield return null;
            Assert.IsNull(pending.Result);
            Assert.AreEqual(provider.Acquired, provider.Released);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator ExplicitCancellationReturnsALateLease()
        {
            var provider = new CountingProvider { Clip = _long, Gate = new TaskCompletionSource<bool>() };
            _manager.SetProvider(provider);
            using var cancellation = new CancellationTokenSource();
            var pending = _manager.PlayAsync("cancel", cancellation.Token, loop: true, debounce: 0);
            cancellation.Cancel();
            provider.Gate.SetResult(true);
            while (!pending.IsCompleted) yield return null;
            Assert.IsTrue(pending.IsCanceled);
            Assert.AreEqual(provider.Acquired, provider.Released);
        }
        [UnityTest]
        public IEnumerator TrackStopCancelsOnlyItsPendingRequests()
        {
            var provider = new CountingProvider { Clip = _long, Gate = new TaskCompletionSource<bool>() };
            _manager.SetProvider(provider);
            var sfx = _manager.PlayAsync("sfx", AudioTrack.Sfx, loop: true, debounce: 0);
            var music = _manager.PlayAsync("music", AudioTrack.Music, loop: true, debounce: 0);
            _manager.StopAllOnTrack(AudioTrack.Sfx);
            provider.Gate.SetResult(true);
            while (!sfx.IsCompleted || !music.IsCompleted) yield return null;
            Assert.IsNull(sfx.Result);
            Assert.NotNull(music.Result);
            Assert.AreEqual(1, provider.Released);
            _manager.StopAll();
            Assert.AreEqual(2, provider.Released);
        }
        [UnityTest]
        public IEnumerator PausedClipIsNotReturnedByItsOriginalDuration()
        {
            var source = _manager.Play(_short, debounce: 0);
            _manager.PauseTrack(AudioTrack.Sfx);
            yield return new WaitForSecondsRealtime(0.25f);
            Assert.AreEqual(1, _manager.ActiveSourceCount);
            Assert.AreSame(_short, source.clip);
            _manager.PlayTrack(AudioTrack.Sfx);
            yield return new WaitForSecondsRealtime(0.3f);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator ProviderSwitchPreservesActiveLeaseAndCancelsPendingPlay()
        {
            var active = new CountingProvider { Clip = _long };
            _manager.SetProvider(active, true);
            var playing = _manager.PlayAsync("active", loop: true, debounce: 0);
            while (!playing.IsCompleted) yield return null;
            _manager.SetProvider(ProviderKind.Resources);
            Assert.IsTrue(active.Disposed);
            Assert.AreEqual(0, active.Released);
            _manager.Stop(playing.Result);
            Assert.AreEqual(1, active.Released);
            var pendingProvider = new CountingProvider { Clip = _long, Gate = new TaskCompletionSource<bool>() };
            _manager.SetProvider(pendingProvider, true);
            var pending = _manager.PlayAsync("pending-switch", loop: true, debounce: 0);
            _manager.SetProvider(ProviderKind.Resources);
            pendingProvider.Gate.SetResult(true);
            while (!pending.IsCompleted) yield return null;
            Assert.IsNull(pending.Result);
            Assert.AreEqual(1, pendingProvider.Released);
        }
        [UnityTest]
        public IEnumerator OwnedEventsControlPlaybackVolumeMuteAndStop()
        {
            AudioEvents.PlayUI.Trigger(_long, loop: true);
            var source = _manager.GetFirstOnTrack(AudioTrack.UI);
            Assert.NotNull(source);
            AudioEvents.SetTrackOn.Trigger(AudioTrack.UI, false);
            Assert.IsTrue(source.mute);
            AudioEvents.SetTrackVolume.Trigger(AudioTrack.UI, 0.25f);
            _manager.SetTrackVolume(AudioTrack.Master, 0.5f);
            Assert.AreEqual(0.125f, source.volume, 0.0001f);
            AudioEvents.StopAllOnTrack.Trigger(AudioTrack.UI);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
            yield return null;
        }
        [UnityTest]
        public IEnumerator LibraryDirectClipAndProviderAliasBothResolve()
        {
            var library = ScriptableObject.CreateInstance<AudioLibrary>();
            library.SetEntries(new[]
            {
                new AudioLibraryEntry { key = "direct", clip = _long },
                new AudioLibraryEntry { key = "mapped", providerKey = "actual-provider-key" }
            });
            _manager.library = library;
            var provider = new CountingProvider { Clip = _short };
            _manager.SetProvider(provider);
            var direct = _manager.PlayAsync("direct", loop: true, debounce: 0);
            while (!direct.IsCompleted) yield return null;
            Assert.AreSame(_long, direct.Result.clip);
            Assert.AreEqual(0, provider.Acquired);
            _manager.StopAll();
            var mapped = _manager.PlayAsync("mapped", loop: true, debounce: 0);
            while (!mapped.IsCompleted) yield return null;
            Assert.AreEqual("actual-provider-key", provider.LastKey);
            Object.Destroy(library);
        }
        [UnityTest]
        public IEnumerator ResourcesProviderKeepsOriginalTrackFolders()
        {
            var provider = new ResourcesClipProvider();
            foreach (AudioTrack track in Enum.GetValues(typeof(AudioTrack)))
            {
                var task = provider.AcquireAsync(track, "jjevol-audio-test-tone");
                while (!task.IsCompleted) yield return null;
                Assert.NotNull(task.Result, track.ToString());
                var clip = task.Result.Clip;
                task.Result.Dispose();
                Assert.IsTrue(clip, "Resources clips are borrowed, not forcibly unloaded.");
            }
        }
        [UnityTest]
        public IEnumerator ScenePolicyPreservesDefaultAndStopsWhenEnabled()
        {
            var provider = new CountingProvider { Clip = _long };
            _manager.SetProvider(provider);
            var original = SceneManager.GetActiveScene();
            var scene = SceneManager.CreateScene("audio-scene-test");
            var task = _manager.PlayAsync("persistent", loop: true, debounce: 0);
            while (!task.IsCompleted) yield return null;
            SceneManager.SetActiveScene(scene);
            Assert.AreEqual(1, _manager.ActiveSourceCount);
            _manager.stopOnSceneChange = true;
            SceneManager.SetActiveScene(original);
            Assert.AreEqual(0, _manager.ActiveSourceCount);
            Assert.AreEqual(1, provider.Released);
            yield return SceneManager.UnloadSceneAsync(scene);
        }
        [UnityTest]
        public IEnumerator DisableAndDestroyReleaseOwnedPlayback()
        {
            var provider = new CountingProvider { Clip = _long };
            _manager.SetProvider(provider, true);
            var task = _manager.PlayAsync("disable", loop: true, debounce: 0);
            while (!task.IsCompleted) yield return null;
            _manager.enabled = false;
            Assert.AreEqual(1, provider.Released);
            _manager.enabled = true;
            var again = _manager.PlayAsync("again", loop: true, debounce: 0);
            while (!again.IsCompleted) yield return null;
            Object.Destroy(_manager.gameObject);
            yield return null;
            Assert.AreEqual(2, provider.Released);
            Assert.IsTrue(provider.Disposed);
        }
        [UnityTest]
        public IEnumerator DelayedCrossfadeDoesNotFadeOrStopAReusedFromSource()
        {
            Object.Destroy(_manager.gameObject);
            yield return null;
            var root = new GameObject("two-source-crossfade");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.initialPoolSize = 2;
            root.SetActive(true);
            var from = _manager.Play(_long, AudioTrack.Music, loop: true, debounce: 0);
            var provider = new CountingProvider { Clip = _short, Gate = new TaskCompletionSource<bool>() };
            _manager.SetProvider(provider);
            _manager.StartCoroutine(_manager.CrossfadeMusic(from, "delayed-crossfade", 0.1f));
            _manager.Stop(from);
            var replacement = _manager.Play(_long, AudioTrack.Music, 0.6f, loop: true, debounce: 0);
            Assert.AreSame(from, replacement);
            provider.Gate.SetResult(true);
            yield return new WaitForSecondsRealtime(0.3f);
            Assert.IsTrue(replacement.isPlaying);
            Assert.AreEqual(0.6f, replacement.volume, 0.0001f);
            Assert.AreEqual(2, _manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator OldCrossfadeCannotChangeAReusedTargetSource()
        {
            var provider = new CountingProvider { Clip = _long };
            _manager.SetProvider(provider);
            _manager.StartCoroutine(_manager.CrossfadeMusic(null, "crossfade-target", 0.2f));
            yield return null;
            var oldTarget = _manager.GetFirstOnTrack(AudioTrack.Music);
            Assert.NotNull(oldTarget);
            _manager.Stop(oldTarget);
            var replacement = _manager.Play(_long, AudioTrack.Music, 0.7f, loop: true, debounce: 0);
            Assert.AreSame(oldTarget, replacement);
            yield return new WaitForSecondsRealtime(0.3f);
            Assert.IsTrue(replacement.isPlaying);
            Assert.AreEqual(0.7f, replacement.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator ProviderInjectedBeforeActivationIsNotReplacedByAwake()
        {
            Object.Destroy(_manager.gameObject);
            yield return null;
            var provider = new CountingProvider { Clip = _long };
            var root = new GameObject("preconfigured-audio-manager");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.SetProvider(provider);
            root.SetActive(true);
            Assert.AreSame(provider, _manager.Provider);
            var task = _manager.PlayAsync("injected", loop: true, debounce: 0);
            while (!task.IsCompleted) yield return null;
            Assert.AreEqual(1, provider.Acquired);
        }
    }
}
