using NUnit.Framework;
using UnityEngine;

namespace jjevol.Audio.Tests
{
    public sealed class AudioTrackStateTests
    {
        private static AudioTrackState State(float master, float music)
        {
            var state = new AudioTrackState();
            state.SetVolume(AudioTrack.Master, master);
            state.SetVolume(AudioTrack.Music, music);
            return state;
        }
        [Test]
        public void SnapshotReachesTheStateDirectlyAndAnOffTrackKeepsItsVolume()
        {
            var snapshot = AudioMixerSettingsSO.DefaultSnapshot();
            snapshot.music = 0.6f; snapshot.musicOn = false;
            var state = new AudioTrackState();
            state.Apply(snapshot);
            Assert.IsFalse(state.IsOn(AudioTrack.Music));
            Assert.AreEqual(0.6f, state.Volume(AudioTrack.Music));
            state.SetOn(AudioTrack.Music, true);
            Assert.AreEqual(0.6f, state.Volume(AudioTrack.Music));
        }
        [Test]
        public void OffTrackSavedAsTheOldMutedValueKeepsItsCurrentVolume()
        {
            var snapshot = AudioMixerSettingsSO.DefaultSnapshot();
            snapshot.music = 0.0001f; snapshot.musicOn = false;
            var state = new AudioTrackState();
            state.SetVolume(AudioTrack.Music, 0.7f);
            state.Apply(snapshot);
            Assert.IsFalse(state.IsOn(AudioTrack.Music));
            Assert.AreEqual(0.7f, state.Volume(AudioTrack.Music));
        }
        [Test]
        public void OffTrackSavedAtZeroStaysAtZero()
        {
            var snapshot = AudioMixerSettingsSO.DefaultSnapshot();
            snapshot.music = 0f; snapshot.musicOn = false;
            var state = new AudioTrackState();
            state.SetVolume(AudioTrack.Music, 0.7f);
            state.Apply(snapshot);
            Assert.AreEqual(0f, state.Volume(AudioTrack.Music));
        }
        [Test]
        public void OnTrackKeepsAVerySmallSavedVolume()
        {
            var snapshot = AudioMixerSettingsSO.DefaultSnapshot();
            snapshot.music = 0.0001f; snapshot.musicOn = true;
            var state = new AudioTrackState();
            state.Apply(snapshot);
            Assert.AreEqual(0.0001f, state.Volume(AudioTrack.Music));
        }
        [Test]
        public void SnapshotRoundTripsEveryTrackIndependently()
        {
            var expected = new AudioMixerSettingsSO.Snapshot
            {
                master = 0.1f, masterOn = true,
                music = 0.2f, musicOn = false,
                sfx = 0.3f, sfxOn = true,
                ui = 0.4f, uiOn = false,
                voice = 0.5f, voiceOn = true,
            };
            var state = new AudioTrackState();
            state.Apply(expected);
            Assert.AreEqual(expected, state.ToSnapshot());
        }
        [Test]
        public void StoredJsonKeepsItsFormatThroughTheState()
        {
            const string stored = "{\"master\":1.0,\"masterOn\":true,\"music\":0.5,\"musicOn\":false,\"sfx\":1.0,\"sfxOn\":true,"
                + "\"ui\":1.0,\"uiOn\":true,\"voice\":1.0,\"voiceOn\":true}";
            var state = new AudioTrackState();
            state.Apply(JsonUtility.FromJson<AudioMixerSettingsSO.Snapshot>(stored));
            Assert.AreEqual(stored, JsonUtility.ToJson(state.ToSnapshot()));
        }
        [Test]
        public void SnapshotVolumesAreClampedLikeTheRuntimeSetter()
        {
            var snapshot = AudioMixerSettingsSO.DefaultSnapshot();
            snapshot.sfx = 3f; snapshot.ui = -1f;
            var state = new AudioTrackState();
            state.Apply(snapshot);
            Assert.AreEqual(1f, state.Volume(AudioTrack.Sfx));
            Assert.AreEqual(0f, state.Volume(AudioTrack.UI));
        }
        [Test]
        public void DefaultsDoNotChangeOnState()
        {
            var state = new AudioTrackState();
            state.SetOn(AudioTrack.Voice, false);
            state.SetDefaults(0.1f, 0.2f, 0.3f, 0.4f, 0.5f);
            Assert.IsFalse(state.IsOn(AudioTrack.Voice));
            Assert.AreEqual(0.1f, state.Volume(AudioTrack.Master));
            Assert.AreEqual(0.2f, state.Volume(AudioTrack.Music));
            Assert.AreEqual(0.3f, state.Volume(AudioTrack.Sfx));
            Assert.AreEqual(0.4f, state.Volume(AudioTrack.UI));
            Assert.AreEqual(0.5f, state.Volume(AudioTrack.Voice));
        }
        [TestCase(true, true)]
        [TestCase(false, true)]
        [TestCase(true, false)]
        [TestCase(false, false)]
        public void EffectiveOnNeedsBothTheTrackAndMaster(bool track, bool master)
        {
            var state = new AudioTrackState();
            state.SetOn(AudioTrack.Sfx, track);
            state.SetOn(AudioTrack.Master, master);
            Assert.AreEqual(track && master, state.EffectiveOn(AudioTrack.Sfx));
        }
        [TestCase(false, false, 0.25f)] // No mixer: the source carries both factors.
        [TestCase(true, false, 0.5f)]   // Track parameter connected: the source carries master only.
        [TestCase(false, true, 0.5f)]   // Track fell back to another group: the source carries the track only.
        [TestCase(true, true, 1f)]      // Fully mixer routed: the source carries neither.
        public void EachVolumeFactorIsAppliedOnce(bool trackViaMixer, bool masterViaMixer, float expected)
        {
            var state = State(0.5f, 0.5f);
            Assert.AreEqual(expected, state.SourceGain(AudioTrack.Music, new AudioRoute(trackViaMixer, masterViaMixer)), 0.0001f);
        }
        [TestCase(false, 0.5f)]
        [TestCase(true, 1f)]
        public void MasterTrackPlaybackCarriesMasterOnce(bool viaMixer, float expected)
        {
            var state = State(0.5f, 1f);
            Assert.AreEqual(expected, state.SourceGain(AudioTrack.Master, new AudioRoute(viaMixer, viaMixer)), 0.0001f);
        }
    }

    public sealed class AudioMixerOutputTests
    {
        [Test]
        public void ConnectedTrackAndMasterParametersBothUseTheMixer()
        {
            var route = AudioMixerOutput.Decide(false, true, true, true, true);
            Assert.IsTrue(route.TrackViaMixer);
            Assert.IsTrue(route.MasterViaMixer);
        }
        [Test]
        public void OverrideGroupInTheMixerKeepsOnlyTheTrackOnTheSource()
        {
            var route = AudioMixerOutput.Decide(true, true, true, true, true);
            Assert.IsFalse(route.TrackViaMixer);
            Assert.IsTrue(route.MasterViaMixer);
        }
        [Test]
        public void OverrideGroupOutsideTheMixerKeepsBothFactorsOnTheSource()
        {
            var route = AudioMixerOutput.Decide(true, false, false, true, true);
            Assert.IsFalse(route.TrackViaMixer);
            Assert.IsFalse(route.MasterViaMixer);
        }
        [Test]
        public void GroupOutsideTheMixerKeepsBothFactorsOnTheSource()
        {
            var route = AudioMixerOutput.Decide(false, false, true, true, true);
            Assert.IsFalse(route.TrackViaMixer);
            Assert.IsFalse(route.MasterViaMixer);
        }
        [Test]
        public void MissingTrackParameterKeepsTheTrackFactorOnTheSource()
        {
            var route = AudioMixerOutput.Decide(false, true, true, false, true);
            Assert.IsFalse(route.TrackViaMixer);
            Assert.IsTrue(route.MasterViaMixer);
        }
        [Test]
        public void FallbackGroupMissesTheTrackParameterButStillReachesMaster()
        {
            var route = AudioMixerOutput.Decide(false, true, false, true, true);
            Assert.IsFalse(route.TrackViaMixer);
            Assert.IsTrue(route.MasterViaMixer);
        }
        [Test]
        public void MissingMasterParameterKeepsTheMasterFactorOnTheSource()
        {
            var route = AudioMixerOutput.Decide(false, true, true, true, false);
            Assert.IsTrue(route.TrackViaMixer);
            Assert.IsFalse(route.MasterViaMixer);
        }
        [Test]
        public void NoSettingsOrNoMixerIsAPlainSourceRoute()
        {
            Assert.AreEqual(default(AudioRoute), AudioMixerOutput.Resolve(null, AudioTrack.Music, null));
            Assert.IsNull(AudioMixerOutput.ChooseGroup(null, AudioTrack.Music, null));
            var settings = ScriptableObject.CreateInstance<AudioMixerSettingsSO>();
            try
            {
                Assert.AreEqual(default(AudioRoute), AudioMixerOutput.Resolve(settings, AudioTrack.Music, null));
                // An unassigned serialized reference can be Unity's fake null, which Assert.IsNull rejects.
                Assert.IsTrue(AudioMixerOutput.ChooseGroup(settings, AudioTrack.Music, null) == null);
            }
            finally { Object.DestroyImmediate(settings); }
        }
    }
}
