using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using Object = UnityEngine.Object;

namespace jjevol.Audio.Tests
{
    public sealed class AudioDebouncerTests
    {
        private float _time;
        private AudioDebouncer Debouncer() => new(() => _time);

        [SetUp]
        public void SetUp() => _time = 0f;

        [Test]
        public void RepeatInsideTheGapIsRejectedAndAfterItPasses()
        {
            var debouncer = Debouncer();
            Assert.IsTrue(debouncer.PassesKey("a", 1f));
            _time = 0.5f;
            Assert.IsFalse(debouncer.PassesKey("a", 1f));
            _time = 1f;
            Assert.IsTrue(debouncer.PassesKey("a", 1f));
        }
        [Test]
        public void RejectedRepeatDoesNotRestartTheGap()
        {
            var debouncer = Debouncer();
            debouncer.PassesKey("a", 1f);
            _time = 0.9f;
            debouncer.PassesKey("a", 1f);
            _time = 1f;
            Assert.IsTrue(debouncer.PassesKey("a", 1f));
        }
        [Test]
        public void ZeroGapPassesAndRecordsNothing()
        {
            var debouncer = Debouncer();
            Assert.IsTrue(debouncer.PassesKey("a", 0f));
            Assert.IsTrue(debouncer.PassesKey("a", 1f), "A zero-gap play must not start a later gap.");
        }
        [Test]
        public void KeysAreComparedExactly()
        {
            var debouncer = Debouncer();
            debouncer.PassesKey("click", 1f);
            Assert.IsTrue(debouncer.PassesKey("Click", 1f));
        }
    }

    public sealed class AudioClipResolverTests
    {
        private sealed class LeaseProvider : IAudioClipLeaseProvider, IDisposable
        {
            internal string LastKey;
            internal bool Disposed;
            public Task<AudioClip> LoadClipAsync(AudioTrack track, string key) => Task.FromResult<AudioClip>(null);
            public Task<AudioClipLease> AcquireAsync(AudioTrack track, string key, CancellationToken token)
            {
                LastKey = key;
                return Task.FromResult(new AudioClipLease(null));
            }
            public void Dispose() => Disposed = true;
        }
        private sealed class LegacyProvider : IAudioClipProvider
        {
            internal string LastKey;
            public Task<AudioClip> LoadClipAsync(AudioTrack track, string key)
            {
                LastKey = key;
                return Task.FromResult<AudioClip>(null);
            }
        }

        [Test]
        public void LibraryProviderKeyReachesTheProviderAndIsReadPerCall()
        {
            AudioLibrary library = null;
            var resolver = new AudioClipResolver(() => library);
            var provider = new LeaseProvider();
            resolver.SetProvider(provider, false);
            var mapped = ScriptableObject.CreateInstance<AudioLibrary>();
            try
            {
                mapped.SetEntries(new[] { new AudioLibraryEntry { key = "alias", providerKey = "actual" } });
                resolver.AcquireAsync("alias", AudioTrack.Sfx, default).Wait();
                Assert.AreEqual("alias", provider.LastKey);
                library = mapped;
                resolver.AcquireAsync("alias", AudioTrack.Sfx, default).Wait();
                Assert.AreEqual("actual", provider.LastKey);
            }
            finally { Object.DestroyImmediate(mapped); }
        }
        [Test]
        public void LegacyProviderIsWrappedInALease()
        {
            var resolver = new AudioClipResolver(() => null);
            var provider = new LegacyProvider();
            resolver.SetProvider(provider, false);
            var task = resolver.AcquireAsync("legacy", AudioTrack.Sfx, default);
            Assert.NotNull(task.Result);
            Assert.AreEqual("legacy", provider.LastKey);
        }
        [Test]
        public void ChangingTheProviderDisposesOnlyAnOwnedOneAndCancelsItsRequests()
        {
            var resolver = new AudioClipResolver(() => null);
            var owned = new LeaseProvider();
            var borrowed = new LeaseProvider();
            resolver.SetProvider(owned, true);
            var request = resolver.ProviderChanged;
            resolver.SetProvider(borrowed, false);
            Assert.IsTrue(owned.Disposed);
            Assert.IsTrue(request.IsCancellationRequested);
            resolver.SetProvider(new LeaseProvider(), false);
            Assert.IsFalse(borrowed.Disposed);
        }
        [Test]
        public void SettingTheSameProviderAgainKeepsItsRequests()
        {
            var resolver = new AudioClipResolver(() => null);
            var provider = new LeaseProvider();
            resolver.SetProvider(provider, true);
            var request = resolver.ProviderChanged;
            resolver.SetProvider(provider, true);
            Assert.IsFalse(request.IsCancellationRequested);
            Assert.IsFalse(provider.Disposed);
        }
        [Test]
        public void DisposeReleasesOnlyAnOwnedProvider()
        {
            var owned = new LeaseProvider();
            var resolver = new AudioClipResolver(() => null);
            resolver.SetProvider(owned, true);
            resolver.Dispose();
            Assert.IsTrue(owned.Disposed);
            var borrowed = new LeaseProvider();
            resolver = new AudioClipResolver(() => null);
            resolver.SetProvider(borrowed, false);
            resolver.Dispose();
            Assert.IsFalse(borrowed.Disposed);
        }
    }

    public sealed class AudioTrackMixerTests
    {
        private GameObject _host;
        private AudioPlayback _playback;

        [SetUp]
        public void SetUp()
        {
            _host = new GameObject("track-mixer-test", typeof(AudioSource));
            _playback = new AudioPlayback { Source = _host.GetComponent<AudioSource>(), Track = AudioTrack.Music, BaseVolume = 0.8f };
        }
        [TearDown]
        public void TearDown() => Object.DestroyImmediate(_host);

        [Test]
        public void WithoutSettingsTheSourceCarriesTrackAndMasterOnce()
        {
            var tracks = new AudioTrackMixer(new AudioTrackState(), () => null);
            tracks.SetVolume(AudioTrack.Music, 0.5f);
            tracks.SetVolume(AudioTrack.Master, 0.5f);
            tracks.Route(_playback);
            Assert.AreEqual(0.2f, _playback.Source.volume, 0.0001f);
            Assert.IsFalse(_playback.Source.mute);
        }
        [Test]
        public void MasterOffMutesAndKeepsEveryVolume()
        {
            var tracks = new AudioTrackMixer(new AudioTrackState(), () => null);
            tracks.SetVolume(AudioTrack.Music, 0.5f);
            tracks.SetOn(AudioTrack.Master, false);
            tracks.Route(_playback);
            Assert.IsTrue(_playback.Source.mute);
            Assert.IsTrue(tracks.IsOn(AudioTrack.Music));
            Assert.AreEqual(0.5f, tracks.Volume(AudioTrack.Music));
        }
        [Test]
        public void EveryPersistenceCallIsSafeWithoutSettings()
        {
            var tracks = new AudioTrackMixer(new AudioTrackState(), () => null);
            tracks.LoadOnStartup();
            tracks.ApplyToMixer();
            tracks.PushChange();
            tracks.Save();
            tracks.ResetPrefs();
            Assert.IsFalse(tracks.Load());
        }
        [Test]
        public void ValidateTrackRejectsAnUndefinedTrack()
        {
            Assert.DoesNotThrow(() => AudioTrackMixer.ValidateTrack(AudioTrack.Voice));
            Assert.Throws<ArgumentOutOfRangeException>(() => AudioTrackMixer.ValidateTrack((AudioTrack)99));
        }
    }

    public sealed class AudioPoolModuleTests
    {
        private GameObject _root;
        private AudioPool _pool;
        private int _released;

        [SetUp]
        public void SetUp()
        {
            _root = new GameObject("audio-pool-test");
            _pool = new AudioPool(_root.transform, 1, false);
            _pool.WarmUp(1);
            _released = 0;
        }
        [TearDown]
        public void TearDown()
        {
            _pool.Dispose();
            Object.DestroyImmediate(_root);
        }
        private AudioPlayback Begin(AudioTrack track = AudioTrack.Sfx)
        {
            var playback = new AudioPlayback { Source = _pool.Rent(null, false, 1f), Track = track };
            _pool.Begin(playback, new AudioClipLease(null, () => _released++));
            return playback;
        }

        [Test]
        public void EndReturnsTheSourceAndItsLeaseOnce()
        {
            var playback = Begin();
            Assert.AreEqual(1, _pool.ActiveCount);
            Assert.IsTrue(_pool.IsLive(playback));
            _pool.End(playback.Source);
            _pool.End(playback.Source);
            Assert.AreEqual(1, _released);
            Assert.AreEqual(0, _pool.ActiveCount);
            Assert.IsFalse(playback.Source.gameObject.activeSelf);
            Assert.IsFalse(_pool.IsLive(playback));
        }
        [Test]
        public void StolenSourceEndsItsOldPlaybackFirst()
        {
            var first = Begin();
            var second = Begin();
            Assert.AreSame(first.Source, second.Source);
            Assert.AreEqual(1, _released);
            Assert.IsFalse(_pool.IsLive(first), "Identity is the playback, not the reused source.");
            Assert.IsTrue(_pool.IsLive(second));
            Assert.IsTrue(second.Source.gameObject.activeSelf);
        }
        [Test]
        public void TrackChangeReachesItsOwnPlaybacksAndMasterReachesAll()
        {
            var pool = new AudioPool(_root.transform, 2, true);
            pool.WarmUp(2);
            var sfx = new AudioPlayback { Source = pool.Rent(null, false, 1f), Track = AudioTrack.Sfx };
            pool.Begin(sfx, null);
            var music = new AudioPlayback { Source = pool.Rent(null, false, 1f), Track = AudioTrack.Music };
            pool.Begin(music, null);
            var reached = new List<AudioPlayback>();
            pool.ForEachAffectedBy(AudioTrack.Music, reached.Add);
            CollectionAssert.AreEquivalent(new[] { music }, reached);
            reached.Clear();
            pool.ForEachAffectedBy(AudioTrack.Master, reached.Add);
            CollectionAssert.AreEquivalent(new[] { sfx, music }, reached);
            pool.Dispose();
        }
        [Test]
        public void EndTrackLeavesOtherTracksPlaying()
        {
            var pool = new AudioPool(_root.transform, 2, true);
            pool.WarmUp(2);
            var sfx = new AudioPlayback { Source = pool.Rent(null, false, 1f), Track = AudioTrack.Sfx };
            pool.Begin(sfx, null);
            var music = new AudioPlayback { Source = pool.Rent(null, false, 1f), Track = AudioTrack.Music };
            pool.Begin(music, null);
            pool.EndTrack(AudioTrack.Sfx);
            Assert.AreEqual(1, pool.ActiveCount);
            Assert.AreSame(music.Source, pool.FirstOnTrack(AudioTrack.Music));
            Assert.IsNull(pool.FirstOnTrack(AudioTrack.Sfx));
            pool.Dispose();
        }
    }

    /// <summary>The channel built on a fake host: no AudioManager, MonoBehaviour or AudioSource.</summary>
    public sealed class AudioMusicChannelHostTests
    {
        private sealed class FakeHost : IAudioMusicHost
        {
            internal readonly List<AudioPlayback> Live = new();
            internal readonly List<AudioPlayback> Stopped = new();
            internal IEnumerator Fade;
            public bool IsLive(AudioPlayback playback) => playback != null && Live.Contains(playback);
            public void StopPlayback(AudioPlayback playback) { if (Live.Remove(playback)) Stopped.Add(playback); }
            public void ApplyOutput(AudioPlayback playback) { }
            public IEnumerable<AudioPlayback> ActiveMusic() => Live;
            public AudioPlayback StartMusicClip(AudioClip clip, float volume, float pitch, float fade) => Started(fade);
            public Task<AudioSource> StartMusicAsync(string key, float volume, float pitch, float fade, CancellationToken superseded, Action<AudioPlayback> onStarted)
            {
                onStarted(Started(fade));
                return Task.FromResult<AudioSource>(null);
            }
            public void StartFade(IEnumerator routine) => Fade = routine;
            private AudioPlayback Started(float fade)
            {
                var playback = new AudioPlayback { Track = AudioTrack.Music, Fade = fade };
                Live.Add(playback);
                return playback;
            }
        }
        private FakeHost _host;
        private AudioMusicChannel _channel;
        private AudioPlayback Request(string key, float seconds = 0f, bool claimTrack = true)
            => _channel.RequestAsync(null, key, 1f, 1f, seconds, null, claimTrack).Result;

        [SetUp]
        public void SetUp()
        {
            _host = new FakeHost();
            _channel = new AudioMusicChannel(_host);
        }
        [TearDown]
        public void TearDown() => _channel.Dispose();

        [Test]
        public void PlainRequestStopsTheMusicItReplaces()
        {
            var first = Request("first");
            var second = Request("second");
            CollectionAssert.AreEqual(new[] { first }, _host.Stopped);
            Assert.AreSame(second, _channel.Current);
        }
        [Test]
        public void ClaimingTheTrackDecidesWhetherDirectMusicIsReplaced()
        {
            var direct = _host.StartMusicClip(null, 1f, 1f, 1f);
            Request("kept", claimTrack: false);
            Assert.IsTrue(_host.IsLive(direct));
            Request("claimed");
            Assert.IsFalse(_host.IsLive(direct));
        }
        [Test]
        public void EmptyRequestStartsNothing()
        {
            var current = Request("current");
            Assert.IsNull(Request(" "));
            Assert.AreSame(current, _channel.Current);
            Assert.IsEmpty(_host.Stopped);
        }
        [Test]
        public void CrossfadeStartsSilentAndHandsTheFadeToTheHost()
        {
            Request("first");
            var next = Request("next", 1f);
            Assert.AreEqual(0f, next.Fade);
            Assert.IsTrue(_channel.IsFadingTo(next));
            Assert.NotNull(_host.Fade);
            Assert.AreEqual(2, _host.Live.Count, "The replaced music plays through the fade.");
        }
        [Test]
        public void StoppingTheFadeTargetBringsBackTheMusicItWasReplacing()
        {
            var first = Request("first");
            var next = Request("next", 1000f);
            _host.Fade.MoveNext();
            _host.StopPlayback(next);
            _host.Fade.MoveNext();
            Assert.AreSame(first, _channel.Current);
            Assert.AreEqual(1f, first.Fade);
            Assert.IsFalse(_channel.IsFadingTo(next));
        }
        [Test]
        public void ResetForgetsEverything()
        {
            Request("first");
            _channel.Reset();
            Assert.IsNull(_channel.Current);
        }
    }

    public sealed class AudioManagerBeforeInitializationTests
    {
        private sealed class Provider : IAudioClipProvider
        {
            public Task<AudioClip> LoadClipAsync(AudioTrack track, string key) => Task.FromResult<AudioClip>(null);
        }

        [Test]
        public void InspectorAndPreActivationCallsNeedNoInitialization()
        {
            var host = new GameObject("audio-manager-edit-mode");
            try
            {
                var manager = host.AddComponent<AudioManager>();
                Assert.AreEqual(1f, manager.GetTrackVolume(AudioTrack.Music));
                Assert.IsTrue(manager.IsTrackOn(AudioTrack.Music));
                Assert.AreEqual(0, manager.ActiveSourceCount);
                Assert.IsNull(manager.CurrentMusic);
                Assert.IsNull(manager.GetFirstOnTrack(AudioTrack.Music));
                manager.Stop(null);
                manager.PauseTrack(AudioTrack.Music);
                manager.PlayTrack(AudioTrack.Music);
                manager.StopAll();
                manager.SetTrackVolume(AudioTrack.Music, 0.5f);
                Assert.AreEqual(0.5f, manager.GetTrackVolume(AudioTrack.Music));
                var provider = new Provider();
                manager.SetProvider(provider);
                Assert.AreSame(provider, manager.Provider);
            }
            finally { Object.DestroyImmediate(host); }
        }
    }
}
