using System;
using NUnit.Framework;
using UnityEngine;

namespace jjevol.Audio.Tests
{
    public sealed class AudioContractsTests
    {
        private enum GameSound { Click, Other }
        private enum AnotherGameSound { Click }
        [Test]
        public void LeaseDisposesExactlyOnce()
        {
            int released = 0;
            var lease = new AudioClipLease(null, () => released++);
            lease.Dispose(); lease.Dispose();
            Assert.AreEqual(1, released);
        }
        [Test]
        public void EnumsRequireExplicitMappingsAndIncludeTheirType()
        {
            AudioKeys.Register(GameSound.Click, "test-click");
            AudioKeys.Register(AnotherGameSound.Click, "other-click");
            Assert.AreEqual("test-click", AudioKeys.Get(GameSound.Click));
            Assert.AreEqual("other-click", AudioKeys.Get(AnotherGameSound.Click));
            Assert.Throws<InvalidOperationException>(() => AudioKeys.Register(GameSound.Click, "changed"));
            Assert.Throws<System.Collections.Generic.KeyNotFoundException>(() => AudioKeys.Get(GameSound.Other));
        }
        [Test]
        public void EventTriggerRetainsKeyClipEnumAndControlCallShapes()
        {
            AudioKeys.Register(GameSound.Click, "test-click");
            AudioEvents.PlaySfx seen = default;
            AudioEvents.PlayMusic music = default;
            AudioEvents.SetTrackVolume volume = default;
            Action<AudioEvents.PlaySfx> onSfx = e => seen = e;
            Action<AudioEvents.PlayMusic> onMusic = e => music = e;
            Action<AudioEvents.SetTrackVolume> onVolume = e => volume = e;
            AudioEvents.SfxRequested += onSfx;
            AudioEvents.MusicRequested += onMusic;
            AudioEvents.TrackVolumeRequested += onVolume;
            var clip = AudioClip.Create("event-test", 1024, 1, 44100, false);
            try
            {
                AudioEvents.PlaySfx.Trigger(GameSound.Click, 0.5f, 1.2f, true);
                Assert.AreEqual("test-click", seen.key);
                Assert.AreEqual(GameSound.Click, seen.soundType);
                Assert.IsTrue(seen.loop);
                AudioEvents.PlaySfx.Trigger(clip);
                Assert.AreSame(clip, seen.clip);
                Assert.IsNull(seen.soundType);
                AudioEvents.PlayMusic.Trigger("music-key", crossfade: 0.4f);
                Assert.AreEqual(0.4f, music.crossfadeSeconds);
                Assert.IsNull(music.soundType);
                AudioEvents.SetTrackVolume.Trigger(AudioTrack.UI, 0.3f);
                Assert.AreEqual(AudioTrack.UI, volume.track);
                Assert.AreEqual(0.3f, volume.volume01);
            }
            finally
            {
                AudioEvents.SfxRequested -= onSfx;
                AudioEvents.MusicRequested -= onMusic;
                AudioEvents.TrackVolumeRequested -= onVolume;
                UnityEngine.Object.DestroyImmediate(clip);
            }
        }
        [Test]
        public void LibraryRejectsDuplicatesWithoutReplacingValidEntries()
        {
            var library = ScriptableObject.CreateInstance<AudioLibrary>();
            try
            {
                library.SetEntries(new[] { new AudioLibraryEntry { key = "click", providerKey = "ui-click" } });
                Assert.Throws<InvalidOperationException>(() => library.SetEntries(new[]
                {
                    new AudioLibraryEntry { key = "duplicate" }, new AudioLibraryEntry { key = "duplicate" }
                }));
                Assert.IsTrue(library.TryGet("click", out var entry));
                Assert.AreEqual("ui-click", entry.providerKey);
            }
            finally { UnityEngine.Object.DestroyImmediate(library); }
        }
        [Test]
        public void PoolReusesReleasedSourceAndPreservesFirstSourceStealing()
        {
            var root = new GameObject("audio-pool-test");
            using var pool = new AudioPool(root.transform, 1, false);
            try
            {
                pool.WarmUp(1);
                var source = pool.Get();
                Assert.AreSame(source, pool.Get());
                pool.Release(source);
                Assert.IsFalse(source.gameObject.activeSelf);
                Assert.IsNull(source.clip);
                Assert.AreSame(source, pool.Get());
            }
            finally { UnityEngine.Object.DestroyImmediate(root); }
        }
        [Test]
        public void EmptyNonExpandingPoolCreatesItsFirstSource()
        {
            using var pool = new AudioPool(null, 0, false);
            Assert.NotNull(pool.Get());
        }
        [TestCase(1f)]
        [TestCase(0.5f)]
        [TestCase(0.001f)]
        public void MixerNormalizedConversionRoundTrips(float volume)
            => Assert.AreEqual(volume, AudioMixerSettingsSO.DbToNorm(AudioMixerSettingsSO.NormToDb(volume)), 0.00001f);
    }
}
