using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("JJEvol.Audio.Tests.Editor")]
[assembly: InternalsVisibleTo("JJEvol.Audio.Tests.Runtime")]
