using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace jjevol.Audio
{
    /// <summary>
    /// Tracks the one current music playback. The latest request wins: it cancels any request still loading, and when it
    /// starts, everything it replaces stops or fades out. The running music keeps playing until then, so a request that
    /// fails to load leaves it untouched.
    /// </summary>
    internal sealed class AudioMusicChannel : IDisposable
    {
        private readonly IAudioMusicHost _host;
        private readonly List<AudioPlayback> _outgoing = new(4);
        private CancellationTokenSource _pending = new();
        private AudioPlayback _current, _fallback, _fadeTarget;

        internal AudioMusicChannel(IAudioMusicHost host) => _host = host;

        internal AudioPlayback Current => _host.IsLive(_current) ? _current : null;
        internal bool IsFadingTo(AudioPlayback playback) => playback != null && ReferenceEquals(_fadeTarget, playback);

        /// <param name="from">An extra playback to replace, beyond those the channel already tracks.</param>
        /// <param name="claimTrack">Also replace Music sources started directly through Play or PlayAsync.</param>
        internal async Task<AudioPlayback> RequestAsync(AudioClip clip, string key, float volume, float pitch, float seconds,
            AudioPlayback from, bool claimTrack)
        {
            if (!clip && string.IsNullOrWhiteSpace(key)) return null;
            var superseded = Supersede();
            float fade = seconds > 0f ? 0f : 1f;
            AudioPlayback started = null;
            if (clip)
            {
                started = _host.StartMusicClip(clip, volume, pitch, fade);
                if (started != null) Adopt(started, from, seconds, claimTrack);
            }
            else
            {
                await _host.StartMusicAsync(key, volume, pitch, fade, superseded, playback =>
                {
                    started = playback;
                    Adopt(playback, from, seconds, claimTrack);
                });
            }
            return started;
        }

        /// <summary>Everything on the track is already being stopped by the caller; forget it all.</summary>
        internal void Reset()
        {
            Supersede();
            _current = _fallback = _fadeTarget = null;
            _outgoing.Clear();
        }

        public void Dispose() => _pending.Dispose();

        private CancellationToken Supersede()
        {
            _pending.Cancel();
            _pending.Dispose();
            _pending = new CancellationTokenSource();
            return _pending.Token;
        }

        private void Adopt(AudioPlayback next, AudioPlayback from, float seconds, bool claimTrack)
        {
            _fallback = _host.IsLive(_current) ? _current : _host.IsLive(from) ? from : null;
            AddOutgoing(_current, next);
            AddOutgoing(from, next);
            if (claimTrack)
                foreach (var playback in _host.ActiveMusic()) AddOutgoing(playback, next);
            _current = next;
            if (seconds > 0f)
            {
                foreach (var playback in _outgoing) playback.FadeStart = playback.Fade;
                _fadeTarget = next;
                _host.StartFade(RunFade(next, seconds));
            }
            else
            {
                _fallback = _fadeTarget = null;
                StopOutgoing();
            }
        }
        private void AddOutgoing(AudioPlayback playback, AudioPlayback next)
        {
            if (playback != next && _host.IsLive(playback) && !_outgoing.Contains(playback)) _outgoing.Add(playback);
        }
        private void StopOutgoing()
        {
            foreach (var playback in _outgoing) _host.StopPlayback(playback);
            _outgoing.Clear();
        }

        private IEnumerator RunFade(AudioPlayback next, float seconds)
        {
            for (float elapsed = 0; elapsed < seconds; elapsed += Time.unscaledDeltaTime)
            {
                if (!ReferenceEquals(_fadeTarget, next)) yield break;
                if (!_host.IsLive(next)) { RecoverFallback(); yield break; }
                float amount = Mathf.Clamp01(elapsed / seconds);
                next.Fade = amount;
                _host.ApplyOutput(next);
                foreach (var playback in _outgoing)
                {
                    if (!_host.IsLive(playback)) continue;
                    playback.Fade = playback.FadeStart * (1 - amount);
                    _host.ApplyOutput(playback);
                }
                yield return null;
            }
            if (!ReferenceEquals(_fadeTarget, next)) yield break;
            if (!_host.IsLive(next)) { RecoverFallback(); yield break; }
            _fallback = _fadeTarget = null;
            StopOutgoing();
            next.Fade = 1;
            _host.ApplyOutput(next);
        }

        // The fade target was stopped from outside: the music it was replacing stays as the current music.
        private void RecoverFallback()
        {
            var survivor = _fallback;
            _fallback = _fadeTarget = null;
            _outgoing.Remove(survivor);
            StopOutgoing();
            if (!_host.IsLive(survivor)) return;
            survivor.Fade = 1f;
            _host.ApplyOutput(survivor);
            _current = survivor;
        }
    }
}
