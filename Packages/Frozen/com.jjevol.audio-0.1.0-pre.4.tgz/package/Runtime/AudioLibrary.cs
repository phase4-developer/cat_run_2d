using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Audio
{
    [Serializable]
    public sealed class AudioLibraryEntry
    {
        public string key;
        public AudioClip clip;
        [Tooltip("Optional provider address/path override. Empty uses key.")]
        public string providerKey;
    }

    [CreateAssetMenu(menuName = "JJEvol/Audio/Audio Library")]
    public sealed class AudioLibrary : ScriptableObject
    {
        [SerializeField] private List<AudioLibraryEntry> entries = new();
        public IReadOnlyList<AudioLibraryEntry> Entries => entries.AsReadOnly();
        public void SetEntries(IEnumerable<AudioLibraryEntry> values)
        {
            if (values == null) throw new ArgumentNullException(nameof(values));
            var next = new List<AudioLibraryEntry>(values);
            Validate(next);
            entries = next;
        }
        public void Validate() => Validate(entries);
        private static void Validate(IEnumerable<AudioLibraryEntry> values)
        {
            var keys = new HashSet<string>(StringComparer.Ordinal);
            foreach (var entry in values)
                if (entry == null || string.IsNullOrWhiteSpace(entry.key) || !keys.Add(entry.key))
                    throw new InvalidOperationException("Audio Library entries need unique, nonempty keys.");
        }
        public bool TryGet(string key, out AudioLibraryEntry entry)
        {
            Validate();
            entry = entries.Find(item => string.Equals(item.key, key, StringComparison.Ordinal));
            return entry != null;
        }
    }
}
