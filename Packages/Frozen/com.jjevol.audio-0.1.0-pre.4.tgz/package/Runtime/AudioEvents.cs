using System;
using UnityEngine;

namespace jjevol.Audio
{
    /// <summary>Project-owned audio events. Trigger usage is retained; no external event framework is required.</summary>
    public static class AudioEvents
    {
        public static event Action<PlaySfx> SfxRequested;
        public struct PlaySfx
        {
            public Enum soundType;
            public string key;
            public AudioClip clip;
            public float volume;
            public float pitch;
            public bool loop;
            public PlaySfx(string key, float volume = 1f, float pitch = 1f, bool loop = false)
            { soundType = null; this.key = key; clip = null; this.volume = volume; this.pitch = pitch; this.loop = loop; }
            public PlaySfx(AudioClip clip, float volume = 1f, float pitch = 1f, bool loop = false)
            { soundType = null; key = null; this.clip = clip; this.volume = volume; this.pitch = pitch; this.loop = loop; }
            public PlaySfx(Enum soundType, float volume = 1f, float pitch = 1f, bool loop = false)
                : this(AudioKeys.Get(soundType), volume, pitch, loop) { this.soundType = soundType; }
            public static void Trigger(string key, float volume = 1f, float pitch = 1f, bool loop = false)
                => SfxRequested?.Invoke(new PlaySfx(key, volume, pitch, loop));
            public static void Trigger(AudioClip clip, float volume = 1f, float pitch = 1f, bool loop = false)
                => SfxRequested?.Invoke(new PlaySfx(clip, volume, pitch, loop));
            public static void Trigger<TEnum>(TEnum soundType, float volume = 1f, float pitch = 1f, bool loop = false) where TEnum : struct, Enum
                => SfxRequested?.Invoke(new PlaySfx((Enum)(object)soundType, volume, pitch, loop));
        }
        public static event Action<PlayUI> UiRequested;
        public struct PlayUI
        {
            public Enum soundType;
            public string key;
            public AudioClip clip;
            public float volume;
            public float pitch;
            public bool loop;
            public PlayUI(string key, float volume = 1f, float pitch = 1f, bool loop = false)
            { soundType = null; this.key = key; clip = null; this.volume = volume; this.pitch = pitch; this.loop = loop; }
            public PlayUI(AudioClip clip, float volume = 1f, float pitch = 1f, bool loop = false)
            { soundType = null; key = null; this.clip = clip; this.volume = volume; this.pitch = pitch; this.loop = loop; }
            public PlayUI(Enum soundType, float volume = 1f, float pitch = 1f, bool loop = false)
                : this(AudioKeys.Get(soundType), volume, pitch, loop) { this.soundType = soundType; }
            public static void Trigger(string key, float volume = 1f, float pitch = 1f, bool loop = false)
                => UiRequested?.Invoke(new PlayUI(key, volume, pitch, loop));
            public static void Trigger(AudioClip clip, float volume = 1f, float pitch = 1f, bool loop = false)
                => UiRequested?.Invoke(new PlayUI(clip, volume, pitch, loop));
            public static void Trigger<TEnum>(TEnum soundType, float volume = 1f, float pitch = 1f, bool loop = false) where TEnum : struct, Enum
                => UiRequested?.Invoke(new PlayUI((Enum)(object)soundType, volume, pitch, loop));
        }
        public static event Action<PlayVoice> VoiceRequested;
        public struct PlayVoice
        {
            public Enum soundType;
            public string key;
            public AudioClip clip;
            public float volume;
            public float pitch;
            public bool loop;
            public PlayVoice(string key, float volume = 1f, float pitch = 1f, bool loop = false)
            { soundType = null; this.key = key; clip = null; this.volume = volume; this.pitch = pitch; this.loop = loop; }
            public PlayVoice(AudioClip clip, float volume = 1f, float pitch = 1f, bool loop = false)
            { soundType = null; key = null; this.clip = clip; this.volume = volume; this.pitch = pitch; this.loop = loop; }
            public PlayVoice(Enum soundType, float volume = 1f, float pitch = 1f, bool loop = false)
                : this(AudioKeys.Get(soundType), volume, pitch, loop) { this.soundType = soundType; }
            public static void Trigger(string key, float volume = 1f, float pitch = 1f, bool loop = false)
                => VoiceRequested?.Invoke(new PlayVoice(key, volume, pitch, loop));
            public static void Trigger(AudioClip clip, float volume = 1f, float pitch = 1f, bool loop = false)
                => VoiceRequested?.Invoke(new PlayVoice(clip, volume, pitch, loop));
            public static void Trigger<TEnum>(TEnum soundType, float volume = 1f, float pitch = 1f, bool loop = false) where TEnum : struct, Enum
                => VoiceRequested?.Invoke(new PlayVoice((Enum)(object)soundType, volume, pitch, loop));
        }
        public static event Action<PlayMusic> MusicRequested;
        public struct PlayMusic
        {
            public Enum soundType;
            public string key;
            public AudioClip clip;
            public float volume;
            public float pitch;
            public float crossfadeSeconds;
            public PlayMusic(string key, float volume = 1f, float pitch = 1f, float crossfade = 0f)
            { soundType = null; this.key = key; clip = null; this.volume = volume; this.pitch = pitch; crossfadeSeconds = crossfade; }
            public PlayMusic(AudioClip clip, float volume = 1f, float pitch = 1f, float crossfade = 0f)
            { soundType = null; key = null; this.clip = clip; this.volume = volume; this.pitch = pitch; crossfadeSeconds = crossfade; }
            public PlayMusic(Enum soundType, float volume = 1f, float pitch = 1f, float crossfade = 0f)
                : this(AudioKeys.Get(soundType), volume, pitch, crossfade) { this.soundType = soundType; }
            public static void Trigger(string key, float volume = 1f, float pitch = 1f, float crossfade = 0f)
                => MusicRequested?.Invoke(new PlayMusic(key, volume, pitch, crossfade));
            public static void Trigger(AudioClip clip, float volume = 1f, float pitch = 1f, float crossfade = 0f)
                => MusicRequested?.Invoke(new PlayMusic(clip, volume, pitch, crossfade));
            public static void Trigger<TEnum>(TEnum soundType, float volume = 1f, float pitch = 1f, float crossfade = 0f) where TEnum : struct, Enum
                => MusicRequested?.Invoke(new PlayMusic((Enum)(object)soundType, volume, pitch, crossfade));
        }
        public static event Action<StopAllOnTrack> StopRequested;
        public struct StopAllOnTrack
        {
            public AudioTrack track;

            public StopAllOnTrack(AudioTrack track) { this.track = track;  }
            public static void Trigger(AudioTrack track) => StopRequested?.Invoke(new StopAllOnTrack(track));
        }
        public static event Action<SetTrackOn> TrackOnRequested;
        public struct SetTrackOn
        {
            public AudioTrack track;
            public bool on;
            public SetTrackOn(AudioTrack track, bool on) { this.track = track; this.on = on; }
            public static void Trigger(AudioTrack track, bool on) => TrackOnRequested?.Invoke(new SetTrackOn(track, on));
        }
        public static event Action<SetTrackVolume> TrackVolumeRequested;
        public struct SetTrackVolume
        {
            public AudioTrack track;
            public float volume01;
            public SetTrackVolume(AudioTrack track, float volume01) { this.track = track; this.volume01 = volume01; }
            public static void Trigger(AudioTrack track, float volume01) => TrackVolumeRequested?.Invoke(new SetTrackVolume(track, volume01));
        }
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void Reset()
        {
            SfxRequested = null; UiRequested = null; VoiceRequested = null; MusicRequested = null;
            StopRequested = null; TrackOnRequested = null; TrackVolumeRequested = null;
        }
    }
}
