using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Audio;

namespace jjevol.Audio
{
    /// <summary>The gameplay surface of audio, for code that receives its player instead of reaching for AudioManager.Instance.</summary>
    public interface IAudioPlayer
    {
        AudioSource CurrentMusic { get; }

        AudioSource Play(AudioClip clip, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null);
        Task<AudioSource> PlayAsync(string key, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null);
        Task<AudioSource> PlayAsync(string key, CancellationToken cancellationToken, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null);
        Task<AudioSource> PlayAsync<TEnum>(TEnum soundType, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null) where TEnum : struct, Enum;

        void Stop(AudioSource src);
        void StopAllOnTrack(AudioTrack track);
        void StopAll();

        Task<AudioSource> PlayMusicAsync(string key, float volume = 1f, float pitch = 1f, float crossfadeSeconds = 0f);
        Task<AudioSource> PlayMusicAsync(AudioClip clip, float volume = 1f, float pitch = 1f, float crossfadeSeconds = 0f);
        Task<AudioSource> PlayMusicAsync<TEnum>(TEnum soundType, float volume = 1f, float pitch = 1f, float crossfadeSeconds = 0f) where TEnum : struct, Enum;
        IEnumerator CrossfadeMusic(AudioSource from, string toKey, float duration, float targetVolume = 1f);

        void SetTrackOn(AudioTrack track, bool on);
        bool IsTrackOn(AudioTrack track);
        void SetTrackVolume(AudioTrack track, float volume01);
        float GetTrackVolume(AudioTrack track);
    }
}
