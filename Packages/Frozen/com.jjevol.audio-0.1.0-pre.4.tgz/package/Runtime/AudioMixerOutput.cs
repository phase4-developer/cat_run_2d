using UnityEngine.Audio;

namespace jjevol.Audio
{
    /// <summary>Which output carries each volume factor of one playback. The default routes both through the AudioSource.</summary>
    internal readonly struct AudioRoute
    {
        internal readonly bool TrackViaMixer, MasterViaMixer;
        internal AudioRoute(bool trackViaMixer, bool masterViaMixer)
        {
            TrackViaMixer = trackViaMixer;
            MasterViaMixer = masterViaMixer;
        }
    }

    /// <summary>Group selection and the rule deciding whether the mixer really carries a volume factor.</summary>
    internal static class AudioMixerOutput
    {
        internal static AudioMixerGroup ChooseGroup(AudioMixerSettingsSO settings, AudioTrack track, AudioMixerGroup overrideGroup)
        {
            if (overrideGroup) return overrideGroup;
            if (settings)
            {
                return track switch
                {
                    AudioTrack.Music => settings.musicGroup ? settings.musicGroup : settings.masterGroup,
                    AudioTrack.Sfx => settings.sfxGroup ? settings.sfxGroup : settings.masterGroup,
                    AudioTrack.UI => settings.uiGroup ? settings.uiGroup : (settings.sfxGroup ? settings.sfxGroup : settings.masterGroup),
                    AudioTrack.Voice => settings.voiceGroup ? settings.voiceGroup : settings.masterGroup,
                    _ => settings.masterGroup
                };
            }
            return null;
        }

        internal static AudioRoute Resolve(AudioMixerSettingsSO settings, AudioTrack track, AudioMixerGroup overrideGroup)
        {
            if (!settings || !settings.mixer) return default;
            var dedicated = DedicatedGroup(settings, track);
            var chosen = ChooseGroup(settings, track, overrideGroup);
            return Decide(
                overridden: overrideGroup && overrideGroup != dedicated,
                inMixer: chosen && chosen.audioMixer == settings.mixer,
                onDedicatedGroup: dedicated && chosen == dedicated,
                hasTrackParameter: HasParameter(settings, TrackParameter(settings, track)),
                hasMasterParameter: HasParameter(settings, settings.masterParam));
        }

        /// <summary>
        /// A track factor reaches the mixer only through the track's own group; an override or a fallback to another group
        /// misses that track's parameter. Every group of a mixer reaches its master, so master needs only the same mixer.
        /// </summary>
        internal static AudioRoute Decide(bool overridden, bool inMixer, bool onDedicatedGroup, bool hasTrackParameter, bool hasMasterParameter)
        {
            if (!inMixer) return default;
            return new AudioRoute(!overridden && onDedicatedGroup && hasTrackParameter, hasMasterParameter);
        }

        private static AudioMixerGroup DedicatedGroup(AudioMixerSettingsSO settings, AudioTrack track) => track switch
        {
            AudioTrack.Music => settings.musicGroup,
            AudioTrack.Sfx => settings.sfxGroup,
            AudioTrack.UI => settings.uiGroup,
            AudioTrack.Voice => settings.voiceGroup,
            _ => settings.masterGroup
        };
        private static string TrackParameter(AudioMixerSettingsSO settings, AudioTrack track) => track switch
        {
            AudioTrack.Music => settings.musicParam,
            AudioTrack.Sfx => settings.sfxParam,
            AudioTrack.UI => settings.uiParam,
            AudioTrack.Voice => settings.voiceParam,
            _ => settings.masterParam
        };
        private static bool HasParameter(AudioMixerSettingsSO settings, string parameter)
            => !string.IsNullOrEmpty(parameter) && settings.mixer.GetFloat(parameter, out _);
    }
}
