using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

namespace jjevol.Audio
{
    public enum AudioTrack { Master, Music, Sfx, UI, Voice }

    [DefaultExecutionOrder(-1000)]
    public class AudioManager : MonoBehaviour, IAudioPlayer
    {
        private static AudioManager _instance;
        public static bool applicationIsQuitting;
        public static AudioManager Instance
        {
            get
            {
                if (!Application.isPlaying || applicationIsQuitting) return null;
                if (!_instance) _instance = FindAnyObjectByType<AudioManager>();
                if (!_instance) _instance = new GameObject(typeof(AudioManager).FullName).AddComponent<AudioManager>();
                return _instance;
            }
        }
        public static bool HasInstance => !IsDestroyed;
        public static bool IsDestroyed => applicationIsQuitting || !_instance;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatic() { _instance = null; applicationIsQuitting = false; }

        [Header("Mixer Settings")]
        public AudioMixerSettingsSO mixerSettings;

        [Header("Pool")]
        public int initialPoolSize = 16;
        public bool poolCanExpand = true;

        [Header("Debounce")]
        public float defaultDebounceSeconds = 0.10f;

        [Header("Default Track Volumes")]
        [Range(0, 1)] public float defaultMasterVolume = 1f;
        [Range(0, 1)] public float defaultMusicVolume = 1f;
        [Range(0, 1)] public float defaultSfxVolume = 1f;
        [Range(0, 1)] public float defaultUiVolume = 1f;
        [Range(0, 1)] public float defaultVoiceVolume = 1f;

        [Header("Optional Key Library")]
        public AudioLibrary library;
        [Tooltip("Default preserves the original persistent manager and music across scene changes.")]
        public bool stopOnSceneChange;

        // Inspectors read tracks in Edit Mode and SetProvider can precede activation, so these two are built on first use.
        private AudioTrackMixer _trackMixer;
        private AudioClipResolver _clipResolver;
        private AudioTrackMixer Tracks => _trackMixer ??= new AudioTrackMixer(new AudioTrackState(), () => mixerSettings);
        private AudioClipResolver Clips => _clipResolver ??= new AudioClipResolver(() => library);
        private AudioPool _pool;
        private AudioPlaybackRequests _requests;
        private AudioMusicChannel _music;
        private bool _initialized, _subscribed, _destroyed, _applicationPaused;
        public IAudioClipProvider Provider => Clips.Provider;
        public int ActiveSourceCount => _pool?.ActiveCount ?? 0;
        /// <summary>The music the channel tracks: PlayMusic events, AudioEventPlayer and CrossfadeMusic. Null when none is live.</summary>
        public AudioSource CurrentMusic => _music?.Current?.Source;
        internal AudioPool Pool => _pool;
        [SerializeField] private ProviderKind providerKind = ProviderKind.Resources;

        protected virtual void Awake()
        {
            if (!Application.isPlaying) return;
            if (_instance && _instance != this) { Destroy(gameObject); return; }
            _instance = this;
            if (transform.parent) transform.SetParent(null);
            DontDestroyOnLoad(gameObject);
            EnsureInitialized();
        }
        private void EnsureInitialized()
        {
            if (_destroyed) throw new ObjectDisposedException(nameof(AudioManager));
            if (_initialized) return;
            if (!Application.isPlaying) throw new InvalidOperationException("AudioManager playback requires Play Mode.");
            _initialized = true;
            _pool = new AudioPool(transform, initialPoolSize, poolCanExpand);
            _pool.WarmUp(Mathf.Max(1, initialPoolSize));
            _requests = new AudioPlaybackRequests(_pool, Tracks, Clips, new AudioDebouncer(() => Time.unscaledTime),
                () => this && isActiveAndEnabled, StartCoroutine);
            _music = new AudioMusicChannel(_requests);
            Tracks.SetDefaults(defaultMasterVolume, defaultMusicVolume, defaultSfxVolume, defaultUiVolume, defaultVoiceVolume);
            if (Provider == null) SetProvider(providerKind);
            Tracks.LoadOnStartup();
        }
        // SetFloat in Awake can be ignored, and a parameter lookup then can miss, so both outputs are repeated here.
        private void Start()
        {
            if (!_initialized || _destroyed) return;
            Tracks.ApplyToMixer();
            foreach (var playback in _pool.Playbacks) Tracks.Reroute(playback);
            RefreshOutputs(AudioTrack.Master);
        }
        protected virtual void OnEnable()
        {
            if (!Application.isPlaying || (_instance && _instance != this)) return;
            EnsureInitialized();
            _requests.BeginLifetime();
            if (_subscribed) return;
            AudioEvents.SfxRequested += OnMMEvent;
            AudioEvents.UiRequested += OnMMEvent;
            AudioEvents.VoiceRequested += OnMMEvent;
            AudioEvents.MusicRequested += OnMMEvent;
            AudioEvents.StopRequested += OnMMEvent;
            AudioEvents.TrackOnRequested += OnMMEvent;
            AudioEvents.TrackVolumeRequested += OnMMEvent;
            SceneManager.activeSceneChanged += OnSceneChanged;
            _subscribed = true;
        }
        protected virtual void OnDisable()
        {
            if (_subscribed)
            {
                AudioEvents.SfxRequested -= OnMMEvent;
                AudioEvents.UiRequested -= OnMMEvent;
                AudioEvents.VoiceRequested -= OnMMEvent;
                AudioEvents.MusicRequested -= OnMMEvent;
                AudioEvents.StopRequested -= OnMMEvent;
                AudioEvents.TrackOnRequested -= OnMMEvent;
                AudioEvents.TrackVolumeRequested -= OnMMEvent;
                SceneManager.activeSceneChanged -= OnSceneChanged;
                _subscribed = false;
            }
            if (!_initialized) return;
            _requests.EndLifetime();
            StopAll();
        }
        private void OnSceneChanged(Scene previous, Scene next) { if (stopOnSceneChange) StopAll(); }
        protected virtual void OnApplicationPause(bool paused) => _applicationPaused = paused;
        protected virtual void OnApplicationQuit() => applicationIsQuitting = true;
        protected virtual void OnDestroy()
        {
            if (_initialized)
            {
                OnDisable();
                _destroyed = true;
                Clips.Dispose();
                _pool.Dispose();
                _requests.Dispose();
                _music.Dispose();
            }
            if (_instance == this) _instance = null;
        }
        private void Update()
        {
            if (!_initialized || _applicationPaused) return;
            _pool.EndFinished();
        }

        public void SetProvider(ProviderKind kind)
        {
            var next = AudioClipProviders.Create(kind);
            SetProvider(next, true);
            providerKind = kind;
        }
        /// <summary>Injected legacy providers retain their own clip ownership; lease providers transfer one lease per playback.</summary>
        public void SetProvider(IAudioClipProvider provider, bool takeOwnership = false) => Clips.SetProvider(provider, takeOwnership);

        // ===== Playback =====
        public Task<AudioSource> PlayAsync(string key, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null)
            => PlayAsync(key, CancellationToken.None, track, volume, pitch, loop, debounce, overrideGroup);
        public Task<AudioSource> PlayAsync<TEnum>(TEnum soundType, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null) where TEnum : struct, Enum
            => PlayAsync(AudioKeys.Get(soundType), track, volume, pitch, loop, debounce, overrideGroup);
        public async Task<AudioSource> PlayAsync(string key, CancellationToken cancellationToken, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null)
        {
            EnsureInitialized();
            return await _requests.PlayAsync(key, cancellationToken, track, volume, pitch, loop, debounce ?? defaultDebounceSeconds, overrideGroup);
        }
        public AudioSource Play(AudioClip clip, AudioTrack track = AudioTrack.Sfx,
            float volume = 1f, float pitch = 1f, bool loop = false, float? debounce = null, AudioMixerGroup overrideGroup = null)
        {
            EnsureInitialized();
            return _requests.Play(clip, track, volume, pitch, loop, debounce ?? defaultDebounceSeconds, overrideGroup);
        }
        public void Stop(AudioSource src) => _pool?.End(src);
        public IEnumerator CrossfadeMusic(AudioSource from, string toKey, float duration, float targetVolume = 1f)
        {
            EnsureInitialized();
            AudioPlayback previous = null;
            if (from) _pool.TryGet(from, out previous);
            var task = _music.RequestAsync(null, toKey, targetVolume, 1f, duration, previous, false);
            while (!task.IsCompleted) yield return null;
            if (task.IsFaulted) { Debug.LogException(task.Exception.GetBaseException()); yield break; }
            if (task.IsCanceled) yield break;
            while (_music.IsFadingTo(task.Result)) yield return null;
        }
        public void StopAllOnTrack(AudioTrack track)
        {
            AudioTrackMixer.ValidateTrack(track);
            if (!_initialized) return;
            _requests.CancelTrack(track);
            if (track == AudioTrack.Music) _music.Reset();
            _pool.EndTrack(track);
        }
        public void StopAll()
        {
            if (!_initialized) return;
            _requests.CancelAll();
            _music.Reset();
            _pool.EndAll();
        }
        public AudioSource GetFirstOnTrack(AudioTrack track) => _pool?.FirstOnTrack(track);

        // ==== Track state (public, editor buttons friendly) ====
        public void SetTrackOn(AudioTrack track, bool on)
        {
            Tracks.SetOn(track, on);
            RefreshOutputs(track);
            Tracks.PushChange();
        }
        public bool IsTrackOn(AudioTrack track) => Tracks.IsOn(track);

        public void SetTrackVolume(AudioTrack track, float volume01)
        {
            Tracks.SetVolume(track, volume01);
            RefreshOutputs(track);
            Tracks.PushChange();
        }
        public float GetTrackVolume(AudioTrack track) => Tracks.Volume(track);
        private void RefreshOutputs(AudioTrack track) => _pool?.ForEachAffectedBy(track, Tracks.ApplyOutput);

        // MM-like helpers for editor buttons
        public void MuteTrack(AudioTrack track) => SetTrackOn(track, false);
        public void UnmuteTrack(AudioTrack track) => SetTrackOn(track, true);
        public void PauseTrack(AudioTrack track) => _pool?.SetPaused(track, true);
        public void PlayTrack(AudioTrack track) => _pool?.SetPaused(track, false);
        public void StopTrack(AudioTrack track) => StopAllOnTrack(track);
        public void FreeTrack(AudioTrack track) => StopAllOnTrack(track);

        // Runtime Save/Load helpers (for editor buttons)
        public void SaveMixerToPrefs() => Tracks.Save();
        public void LoadMixerFromPrefs() { if (Tracks.Load()) RefreshOutputs(AudioTrack.Master); }
        public void ResetMixerPrefs() => Tracks.ResetPrefs();

        /// <summary>Replaces the current music, like the PlayMusic event. A later music request cancels this one.</summary>
        public Task<AudioSource> PlayMusicAsync(string key, float volume = 1f, float pitch = 1f, float crossfadeSeconds = 0f)
            => RequestMusicAsync(null, key, volume, pitch, crossfadeSeconds);
        public Task<AudioSource> PlayMusicAsync(AudioClip clip, float volume = 1f, float pitch = 1f, float crossfadeSeconds = 0f)
            => RequestMusicAsync(clip, null, volume, pitch, crossfadeSeconds);
        public Task<AudioSource> PlayMusicAsync<TEnum>(TEnum soundType, float volume = 1f, float pitch = 1f, float crossfadeSeconds = 0f) where TEnum : struct, Enum
            => RequestMusicAsync(null, AudioKeys.Get(soundType), volume, pitch, crossfadeSeconds);
        private async Task<AudioSource> RequestMusicAsync(AudioClip clip, string key, float volume, float pitch, float crossfadeSeconds)
        {
            EnsureInitialized();
            var playback = await _music.RequestAsync(clip, key, volume, pitch, crossfadeSeconds, null, true);
            return playback?.Source;
        }

        private async void HandlePlay(AudioClip clip, string key, Enum soundType, AudioTrack track, float volume, float pitch, bool loop)
        {
            try
            {
                if (clip) Play(clip, track, volume, pitch, loop);
                else
                {
                    if (string.IsNullOrEmpty(key) && soundType != null) key = AudioKeys.Get(soundType);
                    if (!string.IsNullOrEmpty(key)) await PlayAsync(key, track, volume, pitch, loop);
                }
            }
            catch (Exception exception) { Debug.LogException(exception); }
        }
        // Retain these public handler names for direct callers; subscriptions use the owned AudioEvents bus.
        public void OnMMEvent(AudioEvents.PlaySfx e) => HandlePlay(e.clip, e.key, e.soundType, AudioTrack.Sfx, e.volume, e.pitch, e.loop);
        public void OnMMEvent(AudioEvents.PlayUI e) => HandlePlay(e.clip, e.key, e.soundType, AudioTrack.UI, e.volume, e.pitch, e.loop);
        public void OnMMEvent(AudioEvents.PlayVoice e) => HandlePlay(e.clip, e.key, e.soundType, AudioTrack.Voice, e.volume, e.pitch, e.loop);
        public async void OnMMEvent(AudioEvents.PlayMusic e)
        {
            try
            {
                EnsureInitialized();
                string key = e.key;
                if (string.IsNullOrEmpty(key) && e.soundType != null) key = AudioKeys.Get(e.soundType);
                await _music.RequestAsync(e.clip, key, e.volume, e.pitch, e.crossfadeSeconds, null, true);
            }
            catch (Exception exception) { Debug.LogException(exception); }
        }
        public void OnMMEvent(AudioEvents.StopAllOnTrack e) => StopAllOnTrack(e.track);
        public void OnMMEvent(AudioEvents.SetTrackOn e) => SetTrackOn(e.track, e.on);
        public void OnMMEvent(AudioEvents.SetTrackVolume e) => SetTrackVolume(e.track, e.volume01);
    }
}
