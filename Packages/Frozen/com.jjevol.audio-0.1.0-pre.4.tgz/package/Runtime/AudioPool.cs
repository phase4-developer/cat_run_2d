using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Audio
{
    public class AudioPool : IDisposable
    {
        private readonly Transform _root;
        private readonly List<AudioSource> _pool;
        private readonly bool _canExpand;
        private readonly List<AudioSource> _active = new(64);
        private readonly Dictionary<AudioSource, AudioPlayback> _playbacks = new(64);
        public AudioPool(Transform root, int initialSize, bool canExpand)
        {
            _root = root;
            _pool = new List<AudioSource>(Mathf.Max(1, initialSize));
            _canExpand = canExpand;
        }
        public void WarmUp(int count)
        {
            for (int i = 0; i < count; i++) CreateOne();
        }
        private AudioSource CreateOne()
        {
            var go = new GameObject("AudioSourcePooled");
            go.transform.SetParent(_root, false);
            var src = go.AddComponent<AudioSource>();
            src.playOnAwake = false;
            go.SetActive(false);
            _pool.Add(src);
            return src;
        }
        public AudioSource Get()
        {
            _pool.RemoveAll(source => !source);
            foreach (var source in _pool)
                if (!source.gameObject.activeSelf) { source.gameObject.SetActive(true); return source; }
            if (_canExpand || _pool.Count == 0)
            {
                var source = CreateOne();
                source.gameObject.SetActive(true);
                return source;
            }
            // Preserve the original non-expanding pool's first-source stealing policy.
            return _pool[0];
        }
        public void Release(AudioSource src)
        {
            if (!src || !_pool.Contains(src)) return;
            src.Stop();
            src.clip = null;
            src.outputAudioMixerGroup = null;
            src.gameObject.SetActive(false);
        }
        public void Dispose()
        {
            foreach (var source in _pool)
                if (source)
                {
                    source.Stop();
                    source.clip = null;
                    if (Application.isPlaying) UnityEngine.Object.Destroy(source.gameObject);
                    else UnityEngine.Object.DestroyImmediate(source.gameObject);
                }
            _pool.Clear();
        }

        internal int ActiveCount => _active.Count;
        internal IEnumerable<AudioPlayback> Playbacks => _playbacks.Values;
        internal bool TryGet(AudioSource source, out AudioPlayback playback) => _playbacks.TryGetValue(source, out playback);
        internal bool IsLive(AudioPlayback playback) => playback != null && playback.Source
            && _playbacks.TryGetValue(playback.Source, out var current) && ReferenceEquals(current, playback);

        internal AudioSource Rent(AudioClip clip, bool loop, float pitch)
        {
            var source = Get();
            // A non-expanding pool deliberately steals its first source. Finish its old ownership first.
            End(source);
            source.gameObject.SetActive(true);
            source.clip = clip;
            source.loop = loop;
            source.pitch = pitch;
            source.spatialBlend = 0f;
            source.panStereo = 0f;
            source.playOnAwake = false;
            return source;
        }
        internal void Begin(AudioPlayback playback, AudioClipLease lease)
        {
            playback.Lease = lease;
            _playbacks[playback.Source] = playback;
            _active.Add(playback.Source);
        }
        /// <summary>Returns the source, then its lease. An AudioSource with no playback is ignored, so ending twice is harmless.</summary>
        internal void End(AudioSource source)
        {
            if (ReferenceEquals(source, null) || !_playbacks.TryGetValue(source, out var playback)) return;
            _playbacks.Remove(source);
            _active.Remove(source);
            if (source) Release(source);
            playback.Lease?.Dispose();
        }
        internal void EndTrack(AudioTrack track)
        {
            for (int i = _active.Count - 1; i >= 0; i--)
            {
                var source = _active[i];
                if (_playbacks.TryGetValue(source, out var playback) && playback.Track == track) End(source);
            }
        }
        internal void EndAll()
        {
            for (int i = _active.Count - 1; i >= 0; i--) End(_active[i]);
        }
        internal void EndFinished()
        {
            for (int i = _active.Count - 1; i >= 0; i--)
            {
                var source = _active[i];
                var playback = _playbacks[source];
                if (!source) { End(source); continue; }
                if (playback.Paused || (AudioListener.pause && !source.ignoreListenerPause)) continue;
                // Use actual playback completion, including current pitch. No old duration coroutine survives reuse.
                if (Time.frameCount > playback.StartedFrame && !source.isPlaying) End(source);
            }
        }
        internal void SetPaused(AudioTrack track, bool paused)
        {
            foreach (var source in _active)
            {
                if (!source || TrackOf(source) != track) continue;
                _playbacks[source].Paused = paused;
                if (paused) source.Pause();
                else source.UnPause();
            }
        }
        internal AudioSource FirstOnTrack(AudioTrack track)
        {
            foreach (var source in _active)
                if (source != null && TrackOf(source) == track) return source;
            return null;
        }
        internal IEnumerable<AudioPlayback> OnTrack(AudioTrack track)
        {
            foreach (var source in _active)
                if (_playbacks.TryGetValue(source, out var playback) && playback.Track == track) yield return playback;
        }
        /// <summary>Visits the playbacks a change of this track reaches: its own, or all of them for Master.</summary>
        internal void ForEachAffectedBy(AudioTrack track, Action<AudioPlayback> action)
        {
            for (int i = _active.Count - 1; i >= 0; --i)
            {
                var source = _active[i];
                if (!source) { End(source); continue; }
                if (!_playbacks.TryGetValue(source, out var playback)) continue;
                if (playback.Track != track && track != AudioTrack.Master) continue;
                action(playback);
            }
        }
        private AudioTrack TrackOf(AudioSource source) => _playbacks.TryGetValue(source, out var playback) ? playback.Track : AudioTrack.Sfx;
    }
}
