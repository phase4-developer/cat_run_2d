using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Audio;

namespace jjevol.Audio
{
    /// <summary>
    /// Carries a play request through debounce and clip resolution to a started source, and owns the cancellation scopes of
    /// requests still loading. Hosts the music channel, whose starts are requests that skip debounce.
    /// </summary>
    internal sealed class AudioPlaybackRequests : IAudioMusicHost, IDisposable
    {
        private readonly AudioPool _pool;
        private readonly AudioTrackMixer _tracks;
        private readonly AudioClipResolver _clips;
        private readonly AudioDebouncer _debouncer;
        private readonly Func<bool> _canPlay;
        private readonly Func<IEnumerator, Coroutine> _startCoroutine;
        private readonly CancellationTokenSource[] _trackRequests = new CancellationTokenSource[5];
        private CancellationTokenSource _lifetime = new(), _allRequests = new();

        internal AudioPlaybackRequests(AudioPool pool, AudioTrackMixer tracks, AudioClipResolver clips, AudioDebouncer debouncer,
            Func<bool> canPlay, Func<IEnumerator, Coroutine> startCoroutine)
        {
            _pool = pool;
            _tracks = tracks;
            _clips = clips;
            _debouncer = debouncer;
            _canPlay = canPlay;
            _startCoroutine = startCoroutine;
            for (int i = 0; i < _trackRequests.Length; i++) _trackRequests[i] = new CancellationTokenSource();
        }

        internal AudioSource Play(AudioClip clip, AudioTrack track, float volume, float pitch, bool loop, float minGap, AudioMixerGroup overrideGroup)
        {
            if (!_canPlay() || !clip) return null;
            return Start(new AudioClipLease(clip), track, volume, pitch, loop, minGap, overrideGroup);
        }

        internal async Task<AudioSource> PlayAsync(string key, CancellationToken cancellationToken, AudioTrack track,
            float volume, float pitch, bool loop, float minGap, AudioMixerGroup overrideGroup,
            Action<AudioPlayback> onStarted = null, CancellationToken superseded = default, float fade = 1f)
        {
            AudioTrackMixer.ValidateTrack(track);
            cancellationToken.ThrowIfCancellationRequested();
            if (!_canPlay() || string.IsNullOrWhiteSpace(key)) return null;
            if (!_debouncer.PassesKey(key, minGap)) return null;
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, _lifetime.Token,
                _allRequests.Token, _clips.ProviderChanged, _trackRequests[(int)track].Token, superseded);
            AudioClipLease lease = null;
            try
            {
                lease = await _clips.AcquireAsync(key, track, linked.Token);
                if (!_canPlay() || linked.IsCancellationRequested)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return null;
                }
                var ownedLease = lease; lease = null;
                var result = Start(ownedLease, track, volume, pitch, loop, minGap, overrideGroup, fade);
                if (result && _pool.TryGet(result, out var playback)) onStarted?.Invoke(playback);
                return result;
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested) { return null; }
            finally { lease?.Dispose(); }
        }

        private AudioSource Start(AudioClipLease lease, AudioTrack track, float volume, float pitch, bool loop, float minGap,
            AudioMixerGroup overrideGroup, float fade = 1f)
        {
            AudioSource source = null;
            try
            {
                AudioTrackMixer.ValidateTrack(track);
                if (lease == null || !lease.Clip || !_debouncer.PassesClip(lease.Clip, minGap)) { lease?.Dispose(); return null; }
                if (!float.IsFinite(volume) || !float.IsFinite(pitch)) throw new ArgumentOutOfRangeException(nameof(volume));
                source = _pool.Rent(lease.Clip, loop, pitch);
                var playback = new AudioPlayback
                {
                    Source = source,
                    Track = track,
                    OverrideGroup = overrideGroup,
                    BaseVolume = volume,
                    Fade = fade,
                    StartedFrame = Time.frameCount
                };
                _tracks.Route(playback);
                _pool.Begin(playback, lease);
                source.Play();
                return source;
            }
            catch
            {
                if (source) _pool.End(source);
                lease?.Dispose();
                throw;
            }
        }

        internal void CancelAll() => CancelAndRenew(ref _allRequests);
        internal void CancelTrack(AudioTrack track) => CancelAndRenew(ref _trackRequests[(int)track]);
        internal void EndLifetime() => _lifetime.Cancel();
        internal void BeginLifetime()
        {
            if (!_lifetime.IsCancellationRequested) return;
            _lifetime.Dispose();
            _lifetime = new CancellationTokenSource();
        }
        private static void CancelAndRenew(ref CancellationTokenSource source)
        {
            source.Cancel(); source.Dispose(); source = new CancellationTokenSource();
        }

        public void Dispose()
        {
            _lifetime.Dispose(); _allRequests.Dispose();
            foreach (var request in _trackRequests) request.Dispose();
        }

        public bool IsLive(AudioPlayback playback) => _pool.IsLive(playback);
        public void StopPlayback(AudioPlayback playback) { if (_pool.IsLive(playback)) _pool.End(playback.Source); }
        public void ApplyOutput(AudioPlayback playback) => _tracks.ApplyOutput(playback);
        public IEnumerable<AudioPlayback> ActiveMusic() => _pool.OnTrack(AudioTrack.Music);
        // Music debounces by replacing: a rejected repeat of A after A, B would otherwise leave nothing playing.
        public AudioPlayback StartMusicClip(AudioClip clip, float volume, float pitch, float fade)
        {
            if (!_canPlay() || !clip) return null;
            var source = Start(new AudioClipLease(clip), AudioTrack.Music, volume, pitch, true, 0f, null, fade);
            return source && _pool.TryGet(source, out var playback) ? playback : null;
        }
        public Task<AudioSource> StartMusicAsync(string key, float volume, float pitch, float fade, CancellationToken superseded, Action<AudioPlayback> onStarted)
            => PlayAsync(key, CancellationToken.None, AudioTrack.Music, volume, pitch, true, 0f, null, onStarted, superseded, fade);
        public void StartFade(IEnumerator routine) => _startCoroutine(routine);
    }
}
