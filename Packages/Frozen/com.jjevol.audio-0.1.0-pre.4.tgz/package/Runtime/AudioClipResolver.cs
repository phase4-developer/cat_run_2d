using System;
using System.Threading;
using System.Threading.Tasks;

namespace jjevol.Audio
{
    /// <summary>Turns a key into one AudioClipLease and owns the provider. A library clip wins, then its provider key, then the key itself.</summary>
    internal sealed class AudioClipResolver : IDisposable
    {
        private readonly Func<AudioLibrary> _library;
        private CancellationTokenSource _providerRequests = new();
        private bool _ownsProvider;

        internal AudioClipResolver(Func<AudioLibrary> library) => _library = library;

        internal IAudioClipProvider Provider { get; private set; }
        /// <summary>Cancelled when the provider changes. Leases already handed out stay valid.</summary>
        internal CancellationToken ProviderChanged => _providerRequests.Token;

        internal void SetProvider(IAudioClipProvider provider, bool takeOwnership)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            if (ReferenceEquals(Provider, provider)) return;
            _providerRequests.Cancel();
            _providerRequests.Dispose();
            _providerRequests = new CancellationTokenSource();
            var previous = Provider; bool disposePrevious = _ownsProvider;
            Provider = provider; _ownsProvider = takeOwnership;
            if (disposePrevious && previous is IDisposable disposable) disposable.Dispose();
        }

        internal async Task<AudioClipLease> AcquireAsync(string key, AudioTrack track, CancellationToken cancellationToken)
        {
            var provider = Provider;
            var library = _library();
            if (library && library.TryGet(key, out var entry) && entry.clip) return new AudioClipLease(entry.clip);
            string loadKey = library && library.TryGet(key, out entry) && !string.IsNullOrEmpty(entry.providerKey) ? entry.providerKey : key;
            if (provider is IAudioClipLeaseProvider leaseProvider) return await leaseProvider.AcquireAsync(track, loadKey, cancellationToken);
            return new AudioClipLease(await provider.LoadClipAsync(track, loadKey));
        }

        public void Dispose()
        {
            if (_ownsProvider && Provider is IDisposable disposable) disposable.Dispose();
            _providerRequests.Dispose();
        }
    }
}
