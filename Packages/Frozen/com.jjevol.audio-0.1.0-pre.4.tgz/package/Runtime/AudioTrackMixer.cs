using System;

namespace jjevol.Audio
{
    /// <summary>
    /// Owns track volume and On state, and sends copies of it to the mixer, to PlayerPrefs and to each playback's AudioSource.
    /// Settings are read per call, because AudioManager.mixerSettings can change at runtime.
    /// </summary>
    internal sealed class AudioTrackMixer
    {
        private readonly AudioTrackState _state;
        private readonly Func<AudioMixerSettingsSO> _settings;

        internal AudioTrackMixer(AudioTrackState state, Func<AudioMixerSettingsSO> settings)
        {
            _state = state;
            _settings = settings;
        }

        internal static void ValidateTrack(AudioTrack track)
        {
            if (!Enum.IsDefined(typeof(AudioTrack), track)) throw new ArgumentOutOfRangeException(nameof(track));
        }

        internal bool IsOn(AudioTrack track) => _state.IsOn(track);
        internal float Volume(AudioTrack track) => _state.Volume(track);
        internal void SetOn(AudioTrack track, bool on) => _state.SetOn(track, on);
        internal void SetVolume(AudioTrack track, float volume01) => _state.SetVolume(track, volume01);
        internal void SetDefaults(float master, float music, float sfx, float ui, float voice) => _state.SetDefaults(master, music, sfx, ui, voice);

        internal void LoadOnStartup()
        {
            var settings = _settings();
            if (settings && settings.autoLoadOnStart)
            {
                if (settings.LoadFromPrefs(out var saved)) _state.Apply(saved);
                else Save();
            }
            ApplyToMixer();
        }
        internal void ApplyToMixer()
        {
            var settings = _settings();
            if (settings) settings.Apply(_state.ToSnapshot());
        }
        /// <summary>A change made through the public API: reaches the mixer, and PlayerPrefs when autoSaveOnChange is set.</summary>
        internal void PushChange()
        {
            var settings = _settings();
            if (!settings) return;
            var snapshot = _state.ToSnapshot();
            settings.Apply(snapshot);
            if (settings.autoSaveOnChange) settings.SaveToPrefs(snapshot);
        }
        internal void Save()
        {
            var settings = _settings();
            if (settings) settings.SaveToPrefs(_state.ToSnapshot());
        }
        internal bool Load()
        {
            var settings = _settings();
            if (!settings || !settings.LoadFromPrefs(out var saved)) return false;
            _state.Apply(saved);
            ApplyToMixer();
            return true;
        }
        internal void ResetPrefs() => _settings()?.ResetPrefs();

        /// <summary>Routes a new playback: its source's mixer group, the factors the mixer carries, then its source's output.</summary>
        internal void Route(AudioPlayback playback)
        {
            playback.Source.outputAudioMixerGroup = AudioMixerOutput.ChooseGroup(_settings(), playback.Track, playback.OverrideGroup);
            Reroute(playback);
            ApplyOutput(playback);
        }
        internal void Reroute(AudioPlayback playback) => playback.Route = AudioMixerOutput.Resolve(_settings(), playback.Track, playback.OverrideGroup);
        internal void ApplyOutput(AudioPlayback playback)
        {
            playback.Source.mute = !_state.EffectiveOn(playback.Track);
            playback.Source.volume = playback.BaseVolume * playback.Fade * _state.SourceGain(playback.Track, playback.Route);
        }
    }
}
