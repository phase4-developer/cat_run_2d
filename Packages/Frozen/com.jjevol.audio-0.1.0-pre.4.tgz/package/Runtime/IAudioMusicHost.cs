using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace jjevol.Audio
{
    /// <summary>What the music channel needs from playback. Playbacks are compared as objects, because sources are reused.</summary>
    internal interface IAudioMusicHost
    {
        bool IsLive(AudioPlayback playback);
        void StopPlayback(AudioPlayback playback);
        void ApplyOutput(AudioPlayback playback);
        IEnumerable<AudioPlayback> ActiveMusic();
        AudioPlayback StartMusicClip(AudioClip clip, float volume, float pitch, float fade);
        Task<AudioSource> StartMusicAsync(string key, float volume, float pitch, float fade, CancellationToken superseded, Action<AudioPlayback> onStarted);
        void StartFade(IEnumerator routine);
    }
}
