using UnityEngine;
using UnityEngine.Audio;

namespace jjevol.Audio
{
    /// <summary>One started playback. A pooled AudioSource is reused, so this object, not the source, is the playback's identity.</summary>
    internal sealed class AudioPlayback
    {
        internal AudioSource Source;
        internal AudioTrack Track;
        internal AudioMixerGroup OverrideGroup;
        internal AudioRoute Route;
        internal float BaseVolume, Fade = 1, FadeStart = 1;
        internal bool Paused;
        internal int StartedFrame;
        internal AudioClipLease Lease;
    }
}
