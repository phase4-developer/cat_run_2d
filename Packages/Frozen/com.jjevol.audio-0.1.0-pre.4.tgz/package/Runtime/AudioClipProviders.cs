using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace jjevol.Audio
{
    public enum ProviderKind { Resources, Addressables }

    public interface IAudioClipProvider
    {
        Task<AudioClip> LoadClipAsync(AudioTrack track, string key);
    }

    public class ResourcesClipProvider : IAudioClipLeaseProvider
    {
        public Task<AudioClip> LoadClipAsync(AudioTrack track, string key)
        {
            string folder = track switch
            {
                AudioTrack.Music => "Music",
                AudioTrack.Sfx => "Sfx",
                AudioTrack.UI => "Sfx",
                AudioTrack.Voice => "Voice",
                _ => ""
            };
            string path = string.IsNullOrEmpty(folder) ? key : $"{folder}/{key}";
            return Task.FromResult(Resources.Load<AudioClip>(path));
        }
        public async Task<AudioClipLease> AcquireAsync(AudioTrack track, string key, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var clip = await LoadClipAsync(track, key);
            cancellationToken.ThrowIfCancellationRequested();
            // Resources and caller-owned clips are borrowed. Never unload a possibly shared Unity asset here.
            return clip ? new AudioClipLease(clip) : null;
        }
    }

    /// <summary>Optional packages register their own factory without making Core depend on their SDK.</summary>
    public static class AudioClipProviders
    {
        private static readonly Dictionary<ProviderKind, Func<IAudioClipProvider>> Factories = new();
        public static void Register(ProviderKind kind, Func<IAudioClipProvider> factory)
        {
            if (factory == null) throw new ArgumentNullException(nameof(factory));
            Factories[kind] = factory;
        }
        public static IAudioClipProvider Create(ProviderKind kind)
        {
            if (Factories.TryGetValue(kind, out var factory))
                return factory() ?? throw new InvalidOperationException("The audio provider factory returned null.");
            if (kind == ProviderKind.Resources) return new ResourcesClipProvider();
            throw new InvalidOperationException($"Audio provider {kind} is not installed. Install/register its optional integration.");
        }
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void Reset() => Factories.Clear();
    }
}
