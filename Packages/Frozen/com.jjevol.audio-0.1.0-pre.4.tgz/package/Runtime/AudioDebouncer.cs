using System;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;
#if UNITY_6000_7_OR_NEWER
using ObjectId = UnityEngine.EntityId; // 6.7 makes Object.GetInstanceID a compile error; 6000.3 has no GetEntityId.
#else
using ObjectId = System.Int32;
#endif

namespace jjevol.Audio
{
    /// <summary>Rejects a repeat inside its gap. A rejected repeat does not restart the gap; a gap of 0 or less records nothing.</summary>
    internal sealed class AudioDebouncer
    {
        private readonly Func<float> _now;
        private readonly Dictionary<ObjectId, float> _lastPlayById = new(128);
        private readonly Dictionary<string, float> _lastPlayByKey = new(StringComparer.Ordinal);

        internal AudioDebouncer(Func<float> now) => _now = now;

#if UNITY_6000_7_OR_NEWER
        private static ObjectId IdOf(Object value) => value.GetEntityId();
#else
        private static ObjectId IdOf(Object value) => value.GetInstanceID();
#endif

        internal bool PassesClip(AudioClip clip, float minGap) => minGap <= 0f || Passes(_lastPlayById, IdOf(clip), minGap);
        internal bool PassesKey(string key, float minGap) => minGap <= 0f || Passes(_lastPlayByKey, key, minGap);

        private bool Passes<TId>(Dictionary<TId, float> lastPlay, TId id, float minGap)
        {
            float now = _now();
            if (lastPlay.TryGetValue(id, out var last) && last + minGap > now) return false;
            lastPlay[id] = now;
            return true;
        }
    }
}
