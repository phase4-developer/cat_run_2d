using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Audio
{
    /// <summary>Games own their enums; the playback contract remains an explicit, stable string key.</summary>
    public static class AudioKeys
    {
        private static readonly Dictionary<Enum, string> Keys = new();
        public static void Register<TEnum>(TEnum value, string key) where TEnum : struct, Enum => Register((Enum)(object)value, key);
        public static void Register(Enum value, string key)
        {
            if (value == null) throw new ArgumentNullException(nameof(value));
            if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("A sound key is required.", nameof(key));
            if (Keys.TryGetValue(value, out var existing) && existing != key)
                throw new InvalidOperationException($"Audio enum {value.GetType().Name}.{value} is already mapped to {existing}.");
            Keys[value] = key;
        }
        public static string Get<TEnum>(TEnum value) where TEnum : struct, Enum => Get((Enum)(object)value);
        public static string Get(Enum value)
        {
            if (value == null) throw new ArgumentNullException(nameof(value));
            return Keys.TryGetValue(value, out var key) ? key
                : throw new KeyNotFoundException($"Register an audio key for {value.GetType().Name}.{value} before playing it.");
        }
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void Reset() => Keys.Clear();
    }
}
