using System;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace jjevol.Audio
{
    /// <summary>One playback's clip ownership. Dispose on Unity's main thread, after clearing the source.</summary>
    public sealed class AudioClipLease : IDisposable
    {
        private Action _release;
        public AudioClip Clip { get; }
        public AudioClipLease(AudioClip clip, Action release = null)
        {
            Clip = clip;
            _release = release;
        }
        public void Dispose() => Interlocked.Exchange(ref _release, null)?.Invoke();
    }

    /// <summary>Optional extension of the original provider API. Each successful acquisition is disposed once.</summary>
    public interface IAudioClipLeaseProvider : IAudioClipProvider
    {
        Task<AudioClipLease> AcquireAsync(AudioTrack track, string key, CancellationToken cancellationToken = default);
    }
}
