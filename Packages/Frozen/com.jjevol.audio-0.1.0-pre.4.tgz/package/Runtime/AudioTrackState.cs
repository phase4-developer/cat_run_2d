using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Audio
{
    /// <summary>
    /// The single source of truth for track volume and On state. The mixer, AudioSources and PlayerPrefs only receive
    /// copies of this state; nothing reads an output back into it.
    /// </summary>
    internal sealed class AudioTrackState
    {
        private const float LegacyMutedVolumeLimit = 0.00011f;
        private readonly Dictionary<AudioTrack, bool> _trackOn = new()
        {
            { AudioTrack.Master, true },
            { AudioTrack.Music,  true },
            { AudioTrack.Sfx,    true },
            { AudioTrack.UI,     true },
            { AudioTrack.Voice,  true },
        };
        private readonly Dictionary<AudioTrack, float> _trackVolume = new()
        {
            { AudioTrack.Master, 1f },
            { AudioTrack.Music,  1f },
            { AudioTrack.Sfx,    1f },
            { AudioTrack.UI,     1f },
            { AudioTrack.Voice,  1f },
        };

        internal bool IsOn(AudioTrack track) => _trackOn[track];
        internal float Volume(AudioTrack track) => _trackVolume[track];
        internal void SetOn(AudioTrack track, bool on) => _trackOn[track] = on;
        internal void SetVolume(AudioTrack track, float volume01) => _trackVolume[track] = Mathf.Clamp01(volume01);

        internal void SetDefaults(float master, float music, float sfx, float ui, float voice)
        {
            _trackVolume[AudioTrack.Master] = master;
            _trackVolume[AudioTrack.Music] = music;
            _trackVolume[AudioTrack.Sfx] = sfx;
            _trackVolume[AudioTrack.UI] = ui;
            _trackVolume[AudioTrack.Voice] = voice;
        }

        internal void Apply(AudioMixerSettingsSO.Snapshot s)
        {
            Set(AudioTrack.Master, s.master, s.masterOn);
            Set(AudioTrack.Music, s.music, s.musicOn);
            Set(AudioTrack.Sfx, s.sfx, s.sfxOn);
            Set(AudioTrack.UI, s.ui, s.uiOn);
            Set(AudioTrack.Voice, s.voice, s.voiceOn);
        }
        private void Set(AudioTrack track, float volume, bool on)
        {
            // Earlier builds saved an Off track as the mixer's silent value, which is not a volume the player chose. Zero is a choice.
            bool legacyMuted = !on && volume > 0f && volume < LegacyMutedVolumeLimit;
            if (!legacyMuted) SetVolume(track, volume);
            _trackOn[track] = on;
        }

        internal AudioMixerSettingsSO.Snapshot ToSnapshot() => new()
        {
            master = _trackVolume[AudioTrack.Master],
            masterOn = _trackOn[AudioTrack.Master],
            music = _trackVolume[AudioTrack.Music],
            musicOn = _trackOn[AudioTrack.Music],
            sfx = _trackVolume[AudioTrack.Sfx],
            sfxOn = _trackOn[AudioTrack.Sfx],
            ui = _trackVolume[AudioTrack.UI],
            uiOn = _trackOn[AudioTrack.UI],
            voice = _trackVolume[AudioTrack.Voice],
            voiceOn = _trackOn[AudioTrack.Voice],
        };

        internal bool EffectiveOn(AudioTrack track) => _trackOn[track] && _trackOn[AudioTrack.Master];

        /// <summary>The share of track and master volume the AudioSource must carry. Each factor is applied exactly once.</summary>
        internal float SourceGain(AudioTrack track, AudioRoute route)
        {
            float master = route.MasterViaMixer ? 1f : _trackVolume[AudioTrack.Master];
            if (track == AudioTrack.Master) return master;
            return (route.TrackViaMixer ? 1f : _trackVolume[track]) * master;
        }
    }
}
