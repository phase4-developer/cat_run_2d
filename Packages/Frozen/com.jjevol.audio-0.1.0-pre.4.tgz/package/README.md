# JJEvol Audio — local candidate

Unity 6000.3.9f1. This is a local source candidate, not a published release or frozen tarball. Mobile/Steam Hosts are not migrated.

The mobile AudioManager's tracks, public string/AudioClip playback calls, pool policy, mixer settings, track controls and event Trigger structure are retained. The 2026-10-30 user correction authorizes replacing the complex parent, removing SoundTable, and using an owned simple event implementation. No MoreMountains, CodeStage, PathologicalGames, game SoundType/content, Platform or Runner dependency is included.

## Use

Create/configure an AudioManager component or obtain AudioManager.Instance during Play Mode, before sending events.

~~~csharp
using jjevol.Audio;

var audio = AudioManager.Instance;
var source = await audio.PlayAsync("click", AudioTrack.UI);
audio.Stop(source);
AudioEvents.PlaySfx.Trigger(clip, volume: 0.8f);
AudioEvents.PlayMusic.Trigger("theme", crossfade: 0.5f);
AudioEvents.SetTrackVolume.Trigger(AudioTrack.Music, 0.6f);
~~~

The default Resources provider retains Music/{key}, Sfx/{key} (also UI), Voice/{key}, and {key} for Master. Keys are case-sensitive. AudioClip playback borrows the caller's clip.

Optional enum registration keeps game identifiers in the game:

~~~csharp
AudioKeys.Register(GameSound.Click, "click");
AudioEvents.PlayUI.Trigger(GameSound.Click);
await audio.PlayAsync(GameSound.Click, AudioTrack.UI);
~~~

Register after subsystem initialization and before playback. Enum names/ordinals are never guessed as addresses. Re-registering the same mapping is harmless; conflicting mappings fail explicitly.

An optional AudioLibrary ScriptableObject maps a stable string key to a directly referenced AudioClip or a providerKey override. Assign it to AudioManager.library. It is an authoring convenience, not a replacement table framework or an additional source of game identifiers.

## Lifetime and behavior

- Each managed playback owns one AudioClipLease. Finish, Stop, pool steal, disable and destroy clear the source before disposing its lease. Dispose is idempotent.
- Natural completion observes AudioSource.isPlaying; the old clip-duration coroutine was removed. Track Pause/Play and AudioListener.pause preserve ownership.
- Playback identity is an internal object per started playback, not the pooled AudioSource. A reused source is never modified/stopped by an older fade or load.
- Non-expanding pools retain the original first-source stealing policy. An empty pool now creates its first source instead of indexing an empty list.
- Clip debounce still applies across tracks; key debounce now uses the full string rather than its hash. Rejected loaded clips return their lease.
- StopAll cancels pending requests. Track Stop cancels that track's pending requests. Provider changes cancel pending requests while active leases remain valid.
- The original PlayAsync signature remains. The additive cancellation overload accepts CancellationToken as the second argument. Explicit caller cancellation cancels the Task; internal Stop/disable/provider cancellation returns null.
- A custom IAudioClipProvider using the original interface remains supported; that provider/caller owns its returned clip. Implement IAudioClipLeaseProvider to transfer explicit playback ownership.
- The manager persists across scenes by default, preserving music. stopOnSceneChange opt-in returns active clips and cancels pending loads on an active-scene change.
- Disabling the manager now stops playback and cancels pending loads. Destroy also disposes providers created/owned by the manager. Injected providers are borrowed unless takeOwnership is true.
- Resources clips and caller-owned clips are borrowed. No global Resources.UnloadUnusedAssets/forced unload is performed.

Use manager Stop/PauseTrack/PlayTrack for lifetime control. A returned raw pooled AudioSource is a reference to the current slot; external code must not retain it as an identity for a future playback after reuse.

## Track volume and mixer

AudioManager's track state is the single source of truth for volume and On. The mixer, AudioSources and PlayerPrefs receive copies; the manager never reads the mixer back. AudioMixerSettingsSO.Read remains public for direct callers only.

- Startup and LoadMixerFromPrefs write the saved snapshot straight into the state, so a track saved Off keeps its volume and gets it back when turned On. A volume of 0 stays On. This also holds for settings without a mixer: they save and restore state with nothing to output to.
- The state is sent to the mixer during initialization and again in Start, regardless of autoLoadOnStart, so the mixer always matches GetTrackVolume and IsTrackOn. autoLoadOnStart decides only whether saved values are read.
- SaveMixerToPrefs and autoSaveOnChange write the state. The PlayerPrefs key and JSON format are unchanged.
- Off sets the mixer parameter to -80 dB and AudioSource.mute on every path.

Each factor is applied exactly once, chosen per playback:

| Playback | Track volume | Master volume |
|---|---|---|
| No mixer, or settings without a mixer | AudioSource | AudioSource |
| Track's own group, both parameters exposed | Mixer | Mixer |
| Track's own group, track parameter not exposed | AudioSource | Mixer |
| Track's own group, master parameter not exposed | Mixer | AudioSource |
| No own group, falls back to another group of the mixer | AudioSource | Mixer |
| overrideGroup other than the track's own group, same mixer | AudioSource | Mixer |
| Group from a different mixer | AudioSource | AudioSource |

An overrideGroup placed under the track's own group also receives that track's mixer parameter, so its track volume applies twice. A Master-track playback applies master once. Whether a parameter is exposed is checked when playback starts and again in Start.

Unity cannot report where a parameter is exposed, so the manager relies on the settings asset: each track parameter belongs on that track's group and the master parameter on the mixer's root. Two limits follow. An overrideGroup inside the same mixer is still multiplied on the AudioSource, so any mixer parameter above that group attenuates it again; route such sources to the track's own group, or keep override groups outside the track groups' hierarchy. A UI playback falling back to sfxGroup also passes through the Sfx parameter, because it really is in that group.

## Music

PlayMusic events, AudioEventPlayer and CrossfadeMusic share one channel that tracks the current music, exposed as AudioManager.CurrentMusic.

- The latest request wins. It cancels any request still loading; a late load returns its lease without playing.
- The running music keeps playing until the replacement starts. A request whose load fails, or an empty request, leaves it untouched.
- Without a crossfade the replaced music stops when the new one starts. With a crossfade everything being replaced fades out from its current level, including earlier fade targets, and only the final music remains.
- If the fade target is stopped from outside, the music it was replacing returns to full volume and stays current.
- Requesting the same key or clip again restarts it. Channel requests skip debounce, because a rejected repeat could otherwise leave nothing playing after the request before it was cancelled.
- PlayMusic events and AudioEventPlayer also replace Music-track sources started directly. CrossfadeMusic replaces the tracked music and its from argument only.

Play and PlayAsync with AudioTrack.Music remain direct calls: they are additive, are not tracked as CurrentMusic and do not cancel channel requests. Use PlayMusicAsync or the PlayMusic event for one-at-a-time music.

## Structure

AudioManager holds the serialized fields and Unity callbacks, builds the modules below with plain constructors and forwards the public API. No container is involved. AudioPool is public, the other modules are internal, and each receives its collaborators through its constructor. Unity statics such as Time.frameCount are still read directly.

| Module | Owns |
|---|---|
| AudioClipResolver | Library lookup, the provider and whether it is owned, one lease per request, the provider-change cancellation scope |
| AudioPool | Pooled sources, the playback on each source, finishing a playback and returning its lease |
| AudioTrackMixer | Track volume and On state, their copies in the mixer and PlayerPrefs, each playback's route and output |
| AudioDebouncer | Clip and key repeat decisions |
| AudioPlaybackRequests | The path from a request to a started source, and the lifetime, all and per-track cancellation scopes |
| AudioMusicChannel | The current music and its supersede scope, reached through IAudioMusicHost |

Library and mixer settings are read per call, because AudioManager.library and AudioManager.mixerSettings can change at runtime.

Code that plays audio can receive the public IAudioPlayer instead of reading AudioManager.Instance. It covers Play, PlayAsync, Stop, StopAllOnTrack, StopAll, CurrentMusic, CrossfadeMusic and track volume and On. Provider setup, persistence, diagnostics, editor-button helpers and event handlers stay on AudioManager.

## Explicit compatibility changes

AudioManager keeps its class/namespace, original serialized fields, Instance/HasInstance/IsDestroyed/applicationIsQuitting access and main public playback/mixer methods. Its parent is now MonoBehaviour; inherited generic-parent internals and MMEventListener interfaces are not retained.

SoundTable and AudioManager.Table are deliberately removed. No game-specific SoundType is shipped. Event enum fields now use System.Enum with explicit AudioKeys mapping; string/clip constructors and Trigger calls remain. OnMMEvent method names remain for direct callers, but subscriptions use owned events.

AudioEventPlayer keeps its original script GUID and existing auto-play/track fields. The old serialized soundType integer is retained, hidden, for explicit migration; it is not automatically interpreted as a key. Assign key or call SetSoundType with a registered enum. The obsolete SoundType property returns that legacy integer. Existing game prefabs must be reviewed before migration.

AudioMixerSettingsSO and AudioManagerEditor keep the mobile originals' code; only the original-path comment on their first line was removed. Original transferred script/folder metas remain unchanged. Do not install beside legacy source classes/GUIDs without a separate migration.

Values saved by earlier builds load as stored, with one exception. Those builds could overwrite an Off track's volume with the mixer's silent value (0.0001). An Off track saved with a volume above 0 and below 0.00011 keeps the current volume instead, so turning the track On is audible again. A saved 0 is the player's choice and loads as 0.

## Optional Addressables

Install com.jjevol.audio.addressables separately to enable ProviderKind.Addressables. Core has no Addressables assembly/package dependency. Selecting an unregistered provider fails explicitly instead of silently using Resources.

Enable package testables for isolated Tests/Editor and Tests/Runtime assemblies. Resources integration tests expect the generated WAV fixtures in the dedicated validation Host. AudioMixerRouteTests (category RequiresMixerAsset) expect Resources/jjevol-audio-test-mixer-settings, an AudioMixerSettingsSO with every group assigned and the default parameter names exposed on one mixer; without it they report Ignored. The repository `Docs/Guide/Verification.md` separates automated source/lifecycle tests from listening, Player, device and content-build validation.

## Menus

Framework menus are grouped by feature: Editor tools under `JJEvol/<feature>/`, asset menus under `Assets/Create/JJEvol/<feature>/`, and UI objects under `GameObject/UI/JJEvol/`.

- `Assets/Create/JJEvol/Audio/Audio Library` — `AudioLibrary`
- `Assets/Create/JJEvol/Audio/Audio Mixer Settings` — `AudioMixerSettingsSO`
- `Add Component > JJEvol/Audio/Audio Event Player` — `AudioEventPlayer`
