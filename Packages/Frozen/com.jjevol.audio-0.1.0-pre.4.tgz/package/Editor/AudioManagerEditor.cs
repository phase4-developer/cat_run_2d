#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace jjevol.Audio.EditorTools
{
    [CustomEditor(typeof(AudioManager))]
    [CanEditMultipleObjects]
    public class AudioManagerEditor : Editor
    {
        private AudioManager _mgr;

        private static readonly Color cMaster = new Color(1.00f, 0.89f, 0.29f);
        private static readonly Color cMusic = new Color(0.50f, 1.00f, 0.83f);
        private static readonly Color cSfx = new Color(1.00f, 0.61f, 0.48f);
        private static readonly Color cUI = new Color(0.27f, 0.51f, 0.71f);
        private static readonly Color cVoice = new Color(0.75f, 0.63f, 1.00f);

        public override bool RequiresConstantRepaint() => Application.isPlaying;

        public override void OnInspectorGUI()
        {
            _mgr = target as AudioManager;

            serializedObject.Update();
            DrawDefaultInspector();
            serializedObject.ApplyModifiedProperties();

            if (!_mgr || !_mgr.gameObject.activeInHierarchy) return;

            GUILayout.Space(10f);
            EditorGUILayout.LabelField("Tracks", EditorStyles.boldLabel);

            DrawTrack("Master", AudioTrack.Master, cMaster);
            DrawTrack("Music", AudioTrack.Music, cMusic);
            DrawTrack("SFX", AudioTrack.Sfx, cSfx);
            DrawTrack("UI", AudioTrack.UI, cUI);
            DrawTrack("Voice", AudioTrack.Voice, cVoice);

            GUILayout.Space(10f);
            DrawSaveLoad();
        }

        private void DrawTrack(string title, AudioTrack track, Color color)
        {
            using (new EditorGUI.DisabledScope(!Application.isPlaying))
            {
                GUILayout.Space(6f);
                EditorGUILayout.LabelField(title, EditorStyles.boldLabel);

                // volume slider
                float v = _mgr.GetTrackVolume(track);
                float nv = EditorGUILayout.Slider("Volume", v, 0f, 1f);
                if (!Mathf.Approximately(nv, v))
                    _mgr.SetTrackVolume(track, nv);

                // buttons
                var old = GUI.backgroundColor;
                GUI.backgroundColor = color;

                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button(_mgr.IsTrackOn(track) ? "Mute" : "Unmute", EditorStyles.miniButtonLeft))
                {
                    if (_mgr.IsTrackOn(track)) _mgr.MuteTrack(track); else _mgr.UnmuteTrack(track);
                }
                if (GUILayout.Button("Pause", EditorStyles.miniButtonMid))
                {
                    _mgr.PauseTrack(track);
                }
                if (GUILayout.Button("Stop", EditorStyles.miniButtonMid))
                {
                    _mgr.StopTrack(track);
                }
                if (GUILayout.Button("Play", EditorStyles.miniButtonRight))
                {
                    _mgr.PlayTrack(track);
                }
                EditorGUILayout.EndHorizontal();

                GUI.backgroundColor = old;
            }
        }

        private void DrawSaveLoad()
        {
            using (new EditorGUI.DisabledScope(!Application.isPlaying))
            {
                EditorGUILayout.LabelField("Mixer Settings", EditorStyles.boldLabel);
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Save", EditorStyles.miniButtonLeft)) _mgr.SaveMixerToPrefs();
                if (GUILayout.Button("Load", EditorStyles.miniButtonMid)) _mgr.LoadMixerFromPrefs();
                if (GUILayout.Button("Reset", EditorStyles.miniButtonRight)) _mgr.ResetMixerPrefs();
                EditorGUILayout.EndHorizontal();
            }
        }
    }
}
#endif
