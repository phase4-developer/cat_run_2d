#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace jjevol
{
    [CustomEditor(typeof(AudioEventPlayer))]
    public sealed class AudioEventPlayerEditor : Editor
    {
        private SerializedProperty _track;
        private SerializedProperty _key;

        private SerializedProperty _autoPlay;
        private SerializedProperty _autoTiming;
        private SerializedProperty _autoPlayOnlyOnce;

        private GUIStyle _titleStyle;
        private GUIStyle _sectionStyle;

        private void OnEnable()
        {
            _track = serializedObject.FindProperty("track");
            _key = serializedObject.FindProperty("key");

            _autoPlay = serializedObject.FindProperty("autoPlay");
            _autoTiming = serializedObject.FindProperty("autoTiming");
            _autoPlayOnlyOnce = serializedObject.FindProperty("autoPlayOnlyOnce");
        }

        public override void OnInspectorGUI()
        {
            EnsureStyles();

            serializedObject.Update();

            DrawAudioHeader();

            DrawSection("Sound", () =>
            {
                EditorGUILayout.PropertyField(_key);
                EditorGUILayout.PropertyField(_track);

                if (string.IsNullOrWhiteSpace(_key.stringValue))
                {
                    EditorGUILayout.HelpBox("key가 비어 있으면 재생되지 않습니다. 기존 enum 숫자는 게임의 string key로 명시적으로 연결하세요.", MessageType.Info);
                }
            });

            DrawSection("Auto Play", () =>
            {
                EditorGUILayout.PropertyField(_autoPlay);

                if (_autoPlay.boolValue)
                {
                    EditorGUI.indentLevel++;
                    EditorGUILayout.PropertyField(_autoTiming);
                    EditorGUILayout.PropertyField(_autoPlayOnlyOnce);
                    EditorGUI.indentLevel--;
                }
            });

            DrawSection("Manual / Animation Event", () =>
            {
                EditorGUILayout.HelpBox(
                    "Animation Event에서는 Play(), PlaySound(), PlaySfx(), PlayUI(), PlayVoice(), PlayMusic() 중 하나를 호출하면 됩니다.",
                    MessageType.None
                );

                using (new EditorGUI.DisabledScope(!Application.isPlaying))
                {
                    if (GUILayout.Button("Play"))
                    {
                        foreach (Object targetObject in targets)
                        {
                            if (targetObject is AudioEventPlayer player)
                                player.Play();
                        }
                    }
                }
            });

            serializedObject.ApplyModifiedProperties();
        }

        private void EnsureStyles()
        {
            _titleStyle ??= new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 15,
                alignment = TextAnchor.MiddleLeft
            };

            _sectionStyle ??= new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12
            };
        }

        private void DrawAudioHeader()
        {
            EditorGUILayout.Space(4);

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("Audio Event Player", _titleStyle);
                EditorGUILayout.LabelField("컴포넌트 하나에 사운드 하나를 연결해서 자동/수동으로 재생합니다.", EditorStyles.miniLabel);
            }
        }

        private void DrawSection(string title, System.Action drawAction)
        {
            EditorGUILayout.Space(6);

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField(title, _sectionStyle);
                EditorGUILayout.Space(2);
                drawAction?.Invoke();
            }
        }
    }
}
#endif
