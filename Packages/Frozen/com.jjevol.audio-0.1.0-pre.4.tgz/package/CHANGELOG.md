# Changelog

## 0.1.0-pre.4 - 2026-11-10

- Asset and component menus moved from `jjevol/Audio/` to `JJEvol/Audio/`. `AudioMixerSettings` is now listed as `Audio Mixer Settings`. Framework menus are grouped by feature under one `JJEvol/` root (Editor menus), `Assets/Create/JJEvol/` (asset menus) and `GameObject/UI/JJEvol/` (UI objects). Only the menu path changed; class names, serialized fields and GUIDs are unchanged, so existing assets keep working.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.3 - 2026-11-09

- Compiles on Unity 6.7. `AudioDebouncer` keys clips by `EntityId` from `GetEntityId()` on 6.7, where `Object.GetInstanceID()` is a compile error, and by the instance ID on 6000.3, which has no `GetEntityId()`. Behaviour is unchanged.
- Public API, PlayerPrefs keys, serialized fields and GUIDs are unchanged.

## 0.1.0-pre.2 - 2026-11-06

- Track volume and On state now have one owner. Removed mixer read back, so a muted track keeps its volume across a save round trip.
- A source routed to a connected mixer parameter no longer multiplies track and master volume again.
- Added an internal Music channel and `AudioManager.CurrentMusic`. PlayMusic, AudioEventPlayer and CrossfadeMusic keep one final track.
- Added public `IAudioPlayer`, implemented by AudioManager.
- Split AudioManager into modules built by constructor: AudioClipResolver, AudioPool, AudioTrackMixer, AudioDebouncer and AudioPlaybackRequests. AudioMusicChannel now takes IAudioMusicHost.
- Public signatures, PlayerPrefs keys and format, serialized fields and GUIDs are unchanged.
- An externally destroyed AudioSource returns its lease on the next track change.
- Added PlayMusicAsync to AudioManager and IAudioPlayer.
- An overrideGroup in the configured mixer leaves master volume to the mixer, so it no longer applies twice.
- An Off track saved by an earlier build as the mixer's silent value keeps its current volume.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.1 — 2026-10-30

Local extraction candidate from the mobile Sound implementation. User-authorized parent/table/event dependency improvements; playback leases, stale completion/fade protection, pending cancellation, enum/string/library authoring and isolated tests. No publication, frozen archive or game migration.
