using NUnit.Framework;
using UnityEngine;
using UnityEditor;
using jjevol.UI;

namespace jjevol.UI.Tests
{
    [ExecuteAlways]
    public sealed class UIProbe : UIBase
    {
        public int Draws, Subscriptions;
        protected override void _DrawContents() => Draws++;
        protected override bool SetSubscribe(bool value) { if (!base.SetSubscribe(value)) return false; Subscriptions += value ? 1 : -1; return true; }
    }
    public sealed class UICoreEditTests
    {
        [Test]
        public void ShowRefreshHideRetainEventsAndDesignerRectTransform()
        {
            var go = new GameObject("core fixture", typeof(RectTransform));
            try
            {
                var rt = (RectTransform)go.transform;
                rt.anchorMin = new Vector2(.2f,.3f); rt.anchorMax = new Vector2(.7f,.8f); rt.pivot = new Vector2(.4f,.6f);
                rt.anchoredPosition = new Vector2(17,29); rt.sizeDelta = new Vector2(140,70); rt.localScale = Vector3.one * .8f;
                string rect = EditorJsonUtility.ToJson(rt);
                var ui = go.AddComponent<UIProbe>();
                int shown=0, hidden=0; ui.onShow.AddListener(_ => shown++); ui.onHide.AddListener(_ => hidden++);
                ui.ShowUI(); ui.Refresh(); ui.ShowUI();
                Assert.That(ui.Draws, Is.EqualTo(3)); Assert.That(shown, Is.EqualTo(2));
                Assert.That(ui.Subscriptions, Is.EqualTo(1));
                ui.HideUI(); Assert.That(hidden, Is.EqualTo(1)); Assert.That(ui.Subscriptions, Is.Zero);
                Assert.That(EditorJsonUtility.ToJson(rt), Is.EqualTo(rect));
            }
            finally { Object.DestroyImmediate(go); }
        }
        [Test]
        public void NumberAnimatorKeepsExactLongRangeDecimalAndSerializedFields()
        {
            var go = new GameObject("number fixture");
            try
            {
                var number = go.AddComponent<NumberAnimator>();
                number.SetValueImmediate(long.MaxValue);
                Assert.That(number.CurrentValue, Is.EqualTo((decimal)long.MaxValue));
                number.SetCustomFormat("[{0}]");
                var serialized = new SerializedObject(number);
                foreach(var name in new[]{"_label","_sizeFitter","_customStringFormat","AnimationDuration","UseUnscaledTime","UseSymbolic"})
                    Assert.That(serialized.FindProperty(name), Is.Not.Null, name);
            }
            finally { Object.DestroyImmediate(go); }
        }
        [Test]
        public void LoadingCounterPreservesRepeatedKeyReferenceSemantics()
        {
            var counter = new KeyReferenceCounter(); counter.Enable("a"); counter.Enable("a"); counter.Enable("b");
            counter.Disable("a"); Assert.That(counter.IsContain("a"), Is.True);
            counter.Disable("a"); Assert.That(counter.IsContain("a"), Is.False); Assert.That(counter.IsEnable(), Is.True);
            counter.Disable("b"); counter.Disable("b"); Assert.That(counter.IsEnable(), Is.False);
        }
    }
}
