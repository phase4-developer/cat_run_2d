using System;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.UI.Tests
{
    public sealed class UITestTMPSetup : IPrebuildSetup
    {
        public void Setup()
        {
            if(Shader.Find("TextMeshPro/Mobile/Distance Field")!=null)return;
            string project=Path.GetFullPath(Path.Combine(Application.dataPath,"..")).Replace('\\','/');
            if(!project.EndsWith("/.local/ui-validation/CoreHost",StringComparison.OrdinalIgnoreCase)&&!project.EndsWith("/.local/ui-validation/FullHost",StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Import the installed uGUI package's TMP Essential Resources in this validation project before running UI tests.");
            var package=UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TMP_Text).Assembly);
            string assets=Path.Combine(package.resolvedPath,"Package Resources","TMP Essential Resources.unitypackage");
            AssetDatabase.ImportPackage(assets,false);AssetDatabase.Refresh();
            // ImportPackage completes through the Editor import loop before entering PlayMode.
        }
    }
}
