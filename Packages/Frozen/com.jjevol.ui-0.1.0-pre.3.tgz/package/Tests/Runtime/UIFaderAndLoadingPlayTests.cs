using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace jjevol.UI.Tests
{
    public sealed class UIFaderAndLoadingPlayTests
    {
        private readonly List<GameObject> _objects = new();
        private readonly List<Material> _originals = new();
        private Material _material;

        [SetUp]
        public void Setup()
        {
            typeof(LoadingIndicator).GetField("_warnedMissingInstance", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, false);
        }

        [TearDown]
        public void Cleanup()
        {
            foreach (var go in _objects) if (go) Object.DestroyImmediate(go);
            _objects.Clear();
            if (_material) Object.DestroyImmediate(_material);
            foreach (var material in _originals) if (material) Object.DestroyImmediate(material);
            _originals.Clear();
        }

        private GameObject New(string name, params Type[] types) { var go = new GameObject(name, types); _objects.Add(go); return go; }
        private UIFader NewFader(string name) => New(name, typeof(RectTransform), typeof(Image)).AddComponent<UIFader>();
        private static void Set(object target, string field, object value) => target.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic).SetValue(target, value);
        private static IEnumerator Finish(Task task)
        {
            float end = Time.realtimeSinceStartup + 5;
            while (!task.IsCompleted && Time.realtimeSinceStartup < end) yield return null;
            Assert.That(task.IsCompleted, Is.True, "The transition must finish.");
        }
        private static bool IsCanceled(Task task) => task.IsCanceled || task.Exception?.GetBaseException() is OperationCanceledException;
        private static UIFaderTransitionOption Option(UIFaderTransitionType type) => new UIFaderTransitionOption
        {
            transitionType = type,
            fadeInDuration = 0f,
            fadeOutDuration = 0f,
            color = Color.black,
            showLoadingIndicator = false
        };
        private UIFaderTransitionOption ShaderOption()
        {
            var shader = Shader.Find("UI/Default");
            Assert.That(shader, Is.Not.Null);
            _material = new Material(shader);
            var option = Option(UIFaderTransitionType.ShaderProgress);
            option.transitionMaterial = _material;
            option.progressProperty = "_ColorMask";
            return option;
        }

        private Material OriginalMaterial(Image image)
        {
            var original = new Material(Shader.Find("UI/Default"));
            _originals.Add(original);
            image.material = original;
            return original;
        }

        private IEnumerator AssertShaderTransitionRestoresTheMaterial(Func<UniTask> midAction, bool faulted)
        {
            var fader = NewFader("material owner");
            var image = fader.GetComponent<Image>();
            var original = OriginalMaterial(image);
            Material during = null;
            var task = fader.PlayTransitionAsync(() => { during = image.material; return midAction(); }, null, ShaderOption()).AsTask();
            yield return Finish(task);
            Assert.That(during, Is.Not.SameAs(original), "The transition material was applied.");
            Assert.That(task.IsFaulted, Is.EqualTo(faulted));
            Assert.That(image.material, Is.SameAs(original), "The fader hides itself at the end, which must not skip the restore.");
        }

        [UnityTest]
        public IEnumerator ShaderProgressSuccessRestoresTheOriginalMaterial() => AssertShaderTransitionRestoresTheMaterial(() => UniTask.CompletedTask, false);

        [UnityTest]
        public IEnumerator ShaderProgressFailureRestoresTheOriginalMaterial() => AssertShaderTransitionRestoresTheMaterial(() => UniTask.FromException(new InvalidOperationException("mid failure")), true);

        [UnityTest]
        public IEnumerator DisablingDuringAShaderTransitionRestoresTheOriginalMaterial()
        {
            var fader = NewFader("disabled transition");
            var image = fader.GetComponent<Image>();
            var original = OriginalMaterial(image);
            var gate = new UniTaskCompletionSource();
            var task = fader.PlayTransitionAsync(() => gate.Task, null, ShaderOption()).AsTask();
            Assert.That(image.material, Is.Not.SameAs(original));
            fader.gameObject.SetActive(false);
            Assert.That(image.material, Is.SameAs(original));
            gate.TrySetResult();
            yield return Finish(task);
            Assert.That(image.material, Is.SameAs(original));
        }

        [UnityTest]
        public IEnumerator ReplacingAShaderTransitionKeepsTheOriginalMaterial()
        {
            var fader = NewFader("replaced transition");
            var image = fader.GetComponent<Image>();
            var original = OriginalMaterial(image);
            var option = ShaderOption();
            var gate = new UniTaskCompletionSource();
            var replaced = fader.PlayTransitionAsync(() => gate.Task, null, option).AsTask();
            var current = fader.PlayTransitionAsync(() => UniTask.CompletedTask, null, option).AsTask();
            yield return Finish(current);
            gate.TrySetResult();
            yield return Finish(replaced);
            Assert.That(image.material, Is.SameAs(original), "The second run must not capture the first run's temporary material.");
        }

        private UIFader NewInactiveFader(string name)
        {
            var go = New(name, typeof(RectTransform), typeof(Image));
            go.SetActive(false);
            return go.AddComponent<UIFader>();
        }

        [UnityTest]
        public IEnumerator FirstFadeOfAFaderSavedInactiveStartsAndFinishes()
        {
            var fader = NewInactiveFader("saved inactive fade");
            var task = fader.FadeIn(0.01f).AsTask();
            yield return Finish(task);
            Assert.That(task.IsFaulted, Is.False, task.Exception?.ToString());
            Assert.That(fader.gameObject.activeSelf, Is.True, "Awake must not leave the requested cover hidden.");
            Assert.That(fader.GetComponent<Image>().color.a, Is.GreaterThan(0f));
        }

        [UnityTest]
        public IEnumerator TransitionOfAFaderSavedInactiveCoversBeforeTheMidAction()
        {
            var fader = NewInactiveFader("saved inactive transition");
            float alphaDuringAction = -1f;
            var task = fader.PlayTransitionAsync(() =>
            {
                alphaDuringAction = fader.gameObject.activeSelf ? fader.GetComponent<Image>().color.a : 0f;
                return UniTask.CompletedTask;
            }, null, UIFaderTransitionOption.ColorFade(Color.black, 0.01f)).AsTask();
            yield return Finish(task);
            Assert.That(task.IsFaulted, Is.False, task.Exception?.ToString());
            Assert.That(alphaDuringAction, Is.EqualTo(1f), "The action must run behind a visible cover.");
            Assert.That(fader.gameObject.activeSelf, Is.False);
        }

        [UnityTest]
        public IEnumerator ShowImmediateOfAFaderSavedInactiveShowsTheCover()
        {
            var fader = NewInactiveFader("saved inactive show");
            fader.ShowImmediate(Color.black);
            yield return null;
            Assert.That(fader.gameObject.activeSelf, Is.True);
            Assert.That(fader.IsVisible, Is.True);
        }

        private IEnumerator AssertMidActionFailureUnlocks(UIFaderTransitionOption option)
        {
            var fader = NewFader("failing transition");
            int ended = 0;
            var task = fader.PlayTransitionAsync(() => UniTask.FromException(new InvalidOperationException("mid failure")), () => ended++, option).AsTask();
            yield return Finish(task);
            Assert.That(task.IsFaulted, Is.True);
            Assert.That(task.Exception.GetBaseException(), Is.InstanceOf<InvalidOperationException>());
            Assert.That(fader.IsFading, Is.False, "The input lock must end even though midAction failed.");
            Assert.That(fader.gameObject.activeSelf, Is.False, "The cover must fade out and hide.");
            Assert.That(fader.GetComponent<Image>().raycastTarget, Is.False);
            Assert.That(ended, Is.Zero, "endAction reports a successful transition only.");
        }

        [UnityTest]
        public IEnumerator ColorFadeMidActionFailureFadesOutUnlocksAndRethrows() => AssertMidActionFailureUnlocks(Option(UIFaderTransitionType.ColorFade));

        [UnityTest]
        public IEnumerator ShaderProgressMidActionFailureFadesOutUnlocksAndRethrows() => AssertMidActionFailureUnlocks(ShaderOption());

        [UnityTest]
        public IEnumerator NoneTransitionFailureReleasesTheLockAndRethrows()
        {
            var fader = NewFader("failing lock");
            var task = fader.PlayTransitionAsync(() => UniTask.FromException(new InvalidOperationException("mid failure")), null, Option(UIFaderTransitionType.None)).AsTask();
            yield return Finish(task);
            Assert.That(task.IsFaulted, Is.True);
            Assert.That(fader.IsFading, Is.False);
        }

        [UnityTest]
        public IEnumerator MidActionCancellationIsForwardedAfterTheFadeOut()
        {
            foreach (var type in new[] { UIFaderTransitionType.ColorFade, UIFaderTransitionType.None })
            {
                var fader = NewFader("external cancel " + type);
                var task = fader.PlayTransitionAsync(() => UniTask.FromException(new OperationCanceledException()), null, Option(type)).AsTask();
                yield return Finish(task);
                Assert.That(IsCanceled(task), Is.True, "Only the fader's own cancellation may be swallowed.");
                Assert.That(fader.IsFading, Is.False, type.ToString());
            }
        }

        [UnityTest]
        public IEnumerator FaderOwnCancellationIsSwallowedAndSkipsTheEndAction()
        {
            var fader = NewFader("own cancel");
            var gate = new UniTaskCompletionSource();
            int ended = 0;
            var task = fader.PlayTransitionAsync(() => gate.Task, () => ended++, Option(UIFaderTransitionType.ColorFade)).AsTask();
            fader.gameObject.SetActive(false);
            gate.TrySetCanceled();
            yield return Finish(task);
            Assert.That(task.IsCompletedSuccessfully, Is.True);
            Assert.That(ended, Is.Zero);
        }

        [UnityTest]
        public IEnumerator EndActionFailureStillUnlocksTheFader()
        {
            var fader = NewFader("failing end action");
            var task = fader.PlayTransitionAsync(() => UniTask.CompletedTask, () => throw new InvalidOperationException("end failure"), Option(UIFaderTransitionType.ColorFade)).AsTask();
            yield return Finish(task);
            Assert.That(task.IsFaulted, Is.True);
            Assert.That(fader.IsFading, Is.False);
            Assert.That(fader.gameObject.activeSelf, Is.False);
        }

        [UnityTest]
        public IEnumerator MidActionFailureKeepsTheLoadingIndicatorBalanced()
        {
            var indicator = New("indicator", typeof(RectTransform)).AddComponent<LoadingIndicator>();
            var option = Option(UIFaderTransitionType.ColorFade);
            option.showLoadingIndicator = true;
            option.loadingIndicatorKey = "fader-key";
            bool shown = false;
            var task = NewFader("indicator fader").PlayTransitionAsync(() =>
            {
                shown = indicator.IsContain("fader-key");
                return UniTask.FromException(new InvalidOperationException("mid failure"));
            }, null, option).AsTask();
            yield return Finish(task);
            Assert.That(shown, Is.True);
            Assert.That(indicator.IsEnable(), Is.False);
        }

        [Test]
        public void ScopePairsShowAndHideAndDisposesOnce()
        {
            var indicator = New("indicator", typeof(RectTransform)).AddComponent<LoadingIndicator>();
            var outer = LoadingIndicator.Scope("shared");
            using (LoadingIndicator.Scope("shared")) Assert.That(indicator.IsContain("shared"), Is.True);
            Assert.That(indicator.IsContain("shared"), Is.True);
            outer.Dispose();
            Assert.That(indicator.IsEnable(), Is.False);
            LoadingIndicator.Show("shared");
            outer.Dispose();
            Assert.That(indicator.IsContain("shared"), Is.True, "A second Dispose must not consume another owner's count.");
            LoadingIndicator.Hide("shared");
        }

        [Test]
        public void ScopeReturnsOnlyToTheInstanceThatCountedIt()
        {
            var first = New("first indicator", typeof(RectTransform));
            first.AddComponent<LoadingIndicator>();
            var scope = LoadingIndicator.Scope("key");
            Object.DestroyImmediate(first);
            var next = New("next indicator", typeof(RectTransform)).AddComponent<LoadingIndicator>();
            LoadingIndicator.Show("key");
            scope.Dispose();
            Assert.That(next.IsContain("key"), Is.True);
            LoadingIndicator.Hide("key");
        }

        [Test]
        public void ShowWithoutAnInstanceWarnsOnceAndScopeIsInert()
        {
            Assert.That(LoadingIndicator.HasInstance, Is.False, "This test requires no indicator in the test Scene.");
            LogAssert.Expect(LogType.Warning, new Regex(@"\[LoadingIndicator\] No instance"));
            LoadingIndicator.Show("first");
            LoadingIndicator.Show("second");
            LoadingIndicator.Scope("third").Dispose();
            LoadingIndicator.Hide("first");
            LogAssert.NoUnexpectedReceived();
        }

        [Test]
        public void MissingIndicatorReferenceIsHandledByEveryPath()
        {
            var indicator = New("no view", typeof(RectTransform)).AddComponent<LoadingIndicator>();
            Assert.DoesNotThrow(() =>
            {
                LoadingIndicator.Show();
                LoadingIndicator.Hide();
                LoadingIndicator.Show();
                LoadingIndicator.HideForce();
            });
            Assert.That(indicator.IsEnable(), Is.False);
        }

        [Test]
        public void StaticStateResetsRunAtSubsystemRegistration()
        {
            foreach (var pair in new[] { (typeof(LoadingIndicator), "ResetStaticState"), (typeof(UIRuntimeOptions), "ResetState") })
            {
                var method = pair.Item1.GetMethod(pair.Item2, BindingFlags.Static | BindingFlags.NonPublic);
                Assert.That(method, Is.Not.Null, pair.Item2);
                var attribute = method.GetCustomAttributes<RuntimeInitializeOnLoadMethodAttribute>().Single();
                Assert.That(attribute.loadType, Is.EqualTo(RuntimeInitializeLoadType.SubsystemRegistration));
            }
            int notified = 0;
            UIRuntimeOptions.Localize = (collection, key) => key;
            UIRuntimeOptions.RegisterLoadingCounter = _ => { };
            UIRuntimeOptions.LocaleChanged += () => notified++;
            typeof(UIRuntimeOptions).GetMethod("ResetState", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, null);
            UIRuntimeOptions.NotifyLocaleChanged();
            Assert.That(UIRuntimeOptions.Localize, Is.Null);
            Assert.That(UIRuntimeOptions.RegisterLoadingCounter, Is.Null);
            Assert.That(notified, Is.Zero, "Subscriptions from an earlier Play session must not survive.");
        }

        [UnityTest]
        public IEnumerator LoadingBarFillsSmoothlyAndDropsImmediately()
        {
            var bar = New("bar", typeof(RectTransform)).AddComponent<UILoadingBar>();
            var fill = New("fill", typeof(RectTransform), typeof(Image)).GetComponent<Image>();
            Set(bar, "fillImage", fill);
            Set(bar, "fillSpeed", 50f);
            bar.SetProgress(.5f);
            Assert.That(bar.Progress, Is.EqualTo(.5f));
            Assert.That(bar.DisplayedProgress, Is.Zero, "An increase is animated by Update.");
            float end = Time.realtimeSinceStartup + 5;
            while (bar.DisplayedProgress < .5f && Time.realtimeSinceStartup < end) yield return null;
            Assert.That(fill.fillAmount, Is.EqualTo(.5f).Within(.001f));
            bar.SetProgress(.2f);
            Assert.That(fill.fillAmount, Is.EqualTo(.2f).Within(.001f), "A decrease is shown immediately.");
        }

        [Test]
        public void LoadingBarShowsItsValueOnEnableInsteadOfThePrefabFill()
        {
            var go = New("inactive bar", typeof(RectTransform));
            go.SetActive(false);
            var bar = go.AddComponent<UILoadingBar>();
            var fill = New("fill", typeof(RectTransform), typeof(Image)).GetComponent<Image>();
            fill.fillAmount = .7f;
            Set(bar, "fillImage", fill);
            go.SetActive(true);
            Assert.That(fill.fillAmount, Is.Zero);
        }

        [Test]
        public void FirstReportOfZeroClearsThePrefabFill()
        {
            var bar = New("zero bar", typeof(RectTransform)).AddComponent<UILoadingBar>();
            var fill = New("fill", typeof(RectTransform), typeof(Image)).GetComponent<Image>();
            fill.fillAmount = .7f;
            Set(bar, "fillImage", fill);
            bar.SetProgress(0f);
            Assert.That(fill.fillAmount, Is.Zero);
        }

        [Test]
        public void LoadingBarDrivesASliderAndRejectsInvalidValues()
        {
            var bar = New("slider bar", typeof(RectTransform)).AddComponent<UILoadingBar>();
            var slider = New("slider", typeof(RectTransform)).AddComponent<Slider>();
            slider.minValue = 10f;
            slider.maxValue = 20f;
            Set(bar, "slider", slider);
            Set(bar, "fillSpeed", 0f);
            bar.SetProgress(.5f);
            Assert.That(slider.value, Is.EqualTo(15f).Within(.001f));
            bar.SetProgress(float.NaN);
            Assert.That(bar.Progress, Is.EqualTo(.5f));
            bar.SetProgress(7f);
            Assert.That(bar.Progress, Is.EqualTo(1f));
            Assert.DoesNotThrow(() => bar.SetMessage("no text target"));
        }
    }
}
