using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace jjevol.UI.Tests
{
    public sealed class PlayUIProbe : UIBase
    {
        public int Draws, Subscriptions;
        protected override void _DrawContents() => Draws++;
        protected override bool SetSubscribe(bool value) { if (!base.SetSubscribe(value)) return false; Subscriptions += value ? 1 : -1; return true; }
    }
    [PrebuildSetup("jjevol.UI.Tests.UITestTMPSetup")]
    public sealed class UICorePlayTests
    {
        private readonly List<GameObject> _objects = new();
        private TMP_Settings _priorSettings, _settings;
        private TMP_FontAsset _font;
        [SetUp]
        public void Setup()
        {
            var field = typeof(TMP_Settings).GetField("s_Instance", BindingFlags.Static | BindingFlags.NonPublic);
            _priorSettings = (TMP_Settings)field.GetValue(null);
            _settings = ScriptableObject.CreateInstance<TMP_Settings>();
            _font = TMP_FontAsset.CreateFontAsset("Arial","Regular",32);
            Assert.That(_font,Is.Not.Null,"The Windows validation host requires its installed Arial font.");
            typeof(TMP_Settings).GetField("m_defaultFontAsset", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(_settings, _font);
            field.SetValue(null, _settings);
        }
        [UnityTearDown]
        public IEnumerator Cleanup()
        {
            foreach(var go in _objects) if(go) Object.Destroy(go); _objects.Clear(); yield return null;
            typeof(TMP_Settings).GetField("s_Instance", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, _priorSettings);
            if(_font) { if(_font.material) Object.Destroy(_font.material); foreach(var texture in _font.atlasTextures) if(texture) Object.Destroy(texture); Object.Destroy(_font); }
            Object.Destroy(_settings);
            UIRuntimeOptions.Localize=null; UIRuntimeOptions.Language=null; UIRuntimeOptions.Culture=null;
            yield return null;
        }
        private GameObject New(string name, params Type[] types) { var go=new GameObject(name,types); _objects.Add(go); return go; }

        [UnityTest]
        public IEnumerator DirtyCoalescesAcrossFramesAndHideShowDoesNotDuplicateSubscriptions()
        {
            var probe=New("actual UIBase",typeof(RectTransform)).AddComponent<PlayUIProbe>();
            Assert.That(probe.Subscriptions,Is.EqualTo(1));
            probe.ShowUI(); int draws=probe.Draws;
            probe.SetDirty(); probe.SetDirty(); Assert.That(probe.Draws,Is.EqualTo(draws));
            yield return null; yield return null;
            Assert.That(probe.Draws,Is.EqualTo(draws+1));
            probe.SetDirty(); probe.HideUI(); Assert.That(probe.Subscriptions,Is.Zero);
            yield return null; yield return null; Assert.That(probe.Draws,Is.EqualTo(draws+1));
            for(int i=0;i<6;i++){probe.ShowUI(); Assert.That(probe.Subscriptions,Is.EqualTo(1)); probe.HideUI(); Assert.That(probe.Subscriptions,Is.Zero);}
        }

        [UnityTest]
        public IEnumerator RealTmpLongFormattingAndSymbolicLocalizationAreConnected()
        {
            var text=New("TMP fixture",typeof(RectTransform)).AddComponent<TextMeshProUGUI>();
            var number=text.gameObject.AddComponent<NumberAnimator>();
            number.CurrentPrintType=NumberAnimator.PrintType.Number;
            number.SetValueImmediate(long.MaxValue);
            Assert.That(number.CurrentValue,Is.EqualTo((decimal)long.MaxValue));
            Assert.That(text.text,Is.EqualTo(((decimal)long.MaxValue).ToString("N0")));
            number.UseSymbolic=true; number.CurrentPrintType=NumberAnimator.PrintType.Normal;
            UIRuntimeOptions.Language=()=>"ko-KR"; number.SetValueImmediate(10000);
            Assert.That(text.text,Is.EqualTo("1만"));
            UIRuntimeOptions.Language=()=>"en-US"; number.SetValueImmediate(12000);
            Assert.That(text.text,Is.EqualTo("12K"));
            UIRuntimeOptions.Localize=(collection,key)=>" fixture";
            number.IsBackStringLocalizationKey=true; number.BackString="suffix"; number.UpdateVisuals();
            Assert.That(text.text,Is.EqualTo("12K fixture"));
            yield return null;
        }

        [UnityTest]
        public IEnumerator NumberCompletionCanStartTheNextAnimationWithoutLosingItsCallback()
        {
            var text=New("number callback",typeof(RectTransform)).AddComponent<TextMeshProUGUI>();
            var number=text.gameObject.AddComponent<NumberAnimator>(); number.AnimationDuration=.02f;
            bool first=false,second=false;
            number.AnimateTo(5,()=>{first=true; number.AnimateTo(10,()=>second=true);});
            float until=Time.realtimeSinceStartup+2;
            while(!second&&Time.realtimeSinceStartup<until) yield return null;
            Assert.That(first,Is.True); Assert.That(second,Is.True); Assert.That(number.CurrentValue,Is.EqualTo(10));
        }

        [UnityTest]
        public IEnumerator LateFaderCompletionCannotUnlockAReusedFader()
        {
            var fader=New("fader reuse",typeof(RectTransform)).AddComponent<UIFader>();
            var firstGate=new UniTaskCompletionSource(); var nextGate=new UniTaskCompletionSource();
            var option=new UIFaderTransitionOption{transitionType=UIFaderTransitionType.None,showLoadingIndicator=false};
            int oldEnd=0,newEnd=0;
            var first=fader.PlayTransitionAsync(()=>firstGate.Task,()=>oldEnd++,option).AsTask();
            fader.gameObject.SetActive(false); fader.gameObject.SetActive(true);
            var next=fader.PlayTransitionAsync(()=>nextGate.Task,()=>newEnd++,option).AsTask();
            try
            {
                firstGate.TrySetResult(); while(!first.IsCompleted) yield return null;
                Assert.That(oldEnd,Is.Zero); Assert.That(fader.IsFading,Is.True,"An old finally must not clear the new transition's lock.");
                nextGate.TrySetResult(); while(!next.IsCompleted) yield return null;
                Assert.That(newEnd,Is.EqualTo(1)); Assert.That(fader.IsFading,Is.False);
            }
            finally { firstGate.TrySetResult(); nextGate.TrySetResult(); }
        }
        [UnityTest]
        public IEnumerator SymbolicNumberAndPercentageUseTheirActualFormat()
        {
            var text=New("symbolic format",typeof(RectTransform)).AddComponent<TextMeshProUGUI>();
            var number=text.gameObject.AddComponent<NumberAnimator>();number.UseSymbolic=true;UIRuntimeOptions.Language=()=>"en-US";
            number.CurrentPrintType=NumberAnimator.PrintType.Number;number.SetValueImmediate(12000);
            Assert.That(text.text,Is.EqualTo("12K"));
            number.CurrentPrintType=NumberAnimator.PrintType.Percentage;number.SetValueImmediate(.5m);
            Assert.That(text.text,Is.EqualTo(.5m.ToString("P1")));yield return null;
        }
    }
}
