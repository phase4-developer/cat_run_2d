# Source and distribution boundary

The STEP 11 user request authorizes local extraction from `{workspace}/jjevol_library_mobile` into this Framework candidate. The user separately confirmed that the existing screen/popup/HUD/sound enum declarations may be retained as compatibility IDs. Source files, unchanged metas and adaptations are recorded in `Docs/UIExtraction`.

No public redistribution license has been assigned to the user's code. Company/contract title and third-party licenses are not inferred from local extraction permission. No original game UI/content, paid Vendor implementation, SDK binary, fonts or textures are included in these UI UPM packages. Unity/UniTask and other Framework modules are declared dependencies. Installed uGUI TMP resources were imported only into the new isolated validation Hosts.
