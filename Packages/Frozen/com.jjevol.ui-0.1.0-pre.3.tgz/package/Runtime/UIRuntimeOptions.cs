using System;
using System.Globalization;
using UnityEngine;
using UnityEngine.Events;
namespace jjevol
{
    public static class UIRuntimeOptions
    {
        public static Func<string, string, string> Localize { get; set; }
        public static Func<CultureInfo> Culture { get; set; }
        public static Func<string> Language { get; set; }
        public static Action<IKeyReferenceCounter> RegisterLoadingCounter { get; set; }
        public static CultureInfo DisplayCulture => Culture?.Invoke() ?? CultureInfo.CurrentCulture;
        public static string CurrentLanguage => Language?.Invoke() ?? DisplayCulture.Name;
        public static string GetLocalizedString(string collection, string key) => Localize?.Invoke(collection, key) ?? key;
        public static event Action LocaleChanged;
        public static void NotifyLocaleChanged() => LocaleChanged?.Invoke();
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            Localize = null; Culture = null; Language = null; RegisterLoadingCounter = null; LocaleChanged = null;
        }
    }
    public interface IUITransition
    {
        bool IsTransitioning { get; }
        CanvasGroup TargetCanvasGroup { get; }
        UnityEvent ShowCompleted { get; }
        UnityEvent HideCompleted { get; }
        void OnWindowAdded();
        void OnWindowRemove();
        void ForceStopTransition();
    }
}
