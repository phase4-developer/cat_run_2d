using System.Collections;
using UnityEngine;
using UnityEngine.Events;

namespace jjevol
{
    public class UIBase : MonoBehaviour, IUIElement
    {
        protected IUIReleaseHandle m_ReleaseHandle;

        public void Initialize(IUIReleaseHandle releaseHandle)
        {
            m_ReleaseHandle = releaseHandle;
        }

        public RectTransform rectTransform => transform as RectTransform;

        public virtual bool IsVisible => gameObject.activeSelf;

        [Header("UI Events")]
        public UnityEvent<UIBase> onShow = new ();
        public UnityEvent<UIBase> onHide = new ();
        public UnityEvent<UIBase> onDestory = new ();

        protected bool mDirty = false;
        protected Coroutine mDirtyCoroutine;

        protected bool mSubscribe = false;
        protected virtual bool SetSubscribe(bool subscribe)
        {
            if (subscribe && !gameObject.activeInHierarchy) return false;

            if (mSubscribe != subscribe)
            {
                mSubscribe = subscribe;

                return true;
            }

            return false;
        }

        protected virtual void OnEnable()
        {
            SetSubscribe(true);

            if (mDirty)
                _StartDirty();
        }

        protected virtual void OnDisable()
        {
            SetSubscribe(false);
            _StopDirty();
        }

        protected virtual void OnDestroy()
        {
            SetSubscribe(false);
            onDestory?.Invoke(this);
        }

        public virtual void ShowUI()
        {
            gameObject.SetActive(true);
            Refresh();

            onShow?.Invoke(this);
        }

        public virtual void HideUI()
        {
            gameObject.SetActive(false);

            onHide?.Invoke(this);
        }

        public virtual void Refresh()
        {
            if (!IsVisible) return;
            _DrawContents();
            _StopDirty();
        }

        public virtual void SetDirty()
        {
            if (mDirty || !gameObject.activeInHierarchy) return;
            _StartDirty();
        }

        protected virtual void _DrawContents() { }

        protected void _StartDirty()
        {
            mDirty = true;
            mDirtyCoroutine = StartCoroutine(_Dirty());
        }

        protected void _StopDirty()
        {
            if (mDirtyCoroutine != null)
                StopCoroutine(mDirtyCoroutine);

            mDirtyCoroutine = null;
            mDirty = false;
        }

        private IEnumerator _Dirty()
        {
            yield return null;
            _DrawContents();
            mDirty = false;
            mDirtyCoroutine = null;
        }
    }
}