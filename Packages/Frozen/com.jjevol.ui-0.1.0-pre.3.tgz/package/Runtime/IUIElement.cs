using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol
{
    public interface IUIElement
    {
        void ShowUI();
        void HideUI();
        void Refresh();
        bool IsVisible { get; }
    }
}