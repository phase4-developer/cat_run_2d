

using System;
using UnityEngine;

namespace jjevol
{

    public class LoadingIndicator : Singleton<LoadingIndicator>, IKeyReferenceCounter
    {
        [SerializeField] private UIBase Indicator;
        [SerializeField] private CanvasGroup indicatorCanvasGroup;
        [SerializeField, Min(0f)] private float showDelay = 0.2f;

        private KeyReferenceCounter referenceCounter = new KeyReferenceCounter();
        private double _showAt;
        private static bool _warnedMissingInstance;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStaticState()
        {
            _instance = null;
            applicationIsQuitting = false;
            _warnedMissingInstance = false;
        }

        public static bool IsShowIndicator
        {
            get
            {
                return HasInstance && Instance.IsEnable();
            }
        }

        protected override void InitializeSingleton()
        {
            base.InitializeSingleton();

            UIRuntimeOptions.RegisterLoadingCounter?.Invoke(this);
        }

        public static void Show(string key = "Loading")
        {
            if (!HasInstance)
            {
                WarnMissingInstance(key);
                return;
            }

            Instance.Enable(key);
        }

        /// <summary>
        /// Show와 Hide의 짝을 보장한다. Dispose는 한 번만 적용되고, Show 시점의 인스턴스에만 반환한다.
        /// 인스턴스가 없으면 아무 일도 하지 않는 핸들을 돌려준다.
        /// </summary>
        public static IDisposable Scope(string key = "Loading")
        {
            Show(key);

            return new ScopeHandle(HasInstance ? Instance : null, key);
        }

        private static void WarnMissingInstance(string key)
        {
            if (_warnedMissingInstance || applicationIsQuitting) return;

            _warnedMissingInstance = true;
            Debug.LogWarning($"[LoadingIndicator] No instance in the scene; loading requests are ignored. key:{key}");
        }

        private sealed class ScopeHandle : IDisposable
        {
            private LoadingIndicator _owner;
            private readonly string _key;

            public ScopeHandle(LoadingIndicator owner, string key)
            {
                _owner = owner;
                _key = key;
            }

            public void Dispose()
            {
                LoadingIndicator owner = _owner;
                _owner = null;

                if (owner != null)
                    owner.Disable(_key);
            }
        }

        public static void Hide(string key = "Loading")
        {
            if (!HasInstance) return;

            Instance.Disable(key);
        }

        public static void HideForce()
        {
            if (!HasInstance) return;

            Instance.Clear();
        }

        public bool IsContain(string key)
        {
            return referenceCounter.IsContain(key);
        }

        public bool IsEnable()
        {
            return referenceCounter.IsEnable();
        }

        public void Disable(string name)
        {
            referenceCounter.Disable(name);

            if (!referenceCounter.IsEnable() && Indicator != null)
                Indicator.HideUI();
        }

        public void Enable(string name)
        {
            bool wasEnabled = referenceCounter.IsEnable();
            referenceCounter.Enable(name);

            if (wasEnabled) return;

            _showAt = Time.realtimeSinceStartupAsDouble + Mathf.Max(0f, showDelay);
            if (indicatorCanvasGroup != null)
                indicatorCanvasGroup.alpha = showDelay > 0f ? 0f : 1f;

            // 입력 차단은 즉시 유지하고 로딩 표시만 지연한다.
            if (Indicator != null)
                Indicator.ShowUI();
        }

        private void Update()
        {
            if (!referenceCounter.IsEnable() || indicatorCanvasGroup == null || indicatorCanvasGroup.alpha >= 1f)
                return;

            if (Time.realtimeSinceStartupAsDouble >= _showAt)
                indicatorCanvasGroup.alpha = 1f;
        }

        public void Clear()
        {
            referenceCounter.Clear();

            if (Indicator != null)
                Indicator.HideUI();
        }
    }

}
