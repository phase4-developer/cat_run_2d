// UIDynamicCanvasBinder.cs
using System.Collections.Generic;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// UIDynamicGroupTag ���� �� ���� ĵ���� ���ε� �� ���� ���� ���� �� �ȷο� ����
    /// ȭ�� ȸ��/�ػ� ���� �� ��ü ���� ��ũ + ���־� ���û
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class UIDynamicCanvasBinder : MonoBehaviour
    {
        [SerializeField] RectTransform dynamicCanvasRoot;
        [SerializeField] List<RectTransform> dynamicGroups = new();
        [SerializeField] bool autoCollectFromTags = true;

        Canvas _rootCanvas;
        Vector2Int _lastScreenSize;
        bool _bound;

        readonly Dictionary<RectTransform, RectTransform> _referenceMap = new();

        void Awake()
        {
            _rootCanvas = GetComponentInParent<Canvas>();
            _lastScreenSize = new Vector2Int(Screen.width, Screen.height);

            if (autoCollectFromTags)
            {
                var tags = GetComponentsInChildren<UIDynamicGroupTag>(true);
                System.Array.Sort(tags, (a, b) => a.order.CompareTo(b.order));
                foreach (var tag in tags)
                {
                    var rt = tag.transform as RectTransform;
                    if (!rt) continue;
                    if (tag.includeInactive || rt.gameObject.activeInHierarchy)
                        if (!dynamicGroups.Contains(rt)) dynamicGroups.Add(rt);
                }
            }
        }

        public void BindToDynamicOnce()
        {
            if (_bound) return;
            if (!dynamicCanvasRoot) { Debug.LogWarning($"{name}: dynamicCanvasRoot missing"); return; }
            if (!_rootCanvas) { _rootCanvas = GetComponentInParent<Canvas>(); if (!_rootCanvas) return; }

            foreach (var grp in dynamicGroups)
            {
                var tag = grp ? grp.GetComponent<UIDynamicGroupTag>() : null;
                BindOne(grp, tag);
            }

            // ���ε� ���� 1ȸ ���� ���� + ���־� ����
            foreach (var grp in dynamicGroups)
            {
                // reference�� ������ �� ü�θ� ���� �����
                if (_referenceMap.TryGetValue(grp, out var refRt) && refRt)
                    UILayoutUtils.TryRebuildLayoutChain(refRt);

                var f = grp.GetComponent<UIDynamicCanvasFollower>();
                f?.ForceSync();
                f?.RequestWarmup();
            }

            _bound = true;
            _lastScreenSize = new Vector2Int(Screen.width, Screen.height);
        }

        void BindOne(RectTransform target, UIDynamicGroupTag tag)
        {
            if (!target) return;

            var dynRoot = (tag && tag.overrideDynamicRoot) ? tag.overrideDynamicRoot : dynamicCanvasRoot;
            var canvas = (tag && tag.overrideRootCanvas) ? tag.overrideRootCanvas : _rootCanvas;

            // 1) �ڸ� ������ ���۷��� ����
            RectTransform reference = null;
            bool makeRef = (tag == null) ? true : tag.createReferencePlaceholder;
            if (makeRef)
            {
                reference = CreateReferenceClone(target);
                _referenceMap[target] = reference;
            }

            // 2) �� ȭ�� ���� 1ȸ �̽�
            RectTransformAnchorUtils.FitToParentAuto(target, dynRoot, canvas);

            // 3) �ȷο� ����(�±� �ɼ� ��� ����)
            var follower = target.GetComponent<UIDynamicCanvasFollower>() ?? target.gameObject.AddComponent<UIDynamicCanvasFollower>();
            var mode = tag ? tag.updateMode : FollowUpdateMode.EventDriven;
            var throttle = tag ? tag.throttleFrames : 1;
            var wEnable = tag ? tag.warmupEnabled : true;
            var wMax = tag ? tag.warmupMaxRenders : 8;
            var wStable = tag ? tag.warmupStableRenders : 2;
            var wEps = tag ? tag.warmupEpsilonPx : 0.25f;

            follower.Setup(reference ? reference : target, dynRoot, canvas,
                           mode, throttle,
                           wEnable, wMax, wStable, wEps);
        }

        RectTransform CreateReferenceClone(RectTransform src)
        {
            var go = new GameObject($"{src.name}_Reference", typeof(RectTransform));
            var refRt = go.GetComponent<RectTransform>();
            refRt.SetParent(src.parent, false);

            refRt.anchorMin = src.anchorMin;
            refRt.anchorMax = src.anchorMax;
            refRt.pivot = src.pivot;
            refRt.anchoredPosition = src.anchoredPosition;
            refRt.sizeDelta = src.sizeDelta;
            refRt.localScale = src.localScale;
            refRt.localRotation = src.localRotation;

            go.hideFlags = HideFlags.DontSaveInBuild | HideFlags.DontSaveInEditor;
            return refRt;
        }

        void OnRectTransformDimensionsChange()
        {
            if (!_bound) return;

            var cur = new Vector2Int(Screen.width, Screen.height);
            if (cur == _lastScreenSize) return;
            _lastScreenSize = cur;

            // ȭ�� ȸ��/�ػ� ���� ��: ���� �纸�� + ���־� ���û
            foreach (var grp in dynamicGroups)
            {
                if (!grp) continue;

                var tag = grp.GetComponent<UIDynamicGroupTag>();
                var dynRoot = (tag && tag.overrideDynamicRoot) ? tag.overrideDynamicRoot : dynamicCanvasRoot;
                var canvas = (tag && tag.overrideRootCanvas) ? tag.overrideRootCanvas : _rootCanvas;

                if (_referenceMap.TryGetValue(grp, out var refRt) && refRt)
                    RectTransformAnchorUtils.FitSelfToReferenceScreenRect(refRt, grp, dynRoot, canvas);
                else
                    RectTransformAnchorUtils.FitToParentAuto(grp, dynRoot, canvas);

                var f = grp.GetComponent<UIDynamicCanvasFollower>();
                f?.ForceSync();
                f?.RequestWarmup();
            }
        }
    }
}
