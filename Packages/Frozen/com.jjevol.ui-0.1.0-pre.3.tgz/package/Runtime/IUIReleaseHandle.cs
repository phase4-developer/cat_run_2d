namespace jjevol
{
    // 어떤 UI든 자기를 관리하는 매니저에게 해제를 요청할 수 있는 공통 규격
    public interface IUIReleaseHandle
    {
        void Release(UIBase ui);
    }
}