using System;
using System.Runtime.ExceptionServices;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    public enum UIFaderTransitionType
    {
        None = 0,
        ColorFade = 1,
        ShaderProgress = 2,
    }

    [Serializable]
    public class UIFaderTransitionOption
    {
        public UIFaderTransitionType transitionType = UIFaderTransitionType.ColorFade;

        [Header("Duration")]
        public float fadeInDuration = 0.3f;
        public float fadeOutDuration = 0.3f;

        [Header("Color")]
        public Color color = Color.black;

        [Header("Canvas Sorting")]
        public bool overrideSortingOrder = false;
        public int sortingOrder = 200;

        [Header("Loading Indicator")]
        public bool showLoadingIndicator = false;
        public string loadingIndicatorKey = "UITransition";

        [Header("Shader Progress")]
        public Material transitionMaterial;
        public string progressProperty = "_Progress";
        public float hiddenProgress = 0f;
        public float coveredProgress = 1f;
        public AnimationCurve curve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

        public static UIFaderTransitionOption DefaultFade()
        {
            return new UIFaderTransitionOption
            {
                transitionType = UIFaderTransitionType.None,
                fadeInDuration = 0.3f,
                fadeOutDuration = 0.3f,
                color = Color.black,
                overrideSortingOrder = false,
                sortingOrder = 200,
                showLoadingIndicator = true
            };
        }

        public static UIFaderTransitionOption ColorFade(Color color, float duration)
        {
            return new UIFaderTransitionOption
            {
                transitionType = UIFaderTransitionType.ColorFade,
                fadeInDuration = duration,
                fadeOutDuration = duration,
                color = color,
                overrideSortingOrder = false,
                sortingOrder = 200
            };
        }

        public static UIFaderTransitionOption LoadingOnly(string key = "UITransition")
        {
            return new UIFaderTransitionOption
            {
                transitionType = UIFaderTransitionType.None,
                showLoadingIndicator = true,
                loadingIndicatorKey = key
            };
        }
    }

    [DisallowMultipleComponent]
    public sealed class UIFader : MonoBehaviour
    {
        [Header("Refs")]
        [SerializeField] private Canvas fadeCanvas;
        [SerializeField] private Image fadeImage;

        [Header("Behaviour")]
        [SerializeField] private bool deactivateWhenHidden = true;
        [SerializeField] private bool blockInputWhileFading = true;

        public bool IsFading { get; private set; }
        public bool IsVisible => gameObject.activeSelf && fadeImage != null && fadeImage.color.a > 0f;

        private CancellationTokenSource _cts;

        private bool _hasSavedCanvasSorting;
        private bool _savedOverrideSorting;
        private int _savedSortingOrder;

        private bool _hasSavedMaterial;
        private Material _savedMaterial;

        private void Reset()
        {
            ResolveRefs();
        }

        // Public entry points call this too: a fader saved inactive has not run Awake when it is first used.
        private void ResolveRefs()
        {
            if (fadeCanvas == null)
                fadeCanvas = GetComponent<Canvas>();

            if (fadeImage == null)
                fadeImage = GetComponentInChildren<Image>(true);
        }

        private void Awake()
        {
            ResolveRefs();

            if (fadeImage != null)
                fadeImage.raycastTarget = false;

            if (deactivateWhenHidden)
                gameObject.SetActive(false);
        }

        private void OnDisable()
        {
            CancelRunning();
        }

        private int _runVersion;
        private void CancelRunning()
        {
            _runVersion++;
            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
                _cts = null;
            }

            RestoreCanvasSortingOrder();
            RestoreTransitionMaterial();

            IsFading = false;
        }

        private void EnsureActive()
        {
            if (gameObject.activeSelf)
                return;

            gameObject.SetActive(true);

            // A fader saved inactive runs Awake here, which hides it again when deactivateWhenHidden is set.
            if (!gameObject.activeSelf)
                gameObject.SetActive(true);
        }

        private CancellationToken BeginFade(UIFaderTransitionOption option = null)
        {
            CancelRunning();

            // Activate first: the first activation runs Awake, whose OnDisable clears run state.
            EnsureActive();

            ApplyCanvasSortingOrder(option);

            _cts = new CancellationTokenSource();

            if (fadeImage != null && blockInputWhileFading)
                fadeImage.raycastTarget = true;

            IsFading = true;

            return _cts.Token;
        }

        private void EndFade(bool fullyHidden, int version)
        {
            if (version != _runVersion) return;
            if (fadeImage != null)
                fadeImage.raycastTarget = false;

            RestoreCanvasSortingOrder();
            RestoreTransitionMaterial();

            IsFading = false;

            if (_cts != null)
            {
                _cts.Dispose();
                _cts = null;
            }

            if (fullyHidden && deactivateWhenHidden && gameObject.activeSelf)
                gameObject.SetActive(false);
        }

        private CancellationToken BeginTransitionLock()
        {
            CancelRunning();

            _cts = new CancellationTokenSource();
            IsFading = true;

            return _cts.Token;
        }

        private void EndTransitionLock(int version)
        {
            if (version != _runVersion) return;
            RestoreCanvasSortingOrder();

            IsFading = false;

            if (_cts != null)
            {
                _cts.Dispose();
                _cts = null;
            }
        }

        private void ApplyCanvasSortingOrder(UIFaderTransitionOption option)
        {
            if (fadeCanvas == null)
                return;

            _hasSavedCanvasSorting = true;
            _savedOverrideSorting = fadeCanvas.overrideSorting;
            _savedSortingOrder = fadeCanvas.sortingOrder;

            if (option == null)
                return;

            if (!option.overrideSortingOrder)
                return;

            fadeCanvas.overrideSorting = true;
            fadeCanvas.sortingOrder = option.sortingOrder;
        }

        private void RestoreCanvasSortingOrder()
        {
            if (!_hasSavedCanvasSorting)
                return;

            if (fadeCanvas != null)
            {
                fadeCanvas.overrideSorting = _savedOverrideSorting;
                fadeCanvas.sortingOrder = _savedSortingOrder;
            }

            _hasSavedCanvasSorting = false;
        }

        private void ApplyTransitionMaterial(Material material)
        {
            _hasSavedMaterial = true;
            _savedMaterial = fadeImage.material;
            fadeImage.material = material;
        }

        // 실행 버전과 무관하다. 비활성화와 새 전환이 CancelRunning으로 끝낸 실행도 여기서 원래 material로 돌아간다.
        private void RestoreTransitionMaterial()
        {
            if (!_hasSavedMaterial)
                return;

            if (fadeImage != null)
                fadeImage.material = _savedMaterial;

            _hasSavedMaterial = false;
            _savedMaterial = null;
        }

        public async UniTask FadeAsync(Color from, Color to, float duration)
        {
            ResolveRefs();

            if (fadeImage == null)
                return;

            var option = UIFaderTransitionOption.DefaultFade();
            var ct = BeginFade(option);
            int version = _runVersion;

            try
            {
                await AnimateColorAsync(from, to, duration, ct);
                EndFade(to.a <= 0.0001f, version);
            }
            catch (OperationCanceledException)
            {
            }
        }

        public UniTask FadeIn(float duration = 0.3f, Color? color = null)
        {
            Color c = color ?? Color.black;
            c.a = 1f;

            return FadeAsync(new Color(c.r, c.g, c.b, 0f), c, duration);
        }

        public UniTask FadeOut(float duration = 0.3f)
        {
            ResolveRefs();

            Color from = fadeImage != null ? fadeImage.color : new Color(0, 0, 0, 1);
            Color to = from;
            to.a = 0f;

            return FadeAsync(from, to, duration);
        }

        public async UniTask FadeInOut(
            Func<UniTask> midAction,
            Action endAction = null,
            float duration = 0.3f,
            Color? color = null)
        {
            Color fadeColor = color ?? Color.black;

            var option = UIFaderTransitionOption.ColorFade(fadeColor, duration);

            await PlayTransitionAsync(
                midAction,
                endAction,
                option
            );
        }

        //추가
        public async UniTask PlayTransitionAsync(
            Func<UniTask> midAction,
            Action endAction = null,
            UIFaderTransitionOption option = null)
        {
            option ??= UIFaderTransitionOption.DefaultFade();

            ResolveRefs();

            if (option.transitionType == UIFaderTransitionType.None || fadeImage == null)
            {
                var ct = BeginTransitionLock();
                int version = _runVersion;

                try
                {
                    await RunMidActionWithLoadingIndicatorAsync(midAction, option);

                    ct.ThrowIfCancellationRequested();

                    endAction?.Invoke();
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                }
                finally
                {
                    EndTransitionLock(version);
                }

                return;
            }

            if (fadeImage == null)
            {
                if (midAction != null)
                    await midAction();

                endAction?.Invoke();
                return;
            }

            switch (option.transitionType)
            {
                case UIFaderTransitionType.ShaderProgress:
                    await PlayShaderProgressTransitionAsync(midAction, endAction, option);
                    break;

                case UIFaderTransitionType.ColorFade:
                default:
                    await PlayColorFadeTransitionAsync(midAction, endAction, option);
                    break;
            }
        }

        private async UniTask PlayColorFadeTransitionAsync(
            Func<UniTask> midAction,
            Action endAction,
            UIFaderTransitionOption option)
        {
            Color c = option.color;
            c.a = 1f;

            Color hiddenColor = new Color(c.r, c.g, c.b, 0f);
            Color coveredColor = c;

            var ct = BeginFade(option);
            int version = _runVersion;
            ExceptionDispatchInfo failure = null;

            try
            {
                await AnimateColorAsync(hiddenColor, coveredColor, option.fadeInDuration, ct);

                failure = await CaptureMidActionFailureAsync(midAction, option, ct);

                await AnimateColorAsync(coveredColor, hiddenColor, option.fadeOutDuration, ct);

                failure = InvokeEndAction(endAction, failure);

                EndFade(true, version);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
            }

            failure?.Throw();
        }

        private async UniTask PlayShaderProgressTransitionAsync(
            Func<UniTask> midAction,
            Action endAction,
            UIFaderTransitionOption option)
        {
            if (option.transitionMaterial == null)
            {
                await PlayColorFadeTransitionAsync(midAction, endAction, option);
                return;
            }

            if (!option.transitionMaterial.HasProperty(option.progressProperty))
            {
                Debug.LogWarning($"[UIFader] Transition material does not have property: {option.progressProperty}");
                await PlayColorFadeTransitionAsync(midAction, endAction, option);
                return;
            }

            var ct = BeginFade(option);
            int version = _runVersion;

            Material runtimeMaterial = Instantiate(option.transitionMaterial);
            ExceptionDispatchInfo failure = null;

            try
            {
                ApplyTransitionMaterial(runtimeMaterial);

                Color c = option.color;
                c.a = 1f;
                fadeImage.color = c;

                await AnimateMaterialFloatAsync(
                    runtimeMaterial,
                    option.progressProperty,
                    option.hiddenProgress,
                    option.coveredProgress,
                    option.fadeInDuration,
                    option.curve,
                    ct
                );

                failure = await CaptureMidActionFailureAsync(midAction, option, ct);

                await AnimateMaterialFloatAsync(
                    runtimeMaterial,
                    option.progressProperty,
                    option.coveredProgress,
                    option.hiddenProgress,
                    option.fadeOutDuration,
                    option.curve,
                    ct
                );

                failure = InvokeEndAction(endAction, failure);

                EndFade(true, version);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
            }
            finally
            {
                // 성공과 midAction 실패는 EndFade가, 취소는 CancelRunning이 복원한다. 남은 경로는 예기치 않은 예외다.
                if (version == _runVersion)
                    RestoreTransitionMaterial();

                if (runtimeMaterial != null)
                    Destroy(runtimeMaterial);
            }

            failure?.Throw();
        }

        // midAction 실패로 화면이 덮인 채 끝나면 안 되므로 페이드 아웃 뒤에 전달한다.
        // fader 자체 취소만 삼키고, midAction이 던진 취소는 일반 실패처럼 전달한다.
        private async UniTask<ExceptionDispatchInfo> CaptureMidActionFailureAsync(
            Func<UniTask> midAction,
            UIFaderTransitionOption option,
            CancellationToken ct)
        {
            try
            {
                await RunMidActionWithLoadingIndicatorAsync(midAction, option);
            }
            catch (Exception exception) when (!ct.IsCancellationRequested)
            {
                return ExceptionDispatchInfo.Capture(exception);
            }

            ct.ThrowIfCancellationRequested();

            return null;
        }

        private static ExceptionDispatchInfo InvokeEndAction(Action endAction, ExceptionDispatchInfo failure)
        {
            if (failure != null)
                return failure;

            try
            {
                endAction?.Invoke();
                return null;
            }
            catch (Exception exception)
            {
                return ExceptionDispatchInfo.Capture(exception);
            }
        }

        private async UniTask AnimateColorAsync(
            Color from,
            Color to,
            float duration,
            CancellationToken ct)
        {
            if (fadeImage == null)
                return;

            fadeImage.color = from;

            if (duration <= 0f)
            {
                fadeImage.color = to;
                return;
            }

            float t = 0f;

            while (t < duration)
            {
                ct.ThrowIfCancellationRequested();

                t += Time.unscaledDeltaTime;
                float normalized = Mathf.Clamp01(t / duration);

                fadeImage.color = Color.LerpUnclamped(from, to, normalized);

                await UniTask.Yield(PlayerLoopTiming.Update, ct);
            }

            fadeImage.color = to;
        }

        private async UniTask AnimateMaterialFloatAsync(
            Material material,
            string propertyName,
            float from,
            float to,
            float duration,
            AnimationCurve curve,
            CancellationToken ct)
        {
            if (material == null)
                return;

            if (duration <= 0f)
            {
                material.SetFloat(propertyName, to);
                return;
            }

            float t = 0f;

            while (t < duration)
            {
                ct.ThrowIfCancellationRequested();

                t += Time.unscaledDeltaTime;

                float normalized = Mathf.Clamp01(t / duration);
                float eased = curve != null ? curve.Evaluate(normalized) : normalized;
                float value = Mathf.LerpUnclamped(from, to, eased);

                material.SetFloat(propertyName, value);

                await UniTask.Yield(PlayerLoopTiming.Update, ct);
            }

            material.SetFloat(propertyName, to);
        }

        private async UniTask RunMidActionWithLoadingIndicatorAsync(
            Func<UniTask> midAction,
            UIFaderTransitionOption option)
        {
            if (midAction == null)
                return;

            bool useLoadingIndicator =
                option != null &&
                option.showLoadingIndicator;

            string key = option != null && !string.IsNullOrEmpty(option.loadingIndicatorKey)
                ? option.loadingIndicatorKey
                : "UITransition";

            if (!useLoadingIndicator)
            {
                await midAction();
                return;
            }

            using (LoadingIndicator.Scope(key))
            {
                await midAction();
            }
        }

        public void ShowImmediate(Color? color = null)
        {
            CancelRunning();

            Color c = color ?? Color.black;
            c.a = 1f;

            EnsureActive();

            if (fadeImage != null)
            {
                fadeImage.color = c;
                fadeImage.raycastTarget = false;
            }
        }

        public void HideImmediate()
        {
            CancelRunning();

            ResolveRefs();

            if (fadeImage != null)
            {
                Color c = fadeImage.color;
                c.a = 0f;
                fadeImage.color = c;
                fadeImage.raycastTarget = false;
            }

            if (deactivateWhenHidden && gameObject.activeSelf)
                gameObject.SetActive(false);
        }
    }
}
