using System;
using System.Text;
using UnityEngine;
namespace jjevol { internal static class UINumberFormatting {
private static readonly string[] symbol = { "K", "M", "B", "T" };
private static readonly string[] symbol_KOR = { "만", "억", "조", "경" };
public static string ConvertNumberToSymbolNumber_Localize(decimal number, string format = "{0:#,0}")
    {
        if (UIRuntimeOptions.CurrentLanguage == "ko-KR" || UIRuntimeOptions.CurrentLanguage == "ko")
            return ConvertNumberToSymbolNumber_KOR(format, number);
        else
            return ConvertNumberToSymbolNumber(format, number);
    }
public static string ConvertNumberToSymbolNumber(string format, decimal number)
    {
        decimal value = number;
        decimal[] cVal = new decimal[symbol.Length + 1];
        int index = 0;
        for (; index < cVal.Length; index++)
        {
            if (value >= 1000)
            {
                cVal[index] = value % 1000;
                value = decimal.Floor(value / 1000);
            }
            else
            {
                cVal[index] = value;
                value -= value;
                break;
            }
        }

        index = Mathf.Min(index, cVal.Length - 1);

        if (value > 0)
            cVal[index] += (value * 1000);

        StringBuilder sb = new StringBuilder();

        if (index > 0)
        {
            if (cVal[index] > 10)
            {
                sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, decimal.Floor((cVal[index] + (cVal[index - 1] / 1000)) * 100) / 100));
                sb.Append(symbol[index - 1]);
            }
            else if (index > 1)
            {
                sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, (cVal[index] * 1000 + cVal[index - 1])));
                sb.Append(symbol[index - 2]);
            }
            else
            {
                sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, (cVal[index] * 1000 + cVal[index - 1])));
            }
        }
        else
        {
            sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, cVal[0]));
        }

        return sb.ToString();
    }
public static string ConvertNumberToSymbolNumber_KOR(string format, decimal number)
    {
        decimal value = number;
        decimal[] cVal = new decimal[symbol_KOR.Length + 1];
        int index = 0;
        for (; index < cVal.Length; index++)
        {
            if (value >= 10000)
            {
                cVal[index] = value % 10000;
                value = decimal.Floor(value / 10000);
            }
            else
            {
                cVal[index] = value;
                value -= value;
                break;
            }
        }

        index = Mathf.Min(index, cVal.Length - 1);

        if (value > 0)
            cVal[index] += (value * 10000);

        StringBuilder sb = new StringBuilder();

        if (index > 0)
        {
            int insert = 0;

            for (int i = index; i > 0; i--)
            {
                if (cVal[i] > 0)
                {
                    if (insert > 0)
                        sb.Append(" ");

                    sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, cVal[i]));
                    sb.Append(symbol_KOR[i - 1]);
                    insert++;

                    if (insert >= 2)
                        break;
                }
            }

            if (insert == 0)
            {
                sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, cVal[0]));
            }
            else if (insert == 1 && cVal[0] > 0)
            {
                sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, decimal.Floor(cVal[0])));
            }
        }
        else
        {
            sb.Append(string.Format(UIRuntimeOptions.DisplayCulture, format, cVal[0]));
        }

        return sb.ToString();
    }
} }
