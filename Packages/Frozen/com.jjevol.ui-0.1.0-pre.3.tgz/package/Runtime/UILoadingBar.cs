using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    /// <summary>
    /// 진행률 표시의 기본 구현이다. Image Fill과 Slider 중 연결된 쪽에 표시하고, 증가는 부드럽게, 감소는 즉시 반영한다.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class UILoadingBar : MonoBehaviour, IUILoadingProgressView
    {
        [SerializeField, Tooltip("Filled 타입 Image. fillAmount로 진행률을 표시한다.")] private Image fillImage;
        [SerializeField, Tooltip("Slider. normalizedValue로 진행률을 표시한다.")] private Slider slider;
        [SerializeField, Tooltip("선택 문구 표시.")] private TMP_Text messageText;
        [SerializeField, Min(0f), Tooltip("초당 증가량(unscaled). 0이면 즉시 반영한다.")] private float fillSpeed = 2f;

        private float _target;
        private float _displayed;
        private bool _progressReceived;

        public float Progress => _target;
        public float DisplayedProgress => _displayed;

        public void SetProgress(float progress01)
        {
            if (float.IsNaN(progress01)) return;

            _target = Mathf.Clamp01(progress01);

            bool jump = _target < _displayed || fillSpeed <= 0f;
            if (jump)
                _displayed = _target;

            // 첫 값은 표시값과 같아도 적용해 Prefab에 남은 값을 지운다.
            if (jump || !_progressReceived)
                ApplyDisplayed();

            _progressReceived = true;
        }

        public void SetMessage(string message)
        {
            if (messageText != null)
                messageText.text = message ?? string.Empty;
        }

        private void OnEnable()
        {
            ApplyDisplayed();
        }

        private void Update()
        {
            if (Mathf.Approximately(_displayed, _target)) return;

            _displayed = Mathf.MoveTowards(_displayed, _target, fillSpeed * Time.unscaledDeltaTime);
            ApplyDisplayed();
        }

        private void ApplyDisplayed()
        {
            if (fillImage != null)
                fillImage.fillAmount = _displayed;

            if (slider != null)
                slider.normalizedValue = _displayed;
        }
    }
}
