# Changelog

## 0.1.0-pre.3 — PlayerPrefs AES consolidation

Replaced the file backend with Unity PlayerPrefs and two alternating encrypted revisions. Removed path APIs, the file constructor, File.Replace/temporary-file/lock/archive protocols and their dedicated active tests. Historical logs and frozen candidates are preserved outside the package. Codec output now always requires a key. Corruption blocks normal opening/writing; explicit backup salvage is read-only. Unconfirmed writes preserve live memory and require outcome reconciliation before another mutation. Added real PlayerPrefs tests and an ignored independent Player QA harness. Consumers require an explicit API/key/profile migration after internal platform gates pass.

## 0.1.0-pre.2 — STEP 06-SAVE-R1 internal candidate

Game-provided AES-256-CBC/HMAC-SHA256 protection is required for repository writes. Existing Codec/Repository/Session constructor signatures and the inner v1 document schema remain available. Existing plaintext can be inspected with the legacy codec; it is never migrated or overwritten automatically. Missing keys, plaintext in a protected profile, unknown encryption versions/key IDs and oversized files block writes.

Windows error 1175 permits at most two replacement retries while the exact staged candidate, main and backup bytes are unchanged under both locks. Other error codes and uncertain/foreign states stop. Exact persisted main candidates are reconciled without applying a second mutation.

## 0.1.0-pre.1

Initial extraction from mobile ac18cfbdea56f03447a7d5927395d6bc88ddfd9f. Validation results are recorded outside the package.
