using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;

namespace jjevol.Tests
{
    public sealed class LocalSaveTests
    {
        private string _profile;
        private LocalSaveCodec _codec;
        private LocalSaveRepository _repository;
        private const string Prefix = "qa.playerprefs.r1";
        private static readonly byte[] Key = Enumerable.Range(0, 32).Select(i => (byte)i).ToArray(); // Synthetic only.
        [SetUp] public void SetUp()
        {
            _profile = "qa:" + Guid.NewGuid().ToString("N");
            _codec = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("synthetic-v1", Key));
            _repository = new LocalSaveRepository(_profile, _codec, Prefix);
        }
        [TearDown] public void TearDown()
        { PlayerPrefs.DeleteKey(_repository.Slot0Key); PlayerPrefs.DeleteKey(_repository.Slot1Key); PlayerPrefs.Save(); }
        private static LocalSaveSnapshot Snapshot(int value) => new LocalSaveSnapshot(new JObject { ["progress"] = value, ["private"] = "SYNTHETIC-PRIVATE-PROGRESS" });
        private string[] Values() => new[] { PlayerPrefs.GetString(_repository.Slot0Key), PlayerPrefs.GetString(_repository.Slot1Key) };

        [Test] public void RealPlayerPrefsInitialFirstAndContinuousUpdatesReopen()
        {
            Assert.That(_repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.Missing));
            var session = LocalSaveSession.Open(_repository, () => Snapshot(0));
            for (int i = 1; i <= 24; i++) session.CommitMutation(i - 1, Snapshot(i));
            var restored = LocalSaveSession.Open(new LocalSaveRepository(_profile, _codec, Prefix));
            Assert.That(restored.StateRevision, Is.EqualTo(24)); Assert.That((int)restored.Snapshot.Payload["progress"], Is.EqualTo(24));
            var revisions = new[] { _repository.Slot0Key, _repository.Slot1Key }.Select(key => _codec.Decode(Convert.FromBase64String(PlayerPrefs.GetString(key)), _profile).StateRevision).OrderBy(x => x).ToArray();
            Assert.That(revisions, Is.EqualTo(new long[] { 23, 24 }));
            foreach (string value in Values()) { byte[] wire = Convert.FromBase64String(value); Assert.That(Encoding.UTF8.GetString(wire), Does.Not.Contain("SYNTHETIC-PRIVATE-PROGRESS")); Assert.That(wire.Take(8), Is.EqualTo(new byte[] { 74, 74, 69, 83, 65, 86, 69, 0 })); }
        }
        [Test] public void SnapshotAndDocumentExposeCopies()
        {
            var payload = new JObject { ["x"] = 1 }; var snapshot = new LocalSaveSnapshot(payload); payload["x"] = 9; snapshot.Payload["x"] = 8;
            Assert.That((int)snapshot.Payload["x"], Is.EqualTo(1));
        }
        [Test] public void NoKeyCannotReadOrWriteAndDoesNotTouchPreferences()
        {
            var spy = new FakePreferences(); var plain = new LocalSaveRepository(_profile, new LocalSaveCodec(), Prefix, spy);
            Assert.That(plain.Load().Status, Is.EqualTo(LocalSaveLoadStatus.ProtectionFailed));
            Assert.Throws<LocalSaveProtectionException>(() => plain.Save(Snapshot(1), null)); Assert.That(spy.Reads, Is.Zero); Assert.That(spy.Values, Is.Empty);
            Assert.Throws<LocalSaveProtectionException>(() => new LocalSaveCodec().Encode(Snapshot(1), _profile, 0, DateTime.UtcNow));
        }
        [Test] public void MissingProfileRequiresExplicitInitialData()
        { Assert.Throws<InvalidOperationException>(() => LocalSaveSession.Open(_repository)); Assert.That(Values(), Is.EqualTo(new[] { "", "" })); }
        [Test] public void StaleRevisionAndSameRevisionDifferentDocumentAreRejected()
        {
            var session = LocalSaveSession.Open(_repository, () => Snapshot(0)); var basis = session.Current;
            _repository.Save(Snapshot(1), basis); var bytes = Values();
            Assert.Throws<LocalSaveConflictException>(() => session.CommitMutation(0, Snapshot(2))); Assert.That(session.StateRevision, Is.Zero); Assert.That(Values(), Is.EqualTo(bytes));
            PlayerPrefs.DeleteKey(_repository.Slot1Key); PlayerPrefs.SetString(_repository.Slot0Key, Convert.ToBase64String(_codec.Encode(Snapshot(99), _profile, 0, DateTime.UtcNow)));
            Assert.Throws<LocalSaveConflictException>(() => _repository.Save(Snapshot(2), basis));
        }
        [Test] public void InvalidRevisionAndOverflowDoNotWrite()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => _repository.Save(Snapshot(1), 2, -1));
            PlayerPrefs.SetString(_repository.Slot0Key, Convert.ToBase64String(_codec.Encode(Snapshot(1), _profile, long.MaxValue, DateTime.UtcNow)));
            var basis = _repository.Load().Document; var before = Values(); Assert.Throws<OverflowException>(() => _repository.Save(Snapshot(2), basis)); Assert.That(Values(), Is.EqualTo(before));
        }
        [TestCase(false)] [TestCase(true)] public void WrongKeyNeverInitializesOrOverwrites(bool differentId)
        {
            LocalSaveSession.Open(_repository, () => Snapshot(0)); var before = Values();
            var wrong = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption(differentId ? "other-v1" : "synthetic-v1", Key.Reverse().ToArray()));
            var repository = new LocalSaveRepository(_profile, wrong, Prefix);
            Assert.That(repository.Load().Success, Is.False); Assert.That(repository.LoadRecovery().Success, Is.False);
            Assert.Throws<InvalidDataException>(() => LocalSaveSession.Open(repository, () => Snapshot(99))); Assert.That(Values(), Is.EqualTo(before));
        }
        [Test] public void DamagedSlotBlocksNormalOpenButExplicitSalvageIsReadOnly()
        {
            var session = LocalSaveSession.Open(_repository, () => Snapshot(0)); session.CommitMutation(0, Snapshot(1));
            byte[] wire = Convert.FromBase64String(PlayerPrefs.GetString(_repository.Slot1Key)); wire[wire.Length - 1] ^= 1;
            PlayerPrefs.SetString(_repository.Slot1Key, Convert.ToBase64String(wire)); var before = Values();
            Assert.That(_repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.Corrupt)); Assert.Throws<InvalidDataException>(() => LocalSaveSession.Open(_repository));
            var recovery = _repository.LoadRecovery(); Assert.That(recovery.Status, Is.EqualTo(LocalSaveLoadStatus.RecoveredBackup)); Assert.That(recovery.Document.StateRevision, Is.Zero);
            Assert.Throws<InvalidDataException>(() => _repository.Save(Snapshot(2), recovery.Document)); Assert.That(Values(), Is.EqualTo(before));
        }
        [TestCase("{\"old\":1}")] [TestCase("{\"old\":")] public void LegacyBase64PlaintextRequiresExplicitMigration(string legacy)
        {
            PlayerPrefs.SetString(_repository.Slot0Key, Convert.ToBase64String(Encoding.UTF8.GetBytes(legacy))); var before = Values();
            Assert.That(_repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.ProtectionFailed)); Assert.That(_repository.LoadRecovery().Success, Is.False);
            Assert.Throws<InvalidDataException>(() => LocalSaveSession.Open(_repository, () => Snapshot(99))); Assert.That(Values(), Is.EqualTo(before));
        }
        [Test] public void OldMobileKeyAndFileDataAreNeverReadMigratedOrDeleted()
        {
            string legacy = "qa.legacy." + Guid.NewGuid().ToString("N"); PlayerPrefs.SetString(legacy, "legacy-synthetic");
            try { LocalSaveSession.Open(_repository, () => Snapshot(0)); Assert.That(PlayerPrefs.GetString(legacy), Is.EqualTo("legacy-synthetic")); }
            finally { PlayerPrefs.DeleteKey(legacy); }
        }
        [TestCase(8)] [TestCase(9)] public void UnsupportedWireFormatInEitherSlotBlocksRecovery(int offset)
        {
            var session = LocalSaveSession.Open(_repository, () => Snapshot(0)); session.CommitMutation(0, Snapshot(1));
            byte[] wire = Convert.FromBase64String(PlayerPrefs.GetString(_repository.Slot0Key)); wire[offset] = 99; PlayerPrefs.SetString(_repository.Slot0Key, Convert.ToBase64String(wire));
            Assert.That(_repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.ProtectionFailed)); Assert.That(_repository.LoadRecovery().Success, Is.False);
        }
        [Test] public void OversizeStoredValueIsPreservedAndBlocksInitialization()
        {
            string value = new string('A', LocalSaveRepository.MaxStoredCharacters + 1); PlayerPrefs.SetString(_repository.Slot0Key, value);
            Assert.That(_repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.ProtectionFailed)); Assert.Throws<InvalidDataException>(() => LocalSaveSession.Open(_repository, () => Snapshot(1))); Assert.That(PlayerPrefs.GetString(_repository.Slot0Key), Is.EqualTo(value));
        }
        [Test] public void TwoProfilesAndCaseSensitiveKeysRemainSeparate()
        {
            var other = new LocalSaveRepository(_profile.ToUpperInvariant(), _codec, Prefix);
            try { LocalSaveSession.Open(_repository, () => Snapshot(7)); LocalSaveSession.Open(other, () => Snapshot(9)); Assert.That((int)_repository.Load().Document.Snapshot.Payload["progress"], Is.EqualTo(7)); Assert.That((int)other.Load().Document.Snapshot.Payload["progress"], Is.EqualTo(9)); }
            finally { PlayerPrefs.DeleteKey(other.Slot0Key); PlayerPrefs.DeleteKey(other.Slot1Key); }
        }
        [TestCase("set")] [TestCase("flush")] [TestCase("readback")] public void UnconfirmedSavePreservesPreviousSlotAndSessionAndForbidsRetry(string phase)
        {
            var prefs = new FakePreferences(); var repository = new LocalSaveRepository(_profile, _codec, Prefix, prefs);
            var session = LocalSaveSession.Open(repository, () => Snapshot(0)); string previous = prefs.Values[repository.Slot0Key]; prefs.Failure = phase;
            Assert.Throws<LocalSaveWriteException>(() => session.CommitMutation(0, Snapshot(1))); Assert.That(session.StateRevision, Is.Zero); Assert.That((int)session.Snapshot.Payload["progress"], Is.Zero);
            Assert.That(prefs.Values[repository.Slot0Key], Is.EqualTo(previous)); Assert.That(repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.StorageUnavailable)); Assert.Throws<InvalidOperationException>(() => session.CommitMutation(0, Snapshot(1)));
        }
        [Test] public void ReentrantAndForeignThreadAccessFailBeforeChangingPrefs()
        {
            var prefs = new FakePreferences(); var repository = new LocalSaveRepository(_profile, _codec, Prefix, prefs);
            prefs.OnSet = () => { Assert.Throws<InvalidOperationException>(() => repository.Load()); Assert.Throws<InvalidOperationException>(() => repository.Save(Snapshot(9), null)); };
            LocalSaveSession.Open(repository, () => Snapshot(0));
            var task = Task.Run(() => { Assert.Throws<InvalidOperationException>(() => repository.Load()); }); task.GetAwaiter().GetResult(); Assert.That(repository.Load().Document.StateRevision, Is.Zero);
        }
        [TestCase(0)] [TestCase(4)] public void ForkedOrNonconsecutiveSlotsAreNotOneHistory(int secondRevision)
        {
            PlayerPrefs.SetString(_repository.Slot0Key, Convert.ToBase64String(_codec.Encode(Snapshot(0), _profile, 0, DateTime.UtcNow)));
            PlayerPrefs.SetString(_repository.Slot1Key, Convert.ToBase64String(_codec.Encode(Snapshot(9), _profile, secondRevision, DateTime.UtcNow)));
            Assert.That(_repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.Corrupt)); Assert.That(_repository.LoadRecovery().Success, Is.False);
        }
        private sealed class FakePreferences : ILocalSavePreferences
        {
            public readonly Dictionary<string, string> Values = new Dictionary<string, string>();
            public int Reads; public string Failure; public Action OnSet;
            public bool HasKey(string key) { Reads++; return Values.ContainsKey(key); }
            public string GetString(string key) { Reads++; return Failure == "readback" && key.EndsWith(":1", StringComparison.Ordinal) ? "wrong-readback" : Values[key]; }
            public void SetString(string key, string value) { if (Failure == "set") throw new IOException("synthetic set failure"); OnSet?.Invoke(); Values[key] = value; }
            public void Save() { if (Failure == "flush") throw new IOException("synthetic flush failure"); }
        }
    }
}