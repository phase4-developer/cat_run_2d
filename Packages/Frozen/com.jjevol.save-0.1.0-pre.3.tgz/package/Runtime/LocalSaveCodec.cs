using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace jjevol
{
    public interface ILocalSaveMigration
    {
        int FromVersion { get; }
        JObject Migrate(JObject payload);
    }

    public sealed class UnsupportedLocalSaveVersionException : IOException
    {
        public int SaveVersion { get; }
        public UnsupportedLocalSaveVersionException(int version) : base("Unsupported local save version: " + version) { SaveVersion = version; }
    }

    public sealed class LocalSaveMigrationException : IOException
    {
        public LocalSaveMigrationException(string message, Exception inner = null) : base(message, inner) { }
    }

    public sealed class LocalSaveDocument
    {
        public int SaveVersion { get; }
        public int OriginalVersion { get; }
        public string ProfileId { get; }
        public long StateRevision { get; }
        public DateTime SavedAtUtc { get; }
        public LocalSaveSnapshot Snapshot { get; }
        public bool WasMigrated => OriginalVersion != SaveVersion;
        internal string SourceHash { get; }
        internal JObject ExtraEnvelope { get; }
        public bool Matches(LocalSaveDocument other) => other != null && ProfileId == other.ProfileId && StateRevision == other.StateRevision && SourceHash == other.SourceHash;

        internal LocalSaveDocument(int originalVersion, string profileId, long stateRevision, DateTime savedAtUtc, LocalSaveSnapshot snapshot, string sourceHash, JObject extraEnvelope)
        {
            SaveVersion = LocalSaveCodec.CurrentVersion;
            OriginalVersion = originalVersion;
            ProfileId = profileId;
            StateRevision = stateRevision;
            SavedAtUtc = savedAtUtc;
            Snapshot = snapshot;
            SourceHash = sourceHash;
            ExtraEnvelope = extraEnvelope;
        }
    }

    public sealed class LocalSaveCodec
    {
        public const int CurrentVersion = 1;
        private readonly Dictionary<int, ILocalSaveMigration> _migrations = new Dictionary<int, ILocalSaveMigration>();
        private readonly LocalSaveEncryption _encryption;
        public bool IsEncrypted => _encryption != null;

        public LocalSaveCodec(IEnumerable<ILocalSaveMigration> migrations = null) : this(migrations, null) { }

        public LocalSaveCodec(IEnumerable<ILocalSaveMigration> migrations, LocalSaveEncryption encryption)
        {
            _encryption = encryption;
            foreach (ILocalSaveMigration migration in migrations ?? Array.Empty<ILocalSaveMigration>())
            {
                if (migration == null || migration.FromVersion < 0 || migration.FromVersion >= CurrentVersion || _migrations.ContainsKey(migration.FromVersion))
                    throw new ArgumentException("Invalid or duplicate save migration.", nameof(migrations));
                _migrations.Add(migration.FromVersion, migration);
            }
        }

        public static LocalSaveCodec CreateEncrypted(LocalSaveEncryption encryption, IEnumerable<ILocalSaveMigration> migrations = null)
            => new LocalSaveCodec(migrations, encryption ?? throw new ArgumentNullException(nameof(encryption)));

        public byte[] Encode(LocalSaveSnapshot snapshot, string profileId, long stateRevision, DateTime savedAtUtc)
            => Encode(snapshot, profileId, stateRevision, savedAtUtc, null);

        internal byte[] Encode(LocalSaveSnapshot snapshot, string profileId, long stateRevision, DateTime savedAtUtc, JObject extraEnvelope)
        {
            if (snapshot == null) throw new ArgumentNullException(nameof(snapshot));
            LocalSaveRepository.ValidateProfileId(profileId);
            if (stateRevision < 0) throw new ArgumentOutOfRangeException(nameof(stateRevision));
            savedAtUtc = savedAtUtc.Kind == DateTimeKind.Unspecified ? DateTime.SpecifyKind(savedAtUtc, DateTimeKind.Utc) : savedAtUtc.ToUniversalTime();
            var envelope = new JObject
            {
                ["saveVersion"] = CurrentVersion,
                ["profileId"] = profileId,
                ["stateRevision"] = stateRevision,
                ["savedAt"] = savedAtUtc.ToString("O", CultureInfo.InvariantCulture),
                ["payload"] = snapshot.Payload
            };
            if (extraEnvelope != null)
                foreach (JProperty property in extraEnvelope.Properties())
                    if (!envelope.ContainsKey(property.Name) && property.Name != "integrity") envelope[property.Name] = property.Value.DeepClone();
            envelope["integrity"] = Hash(envelope);
            byte[] plaintext = Encoding.UTF8.GetBytes(envelope.ToString(Formatting.None));
            if (_encryption == null) { Array.Clear(plaintext, 0, plaintext.Length); throw new LocalSaveProtectionException(LocalSaveProtectionFailure.KeyRequired, "Encoding requires a game-provided encryption key."); }
            try { return _encryption.Encrypt(plaintext, profileId); }
            finally { Array.Clear(plaintext, 0, plaintext.Length); }
        }

        public LocalSaveDocument Decode(byte[] bytes, string expectedProfileId)
        {
            LocalSaveRepository.ValidateProfileId(expectedProfileId);
            if (_encryption == null)
                throw new LocalSaveProtectionException(LocalSaveProtectionFailure.KeyRequired, "Decoding requires a game-provided encryption key; original data was preserved.");
            byte[] plaintext = _encryption == null ? bytes : _encryption.Decrypt(bytes, expectedProfileId);
            try { return DecodeEnvelope(ReadEnvelope(plaintext), expectedProfileId); }
            catch (Exception exception) when (exception is OverflowException || exception is FormatException || exception is ArgumentException || exception is InvalidCastException)
            { throw new InvalidDataException("Invalid local save metadata.", exception); }
            finally { if (_encryption != null && plaintext != null) Array.Clear(plaintext, 0, plaintext.Length); }
        }

        private LocalSaveDocument DecodeEnvelope(JObject envelope, string expectedProfileId)
        {
            int originalVersion = ReadVersion(envelope);
            if (originalVersion > CurrentVersion) throw new UnsupportedLocalSaveVersionException(originalVersion);
            if (envelope["profileId"]?.Type != JTokenType.String || envelope.Value<string>("profileId") != expectedProfileId ||
                envelope["stateRevision"]?.Type != JTokenType.Integer || envelope.Value<long>("stateRevision") < 0 ||
                envelope["savedAt"]?.Type != JTokenType.String || !DateTime.TryParseExact(envelope.Value<string>("savedAt"), "O", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out DateTime savedAt) ||
                envelope["payload"] is not JObject payload || envelope["integrity"]?.Type != JTokenType.String)
                throw new InvalidDataException("Invalid local save metadata.");
            string integrity = envelope.Value<string>("integrity");
            envelope.Remove("integrity");
            string sourceHash = Hash(envelope);
            if (!string.Equals(integrity, sourceHash, StringComparison.Ordinal)) throw new InvalidDataException("Local save integrity mismatch.");
            for (int version = originalVersion; version < CurrentVersion; version++)
            {
                if (!_migrations.TryGetValue(version, out ILocalSaveMigration migration))
                    throw new LocalSaveMigrationException("Missing migration from save version " + version);
                try { payload = migration.Migrate((JObject)payload.DeepClone()) ?? throw new InvalidDataException("Migration returned no payload."); }
                catch (Exception exception) { throw new LocalSaveMigrationException("Save migration failed from version " + version, exception); }
            }
            LocalSaveSnapshot snapshot;
            try { snapshot = new LocalSaveSnapshot(payload); }
            catch (Exception exception) when (originalVersion != CurrentVersion)
            { throw new LocalSaveMigrationException("Migrated payload is not valid JSON.", exception); }
            var extra = (JObject)envelope.DeepClone();
            foreach (string key in new[] { "saveVersion", "profileId", "stateRevision", "savedAt", "payload" }) extra.Remove(key);
            return new LocalSaveDocument(originalVersion, expectedProfileId, envelope.Value<long>("stateRevision"), savedAt, snapshot, sourceHash, extra);
        }

        internal static JObject ReadEnvelope(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0) throw new InvalidDataException("Local save is empty.");
            try
            {
                using var reader = new JsonTextReader(new StringReader(new UTF8Encoding(false, true).GetString(bytes))) { DateParseHandling = DateParseHandling.None, MaxDepth = 128 };
                JObject envelope = JObject.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
                if (reader.Read()) throw new InvalidDataException("Trailing data in local save.");
                return envelope;
            }
            catch (Exception exception) when (exception is JsonException || exception is DecoderFallbackException)
            { throw new InvalidDataException("Local save is not valid JSON.", exception); }
        }

        internal static int ReadVersion(JObject envelope)
        {
            if (envelope["saveVersion"]?.Type != JTokenType.Integer) throw new InvalidDataException("Save version is missing.");
            long version = envelope.Value<long>("saveVersion");
            if (version < 0 || version > int.MaxValue) throw new InvalidDataException("Invalid save version.");
            return (int)version;
        }

        // SHA-256 detects corruption, not cheating; no device or account secret is used.
        internal static string Hash(JObject envelope)
        {
            using var sha = SHA256.Create();
            return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(Canonicalize(envelope).ToString(Formatting.None))));
        }

        private static JToken Canonicalize(JToken token)
        {
            if (token is JObject obj) return new JObject(obj.Properties().OrderBy(p => p.Name, StringComparer.Ordinal).Select(p => new JProperty(p.Name, Canonicalize(p.Value))));
            if (token is JArray array) return new JArray(array.Select(Canonicalize));
            return token.DeepClone();
        }
    }
}
