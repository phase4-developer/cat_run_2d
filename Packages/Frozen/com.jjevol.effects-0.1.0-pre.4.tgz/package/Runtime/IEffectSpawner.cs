namespace jjevol.Effect
{
    /// <summary>
    /// Creates and pools one kind of effect object (GameObject, VisualElement). EffectManager owns every spawner and
    /// drives the shared rules: Update and LateUpdate every frame, DespawnAll when the manager is disabled (each live
    /// instance ends as Despawned), Resume when it is enabled again and Shutdown when it is destroyed. The GameObject
    /// spawner is built in; other packages add theirs with <see cref="EffectManager.AddSpawner"/>.
    /// </summary>
    public interface IEffectSpawner
    {
        void Update();
        void LateUpdate();
        /// <summary>The manager was enabled (again).</summary>
        void Resume();
        void DespawnAll();
        /// <summary>The manager is destroyed. Release every instance and asset; the spawner is not used again.</summary>
        void Shutdown();
    }
}
