using System;
using System.Runtime.ExceptionServices;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine;


namespace jjevol.Effect
{
    [System.Serializable]
    public class PoolProfile
    {
        [Min(0)] public int minRetain = 1;
        [Min(1)] public int maxPool = 32;
        [Min(0.1f)] public float idleSeconds = 15f;
    }

    [System.Serializable]
    public struct PoolProfileEntry
    {
        public string effectType;
        public PoolProfile profile;
    }

    /// <summary>
    /// 이펙트 관리자 하나. 직렬화 필드, Unity 수명 콜백, 공개 API, 스포너 목록만 둔다.
    /// GameObject 이펙트는 내장 GameObjectEffectSpawner가 맡는다(풀은 EffectPool, 재생 흐름은 EffectPlaybackPipeline,
    /// 바인딩은 EffectInstanceBinder, 지연 처리는 EffectSettleQueue, 수명 상태는 EffectHandle, 프리팹 상태는 EffectPrefabCache).
    /// 다른 렌더 방식의 스포너는 AddSpawner로 더하고, 비활성·재활성·파괴·매 프레임 처리를 모든 스포너에 똑같이 전한다.
    /// </summary>
    public sealed class EffectManager : MonoBehaviour, IEffectPlayer
    {
        static EffectManager _instance;
        public static bool applicationIsQuitting;
        public static EffectManager Instance => !Application.isPlaying || applicationIsQuitting ? null : (_instance ? _instance : (_instance = new GameObject("EffectManager").AddComponent<EffectManager>()));
        public static bool HasInstance => !applicationIsQuitting && _instance;
        public static bool IsDestroyed => !HasInstance;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatic() { _instance = null; applicationIsQuitting = false; }
        void OnApplicationQuit() => applicationIsQuitting = true;

        [Header("Roots")]
        [SerializeField] Transform _poolRoot;

        [Header("Default Profile")]
        [SerializeField] PoolProfile _defaultProfile = new PoolProfile();

        [Header("Preset Profiles")]
        [SerializeField] PoolProfileEntry[] _profilesPreset = System.Array.Empty<PoolProfileEntry>();

        // 설정 API는 Awake 전에도 불릴 수 있다.
        readonly EffectPrefabCache _prefabs = new();
        // runtime profiles
        readonly Dictionary<string, PoolProfile> _profiles = new();
        GameObjectEffectSpawner _gameObjects;
        // GameObject 스포너가 처음이고, 나머지는 더한 순서대로 부른다.
        readonly List<IEffectSpawner> _spawners = new();

        GameObjectEffectSpawner GameObjects
        {
            get
            {
                if (_gameObjects == null)
                {
                    _gameObjects = new GameObjectEffectSpawner(this, _prefabs, GetProfile);
                    _spawners.Insert(0, _gameObjects);
                }
                return _gameObjects;
            }
        }

        void Awake()
        {
            _ = GameObjects;

            if (_instance && _instance != this) { Destroy(gameObject); return; }
            _instance = this;
            transform.SetParent(null); DontDestroyOnLoad(gameObject);

            if (this != Instance) return;

            if (!_poolRoot)
            {
                var go = new GameObject("EffectManager");
                _poolRoot = go.transform; _poolRoot.SetParent(transform, false);
            }
            GameObjects.SetRoot(_poolRoot);

            // presets
            foreach (var e in _profilesPreset)
            {
                if (!string.IsNullOrEmpty(e.effectType) && e.profile != null)
                    _profiles[e.effectType] = e.profile;
            }
        }

        void OnEnable() => ForEachSpawner(s => s.Resume());

        void OnDisable() => ForEachSpawner(s => s.DespawnAll());

        void OnDestroy()
        {
            try { ForEachSpawner(s => s.Shutdown()); }
            finally
            {
                _spawners.Clear();
                if (_instance == this) _instance = null;
            }
        }

        void Update() => ForEachSpawner(s => s.Update());

        void LateUpdate() => ForEachSpawner(s => s.LateUpdate());

        // Every spawner gets the step. An added spawner's exception is logged. The GameObject spawner was never guarded
        // here, so its exception still reaches Unity as before, but only after the other spawners had their turn.
        void ForEachSpawner(Action<IEffectSpawner> step)
        {
            ExceptionDispatchInfo gameObjectFailure = null;
            for (int i = 0; i < _spawners.Count; i++)
            {
                var spawner = _spawners[i];
                try { step(spawner); }
                catch (Exception exception) when (ReferenceEquals(spawner, _gameObjects)) { gameObjectFailure = ExceptionDispatchInfo.Capture(exception); }
                catch (Exception exception) { Debug.LogException(exception); }
            }
            gameObjectFailure?.Throw();
        }

        /// <summary>
        /// 다른 렌더 방식의 스포너를 더한다(예: com.jjevol.effects.uitoolkit). 같은 형식은 하나만 둔다.
        /// 관리자가 비활성이면 DespawnAll, 다시 활성이면 Resume, 파괴되면 Shutdown을 받는다.
        /// </summary>
        public void AddSpawner(IEffectSpawner spawner)
        {
            if (spawner == null) throw new ArgumentNullException(nameof(spawner));
            _ = GameObjects;
            foreach (var existing in _spawners)
                if (existing.GetType() == spawner.GetType()) throw new InvalidOperationException(spawner.GetType().Name + " is already added.");
            _spawners.Add(spawner);
        }

        /// <summary>AddSpawner로 더한 스포너 중 T 형식을 찾는다. 없으면 null. 내장 GameObject 스포너는 돌려주지 않는다.</summary>
        public T GetSpawner<T>() where T : class, IEffectSpawner
        {
            foreach (var spawner in _spawners)
                if (!ReferenceEquals(spawner, _gameObjects) && spawner is T found) return found;
            return null;
        }

        public void SetPrefabProvider(IEffectPrefabProvider provider)
        {
            if (GameObjects.HasPools || _prefabs.HasLoadedOrPending) throw new InvalidOperationException("Configure the provider before loading effects.");
            _prefabs.SetProvider(provider ?? throw new ArgumentNullException(nameof(provider)));
        }

        /// <summary>런타임에 타입별 풀 정책 수정/등록</summary>
        public void SetPoolProfile(string effectType, int minRetain, int maxPool, float idleSeconds)
        {
            if (string.IsNullOrEmpty(effectType)) return;
            var p = new PoolProfile { minRetain = Mathf.Max(0, minRetain), maxPool = Mathf.Max(1, maxPool), idleSeconds = Mathf.Max(0.1f, idleSeconds) };
            _profiles[effectType] = p;

            GameObjects.SetProfile(effectType, p);
        }

        public async UniTask PreloadAsync(string effectType)
        {
            await _prefabs.LoadAsync(effectType);
        }

        public EffectHandle Play(string effectName, Vector3 position, Transform parent = null)
        {
            return Play(new EffectRequest(effectType: effectName, localPos: position, parent: parent));
        }

        public EffectHandle PlayRouletteEffect(string effectName, int skinIndex, int animationIndex, Vector3 position, Transform parent = null)
        {
            return Play(new EffectRequest(effectType: effectName, skinIndex:skinIndex, animationIndex:animationIndex, localPos: position, parent: parent, sortingLayer: "RouletteEffect"));
        }

        /// <summary>
        /// 동기 Play: 즉시 핸들을 반환. 내부에서 비동기 로드/바인딩 후 준비되면 재생.
        /// 실패는 로그로 남기고 Handle은 종료 경로로 회수된다.
        /// </summary>
        public EffectHandle Play(EffectRequest request)
        {
            var handle = Acquire(request, out int version);
            if (handle != null) GameObjects.Pipeline.RunDetached(handle, version).Forget();
            return handle;
        }

        /// <summary>선택형 비동기 API. 실패는 Handle을 회수한 뒤 호출자에게 전달한다.</summary>
        public async UniTask<EffectHandle> PlayAsync(EffectRequest request)
        {
            var handle = Acquire(request, out int version);
            if (handle == null) return null;
            return await GameObjects.Pipeline.Run(handle, version) ? handle : null;
        }

        public void Despawn(EffectHandle handle)
        {
            if (handle == null) return;
            handle.Terminate(EffectEndReason.Despawned);
        }

        EffectHandle Acquire(in EffectRequest request, out int version)
        {
            version = 0;
            if (!request.IsValid) return null;
            // rejected calls must not consume an inactive pooled handle.
            if (!isActiveAndEnabled) return null;

            var handle = GameObjects.Get(request.effectType);
            version = handle.Configure(request);
            handle.gameObject.SetActive(true);
            return handle;
        }

        PoolProfile GetProfile(string effectType)
        {
            if (string.IsNullOrEmpty(effectType)) return _defaultProfile;
            if (_profiles.TryGetValue(effectType, out var p)) return p;
            return _defaultProfile;
        }
    }
}
