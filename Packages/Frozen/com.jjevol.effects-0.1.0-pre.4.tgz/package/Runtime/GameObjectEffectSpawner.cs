using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>
    /// The GameObject spawner: per-type pools of <see cref="EffectHandle"/>, the shared prefab cache, the settle queue and
    /// the playback pipeline. Moved out of EffectManager without changing what it does.
    /// </summary>
    internal sealed class GameObjectEffectSpawner : IEffectSpawner
    {
        readonly MonoBehaviour _coroutines;
        readonly Func<string, PoolProfile> _profileOf;
        readonly EffectSettleQueue _settleQueue = new();
        readonly HashSet<EffectHandle> _owned = new();
        readonly Dictionary<string, EffectPool> _pools = new();
        Transform _root;

        public EffectPrefabCache Prefabs { get; }
        public EffectPlaybackPipeline Pipeline { get; }
        public bool HasPools => _pools.Count != 0;

        public GameObjectEffectSpawner(MonoBehaviour coroutines, EffectPrefabCache prefabs, Func<string, PoolProfile> profileOf)
        {
            _coroutines = coroutines;
            _profileOf = profileOf;
            Prefabs = prefabs;
            Pipeline = new EffectPlaybackPipeline(prefabs, new EffectInstanceBinder(EffectRendererAdapters.Factories));
        }

        public void SetRoot(Transform root) => _root = root;

        public EffectHandle Get(string effectType) => GetOrCreatePool(effectType).Get();

        public void SetProfile(string effectType, PoolProfile profile)
        {
            if (_pools.TryGetValue(effectType, out var pool)) pool.SetProfile(profile);
        }

        public void Update() { }

        public void LateUpdate() => _settleQueue.Drain();

        // restart a full idle interval after enabling the manager.
        public void Resume()
        {
            foreach (var pool in _pools.Values) pool.ResumeIdleCleanup();
        }

        public void DespawnAll()
        {
            // Unity stops these timers when the GameObject is disabled.
            _coroutines.StopAllCoroutines();
            foreach (var handle in new List<EffectHandle>(_owned))
                if (handle) handle.Terminate(EffectEndReason.Despawned);
        }

        public void Shutdown()
        {
            Prefabs.Shutdown();
            foreach (var handle in new List<EffectHandle>(_owned)) if (handle) UnityEngine.Object.Destroy(handle.gameObject);
        }

        EffectPool GetOrCreatePool(string effectType)
        {
            if (_pools.TryGetValue(effectType, out var pool)) return pool;
            pool = new EffectPool(effectType, _root, _profileOf(effectType), _coroutines, _settleQueue, Prefabs, _owned);
            _pools.Add(effectType, pool);
            return pool;
        }
    }
}
