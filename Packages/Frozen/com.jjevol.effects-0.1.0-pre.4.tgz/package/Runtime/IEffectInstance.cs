namespace jjevol.Effect
{
    /// <summary>
    /// What every playing effect offers, whatever renders it. EffectManager.Play still returns <see cref="EffectHandle"/>
    /// for GameObject effects; code that only controls effects can take this interface instead (UI Toolkit plan G6).
    /// </summary>
    public interface IEffectInstance
    {
        string EffectType { get; }
        bool IsPlaying { get; }
        bool IsLoop { get; }
        /// <summary>Freezes the effect's behaviours until Resume, and what else its render kind can freeze (a GameObject renderer; not USS transitions). The pause survives a reactivation.</summary>
        void Pause();
        void Resume();
        /// <summary>Halts playback without ending the request; the owner still calls Despawn.</summary>
        void Stop();
        /// <summary>Ends the request as Despawned and returns the instance to its pool. A second call does nothing.</summary>
        void Despawn();
    }
}
