using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Tests
{
    // The manager's spawner list: every spawner gets the same per-frame calls and lifetime events.
    public sealed class EffectsSpawnerTests
    {
        sealed class RecordingSpawner : IEffectSpawner
        {
            public readonly List<string> log = new List<string>();
            public int updates, lateUpdates;
            public bool throwOnUpdate;
            public void Update() { updates++; if (throwOnUpdate) throw new InvalidOperationException("spawner update"); }
            public void LateUpdate() => lateUpdates++;
            public void Resume() => log.Add("Resume");
            public void DespawnAll() => log.Add("DespawnAll");
            public void Shutdown() => log.Add("Shutdown");
        }

        sealed class OtherSpawner : IEffectSpawner
        {
            public int updates;
            public void Update() => updates++;
            public void LateUpdate() { }
            public void Resume() { }
            public void DespawnAll() { }
            public void Shutdown() { }
        }

        sealed class PendingPrefabs : IEffectPrefabProvider
        {
            public UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token) => new UniTaskCompletionSource<EffectPrefabLease>().Task;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            LogAssert.ignoreFailingMessages = false;
            if (EffectManager.HasInstance) Object.Destroy(EffectManager.Instance.gameObject);
            yield return null;
        }

        [UnityTest]
        public IEnumerator AddedSpawnerFollowsTheManager()
        {
            var manager = EffectManager.Instance;
            var spawner = new RecordingSpawner();
            manager.AddSpawner(spawner);
            Assert.That(manager.GetSpawner<RecordingSpawner>(), Is.SameAs(spawner));
            Assert.That(manager.GetSpawner<OtherSpawner>(), Is.Null);
            Assert.That(manager.GetSpawner<IEffectSpawner>(), Is.SameAs(spawner), "the built-in GameObject spawner was handed out");
            Assert.Throws<InvalidOperationException>(() => manager.AddSpawner(new RecordingSpawner()));

            yield return null;
            yield return null;
            Assert.That(spawner.updates, Is.GreaterThan(0));
            Assert.That(spawner.lateUpdates, Is.GreaterThan(0));

            manager.enabled = false;
            manager.enabled = true;
            Object.Destroy(manager.gameObject);
            yield return null;
            Assert.That(spawner.log, Is.EqualTo(new[] { "DespawnAll", "Resume", "DespawnAll", "Shutdown" }));
        }

        [UnityTest]
        public IEnumerator AnAddedSpawnersExceptionIsLoggedAndTheOthersGoOn()
        {
            var manager = EffectManager.Instance;
            var failing = new RecordingSpawner { throwOnUpdate = true };
            var other = new OtherSpawner();
            manager.AddSpawner(failing);
            manager.AddSpawner(other);
            LogAssert.ignoreFailingMessages = true;
            yield return null;
            yield return null;
            LogAssert.ignoreFailingMessages = false;
            Assert.That(other.updates, Is.GreaterThan(0), "a spawner after the failing one was skipped");
            Assert.That(failing.lateUpdates, Is.GreaterThan(0), "the manager stopped after a spawner threw");
        }

        [UnityTest]
        public IEnumerator EffectHandleIsAnEffectInstance()
        {
            var manager = EffectManager.Instance;
            manager.SetPrefabProvider(new PendingPrefabs());
            var ends = new List<EffectEndReason>();
            IEffectInstance instance = manager.Play(new EffectRequest("Pending", loop: true, onEnded: ends.Add));
            Assert.That(instance.EffectType, Is.EqualTo("Pending"));
            Assert.That(instance.IsLoop, Is.True);
            instance.Pause();
            instance.Resume();
            instance.Despawn();
            instance.Despawn();
            Assert.That(ends, Is.EqualTo(new[] { EffectEndReason.Despawned }));
            yield return null;
        }
    }
}
