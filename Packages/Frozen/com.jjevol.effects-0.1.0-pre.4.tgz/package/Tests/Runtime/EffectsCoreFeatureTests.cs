#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using jjevol.Effect.Behaviours;
using jjevol.Effect.Renderers;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Tests
{
    // Independent editor-only fixtures; no source game assets or Vendor substitutes.
    public sealed class EffectsCoreFeatureTests
    {
        sealed class Provider : IEffectPrefabProvider
        {
            public GameObject Prefab;
            public int Loads, Releases;
            public UniTaskCompletionSource<EffectPrefabLease> Gate;
            public CancellationToken Token;
            public async UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token)
            {
                Loads++; Token = token;
                if (Gate != null) return await Gate.Task;
                return Lease();
            }
            public EffectPrefabLease Lease() => new EffectPrefabLease(Prefab, () => Releases++);
        }
        EffectManager manager;
        GameObject prefab;
        Provider provider;
        readonly List<GameObject> extras = new();
        readonly List<Scene> scenes = new();
        string assetFolder;

        static void Set(object target, string field, object value) => target.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic).SetValue(target, value);
        static IEnumerator Until(Func<bool> predicate, string message, float seconds = 3f)
        {
            float end = Time.realtimeSinceStartup + seconds;
            while (!predicate() && Time.realtimeSinceStartup < end) yield return null;
            Assert.IsTrue(predicate(), message);
        }
        GameObject Extra(string name, params Type[] components)
        {
            var go = new GameObject(name, components); extras.Add(go); return go;
        }
        EffectHandle Play(bool loop = true, Transform parent = null, bool unscaled = false, int animationIndex = 0, Action callback = null)
            => manager.Play(new EffectRequest("fixture", loop:loop, parent:parent, unscaledTime:unscaled, animationIndex:animationIndex, callBack:callback));
        void Controlled() => prefab.AddComponent<ControlledEffectRenderer>();
        AnimatorEffectRenderer AnimatorFixture(bool trigger = false, float duration = 0.2f, float fallback = 3f)
        {
            assetFolder = "Assets/JJEvolStep6_" + Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets", assetFolder.Substring(7));
            var clip = new AnimationClip { name = "IndependentMotion" };
            clip.SetCurve("", typeof(Transform), "localPosition.x", AnimationCurve.Linear(0, 0, duration, 1));
            AssetDatabase.CreateAsset(clip, assetFolder + "/Motion.anim");
            var controller = AnimatorController.CreateAnimatorControllerAtPath(assetFolder + "/Fixture.controller");
            var machine = controller.layers[0].stateMachine;
            var idle = machine.AddState("Idle");
            var play = machine.AddState("Play"); play.motion = clip;
            var alternate = machine.AddState("Alternate"); alternate.motion = clip;
            machine.defaultState = idle;
            controller.AddParameter("Play", AnimatorControllerParameterType.Trigger);
            var transition = idle.AddTransition(play); transition.hasExitTime = false; transition.duration = 0;
            transition.AddCondition(AnimatorConditionMode.If, 0, "Play");
            AssetDatabase.SaveAssets();
            var animator = prefab.AddComponent<Animator>(); animator.runtimeAnimatorController = controller;
            animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            var renderer = prefab.AddComponent<AnimatorEffectRenderer>();
            Set(renderer, "stateNames", new List<string> { "Play", "Alternate" });
            Set(renderer, "fallbackCompleteSeconds", fallback);
            if (trigger)
            {
                var field = typeof(AnimatorEffectRenderer).GetField("playMode", BindingFlags.Instance | BindingFlags.NonPublic);
                field.SetValue(renderer, Enum.ToObject(field.FieldType, 1));
                Set(renderer, "waitStateName", "Play");
            }
            return renderer;
        }
        [UnitySetUp] public IEnumerator Setup()
        {
            Time.timeScale = 1;
            prefab = new GameObject("independent-effect-fixture");
            manager = new GameObject("step6-manager").AddComponent<EffectManager>();
            provider = new Provider { Prefab = prefab }; manager.SetPrefabProvider(provider);
            yield return null;
        }
        [UnityTearDown] public IEnumerator Cleanup()
        {
            Time.timeScale = 1;
            if (manager) Object.Destroy(manager.gameObject);
            foreach (var go in extras) if (go) Object.Destroy(go);
            if (prefab) Object.Destroy(prefab);
            yield return null; yield return null;
            foreach (var scene in scenes) if (scene.IsValid() && scene.isLoaded) yield return SceneManager.UnloadSceneAsync(scene);
            scenes.Clear(); extras.Clear();
            if (assetFolder != null) { AssetDatabase.DeleteAsset(assetFolder); assetFolder = null; }
        }
        [UnityTest] public IEnumerator AnimatorIndexedStateCompletesAndSorts()
        {
            var source = AnimatorFixture();
            var canvas = prefab.AddComponent<Canvas>();
            Set(source, "sortingCanvases", new List<Canvas> { canvas });
            var handle = Play(loop:false, unscaled:true, animationIndex:1);
            var animator = handle.GetComponentInChildren<Animator>(true);
            Assert.IsTrue(animator.GetCurrentAnimatorStateInfo(0).IsName("Alternate"));
            handle.SetSorting("Default", 17);
            Assert.AreEqual(17, handle.GetComponentInChildren<Canvas>().sortingOrder);
            Assert.AreEqual(AnimatorUpdateMode.UnscaledTime, animator.updateMode);
            yield return Until(() => !handle.gameObject.activeSelf, "Animator completion must return instance");
        }
        [UnityTest] public IEnumerator AnimatorTriggerAndLoopStopReuse()
        {
            AnimatorFixture(trigger:true);
            var handle = Play(loop:false);
            yield return Until(() => !handle.gameObject.activeSelf, "Trigger state must finish");
            var reused = Play(); Assert.AreSame(handle, reused);
            yield return new WaitForSecondsRealtime(0.35f);
            Assert.IsTrue(reused.IsPlaying, "Loop must not auto-return");
            manager.Despawn(reused); Assert.IsFalse(reused.gameObject.activeSelf);
        }
        [UnityTest] public IEnumerator AnimatorPauseDoesNotConsumeFallbackTimeout()
        {
            AnimatorFixture(duration:0.2f, fallback:0.4f);
            var handle = Play(loop:false);
            handle.Pause();
            var animator = handle.GetComponentInChildren<Animator>();
            float position = animator.GetCurrentAnimatorStateInfo(0).normalizedTime;
            yield return new WaitForSecondsRealtime(0.65f);
            Assert.IsTrue(handle.IsPlaying, "Pause must preserve pending completion beyond fallback timeout");
            Assert.AreEqual(position, animator.GetCurrentAnimatorStateInfo(0).normalizedTime, 0.02f);
            handle.Resume();
            yield return Until(() => !handle.gameObject.activeSelf, "Resume must complete");
        }
        [UnityTest] public IEnumerator FollowTracksWorldTargetAndEndsWhenTargetDestroyed()
        {
            Controlled(); var target = Extra("follow-target"); target.transform.position = new Vector3(5, 7, 0);
            var follow = prefab.AddComponent<FollowTargetBehaviour>(); follow.Target = target.transform; follow.Offset = Vector3.up;
            var handle = Play(); yield return null;
            Assert.AreEqual(target.transform.position + Vector3.up, handle.transform.position);
            target.transform.position += Vector3.right * 4; yield return null;
            Assert.AreEqual(target.transform.position + Vector3.up, handle.transform.position);
            Object.Destroy(target); yield return null; yield return null;
            Assert.IsFalse(handle.GetComponentInChildren<FollowTargetBehaviour>(true).enabled);
        }
        [UnityTest] public IEnumerator JumpBouncesAndReusesWithoutOldCallback()
        {
            Controlled(); var handle = Play(); int first = 0, second = 0;
            var jump = handle.AddBehaviour<JumpPopBehaviour>(); jump.SetJump(4, 2, 0.1f, 2); jump.OnComplete = () => first++;
            yield return Until(() => first == 1, "Both jumps must finish");
            Assert.Greater(handle.transform.localPosition.x, 0.3f);
            manager.Despawn(handle); Assert.AreSame(handle, Play());
            var reused = handle.AddBehaviour<JumpPopBehaviour>(); Assert.AreSame(jump, reused);
            reused.SetJump(1, 1, 0.1f, 1); reused.OnComplete = () => second++;
            yield return Until(() => second == 1, "Reused jump must finish"); Assert.AreEqual(1, first);
        }
        [UnityTest] public IEnumerator PauseFreezesBehaviourAndResumeCompletes()
        {
            Controlled(); var handle = Play(); int done = 0;
            var move = handle.AddBehaviour<MoveToTargetBehaviour>(); move.SetTargetPosition(Vector3.right * 10, 5); move.OnReached = () => done++;
            handle.Pause(); var position = handle.transform.position;
            yield return new WaitForSecondsRealtime(0.3f);
            Assert.AreEqual(position, handle.transform.position, "Pause must suspend behaviour Tick");
            Assert.AreEqual(0, done); handle.Resume();
            yield return Until(() => done == 1, "Resume must continue movement");
        }
        [UnityTest] public IEnumerator MoveCurveAnchoredAndWorldDrainReachEndpoints()
        {
            Controlled(); var canvas = Extra("curve-canvas", typeof(Canvas));
            var handle = Play(parent:canvas.transform); int reached = 0;
            var curve = handle.AddBehaviour<MoveCurveBehaviour>(); curve.SetCurve(new Vector2(80, 30), 0.15f, 50); curve.OnReached = () => reached++;
            yield return Until(() => reached == 1, "Anchored curve must complete");
            Assert.Less(Vector2.Distance(((RectTransform)handle.transform).anchoredPosition, new Vector2(80, 30)), 0.01f);
            var target = Extra("drain-target"); target.transform.position = new Vector3(3, 4, 0);
            curve = handle.AddBehaviour<MoveCurveBehaviour>(); curve.SetWorldDrainCurve(target.transform, 0.15f, 2, 1); curve.OnReached = () => reached++;
            target.transform.position = new Vector3(4, 5, 0);
            yield return Until(() => reached == 2, "World drain must follow target endpoint");
            Assert.Less(Vector3.Distance(handle.transform.position, target.transform.position), 0.01f);
        }
        [UnityTest] public IEnumerator MoveTargetSupportsMovingAndFixedDestinations()
        {
            Controlled(); var handle = Play(); var target = Extra("moving-target"); target.transform.position = Vector3.right;
            int reached = 0; var move = handle.AddBehaviour<MoveToTargetBehaviour>(); move.SetTarget(target.transform); move.OnReached = () => reached++;
            target.transform.position = Vector3.right * 2;
            yield return Until(() => reached == 1, "Moving target must be reached");
            Assert.Less(Vector3.Distance(handle.transform.position, target.transform.position), 0.1f);
            move = handle.AddBehaviour<MoveToTargetBehaviour>(); move.SetWorldPosition(Vector3.left); move.OnReached = () => reached++;
            yield return Until(() => reached == 2, "Fixed destination must be reached");
            Assert.Less(Vector3.Distance(handle.transform.position, Vector3.left), 0.1f);
        }
        [UnityTest] public IEnumerator UIJumpAndBurstRunUnderCanvasWithoutChangingParentLayout()
        {
            Controlled(); var canvas = Extra("ui-canvas", typeof(Canvas)); canvas.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var parent = Extra("ui-parent", typeof(RectTransform)); parent.transform.SetParent(canvas.transform, false);
            var rect = (RectTransform)parent.transform; rect.sizeDelta = new Vector2(320, 180); rect.localScale = Vector3.one * 1.5f;
            var handle = Play(parent:rect); int completed = 0;
            var jump = handle.AddBehaviour<UIJumpPopBehaviour>(); jump.SetJump(20, 30, 0.1f, 2); jump.OnComplete = () => completed++;
            yield return Until(() => completed == 1, "UI jump must complete");
            Assert.Greater(((RectTransform)handle.transform).anchoredPosition.x, 1);
            var burst = handle.AddBehaviour<UIBurstScatterBehaviour>(); burst.SetBurst(new Vector2(60, 40), 30, 0.2f); burst.OnReached = () => completed++;
            yield return Until(() => completed == 2, "UI burst must complete");
            Assert.Less(Vector2.Distance(((RectTransform)handle.transform).anchoredPosition, new Vector2(60,40)), 0.01f);
            Assert.AreEqual(new Vector2(320,180), rect.sizeDelta); Assert.AreEqual(Vector3.one * 1.5f, rect.localScale);
        }
        [UnityTest] public IEnumerator ParticlePausePreservesCompletionAndUnscaledSimulation()
        {
            var particle = prefab.AddComponent<ParticleSystem>(); particle.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear); var main = particle.main;
            main.playOnAwake = false; main.duration = 0.15f; main.startLifetime = 0.1f;
            var handle = Play(loop:false, unscaled:true); handle.Pause();
            yield return new WaitForSecondsRealtime(0.6f);
            Assert.IsTrue(handle.IsPlaying, "Paused particles must not expire via timeout");
            var instance = handle.GetComponentInChildren<ParticleSystem>();
            Assert.IsTrue(instance.main.useUnscaledTime, "Unscaled request must affect simulation, not just waiter");
            Time.timeScale = 0; handle.Resume();
            yield return Until(() => !handle.gameObject.activeSelf, "Unscaled particles must finish at timescale zero");
            Time.timeScale = 1;
        }
        [UnityTest] public IEnumerator DisableReturnsActiveAndPendingInstancesThenAllowsReuse()
        {
            Controlled(); var first = Play(); manager.enabled = false;
            Assert.IsFalse(first.gameObject.activeSelf); manager.enabled = true;
            Assert.AreSame(first, Play()); manager.Despawn(first);
            provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var pending = manager.Play(new EffectRequest("pending", loop:true)); manager.enabled = false;
            provider.Gate.TrySetResult(provider.Lease()); yield return null;
            Assert.IsFalse(pending.gameObject.activeSelf); Assert.IsNull(pending.Renderer);
        }
        [UnityTest] public IEnumerator PlayAsyncWhileDisabledCannotStartAnEffect()
        {
            Controlled(); manager.enabled = false;
            Assert.IsNull(Play());
            var task = manager.PlayAsync(new EffectRequest("fixture", loop:true)).AsTask();
            yield return Until(() => task.IsCompleted, "Disabled async call must finish");
            Assert.IsNull(task.Result); Assert.AreEqual(0, provider.Loads);
            manager.enabled = true; manager.SetPoolProfile("fixture", 0, 4, 0.1f);
            var handle = Play(); manager.Despawn(handle);
            yield return Until(() => provider.Releases == 1, "Disabled calls must not leave active pool slots");
        }
        [UnityTest] public IEnumerator DisabledSyncPlayCannotConsumeAnExistingIdleHandle()
        {
            Controlled(); var handle = Play(); manager.enabled = false;
            Assert.IsNull(Play()); manager.enabled = true;
            Assert.AreSame(handle, Play(), "Rejected disabled Play must leave the idle handle available");
            manager.SetPoolProfile("fixture", 0, 4, 0.1f); manager.Despawn(handle);
            yield return Until(() => provider.Releases == 1, "Rejected disabled call must not leave active ownership");
        }
        [UnityTest] public IEnumerator DestroyDuringLoadReturnsLateLeaseExactlyOnce()
        {
            Controlled(); provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var task = manager.PlayAsync(new EffectRequest("fixture", loop:true)).AsTask();
            Object.Destroy(manager.gameObject); yield return null;
            Assert.IsTrue(provider.Token.IsCancellationRequested);
            provider.Gate.TrySetResult(provider.Lease());
            yield return Until(() => task.IsCompleted, "Late completion must resolve after destroy");
            Assert.IsFalse(task.IsFaulted, task.Exception?.ToString()); Assert.IsNull(task.Result); Assert.AreEqual(1, provider.Releases);
        }
        [UnityTest] public IEnumerator PreloadPinsUntilManagerDestroyAndMinRetainPinsIdle()
        {
            Controlled(); var preload = manager.PreloadAsync("fixture").AsTask();
            yield return Until(() => preload.IsCompleted, "Preload must finish");
            Assert.AreEqual(1, provider.Loads); yield return new WaitForSecondsRealtime(0.7f); Assert.AreEqual(0, provider.Releases);
            manager.SetPoolProfile("fixture", 1, 4, 0.1f); var handle = Play(); manager.Despawn(handle);
            yield return new WaitForSecondsRealtime(0.7f); Assert.IsTrue(handle != null); Assert.AreEqual(0, provider.Releases);
            manager.SetPoolProfile("fixture", 0, 4, 0.1f); handle = Play(); manager.Despawn(handle);
            yield return Until(() => provider.Releases == 1, "Last idle cull must release prefab lease");
            Assert.IsTrue(handle == null);
        }
        [UnityTest] public IEnumerator SceneTransitionKeepsPersistentEffectAndReturnsCompletedPool()
        {
            AnimatorFixture(duration:0.5f); var scene = SceneManager.CreateScene("step6-transition-" + Guid.NewGuid()); scenes.Add(scene);
            var handle = Play(loop:false); yield return SceneManager.UnloadSceneAsync(scene);
            Assert.IsTrue(manager && handle.IsPlaying); Assert.IsTrue(handle.gameObject.scene.name == "DontDestroyOnLoad");
            yield return Until(() => !handle.gameObject.activeSelf, "Animation must finish and return across scene transition");
            Assert.AreSame(handle, Play());
        }
        [UnityTest] public IEnumerator UnloadingExternalParentSceneRetiresInstanceAndLease()
        {
            Controlled(); manager.SetPoolProfile("fixture", 0, 4, 0.1f);
            var scene = SceneManager.CreateScene("step6-parent-" + Guid.NewGuid()); scenes.Add(scene);
            var parent = Extra("scene-parent", typeof(RectTransform)); SceneManager.MoveGameObjectToScene(parent, scene);
            var handle = Play(parent:parent.transform);
            yield return SceneManager.UnloadSceneAsync(scene);
            Assert.IsTrue(handle == null);
            yield return Until(() => provider.Releases == 1, "Scene-destroyed instance must not pin prefab forever");
            var next = Play(); Assert.IsTrue(next && next.IsPlaying); Assert.AreEqual(2, provider.Loads);
            manager.Despawn(next);
        }
        [UnityTest] public IEnumerator BehaviourCompletionCanDespawnAndConfigureReusedBehaviour()
        {
            Controlled(); var handle = Play(); int reached = 0;
            var move = handle.AddBehaviour<MoveToTargetBehaviour>(); move.SetTargetPosition(Vector3.right, 20);
            move.OnReached = () =>
            {
                reached++; manager.Despawn(handle); Assert.AreSame(handle, Play());
                var next = handle.AddBehaviour<MoveToTargetBehaviour>();
                next.SetTargetPosition(Vector3.left, 20); next.OnReached = () => reached++;
            };
            yield return Until(() => reached == 2, "Old Tick must not recycle the behaviour belonging to the next request");
        }
        [UnityTest] public IEnumerator GameObjectDisableReturnsActiveAndRestartsIdleCleanupOnEnable()
        {
            Controlled(); manager.SetPoolProfile("fixture", 0, 4, 0.1f); var handle = Play();
            manager.gameObject.SetActive(false);
            Assert.IsFalse(handle.gameObject.activeSelf);
            yield return new WaitForSecondsRealtime(0.7f);
            Assert.AreEqual(0, provider.Releases, "Disabled manager retains idle cache until enabled or destroyed");
            manager.gameObject.SetActive(true);
            yield return Until(() => provider.Releases == 1, "Re-enabled manager must resume idle eviction");
        }
        [UnityTest] public IEnumerator PreloadWithoutInstancesIsReleasedByDestroy()
        {
            Controlled(); var task = manager.PreloadAsync("fixture").AsTask();
            yield return Until(() => task.IsCompleted, "Preload must finish");
            yield return new WaitForSecondsRealtime(0.7f);
            Assert.AreEqual(0, provider.Releases);
            Object.Destroy(manager.gameObject); yield return null; yield return null;
            Assert.AreEqual(1, provider.Releases);
        }
        [UnityTest] public IEnumerator PauseBeforeAsyncBindIsAppliedToAnimator()
        {
            AnimatorFixture(); provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var handle = Play(loop:false); handle.Pause(); provider.Gate.TrySetResult(provider.Lease());
            yield return null;
            Assert.AreEqual(0, handle.GetComponentInChildren<Animator>().speed);
            yield return new WaitForSecondsRealtime(0.25f); Assert.IsTrue(handle.IsPlaying);
            handle.Resume(); yield return Until(() => !handle.gameObject.activeSelf, "Resume after late bind must complete");
        }
        [UnityTest] public IEnumerator AnimatorWaitsForChildParticlesAndStopCanDisableAnimator()
        {
            var renderer = AnimatorFixture(duration:0.1f);
            var particle = prefab.AddComponent<ParticleSystem>(); particle.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var main = particle.main; main.playOnAwake = false; main.duration = 0.1f; main.startLifetime = 0.45f;
            var emission = particle.emission; emission.rateOverTime = 0; emission.SetBursts(new[] { new ParticleSystem.Burst(0, 1) });
            Set(renderer, "particleSystems", new List<ParticleSystem> { particle }); Set(renderer, "disableAnimatorOnStop", true);
            // Asset creation stalls this frame and the next frame's deltaTime carries the stall; let both frames pass so Play starts on normal game time.
            yield return null; yield return null;
            var handle = Play(loop:false);
            var animator = handle.GetComponentInChildren<Animator>(true);
            var live = handle.GetComponentInChildren<ParticleSystem>(true);
            yield return Until(() => !handle.IsPlaying || (animator.GetCurrentAnimatorStateInfo(0).IsName("Play") && animator.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1f), "Animator must finish the Play state");
            Assert.IsTrue(live.IsAlive(true), "Particle must still be alive when the animation ends");
            Assert.IsTrue(handle.IsPlaying, "Animation end must wait for live particles");
            yield return Until(() => !handle.gameObject.activeSelf, "Particles and animation must both finish");
            Assert.IsFalse(animator.enabled);
        }
        [UnityTest] public IEnumerator FailedAsyncLoadCanRetryWithoutLeakingPoolSlot()
        {
            Controlled(); provider.Gate = new UniTaskCompletionSource<EffectPrefabLease>();
            var failed = manager.PlayAsync(new EffectRequest("fixture", loop:true)).AsTask();
            provider.Gate.TrySetException(new InvalidOperationException("independent fixture load failure"));
            yield return Until(() => failed.IsCompleted, "Failed load must complete");
            Assert.IsTrue(failed.IsFaulted); Assert.IsInstanceOf<InvalidOperationException>(failed.Exception.InnerException);
            provider.Gate = null; var retry = Play(); Assert.IsTrue(retry.IsPlaying); Assert.AreEqual(2, provider.Loads);
            manager.SetPoolProfile("fixture", 0, 4, 0.1f); manager.Despawn(retry);
            yield return Until(() => provider.Releases == 1, "Failed request must not leave a phantom active slot");
        }
    }
}
#endif
