# Changelog

## 0.1.0-pre.4 - 2026-11-12

- Spawners: the GameObject pools, prefab cache, settle queue and playback pipeline moved from `EffectManager` into the internal `GameObjectEffectSpawner` without changing what they do. `EffectManager` keeps its serialized fields and public API and now drives a list of spawners: `Update` and `LateUpdate` every frame, `DespawnAll` when disabled, `Resume` when enabled and `Shutdown` when destroyed.
- New public `IEffectSpawner`, `EffectManager.AddSpawner` and `EffectManager.GetSpawner<T>()` for spawners of other render kinds (`com.jjevol.effects.uitoolkit` adds the VisualElement spawner). An added spawner that throws is logged and the others go on.
- New public `IEffectInstance` (`EffectType`, `IsPlaying`, `IsLoop`, `Pause`, `Resume`, `Stop`, `Despawn`). `EffectHandle` implements it and gains `Despawn()`, the same as `EffectManager.Despawn(handle)`. `Play` still returns `EffectHandle` (UI Toolkit plan G6).

## 0.1.0-pre.3 - 2026-11-10

- The asset menu `jjevol/Effect/Pool Profiles` is now `JJEvol/Effects/Pool Profiles`. Framework menus are grouped by feature under one `JJEvol/` root (Editor menus), `Assets/Create/JJEvol/` (asset menus) and `GameObject/UI/JJEvol/` (UI objects). Only the menu path changed; class names, serialized fields and GUIDs are unchanged, so existing assets keep working.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.2 - 2026-11-06

- `EffectHandle` has one lifetime state and every ending uses one path, so `callBack` runs exactly once.
- `Play` and `PlayAsync` share one pipeline. `EffectPrefabCache` keeps one record per key and failed loads retry.
- Handles under an inactive parent end or wait safely, with deferred reparenting.
- Fixed code attached `FollowTargetBehaviour`, Pause and Sorting leaking through the pool, and prefabs with child-only ParticleSystems.
- Added optional `IEffectRendererStateRestore` and `EffectSortingSnapshot`.
- Added public `EffectEndReason`, `IEffectPlayer` (implemented by `EffectManager`) and `EffectRequest.onEnded`, a new trailing optional constructor parameter. `onEnded` runs once for every end, after `callBack` and `OnComplete`.
- `callBack`, `OnComplete` and `onEnded` run before the handle returns to the pool, so a `Play` inside them takes another handle.
- Behaviour change: a non-loop handle ended by a deactivated hierarchy or a destroyed parent now ends as `Interrupted` and no longer raises `OnComplete`. `callBack` still runs once.
- `EffectManager` is split into internal `EffectPool`, `EffectPlaybackPipeline`, `EffectInstanceBinder` and `EffectSettleQueue`, built by constructor. `EffectHandle` depends only on `IEffectHandleHost`.

Unity tests for this candidate are NOT_RUN.

# 0.1.0-pre.1 — 2026-10-31

Local extraction candidate. Existing request/renderer/behaviour contracts retained. Core prefab-provider seam, completion and idle identity guards, duplicate return protection and external-parent ownership added. Vendor/UI sources preserved but not validated. Overall PARTIAL.

STEP 6 local candidate corrections (same unpublished version): pause now suspends behaviour and renderer timeout progression; particle simulation observes unscaled timing. Disabled Play/PlayAsync cannot consume pool slots. GameObject re-enable restarts idle eviction. Scene-destroyed handles retire pool ownership and release the final prefab lease. Added 23 Editor PlayMode feature/lifetime tests. Basic Core validation passed; full Vendor/UI/content/Player transfer remains PARTIAL. No snapshot or publication.
