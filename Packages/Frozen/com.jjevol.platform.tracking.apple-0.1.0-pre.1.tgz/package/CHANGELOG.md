# Changelog

## 0.1.0-pre.1 - 2026-11-08

- First candidate. `AppleTrackingConsentProvider` waits for focus, shows the App Tracking Transparency prompt once and answers the decision. Unsupported before iOS 14 and outside an iOS Player.
- Redesigned from the mobile library's `AppleTrackingAuthorization`.

Unity tests for this candidate are recorded in Docs/PlatformReviewTracking/Report.md.
