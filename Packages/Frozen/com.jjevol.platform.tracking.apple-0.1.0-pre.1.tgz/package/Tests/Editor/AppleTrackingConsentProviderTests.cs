using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;

namespace PlatformLibrary.Tracking.Apple.Tests
{
    internal sealed class FakeAppleTrackingClient : IAppleTrackingClient
    {
        public bool Available = true;
        public bool Focused = true;
        public int Status;
        public int Requests;
        /// <summary>Called on each poll, so a test can change focus or the decision as time passes.</summary>
        public Action OnWait;

        public bool IsAvailable => Available;
        public bool IsFocused => Focused;
        public int GetStatus() => Status;
        public void RequestAuthorization() => Requests++;
    }

    public sealed class AppleTrackingConsentProviderTests
    {
        private SynchronizationContext _context;
        private FakeAppleTrackingClient _client;
        private AppleTrackingConsentProvider _provider;
        private List<TrackingConsentStatus> _answers;
        private int _waits;

        // Without a context, completed waits continue inline, so each poll runs synchronously.
        [SetUp]
        public void SetUp()
        {
            _context = SynchronizationContext.Current;
            SynchronizationContext.SetSynchronizationContext(null);
            _client = new FakeAppleTrackingClient();
            _waits = 0;
            _provider = new AppleTrackingConsentProvider(_client, () =>
            {
                _waits++;
                _client.OnWait?.Invoke();
                return Task.CompletedTask;
            });
            _answers = new List<TrackingConsentStatus>();
        }

        [TearDown]
        public void TearDown() => SynchronizationContext.SetSynchronizationContext(_context);

        [Test]
        public void TheEditorIsUnsupported()
        {
            var provider = new AppleTrackingConsentProvider();
            Assert.That(provider.Status, Is.EqualTo(TrackingConsentStatus.Unsupported));
            provider.Request(_answers.Add);
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Unsupported }));
        }

        [Test]
        public void BeforeIos14ItIsUnsupported()
        {
            _client.Available = false;
            Assert.That(_provider.Status, Is.EqualTo(TrackingConsentStatus.Unsupported));
        }

        [Test]
        public void StatusValuesMapToTheEnum()
        {
            Assert.That(AppleTrackingConsentProvider.Map(0), Is.EqualTo(TrackingConsentStatus.NotDetermined));
            Assert.That(AppleTrackingConsentProvider.Map(1), Is.EqualTo(TrackingConsentStatus.Restricted));
            Assert.That(AppleTrackingConsentProvider.Map(2), Is.EqualTo(TrackingConsentStatus.Denied));
            Assert.That(AppleTrackingConsentProvider.Map(3), Is.EqualTo(TrackingConsentStatus.Authorized));
            Assert.That(AppleTrackingConsentProvider.Map(9), Is.EqualTo(TrackingConsentStatus.NotDetermined));
        }

        [Test]
        public void ADecidedStatusDoesNotShowThePrompt()
        {
            _client.Status = 3;
            _provider.Request(_answers.Add);
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Authorized }));
            Assert.That(_client.Requests, Is.EqualTo(0));
        }

        [Test]
        public void ItWaitsForFocusThenAsksOnceAndAnswersTheDecision()
        {
            _client.Focused = false;
            _client.OnWait = () =>
            {
                if (_waits == 2) _client.Focused = true;
                if (_waits == 4) _client.Status = 2;
            };

            _provider.Request(_answers.Add);

            Assert.That(_client.Requests, Is.EqualTo(1));
            Assert.That(_waits, Is.EqualTo(4));
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Denied }));
        }

        [Test]
        public void ADecisionMadeWhileWaitingForFocusIsNotAskedAgain()
        {
            _client.Focused = false;
            _client.OnWait = () =>
            {
                _client.Status = 1;
                _client.Focused = true;
            };

            _provider.Request(_answers.Add);
            Assert.That(_client.Requests, Is.EqualTo(0));
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Restricted }));
        }

        [Test]
        public void AFailedWaitAnswersTheCurrentStatus()
        {
            var provider = new AppleTrackingConsentProvider(_client, () => Task.FromException(new InvalidOperationException("stopped")));
            _client.Focused = false;
            provider.Request(_answers.Add);
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.NotDetermined }));
        }
    }
}
