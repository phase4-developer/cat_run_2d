using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Tracking.Apple.Tests.Editor")]
