using System;
using System.Threading.Tasks;

namespace PlatformLibrary.Tracking.Apple
{
    /// <summary>
    /// Apple App Tracking Transparency. On an iOS 14 or later Player it waits until the app has focus, shows the system
    /// prompt once, and answers when the player decides. Elsewhere, including the Editor, it is unsupported.
    /// </summary>
    public sealed class AppleTrackingConsentProvider : ITrackingConsentProvider
    {
        /// <summary>How often the provider checks focus and the decision while the prompt is open.</summary>
        internal const int PollMilliseconds = 100;

        private readonly IAppleTrackingClient _client;
        private readonly Func<Task> _wait;

        public AppleTrackingConsentProvider() : this(new AppleTrackingSdkClient(), () => Task.Delay(PollMilliseconds))
        {
        }

        internal AppleTrackingConsentProvider(IAppleTrackingClient client, Func<Task> wait)
        {
            _client = client ?? throw new ArgumentNullException(nameof(client));
            _wait = wait ?? throw new ArgumentNullException(nameof(wait));
        }

        public TrackingConsentStatus Status => _client.IsAvailable ? Map(_client.GetStatus()) : TrackingConsentStatus.Unsupported;

        public void Request(Action<TrackingConsentStatus> completed)
        {
            if (completed == null) throw new ArgumentNullException(nameof(completed));
            TrackingConsentStatus status = Status;
            if (status != TrackingConsentStatus.NotDetermined)
            {
                completed(status);
                return;
            }

            Run(completed);
        }

        private async void Run(Action<TrackingConsentStatus> completed)
        {
            TrackingConsentStatus answer;
            try
            {
                // iOS ignores the request while the app is not active, so it waits for focus first.
                while (!_client.IsFocused) await _wait();
                if (Status == TrackingConsentStatus.NotDetermined) _client.RequestAuthorization();
                while (Status == TrackingConsentStatus.NotDetermined) await _wait();
                answer = Status;
            }
            catch (Exception)
            {
                answer = SafeStatus();
            }

            completed(answer);
        }

        private TrackingConsentStatus SafeStatus()
        {
            try { return Status; }
            catch (Exception) { return TrackingConsentStatus.NotDetermined; }
        }

        /// <summary><c>AuthorizationTrackingStatus</c>: 0 not determined, 1 restricted, 2 denied, 3 authorized.</summary>
        internal static TrackingConsentStatus Map(int status)
        {
            switch (status)
            {
                case 0: return TrackingConsentStatus.NotDetermined;
                case 1: return TrackingConsentStatus.Restricted;
                case 2: return TrackingConsentStatus.Denied;
                case 3: return TrackingConsentStatus.Authorized;
                default: return TrackingConsentStatus.NotDetermined;
            }
        }
    }
}
