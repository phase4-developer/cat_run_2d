#if UNITY_IOS && !UNITY_EDITOR
using System;
using Unity.Advertisement.IosSupport;
using UnityEngine;
#endif

namespace PlatformLibrary.Tracking.Apple
{
    /// <summary>The only type that touches iOS 14 Advertising Support. Outside an iOS Player it reports itself unavailable.</summary>
    internal sealed class AppleTrackingSdkClient : IAppleTrackingClient
    {
#if UNITY_IOS && !UNITY_EDITOR
        // A version that cannot be read is treated as recent, as the original did.
        public bool IsAvailable => !Version.TryParse(UnityEngine.iOS.Device.systemVersion, out Version version) || version.Major >= 14;

        public bool IsFocused => Application.isFocused;

        public int GetStatus() => (int)ATTrackingStatusBinding.GetAuthorizationTrackingStatus();

        public void RequestAuthorization() => ATTrackingStatusBinding.RequestAuthorizationTracking();
#else
        public bool IsAvailable => false;

        public bool IsFocused => true;

        public int GetStatus() => 0;

        public void RequestAuthorization()
        {
        }
#endif
    }
}
