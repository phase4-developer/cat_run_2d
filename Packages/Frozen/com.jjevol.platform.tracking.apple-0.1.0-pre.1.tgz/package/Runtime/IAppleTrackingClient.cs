namespace PlatformLibrary.Tracking.Apple
{
    /// <summary>The calls <see cref="AppleTrackingConsentProvider"/> makes. Status values are <c>AuthorizationTrackingStatus</c> numbers.</summary>
    internal interface IAppleTrackingClient
    {
        /// <summary>An iOS 14 or later Player, where App Tracking Transparency exists.</summary>
        bool IsAvailable { get; }

        bool IsFocused { get; }

        int GetStatus();

        void RequestAuthorization();
    }
}
