# JJEvol Platform Tracking Apple

`AppleTrackingConsentProvider` for `com.jjevol.platform.tracking`: Apple App Tracking Transparency through Unity's iOS 14 Advertising Support (`com.unity.ads.ios-support` 1.0.1, installed with this package).

Status: local validation candidate. Tested in the Editor; an iOS Player and the real prompt are NOT_RUN.

- On an iOS 14 or later Player it waits until the app has focus, because iOS ignores the request otherwise. It shows the system prompt once and answers when the player decides.
- A status already decided answers at once without the prompt.
- Before iOS 14, in the Editor and on other platforms it is `Unsupported`.
- The assembly builds for the Editor and iOS only. Choose the provider in start-up code under `#if UNITY_IOS`.
- Add `NSUserTrackingUsageDescription` to the iOS build's Info.plist; the project owns that text. Without it iOS ignores the request and the status stays `NotDetermined`, so a call with no time limit never answers. Pass a time limit to `RequestIfNeeded` when start-up waits for the answer.
