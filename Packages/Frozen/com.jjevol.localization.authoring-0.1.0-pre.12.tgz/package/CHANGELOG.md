# Changelog

## 0.1.0-pre.12 - 2026-11-10

- Depends on `com.jjevol.tables.authoring` 0.1.0-pre.10 (ConsumeTypes diagnostics name the source row). Code in this package is unchanged.

## 0.1.0-pre.11 - 2026-11-10

- `Custom/Localization/Google Sheet/Download & Import` is now `JJEvol/Localization/Sheet Import`, and its window is titled `Localization Sheet Import`.
- `Tools/Localization/Convert Selected LocalizeStringEvent To LocalizeTmpTextEvent` is now `JJEvol/Localization/Convert Selected to LocalizeTmpTextEvent`. The component context menu is unchanged.
- `GameObject/UI/LocalizeText` is now `GameObject/UI/JJEvol/Localized Text (TMP)`. The created object is unchanged.
- Depends on `com.jjevol.tables.authoring` 0.1.0-pre.9 (columns matched by name, spreadsheet link, `JJEvol/Tables/Table Builder` menu).
- Framework menus are grouped by feature under one `JJEvol/` root (Editor menus), `Assets/Create/JJEvol/` (asset menus) and `GameObject/UI/JJEvol/` (UI objects). Only the menu path changed; class names, serialized fields and GUIDs are unchanged, so existing assets keep working.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.10 - 2026-11-10

- Sheets download from `https://docs.google.com/spreadsheets/d/{id}/export?format=csv&gid={gid}` instead of the gviz query endpoint. gviz guessed column types and header rows and could drop or merge cell values. The gviz preamble stripping is removed with it. Its line ending handling stays: a download is kept with LF and without a final line ending, so a repeated download writes the same bytes and no empty last row is read.
- Breaking: Manual Sheets is now `Name=gid`, comma-separated (for example `UI=0,Shop=1234567890`). The export endpoint selects a sheet only by gid. An entry without a valid gid fails before any download. The serialized field is renamed `manualSheets`.
- Breaking: the Google API key is no longer serialized with the window and no longer read from `CommonDataToolSettings` (its `GoogleApiKey` member is removed in tables.authoring 0.1.0-pre.8). The key is stored per user in EditorPrefs (`JJEvol.Localization.Authoring.GoogleApiKey`), outside the project, is still drawn as a password field, and Forget removes it.
- Depends on `com.jjevol.tables.authoring` 0.1.0-pre.8.

Unity 6000.3.9f1 on `Hosts/CombinedValidationHost`: the first run, job `pkg1110-comb-edit-locauth-01`, failed 3 tests (an empty last row and a trailing line break from the download), fixed by the line ending normalization above. The rerun, job `pkg1110-comb-edit-locauth-02`, passed 115/115. A real Google sheet download is NOT_RUN (one user check).

## 0.1.0-pre.9 - 2026-11-09

- Depends on `com.jjevol.tables.authoring` 0.1.0-pre.7, which waits briefly when Windows reports `File.Replace` `0x80070497`. Code in this package is unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.8 - 2026-11-09

- Compiles on Unity 6.7. The import transaction compares object identity through `GetEntityId()` on 6.7 and the instance ID on 6000.3. Behaviour is unchanged.

## 0.1.0-pre.7 - 2026-11-08

- Tests only. `LocalizationAuthoringRunResidue` removes the run's Addressables groups and labels only when Addressables settings existed when the run started. Without settings there is no snapshot, and the cleanup would have removed every group the run created, `Default Local Group` included.
- Runtime and Editor code are unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.6 - 2026-11-08

- Version 0.1.0-pre.6 follows the test-only 0.1.0-pre.5 on `fix/localization-authoring-test-residue`.
- The LocalizeText creation menu no longer adds `LocalizeTmpStyleEvent`, which `com.jjevol.localization` 0.1.0-pre.3 removed.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.5 - 2026-11-08

- Tests only. Import, transaction, protection, Inspector and build check tests remove what they leave in the Host: their fixture folders, an emptied `Step24AuthoringFixtures`, `Ae1LocalizationFixtures` or `T1LocalizationFixtures` root, and, once after the last test, the Addressables groups and labels the run created (`Ae1SaveGuard_*` and the extra Locale groups). Removing a group mid-run and creating one of the same name later in the same Editor session breaks the import's persisted verification, so groups are not removed per test. A test that saved the untitled scene into its folder opens an empty scene first.
- `RestartProofTests` is unchanged and still keeps its collection for the next run.
- Runtime and Editor code are unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.4 - 2026-11-07

- Fetch Sheets keeps each sheet's title and gid and shows a checkbox list, all on by default. Only checked sheets are downloaded, by gid. Manual Sheets names are still downloaded by name.
- The Google API Key field is a password field. The serialized field and its `CommonDataToolSettings` default are unchanged.
- Player build now stops with the table path and Locale code when a `Localization`-labelled StringTable has no registered Locale. `LocalizationManager` would throw on it during initialization, and its behaviour is unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.3 - 2026-11-06

- Google Sheet import is now Preview then Apply. Sheets with no keys are rejected, deletion impact is reported, and large deletions need confirmation.
- Preamble stripping stops at the first record.

Unity tests for this candidate are NOT_RUN.
