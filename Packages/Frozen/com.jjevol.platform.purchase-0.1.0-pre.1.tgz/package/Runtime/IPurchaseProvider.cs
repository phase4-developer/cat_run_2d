using System;
using System.Collections.Generic;

namespace PlatformLibrary.Purchase
{
    /// <summary>
    /// Connects one store SDK to <see cref="PurchaseManager"/>. Games do not call this.
    /// <para>
    /// The manager calls every member on the Unity main thread, one store call at a time, and handles
    /// busy checks, duplicate orders, verification and when to close an order. A provider only talks to its SDK
    /// and turns SDK codes into <see cref="PurchaseFailure"/>. It does not throw for an ordinary failure.
    /// </para>
    /// <para>Callbacks and <see cref="UnrequestedOrderReceived"/> may be used from any thread. Call each callback once.</para>
    /// </summary>
    public interface IPurchaseProvider
    {
        /// <summary>For logs.</summary>
        string Name { get; }

        /// <summary>
        /// The store sent a paid order nobody asked for while the game runs, such as an approved deferred purchase.
        /// The manager keeps it for <see cref="PurchaseManager.RecoverPendingPurchases"/>. Orders left from an earlier
        /// run are not announced here: <see cref="FetchPendingOrders"/> finds them.
        /// </summary>
        event Action<PurchaseOrder> UnrequestedOrderReceived;

        /// <summary>Connects to the store and fetches these products. May be called again to retry or refresh.</summary>
        void Initialize(IReadOnlyList<PurchaseProductDefinition> products, Action<PurchaseStatus> completed);

        /// <summary>A fetched product by the project's ID, or null.</summary>
        PurchaseProduct GetProduct(string productId);

        /// <summary>
        /// Starts the store's payment flow. On payment, answers success with a <see cref="PurchaseOrderState.Pending"/>
        /// order and does not close it. Orders for other products that arrive meanwhile go to <see cref="UnrequestedOrderReceived"/>.
        /// </summary>
        void Purchase(PurchaseRequest request, Action<PurchaseStatus, PurchaseOrder> completed);

        /// <summary>Paid orders that are not closed yet.</summary>
        void FetchPendingOrders(Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> completed);

        /// <summary>Orders the player owns, closed or not, for a restore. On iOS this is where transactions are restored.</summary>
        void FetchOwnedOrders(Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> completed);

        /// <summary>Closes a verified <see cref="PurchaseOrderState.Pending"/> order: consumes or acknowledges it.</summary>
        void Confirm(PurchaseOrder order, Action<PurchaseStatus> completed);
    }
}
