using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Purchase.Tests.Editor")]
[assembly: InternalsVisibleTo("PlatformLibrary.Purchase.Tests.Runtime")]
