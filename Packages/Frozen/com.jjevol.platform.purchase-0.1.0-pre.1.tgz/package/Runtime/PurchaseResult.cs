using System;
using System.Collections.Generic;
using System.Linq;

namespace PlatformLibrary.Purchase
{
    /// <summary>The end of one purchase or one order in a batch.</summary>
    public readonly struct PurchaseResult
    {
        private readonly string _productId;
        private readonly string _serverErrorCode;
        private readonly string _detail;

        public PurchaseFailure Failure { get; }
        public bool Success => Failure == PurchaseFailure.None;

        /// <summary>The project's product ID. Empty for <see cref="PurchaseManager.Initialize"/>.</summary>
        public string ProductId => _productId ?? string.Empty;

        /// <summary>Transaction ID, price and currency. Null when the store returned no order.</summary>
        public PurchaseOrder Order { get; }

        /// <summary>The server had already granted this order. Count revenue only when this is false.</summary>
        public bool AlreadyGranted { get; }

        /// <summary>What the verifier passed on from the server, such as a reward list. The project decides its type.</summary>
        public object Grant { get; }

        /// <summary>The store SDK's own code. For logs only.</summary>
        public int ProviderCode { get; }

        /// <summary>The server's own result code. For logs only.</summary>
        public string ServerErrorCode => _serverErrorCode ?? string.Empty;

        public string Detail => _detail ?? string.Empty;

        private PurchaseResult(PurchaseFailure failure, string productId, PurchaseOrder order, bool alreadyGranted, object grant, int providerCode, string serverErrorCode, string detail)
        {
            Failure = failure;
            _productId = productId ?? string.Empty;
            Order = order;
            AlreadyGranted = alreadyGranted;
            Grant = grant;
            ProviderCode = providerCode;
            _serverErrorCode = serverErrorCode ?? string.Empty;
            _detail = detail ?? string.Empty;
        }

        /// <summary>The <see cref="Grant"/> as <typeparamref name="T"/>, or the default when it is not one.</summary>
        public T GetGrant<T>() => Grant is T grant ? grant : default;

        internal static PurchaseResult Succeeded(string productId, PurchaseOrder order = null, bool alreadyGranted = false, object grant = null, string serverErrorCode = "", string detail = "") =>
            new PurchaseResult(PurchaseFailure.None, productId, order, alreadyGranted, grant, 0, serverErrorCode, detail);

        internal static PurchaseResult Failed(PurchaseFailure failure, string productId, PurchaseOrder order = null, int providerCode = 0, string detail = "", string serverErrorCode = "") =>
            new PurchaseResult(failure == PurchaseFailure.None ? PurchaseFailure.ProviderError : failure, productId, order, false, null, providerCode, serverErrorCode, detail);

        internal static PurchaseResult From(PurchaseStatus status, string productId, PurchaseOrder order = null) =>
            status.Success ? Succeeded(productId, order, detail: status.Detail) : Failed(status.Failure, productId, order, status.ProviderCode, status.Detail);

        public override string ToString() => (Success ? "None" : Failure.ToString()) + " " + ProductId + " " + Detail;
    }

    /// <summary>The end of <see cref="PurchaseManager.RecoverPendingPurchases"/> or <see cref="PurchaseManager.RestorePurchases"/>.</summary>
    public sealed class PurchaseBatchResult
    {
        /// <summary>Why the order list could not be fetched. None when it was, even if some orders failed.</summary>
        public PurchaseFailure Failure { get; }

        public bool Success => Failure == PurchaseFailure.None;
        public int ProviderCode { get; }
        public string Detail { get; }

        /// <summary>One result for each order handled, in order. Orders handled before a failure stay here.</summary>
        public IReadOnlyList<PurchaseResult> Results { get; }

        /// <summary>The results that succeeded, including orders the server had already granted.</summary>
        public IEnumerable<PurchaseResult> Granted => Results.Where(result => result.Success);

        internal PurchaseBatchResult(PurchaseFailure failure, int providerCode, string detail, IReadOnlyList<PurchaseResult> results)
        {
            Failure = failure;
            ProviderCode = providerCode;
            Detail = detail ?? string.Empty;
            Results = results ?? Array.Empty<PurchaseResult>();
        }

        internal static PurchaseBatchResult Failed(PurchaseFailure failure, int providerCode = 0, string detail = "", IReadOnlyList<PurchaseResult> results = null) =>
            new PurchaseBatchResult(failure == PurchaseFailure.None ? PurchaseFailure.ProviderError : failure, providerCode, detail, results);
    }
}
