using System;
using System.Collections.Generic;
using System.Globalization;

namespace PlatformLibrary.Purchase
{
    /// <summary>Formats a raw store amount with its ISO currency code, for stores that return only a number.</summary>
    public static class PurchasePriceFormatter
    {
        private const string AmountFormat = "#,0.############################";
        private static readonly Dictionary<string, NumberFormatInfo> CurrencyFormats = CreateCurrencyFormats();

        public static string Format(string price, string currencyCode)
        {
            // Store amounts use a decimal point. Do not interpret a localized decimal comma as a thousands separator.
            const NumberStyles styles = NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint;
            if (!decimal.TryParse(price, styles, CultureInfo.InvariantCulture, out decimal amount))
                return price ?? string.Empty;

            string code = currencyCode?.Trim().ToUpperInvariant() ?? string.Empty;
            if (CurrencyFormats.TryGetValue(code, out NumberFormatInfo format))
            {
                string significantAmount = amount.ToString("0.############################", CultureInfo.InvariantCulture);
                int decimalPoint = significantAmount.IndexOf('.');
                int decimalDigits = decimalPoint < 0 ? 0 : significantAmount.Length - decimalPoint - 1;
                // Keep the currency's normal precision without rounding away a supplied fractional amount.
                int precision = Math.Max(format.CurrencyDecimalDigits, decimalDigits);
                return amount.ToString("C" + precision.ToString(CultureInfo.InvariantCulture), format);
            }

            string formattedAmount = amount.ToString(AmountFormat, CultureInfo.InvariantCulture);
            return code.Length > 0 ? code + " " + formattedAmount : formattedAmount;
        }

        private static Dictionary<string, NumberFormatInfo> CreateCurrencyFormats()
        {
            var formats = new Dictionary<string, NumberFormatInfo>(StringComparer.Ordinal);
            CultureInfo[] cultures;
            try
            {
                cultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
            }
            catch (NotSupportedException)
            {
                return formats;
            }

            // Enumeration order is unspecified; select the first usable culture by ordinal name.
            Array.Sort(cultures, (left, right) => StringComparer.Ordinal.Compare(left.Name, right.Name));
            foreach (CultureInfo culture in cultures)
            {
                try
                {
                    var region = new RegionInfo(culture.Name);
                    string code = region.ISOCurrencySymbol;
                    if (string.IsNullOrEmpty(code) || formats.ContainsKey(code)) continue;

                    NumberFormatInfo format = new CultureInfo(culture.Name, false).NumberFormat;
                    string symbol = format.CurrencySymbol;
                    if (string.IsNullOrWhiteSpace(symbol) || symbol == "\u00a4" || string.Equals(symbol, code, StringComparison.OrdinalIgnoreCase)) continue;

                    formats.Add(code, NumberFormatInfo.ReadOnly(format));
                }
                catch (ArgumentException)
                {
                    // Some runtimes expose cultures without usable region data. Leave them on the code fallback.
                }
            }

            return formats;
        }
    }
}
