using System;
using System.Collections.Generic;

namespace PlatformLibrary.Purchase
{
    /// <summary>
    /// The manager's work for one provider. Runs on the main thread. One call at a time: initialize, purchase,
    /// recover or restore. Ends every call once, also when the provider is replaced.
    /// </summary>
    internal sealed class PurchaseSession
    {
        internal const float DefaultVerificationTimeoutSeconds = 90f;

        private sealed class Operation
        {
            public readonly bool ShowsLoading;
            /// <summary>Orders this call verifies. The store may announce them again while the call runs.</summary>
            public readonly HashSet<string> Keys = new HashSet<string>(StringComparer.Ordinal);
            public Action<PurchaseFailure, int, string> Abort;

            public Operation(bool showsLoading) => ShowsLoading = showsLoading;
        }

        private readonly IPurchaseProvider _provider;
        private readonly IPurchaseHost _host;
        private readonly Func<IPurchaseVerifier> _verifier;
        private readonly Action<PurchaseResult> _completed;
        private readonly Action<PurchaseOrder> _pendingDetected;
        private readonly Action<bool> _loadingChanged;
        private readonly Func<float> _verificationTimeoutSeconds;
        private readonly Dictionary<string, PurchaseOrder> _held = new Dictionary<string, PurchaseOrder>(StringComparer.Ordinal);
        private readonly HashSet<string> _closing = new HashSet<string>(StringComparer.Ordinal);
        private Operation _current;
        private bool _closed;

        public PurchaseSession(IPurchaseProvider provider, IPurchaseHost host, Func<IPurchaseVerifier> verifier,
            Action<PurchaseResult> completed, Action<PurchaseOrder> pendingDetected, Action<bool> loadingChanged,
            Func<float> verificationTimeoutSeconds)
        {
            _provider = provider ?? throw new ArgumentNullException(nameof(provider));
            _host = host ?? throw new ArgumentNullException(nameof(host));
            _verifier = verifier;
            _completed = completed;
            _pendingDetected = pendingDetected;
            _loadingChanged = loadingChanged;
            _verificationTimeoutSeconds = verificationTimeoutSeconds ?? throw new ArgumentNullException(nameof(verificationTimeoutSeconds));
            _provider.UnrequestedOrderReceived += OnUnrequestedOrder;
        }

        public IPurchaseProvider Provider => _provider;
        public bool IsInitialized { get; private set; }
        public bool IsLoading { get; private set; }
        public bool HasPendingPurchases => _held.Count > 0;

        public PurchaseProduct GetProduct(string productId)
        {
            if (string.IsNullOrWhiteSpace(productId)) return null;
            try { return _provider.GetProduct(productId); }
            catch (Exception exception)
            {
                _host.LogException(exception);
                return null;
            }
        }

        public void Initialize(IReadOnlyList<PurchaseProductDefinition> products, Action<PurchaseResult> callback)
        {
            if (_current != null)
            {
                Invoke(callback, PurchaseResult.Failed(PurchaseFailure.Busy, string.Empty));
                return;
            }

            var operation = new Operation(false);
            operation.Abort = (failure, code, detail) => EndInitialize(operation, PurchaseStatus.Failed(failure, code, detail), callback);
            Begin(operation);
            Call(operation, () => _provider.Initialize(products, status => _host.Post(() => EndInitialize(operation, status, callback))));
        }

        public void Purchase(PurchaseRequest request, Action<PurchaseResult> callback)
        {
            string productId = request.ProductId;
            PurchaseFailure refusal = PurchaseFailure.None;
            if (!IsInitialized) refusal = PurchaseFailure.NotInitialized;
            else if (_current != null) refusal = PurchaseFailure.Busy;
            else
            {
                PurchaseProduct product = GetProduct(productId);
                if (product == null || !product.AvailableToPurchase) refusal = PurchaseFailure.ProductUnavailable;
            }

            if (refusal != PurchaseFailure.None)
            {
                Invoke(callback, PurchaseResult.Failed(refusal, productId));
                return;
            }

            var operation = new Operation(true);
            operation.Abort = (failure, code, detail) => EndPurchase(operation, PurchaseResult.Failed(failure, productId, null, code, detail), callback);
            Begin(operation);
            Call(operation, () => _provider.Purchase(request, (status, order) => _host.Post(() => OnPaid(operation, productId, status, order, callback))));
        }

        public void RecoverPendingPurchases(Action<PurchaseBatchResult> callback) => RunBatch(false, callback);

        public void RestorePurchases(Action<PurchaseBatchResult> callback) => RunBatch(true, callback);

        /// <summary>Ends a running call with <see cref="PurchaseFailure.ProviderError"/> and ignores the provider from now on.</summary>
        public void Close()
        {
            if (_closed) return;
            _closed = true;
            _provider.UnrequestedOrderReceived -= OnUnrequestedOrder;
            _held.Clear();
            _closing.Clear();
            _current?.Abort(PurchaseFailure.ProviderError, 0, "PROVIDER_CHANGED");
        }

        private void EndInitialize(Operation operation, PurchaseStatus status, Action<PurchaseResult> callback)
        {
            if (!End(operation)) return;
            IsInitialized = status.Success && !_closed;
            Invoke(callback, PurchaseResult.From(status, string.Empty));
        }

        private void OnPaid(Operation operation, string productId, PurchaseStatus status, PurchaseOrder order, Action<PurchaseResult> callback)
        {
            if (!ReferenceEquals(_current, operation)) return;
            if (!status.Success)
            {
                EndPurchase(operation, PurchaseResult.Failed(status.Failure, productId, order, status.ProviderCode, status.Detail), callback);
                return;
            }

            if (order == null)
            {
                EndPurchase(operation, PurchaseResult.Failed(PurchaseFailure.ProviderError, productId, null, status.ProviderCode, "NO_ORDER"), callback);
                return;
            }

            _held.Remove(order.Key);
            operation.Keys.Add(order.Key);
            Verify(operation, order, result => EndPurchase(operation, result, callback));
        }

        private void EndPurchase(Operation operation, PurchaseResult result, Action<PurchaseResult> callback)
        {
            if (!End(operation)) return;
            if (result.Success) Raise(_completed, result);
            Invoke(callback, result);
        }

        private void RunBatch(bool restore, Action<PurchaseBatchResult> callback)
        {
            if (!IsInitialized || _current != null)
            {
                Invoke(callback, PurchaseBatchResult.Failed(IsInitialized ? PurchaseFailure.Busy : PurchaseFailure.NotInitialized));
                return;
            }

            var results = new List<PurchaseResult>();
            var operation = new Operation(true);
            operation.Abort = (failure, code, detail) => EndBatch(operation, PurchaseBatchResult.Failed(failure, code, detail, results), callback);
            Begin(operation);

            Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> fetched = (status, orders) =>
                _host.Post(() => OnFetched(operation, restore, status, orders, results, callback));
            Call(operation, () =>
            {
                if (restore) _provider.FetchOwnedOrders(fetched);
                else _provider.FetchPendingOrders(fetched);
            });
        }

        private void OnFetched(Operation operation, bool restore, PurchaseStatus status, IReadOnlyList<PurchaseOrder> orders,
            List<PurchaseResult> results, Action<PurchaseBatchResult> callback)
        {
            if (!ReferenceEquals(_current, operation)) return;
            if (!status.Success)
            {
                EndBatch(operation, PurchaseBatchResult.Failed(status.Failure, status.ProviderCode, status.Detail, results), callback);
                return;
            }

            var queue = new List<PurchaseOrder>();
            var keys = new HashSet<string>(StringComparer.Ordinal);
            if (orders != null)
            {
                foreach (PurchaseOrder order in orders)
                {
                    if (order == null || (restore && !IsRestorable(order)) || (!restore && order.State != PurchaseOrderState.Pending)) continue;
                    // Already granted and being closed. The store may still list it until the close lands.
                    if (_closing.Contains(order.Key)) continue;
                    if (keys.Add(order.Key)) queue.Add(order);
                }
            }

            if (!restore)
            {
                foreach (PurchaseOrder order in _held.Values)
                    if (keys.Add(order.Key)) queue.Add(order);
            }

            foreach (string key in keys) _held.Remove(key);
            operation.Keys.UnionWith(keys);
            VerifyNext(operation, queue, 0, results, callback);
        }

        private void VerifyNext(Operation operation, List<PurchaseOrder> queue, int index, List<PurchaseResult> results, Action<PurchaseBatchResult> callback)
        {
            if (!ReferenceEquals(_current, operation)) return;
            if (index >= queue.Count)
            {
                EndBatch(operation, new PurchaseBatchResult(PurchaseFailure.None, 0, string.Empty, results), callback);
                return;
            }

            Verify(operation, queue[index], result =>
            {
                results.Add(result);
                if (result.Success) Raise(_completed, result);
                VerifyNext(operation, queue, index + 1, results, callback);
            });
        }

        private void EndBatch(Operation operation, PurchaseBatchResult result, Action<PurchaseBatchResult> callback)
        {
            if (!End(operation)) return;
            Invoke(callback, result);
        }

        private void Verify(Operation operation, PurchaseOrder order, Action<PurchaseResult> done)
        {
            IPurchaseVerifier verifier = _verifier?.Invoke();
            if (verifier == null)
            {
                done(PurchaseResult.Failed(PurchaseFailure.VerifierMissing, order.ProductId, order, 0, "NO_VERIFIER"));
                return;
            }

            bool answered = false;
            Action cancelTimeout = null;

            bool Claim()
            {
                if (answered || !ReferenceEquals(_current, operation)) return false;
                answered = true;
                cancelTimeout?.Invoke();
                return true;
            }

            // Read for each order, so a change applies to the next verification.
            cancelTimeout = _host.Schedule(_verificationTimeoutSeconds(), () =>
            {
                if (!Claim()) return;
                _host.LogWarning("Verification timed out. The order stays pending: " + order.Key);
                done(PurchaseResult.Failed(PurchaseFailure.VerificationUnavailable, order.ProductId, order, 0, "VERIFICATION_TIMEOUT"));
            });

            try
            {
                verifier.Verify(order, verification => _host.Post(() =>
                {
                    if (Claim()) Settle(order, verification, done);
                }));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                if (Claim()) done(PurchaseResult.Failed(PurchaseFailure.VerificationUnavailable, order.ProductId, order, 0, exception.Message));
            }
        }

        private void Settle(PurchaseOrder order, PurchaseVerification verification, Action<PurchaseResult> done)
        {
            string productId = order.ProductId;
            switch (verification.Verdict)
            {
                case PurchaseVerdict.Granted:
                    Confirm(order);
                    done(PurchaseResult.Succeeded(productId, order, false, verification.Grant, verification.ServerErrorCode, verification.Detail));
                    break;
                case PurchaseVerdict.AlreadyGranted:
                    Confirm(order);
                    done(PurchaseResult.Succeeded(productId, order, true, verification.Grant, verification.ServerErrorCode, verification.Detail));
                    break;
                case PurchaseVerdict.Rejected:
                    Confirm(order);
                    done(PurchaseResult.Failed(PurchaseFailure.VerificationRejected, productId, order, 0, verification.Detail, verification.ServerErrorCode));
                    break;
                default:
                    done(PurchaseResult.Failed(PurchaseFailure.VerificationUnavailable, productId, order, 0, verification.Detail, verification.ServerErrorCode));
                    break;
            }
        }

        /// <summary>
        /// Closes the order at the store without waiting. If closing fails, the order stays pending, comes back in the
        /// next recovery and is answered <see cref="PurchaseVerdict.AlreadyGranted"/> by the server.
        /// </summary>
        private void Confirm(PurchaseOrder order)
        {
            if (order.State != PurchaseOrderState.Pending) return;
            string key = order.Key;
            // A close already running for this order keeps its mark. A second close would fail and clear it.
            if (!_closing.Add(key)) return;
            try
            {
                _provider.Confirm(order, status => _host.Post(() =>
                {
                    if (status.Success || _closed) return;
                    _closing.Remove(key);
                    _host.LogWarning("Closing the order failed. It stays pending: " + key + " " + status);
                }));
            }
            catch (Exception exception)
            {
                _closing.Remove(key);
                _host.LogException(exception);
            }
        }

        private void OnUnrequestedOrder(PurchaseOrder order)
        {
            _host.Post(() =>
            {
                if (_closed || order == null || order.State != PurchaseOrderState.Pending) return;
                // Already settled or being verified now. Holding it again would report an order that is no longer pending.
                if (_closing.Contains(order.Key) || (_current != null && _current.Keys.Contains(order.Key))) return;
                _held[order.Key] = order;
                Raise(_pendingDetected, order);
            });
        }

        private static bool IsRestorable(PurchaseOrder order)
        {
            PurchaseProductType type = order.Product.Definition.Type;
            return type == PurchaseProductType.NonConsumable || type == PurchaseProductType.Subscription;
        }

        private void Begin(Operation operation)
        {
            _current = operation;
            if (!operation.ShowsLoading) return;
            IsLoading = true;
            Raise(_loadingChanged, true);
        }

        /// <summary>Clears the running call if it is <paramref name="operation"/>. False when it already ended.</summary>
        private bool End(Operation operation)
        {
            if (!ReferenceEquals(_current, operation)) return false;
            _current = null;
            if (operation.ShowsLoading)
            {
                IsLoading = false;
                Raise(_loadingChanged, false);
            }

            return true;
        }

        private void Call(Operation operation, Action call)
        {
            try { call(); }
            catch (Exception exception)
            {
                _host.LogException(exception);
                if (ReferenceEquals(_current, operation)) operation.Abort(PurchaseFailure.ProviderError, 0, exception.Message);
            }
        }

        private void Invoke<T>(Action<T> callback, T value)
        {
            if (callback == null) return;
            try { callback(value); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void Raise<T>(Action<T> handler, T value) => Invoke(handler, value);
    }
}
