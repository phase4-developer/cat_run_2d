using System;

namespace PlatformLibrary.Purchase
{
    public enum PurchaseVerdict
    {
        /// <summary>The server checked the receipt with the store, recorded the order and granted it.</summary>
        Granted,

        /// <summary>The server had already recorded this order. Nothing new is granted, and the order is closed.</summary>
        AlreadyGranted,

        /// <summary>The server rejected the receipt. The order is closed and nothing is granted.</summary>
        Rejected,

        /// <summary>No answer. The order stays pending at the store and is tried again later.</summary>
        Unavailable
    }

    /// <summary>A verifier's answer for one order.</summary>
    public readonly struct PurchaseVerification
    {
        private readonly string _serverErrorCode;
        private readonly string _detail;

        public PurchaseVerdict Verdict { get; }

        /// <summary>What the server granted, such as a reward list. Passed to <see cref="PurchaseResult.Grant"/> unchanged.</summary>
        public object Grant { get; }

        /// <summary>The server's own result code, such as ReceiptAlreadyUsed. For logs only.</summary>
        public string ServerErrorCode => _serverErrorCode ?? string.Empty;

        public string Detail => _detail ?? string.Empty;

        private PurchaseVerification(PurchaseVerdict verdict, object grant, string serverErrorCode, string detail)
        {
            Verdict = verdict;
            Grant = grant;
            _serverErrorCode = serverErrorCode ?? string.Empty;
            _detail = detail ?? string.Empty;
        }

        public static PurchaseVerification Granted(object grant = null, string serverErrorCode = "", string detail = "") =>
            new PurchaseVerification(PurchaseVerdict.Granted, grant, serverErrorCode, detail);

        public static PurchaseVerification AlreadyGranted(object grant = null, string serverErrorCode = "", string detail = "") =>
            new PurchaseVerification(PurchaseVerdict.AlreadyGranted, grant, serverErrorCode, detail);

        public static PurchaseVerification Rejected(string serverErrorCode = "", string detail = "") =>
            new PurchaseVerification(PurchaseVerdict.Rejected, null, serverErrorCode, detail);

        public static PurchaseVerification Unavailable(string serverErrorCode = "", string detail = "") =>
            new PurchaseVerification(PurchaseVerdict.Unavailable, null, serverErrorCode, detail);
    }

    /// <summary>
    /// Decides whether an order is paid. The project implements it, usually with a call to its server, which checks
    /// <see cref="PurchaseOrder.VerificationData"/> with the store, records <see cref="PurchaseOrder.TransactionId"/> once and grants.
    /// <para>
    /// The manager closes the order at the store only after <see cref="PurchaseVerdict.Granted"/>,
    /// <see cref="PurchaseVerdict.AlreadyGranted"/> or <see cref="PurchaseVerdict.Rejected"/>. Answer
    /// <see cref="PurchaseVerdict.Unavailable"/> for anything the server did not finish, so the order can be tried again.
    /// </para>
    /// </summary>
    public interface IPurchaseVerifier
    {
        /// <summary>Call <paramref name="completed"/> once, from any thread. An answer after the manager's timeout is ignored.</summary>
        void Verify(PurchaseOrder order, Action<PurchaseVerification> completed);
    }

    /// <summary>
    /// Grants every order without a server. A modified client can then fake or repeat purchases, so use it only for
    /// development or for a game that has decided to accept that risk. The project has to set it explicitly.
    /// </summary>
    public sealed class UnverifiedPurchaseVerifier : IPurchaseVerifier
    {
        public const string ServerErrorCode = "UNVERIFIED";

        public void Verify(PurchaseOrder order, Action<PurchaseVerification> completed)
        {
            completed?.Invoke(PurchaseVerification.Granted(null, ServerErrorCode, "Granted without server verification."));
        }
    }
}
