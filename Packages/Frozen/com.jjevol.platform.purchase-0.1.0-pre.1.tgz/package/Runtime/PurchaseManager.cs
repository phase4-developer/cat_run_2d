using System;
using System.Collections.Generic;
using UnityEngine;

namespace PlatformLibrary.Purchase
{
    /// <summary>
    /// The only purchase API a game uses. Call it from the Unity main thread. Every callback runs once, on the main thread.
    /// With no provider set, purchase calls answer <see cref="PurchaseFailure.Unsupported"/> and the game keeps running.
    /// <para>
    /// A client callback is not proof of payment. The manager closes a store order only after the verifier's
    /// verdict, and grants come from the verifier's server, not from this class.
    /// </para>
    /// </summary>
    public static class PurchaseManager
    {
        private static PurchaseSession _session;
        private static IPurchaseVerifier _verifier;
        private static float _verificationTimeoutSeconds = PurchaseSession.DefaultVerificationTimeoutSeconds;

        /// <summary>
        /// An order was granted, by a purchase, a recovery or a restore. For analytics. Check
        /// <see cref="PurchaseResult.AlreadyGranted"/> so revenue is counted once.
        /// </summary>
        public static event Action<PurchaseResult> PurchaseCompleted;

        /// <summary>
        /// The store sent a paid order that no call asked for while the game runs. Call <see cref="RecoverPendingPurchases"/>
        /// when the game can show what it grants. Orders from an earlier run are not reported here; only a recovery finds them.
        /// </summary>
        public static event Action<PurchaseOrder> PendingPurchaseDetected;

        /// <summary>
        /// A purchase, recovery or restore started or ended, so the project can show its loading indicator.
        /// Every start is followed by an end, before the call's callback runs.
        /// </summary>
        public static event Action<bool> LoadingChanged;

        /// <summary>The store is connected and the products were fetched.</summary>
        public static bool IsInitialized => _session != null && _session.IsInitialized;

        public static bool IsLoading => _session != null && _session.IsLoading;

        /// <summary>
        /// An order from <see cref="PendingPurchaseDetected"/> waits for <see cref="RecoverPendingPurchases"/>. False does not
        /// mean nothing is pending: orders from an earlier run show only in a recovery, so call it after every successful initialize.
        /// </summary>
        public static bool HasPendingPurchases => _session != null && _session.HasPendingPurchases;

        /// <summary>
        /// Sets the provider, or removes it with null. A replaced provider's running call ends with
        /// <see cref="PurchaseFailure.ProviderError"/>, and the new one starts uninitialized. The project owns the provider's lifetime.
        /// </summary>
        public static void SetProvider(IPurchaseProvider provider)
        {
            SetProvider(provider, provider == null ? null : UnityPurchaseHost.Instance);
        }

        /// <summary>
        /// How long the manager waits for the verifier before it ends the call as
        /// <see cref="PurchaseFailure.VerificationUnavailable"/>. The order stays pending, and the next recovery verifies it
        /// again. A safety limit, so keep it longer than the verifier's own request limit. 90 seconds by default. Read for each order.
        /// </summary>
        public static float VerificationTimeoutSeconds
        {
            get => _verificationTimeoutSeconds;
            set
            {
                if (!(value > 0f) || float.IsInfinity(value)) throw new ArgumentOutOfRangeException(nameof(value), value, "A positive number of seconds is required.");
                _verificationTimeoutSeconds = value;
            }
        }

        /// <summary>Sets the verifier, or removes it with null. Read at each verification.</summary>
        public static void SetVerifier(IPurchaseVerifier verifier) => _verifier = verifier;

        /// <summary>Connects to the store and fetches the products. Can be called again after a failure or to refresh.</summary>
        public static void Initialize(IReadOnlyList<PurchaseProductDefinition> products, Action<PurchaseResult> callback = null)
        {
            CheckDefinitions(products);
            if (_session != null) _session.Initialize(products, callback);
            else ReplyUnsupported(string.Empty, callback);
        }

        /// <summary>A fetched product by the project's ID, or null.</summary>
        public static PurchaseProduct GetProduct(string productId) => _session?.GetProduct(productId);

        /// <summary>The price to show, or an empty string when the product was not fetched.</summary>
        public static string GetLocalizedPrice(string productId) => GetProduct(productId)?.LocalizedPrice ?? string.Empty;

        public static void Purchase(string productId, Action<PurchaseResult> callback) => Purchase(new PurchaseRequest(productId), callback);

        /// <summary>Pays, verifies and closes the order. The callback gets the verifier's grant.</summary>
        public static void Purchase(PurchaseRequest request, Action<PurchaseResult> callback)
        {
            if (_session != null) _session.Purchase(request, callback);
            else ReplyUnsupported(request.ProductId, callback);
        }

        /// <summary>
        /// Verifies and closes paid orders that were never granted: an interrupted purchase, a timed-out verification,
        /// an approved deferred purchase. Call it at a point where the game can show what it grants.
        /// </summary>
        public static void RecoverPendingPurchases(Action<PurchaseBatchResult> callback)
        {
            if (_session != null) _session.RecoverPendingPurchases(callback);
            else ReplyUnsupported(callback);
        }

        /// <summary>Verifies the non-consumables and subscriptions the player owns. The server answers AlreadyGranted for those it knows.</summary>
        public static void RestorePurchases(Action<PurchaseBatchResult> callback)
        {
            if (_session != null) _session.RestorePurchases(callback);
            else ReplyUnsupported(callback);
        }

        /// <summary>With the manager's <see cref="VerificationTimeoutSeconds"/>, read for each order.</summary>
        internal static void SetProvider(IPurchaseProvider provider, IPurchaseHost host) =>
            SetProvider(provider, host, () => _verificationTimeoutSeconds);

        internal static void SetProvider(IPurchaseProvider provider, IPurchaseHost host, float verificationTimeoutSeconds) =>
            SetProvider(provider, host, () => verificationTimeoutSeconds);

        private static void SetProvider(IPurchaseProvider provider, IPurchaseHost host, Func<float> verificationTimeoutSeconds)
        {
            if (ReferenceEquals(_session?.Provider, provider)) return;
            PurchaseSession previous = _session;
            _session = provider == null
                ? null
                : new PurchaseSession(provider, host, () => _verifier, RaisePurchaseCompleted, RaisePendingPurchaseDetected, RaiseLoadingChanged, verificationTimeoutSeconds);
            previous?.Close();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        internal static void ResetState()
        {
            _session?.Close();
            _session = null;
            _verifier = null;
            _verificationTimeoutSeconds = PurchaseSession.DefaultVerificationTimeoutSeconds;
            PurchaseCompleted = null;
            PendingPurchaseDetected = null;
            LoadingChanged = null;
        }

        private static void CheckDefinitions(IReadOnlyList<PurchaseProductDefinition> products)
        {
            if (products == null) throw new ArgumentNullException(nameof(products));
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (PurchaseProductDefinition product in products)
            {
                if (product == null) throw new ArgumentException("A product definition is null.", nameof(products));
                if (!ids.Add(product.Id)) throw new ArgumentException("A product ID is defined twice: " + product.Id, nameof(products));
            }
        }

        private static void ReplyUnsupported(string productId, Action<PurchaseResult> callback) =>
            Reply(callback, PurchaseResult.Failed(PurchaseFailure.Unsupported, productId, null, 0, "NO_PURCHASE_PROVIDER"));

        private static void ReplyUnsupported(Action<PurchaseBatchResult> callback) =>
            Reply(callback, PurchaseBatchResult.Failed(PurchaseFailure.Unsupported, 0, "NO_PURCHASE_PROVIDER"));

        /// <summary>Without a provider there is no host, so a throwing callback is logged here, as the session would.</summary>
        private static void Reply<T>(Action<T> callback, T value)
        {
            if (callback == null) return;
            try { callback(value); }
            catch (Exception exception) { Debug.LogException(exception); }
        }

        private static void RaisePurchaseCompleted(PurchaseResult result) => PurchaseCompleted?.Invoke(result);

        private static void RaisePendingPurchaseDetected(PurchaseOrder order) => PendingPurchaseDetected?.Invoke(order);

        private static void RaiseLoadingChanged(bool active) => LoadingChanged?.Invoke(active);
    }
}
