using System;

namespace PlatformLibrary.Purchase
{
    public enum PurchaseProductType
    {
        Consumable,
        NonConsumable,
        Subscription
    }

    /// <summary>A product the project sells. The project picks the store product ID for the store it builds for.</summary>
    public sealed class PurchaseProductDefinition
    {
        /// <summary>The project's own product ID. Games use this everywhere.</summary>
        public string Id { get; }

        /// <summary>The ID registered in the store console.</summary>
        public string StoreProductId { get; }

        public PurchaseProductType Type { get; }

        public PurchaseProductDefinition(string id, string storeProductId, PurchaseProductType type = PurchaseProductType.Consumable)
        {
            if (string.IsNullOrWhiteSpace(id)) throw new ArgumentException("A product ID is required.", nameof(id));
            if (string.IsNullOrWhiteSpace(storeProductId)) throw new ArgumentException("A store product ID is required.", nameof(storeProductId));
            Id = id;
            StoreProductId = storeProductId;
            Type = type;
        }
    }

    /// <summary>A product as the store reported it.</summary>
    public sealed class PurchaseProduct
    {
        public PurchaseProductDefinition Definition { get; }
        public string Id => Definition.Id;
        public bool AvailableToPurchase { get; }

        /// <summary>The price ready to show, with its currency.</summary>
        public string LocalizedPrice { get; }

        public decimal Price { get; }

        /// <summary>ISO 4217 code, such as KRW. Empty when the store did not say.</summary>
        public string Currency { get; }

        public string Title { get; }

        public PurchaseProduct(PurchaseProductDefinition definition, bool availableToPurchase, string localizedPrice, decimal price, string currency, string title)
        {
            Definition = definition ?? throw new ArgumentNullException(nameof(definition));
            AvailableToPurchase = availableToPurchase;
            LocalizedPrice = localizedPrice ?? string.Empty;
            Price = price;
            Currency = currency ?? string.Empty;
            Title = title ?? string.Empty;
        }
    }
}
