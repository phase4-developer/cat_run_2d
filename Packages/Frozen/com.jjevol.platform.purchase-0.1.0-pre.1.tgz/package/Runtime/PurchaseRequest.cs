namespace PlatformLibrary.Purchase
{
    public readonly struct PurchaseRequest
    {
        private readonly string _productId;
        private readonly string _payload;

        /// <summary>The project's product ID, <see cref="PurchaseProductDefinition.Id"/>.</summary>
        public string ProductId => _productId ?? string.Empty;

        /// <summary>
        /// A value the store carries with the order, such as a ONE store developer payload.
        /// The project decides what goes here. A provider whose store has no such field ignores it.
        /// </summary>
        public string Payload => _payload ?? string.Empty;

        public PurchaseRequest(string productId, string payload = "")
        {
            _productId = productId ?? string.Empty;
            _payload = payload ?? string.Empty;
        }
    }
}
