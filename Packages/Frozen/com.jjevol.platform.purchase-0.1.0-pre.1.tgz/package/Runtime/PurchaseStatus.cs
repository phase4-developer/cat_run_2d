namespace PlatformLibrary.Purchase
{
    /// <summary>How a provider reports the end of a store call.</summary>
    public readonly struct PurchaseStatus
    {
        private readonly string _detail;

        public PurchaseFailure Failure { get; }
        public bool Success => Failure == PurchaseFailure.None;

        /// <summary>The SDK's own code. For logs only.</summary>
        public int ProviderCode { get; }

        public string Detail => _detail ?? string.Empty;

        private PurchaseStatus(PurchaseFailure failure, int providerCode, string detail)
        {
            Failure = failure;
            ProviderCode = providerCode;
            _detail = detail ?? string.Empty;
        }

        public static PurchaseStatus Succeeded => default;

        /// <summary>A failure. <see cref="PurchaseFailure.None"/> becomes <see cref="PurchaseFailure.ProviderError"/>.</summary>
        public static PurchaseStatus Failed(PurchaseFailure failure, int providerCode = 0, string detail = "") =>
            new PurchaseStatus(failure == PurchaseFailure.None ? PurchaseFailure.ProviderError : failure, providerCode, detail);

        public override string ToString() => Success ? "None" : Failure + " (" + ProviderCode + ") " + Detail;
    }
}
