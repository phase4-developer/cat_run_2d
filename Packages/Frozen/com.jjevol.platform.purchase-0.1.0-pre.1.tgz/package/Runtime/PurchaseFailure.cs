namespace PlatformLibrary.Purchase
{
    /// <summary>Why a purchase call failed. Games branch on this, never on a store or server code.</summary>
    public enum PurchaseFailure
    {
        None,

        /// <summary><see cref="PurchaseManager.Initialize"/> has not completed, or its last run failed.</summary>
        NotInitialized,

        /// <summary>No provider, or the provider does not support this platform or product type.</summary>
        Unsupported,

        /// <summary>The store could not connect, disconnected, or its sign-in or update flow failed.</summary>
        StoreUnavailable,

        /// <summary>The product was not fetched or the store does not sell it now.</summary>
        ProductUnavailable,

        /// <summary>Another purchase call is running.</summary>
        Busy,

        /// <summary>The player closed the payment screen.</summary>
        Cancelled,

        /// <summary>Payment waits for approval. Once approved, the order arrives as a pending purchase.</summary>
        Deferred,

        AlreadyOwned,

        /// <summary>The store could not be reached. Same name as <c>NetworkFailure.NoConnection</c>.</summary>
        NoConnection,

        /// <summary>The store did not answer in time. Same name as <c>NetworkFailure.Timeout</c>.</summary>
        Timeout,

        /// <summary>No verifier is set. The order stays pending at the store and nothing is granted.</summary>
        VerifierMissing,

        /// <summary>The server rejected the receipt. The order is closed at the store and nothing is granted.</summary>
        VerificationRejected,

        /// <summary>
        /// Verification did not finish. The order stays pending at the store and
        /// <see cref="PurchaseManager.RecoverPendingPurchases"/> tries it again.
        /// </summary>
        VerificationUnavailable,

        ProviderError
    }
}
