using System;

namespace PlatformLibrary.Purchase
{
    public enum PurchaseOrderState
    {
        /// <summary>Paid and not yet closed at the store. The manager closes it only after verification.</summary>
        Pending,

        /// <summary>Already closed at the store, such as an owned non-consumable found by a restore.</summary>
        Confirmed
    }

    /// <summary>
    /// One store transaction. Everything here came from the client, so it is not proof of payment.
    /// A verifier sends <see cref="VerificationData"/> to a server, which checks it with the store.
    /// </summary>
    public sealed class PurchaseOrder
    {
        /// <summary>Stable ID of this order within its provider. The manager never verifies one key twice in one call.</summary>
        public string Key { get; }

        public PurchaseProduct Product { get; }
        public string ProductId => Product.Id;
        public PurchaseOrderState State { get; }
        public string TransactionId { get; }

        /// <summary>The store receipt as the SDK gave it.</summary>
        public string Receipt { get; }

        /// <summary>What the server sends to the store: a Google purchase token, an Apple JWS or a ONE store purchase token.</summary>
        public string VerificationData { get; }

        /// <summary>Store code that some stores need for server verification. Empty when the store has none.</summary>
        public string StoreCode { get; }

        public PurchaseOrder(string key, PurchaseProduct product, PurchaseOrderState state, string transactionId, string receipt, string verificationData, string storeCode = "")
        {
            if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("An order key is required.", nameof(key));
            Key = key;
            Product = product ?? throw new ArgumentNullException(nameof(product));
            State = state;
            TransactionId = transactionId ?? string.Empty;
            Receipt = receipt ?? string.Empty;
            VerificationData = verificationData ?? string.Empty;
            StoreCode = storeCode ?? string.Empty;
        }
    }
}
