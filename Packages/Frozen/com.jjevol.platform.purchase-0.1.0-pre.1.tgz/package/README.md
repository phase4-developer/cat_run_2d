# JJEvol Platform Purchase

Local validation candidate 0.1.0-pre.1. The in-app purchase manager, the provider and verifier contracts and the result types. Games call `PurchaseManager` and never see an SDK or a store.

The code is user-authored, confirmed by the user on 2026-11-08. This package has no SDK, product ID, license key, server address or game policy in it. Design: `Docs/PlatformPurchase/Design.md`.

## Use

The project's start code decides what runs. This is the only place that names a provider or a store:

```csharp
PurchaseManager.SetProvider(new UnityIAPPurchaseProvider());   // or OneStorePurchaseProvider in a ONE store build
PurchaseManager.SetVerifier(new GamePurchaseVerifier());       // the project's server call
PurchaseManager.Initialize(GameProducts.CreateDefinitions(), result =>
{
    if (!result.Success) Debug.LogWarning(result.Failure);
});
```

Game code knows only the manager:

```csharp
priceLabel.text = PurchaseManager.GetLocalizedPrice("gem_100");

PurchaseManager.Purchase(new PurchaseRequest("gem_100"), result =>
{
    if (result.Success) ShowRewards(result.Grant);
    else if (result.Failure == PurchaseFailure.Cancelled) { }
    else ShowPurchaseFailedPopup(result.Failure);
});

PurchaseManager.RecoverPendingPurchases(batch =>
{
    foreach (PurchaseResult granted in batch.Granted) ShowRewards(granted.Grant);
});
```

Call `RecoverPendingPurchases` after every successful `Initialize`, at a point where the game can show rewards. Orders left unclosed by an earlier run are found only this way. `PendingPurchaseDetected` and `HasPendingPurchases` do not report them: Unity IAP is set not to announce fetched pending orders, and ONE store finds them only through its purchase query. Google Play refunds an order that stays unacknowledged for three days, so do not decide on recovery from `HasPendingPurchases`. Whether Apple announces an earlier run's unfinished transaction through `PendingPurchaseDetected` has not been checked.

Call `PurchaseManager` from the Unity main thread. Every callback runs once, on the main thread. A callback that throws is logged and does not stop the manager.

## Trust boundary

A client callback is not proof of payment. A modified client, a replayed event or a compromised device can fake or repeat it. So the manager never decides a grant: the verifier does, normally by asking the game's server, which checks `PurchaseOrder.VerificationData` with the store, records `TransactionId` once and grants.

The manager closes an order at the store (consume or acknowledge) only after the verifier's verdict:

| Verdict | Store order | Result |
|---|---|---|
| `Granted` | Closed | Success, with `Grant` |
| `AlreadyGranted` | Closed | Success, `AlreadyGranted` is true |
| `Rejected` | Closed | `VerificationRejected` |
| `Unavailable`, a throw, or no answer within `VerificationTimeoutSeconds` (90 by default) | Stays pending | `VerificationUnavailable` |
| No verifier set | Stays pending | `VerifierMissing` |

An order that stays pending comes back in the next `RecoverPendingPurchases`. A verifier answer that arrives after the timeout is ignored, so the server must treat a repeated `TransactionId` as `AlreadyGranted`.

`UnverifiedPurchaseVerifier` grants every order without a server. Anyone who can change the client can then get purchases for free. Use it only for development, or for a game that has decided to accept that, and set it explicitly.

## No provider

Nothing is required. With no provider, every call answers `PurchaseFailure.Unsupported` at once, `IsInitialized` stays false and `GetLocalizedPrice` returns an empty string. A platform with no store needs no special code.

Choosing a provider belongs to the project: this package has no default provider, no selection define and no store branch. `SetProvider(null)` removes a provider. Replacing one ends its running call with `ProviderError`, and the new one starts uninitialized. The project owns each provider's lifetime.

## Calls

| Call | Behavior |
|---|---|
| `Initialize(definitions, callback)` | Connects and fetches the products. Throws for a null list, a null entry or a duplicate product ID. Can be called again after a failure or to refresh. |
| `GetProduct(id)`, `GetLocalizedPrice(id)` | The fetched product, or null and an empty string. |
| `Purchase(request, callback)` | Pays, verifies and closes. Before `Initialize`: `NotInitialized`. Unknown or unsellable product: `ProductUnavailable`. |
| `RecoverPendingPurchases(callback)` | Verifies every pending order the store returns and every order `PendingPurchaseDetected` reported, one at a time, each once. |
| `RestorePurchases(callback)` | Verifies the player's non-consumables and subscriptions. Closes those still pending. |

Only one call runs at a time. Any other call meanwhile answers `Busy`. A batch reports one `PurchaseResult` for each order. Its own `Failure` is set only when the order list could not be fetched.

| Event | When |
|---|---|
| `PurchaseCompleted` | Any order granted, by a purchase, a recovery or a restore. For analytics. Skip revenue when `AlreadyGranted` is true. |
| `PendingPurchaseDetected` | The store sent a paid order no call asked for while the game runs, such as an approved deferred purchase. `HasPendingPurchases` turns true until the next recovery. Orders from an earlier run are not reported here. |
| `LoadingChanged` | A purchase, recovery or restore started (true) or ended (false), so the project can show its loading indicator. The end comes before the callback. |

To send revenue to analytics, connect the event in the start code:

```csharp
PurchaseManager.PurchaseCompleted += result =>
{
    if (result.AlreadyGranted) return;
    AnalyticsManager.LogPurchase(/* result.Order.Product.Price, result.Order.Product.Currency, result.Order.TransactionId */);
};
```

## Writing a verifier

```csharp
public sealed class GamePurchaseVerifier : IPurchaseVerifier
{
    public void Verify(PurchaseOrder order, Action<PurchaseVerification> completed)
    {
        // Send order.ProductId, order.Product.Definition.StoreProductId, order.VerificationData,
        // order.TransactionId and order.StoreCode to the server, then map its answer:
        //   granted                         -> PurchaseVerification.Granted(rewards, code)
        //   already processed or used       -> PurchaseVerification.AlreadyGranted(rewards, code)
        //   invalid receipt                 -> PurchaseVerification.Rejected(code)
        //   anything else, network failures -> PurchaseVerification.Unavailable(code)
    }
}
```

Call `completed` once, from any thread. The server's error names and reward format belong to the project.

## Writing a provider

Implement `IPurchaseProvider`. The manager calls it on the main thread, one store call at a time. A provider talks to its SDK, turns SDK codes into `PurchaseFailure` and puts the SDK code in `PurchaseStatus.ProviderCode`. It does not throw for an ordinary failure, answers each callback once, from any thread, and never closes an order on its own.

## Validation

Tests are in `Tests/Editor` and `Tests/Runtime`. See `Docs/PlatformPurchase/Report.md` for what has run.
