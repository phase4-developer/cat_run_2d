using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseVerificationTests : PurchaseTestBase
    {
        [Test]
        public void ATimeoutLeavesTheOrderPending()
        {
            StartPaidPurchase();
            Host.Advance(Timeout);

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.VerificationUnavailable));
            Assert.That(Single.Detail, Is.EqualTo("VERIFICATION_TIMEOUT"));
            Assert.That(Provider.Confirmed, Is.Empty);
            Assert.That(Host.Warnings, Has.Count.EqualTo(1));
        }

        [Test]
        public void ALateAnswerAfterTheTimeoutIsIgnored()
        {
            StartPaidPurchase();
            Host.Advance(Timeout);
            Verifier.Answer(PurchaseVerification.Granted());

            Assert.That(Results, Has.Count.EqualTo(1));
            Assert.That(Provider.Confirmed, Is.Empty);
            Assert.That(Completed, Is.Empty);
        }

        [Test]
        public void AnAnswerCancelsTheTimeout()
        {
            StartPaidPurchase();
            Verifier.Answer(PurchaseVerification.Granted());
            Assert.That(Host.PendingTimers, Is.EqualTo(0));
            Host.Advance(Timeout);
            Assert.That(Results, Has.Count.EqualTo(1));
        }

        [Test]
        public void ASecondAnswerIsIgnored()
        {
            PurchaseOrder order = StartPaidPurchase();
            Verifier.Answer(PurchaseVerification.Granted());
            Verifier.Answer(PurchaseVerification.Rejected());

            Assert.That(Single.Success, Is.True);
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { order }));
        }

        [Test]
        public void AThrowingVerifierLeavesTheOrderPending()
        {
            StartManager();
            Verifier.Throw = true;
            PurchaseManager.Purchase(Gem, Record);
            Provider.CompletePurchase(Provider.Order(Gem));

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.VerificationUnavailable));
            Assert.That(Host.Exceptions, Has.Count.EqualTo(1));
            Assert.That(Provider.Confirmed, Is.Empty);
        }

        [Test]
        public void AnAnswerFromAWorkerThreadWaitsForTheMainThread()
        {
            StartPaidPurchase();
            Host.HoldPosts = true;
            Verifier.Answer(PurchaseVerification.Granted());
            Assert.That(Results, Is.Empty);
            Assert.That(Provider.Confirmed, Is.Empty);

            Host.RunHeldPosts();
            Assert.That(Single.Success, Is.True);
        }

        [Test]
        public void TheVerifierIsReadAtVerification()
        {
            StartManager();
            PurchaseManager.SetVerifier(null);
            PurchaseManager.Purchase(Gem, Record);
            PurchaseManager.SetVerifier(Verifier);
            Provider.CompletePurchase(Provider.Order(Gem));

            Assert.That(Verifier.Orders, Has.Count.EqualTo(1));
        }

        [Test]
        public void VerificationFactoriesSetTheVerdict()
        {
            Assert.That(PurchaseVerification.Granted().Verdict, Is.EqualTo(PurchaseVerdict.Granted));
            Assert.That(PurchaseVerification.AlreadyGranted().Verdict, Is.EqualTo(PurchaseVerdict.AlreadyGranted));
            Assert.That(PurchaseVerification.Rejected().Verdict, Is.EqualTo(PurchaseVerdict.Rejected));
            Assert.That(PurchaseVerification.Unavailable().Verdict, Is.EqualTo(PurchaseVerdict.Unavailable));
            Assert.That(PurchaseVerification.Rejected().Grant, Is.Null);
            Assert.That(default(PurchaseVerification).ServerErrorCode, Is.Empty);
        }
    }
}
