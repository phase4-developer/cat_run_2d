using System;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Purchase.Tests
{
    /// <summary>Needs Unity's log capture, so it is kept apart from the tests that run outside Unity.</summary>
    public sealed class PurchaseNoProviderLogTests : PurchaseTestBase
    {
        [Test]
        public void AThrowingCallbackIsLoggedWithoutAProvider()
        {
            LogAssert.Expect(LogType.Exception, new Regex("purchase callback"));
            LogAssert.Expect(LogType.Exception, new Regex("batch callback"));

            Assert.DoesNotThrow(() => PurchaseManager.Purchase(Gem, _ => throw new InvalidOperationException("purchase callback")));
            Assert.DoesNotThrow(() => PurchaseManager.RecoverPendingPurchases(_ => throw new InvalidOperationException("batch callback")));
        }
    }
}
