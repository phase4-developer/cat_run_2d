using System;
using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseInitializeTests : PurchaseTestBase
    {
        private static readonly PurchaseProductDefinition[] Definitions = { new PurchaseProductDefinition(Gem, "store." + Gem) };

        [Test]
        public void SuccessFetchesTheGivenProducts()
        {
            UseProvider();
            PurchaseManager.Initialize(Definitions, Record);
            Assert.That(PurchaseManager.IsInitialized, Is.False);
            Assert.That(Provider.InitializedProducts, Is.EqualTo(Definitions));

            Provider.CompleteInitialize();

            Assert.That(Single.Success, Is.True);
            Assert.That(PurchaseManager.IsInitialized, Is.True);
            Assert.That(Loading, Is.Empty);
        }

        [Test]
        public void FailurePassesTheReasonAndStaysUninitialized()
        {
            UseProvider();
            PurchaseManager.Initialize(Definitions, Record);
            Provider.InitializeCallback(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 3, "billing unavailable"));

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.StoreUnavailable));
            Assert.That(Single.ProviderCode, Is.EqualTo(3));
            Assert.That(Single.Detail, Is.EqualTo("billing unavailable"));
            Assert.That(PurchaseManager.IsInitialized, Is.False);
        }

        [Test]
        public void ItCanBeCalledAgainAfterAFailure()
        {
            UseProvider();
            PurchaseManager.Initialize(Definitions, Record);
            Provider.InitializeCallback(PurchaseStatus.Failed(PurchaseFailure.NoConnection));
            PurchaseManager.Initialize(Definitions, Record);
            Provider.CompleteInitialize();

            Assert.That(Provider.InitializeCalls, Is.EqualTo(2));
            Assert.That(Results[1].Success, Is.True);
            Assert.That(PurchaseManager.IsInitialized, Is.True);
        }

        [Test]
        public void AnOverlappingCallIsBusy()
        {
            UseProvider();
            PurchaseManager.Initialize(Definitions);
            PurchaseManager.Initialize(Definitions, Record);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.Busy));
            Assert.That(Provider.InitializeCalls, Is.EqualTo(1));
        }

        [Test]
        public void ADuplicateProductIdThrows()
        {
            UseProvider();
            var duplicate = new[] { new PurchaseProductDefinition("a", "store.a"), new PurchaseProductDefinition("a", "store.b") };
            Assert.Throws<ArgumentException>(() => PurchaseManager.Initialize(duplicate));
            Assert.Throws<ArgumentException>(() => PurchaseManager.Initialize(new PurchaseProductDefinition[] { null }));
            Assert.Throws<ArgumentNullException>(() => PurchaseManager.Initialize(null));
            Assert.That(Provider.InitializeCalls, Is.EqualTo(0));
        }

        [Test]
        public void AThrowingProviderAnswersProviderError()
        {
            UseProvider();
            Provider.ThrowOnCall = true;
            PurchaseManager.Initialize(Definitions, Record);

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.ProviderError));
            Assert.That(Host.Exceptions, Has.Count.EqualTo(1));
            Assert.That(PurchaseManager.IsInitialized, Is.False);
        }

        [Test]
        public void AProviderAnswerFromAWorkerThreadWaitsForTheMainThread()
        {
            UseProvider();
            PurchaseManager.Initialize(Definitions, Record);
            Host.HoldPosts = true;
            Provider.CompleteInitialize();
            Assert.That(Results, Is.Empty);

            Host.RunHeldPosts();
            Assert.That(Single.Success, Is.True);
        }
    }
}
