using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseProviderChangeTests : PurchaseTestBase
    {
        [Test]
        public void ARunningPurchaseEndsWithProviderError()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, Record);
            PurchaseManager.SetProvider(new FakePurchaseProvider(), Host, Timeout);

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.ProviderError));
            Assert.That(Single.Detail, Is.EqualTo("PROVIDER_CHANGED"));
            Assert.That(Loading, Is.EqualTo(new[] { true, false }));
            Assert.That(PurchaseManager.IsInitialized, Is.False);
        }

        [Test]
        public void TheOldProvidersLateAnswersAreIgnored()
        {
            StartPaidPurchase();
            FakePurchaseProvider old = Provider;
            PurchaseManager.SetProvider(new FakePurchaseProvider(), Host, Timeout);
            Verifier.Answer(PurchaseVerification.Granted());
            Host.Advance(Timeout);

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.ProviderError));
            Assert.That(old.Confirmed, Is.Empty);
            Assert.That(Completed, Is.Empty);
        }

        [Test]
        public void TheOldProviderIsNoLongerHeard()
        {
            StartManager();
            FakePurchaseProvider old = Provider;
            PurchaseManager.SetProvider(new FakePurchaseProvider(), Host, Timeout);

            Assert.That(old.HasListener, Is.False);
            old.SendUnrequested(old.Order(Gem));
            Assert.That(PurchaseManager.HasPendingPurchases, Is.False);
        }

        [Test]
        public void ARunningBatchEndsWithItsResultsSoFar()
        {
            StartManager();
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending(Provider.Order(Gem), Provider.Order(Gem));
            Verifier.Answer(PurchaseVerification.Granted());
            PurchaseManager.SetProvider(null, null, Timeout);

            Assert.That(SingleBatch.Failure, Is.EqualTo(PurchaseFailure.ProviderError));
            Assert.That(SingleBatch.Results, Has.Count.EqualTo(1));
        }

        [Test]
        public void SettingTheSameProviderKeepsTheSession()
        {
            StartManager();
            PurchaseManager.SetProvider(Provider, Host, Timeout);
            Assert.That(PurchaseManager.IsInitialized, Is.True);
        }
    }
}
