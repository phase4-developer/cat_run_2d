using System.Linq;
using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseBatchTests : PurchaseTestBase
    {
        [Test]
        public void BeforeInitializeABatchAnswersNotInitialized()
        {
            UseProvider();
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            PurchaseManager.RestorePurchases(RecordBatch);
            Assert.That(Batches.Select(batch => batch.Failure), Is.EqualTo(new[] { PurchaseFailure.NotInitialized, PurchaseFailure.NotInitialized }));
        }

        [Test]
        public void ABatchWhileAPurchaseRunsIsBusy()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, null);
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Assert.That(SingleBatch.Failure, Is.EqualTo(PurchaseFailure.Busy));
            Assert.That(Provider.PendingCallback, Is.Null);
        }

        [Test]
        public void AFetchFailureEndsTheBatch()
        {
            StartManager();
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.PendingCallback(PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable, 7, "disconnected"), null);

            Assert.That(SingleBatch.Failure, Is.EqualTo(PurchaseFailure.StoreUnavailable));
            Assert.That(SingleBatch.ProviderCode, Is.EqualTo(7));
            Assert.That(SingleBatch.Results, Is.Empty);
            Assert.That(Loading, Is.EqualTo(new[] { true, false }));
        }

        [Test]
        public void RecoveryVerifiesEachPendingOrderOnceInTurn()
        {
            StartManager();
            Verifier.AutoAnswer = PurchaseVerification.Granted();
            PurchaseOrder first = Provider.Order(Gem);
            PurchaseOrder second = Provider.Order(Gem);
            PurchaseOrder duplicate = Provider.Order(Gem, key: first.Key);
            PurchaseOrder closed = Provider.Order(Gem, PurchaseOrderState.Confirmed);
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending(first, null, second, duplicate, closed);

            Assert.That(Verifier.Orders, Is.EqualTo(new[] { first, second }));
            Assert.That(SingleBatch.Success, Is.True);
            Assert.That(SingleBatch.Results.Select(result => result.Order), Is.EqualTo(new[] { first, second }));
            Assert.That(SingleBatch.Granted.Count(), Is.EqualTo(2));
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { first, second }));
            Assert.That(Completed, Has.Count.EqualTo(2));
        }

        [Test]
        public void RecoveryReportsEachOrdersOwnVerdict()
        {
            StartManager();
            PurchaseOrder first = Provider.Order(Gem);
            PurchaseOrder second = Provider.Order(Gem);
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending(first, second);

            Assert.That(Verifier.Orders, Is.EqualTo(new[] { first }));
            Verifier.Answer(PurchaseVerification.Unavailable());
            Assert.That(Verifier.Orders, Is.EqualTo(new[] { first, second }));
            Verifier.Answer(PurchaseVerification.AlreadyGranted());

            Assert.That(SingleBatch.Results.Select(result => result.Failure), Is.EqualTo(new[] { PurchaseFailure.VerificationUnavailable, PurchaseFailure.None }));
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { second }));
        }

        [Test]
        public void AnUnrequestedOrderIsHeldUntilRecovery()
        {
            StartManager();
            var detected = new System.Collections.Generic.List<PurchaseOrder>();
            PurchaseManager.PendingPurchaseDetected += detected.Add;
            PurchaseOrder approved = Provider.Order(Gem);
            Provider.SendUnrequested(approved);

            Assert.That(detected, Is.EqualTo(new[] { approved }));
            Assert.That(PurchaseManager.HasPendingPurchases, Is.True);
            Assert.That(Verifier.Orders, Is.Empty);

            Verifier.AutoAnswer = PurchaseVerification.Granted();
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending();

            Assert.That(Verifier.Orders, Is.EqualTo(new[] { approved }));
            Assert.That(PurchaseManager.HasPendingPurchases, Is.False);
            Assert.That(SingleBatch.Granted.Count(), Is.EqualTo(1));
        }

        [Test]
        public void AHeldOrderTheStoreAlsoReturnsIsVerifiedOnce()
        {
            StartManager();
            Verifier.AutoAnswer = PurchaseVerification.Granted();
            PurchaseOrder order = Provider.Order(Gem);
            Provider.SendUnrequested(order);
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending(order);
            Assert.That(Verifier.Orders, Has.Count.EqualTo(1));
        }

        [Test]
        public void AnOrderAnnouncedWhileItIsVerifiedIsNotHeldAgain()
        {
            StartManager();
            PurchaseOrder order = Provider.Order(Gem);
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending(order);
            Provider.SendUnrequested(order);
            Verifier.Answer(PurchaseVerification.Granted());
            Provider.SendUnrequested(order);

            Assert.That(PurchaseManager.HasPendingPurchases, Is.False);
            Assert.That(SingleBatch.Granted.Count(), Is.EqualTo(1));
        }

        [Test]
        public void AnOrderWhoseCloseFailedCanBeHeldAgain()
        {
            StartManager();
            PurchaseOrder order = Provider.Order(Gem);
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending(order);
            Verifier.Answer(PurchaseVerification.Granted());
            Provider.ConfirmCallbacks[0](PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable));
            Provider.SendUnrequested(order);

            Assert.That(PurchaseManager.HasPendingPurchases, Is.True);
        }

        [Test]
        public void RecoveryWhileAnOrderIsClosingSkipsIt()
        {
            StartManager();
            Verifier.AutoAnswer = PurchaseVerification.Granted();
            PurchaseOrder order = Provider.Order(Gem);
            PurchaseManager.Purchase(Gem, result =>
            {
                Record(result);
                PurchaseManager.RecoverPendingPurchases(RecordBatch);
            });
            Provider.CompletePurchase(order);
            // The store still lists the order because its close has not landed.
            Provider.CompletePending(order);

            Assert.That(Verifier.Orders, Is.EqualTo(new[] { order }));
            Assert.That(SingleBatch.Success, Is.True);
            Assert.That(SingleBatch.Results, Is.Empty);
            Assert.That(Completed, Has.Count.EqualTo(1));
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { order }));

            Provider.ConfirmCallbacks[0](PurchaseStatus.Succeeded);
            Provider.SendUnrequested(order);
            Assert.That(PurchaseManager.HasPendingPurchases, Is.False);
        }

        [Test]
        public void RecoveryAfterAFailedCloseVerifiesTheOrderAgain()
        {
            StartManager();
            Verifier.AutoAnswer = PurchaseVerification.Granted();
            PurchaseOrder order = Provider.Order(Gem);
            PurchaseManager.Purchase(Gem, Record);
            Provider.CompletePurchase(order);
            Provider.ConfirmCallbacks[0](PurchaseStatus.Failed(PurchaseFailure.StoreUnavailable));

            Verifier.AutoAnswer = PurchaseVerification.AlreadyGranted();
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            Provider.CompletePending(order);

            Assert.That(Verifier.Orders, Is.EqualTo(new[] { order, order }));
            Assert.That(SingleBatch.Results.Single().AlreadyGranted, Is.True);
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { order, order }));
        }

        [Test]
        public void AClosedUnrequestedOrderIsIgnored()
        {
            StartManager();
            Provider.SendUnrequested(Provider.Order(Gem, PurchaseOrderState.Confirmed));
            Assert.That(PurchaseManager.HasPendingPurchases, Is.False);
        }

        [Test]
        public void TheOrderBeingBoughtLeavesTheHeldList()
        {
            StartManager();
            PurchaseOrder order = Provider.Order(Gem);
            Provider.SendUnrequested(order);
            PurchaseManager.Purchase(Gem, Record);
            Provider.CompletePurchase(order);
            Assert.That(PurchaseManager.HasPendingPurchases, Is.False);
        }

        [Test]
        public void RestoreVerifiesOnlyOwnedNonConsumablesAndSubscriptions()
        {
            StartManager();
            Verifier.AutoAnswer = PurchaseVerification.AlreadyGranted();
            Provider.AddProduct("no_ads", PurchaseProductType.NonConsumable);
            Provider.AddProduct("pass", PurchaseProductType.Subscription);
            PurchaseOrder consumable = Provider.Order(Gem);
            PurchaseOrder owned = Provider.Order("no_ads", PurchaseOrderState.Confirmed);
            PurchaseOrder pending = Provider.Order("pass");
            PurchaseManager.RestorePurchases(RecordBatch);
            Provider.CompleteOwned(consumable, owned, pending);

            Assert.That(Verifier.Orders, Is.EqualTo(new[] { owned, pending }));
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { pending }));
            Assert.That(SingleBatch.Results.All(result => result.Success && result.AlreadyGranted), Is.True);
        }

        [Test]
        public void RestoreLeavesHeldOrdersForRecovery()
        {
            StartManager();
            Provider.SendUnrequested(Provider.Order(Gem));
            PurchaseManager.RestorePurchases(RecordBatch);
            Provider.CompleteOwned();
            Assert.That(PurchaseManager.HasPendingPurchases, Is.True);
        }
    }
}
