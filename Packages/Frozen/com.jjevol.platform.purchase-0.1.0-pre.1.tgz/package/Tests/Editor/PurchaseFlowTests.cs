using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseFlowTests : PurchaseTestBase
    {
        [Test]
        public void BeforeInitializeItAnswersNotInitialized()
        {
            UseProvider();
            PurchaseManager.Purchase(Gem, Record);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.NotInitialized));
            Assert.That(Provider.PurchaseCalls, Is.EqualTo(0));
        }

        [Test]
        public void AnUnknownProductIsUnavailable()
        {
            StartManager();
            PurchaseManager.Purchase("unknown", Record);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.ProductUnavailable));
            Assert.That(Single.ProductId, Is.EqualTo("unknown"));
        }

        [Test]
        public void AProductTheStoreDoesNotSellIsUnavailable()
        {
            StartManager();
            Provider.AddProduct("off", available: false);
            PurchaseManager.Purchase("off", Record);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.ProductUnavailable));
            Assert.That(Provider.PurchaseCalls, Is.EqualTo(0));
        }

        [Test]
        public void ASecondPurchaseWhileOneRunsIsBusy()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, null);
            PurchaseManager.Purchase(Gem, Record);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.Busy));
            Assert.That(Provider.PurchaseCalls, Is.EqualTo(1));
        }

        [Test]
        public void TheRequestReachesTheProvider()
        {
            StartManager();
            PurchaseManager.Purchase(new PurchaseRequest(Gem, "player-1"), Record);
            Assert.That(Provider.LastRequest.ProductId, Is.EqualTo(Gem));
            Assert.That(Provider.LastRequest.Payload, Is.EqualTo("player-1"));
        }

        [Test]
        public void GrantedOrderIsClosedAndCarriesTheGrant()
        {
            PurchaseOrder order = StartPaidPurchase();
            Assert.That(Verifier.Orders, Is.EqualTo(new[] { order }));
            Assert.That(Provider.Confirmed, Is.Empty);
            Assert.That(Results, Is.Empty);

            var grant = new[] { "gem x100" };
            Verifier.Answer(PurchaseVerification.Granted(grant, "OK"));

            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { order }));
            Assert.That(Single.Success, Is.True);
            Assert.That(Single.AlreadyGranted, Is.False);
            Assert.That(Single.Order, Is.SameAs(order));
            Assert.That(Single.GetGrant<string[]>(), Is.SameAs(grant));
            Assert.That(Single.ServerErrorCode, Is.EqualTo("OK"));
            Assert.That(Completed, Has.Count.EqualTo(1));
        }

        [Test]
        public void AlreadyGrantedIsASuccessAndClosesTheOrder()
        {
            PurchaseOrder order = StartPaidPurchase();
            Verifier.Answer(PurchaseVerification.AlreadyGranted(null, "ReceiptAlreadyUsed"));

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.AlreadyGranted, Is.True);
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { order }));
            Assert.That(Completed[0].AlreadyGranted, Is.True);
        }

        [Test]
        public void RejectedClosesTheOrderAndGrantsNothing()
        {
            PurchaseOrder order = StartPaidPurchase();
            Verifier.Answer(PurchaseVerification.Rejected("InvalidReceipt", "bad receipt"));

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.VerificationRejected));
            Assert.That(Single.ServerErrorCode, Is.EqualTo("InvalidReceipt"));
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { order }));
            Assert.That(Completed, Is.Empty);
        }

        [Test]
        public void UnavailableLeavesTheOrderPending()
        {
            StartPaidPurchase();
            Verifier.Answer(PurchaseVerification.Unavailable("ServerBusy"));

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.VerificationUnavailable));
            Assert.That(Single.ServerErrorCode, Is.EqualTo("ServerBusy"));
            Assert.That(Provider.Confirmed, Is.Empty);
            Assert.That(Completed, Is.Empty);
        }

        [Test]
        public void WithoutAVerifierTheOrderStaysPending()
        {
            StartManager();
            PurchaseManager.SetVerifier(null);
            PurchaseManager.Purchase(Gem, Record);
            Provider.CompletePurchase(Provider.Order(Gem));

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.VerifierMissing));
            Assert.That(Single.Order, Is.Not.Null);
            Assert.That(Provider.Confirmed, Is.Empty);
        }

        [Test]
        public void TheUnverifiedVerifierGrantsWithoutAServer()
        {
            StartManager();
            PurchaseManager.SetVerifier(new UnverifiedPurchaseVerifier());
            PurchaseManager.Purchase(Gem, Record);
            PurchaseOrder order = Provider.Order(Gem);
            Provider.CompletePurchase(order);

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.ServerErrorCode, Is.EqualTo(UnverifiedPurchaseVerifier.ServerErrorCode));
            Assert.That(Provider.Confirmed, Is.EqualTo(new[] { order }));
        }

        [Test]
        public void AStoreFailureSkipsVerification()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, Record);
            Provider.FailPurchase(PurchaseFailure.Cancelled, 4);

            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.Cancelled));
            Assert.That(Single.ProviderCode, Is.EqualTo(4));
            Assert.That(Verifier.Orders, Is.Empty);
        }

        [Test]
        public void SuccessWithoutAnOrderIsAProviderError()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, Record);
            Provider.PurchaseCallback(PurchaseStatus.Succeeded, null);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.ProviderError));
        }

        [Test]
        public void LoadingEndsBeforeTheCallback()
        {
            StartManager();
            bool loadingInCallback = true;
            PurchaseManager.Purchase(Gem, result => loadingInCallback = PurchaseManager.IsLoading);
            Assert.That(PurchaseManager.IsLoading, Is.True);
            Provider.FailPurchase(PurchaseFailure.Cancelled);

            Assert.That(Loading, Is.EqualTo(new[] { true, false }));
            Assert.That(loadingInCallback, Is.False);
        }

        [Test]
        public void ANewPurchaseCanStartAfterTheLastEnds()
        {
            StartPaidPurchase();
            Verifier.Answer(PurchaseVerification.Granted());
            PurchaseManager.Purchase(Gem, Record);
            Assert.That(Provider.PurchaseCalls, Is.EqualTo(2));
        }

        [Test]
        public void ACallbackThatThrowsIsLoggedAndTheManagerGoesOn()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, result => throw new System.InvalidOperationException("game fault"));
            Provider.FailPurchase(PurchaseFailure.Cancelled);
            Assert.That(Host.Exceptions, Has.Count.EqualTo(1));

            PurchaseManager.Purchase(Gem, Record);
            Assert.That(Provider.PurchaseCalls, Is.EqualTo(2));
        }

        [Test]
        public void AFailedCloseIsLoggedAndTheResultStands()
        {
            StartPaidPurchase();
            Verifier.Answer(PurchaseVerification.Granted());
            Provider.ConfirmCallbacks[0](PurchaseStatus.Failed(PurchaseFailure.NoConnection));

            Assert.That(Single.Success, Is.True);
            Assert.That(Host.Warnings, Has.Count.EqualTo(1));
        }

        [Test]
        public void ConfirmedOrdersAreNotClosedAgain()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, Record);
            Provider.CompletePurchase(Provider.Order(Gem, PurchaseOrderState.Confirmed));
            Verifier.Answer(PurchaseVerification.Granted());

            Assert.That(Single.Success, Is.True);
            Assert.That(Provider.Confirmed, Is.Empty);
        }
    }
}
