using System;
using System.Collections.Generic;
using System.Linq;

namespace PlatformLibrary.Purchase.Tests
{
    /// <summary>A host with a hand-driven clock. With <see cref="HoldPosts"/> it stands in for a callback from a worker thread.</summary>
    internal sealed class FakePurchaseHost : IPurchaseHost
    {
        private sealed class Timer
        {
            public float Due;
            public Action Action;
        }

        private readonly List<Timer> _timers = new List<Timer>();
        private readonly Queue<Action> _held = new Queue<Action>();
        private float _now;

        public bool HoldPosts { get; set; }
        public List<string> Warnings { get; } = new List<string>();
        public List<Exception> Exceptions { get; } = new List<Exception>();
        public int PendingTimers => _timers.Count;

        public void Post(Action action)
        {
            if (HoldPosts) _held.Enqueue(action);
            else action();
        }

        public void RunHeldPosts()
        {
            HoldPosts = false;
            while (_held.Count > 0) _held.Dequeue()();
        }

        public Action Schedule(float seconds, Action action)
        {
            var timer = new Timer { Due = _now + seconds, Action = action };
            _timers.Add(timer);
            return () => _timers.Remove(timer);
        }

        public void Advance(float seconds)
        {
            _now += seconds;
            while (true)
            {
                Timer next = _timers.Where(timer => timer.Due <= _now).OrderBy(timer => timer.Due).FirstOrDefault();
                if (next == null) return;
                _timers.Remove(next);
                next.Action();
            }
        }

        public void LogWarning(string message) => Warnings.Add(message);
        public void LogException(Exception exception) => Exceptions.Add(exception);
    }

    /// <summary>A provider whose store answers only when a test says so.</summary>
    internal sealed class FakePurchaseProvider : IPurchaseProvider
    {
        private readonly Dictionary<string, PurchaseProduct> _products = new Dictionary<string, PurchaseProduct>(StringComparer.Ordinal);
        private int _orderNumber;

        public string Name => "fake";
        public event Action<PurchaseOrder> UnrequestedOrderReceived;

        public bool ThrowOnCall { get; set; }
        public IReadOnlyList<PurchaseProductDefinition> InitializedProducts { get; private set; }
        public Action<PurchaseStatus> InitializeCallback { get; private set; }
        public PurchaseRequest LastRequest { get; private set; }
        public Action<PurchaseStatus, PurchaseOrder> PurchaseCallback { get; private set; }
        public Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> PendingCallback { get; private set; }
        public Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> OwnedCallback { get; private set; }
        public List<PurchaseOrder> Confirmed { get; } = new List<PurchaseOrder>();
        public List<Action<PurchaseStatus>> ConfirmCallbacks { get; } = new List<Action<PurchaseStatus>>();
        public int InitializeCalls { get; private set; }
        public int PurchaseCalls { get; private set; }

        public void Initialize(IReadOnlyList<PurchaseProductDefinition> products, Action<PurchaseStatus> completed)
        {
            Check();
            InitializeCalls++;
            InitializedProducts = products;
            InitializeCallback = completed;
        }

        public PurchaseProduct GetProduct(string productId)
        {
            Check();
            return _products.TryGetValue(productId, out PurchaseProduct product) ? product : null;
        }

        public void Purchase(PurchaseRequest request, Action<PurchaseStatus, PurchaseOrder> completed)
        {
            Check();
            PurchaseCalls++;
            LastRequest = request;
            PurchaseCallback = completed;
        }

        public void FetchPendingOrders(Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> completed)
        {
            Check();
            PendingCallback = completed;
        }

        public void FetchOwnedOrders(Action<PurchaseStatus, IReadOnlyList<PurchaseOrder>> completed)
        {
            Check();
            OwnedCallback = completed;
        }

        public void Confirm(PurchaseOrder order, Action<PurchaseStatus> completed)
        {
            Check();
            Confirmed.Add(order);
            ConfirmCallbacks.Add(completed);
        }

        public PurchaseProduct AddProduct(string id, PurchaseProductType type = PurchaseProductType.Consumable, bool available = true)
        {
            var product = new PurchaseProduct(new PurchaseProductDefinition(id, "store." + id, type), available, "1,200 KRW", 1200m, "KRW", id);
            _products[id] = product;
            return product;
        }

        public PurchaseOrder Order(string productId, PurchaseOrderState state = PurchaseOrderState.Pending, string key = null)
        {
            _orderNumber++;
            PurchaseProduct product = _products.TryGetValue(productId, out PurchaseProduct known) ? known : AddProduct(productId);
            return new PurchaseOrder(key ?? "order-" + _orderNumber, product, state, "transaction-" + _orderNumber, "receipt", "token-" + _orderNumber);
        }

        public void CompleteInitialize() => InitializeCallback(PurchaseStatus.Succeeded);
        public void CompletePurchase(PurchaseOrder order) => PurchaseCallback(PurchaseStatus.Succeeded, order);
        public void FailPurchase(PurchaseFailure failure, int code = 0) => PurchaseCallback(PurchaseStatus.Failed(failure, code, "fake failure"), null);
        public void CompletePending(params PurchaseOrder[] orders) => PendingCallback(PurchaseStatus.Succeeded, orders);
        public void CompleteOwned(params PurchaseOrder[] orders) => OwnedCallback(PurchaseStatus.Succeeded, orders);
        public void SendUnrequested(PurchaseOrder order) => UnrequestedOrderReceived?.Invoke(order);
        public bool HasListener => UnrequestedOrderReceived != null;

        private void Check()
        {
            if (ThrowOnCall) throw new InvalidOperationException("fake provider fault");
        }
    }

    /// <summary>A verifier that answers when a test says so, or at once with <see cref="AutoAnswer"/>.</summary>
    internal sealed class FakePurchaseVerifier : IPurchaseVerifier
    {
        public List<PurchaseOrder> Orders { get; } = new List<PurchaseOrder>();
        public List<Action<PurchaseVerification>> Callbacks { get; } = new List<Action<PurchaseVerification>>();
        public PurchaseVerification? AutoAnswer { get; set; }
        public bool Throw { get; set; }

        public void Verify(PurchaseOrder order, Action<PurchaseVerification> completed)
        {
            if (Throw) throw new InvalidOperationException("fake verifier fault");
            Orders.Add(order);
            Callbacks.Add(completed);
            if (AutoAnswer.HasValue) completed(AutoAnswer.Value);
        }

        public void Answer(PurchaseVerification verification) => Callbacks[Callbacks.Count - 1](verification);
    }
}
