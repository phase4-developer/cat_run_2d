using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchasePriceFormatterTests
    {
        [Test]
        public void KnownCurrencyUsesItsSymbolAndPrecision()
        {
            string won = PurchasePriceFormatter.Format("1200", "KRW");
            Assert.That(won, Does.Contain("1,200"));
            Assert.That(won, Does.Not.Contain("KRW"));
            Assert.That(PurchasePriceFormatter.Format("0.99", "usd"), Does.Contain("0.99"));
        }

        [Test]
        public void AFractionIsNotRoundedAway()
        {
            Assert.That(PurchasePriceFormatter.Format("1200.5", "KRW"), Does.Contain("1,200.5"));
        }

        [Test]
        public void UnknownCurrencyFallsBackToTheCode()
        {
            Assert.That(PurchasePriceFormatter.Format("1200", "XYZ"), Is.EqualTo("XYZ 1,200"));
            Assert.That(PurchasePriceFormatter.Format("1200", ""), Is.EqualTo("1,200"));
        }

        [Test]
        public void TextThatIsNotANumberIsReturnedAsIs()
        {
            Assert.That(PurchasePriceFormatter.Format("1,200", "KRW"), Is.EqualTo("1,200"));
            Assert.That(PurchasePriceFormatter.Format(null, "KRW"), Is.Empty);
        }
    }
}
