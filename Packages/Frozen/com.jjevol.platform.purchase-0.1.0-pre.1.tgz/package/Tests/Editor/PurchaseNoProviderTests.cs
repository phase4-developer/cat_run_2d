using System;
using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseNoProviderTests : PurchaseTestBase
    {
        [Test]
        public void EveryCallAnswersUnsupported()
        {
            PurchaseManager.Initialize(Array.Empty<PurchaseProductDefinition>(), Record);
            PurchaseManager.Purchase(Gem, Record);
            PurchaseManager.RecoverPendingPurchases(RecordBatch);
            PurchaseManager.RestorePurchases(RecordBatch);

            Assert.That(Results, Has.Count.EqualTo(2));
            Assert.That(Results, Has.All.Matches<PurchaseResult>(result => result.Failure == PurchaseFailure.Unsupported));
            Assert.That(Results[1].ProductId, Is.EqualTo(Gem));
            Assert.That(Batches, Has.Count.EqualTo(2));
            Assert.That(Batches, Has.All.Matches<PurchaseBatchResult>(result => result.Failure == PurchaseFailure.Unsupported));
        }

        [Test]
        public void StateStaysEmpty()
        {
            Assert.That(PurchaseManager.IsInitialized, Is.False);
            Assert.That(PurchaseManager.IsLoading, Is.False);
            Assert.That(PurchaseManager.HasPendingPurchases, Is.False);
            Assert.That(PurchaseManager.GetProduct(Gem), Is.Null);
            Assert.That(PurchaseManager.GetLocalizedPrice(Gem), Is.Empty);
            Assert.That(Loading, Is.Empty);
        }

        [Test]
        public void NullCallbacksAreAllowed()
        {
            Assert.DoesNotThrow(() => PurchaseManager.Purchase(Gem, null));
            Assert.DoesNotThrow(() => PurchaseManager.RecoverPendingPurchases(null));
        }

        [Test]
        public void RemovingTheProviderReturnsToUnsupported()
        {
            StartManager();
            PurchaseManager.SetProvider(null, null, Timeout);
            PurchaseManager.Purchase(Gem, Record);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.Unsupported));
            Assert.That(PurchaseManager.IsInitialized, Is.False);
        }
    }
}
