using System;
using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseVerificationTimeoutTests : PurchaseTestBase
    {
        private PurchaseOrder StartWithManagerLimit()
        {
            PurchaseManager.SetProvider(Provider, Host);
            PurchaseManager.SetVerifier(Verifier);
            Provider.AddProduct(Gem);
            PurchaseManager.Initialize(new[] { new PurchaseProductDefinition(Gem, "store." + Gem) });
            Provider.CompleteInitialize();
            PurchaseManager.Purchase(Gem, Record);
            PurchaseOrder order = Provider.Order(Gem);
            Provider.CompletePurchase(order);
            return order;
        }

        [Test]
        public void TheDefaultLimitIsNinetySeconds()
        {
            Assert.That(PurchaseManager.VerificationTimeoutSeconds, Is.EqualTo(90f));
            StartWithManagerLimit();

            Host.Advance(89f);
            Assert.That(Results, Is.Empty, "A slow server still answers within the default limit.");

            Host.Advance(1f);
            Assert.That(Single.Failure, Is.EqualTo(PurchaseFailure.VerificationUnavailable));
            Assert.That(Single.Detail, Is.EqualTo("VERIFICATION_TIMEOUT"));
        }

        [Test]
        public void TheProjectCanSetTheLimitAndItAppliesToTheNextOrder()
        {
            PurchaseOrder first = StartWithManagerLimit();
            Verifier.Answer(PurchaseVerification.Granted());
            Assert.That(Results, Has.Count.EqualTo(1));

            // Set after the provider and after an order, so the value must be read again for the next order.
            PurchaseManager.VerificationTimeoutSeconds = 120f;
            PurchaseManager.Purchase(Gem, Record);
            PurchaseOrder second = Provider.Order(Gem);
            Provider.CompletePurchase(second);

            Host.Advance(119f);
            Assert.That(Results, Has.Count.EqualTo(1), "Still waiting at 119 seconds.");
            Host.Advance(1f);
            Assert.That(Results, Has.Count.EqualTo(2));
            Assert.That(Results[1].Failure, Is.EqualTo(PurchaseFailure.VerificationUnavailable));
            Assert.That(Results[1].Detail, Is.EqualTo("VERIFICATION_TIMEOUT"));
            Assert.That(first, Is.Not.SameAs(second));
        }

        [Test]
        public void TheLimitMustBePositive()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => PurchaseManager.VerificationTimeoutSeconds = 0f);
            Assert.Throws<ArgumentOutOfRangeException>(() => PurchaseManager.VerificationTimeoutSeconds = -1f);
            Assert.Throws<ArgumentOutOfRangeException>(() => PurchaseManager.VerificationTimeoutSeconds = float.NaN);
            Assert.Throws<ArgumentOutOfRangeException>(() => PurchaseManager.VerificationTimeoutSeconds = float.PositiveInfinity);
            Assert.That(PurchaseManager.VerificationTimeoutSeconds, Is.EqualTo(90f));
        }

        [Test]
        public void ResetRestoresTheDefault()
        {
            PurchaseManager.VerificationTimeoutSeconds = 30f;
            PurchaseManager.ResetState();
            Assert.That(PurchaseManager.VerificationTimeoutSeconds, Is.EqualTo(90f));
        }
    }
}
