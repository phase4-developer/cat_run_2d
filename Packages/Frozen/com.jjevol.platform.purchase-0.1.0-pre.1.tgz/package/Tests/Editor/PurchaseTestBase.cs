using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public abstract class PurchaseTestBase
    {
        protected const float Timeout = 60f;
        protected const string Gem = "gem_100";

        private protected FakePurchaseProvider Provider;
        private protected FakePurchaseHost Host;
        private protected FakePurchaseVerifier Verifier;
        protected List<PurchaseResult> Results;
        protected List<PurchaseBatchResult> Batches;
        protected List<PurchaseResult> Completed;
        protected List<bool> Loading;

        [SetUp]
        public void SetUpManager()
        {
            PurchaseManager.ResetState();
            Provider = new FakePurchaseProvider();
            Host = new FakePurchaseHost();
            Verifier = new FakePurchaseVerifier();
            Results = new List<PurchaseResult>();
            Batches = new List<PurchaseBatchResult>();
            Completed = new List<PurchaseResult>();
            Loading = new List<bool>();
            PurchaseManager.PurchaseCompleted += Completed.Add;
            PurchaseManager.LoadingChanged += Loading.Add;
        }

        [TearDown]
        public void TearDownManager() => PurchaseManager.ResetState();

        protected PurchaseResult Single
        {
            get
            {
                Assert.That(Results, Has.Count.EqualTo(1));
                return Results[0];
            }
        }

        protected PurchaseBatchResult SingleBatch
        {
            get
            {
                Assert.That(Batches, Has.Count.EqualTo(1));
                return Batches[0];
            }
        }

        protected void UseProvider() => PurchaseManager.SetProvider(Provider, Host, Timeout);

        /// <summary>Provider and verifier set, one consumable fetched, initialized.</summary>
        protected void StartManager()
        {
            UseProvider();
            PurchaseManager.SetVerifier(Verifier);
            Provider.AddProduct(Gem);
            PurchaseManager.Initialize(new[] { new PurchaseProductDefinition(Gem, "store." + Gem) });
            Provider.CompleteInitialize();
        }

        /// <summary>Started, with a purchase of <see cref="Gem"/> paid and waiting for the verifier.</summary>
        private protected PurchaseOrder StartPaidPurchase()
        {
            StartManager();
            PurchaseManager.Purchase(Gem, Record);
            PurchaseOrder order = Provider.Order(Gem);
            Provider.CompletePurchase(order);
            return order;
        }

        protected void Record(PurchaseResult result) => Results.Add(result);
        protected void RecordBatch(PurchaseBatchResult result) => Batches.Add(result);
    }
}
