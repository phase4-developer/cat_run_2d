using System;
using NUnit.Framework;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class PurchaseDataTests
    {
        [Test]
        public void DefinitionsNeedBothIds()
        {
            Assert.Throws<ArgumentException>(() => new PurchaseProductDefinition("", "store.a"));
            Assert.Throws<ArgumentException>(() => new PurchaseProductDefinition("a", " "));
            Assert.That(new PurchaseProductDefinition("a", "store.a").Type, Is.EqualTo(PurchaseProductType.Consumable));
        }

        [Test]
        public void OrdersNeedAKeyAndAProduct()
        {
            var product = new PurchaseProduct(new PurchaseProductDefinition("a", "store.a"), true, null, 0m, null, null);
            Assert.Throws<ArgumentException>(() => new PurchaseOrder("", product, PurchaseOrderState.Pending, null, null, null));
            Assert.Throws<ArgumentNullException>(() => new PurchaseOrder("k", null, PurchaseOrderState.Pending, null, null, null));

            var order = new PurchaseOrder("k", product, PurchaseOrderState.Pending, null, null, null, null);
            Assert.That(order.ProductId, Is.EqualTo("a"));
            Assert.That(order.TransactionId + order.Receipt + order.VerificationData + order.StoreCode, Is.Empty);
            Assert.That(product.LocalizedPrice + product.Currency + product.Title, Is.Empty);
        }

        [Test]
        public void DefaultRequestAndStatusAreEmpty()
        {
            Assert.That(default(PurchaseRequest).ProductId, Is.Empty);
            Assert.That(default(PurchaseRequest).Payload, Is.Empty);
            Assert.That(default(PurchaseStatus).Success, Is.True);
            Assert.That(default(PurchaseStatus).Detail, Is.Empty);
            Assert.That(default(PurchaseResult).ServerErrorCode, Is.Empty);
        }

        [Test]
        public void AFailedStatusIsNeverNone()
        {
            Assert.That(PurchaseStatus.Failed(PurchaseFailure.None).Failure, Is.EqualTo(PurchaseFailure.ProviderError));
            Assert.That(PurchaseStatus.Failed(PurchaseFailure.Cancelled, 1, "x").ToString(), Does.Contain("Cancelled"));
        }

        [Test]
        public void GetGrantReturnsTheDefaultForAnotherType()
        {
            PurchaseResult result = PurchaseResult.Succeeded("a", grant: 5);
            Assert.That(result.GetGrant<int>(), Is.EqualTo(5));
            Assert.That(result.GetGrant<string>(), Is.Null);
        }
    }
}
