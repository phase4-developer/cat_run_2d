using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Purchase.Tests
{
    public sealed class UnityPurchaseHostTests
    {
        [UnityTest]
        public IEnumerator APostFromAWorkerThreadRunsOnTheMainThread()
        {
            UnityPurchaseHost host = UnityPurchaseHost.Instance;
            int mainThread = Thread.CurrentThread.ManagedThreadId;
            int ranOn = -1;
            Task.Run(() => host.Post(() => ranOn = Thread.CurrentThread.ManagedThreadId)).Wait();
            Assert.That(ranOn, Is.EqualTo(-1));

            for (int frame = 0; frame < 10 && ranOn == -1; frame++) yield return null;
            Assert.That(ranOn, Is.EqualTo(mainThread));
        }

        [Test]
        public void APostOnTheMainThreadRunsAtOnce()
        {
            bool ran = false;
            UnityPurchaseHost.Instance.Post(() => ran = true);
            Assert.That(ran, Is.True);
        }

        [UnityTest]
        public IEnumerator AScheduledActionRunsAfterRealTimeAndCanBeCancelled()
        {
            UnityPurchaseHost host = UnityPurchaseHost.Instance;
            bool ran = false;
            bool cancelledRan = false;
            host.Schedule(0.05f, () => ran = true);
            host.Schedule(0.05f, () => cancelledRan = true)();

            yield return new WaitForSecondsRealtime(0.2f);
            Assert.That(ran, Is.True);
            Assert.That(cancelledRan, Is.False);
        }
    }
}
