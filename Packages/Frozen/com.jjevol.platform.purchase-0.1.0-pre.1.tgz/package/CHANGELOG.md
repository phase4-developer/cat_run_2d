# Changelog

## 0.1.0-pre.1 - 2026-11-08

- `PurchaseManager.VerificationTimeoutSeconds` sets how long the manager waits for the verifier. The default rises from a fixed 60 seconds to 90, longer than the Firebase call limit, so a slow server still grants as the original game did. Read for each order; reset at `SubsystemRegistration`.

New design, per `Docs/PlatformPurchase/Design.md`. It replaces the mobile library's `IAPManager`, `IPurchaseManager`, `UnsupportedPurchaseManager`, the shared parts of `UnityIAPBillingManager` and `OneStorePurchaseManager`, and Core's `IPlatformStoreProvider`. Class names and GUIDs are not kept, so a game moving over needs code changes.

- `PurchaseManager` is the static entry point. Games need no SDK, no provider and no store define.
- `Initialize` replaces `Init` and `LoadStore`. Products come from the project, not from a game table.
- `PurchaseFailure` replaces `BillingManagerRequet` codes and error strings such as `BillingBusy` and `StoreNotLoaded`. The SDK code stays in `PurchaseResult.ProviderCode` and the server's error string in `ServerErrorCode`. Names shared with the network package (`ServerErrorCode`, `NoConnection`, `Timeout`) follow `Docs/PlatformNetwork/Design.md`.
- `IPurchaseVerifier` replaces the direct server call. The manager closes an order only after its verdict. `UnverifiedPurchaseVerifier` is there for games without a server.
- Busy checks, duplicate order checks, batch handling and the close-after-verification rule moved from each store manager into one place.
- Each purchase gets its own callback, instead of being found by product key.
- Recovery and restore return one result per order.
- An order the store sends unasked while the game runs is kept and reported with `PendingPurchaseDetected`, instead of being dropped. Orders from an earlier run are found only by `RecoverPendingPurchases`, which the game calls after every successful `Initialize`.
- An order still being closed is not verified again when a recovery finds it, and a callback that throws is logged also when no provider is set.
- `LoadingChanged` replaces the `"Billing"` loading indicator key.
- `PurchasePriceFormatter` moved here from the game code, unchanged.

Unity tests: see `Docs/PlatformPurchase/Report.md` for the latest candidate.
