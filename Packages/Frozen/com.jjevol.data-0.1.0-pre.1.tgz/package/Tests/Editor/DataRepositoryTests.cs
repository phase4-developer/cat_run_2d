using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;

namespace jjevol.Data.Tests
{
    /// <summary>Synthetic container: an object of text values under its own key.</summary>
    internal sealed class NoteContainer : DataContainer
    {
        public NoteContainer(string key) : base(key, new Dictionary<string, string>(StringComparer.Ordinal)) { }
        public string Read(string id) => ((Dictionary<string, string>)State).TryGetValue(id, out string value) ? value : null;
        public int Count => ((Dictionary<string, string>)State).Count;

        protected override StateChange ParseState(JObject data, bool replace)
        {
            var current = (Dictionary<string, string>)State;
            var next = replace ? new Dictionary<string, string>(StringComparer.Ordinal) : new Dictionary<string, string>(current, StringComparer.Ordinal);
            if (!(data[DataKey] is JObject values)) throw new InvalidDataException("Expected an object: " + DataKey);
            foreach (var pair in values)
            {
                if (pair.Value.Type != JTokenType.String) throw new InvalidDataException("Expected text: " + pair.Key);
                next[pair.Key] = pair.Value.Value<string>();
            }
            IEnumerable<string> changed = next.Keys.Union(current.Keys)
                .Where(key => !current.TryGetValue(key, out string before) || !next.TryGetValue(key, out string after) || before != after);
            return new StateChange(next, changed);
        }

        protected override JObject WriteState(object state)
        {
            var values = new JObject();
            foreach (var pair in ((Dictionary<string, string>)state).OrderBy(pair => pair.Key, StringComparer.Ordinal)) values[pair.Key] = pair.Value;
            return new JObject { [DataKey] = values };
        }
    }

    public sealed class DataRepositoryTests
    {
        private const string Schema = "synthetic:data:v1";
        private static readonly LocalSaveCodec Codec = LocalSaveCodec.CreateEncrypted(
            new LocalSaveEncryption("test-v1", Encoding.ASCII.GetBytes("0123456789abcdef0123456789abcdef")));
        private readonly List<LocalSaveRepository> _saves = new List<LocalSaveRepository>();
        private readonly List<DataRepository> _repositories = new List<DataRepository>();
        private string _profile;

        [SetUp]
        public void SetUp() => _profile = "data:" + Guid.NewGuid().ToString("N");

        [TearDown]
        public void TearDown()
        {
            foreach (DataRepository repository in _repositories) repository.Dispose();
            foreach (LocalSaveRepository save in _saves) { PlayerPrefs.DeleteKey(save.Slot0Key); PlayerPrefs.DeleteKey(save.Slot1Key); }
            PlayerPrefs.Save();
            _repositories.Clear(); _saves.Clear();
        }

        private DataRepository Create(out NoteContainer mails, out NoteContainer options, bool saveMails = false)
        {
            var repository = new DataRepository(_profile);
            _repositories.Add(repository);
            mails = new NoteContainer("userMails");
            options = new NoteContainer("gameOptions");
            repository.Register(mails, saveLocal: saveMails);
            repository.Register(options);
            return repository;
        }

        private LocalSaveRepository Save()
        {
            var save = new LocalSaveRepository(_profile, Codec, "qa.data." + Guid.NewGuid().ToString("N"));
            _saves.Add(save);
            return save;
        }

        private static JObject Response(string mail = null, string option = null)
        {
            var data = new JObject { ["timeStamp"] = 1 };
            if (mail != null) data["userMails"] = new JObject { ["m1"] = mail };
            if (option != null) data["gameOptions"] = new JObject { ["sound"] = option };
            return data;
        }

        [Test]
        public void UpdateJsonAppliesOnlyNamedKeys()
        {
            DataRepository repository = Create(out NoteContainer mails, out NoteContainer options);
            int notices = 0;
            repository.Changed += change => { notices++; Assert.AreEqual(1, change.Containers.Count); };

            Assert.IsTrue(repository.UpdateJson(Response("hello", "on"), "userMails"));
            Assert.AreEqual("hello", mails.Read("m1"));
            Assert.IsNull(options.Read("sound"));
            Assert.AreEqual(1, notices);
            Assert.AreEqual(1, repository.Revision);
        }

        [Test]
        public void MergeSkipsMissingKeysAndReplaceRequiresThem()
        {
            DataRepository repository = Create(out NoteContainer mails, out _);
            Assert.IsTrue(repository.UpdateJson(Response("a"), "userMails", "gameOptions"));
            Assert.AreEqual("a", mails.Read("m1"));
            Assert.Throws<InvalidDataException>(() => repository.ImportJson(Response("b"), "userMails", "gameOptions"));
            Assert.AreEqual("a", mails.Read("m1"));
        }

        [Test]
        public void FailedContainerLeavesEveryTargetUnchanged()
        {
            DataRepository repository = Create(out NoteContainer mails, out NoteContainer options);
            var bad = Response("changed");
            bad["gameOptions"] = new JObject { ["sound"] = 3 };
            Assert.Throws<InvalidDataException>(() => repository.UpdateJson(bad, "userMails", "gameOptions"));
            Assert.IsNull(mails.Read("m1"));
            Assert.AreEqual(0, options.Count);
            Assert.AreEqual(0, repository.Revision);
        }

        [Test]
        public void UnknownTargetKeyIsRejected()
        {
            DataRepository repository = Create(out _, out _);
            Assert.IsTrue(repository.Contains("userMails"));
            Assert.IsFalse(repository.Contains("missing"));
            Assert.Throws<KeyNotFoundException>(() => repository.UpdateJson(Response("a"), "missing"));
        }

        [Test]
        public void StorageSavesOnlyLocalContainers()
        {
            DataRepository repository = Create(out NoteContainer mails, out NoteContainer options);
            Assert.IsFalse(repository.IsSavedLocally("userMails"));
            Assert.IsTrue(repository.IsSavedLocally("gameOptions"));
            LocalSaveRepository save = Save();
            RepositoryStorageAdapter storage = RepositoryStorageAdapter.Open(repository, save, Schema, RepositoryStorageMode.ServerCache,
                () => new JObject { ["gameOptions"] = new JObject { ["sound"] = "off" } });
            Assert.AreEqual("off", options.Read("sound"));

            repository.UpdateJson(Response("server"), "userMails");
            Assert.IsFalse(storage.IsDirty, "Server-only data does not dirty local storage.");
            repository.UpdateJson(Response(option: "on"), "gameOptions");
            Assert.IsTrue(storage.IsDirty);
            Assert.IsTrue(storage.Save());

            LocalSaveLoadResult loaded = save.Load();
            Assert.IsTrue(loaded.Success);
            JObject payload = loaded.Document.Snapshot.Payload;
            Assert.IsFalse(payload.ContainsKey("userMails"));
            Assert.AreEqual("on", payload["gameOptions"]["sound"].Value<string>());
        }

        [Test]
        public void LocalApplyRejectsServerOnlyContainer()
        {
            DataRepository repository = Create(out _, out _);
            RepositoryStorageAdapter storage = RepositoryStorageAdapter.Open(repository, Save(), Schema, RepositoryStorageMode.LocalAuthority,
                () => new JObject { ["gameOptions"] = new JObject() });
            Assert.Throws<InvalidOperationException>(() => storage.ApplyAndSave(Response("a"), false, "userMails"));
            Assert.IsTrue(storage.ApplyAndSave(Response(option: "on"), false, "gameOptions"));
        }

        [Test]
        public void StorageNeedsALocalContainer()
        {
            var repository = new DataRepository(_profile);
            _repositories.Add(repository);
            repository.Register(new NoteContainer("userMails"), saveLocal: false);
            Assert.Throws<InvalidOperationException>(() => RepositoryStorageAdapter.Open(repository, Save(), Schema, RepositoryStorageMode.ServerCache, () => new JObject()));
        }

        [Test]
        public void ReentryFromNotificationIsRejected()
        {
            DataRepository repository = Create(out NoteContainer mails, out _);
            Exception nested = null;
            repository.Changed += _ =>
            {
                try { repository.UpdateJson(Response("again"), "userMails"); }
                catch (Exception exception) { nested = exception; }
            };
            repository.UpdateJson(Response("first"), "userMails");
            Assert.IsInstanceOf<InvalidOperationException>(nested, "A change from inside a notification is rejected.");
            Assert.AreEqual("first", mails.Read("m1"));
            Assert.AreEqual(1, repository.Revision);
        }
    }
}
