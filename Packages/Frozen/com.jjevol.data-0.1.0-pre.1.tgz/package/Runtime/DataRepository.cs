using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace jjevol
{
    public sealed class RepositoryChange
    {
        public DataRepository Repository { get; }
        public long Revision { get; }
        public IReadOnlyList<ContainerChange> Containers { get; }
        internal RepositoryChange(DataRepository repository, long revision, ContainerChange[] changes)
        { Repository = repository; Revision = revision; Containers = Array.AsReadOnly(changes); }
    }

    /// <summary>Profile-scoped owner of containers. No transport or reservation policy; storage is attached separately.</summary>
    public sealed partial class DataRepository : IDisposable
    {
        private readonly int _threadId = Thread.CurrentThread.ManagedThreadId;
        private readonly Dictionary<string, DataContainer> _containers = new Dictionary<string, DataContainer>(StringComparer.Ordinal);
        private readonly HashSet<string> _localKeys = new HashSet<string>(StringComparer.Ordinal);
        private readonly IReadOnlyDictionary<string, DataContainer> _view;
        private long _revision;
        private bool _busy;
        private IRepositoryOverlay _overlay;
        public string ProfileId { get; }
        public bool IsDisposed { get; private set; }
        public long Revision { get { EnsureAccess(); return _revision; } }
        public IReadOnlyDictionary<string, DataContainer> Containers { get { EnsureAccess(); return _view; } }
        public event Action<RepositoryChange> Changed;

        public DataRepository(string profileId)
        {
            if (string.IsNullOrWhiteSpace(profileId)) throw new ArgumentException("An explicit profile identity is required.", nameof(profileId));
            ProfileId = profileId;
            _view = new ReadOnlyDictionary<string, DataContainer>(_containers);
            DataProfileOwnership.Acquire(this);
        }

        /// <summary>
        /// Registers a container. <paramref name="saveLocal"/> decides whether an attached storage adapter
        /// saves and requires it. Server-only data passes false.
        /// </summary>
        public void Register(DataContainer container, bool saveLocal = true)
        {
            EnsureIdle();
            if (Storage != null) throw new InvalidOperationException("Register all containers before attaching storage.");
            if (container == null) throw new ArgumentNullException(nameof(container));
            if (_containers.ContainsKey(container.DataKey)) throw new ArgumentException("Duplicate container key: " + container.DataKey, nameof(container));
            container.Attach(this);
            _containers.Add(container.DataKey, container);
            if (saveLocal) _localKeys.Add(container.DataKey);
        }

        public bool Contains(string dataKey)
        {
            EnsureAccess();
            return dataKey != null && _containers.ContainsKey(dataKey);
        }

        public bool IsSavedLocally(string dataKey)
        {
            EnsureAccess();
            return dataKey != null && _localKeys.Contains(dataKey);
        }

        public DataContainer Get(string dataKey)
        {
            EnsureAccess();
            return _containers.TryGetValue(dataKey, out DataContainer container) ? container : throw new KeyNotFoundException("Unknown container: " + dataKey);
        }

        public T Get<T>(string dataKey) where T : DataContainer => Get(dataKey) as T ?? throw new InvalidCastException("Unexpected container type: " + dataKey);

        // The caller names the scope and operation. Missing patch targets are skipped; replacements require all targets.
        public bool ImportJson(JObject data, params string[] targetKeys) => Change(data, true, targetKeys);
        public bool UpdateJson(JObject data, params string[] targetKeys) => Change(data, false, targetKeys);

        internal bool Change(DataContainer container, JObject data, bool replace)
        {
            if (!ReferenceEquals(Get(container.DataKey), container)) throw new InvalidOperationException("The container is not registered here.");
            return Change(data, replace, new[] { container.DataKey });
        }

        private bool Change(JObject data, bool replace, string[] targetKeys)
        {
            EnsureIdle();
            _busy = true;
            try { return ChangeCore(data, replace, targetKeys, null); }
            finally { _busy = false; }
        }

        private bool ChangeCore(JObject data, bool replace, string[] targetKeys, object overlayState)
            => Publish(PreparePlans(data, replace, targetKeys), overlayState);

        private List<DataContainer.PreparedChange> PreparePlans(JObject data, bool replace, string[] targetKeys)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (targetKeys == null || targetKeys.Length == 0) throw new ArgumentException("Name at least one target container.", nameof(targetKeys));
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var plans = new List<DataContainer.PreparedChange>();
            foreach (string key in targetKeys)
            {
                if (string.IsNullOrWhiteSpace(key) || !seen.Add(key)) throw new ArgumentException("Target keys must be nonempty and unique.", nameof(targetKeys));
                DataContainer container = Get(key);
                if (!data.ContainsKey(key))
                {
                    if (replace) throw new System.IO.InvalidDataException("Missing replacement container: " + key);
                    continue;
                }
                DataContainer.PreparedChange plan = container.Prepare(data, replace);
                if (plan.Notice.ChangedKeys.Count != 0) plans.Add(plan);
            }
            return plans;
        }

        private bool Publish(List<DataContainer.PreparedChange> plans, object overlayState)
        {
            PreparedBatch batch = PreparePublication(plans, overlayState);
            ApplyPublication(batch);
            if (TouchesLocalData(plans)) Storage?.MarkDirty();
            NotifyPublication(batch);
            return plans.Count != 0;
        }

        private bool TouchesLocalData(List<DataContainer.PreparedChange> plans)
        {
            foreach (DataContainer.PreparedChange plan in plans)
                if (_localKeys.Contains(plan.Notice.Container.DataKey)) return true;
            return false;
        }

        internal sealed class PreparedBatch
        {
            internal List<DataContainer.PreparedChange> Plans;
            internal RepositoryChange Notice;
            internal object Overlay;
        }

        private PreparedBatch PreparePublication(List<DataContainer.PreparedChange> plans, object overlayState)
        {
            long revision = plans.Count == 0 ? _revision : checked(_revision + 1);
            var notices = new ContainerChange[plans.Count];
            for (int i = 0; i < plans.Count; i++) notices[i] = plans[i].Notice;
            var notice = new RepositoryChange(this, revision, notices);
            object overlay = _overlay?.PrepareOverlay(plans, overlayState, revision);
            return new PreparedBatch { Plans = plans, Notice = notice, Overlay = overlay };
        }

        private void ApplyPublication(PreparedBatch batch)
        {
            // All parsing, export, allocations and persistence finish before these assignments.
            foreach (DataContainer.PreparedChange plan in batch.Plans) plan.Notice.Container.Apply(plan);
            _revision = batch.Notice.Revision;
            if (batch.Overlay != null) _overlay.ApplyOverlay(batch.Overlay);
        }

        private void NotifyPublication(PreparedBatch batch)
        {
            foreach (ContainerChange change in batch.Notice.Containers) change.Container.Notify(change);
            if (batch.Plans.Count != 0) Notify(batch.Notice);
            if (batch.Overlay != null) _overlay.NotifyOverlay(batch.Overlay);
        }

        // Overlay owners (economy reservations) publish their state through the same atomic path.
        internal IRepositoryOverlay Overlay => _overlay;
        internal void AttachOverlay(IRepositoryOverlay overlay)
        {
            EnsureIdle();
            if (overlay == null) throw new ArgumentNullException(nameof(overlay));
            if (_overlay != null) throw new InvalidOperationException("A repository already has an overlay owner.");
            _overlay = overlay;
        }
        internal void EnsureOverlayAccess(IRepositoryOverlay overlay)
        {
            EnsureAccess();
            if (!ReferenceEquals(overlay, _overlay)) throw new InvalidOperationException("This overlay is not attached here.");
        }
        internal void BeginOverlayChange(IRepositoryOverlay overlay)
        { EnsureOverlayAccess(overlay); EnsureIdle(); _busy = true; }
        internal bool BeginOverlayRead(IRepositoryOverlay overlay)
        { EnsureOverlayAccess(overlay); bool entered = !_busy; _busy = true; return entered; }
        internal void EndOverlayChange() { _busy = false; }
        internal void ApplyOverlay(IRepositoryOverlay overlay, object state)
        { EnsureOverlayAccess(overlay); Publish(new List<DataContainer.PreparedChange>(), state); }
        internal void ChangeWithOverlay(IRepositoryOverlay overlay, object state, JObject data, bool replace, string[] targets)
        { EnsureOverlayAccess(overlay); ChangeCore(data, replace, targets, state); }
        internal void DetachOverlay(IRepositoryOverlay overlay)
        { EnsureOverlayAccess(overlay); EnsureIdle(true); overlay.ReleaseOverlay(); _overlay = null; }

        public JObject ExportJson()
        {
            EnsureAccess();
            var data = new JObject();
            foreach (var pair in _containers)
            {
                JObject exported = pair.Value.ExportJson();
                if (exported.Count != 1 || !exported.ContainsKey(pair.Key)) throw new InvalidOperationException("A container must export its own data key only: " + pair.Key);
                data[pair.Key] = exported[pair.Key];
            }
            return data;
        }

        private void Notify(RepositoryChange change)
        {
            var subscribers = Changed;
            if (subscribers == null) return;
            foreach (Action<RepositoryChange> subscriber in subscribers.GetInvocationList())
                try { subscriber(change); } catch (Exception exception) { Debug.LogException(exception); }
        }

        private void EnsureAccess()
        {
            if (Thread.CurrentThread.ManagedThreadId != _threadId) throw new InvalidOperationException("Use a repository on its creating thread.");
            if (IsDisposed) throw new ObjectDisposedException(nameof(DataRepository));
        }

        private void EnsureIdle(bool allowRecovery = false)
        {
            EnsureAccess();
            if (_busy) throw new InvalidOperationException("A repository change is already being prepared or published.");
            if (!allowRecovery) Storage?.EnsureChangeAllowed();
        }

        public void Dispose()
        {
            if (IsDisposed) return;
            EnsureIdle(true);
            Storage?.Release();
            _overlay?.ReleaseOverlay();
            _overlay = null;
            foreach (DataContainer container in _containers.Values) container.Release();
            _containers.Clear();
            _localKeys.Clear();
            Changed = null;
            IsDisposed = true;
            DataProfileOwnership.Release(this);
        }
    }
}
