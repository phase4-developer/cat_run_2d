using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace jjevol
{
    public sealed class ContainerChange
    {
        public DataContainer Container { get; }
        public long Revision { get; }
        public IReadOnlyList<string> ChangedKeys { get; }
        internal ContainerChange(DataContainer container, long revision, string[] keys)
        { Container = container; Revision = revision; ChangedKeys = Array.AsReadOnly(keys); }
    }

    /// <summary>
    /// Owns one model state. Parsing builds a private candidate; publishing only swaps that state.
    /// Implementations keep state private and perform all fallible work in ParseState.
    /// Access, including item views and notifications, is confined to the creating thread.
    /// </summary>
    public abstract class DataContainer : IDisposable
    {
        private readonly int _threadId = Thread.CurrentThread.ManagedThreadId;
        private object _state;
        private long _revision;
        private bool _busy;
        private bool _disposed;
        public string DataKey { get; }
        public DataRepository Repository { get; private set; }
        public long Revision { get { EnsureAccess(); return _revision; } }
        public bool IsDisposed => _disposed;
        public event Action<ContainerChange> Changed;

        protected DataContainer(string dataKey, object initialState)
        {
            if (string.IsNullOrWhiteSpace(dataKey)) throw new ArgumentException("A container data key is required.", nameof(dataKey));
            DataKey = dataKey;
            _state = initialState ?? throw new ArgumentNullException(nameof(initialState));
        }

        protected object State { get { EnsureAccess(); return _state; } }

        protected sealed class StateChange
        {
            internal object Value { get; }
            internal string[] Keys { get; }
            public StateChange(object state, IEnumerable<string> changedKeys)
            {
                Value = state ?? throw new ArgumentNullException(nameof(state));
                if (changedKeys == null) throw new ArgumentNullException(nameof(changedKeys));
                Keys = changedKeys.ToArray();
                if (Keys.Any(string.IsNullOrWhiteSpace) || Keys.Distinct(StringComparer.Ordinal).Count() != Keys.Length)
                    throw new ArgumentException("Changed item keys must be nonempty and unique.", nameof(changedKeys));
                Array.Sort(Keys, StringComparer.Ordinal);
            }
        }

        protected abstract StateChange ParseState(JObject data, bool replace);
        protected abstract JObject WriteState(object state);
        public bool ImportJson(JObject data) => Change(data, true);
        public bool UpdateJson(JObject data) => Change(data, false);

        public JObject ExportJson()
        {
            EnsureAccess();
            return (JObject)(WriteState(_state) ?? throw new InvalidOperationException("A container export cannot be null.")).DeepClone();
        }

        private bool Change(JObject data, bool replace)
        {
            EnsureAccess();
            if (Repository != null) return Repository.Change(this, data, replace);
            if (_busy) throw new InvalidOperationException("A container change is already being prepared or published.");
            _busy = true;
            try
            {
                PreparedChange plan = Prepare(data, replace);
                if (plan.Notice.ChangedKeys.Count == 0) return false;
                Apply(plan);
                Notify(plan.Notice);
                return true;
            }
            finally { _busy = false; }
        }

        internal sealed class PreparedChange
        {
            internal readonly object State;
            internal readonly ContainerChange Notice;
            internal PreparedChange(DataContainer container, object state, long revision, string[] keys)
            { State = state; Notice = new ContainerChange(container, revision, keys); }
        }

        internal PreparedChange Prepare(JObject data, bool replace)
        {
            EnsureAccess();
            if (data == null) throw new ArgumentNullException(nameof(data));
            StateChange next = ParseState((JObject)data.DeepClone(), replace) ?? throw new InvalidOperationException("A parser returned no candidate.");
            long revision = next.Keys.Length == 0 ? _revision : checked(_revision + 1);
            return new PreparedChange(this, next.Value, revision, next.Keys);
        }

        internal void Apply(PreparedChange plan)
        {
            // All validation, allocations and user code have already completed.
            _state = plan.State;
            _revision = plan.Notice.Revision;
        }

        internal JObject ExportPrepared(PreparedChange plan)
            => (JObject)(WriteState(plan.State) ?? throw new InvalidOperationException("A container export cannot be null.")).DeepClone();

        internal void Notify(ContainerChange change)
        {
            var subscribers = Changed;
            if (subscribers == null) return;
            foreach (Action<ContainerChange> subscriber in subscribers.GetInvocationList())
                try { subscriber(change); } catch (Exception exception) { Debug.LogException(exception); }
        }

        internal void Attach(DataRepository repository)
        {
            EnsureAccess();
            if (_busy || Repository != null) throw new InvalidOperationException("The container already has an owner or an active change.");
            Repository = repository;
        }

        protected void EnsureAccess()
        {
            if (Thread.CurrentThread.ManagedThreadId != _threadId) throw new InvalidOperationException("Use a container on its creating thread.");
            if (_disposed) throw new ObjectDisposedException(GetType().Name);
        }

        public void Dispose()
        {
            EnsureAccess();
            if (_busy || Repository != null) throw new InvalidOperationException("Dispose a registered container through its repository.");
            Release();
        }

        internal void Release()
        {
            _disposed = true;
            _state = null;
            Changed = null;
        }
    }
}
