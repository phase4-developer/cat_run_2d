using System.Collections.Generic;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("JJEvol.Economy.Runtime")]
[assembly: InternalsVisibleTo("JJEvol.Data.Tests.Editor")]

namespace jjevol
{
    /// <summary>
    /// A state that is published together with container changes (for example economy reservations).
    /// The repository prepares, applies and notifies it in the same atomic step without knowing its type.
    /// </summary>
    internal interface IRepositoryOverlay
    {
        bool OverlayRequiresResynchronization { get; }
        object EmptyOverlayState();
        object PrepareOverlay(IReadOnlyList<DataContainer.PreparedChange> plans, object nextState, long repositoryRevision);
        void ApplyOverlay(object prepared);
        void NotifyOverlay(object prepared);
        void ReleaseOverlay();
    }
}
