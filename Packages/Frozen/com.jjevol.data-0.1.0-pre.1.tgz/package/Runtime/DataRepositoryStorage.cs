using System;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace jjevol
{
    public sealed partial class DataRepository
    {
        public RepositoryStorageAdapter Storage { get; private set; }
        internal void AttachStorage(RepositoryStorageAdapter storage)
        {
            EnsureIdle();
            if (Storage != null) throw new InvalidOperationException("Storage is already attached.");
            if (_localKeys.Count == 0 || _containers.ContainsKey(RepositoryStorageAdapter.SchemaKey)) throw new InvalidOperationException("Register at least one locally saved container before storage; the schema key is reserved.");
            Storage = storage;
        }
        internal void DetachFailedStorage(RepositoryStorageAdapter storage)
        { if (ReferenceEquals(Storage, storage)) { storage.Release(); Storage = null; } }
        internal void BeginStorageChange(RepositoryStorageAdapter storage, bool recovery)
        {
            EnsureIdle(recovery);
            if (!ReferenceEquals(Storage, storage)) throw new InvalidOperationException("Storage is not attached here.");
            _busy = true;
        }
        internal void EndStorageChange() { _busy = false; }
        internal PreparedBatch PrepareStored(JObject data, bool replace, string[] keys, bool clearOverlay = false)
        {
            if (keys != null)
                foreach (string key in keys)
                    if (key != null && _containers.ContainsKey(key) && !_localKeys.Contains(key))
                        throw new InvalidOperationException("The container is not saved locally: " + key);
            return PreparePublication(PreparePlans(data, replace, keys), clearOverlay && _overlay != null ? _overlay.EmptyOverlayState() : null);
        }
        // Only containers registered with saveLocal are written and required by storage.
        internal string[] StorageKeys => _localKeys.OrderBy(key => key, StringComparer.Ordinal).ToArray();
        internal JObject ExportStored(PreparedBatch batch, JObject preserved)
        {
            var payload = (JObject)preserved.DeepClone();
            foreach (var pair in _containers)
            {
                if (!_localKeys.Contains(pair.Key)) continue;
                DataContainer.PreparedChange plan = batch.Plans.FirstOrDefault(candidate => ReferenceEquals(candidate.Notice.Container, pair.Value));
                JObject exported = plan == null ? pair.Value.ExportJson() : pair.Value.ExportPrepared(plan);
                if (exported.Count != 1 || !exported.ContainsKey(pair.Key)) throw new InvalidOperationException("A container must export only its registered key: " + pair.Key);
                payload[pair.Key] = exported[pair.Key];
            }
            return payload;
        }
        internal PreparedBatch PrepareSaveCurrent() => PreparePublication(new System.Collections.Generic.List<DataContainer.PreparedChange>(), null);
        internal void ApplyStored(PreparedBatch batch) => ApplyPublication(batch);
        internal void NotifyStored(PreparedBatch batch) => NotifyPublication(batch);
    }
}
