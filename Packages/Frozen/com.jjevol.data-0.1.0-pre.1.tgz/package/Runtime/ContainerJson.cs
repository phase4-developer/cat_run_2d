using System;
using System.IO;
using Newtonsoft.Json.Linq;

namespace jjevol
{
    // Strict, explicit model input helpers shared by Containers and ConsumeData.
    public static class ContainerJson
    {
        public static JArray RequireArray(JObject data, string key)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (!data.TryGetValue(key, out JToken value)) throw new InvalidDataException("Missing array: " + key);
            return value as JArray ?? throw new InvalidDataException("Expected an array: " + key);
        }

        public static string RequireKey(JObject data, string key)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (!data.TryGetValue(key, out JToken value)) throw new InvalidDataException("Missing key: " + key);
            if (value.Type != JTokenType.String || string.IsNullOrWhiteSpace(value.Value<string>())) throw new InvalidDataException("Expected a nonempty string key: " + key);
            return value.Value<string>();
        }

        public static bool TryReadInt64(JObject data, string key, out long value)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            value = 0;
            if (!data.TryGetValue(key, out JToken token)) return false;
            if (token.Type != JTokenType.Integer) throw new InvalidDataException("Expected a long integer: " + key);
            try { value = ((JValue)token).Value is System.Numerics.BigInteger integer ? checked((long)integer) : token.Value<long>(); }
            catch (Exception exception) when (exception is OverflowException || exception is InvalidCastException || exception is FormatException || exception is ArgumentException)
            { throw new InvalidDataException("Integer exceeds the long range: " + key, exception); }
            return true;
        }

        public static long RequireInt64(JObject data, string key)
            => TryReadInt64(data, key, out long value) ? value : throw new InvalidDataException("Missing integer: " + key);
    }
}
