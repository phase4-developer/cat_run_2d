using System;
using System.IO;
using Newtonsoft.Json.Linq;

namespace jjevol
{
    public enum RepositoryStorageMode { LocalAuthority, ServerCache }
    public enum RepositoryStorageStatus { Ready, Conflict, RecoveryRequired, Disposed }
    public sealed class RepositoryRecoveryRequiredException : InvalidOperationException
    {
        public RepositoryRecoveryRequiredException(string message, Exception inner = null) : base(message, inner) { }
    }

    /// <summary>Document basis and synchronous persistence only. Live game values remain in Repository containers.</summary>
    public sealed class RepositoryStorageAdapter
    {
        public const string SchemaKey = "_containerSchema";
        private readonly LocalSaveRepository _preferences;
        private LocalSaveDocument _basis;
        // The save repository refuses further writes after an uncertain write, for its whole lifetime. Reload cannot clear that.
        private bool _reopenRequired;
        public DataRepository Repository { get; }
        public RepositoryStorageMode Mode { get; }
        public string SchemaId { get; }
        public RepositoryStorageStatus Status { get; private set; }
        public bool IsDirty { get; private set; }
        public long SavedRevision => _basis?.StateRevision ?? -1;
        public LocalSaveLoadStatus LastLoadStatus { get; private set; }
#if UNITY_EDITOR
        // Narrow failure injection for the otherwise nonvirtual assignment-only publish phase; no callback hook.
        private bool _failNextApplyForTesting = false;
#endif
        private RepositoryStorageAdapter(DataRepository repository, LocalSaveRepository preferences, string schemaId, RepositoryStorageMode mode)
        {
            Repository = repository ?? throw new ArgumentNullException(nameof(repository));
            _preferences = preferences ?? throw new ArgumentNullException(nameof(preferences));
            if (repository.ProfileId != preferences.ProfileId) throw new ArgumentException("Storage and repository profile identities differ.");
            if (string.IsNullOrWhiteSpace(schemaId)) throw new ArgumentException("An explicit versioned game schema ID is required.", nameof(schemaId));
            if (mode != RepositoryStorageMode.LocalAuthority && mode != RepositoryStorageMode.ServerCache) throw new ArgumentOutOfRangeException(nameof(mode));
            SchemaId = schemaId; Mode = mode;
        }

        public static RepositoryStorageAdapter Open(DataRepository repository, LocalSaveRepository preferences, string schemaId, RepositoryStorageMode mode, Func<JObject> createInitial = null)
        {
            var adapter = new RepositoryStorageAdapter(repository, preferences, schemaId, mode);
            repository.AttachStorage(adapter);
            try { adapter.LoadIntoRepository(createInitial); return adapter; }
            catch { if (adapter.Status != RepositoryStorageStatus.RecoveryRequired) repository.DetachFailedStorage(adapter); throw; }
        }

        private void EnsureAccess()
        {
            _ = Repository.Revision; // Creating thread and repository lifetime.
            if (Status == RepositoryStorageStatus.Disposed || !ReferenceEquals(Repository.Storage, this)) throw new ObjectDisposedException(nameof(RepositoryStorageAdapter));
        }
        internal void EnsureChangeAllowed()
        {
            if (Mode == RepositoryStorageMode.LocalAuthority && Status != RepositoryStorageStatus.Ready)
                throw new RepositoryRecoveryRequiredException(_reopenRequired ? ReopenMessage : "Reload the local profile before making further changes: " + Status);
        }
        private const string ReopenMessage = "A save write is uncertain. Dispose the repository and open the profile again with a new LocalSaveRepository; Reload cannot recover this instance.";
        internal void MarkDirty() { IsDirty = true; }
        internal void Release() { Status = RepositoryStorageStatus.Disposed; _basis = null; }

        private JObject ValidateDocument(LocalSaveLoadResult loaded)
        {
            LastLoadStatus = loaded.Status;
            if (!loaded.Success) throw new InvalidDataException("Cannot load repository: " + loaded.Status + ". " + loaded.Error);
            JObject payload = loaded.Document.Snapshot.Payload;
            if (payload[SchemaKey]?.Type != JTokenType.String || payload.Value<string>(SchemaKey) != SchemaId)
                throw new InvalidDataException("Unexpected repository schema; explicit migration is required.");
            return payload;
        }

        private void LoadIntoRepository(Func<JObject> createInitial)
        {
            EnsureAccess();
            Repository.BeginStorageChange(this, true);
            try
            {
                LocalSaveLoadResult loaded = _preferences.Load();
                LastLoadStatus = loaded.Status;
                bool missing = loaded.Status == LocalSaveLoadStatus.Missing;
                JObject payload;
                if (missing)
                {
                    if (createInitial == null) throw new InvalidOperationException("A missing profile requires explicit initial container data.");
                    payload = (JObject)(createInitial() ?? throw new InvalidDataException("The initial factory returned null.")).DeepClone();
                    if (payload.ContainsKey(SchemaKey) && (payload[SchemaKey].Type != JTokenType.String || payload.Value<string>(SchemaKey) != SchemaId)) throw new InvalidDataException("Initial schema does not match.");
                    payload[SchemaKey] = SchemaId;
                }
                else payload = ValidateDocument(loaded);
                DataRepository.PreparedBatch batch = Repository.PrepareStored(payload, true, Repository.StorageKeys, true);
                // Export is also validated before a new profile is written.
                JObject canonical = Repository.ExportStored(batch, payload);
                LocalSaveDocument saved = missing ? Write(new LocalSaveSnapshot(canonical)) : loaded.Document;
                Complete(saved, batch);
            }
            catch { if (_basis != null) Status = RepositoryStorageStatus.RecoveryRequired; throw; }
            finally { Repository.EndStorageChange(); }
        }

        public void Reload()
        {
            EnsureAccess();
            if (Mode != RepositoryStorageMode.LocalAuthority) throw new NotSupportedException("A server cache must not roll back server state; use RefreshCacheBasis.");
            // Missing established PlayerPrefs slots are an error, never a new initial profile.
            LoadIntoRepository(null);
        }

        public void RefreshCacheBasis()
        {
            EnsureAccess();
            if (Mode != RepositoryStorageMode.ServerCache) throw new NotSupportedException("This API is for optional server caches.");
            Repository.BeginStorageChange(this, true);
            try
            {
                LocalSaveLoadResult loaded = _preferences.Load(); JObject payload = ValidateDocument(loaded);
                _ = Repository.PrepareStored(payload, true, Repository.StorageKeys);
                _basis = loaded.Document; Status = RepositoryStorageStatus.Ready;
                IsDirty = !JToken.DeepEquals(Repository.ExportStored(Repository.PrepareSaveCurrent(), payload), payload);
            }
            catch { Status = RepositoryStorageStatus.RecoveryRequired; throw; }
            finally { Repository.EndStorageChange(); }
        }

        public bool Save()
        {
            EnsureAccess(); EnsurePersistenceReady();
            Repository.BeginStorageChange(this, false);
            try { return Persist(Repository.PrepareSaveCurrent()); }
            finally { Repository.EndStorageChange(); }
        }
        public bool ApplyAndSave(JObject data, bool replace, params string[] targetKeys)
        {
            EnsureAccess(); EnsurePersistenceReady();
            if (Mode != RepositoryStorageMode.LocalAuthority) throw new NotSupportedException("Server cache writes use Save after authoritative server application.");
            Repository.BeginStorageChange(this, false);
            try { return Persist(Repository.PrepareStored(data, replace, targetKeys)); }
            finally { Repository.EndStorageChange(); }
        }
        private void EnsurePersistenceReady()
        {
            if (Status != RepositoryStorageStatus.Ready) throw new RepositoryRecoveryRequiredException(_reopenRequired ? ReopenMessage : "Reload or refresh the document basis before saving: " + Status);
        }

        internal LocalSaveDocument Basis => _basis;
        internal void EnsureLocalMutation(IRepositoryOverlay overlay, DataRepository overlayRepository, string dataKey)
        {
            EnsureAccess(); EnsurePersistenceReady();
            if (Mode != RepositoryStorageMode.LocalAuthority || overlay == null || !ReferenceEquals(overlayRepository, Repository)) throw new NotSupportedException("Local mutation requires this repository's local authority adapter and resources.");
            if (!Repository.IsSavedLocally(dataKey)) throw new NotSupportedException("Local mutation requires a locally saved container: " + dataKey);
            if (IsDirty) throw new InvalidOperationException("Explicitly save or reload unsaved container changes before preparing a local transaction.");
            if (overlay.OverlayRequiresResynchronization) throw new RepositoryRecoveryRequiredException("Resolve the uncertain resource request first.");
        }
        internal bool Persist(DataRepository.PreparedBatch batch)
        {
            JObject payload = Repository.ExportStored(batch, _basis.Snapshot.Payload);
            var snapshot = new LocalSaveSnapshot(payload); // Serialize/normalize before touching storage.
            bool changed = !JToken.DeepEquals(snapshot.Payload, _basis.Snapshot.Payload);
            LocalSaveDocument saved;
            if (changed) saved = Write(snapshot);
            else
            {
                LocalSaveLoadResult current = _preferences.Load();
                if (!current.Success || !_basis.Matches(current.Document)) { Status = RepositoryStorageStatus.Conflict; throw new LocalSaveConflictException(); }
                saved = _basis;
            }
            Complete(saved, batch);
            return changed;
        }
        private LocalSaveDocument Write(LocalSaveSnapshot snapshot)
        {
            // Checked before IO; revision overflow is a validation failure.
            _ = checked((_basis?.StateRevision ?? -1) + 1);
            try { return _preferences.Save(snapshot, _basis); }
            catch (LocalSaveConflictException) { Status = RepositoryStorageStatus.Conflict; throw; }
            catch (Exception exception)
            {
                if (exception is LocalSaveWriteException) _reopenRequired = true;
                try
                {
                    LocalSaveLoadResult current = _preferences.Load();
                    bool old = _basis == null ? current.Status == LocalSaveLoadStatus.Missing : current.Success && _basis.Matches(current.Document);
                    if (!old) Status = RepositoryStorageStatus.RecoveryRequired;
                }
                catch { Status = RepositoryStorageStatus.RecoveryRequired; }
                throw;
            }
        }
        private void Complete(LocalSaveDocument saved, DataRepository.PreparedBatch batch)
        {
            _basis = saved;
            try
            {
#if UNITY_EDITOR
                if (_failNextApplyForTesting) { _failNextApplyForTesting = false; throw new InvalidOperationException("Injected post-save memory publication failure."); }
#endif
                Repository.ApplyStored(batch);
            }
            catch (Exception exception)
            {
                Status = RepositoryStorageStatus.RecoveryRequired;
                throw new RepositoryRecoveryRequiredException("Storage was confirmed but memory publication failed. Reload; do not repeat the reward.", exception);
            }
            IsDirty = false; Status = RepositoryStorageStatus.Ready;
            Repository.NotifyStored(batch);
        }
    }
}
