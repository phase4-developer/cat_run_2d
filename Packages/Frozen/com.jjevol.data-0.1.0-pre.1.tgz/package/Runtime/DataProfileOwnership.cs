using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol
{
    // Exactly one live Container repository per profile. Stores no model data and resolves no services.
    internal static class DataProfileOwnership
    {
        private static readonly Dictionary<string, WeakReference<DataRepository>> Claims = new Dictionary<string, WeakReference<DataRepository>>(StringComparer.Ordinal);

        // With Domain Reload disabled, an undisposed repository from the previous Play session must not block its profile.
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetSession()
        {
            lock (Claims) Claims.Clear();
        }

        internal static void Acquire(DataRepository repository)
        {
            lock (Claims)
            {
                if (Claims.TryGetValue(repository.ProfileId, out var claim) && claim.TryGetTarget(out DataRepository current) && !current.IsDisposed)
                    throw new InvalidOperationException("This profile already has a container owner.");
                Claims[repository.ProfileId] = new WeakReference<DataRepository>(repository);
            }
        }

        internal static void Release(DataRepository repository)
        {
            lock (Claims)
            {
                if (Claims.TryGetValue(repository.ProfileId, out var claim) && claim.TryGetTarget(out DataRepository current) && ReferenceEquals(current, repository))
                    Claims.Remove(repository.ProfileId);
            }
        }
    }
}
