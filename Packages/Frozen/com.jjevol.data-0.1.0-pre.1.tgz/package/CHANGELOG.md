# Changelog

## 0.1.0-pre.1 - 2026-11-08

- Moved `DataRepository`, `DataContainer`, `RepositoryStorageAdapter`, `ContainerJson` and profile ownership out of `com.jjevol.economy@0.1.0-pre.3`. Class names, the `jjevol` namespace and the script GUIDs are unchanged.
- Added `Register(container, saveLocal = true)`. Storage saves and requires only locally saved containers. Server-only changes do not mark storage dirty.
- Added `Contains(key)` and `IsSavedLocally(key)`.
- The repository no longer knows the economy resource service. Reservations publish through an internal overlay connection.

The 8 Editor tests passed in Unity EditMode on Hosts/NetworkValidationHost (job network-host-2, candidate abd61a5).
