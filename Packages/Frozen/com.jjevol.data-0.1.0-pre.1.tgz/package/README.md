# JJEvol Data Repository

`com.jjevol.data@0.1.0-pre.1`은 프로필 단위 데이터 저장소다. 서버나 로컬 서비스 응답을 대상 키로 받아 여러 Container에 한 번에 반영하고, 필요한 Container만 AES PlayerPrefs에 저장한다. Unity 6000.3.9f1 기준이다.

필수: `com.jjevol.save@0.1.0-pre.3`, Unity Newtonsoft JSON 3.2.2. 통신, 재화, UI, Firebase를 요구하지 않는다. 재화(`com.jjevol.economy`)와 통신 연결(`com.jjevol.platform.network.data`)은 이 패키지에 의존하는 선택 패키지다.

## 게임 데이터 정의

게임은 `DataContainer`를 상속해 자기 키의 값을 해석한다. 값이 배열인지 객체인지는 상속한 쪽이 정한다. 리스트 전용 부모 클래스나 리플렉션 자동 병합은 없다.

```csharp
public sealed class MailContainer : DataContainer
{
    public const string Key = "userMails";
    public MailContainer() : base(Key, MailState.Empty) { }

    // data는 응답 전체의 복사본이다. 자기 키 값을 꺼내 새 상태 후보를 만든다.
    protected override StateChange ParseState(JObject data, bool replace) { /* data[Key] 해석 */ }
    protected override JObject WriteState(object state) { /* { "userMails": [...] } */ }
}
```

`ParseState`는 실패할 수 있는 일을 모두 끝내고 새 상태와 바뀐 항목 키를 돌려준다. 상태 교체는 저장소가 모든 대상의 검증을 마친 뒤 한 번에 한다.

## 반영

```csharp
var data = new DataRepository(profileId);
data.Register(new MailContainer(), saveLocal: false);   // 서버 데이터
data.Register(new GameOptionContainer());               // 기본값 saveLocal: true

data.UpdateJson(response, MailContainer.Key, "wealthInfos"); // 병합
data.ImportJson(response, MailContainer.Key);                // 교체
```

- 호출하는 쪽이 대상 키를 알려 준다. 응답 모양으로 전체/부분을 추측하지 않는다.
- 병합은 응답에 없는 대상 키를 건너뛴다. 교체는 대상 키가 모두 있어야 한다.
- 대상 Container 하나라도 해석에 실패하면 어느 Container도 바뀌지 않는다.
- 알림 순서는 Container → `DataRepository.Changed`다. 알림 안에서 조회는 되고 같은 저장소 변경은 거부된다. 구독자 예외는 격리한다.
- 생성한 스레드에서만 쓴다. 한 프로필에는 살아 있는 저장소가 하나만 있다.
- `Contains(key)`, `IsSavedLocally(key)`로 등록 상태를 확인한다.

## 로컬 저장

```csharp
var storage = RepositoryStorageAdapter.Open(data,
    new LocalSaveRepository(profileId, encryptedCodec, "mygame.progress.v2"),
    "game:local:v1", RepositoryStorageMode.ServerCache,
    () => initialLocalJson);
storage.Save();
```

- `saveLocal: true`로 등록한 Container만 저장하고, 로드 때 그것만 필수로 본다. 로컬 저장 Container가 하나도 없으면 저장소를 열 수 없다.
- 서버 전용 Container 변경은 `IsDirty`를 켜지 않는다.
- `ApplyAndSave`는 로컬 저장 Container만 대상으로 받는다.
- 저장 확인 → 메모리 반영 → 알림 순서다. 저장 후 메모리 반영이 실패하면 `RecoveryRequired`로 멈춘다.
- `LocalAuthority`는 로컬이 정본인 게임, `ServerCache`는 서버가 정본이고 로컬은 캐시인 게임이다.

## 재화와의 관계

`com.jjevol.economy`의 `ResourceService`는 저장소 내부 연결 지점(`IRepositoryOverlay`, internal)으로 예약 상태를 Container 변경과 같은 단계에 반영한다. 이 연결은 공개 API가 아니다.

## 시험

`Tests/Editor`(`JJEvol.Data.Tests.Editor`)에 합성 Container로 반영, 원자성, 로컬 저장 선택, 재진입 차단 시험이 있다. 재화와 함께 쓰는 시험은 `com.jjevol.economy/Tests`에 있다.

Unity EditMode 시험은 `Hosts/NetworkValidationHost`(잡 `network-host-2`, 후보 `abd61a5`)에서 모두 통과했다. 같은 시험 8개를 Unity 없이 .NET 실행기(`PlayerPrefs` 대역)로 돌려 통과했다.
