# Provenance and distribution boundary

User-authored code. The repository and container contracts were written in this Framework (ContractRecovery steps, 2026-11-02 to 2026-11-03) inside `com.jjevol.economy` and moved here on 2026-11-08 at the user's direction. Original game libraries were used as reference only.

No SDK source, product keys, server addresses, company content or paid Vendor source is bundled. Unity Newtonsoft JSON and `com.jjevol.save` are declared dependencies.

This is an unfrozen local validation candidate. Publishing and installing into existing games remain separate review steps.
