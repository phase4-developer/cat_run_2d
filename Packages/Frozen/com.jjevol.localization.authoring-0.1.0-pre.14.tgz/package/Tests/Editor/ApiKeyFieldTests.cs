using System;
using System.IO;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Localization.Authoring.Tests
{
    public class ApiKeyFieldTests
    {
        private static readonly FieldInfo Field = typeof(GoogleSheetLocImporterWindow).GetField("googleApiKey", BindingFlags.NonPublic | BindingFlags.Instance);
        private static string PreferenceKey => (string)typeof(GoogleSheetLocImporterWindow).GetField("ApiKeyPreference", BindingFlags.NonPublic | BindingFlags.Static).GetValue(null);
        private static void Store(GoogleSheetLocImporterWindow window, string value)
            => typeof(GoogleSheetLocImporterWindow).GetMethod("StoreApiKey", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(window, new object[] { value });

        [Test] public void TheKeyIsDrawnOnlyThroughAPasswordField()
        {
            // IMGUI masks the value while drawing, so the drawing call itself is what can regress.
            string package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(GoogleSheetLocImporterWindow).Assembly).resolvedPath;
            string source = File.ReadAllText(Path.Combine(package, "Editor", "GoogleSheetExporterWindow.cs"));
            StringAssert.Contains("EditorGUILayout.PasswordField(new GUIContent(\"Google API Key", source);
            StringAssert.DoesNotContain("googleApiKey = EditorGUILayout.TextField(", source);
        }
        [Test] public void TheKeyIsNeverSerializedWithTheWindow()
        {
            Assert.IsNull(Field.GetCustomAttribute<SerializeField>());
            Assert.IsTrue(Field.IsNotSerialized, "The window layout lives in the project; the key must not.");
            var window = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            try
            {
                Field.SetValue(window, "synthetic_key_not_saved");
                StringAssert.DoesNotContain("synthetic_key_not_saved", EditorJsonUtility.ToJson(window));
            }
            finally { UnityEngine.Object.DestroyImmediate(window); }
        }
        [Test] public void TheKeyIsKeptInEditorPrefsOutsideTheProject()
        {
            string key = PreferenceKey;
            bool had = EditorPrefs.HasKey(key);
            string previous = EditorPrefs.GetString(key, string.Empty);
            var window = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            GoogleSheetLocImporterWindow reopened = null;
            try
            {
                Store(window, "synthetic_key_in_prefs");
                Assert.AreEqual("synthetic_key_in_prefs", EditorPrefs.GetString(key, string.Empty));
                reopened = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
                Assert.AreEqual("synthetic_key_in_prefs", Field.GetValue(reopened), "A new window reads the key back.");
                Store(window, string.Empty);
                Assert.IsFalse(EditorPrefs.HasKey(key), "Forget removes the stored key.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(window);
                if (reopened) UnityEngine.Object.DestroyImmediate(reopened);
                if (had) EditorPrefs.SetString(key, previous); else EditorPrefs.DeleteKey(key);
            }
        }
    }
}
