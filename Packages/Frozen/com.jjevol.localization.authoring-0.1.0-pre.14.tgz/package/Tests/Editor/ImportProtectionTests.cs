using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.Localization;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Localization.Authoring.Tests
{
    /// <summary>Rules that need no Localization assets, so they run outside the approved fixture Host.</summary>
    public class ImportImpactTests
    {
        private static object Impact(IEnumerable<string> existing, IEnumerable<string> incoming, int emptyRows = 0, int textRows = 0)
        {
            var type = typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationImportImpact", true);
            return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.NonPublic, null, new object[] { "collection", existing, incoming, emptyRows, textRows }, null);
        }
        private static T Read<T>(object impact, string property) => (T)impact.GetType().GetProperty(property, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(impact);
        private static string Describe(object impact) => (string)impact.GetType().GetMethod("Describe", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(impact, null);
        private static string[] Keys(int count, string prefix = "key") => Enumerable.Range(0, count).Select(index => prefix + index).ToArray();

        [Test] public void ImpactCountsAddedAndRemovedExactKeys()
        {
            var impact = Impact(new[] { "Title", "keep", "gone" }, new[] { "title", "keep" });
            Assert.AreEqual(3, Read<int>(impact, "ExistingKeys")); Assert.AreEqual(2, Read<int>(impact, "IncomingKeys")); Assert.AreEqual(1, Read<int>(impact, "AddedKeys"));
            CollectionAssert.AreEqual(new[] { "Title", "gone" }, Read<IReadOnlyList<string>>(impact, "RemovedKeys"));
            Assert.That(Read<double>(impact, "RemovedRatio"), Is.EqualTo(2d / 3).Within(1e-9));
        }

        [TestCase(0, 0, false)]
        [TestCase(10, 0, false)]
        [TestCase(10, 1, false)]
        [TestCase(10, 2, true)]
        [TestCase(1, 1, true)]
        [TestCase(1000, 50, false)]
        [TestCase(1000, 51, true)]
        public void ConfirmationStartsAboveTheRatioOrCountThreshold(int existing, int removed, bool expected)
        {
            var all = Keys(existing);
            Assert.AreEqual(expected, Read<bool>(Impact(all, all.Skip(removed)), "RequiresConfirmation"));
        }

        [Test] public void FirstImportOfANewCollectionNeedsNoConfirmation()
            => Assert.IsFalse(Read<bool>(Impact(Array.Empty<string>(), Keys(500)), "RequiresConfirmation"));

        [Test] public void DescriptionReportsDeletionAndEmptyRowsAndBoundsItsKeyList()
        {
            string text = Describe(Impact(Keys(30, "gone"), new[] { "fresh" }, 4, 3));
            StringAssert.Contains("30 existing", text); StringAssert.Contains("1 added", text); StringAssert.Contains("30 removed (100%)", text);
            StringAssert.Contains("Empty Key rows: 4 (3 with text", text); StringAssert.Contains("and 10 more", text);
        }
    }

    public class ImportProtectionTests
    {
        private GoogleSheetLocImporterWindow window;
        private string directory, first, second;
        private jjevol.Step24.Tests.HostResidue residue;
        private const string Seed = "Key,ko,en\nkeep,유지,keep\nremove,삭제,remove\n";
        private static string Journal => (string)typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationImportTransaction", true).GetProperty("JournalPath", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);
        private static void Set(object target, string field, object value) => target.GetType().GetField(field, BindingFlags.NonPublic | BindingFlags.Instance).SetValue(target, value);
        private static object Get(object target, string field) => target.GetType().GetField(field, BindingFlags.NonPublic | BindingFlags.Instance).GetValue(target);
        private static object Call(object target, string method, params object[] values)
        {
            try { return target.GetType().GetMethod(method, BindingFlags.NonPublic | BindingFlags.Instance).Invoke(target, values); }
            catch (TargetInvocationException error) { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
        }
        private static Dictionary<string, byte[]> Files(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path.Replace('\\', '/'), File.ReadAllBytes);
        private static void SameFiles(Dictionary<string, byte[]> expected, string root)
        {
            var actual = Files(root);
            CollectionAssert.AreEquivalent(expected.Keys, actual.Keys);
            foreach (var pair in expected) CollectionAssert.AreEqual(pair.Value, actual[pair.Key], pair.Key);
        }
        private static StringTable Table(string name, string locale) => LocalizationEditorSettings.GetStringTableCollection(name).GetTable(new LocaleIdentifier(locale)) as StringTable;
        private string Status => (string)Get(window, "_importStatus");
        private void Respond(params string[] sheets)
        {
            int index = 0;
            Set(window, "RequestText", new Func<string, int, CancellationToken, Task<string>>((url, timeout, token) => Task.FromResult(sheets[index++ % sheets.Length])));
        }
        // Synchronous responses let each operation finish inside its call.
        private void Preview() => Call(window, "DownloadAndPreview");
        private void Apply(bool confirmed = true) => Call(window, "ApplyPreview", confirmed);
        private void Seeded() { Respond(Seed); Preview(); Apply(false); Assert.AreEqual("Completed", Status); }

        [SetUp] public void Setup()
        {
            jjevol.Step24.Tests.ImportTestUtil.Guard();
            Assert.IsFalse(File.Exists(Journal), "A previous unresolved import must not be overwritten by tests.");
            string id = Guid.NewGuid().ToString("N");
            directory = "Assets/T1LocalizationFixtures/" + id; residue = new jjevol.Step24.Tests.HostResidue(directory);
            first = "t1_a_" + id; second = "t1_b_" + id;
            Directory.CreateDirectory(directory + "/Tables"); AssetDatabase.Refresh();
            window = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            Set(window, "collectionSaveDir", directory + "/Tables");
            Set(window, "outputFolder", directory + "/Downloads");
            Set(window, "exportAsTsv", false);
            Set(window, "spreadsheetUrlOrId", "synthetic_spreadsheet_id_123456789");
            Set(window, "googleApiKey", string.Empty);
            Set(window, "manualSheets", first + "=0," + second + "=1");
        }
        [TearDown] public void Cleanup()
        {
            if (window) Object.DestroyImmediate(window);
            residue?.Clean();
        }

        [TestCase("Key,ko,en\n")]
        [TestCase("Key,ko,en")]
        [TestCase("Key,ko,en\n,,\n,,\n")]
        [TestCase("Key,ko,en\n,번역만 있음,text only\n")]
        public void SheetWithoutKeyRowsIsRejectedBeforeAnyChange(string empty)
        {
            Seeded(); var before = Files(directory);
            Respond(Seed, empty); LogAssert.Expect(LogType.Error, new Regex("no Key rows"));
            Preview();
            Assert.AreEqual("Failed", Status); Assert.IsNull(Get(window, "_previewPlans"));
            SameFiles(before, directory);
            Assert.AreEqual("keep", Table(first, "en").GetEntry("keep").Value); Assert.AreEqual("remove", Table(second, "en").GetEntry("remove").Value);
        }

        [Test] public void EmptySheetCannotCreateANewCollection()
        {
            Respond("Key,ko,en\n"); LogAssert.Expect(LogType.Error, new Regex("no Key rows"));
            Preview();
            Assert.AreEqual("Failed", Status); Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(first));
        }

        [Test] public void DirectImportBoundaryAlsoRejectsAnEmptySheet()
        {
            Seeded();
            Assert.Throws<InvalidDataException>(() => Call(window, "PrepareImport", "Key,ko,en\n", first, false));
        }

        [Test] public void PreviewReportsTheReplacementWithoutChangingAnyFile()
        {
            Seeded(); var before = Files(directory);
            Respond("Key,ko,en\nkeep,수정,changed\nfresh,추가,new\n,,\n,고아,orphan\n");
            Preview();
            Assert.AreEqual("PreviewReady", Status); SameFiles(before, directory);
            Assert.AreEqual("keep", Table(first, "en").GetEntry("keep").Value);
            var plans = (Array)Get(window, "_previewPlans"); Assert.AreEqual(2, plans.Length);
            var plan = plans.GetValue(0); var impact = plan.GetType().GetField("Impact", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(plan);
            int Count(string property) => (int)impact.GetType().GetProperty(property, BindingFlags.NonPublic | BindingFlags.Instance).GetValue(impact);
            Assert.AreEqual(2, Count("ExistingKeys")); Assert.AreEqual(2, Count("IncomingKeys")); Assert.AreEqual(1, Count("AddedKeys"));
            Assert.AreEqual(2, Count("EmptyKeyRows")); Assert.AreEqual(1, Count("EmptyKeyRowsWithText"));
        }

        [Test] public void TrailingLineEndingIsNotReportedAsAnEmptyKeyRow()
        {
            var plan = Call(window, "PrepareImport", "Key,ko,en\nkeep,가,a\n", first, false);
            var impact = plan.GetType().GetField("Impact", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(plan);
            Assert.AreEqual(0, (int)impact.GetType().GetProperty("EmptyKeyRows", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(impact));
        }

        [Test] public void DeletionAboveThresholdNeedsExplicitConfirmationThenApplies()
        {
            Seeded(); var before = Files(directory);
            Respond("Key,ko,en\nkeep,수정,changed\n"); Preview();
            LogAssert.Expect(LogType.Error, new Regex("Confirm the reported key deletion"));
            Apply(false);
            Assert.AreEqual("Failed", Status); SameFiles(before, directory);
            Assert.IsNotNull(Get(window, "_previewPlans"), "An unconfirmed preview stays available for confirmation.");
            Apply(true);
            Assert.AreEqual("Completed", Status);
            Assert.IsNull(Table(first, "en").GetEntry("remove")); Assert.AreEqual("changed", Table(first, "en").GetEntry("keep").Value);
            Assert.IsNull(Get(window, "_previewPlans"));
        }

        [Test] public void DeletionWithinThresholdOnlyNeedsApply()
        {
            string Sheet(int count) => "Key,ko,en\n" + string.Concat(Enumerable.Range(0, count).Select(index => $"key{index},가,a\n"));
            Respond(Sheet(10)); Preview(); Apply(false); Assert.AreEqual("Completed", Status);
            Respond(Sheet(9)); Preview(); Apply(false);
            Assert.AreEqual("Completed", Status); Assert.IsNull(Table(first, "en").GetEntry("key9"));
        }

        [Test] public void ConfirmationIsNotCarriedIntoTheNextPreview()
        {
            Seeded(); Respond("Key,ko,en\nkeep,수정,changed\n"); Preview();
            Set(window, "_deletionConfirmed", true); Preview();
            Assert.IsFalse((bool)Get(window, "_deletionConfirmed"));
        }

        [Test] public void DiscardLeavesEveryAssetAndReturnsToReady()
        {
            Seeded(); var before = Files(directory);
            Respond("Key,ko,en\nkeep,수정,changed\n"); Preview(); Call(window, "DiscardPreview");
            Assert.AreEqual("Ready", Status); Assert.IsNull(Get(window, "_previewPlans")); SameFiles(before, directory);
        }

        [Test] public void ClosingTheWindowDropsThePreview()
        {
            Seeded(); Respond("Key,ko,en\nkeep,수정,changed\n"); Preview();
            Call(window, "OnDisable"); Assert.IsNull(Get(window, "_previewPlans"));
        }

        [Test] public void ApplyWithoutAPreviewChangesNothing()
        {
            Seeded(); var before = Files(directory);
            LogAssert.Expect(LogType.Error, new Regex("Preview the sheets"));
            Apply(true);
            Assert.AreEqual("Failed", Status); SameFiles(before, directory);
        }

        [Test] public void KeyAddedAfterPreviewBlocksApplyAndNeedsANewPreview()
        {
            Seeded(); Respond("Key,ko,en\nkeep,수정,changed\nremove,삭제,remove\n"); Preview();
            var collection = LocalizationEditorSettings.GetStringTableCollection(first);
            collection.SharedData.AddKey("added_after_preview"); EditorUtility.SetDirty(collection.SharedData); AssetDatabase.SaveAssetIfDirty(collection.SharedData);
            var before = Files(directory);
            LogAssert.Expect(LogType.Error, new Regex("changed after Preview"));
            Apply(true);
            Assert.AreEqual("Failed", Status); Assert.IsNull(Get(window, "_previewPlans")); SameFiles(before, directory);
            Assert.NotNull(collection.SharedData.GetEntry("added_after_preview")); Assert.IsFalse(File.Exists(Journal));
        }
    }
}
