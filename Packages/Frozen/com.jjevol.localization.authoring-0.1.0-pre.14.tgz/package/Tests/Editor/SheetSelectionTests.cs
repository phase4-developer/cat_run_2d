using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Localization.Authoring.Tests
{
    /// <summary>Which sheets are requested, and how. Preview writes no asset, but it parses through the import path, so this keeps the fixture Host guard.</summary>
    public class SheetSelectionTests
    {
        private const string Sheet = "Key,ko,en\nkeep,유지,keep\n";
        private const string Meta = "{\"sheets\":[{\"properties\":{\"sheetId\":0,\"title\":\"sheet_ui\"}},{\"properties\":{\"sheetId\":1234567890,\"title\":\"sheet shop\"}}]}";
        private GoogleSheetLocImporterWindow window;
        private List<string> downloads;
        private static void Set(object target, string field, object value) => target.GetType().GetField(field, BindingFlags.NonPublic | BindingFlags.Instance).SetValue(target, value);
        private static object Get(object target, string field) => target.GetType().GetField(field, BindingFlags.NonPublic | BindingFlags.Instance).GetValue(target);
        private static void Call(object target, string method) => target.GetType().GetMethod(method, BindingFlags.NonPublic | BindingFlags.Instance).Invoke(target, null);
        private string Status => (string)Get(window, "_importStatus");
        private IEnumerable<object> Fetched => ((IEnumerable)Get(window, "_fetchedSheets")).Cast<object>();
        private static string Title(object sheet) => (string)sheet.GetType().GetField("Title").GetValue(sheet);
        private static long Gid(object sheet) => (long)sheet.GetType().GetField("Gid").GetValue(sheet);
        private static bool Selected(object sheet) => (bool)sheet.GetType().GetField("Selected").GetValue(sheet);
        private void Tick(string title, bool selected) { var sheet = Fetched.Single(s => Title(s) == title); sheet.GetType().GetField("Selected").SetValue(sheet, selected); }
        private void Fetch() { Call(window, "TryFetchSheets"); Assert.AreEqual("Completed", Status); }
        private void Preview() => Call(window, "DownloadAndPreview");
        private int Plans => ((Array)Get(window, "_previewPlans"))?.Length ?? 0;

        [SetUp] public void Setup()
        {
            jjevol.Step24.Tests.ImportTestUtil.Guard();
            downloads = new List<string>();
            window = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            Set(window, "exportAsTsv", false);
            Set(window, "collectionSaveDir", "Assets/SheetSelectionFixture/Tables");
            Set(window, "outputFolder", "Assets/SheetSelectionFixture/Downloads");
            Set(window, "spreadsheetUrlOrId", "synthetic_spreadsheet_id_123456789");
            Set(window, "googleApiKey", "synthetic_key");
            Set(window, "manualSheets", "");
            // Synchronous responses let each operation finish inside its call.
            Set(window, "RequestText", new Func<string, int, CancellationToken, Task<string>>((url, timeout, token) =>
            {
                if (url.Contains("sheets.googleapis.com")) return Task.FromResult(Meta);
                downloads.Add(url); return Task.FromResult(Sheet);
            }));
        }
        [TearDown] public void Cleanup() { if (window) Object.DestroyImmediate(window); }

        [Test] public void FetchKeepsTitleAndGidAndSelectsEverySheet()
        {
            Fetch();
            CollectionAssert.AreEqual(new[] { "sheet_ui", "sheet shop" }, Fetched.Select(Title));
            CollectionAssert.AreEqual(new[] { 0L, 1234567890L }, Fetched.Select(Gid));
            Assert.IsTrue(Fetched.All(Selected));
        }
        [Test] public void FetchedSheetsAreDownloadedByGidIncludingTheFirstSheet()
        {
            Fetch(); Preview();
            Assert.AreEqual(2, downloads.Count);
            Assert.IsTrue(downloads.Any(url => url.EndsWith("&gid=0", StringComparison.Ordinal)), string.Join("\n", downloads));
            Assert.IsTrue(downloads.Any(url => url.EndsWith("&gid=1234567890", StringComparison.Ordinal)), string.Join("\n", downloads));
            Assert.IsTrue(downloads.All(url => url.Contains("/export?format=csv&gid=")), "The export endpoint, not gviz.");
            Assert.AreEqual(2, Plans);
        }
        [Test] public void AnUncheckedSheetIsNotDownloaded()
        {
            Fetch(); Tick("sheet shop", false); Preview();
            Assert.AreEqual(1, downloads.Count); StringAssert.EndsWith("&gid=0", downloads[0]);
            Assert.AreEqual(1, Plans);
        }
        [Test] public void ManualSheetsAreDownloadedByGidBesideCheckedSheets()
        {
            Fetch(); Tick("sheet shop", false); Set(window, "manualSheets", "manual_a=11, manual_b = 22");
            Preview();
            Assert.AreEqual(3, downloads.Count);
            Assert.AreEqual(1, downloads.Count(url => url.EndsWith("&gid=11", StringComparison.Ordinal)));
            Assert.AreEqual(1, downloads.Count(url => url.EndsWith("&gid=22", StringComparison.Ordinal)));
            Assert.AreEqual(1, downloads.Count(url => url.EndsWith("&gid=0", StringComparison.Ordinal)));
        }
        [Test] public void ManualSheetsWorkWithoutFetching()
        {
            Set(window, "manualSheets", "manual_a=7"); Preview();
            Assert.AreEqual(1, downloads.Count);
            Assert.AreEqual("https://docs.google.com/spreadsheets/d/synthetic_spreadsheet_id_123456789/export?format=csv&gid=7", downloads[0]);
        }
        [TestCase("manual_a")]
        [TestCase("manual_a=")]
        [TestCase("=7")]
        [TestCase("manual_a=-1")]
        [TestCase("manual_a=seven")]
        public void AManualSheetWithoutAGidIsRejected(string manual)
        {
            Set(window, "manualSheets", manual);
            LogAssert.Expect(LogType.Error, new Regex("Manual sheets are Name=gid"));
            Preview();
            Assert.AreEqual("Failed", Status); Assert.AreEqual(0, downloads.Count);
        }
        [Test] public void ASheetThatIsCheckedAndTypedIsDownloadedOnceByGid()
        {
            Fetch(); Tick("sheet shop", false); Set(window, "manualSheets", "sheet_ui=99");
            Preview();
            Assert.AreEqual(1, downloads.Count); StringAssert.EndsWith("&gid=0", downloads[0]);
        }
        [Test] public void NothingCheckedAndNoManualNameRequestsNothing()
        {
            Fetch(); Tick("sheet_ui", false); Tick("sheet shop", false);
            LogAssert.Expect(LogType.Error, new Regex("Select at least one sheet"));
            Preview();
            Assert.AreEqual("Failed", Status); Assert.AreEqual(0, downloads.Count); Assert.IsNull(Get(window, "_previewPlans"));
        }
        [Test] public void AGidIsNotUsedAgainstAnotherSpreadsheet()
        {
            Fetch(); Set(window, "spreadsheetUrlOrId", "another_spreadsheet_id_123456789");
            LogAssert.Expect(LogType.Error, new Regex("Fetch the sheet list again"));
            Preview();
            Assert.AreEqual("Failed", Status); Assert.AreEqual(0, downloads.Count);
        }
    }
}
