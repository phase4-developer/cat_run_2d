using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Localization;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Localization.Authoring.Tests
{
    // Select the exact methods in separate Editor processes; never claim a same-process repeat is a restart.
    public class RecoveryRestartProofTests
    {
        [Serializable] private sealed class BeforeFile { public string path, data; }
        [Serializable] private sealed class Proof
        {
            public int processId;
            public string directory, collection;
            public long id;
            public bool completed;
            public List<BeforeFile> files;
        }
        private static string ProofPath => Path.GetFullPath("Library/JJEvol/LocalizationImport/restart-proof.json");
        private static Type Transaction => typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationImportTransaction", true);
        private static string Journal => (string)Transaction.GetProperty("JournalPath", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);
        private static void Set(object target, string field, object value) => target.GetType().GetField(field, BindingFlags.NonPublic | BindingFlags.Instance).SetValue(target, value);
        private static object Call(object target, string method, params object[] values)
        {
            try { return target.GetType().GetMethod(method, BindingFlags.NonPublic | BindingFlags.Instance).Invoke(target, values); }
            catch (TargetInvocationException error) { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
        }
        private static GoogleSheetLocImporterWindow Window(Proof proof)
        {
            var window = jjevol.Step24.Tests.ImportTestUtil.Window(proof.directory);
            Set(window, "outputFolder", proof.directory + "/Downloads");
            Set(window, "spreadsheetUrlOrId", "synthetic_restart_spreadsheet_id");
            Set(window, "manualSheets", proof.collection + "=0"); Set(window, "exportAsTsv", false);
            return window;
        }

        [Test, Explicit("Run this exact method, then restart the Editor before running the recovery method.")]
        public void CreatePendingImport()
        {
            jjevol.Step24.Tests.ImportTestUtil.Guard();
            Assert.IsFalse(File.Exists(Journal)); Assert.IsFalse(File.Exists(ProofPath));
            string id = Guid.NewGuid().ToString("N");
            var proof = new Proof { processId = Process.GetCurrentProcess().Id, directory = "Assets/Ae1Restart_" + id, collection = "ae1_restart_" + id };
            var window = Window(proof);
            try
            {
                jjevol.Step24.Tests.ImportTestUtil.Import(window, proof.directory, proof.collection, "Key,ko,en\nkeep,기존,original\n");
                proof.id = (LocalizationEditorSettings.GetStringTableCollection(proof.collection).GetTable(new LocaleIdentifier("en")) as StringTable).GetEntry("keep").KeyId;
                // Materialize Unity's own input meta before capturing the cross-process baseline.
                AssetDatabase.ImportAsset(proof.directory + "/Input.csv", ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
                Assert.IsTrue(File.Exists(proof.directory + "/Input.csv.meta"));
                Assert.IsFalse(File.Exists(Journal));
                proof.files = Directory.GetFiles(proof.directory, "*", SearchOption.AllDirectories)
                    .Select(path => new BeforeFile { path = path.Replace('\\', '/'), data = Convert.ToBase64String(File.ReadAllBytes(path)) }).ToList();
                Set(window, "RequestText", new Func<string, int, CancellationToken, Task<string>>((url, timeout, token) => Task.FromResult("Key,ko,en\nkeep,변경,changed\n")));
                Set(window, "ImportFault", new Action<string>(point => { if (point == "BeforeCommit" || point == "BeforeRollback") throw new IOException("Synthetic restart boundary"); }));
                LogAssert.Expect(LogType.Error, new Regex("RecoveryRequired"));
                Call(window, "DownloadAndPreview");
                Call(window, "ApplyPreview", false);
                Assert.IsTrue(File.Exists(Journal));
                Assert.IsTrue(Directory.GetFiles(proof.directory + "/Downloads").Length > 0, "A newly created download must be included in persisted recovery.");
                File.WriteAllText(ProofPath, JsonUtility.ToJson(proof));
            }
            finally { Object.DestroyImmediate(window); }
        }

        [Test, Explicit("Run only after CreatePendingImport in a different Editor process.")]
        public void RecoverPendingImportAfterEditorRestart()
        {
            jjevol.Step24.Tests.ImportTestUtil.Guard();
            var proof = JsonUtility.FromJson<Proof>(File.ReadAllText(ProofPath));
            Assert.AreNotEqual(proof.processId, Process.GetCurrentProcess().Id, "This proof requires an actual Editor restart.");
            Assert.IsFalse(proof.completed); Assert.IsTrue(File.Exists(Journal));
            Assert.IsTrue((bool)Transaction.GetMethod("Recover", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, null));
            var actual = Directory.GetFiles(proof.directory, "*", SearchOption.AllDirectories).Select(path => path.Replace('\\', '/')).ToArray();
            CollectionAssert.AreEquivalent(proof.files.Select(file => file.path), actual);
            foreach (var file in proof.files) CollectionAssert.AreEqual(Convert.FromBase64String(file.data), File.ReadAllBytes(file.path), file.path);
            var table = LocalizationEditorSettings.GetStringTableCollection(proof.collection).GetTable(new LocaleIdentifier("en")) as StringTable;
            Assert.AreEqual(proof.id, table.GetEntry("keep").KeyId); Assert.AreEqual("original", table.GetEntry("keep").Value);
            var window = Window(proof);
            try
            {
                jjevol.Step24.Tests.ImportTestUtil.Import(window, proof.directory, proof.collection, "Key,ko,en\nkeep,재시도,retry\n");
                Assert.AreEqual(proof.id, table.GetEntry("keep").KeyId); Assert.AreEqual("retry", table.GetEntry("keep").Value);
                Assert.IsFalse(File.Exists(Journal));
                proof.completed = true; File.WriteAllText(ProofPath, JsonUtility.ToJson(proof));
            }
            finally { Object.DestroyImmediate(window); }
        }
    }
}
