using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEditor.Localization;
using UnityEditor.Localization.Addressables;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Localization.Authoring.Tests
{
    public class ImportTransactionTests
    {
        private GoogleSheetLocImporterWindow window;
        private string directory, first, second;
        private jjevol.Step24.Tests.HostResidue residue;
        private static Type Transaction => typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationImportTransaction", true);
        private static string Journal => (string)Transaction.GetProperty("JournalPath", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);
        private static bool Recover() => (bool)Transaction.GetMethod("Recover", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, null);
        private const string Seed = "Key,ko,en\nkeep,기존,original\nremove,삭제,remove\n";
        private const string Changed = "Key,ko,en\nkeep,수정,changed\nnew,추가,new\n";
        private static void Set(object target, string field, object value) => target.GetType().GetField(field, BindingFlags.NonPublic | BindingFlags.Instance).SetValue(target, value);
        private static object Get(object target, string field) => target.GetType().GetField(field, BindingFlags.NonPublic | BindingFlags.Instance).GetValue(target);
        private static object Call(object target, string method, params object[] values)
        {
            try { return target.GetType().GetMethod(method, BindingFlags.NonPublic | BindingFlags.Instance).Invoke(target, values); }
            catch (TargetInvocationException error) { System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
        }
        private static Dictionary<string, byte[]> Files(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path.Replace('\\', '/'), File.ReadAllBytes);
        private static void SameFiles(Dictionary<string, byte[]> expected, string root)
        {
            var actual = Files(root);
            CollectionAssert.AreEquivalent(expected.Keys, actual.Keys);
            foreach (var pair in expected) CollectionAssert.AreEqual(pair.Value, actual[pair.Key], pair.Key);
        }
        private static StringTable Table(string name, string locale) => LocalizationEditorSettings.GetStringTableCollection(name).GetTable(new LocaleIdentifier(locale)) as StringTable;

        [SetUp] public void Setup()
        {
            jjevol.Step24.Tests.ImportTestUtil.Guard();
            Assert.IsFalse(File.Exists(Journal), "A previous unresolved import must not be overwritten by tests.");
            string id = Guid.NewGuid().ToString("N");
            directory = "Assets/Ae1LocalizationFixtures/" + id; residue = new jjevol.Step24.Tests.HostResidue(directory);
            first = "ae1_a_" + id; second = "ae1_b_" + id;
            Directory.CreateDirectory(directory + "/Tables"); AssetDatabase.Refresh();
            window = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            Set(window, "collectionSaveDir", directory + "/Tables");
            Set(window, "outputFolder", directory + "/Downloads");
            Set(window, "exportAsTsv", false);
            Set(window, "spreadsheetUrlOrId", "synthetic_spreadsheet_id_123456789");
            Set(window, "googleApiKey", string.Empty);
            Set(window, "manualSheets", first + "=0," + second + "=1");
        }
        [TearDown] public void Cleanup()
        {
            if (window) { Set(window, "ImportFault", null); Object.DestroyImmediate(window); }
            Assert.IsTrue(Recover(), "Leave uncertain evidence intact instead of deleting the recovery marker.");
            residue?.Clean();
        }
        private void Apply(string a = Changed, string b = Changed, CancellationToken cancellation = default)
        {
            var planType = typeof(GoogleSheetLocImporterWindow).GetNestedType("ImportPlan", BindingFlags.NonPublic);
            Array plans = Array.CreateInstance(planType, 2);
            plans.SetValue(Call(window, "PrepareImport", a, first, false), 0);
            plans.SetValue(Call(window, "PrepareImport", b, second, false), 1);
            Call(window, "ApplyPrepared", plans, cancellation);
        }
        private void SeedBoth() => Apply(Seed, Seed);
        private void ApplySingle(string name, string content)
        {
            var type = typeof(GoogleSheetLocImporterWindow).GetNestedType("ImportPlan", BindingFlags.NonPublic);
            Array plans = Array.CreateInstance(type, 1);
            plans.SetValue(Call(window, "PrepareImport", content, name, false), 0);
            Call(window, "ApplyPrepared", plans, CancellationToken.None);
        }
        private Task Download() { Call(window, "DownloadAndPreview"); return ApplyAfterPreview((Task)Get(window, "_activeRequest")); }
        private async Task ApplyAfterPreview(Task preview)
        {
            await preview;
            if (Get(window, "_previewPlans") == null) return;
            Call(window, "ApplyPreview", true);
            await (Task)Get(window, "_activeRequest");
        }
        private void Respond(Func<string, Task<string>> response)
            => Set(window, "RequestText", new Func<string, int, CancellationToken, Task<string>>((url, timeout, token) => response(url)));

        [Test] public void EveryCollectionAndLocaleIsVerifiedAndReimportPreservesIdsAndGuids()
        {
            SeedBoth();
            foreach (string name in new[] { first, second })
            {
                var collection = LocalizationEditorSettings.GetStringTableCollection(name);
                Assert.IsFalse(EditorUtility.IsDirty(collection), "The completed request must persist its own collection connection update.");
                Assert.IsFalse(EditorUtility.IsDirty(collection.SharedData));
                foreach (var table in collection.StringTables) Assert.IsFalse(EditorUtility.IsDirty(table));
            }
            long aId = Table(first, "en").GetEntry("keep").KeyId, bId = Table(second, "en").GetEntry("keep").KeyId;
            string aGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Table(first, "en")));
            Apply("Key,ko,en,ja\nkeep,수정,changed,変更\n", "Key,ko,en,ja\nkeep,수정,changed,変更\n");
            Assert.AreEqual(aId, Table(first, "en").GetEntry("keep").KeyId);
            Assert.AreEqual(bId, Table(second, "en").GetEntry("keep").KeyId);
            Assert.AreEqual(aGuid, AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Table(first, "en"))));
            Assert.AreEqual("変更", Table(second, "ja").GetEntry("keep").Value);
            Assert.IsNull(Table(first, "en").GetEntry("remove"));
            Assert.IsFalse(EditorUtility.IsDirty(LocalizationEditorSettings.GetStringTableCollection(first)));
            Assert.IsFalse(EditorUtility.IsDirty(LocalizationEditorSettings.GetStringTableCollection(second)));
            Assert.IsFalse(File.Exists(Journal));
        }

        [Test] public void MalformedLaterInputLeavesEveryCollectionAndOutputUntouched()
        {
            SeedBoth(); var before = Files(directory);
            Assert.Throws<FormatException>(() => Apply(Changed, "Key,ko,en,ja\nkeep,valid,valid,\"unfinished\n"));
            SameFiles(before, directory); Assert.IsFalse(File.Exists(Journal));
        }

        [Test] public void ExactCaseKeysHaveIndependentIdsAndCaseOnlyReplacementRemovesStaleKey()
        {
            const string initial = "Key,ko,en\nTitle,제목,Title\ntitle,소문자,lower\n";
            Apply(initial, initial);
            var shared = LocalizationEditorSettings.GetStringTableCollection(first).SharedData;
            long upper = shared.GetEntry("Title").Id, lower = shared.GetEntry("title").Id;
            Assert.AreNotEqual(upper, lower);
            Apply("Key,ko,en\ntitle,변경,changed\n", "Key,ko,en\nTitle,유지,Title\n");
            Assert.IsNull(shared.GetEntry("Title"));
            Assert.AreEqual(lower, shared.GetEntry("title").Id);
            Assert.AreEqual(1, shared.Entries.Count);
            Assert.IsNull(Table(first, "en").GetEntry(upper));
            Assert.AreEqual("changed", Table(first, "en").GetEntry(lower).Value);
        }

        [Test] public void SdkAddNewTableThrowingAfterCreationRestoresEarlierCollectionsAndNewAssets()
        {
            SeedBoth(); var before = Files(directory);
            var config = Files(AddressableAssetSettingsDefaultObject.Settings.ConfigFolder);
            Set(window, "AddTableForImport", new Func<StringTableCollection, LocaleIdentifier, StringTable>((collection, locale) =>
            {
                var table = collection.AddNewTable(locale) as StringTable;
                if (collection.TableCollectionName == second && locale.Code == "ja") throw new IOException("Synthetic SDK failure after AddNewTable");
                return table;
            }));
            Assert.Throws<IOException>(() => Apply(Changed, "Key,ko,en,ja\nkeep,수정,changed,変更\n"));
            SameFiles(before, directory); SameFiles(config, AddressableAssetSettingsDefaultObject.Settings.ConfigFolder);
            Assert.AreEqual("original", Table(first, "en").GetEntry("keep").Value);
            Assert.IsNull(Table(second, "ja")); Assert.IsFalse(File.Exists(Journal));
        }

        [TestCase("BeforeValue:")]
        [TestCase("BeforeAddressables:")]
        [TestCase("BeforeSave:")]
        [TestCase("BeforeCommit")]
        public void MutationSaveAndAddressablesFailuresNeverLeavePartialCollections(string boundary)
        {
            SeedBoth(); var before = Files(directory);
            var config = Files(AddressableAssetSettingsDefaultObject.Settings.ConfigFolder);
            Set(window, "ImportFault", new Action<string>(point =>
            {
                bool hit = boundary == "BeforeValue:" || boundary == "BeforeAddressables:" ? point.StartsWith(boundary + second + ":", StringComparison.Ordinal) || point == boundary + second : point.StartsWith(boundary, StringComparison.Ordinal);
                if (hit) throw new IOException("Synthetic import failure at " + boundary);
            }));
            Assert.Throws<IOException>(() => Apply());
            SameFiles(before, directory); SameFiles(config, AddressableAssetSettingsDefaultObject.Settings.ConfigFolder);
            Assert.IsFalse(File.Exists(Journal));
        }

        [Test] public void ActualAddressablesConnectionLossFailsVerificationAndRestoresOriginalEntries()
        {
            SeedBoth(); var before = Files(directory);
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Table(second, "en")));
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point == "AfterAddressables:" + second) AddressableAssetSettingsDefaultObject.Settings.RemoveAssetEntry(guid);
            }));
            Assert.Throws<InvalidDataException>(() => Apply());
            SameFiles(before, directory);
            Assert.NotNull(AddressableAssetSettingsDefaultObject.Settings.FindAssetEntry(guid));
        }

        [Test] public void CancellationAfterMutationRollsBackAllRequestedCollections()
        {
            SeedBoth(); var before = Files(directory);
            using var cancellation = new CancellationTokenSource();
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point.StartsWith("BeforeValue:" + second, StringComparison.Ordinal)) cancellation.Cancel();
            }));
            Assert.Throws<OperationCanceledException>(() => Apply(cancellation: cancellation.Token));
            SameFiles(before, directory); Assert.IsFalse(File.Exists(Journal));
        }

        [Test] public void UncertainRecoveryBlocksRetryAndExplicitRecoveryUsesPersistedBytes()
        {
            SeedBoth(); var before = Files(directory);
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point == "BeforeCommit" || point == "BeforeRollback") throw new IOException("Synthetic failure");
            }));
            var failure = Assert.Throws<InvalidOperationException>(() => Apply());
            StringAssert.Contains("RecoveryRequired", failure.Message);
            Assert.IsTrue(File.Exists(Journal));
            Assert.Throws<InvalidOperationException>(() => Apply());
            Set(window, "ImportFault", null);
            Assert.IsTrue(Recover()); SameFiles(before, directory);
            Apply(); Assert.AreEqual("changed", Table(second, "en").GetEntry("keep").Value);
        }

        [Test] public void ForeignDiskChangeDuringRecoveryIsPreservedUntilOwnerRestoresIt()
        {
            SeedBoth(); var before = Files(directory);
            string path = AssetDatabase.GetAssetPath(Table(first, "en"));
            byte[] candidate = null;
            byte[] foreign = System.Text.Encoding.UTF8.GetBytes("synthetic external owner bytes");
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point == "BeforeCommit") throw new IOException("Synthetic apply failure");
                if (point == "BeforeRollback") { candidate = File.ReadAllBytes(path); File.WriteAllBytes(path, foreign); }
            }));
            Assert.Throws<InvalidOperationException>(() => Apply());
            CollectionAssert.AreEqual(foreign, File.ReadAllBytes(path));
            Assert.IsFalse(Recover());
            File.WriteAllBytes(path, candidate);
            Set(window, "ImportFault", null);
            Assert.IsTrue(Recover()); SameFiles(before, directory);
        }

        [Test] public void ManualRecoveryPreservesSubsequentUnsavedInspectorEdit()
        {
            SeedBoth(); var before = Files(directory);
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point == "BeforeCommit" || point == "BeforeRollback") throw new IOException("Synthetic failure");
            }));
            Assert.Throws<InvalidOperationException>(() => Apply());
            var table = Table(first, "en"); string candidate = table.GetEntry("keep").Value;
            table.GetEntry("keep").Value = "synthetic unsaved user edit"; EditorUtility.SetDirty(table);
            Assert.IsFalse(Recover());
            Assert.AreEqual("synthetic unsaved user edit", table.GetEntry("keep").Value);
            Assert.IsTrue(EditorUtility.IsDirty(table)); Assert.IsTrue(File.Exists(Journal));
            table.GetEntry("keep").Value = candidate; Set(window, "ImportFault", null);
            Assert.IsTrue(Recover()); SameFiles(before, directory);
        }

        [Test] public void UnrelatedDirtyAssetIsNeitherSavedNorChanged()
        {
            SeedBoth();
            var unrelated = ScriptableObject.CreateInstance<Locale>(); unrelated.Identifier = new LocaleIdentifier("de");
            string path = directory + "/unrelated.asset"; AssetDatabase.CreateAsset(unrelated, path);
            byte[] before = File.ReadAllBytes(path);
            unrelated.name = "unsaved synthetic edit"; EditorUtility.SetDirty(unrelated);
            Apply();
            Assert.IsTrue(EditorUtility.IsDirty(unrelated)); Assert.AreEqual("unsaved synthetic edit", unrelated.name);
            CollectionAssert.AreEqual(before, File.ReadAllBytes(path));
        }

        [Test] public void SdkGlobalSaveDuringNewSchemaCreationCannotSaveUnrelatedDirtyAsset()
        {
            var unrelated = ScriptableObject.CreateInstance<Locale>(); unrelated.Identifier = new LocaleIdentifier("de");
            string path = directory + "/unrelated.asset"; AssetDatabase.CreateAsset(unrelated, path);
            byte[] before = File.ReadAllBytes(path);
            unrelated.name = "unsaved user data"; EditorUtility.SetDirty(unrelated);
            var rules = AddressableGroupRules.Instance; var previous = rules.StringTablesResolver;
            string unique = "Ae1SaveGuard_" + Guid.NewGuid().ToString("N");
            try
            {
                rules.StringTablesResolver = new GroupResolver(unique + "_{Identifier.Code}", unique + "_Shared");
                Apply();
                Assert.IsTrue(AddressableAssetSettingsDefaultObject.Settings.groups.Any(group => group && group.Name.StartsWith(unique, StringComparison.Ordinal)));
                Assert.IsTrue(EditorUtility.IsDirty(unrelated));
                CollectionAssert.AreEqual(before, File.ReadAllBytes(path));
            }
            finally { rules.StringTablesResolver = previous; }
        }

        [TestCase(".asset")]
        [TestCase(" Shared Data.asset")]
        public void UnownedAssetAtNewCollectionSdkPathIsPreserved(string suffix)
        {
            var unrelated = ScriptableObject.CreateInstance<Locale>(); unrelated.Identifier = new LocaleIdentifier("de");
            string path = directory + "/Tables/" + first + suffix;
            AssetDatabase.CreateAsset(unrelated, path);
            byte[] before = File.ReadAllBytes(path), meta = File.ReadAllBytes(path + ".meta");
            Assert.Throws<InvalidDataException>(() => Apply());
            CollectionAssert.AreEqual(before, File.ReadAllBytes(path)); CollectionAssert.AreEqual(meta, File.ReadAllBytes(path + ".meta"));
            Assert.IsFalse(File.Exists(Journal)); Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(first));
        }

        [Test] public void UnownedAssetAtAdditionalLocaleSdkPathIsNeverAdoptedOrOverwritten()
        {
            SeedBoth(); var unrelated = ScriptableObject.CreateInstance<Locale>(); unrelated.Identifier = new LocaleIdentifier("de");
            string path = directory + "/Tables/" + second + "_ja.asset"; AssetDatabase.CreateAsset(unrelated, path);
            var before = Files(directory);
            Assert.Throws<InvalidDataException>(() => Apply(Changed, "Key,ko,en,ja\nkeep,가,a,あ\n"));
            SameFiles(before, directory); Assert.IsFalse(File.Exists(Journal));
        }

        [Test] public void UnrelatedNewGroupFromSdkCallbackSurvivesAndRequiresOwnershipReview()
        {
            SeedBoth();
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            AddressableAssetGroup unrelated = null;
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point == "BeforeAddressables:" + second)
                {
                    unrelated = settings.CreateGroup("synthetic_external_" + Guid.NewGuid().ToString("N"), false, false, false, null);
                    throw new IOException("Synthetic external callback then import failure");
                }
            }));
            Assert.Throws<InvalidOperationException>(() => Apply());
            string path = AssetDatabase.GetAssetPath(unrelated), guid = AssetDatabase.AssetPathToGUID(path);
            Assert.IsTrue(File.Exists(path)); Assert.IsTrue(settings.groups.Contains(unrelated));
            Assert.IsFalse(Recover()); Assert.AreEqual(guid, AssetDatabase.AssetPathToGUID(path));
            // The simulated external owner removes its own group before allowing explicit recovery.
            settings.RemoveGroup(unrelated);
            Set(window, "ImportFault", null);
            Assert.IsTrue(Recover());
        }

        [TestCase(".asset")]
        [TestCase(" Shared Data.asset")]
        [TestCase("_en.asset")]
        public void LateSdkAssetCollisionCreatedByEarlierCollectionCallbackIsPreserved(string suffix)
        {
            string path = directory + "/Tables/" + second + suffix;
            byte[] bytes = null, meta = null;
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point != "BeforeAddressables:" + first) return;
                var external = new Texture2D(2, 2) { name = "synthetic external collision" };
                AssetDatabase.CreateAsset(external, path);
                bytes = File.ReadAllBytes(path); meta = File.ReadAllBytes(path + ".meta");
            }));
            Assert.Throws<InvalidDataException>(() => Apply());
            CollectionAssert.AreEqual(bytes, File.ReadAllBytes(path)); CollectionAssert.AreEqual(meta, File.ReadAllBytes(path + ".meta"));
            Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(first));
            Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(second));
            Assert.IsFalse(File.Exists(Journal));
        }

        [Test] public void ExternalLocalePostprocessorConnectionIsPreservedAsRecoveryRequired()
        {
            SeedBoth(); var before = Files(directory);
            string path = directory + "/external-locale.asset";
            Locale external = null; byte[] bytes = null, meta = null;
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point != "BeforeAddressables:" + second) return;
                external = ScriptableObject.CreateInstance<Locale>(); external.Identifier = new LocaleIdentifier("de");
                AssetDatabase.CreateAsset(external, path);
                bytes = File.ReadAllBytes(path); meta = File.ReadAllBytes(path + ".meta");
            }));
            Assert.Throws<InvalidOperationException>(() => Apply());
            Assert.IsTrue(File.Exists(Journal));
            CollectionAssert.AreEqual(bytes, File.ReadAllBytes(path)); CollectionAssert.AreEqual(meta, File.ReadAllBytes(path + ".meta"));
            Assert.IsTrue(LocalizationEditorSettings.GetLocales().Contains(external));
            Assert.IsFalse(Recover());
            Assert.IsTrue(LocalizationEditorSettings.GetLocales().Contains(external));
            // Only the simulated external owner withdraws its new Locale and asset.
            LocalizationEditorSettings.RemoveLocale(external); AssetDatabase.DeleteAsset(path);
            Set(window, "ImportFault", null);
            Assert.IsTrue(Recover()); SameFiles(before, directory);
        }

        private static void ConfigBoolean(Object target, bool schema, bool value)
        {
            var serialized = new SerializedObject(target); serialized.Update();
            serialized.FindProperty(schema ? "m_UseAssetBundleCache" : "m_ReadOnly").boolValue = value;
            serialized.ApplyModifiedPropertiesWithoutUndo(); EditorUtility.SetDirty(target);
        }
        private static bool ConfigBoolean(Object target, bool schema)
        {
            var serialized = new SerializedObject(target);
            return serialized.FindProperty(schema ? "m_UseAssetBundleCache" : "m_ReadOnly").boolValue;
        }
        private static AddressableAssetGroup UnrelatedGroup()
        {
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            var group = settings.CreateGroup("synthetic_unrelated_config_" + Guid.NewGuid().ToString("N"), false, false, false, null, typeof(BundledAssetGroupSchema));
            foreach (var schema in group.Schemas) AssetDatabase.SaveAssetIfDirty(schema);
            AssetDatabase.SaveAssetIfDirty(group); AssetDatabase.SaveAssetIfDirty(settings);
            return group;
        }

        [TestCase(false)]
        [TestCase(true)]
        public void CallbackEditToExistingUnrelatedGroupOrSchemaIsNotSavedOrOverwritten(bool schema)
        {
            var group = UnrelatedGroup(); SeedBoth();
            Object target = schema ? (Object)group.GetSchema<BundledAssetGroupSchema>() : group;
            bool original = ConfigBoolean(target, schema); string path = AssetDatabase.GetAssetPath(target);
            byte[] before = File.ReadAllBytes(path);
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point == "BeforeAddressables:" + second) ConfigBoolean(target, schema, !original);
            }));
            Assert.Throws<InvalidOperationException>(() => Apply());
            Assert.AreEqual(!original, ConfigBoolean(target, schema)); Assert.IsTrue(EditorUtility.IsDirty(target));
            CollectionAssert.AreEqual(before, File.ReadAllBytes(path)); Assert.IsFalse(Recover());
            ConfigBoolean(target, schema, original); EditorUtility.ClearDirty(target);
            Set(window, "ImportFault", null); Assert.IsTrue(Recover());
            AddressableAssetSettingsDefaultObject.Settings.RemoveGroup(group);
        }

        [TestCase(false)]
        [TestCase(true)]
        public void ExistingUnrelatedDirtyConfigurationRemainsUnsavedOnSuccessfulImport(bool schema)
        {
            var group = UnrelatedGroup();
            Object target = schema ? (Object)group.GetSchema<BundledAssetGroupSchema>() : group;
            bool original = ConfigBoolean(target, schema); string path = AssetDatabase.GetAssetPath(target);
            byte[] before = File.ReadAllBytes(path);
            try
            {
                ConfigBoolean(target, schema, !original);
                Apply();
                Assert.AreEqual(!original, ConfigBoolean(target, schema)); Assert.IsTrue(EditorUtility.IsDirty(target));
                CollectionAssert.AreEqual(before, File.ReadAllBytes(path));
            }
            finally
            {
                ConfigBoolean(target, schema, original); EditorUtility.ClearDirty(target);
                AddressableAssetSettingsDefaultObject.Settings.RemoveGroup(group);
            }
        }

        [Test] public void DirtyRequiredTableGroupCannotCompleteNewConnectionsAndKeepsUserEdits()
        {
            SeedBoth();
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            string tableGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Table(first, "en")));
            var group = settings.FindAssetEntry(tableGuid).parentGroup;
            bool original = ConfigBoolean(group, false);
            string path = AssetDatabase.GetAssetPath(group); byte[] bytes = File.ReadAllBytes(path);
            ConfigBoolean(group, false, !original);
            string unsaved = EditorJsonUtility.ToJson(group);
            string added = "ae1_new_" + Guid.NewGuid().ToString("N");
            try
            {
                Assert.Throws<IOException>(() => ApplySingle(added, Changed));
                Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(added));
                Assert.AreEqual(unsaved, EditorJsonUtility.ToJson(group));
                Assert.IsTrue(EditorUtility.IsDirty(group)); CollectionAssert.AreEqual(bytes, File.ReadAllBytes(path));
                Assert.IsFalse(File.Exists(Journal), "This known entry-only rollback must restore the original unsaved group state.");
            }
            finally { ConfigBoolean(group, false, original); EditorUtility.ClearDirty(group); }
        }

        [TestCase("collection", false)]
        [TestCase("group", false)]
        [TestCase("settings", false)]
        [TestCase("collection", true)]
        [TestCase("group", true)]
        [TestCase("settings", true)]
        public void RequiredSerializedSaveMustBeProvenOnDisk(string kind, bool readOnly)
        {
            SeedBoth();
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            Object target = kind == "collection" ? (Object)LocalizationEditorSettings.GetStringTableCollection(first)
                : kind == "group" ? settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(Table(first, "en")))).parentGroup : settings;
            string path = AssetDatabase.GetAssetPath(target);
            byte[] original = File.ReadAllBytes(path), originalMeta = File.ReadAllBytes(path + ".meta");
            var before = Files(directory); FileAttributes attributes = File.GetAttributes(path);
            var rules = AddressableGroupRules.Instance; var previous = rules.StringTablesResolver;
            if (kind == "settings")
            {
                string name = "Ae1SaveProof_" + Guid.NewGuid().ToString("N");
                rules.StringTablesResolver = new GroupResolver(name + "_{Identifier.Code}", name + "_Shared");
            }
            bool reached = false;
            int oldCount = target is AddressableAssetGroup group ? group.entries.Count : settings.groups.Count;
            try
            {
                Set(window, "ImportFault", new Action<string>(point =>
                {
                    if (point != "BeforeSave:" + path) return;
                    reached = true;
                    if (kind == "collection") Assert.AreEqual(3, ((StringTableCollection)target).StringTables.Count, "The candidate must add a required table reference.");
                    else if (kind == "group") Assert.Greater(((AddressableAssetGroup)target).entries.Count, oldCount);
                    else Assert.Greater(settings.groups.Count, oldCount, "The candidate must add a required group reference.");
                    if (readOnly) File.SetAttributes(path, attributes | FileAttributes.ReadOnly);
                }));
                if (!readOnly)
                    Set(window, "SaveAssetForImport", new Action<Object>(asset =>
                    {
                        // Restore this test asset's pre-change bytes at the exact native save boundary.
                        // Earlier SDK global saves may already have persisted the candidate.
                        // The verification must read these stale bytes rather than a dirty live cache.
                        if (AssetDatabase.GetAssetPath(asset) == path) File.WriteAllBytes(path, original);
                        else AssetDatabase.SaveAssetIfDirty(asset);
                    }));
                Exception failure = Assert.Catch<Exception>(() =>
                {
                    if (kind == "collection") Apply("Key,ko,en,ja\nkeep,수정,changed,変更\n", Changed);
                    else ApplySingle("ae1_save_proof_" + Guid.NewGuid().ToString("N"), Changed);
                });
                Assert.IsTrue(reached, "The required save boundary was not exercised. Caught: " + failure);
                Assert.IsTrue(failure is IOException || failure is InvalidOperationException && File.Exists(Journal),
                    "Only an honest save/refusal or RecoveryRequired failure is expected: " + failure);
            }
            finally
            {
                File.SetAttributes(path, attributes);
                rules.StringTablesResolver = previous;
                Set(window, "ImportFault", null);
                Set(window, "SaveAssetForImport", new Action<Object>(AssetDatabase.SaveAssetIfDirty));
            }
            Assert.IsTrue(Recover()); SameFiles(before, directory);
            CollectionAssert.AreEqual(original, File.ReadAllBytes(path));
            CollectionAssert.AreEqual(originalMeta, File.ReadAllBytes(path + ".meta"));
            Assert.AreEqual("original", Table(first, "en").GetEntry("keep").Value);
        }

        [Test] public void DirtyCollectionMemoryCannotStandInForUnchangedDisk()
        {
            SeedBoth();
            var collection = LocalizationEditorSettings.GetStringTableCollection(first);
            string path = AssetDatabase.GetAssetPath(collection), oldGroup = collection.Group;
            string unsavedGroup = "ae1_memory_only_" + Guid.NewGuid().ToString("N");
            byte[] original = File.ReadAllBytes(path), originalMeta = File.ReadAllBytes(path + ".meta");
            var before = Files(directory); bool reached = false, skipped = false;
            try
            {
                Set(window, "ImportFault", new Action<string>(point =>
                {
                    if (point != "BeforeSave:" + path) return;
                    reached = true;
                    CollectionAssert.AreEqual(original, File.ReadAllBytes(path), "The synthetic Group must start from unchanged disk bytes.");
                    collection.Group = unsavedGroup; EditorUtility.SetDirty(collection);
                    Assert.IsFalse(System.Text.Encoding.UTF8.GetString(File.ReadAllBytes(path)).Contains(unsavedGroup));
                }));
                Set(window, "SaveAssetForImport", new Action<Object>(asset =>
                {
                    if (AssetDatabase.GetAssetPath(asset) != path) { AssetDatabase.SaveAssetIfDirty(asset); return; }
                    skipped = true;
                    Assert.AreEqual(unsavedGroup, ((StringTableCollection)asset).Group);
                    CollectionAssert.AreEqual(original, File.ReadAllBytes(path), "Skipping a save must not change disk or its import artifact.");
                }));
                Exception failure = Assert.Catch<Exception>(() => Apply());
                Assert.IsTrue(reached && skipped, "Both the memory-only mutation and skipped save must execute. Caught: " + failure);
                Assert.IsTrue(failure is IOException || failure is InvalidOperationException && File.Exists(Journal),
                    "Only an honest persisted-state refusal or RecoveryRequired failure is expected: " + failure);
            }
            finally
            {
                Set(window, "ImportFault", null);
                Set(window, "SaveAssetForImport", new Action<Object>(AssetDatabase.SaveAssetIfDirty));
            }
            Assert.IsTrue(Recover()); SameFiles(before, directory);
            Assert.AreEqual(oldGroup, LocalizationEditorSettings.GetStringTableCollection(first).Group);
            CollectionAssert.AreEqual(original, File.ReadAllBytes(path));
            CollectionAssert.AreEqual(originalMeta, File.ReadAllBytes(path + ".meta"));
            Assert.AreEqual("original", Table(first, "en").GetEntry("keep").Value);
        }
        [Test] public void ForeignAddressableSettingsScalarIsNotSavedOrOverwritten()
        {
            SeedBoth();
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            bool original = settings.BuildRemoteCatalog; string path = AssetDatabase.GetAssetPath(settings);
            byte[] before = File.ReadAllBytes(path);
            Set(window, "ImportFault", new Action<string>(point =>
            {
                if (point == "BeforeAddressables:" + second)
                {
                    settings.BuildRemoteCatalog = !original; EditorUtility.SetDirty(settings);
                }
            }));
            Assert.Throws<InvalidOperationException>(() => Apply());
            Assert.AreEqual(!original, settings.BuildRemoteCatalog); Assert.IsTrue(EditorUtility.IsDirty(settings));
            CollectionAssert.AreEqual(before, File.ReadAllBytes(path)); Assert.IsFalse(Recover());
            settings.BuildRemoteCatalog = original; EditorUtility.ClearDirty(settings);
            Set(window, "ImportFault", null); Assert.IsTrue(Recover());
        }

        [UnityTest] public IEnumerator RepeatedDownloadPreservesOutputGuidAndFailureRestoresAllExistingOutputs()
        {
            var empty = Files(directory);
            Respond(url => Task.FromResult(Seed));
            Set(window, "ImportFault", new Action<string>(point => { if (point == "BeforeCommit") throw new IOException("Synthetic failure after creating new outputs."); }));
            LogAssert.Expect(LogType.Error, new Regex("Synthetic failure after creating new outputs"));
            Task request = Download(); while (!request.IsCompleted) yield return null;
            Assert.AreEqual("Failed", Get(window, "_importStatus"));
            Assert.IsTrue(Recover()); SameFiles(empty, directory);
            Assert.IsFalse(Directory.Exists(directory + "/Downloads")); Assert.IsFalse(File.Exists(Journal));
            Set(window, "ImportFault", null);
            request = Download(); while (!request.IsCompleted) yield return null;
            Assert.AreEqual("Completed", Get(window, "_importStatus"));
            string output = directory + "/Downloads/" + first + ".csv";
            Assert.IsInstanceOf<TextAsset>(AssetDatabase.LoadMainAssetAtPath(output));
            string outputGuid = AssetDatabase.AssetPathToGUID(output);
            byte[] outputMeta = File.ReadAllBytes(output + ".meta");
            long id = Table(first, "en").GetEntry("keep").KeyId;
            Respond(url => Task.FromResult(Changed));
            request = Download(); while (!request.IsCompleted) yield return null;
            Assert.AreEqual("Completed", Get(window, "_importStatus"));
            const string expectedOutput = "Key,ko,en\nkeep,수정,changed\nnew,추가,new";
            CollectionAssert.AreEqual(System.Text.Encoding.UTF8.GetPreamble().Concat(System.Text.Encoding.UTF8.GetBytes(expectedOutput)).ToArray(), File.ReadAllBytes(output));
            Assert.AreEqual(outputGuid, AssetDatabase.AssetPathToGUID(output));
            CollectionAssert.AreEqual(outputMeta, File.ReadAllBytes(output + ".meta"));
            Assert.AreEqual(id, Table(first, "en").GetEntry("keep").KeyId);
            var before = Files(directory);
            Respond(url => Task.FromResult(Seed));
            Set(window, "ImportFault", new Action<string>(point => { if (point == "BeforeCommit") throw new IOException("Synthetic failure after replacing existing outputs."); }));
            LogAssert.Expect(LogType.Error, new Regex("Synthetic failure after replacing existing outputs"));
            request = Download(); while (!request.IsCompleted) yield return null;
            Assert.AreEqual("Failed", Get(window, "_importStatus"));
            Assert.IsTrue(Recover()); SameFiles(before, directory);
            Assert.AreEqual(outputGuid, AssetDatabase.AssetPathToGUID(output));
            Assert.AreEqual(id, Table(first, "en").GetEntry("keep").KeyId);
            Assert.AreEqual("changed", Table(first, "en").GetEntry("keep").Value);
            Assert.IsFalse(File.Exists(Journal));
        }
        [UnityTest] public IEnumerator SlowDownloadKeepsEditorUpdatingAndCancelRejectsLateResponse()
        {
            SeedBoth(); var before = Files(directory);
            var late = new TaskCompletionSource<string>(); Respond(url => late.Task);
            Task request = Download();
            for (int i = 0; i < 3; ++i) { Assert.IsFalse(request.IsCompleted); yield return null; }
            Call(window, "CancelPendingRequest");
            late.SetResult(Changed);
            while (!request.IsCompleted) yield return null;
            Assert.AreEqual("Cancelled", Get(window, "_importStatus"));
            SameFiles(before, directory); Assert.IsFalse(Directory.Exists(directory + "/Downloads"));
        }

        [UnityTest] public IEnumerator ClosedWindowCannotApplyLateDownloadedContent()
        {
            SeedBoth(); var before = Files(directory);
            var late = new TaskCompletionSource<string>(); Respond(url => late.Task);
            Task request = Download(); Call(window, "OnDisable"); late.SetResult(Changed);
            while (!request.IsCompleted) yield return null;
            Assert.AreNotEqual("Completed", Get(window, "_importStatus")); SameFiles(before, directory);
        }

        [UnityTest] public IEnumerator DownloadFailureAfterFirstSheetNeverAppliesOrCountsPartialSuccess()
        {
            SeedBoth(); var before = Files(directory);
            int calls = 0;
            Respond(url => ++calls == 1 ? Task.FromResult(Changed) : Task.FromException<string>(new IOException("Synthetic second sheet failure")));
            LogAssert.Expect(LogType.Error, new Regex("Synthetic second sheet failure"));
            Task request = Download(); while (!request.IsCompleted) yield return null;
            Assert.AreEqual("Failed", Get(window, "_importStatus"));
            SameFiles(before, directory); Assert.IsFalse(Directory.Exists(directory + "/Downloads"));
        }
    }
}
