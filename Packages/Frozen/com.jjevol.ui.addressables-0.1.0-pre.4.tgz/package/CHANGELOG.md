# Changelog

## 0.1.0-pre.4 - 2026-11-07

- Breaking: `UIScreenTypes`, `UIPopupTypes` and `UIHudTypes` are removed. Screens, Popups and HUDs use game-owned string IDs. Addresses stay `UIScreen_{id}`, `UIPopup_{id}` and `UIHud_{id}`.
- Added `UIAddress`, `[UIAddressId]` with an Inspector dropdown, and `JJEvol/UI/Generate UI ID Constants`.
- Breaking: `UICommonBtn`, `SoundType`, `IUIInteractable` and `IUIDisable` are removed. Added `UIButtonLock`, `UIButtonSound`, `UIButtonStateVisual` and `UIButtonHoldRepeat` for Unity `Button`.
- `UIPopup` plays its optional `closeSoundKey` instead of a fixed sound.
- `UIEvent.Trigger` takes a string ID in place of the two enum overloads.

## 0.1.0-pre.3 - 2026-11-06

- Added `UIManager.AcquireLoadingAsync` and `UILoadingSession` for owned, reference counted full screen loading.
- Extracted shared image loading, preview mesh and Inspector code. Prefabs still keep only string keys.
- `Show Loading` is now the only loading switch, and loading display no longer blocks the image load.
- Fixed sound exceptions interrupting input, replaced Screen requests, closing Popup reopen, `CloseWait` results and lease leaks on never activated objects.
- Inspector warns about assets that are not Addressable.
- Added `AddressableImage.IsLoadDeferred` and `AddressableTexture.IsLoadDeferred`.

Unity tests for this candidate are NOT_RUN.
