#if UNITY_2018_3 || UNITY_2019 || UNITY_2018_3_OR_NEWER
#define NEW_PREFAB_SYSTEM
#endif

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace jjevol
{
	public class CustomMenu : MonoBehaviour
	{
		[MenuItem("GameObject/UI/AddressableImage", false, 13)]
		static void RHImageCreateMenu()
		{
			var parentGameObject = Selection.activeObject as GameObject;
			var parentTransform = parentGameObject == null ? null : parentGameObject.GetComponent<RectTransform>();

			if (parentTransform == null)
				Debug.LogWarning("Your new SkeletonGraphic will not be visible until it is placed under a Canvas");

			var gameObject = NewRHImage("AddressableImage");
			gameObject.transform.SetParent(parentTransform, false);
			EditorUtility.FocusProjectWindow();
			Selection.activeObject = gameObject;
			EditorGUIUtility.PingObject(Selection.activeObject);
		}

		static GameObject NewRHImage(string gameObjectName)
		{
			var go = NewGameObject(gameObjectName, true, typeof(RectTransform), typeof(CanvasRenderer), typeof(AddressableImage));
		
			return go;
		}

		public static GameObject NewGameObject(string name, bool useObjectFactory, params System.Type[] components)
		{
#if NEW_PREFAB_SYSTEM
			if (useObjectFactory)
				return ObjectFactory.CreateGameObject(name, components);
#endif
			return new GameObject(name, components);
		}

		[MenuItem("GameObject/UI/AddressableTexture", false, 13)]
		static void RHTextureCreateMenu()
		{
			var parentGameObject = Selection.activeObject as GameObject;
			var parentTransform = parentGameObject == null ? null : parentGameObject.GetComponent<RectTransform>();

			if (parentTransform == null)
				Debug.LogWarning("Your new SkeletonGraphic will not be visible until it is placed under a Canvas");

			var gameObject = NewRHTexture("AddressableTexture");
			gameObject.transform.SetParent(parentTransform, false);
			EditorUtility.FocusProjectWindow();
			Selection.activeObject = gameObject;
			EditorGUIUtility.PingObject(Selection.activeObject);
		}

		static GameObject NewRHTexture(string gameObjectName)
		{
			var go = NewGameObject(gameObjectName, true, typeof(RectTransform), typeof(CanvasRenderer), typeof(AddressableTexture));

			return go;
		}
	}
}