# JJEvol UI Addressables and Navigation

`com.jjevol.ui.addressables@0.1.0-pre.4`은 기존 UIManager·Screen/Popup/HUD·버튼 모듈·이미지·LoadingView를 제공한다. Core에 이 의존성을 강제하지 않는 선택 설치층이다. 이전 STEP11~26의 `pre.1` 고정본과 현재 개발 소스를 구분하며, 내부 후보는 해당 manifest와 SHA로 선택한다. 공식 릴리스나 소비 프로젝트 자동 갱신을 뜻하지 않는다.

AE1 보완은 HUD 컴포넌트 누락·Init 예외·세대 취소 후 미게시 인스턴스를 반환하고, 완료된 pending을 제거한 뒤 결과를 전달해 같은 await 흐름의 즉시 재호출을 허용한다. 기존 warning/완료 계약·정상 pool 재사용·공개 API·serialized field·GUID를 유지한다. AddressablesManager와 UIInstanceOwner의 구조는 변경하지 않는다.

필수는 UI Core, 일반 Resources Addressables, Audio Core, Effects Core 및 Addressables 4.0.1/UniTask 2.5.10/Input System 1.18.0이다. Audio는 버튼/팝업 사운드, Effect는 UIManager의 기존 typed PlayUIEffect/PlayScreenEffect API를 보존하는 직접 의존성이다. Economy·Tables·Save·Firebase·Platform·Runner·Localization SDK·DOTween·URP는 강제하지 않는다.

## 초기화와 종료

게임이 소유한 UIManager Prefab에서 screenRoot/popupRoot/hudRoot를 연결한다. loadingRoot, effectRoot, Camera/Canvas와 로딩 view는 사용할 기능에 맞게 연결한다. Awake가 초기화하므로 연결이 끝난 Prefab을 생성해야 한다. 초기화 전 `UIManager.Instance` 접근으로 빈 Manager를 생성하는 방식은 사용하지 않는다.

```csharp
var operation = UnityEngine.AddressableAssets.Addressables.InstantiateAsync(gameUIManagerKey);
var root = await operation;
var ui = root.GetComponent<jjevol.UIManager>();
await ui.screenManager.CachingScreenAsync(screenIds);
await ui.screenManager.ChangeUIScreenAsync(initialScreenId, screenData);
var popup = await ui.SpawnUIPopupAsync(popupId, popupData);
bool result = await popup.CloseWait();
// bootstrap 종료 시, 자신의 Manager 생성 Handle을 반환한다.
UnityEngine.AddressableAssets.Addressables.ReleaseInstance(operation);
```

변수·Prefab·Address는 소비 게임 소유다. Screen/Popup/HUD의 ID는 게임이 정하는 문자열이고 주소는 `UIScreen_{id}`, `UIPopup_{id}`, `UIHud_{id}`다(`UIAddress`). `JJEvol/UI/Generate UI ID Constants`는 등록된 주소를 읽어 게임 폴더에 문자열 상수를 만든다. 패키지에는 게임 화면 목록이 없다. 새 ID 칸은 `[UIAddressId]`로 Inspector에서 등록 주소를 고른다.

UIManagerCreater는 별도 `com.jjevol.ui.urp`가 소유한다. 해당 패키지를 선택하지 않는 공통 설치 절차는 위의 직접 SDK bootstrap이다. UI Manager 자신의 Handle은 bootstrap, Manager가 생성한 화면·팝업·HUD·loading instance는 각 Manager가 소유한다.

`UIManager.Init` 재호출/Disable/Destroy는 이전 Managers의 요청·인스턴스를 정리한다. standalone managers도 Dispose 및 root 파괴로 소유 SDK Handle을 반환한다. 같은 pooled Screen/HUD/Loading 동시 요청은 한 로드를 공유한다. 이전 navigation/닫힌 popup의 늦은 결과는 새 UI를 표시하지 않는다. 서로 다른 pre-transition/게임 정책은 `UINavigationOptions.ScreenPolicy`, `PopupPolicy`, `ConfigureTransitions`, `IsBackInputBlocked`로 연결한다. 종료 확인 UI는 게임이 ConfirmExitAsync를 제공해야 하며, 미설정 시 명시적인 오류다.

## 두 리소스 경로

- Navigation: 실제 `Addressables.InstantiateAsync`의 instance Handle을 보유하고 `ReleaseInstance`로 반환한다. 일반 로더의 Unity clone과 합치지 않았다.
- 이미지/LoadingView: STEP 9의 AddressableScope/Lease를 통해 원래 Manager 세대의 획득을 반환한다. LoadingView의 Unity clone은 파괴 완료 후 prefab lease를 반환한다.

AddressableImage는 Atlas Address(`atlasKey`/호환 `atlasTag`)와 내부 Sprite 이름(`spriteName`/SetSprite)을 구분한다. `SetAtlasSprite(address,name)`도 유지한다. SpriteAtlas가 돌려준 복사본은 교체·파괴 시 반환한다. AddressableTexture는 Texture2D → runtime Sprite 경로를 우선하고, Sprite 공급원도 지원한다. 실제 location 형식을 확인하며 runtime-created Sprite와 공급된 Sprite의 소유권을 구별한다. `spriteKey`, `spriteName`, SetSprite, `originColor` 및 오타 호환 `orginColor`, alpha를 유지한다.

취소/교체/파괴된 요청의 결과는 적용하지 않는다. ReleaseOnDisable 기본 false는 보유 정책으로 유지한다. UI를 비활성화한다고 기본값에서 곧바로 모든 자산이 해제되는 것은 아니다.

### 이미지 컴포넌트 규칙

두 컴포넌트의 핵심은 Prefab에 이미지 직접 참조를 남기지 않아 Bundle 의존성을 만들지 않는 것이다. Edit Mode에서 `m_Sprite`를 비우고 문자열 키만 직렬화하며, 프리뷰는 비직렬화 필드로 표시하고, 런타임에서 lease로 로드한다. 공통 코드(`AddressableImageLoadState`, Editor 전용 `AddressablePreviewMesh`, `AddressableImageInspectorBase`)는 직렬화 데이터를 추가하지 않는다.

- **Show Loading:** `m_ShowLoading`이 유일한 스위치다. 켜면 `m_LoadingView`가 있으면 그것을, 없으면 UIManager의 전역 로딩 뷰를 쓰고, 끄면 어느 쪽도 표시하지 않는다. AddressableImage의 기본값은 꺼짐이므로, 이전처럼 전역 로딩을 쓰던 Prefab은 값을 켜야 한다.
- **로딩 표시와 로드:** 로딩 표시를 기다리지 않고 이미지를 로드한다. 로딩 Prefab이 느리거나 실패해도 이미지는 로드되고, 표시 실패는 경고만 남는다.
- **같은 키 호출:** 로드 중 같은 키의 호출은 그 로드가 끝날 때까지 기다린다. 기다리는 호출자의 토큰은 자기 대기만 취소한다. 로드를 시작한 첫 호출자의 토큰은 로드 자체에 연결돼 있어서, 취소하면 로드가 끝나고 대기자도 Sprite 적용 없이 예외 없이 반환한다. 공유 로드의 결과가 필요한 호출자는 반환 뒤 `sprite`를 확인한다. 대기자는 로딩 표시와 로딩 색이 정리된 뒤 재개된다.
- **키 필드:** `LoadAtlasAsync`, `LoadSpriteAsync`는 성공하면 키 필드를 요청한 키로 갱신한다. 재활성화는 마지막으로 성공한 키를 다시 쓴다. 표시 중인 키를 다시 요청하면 진행 중인 다른 키의 로드를 취소한다. `atlasKey`, `spriteKey`에 현재 키를 다시 넣을 때도 같다.
- **활성화된 적 없는 객체:** 이런 객체는 OnDestroy가 불리지 않아 lease를 돌려줄 수 없으므로 로드를 시작하지 않는다. `LoadAtlasAsync`, `LoadSpriteAsync`는 키를 기록하고 로드를 지연한 뒤 바로 반환하며, 지연된 로드는 첫 활성화 때 `LoadOnEnable` 값과 무관하게 시작한다. 지연 중에는 `IsLoadDeferred`가 true이고, 이때 `sprite`가 비어 있는 것은 실패가 아니다. 호출자는 `IsLoadDeferred`가 false가 된 뒤 같은 키를 다시 요청해 시작된 로드를 기다릴 수 있다. `SetAtlasSprite`는 Atlas 키가 바뀔 때, AddressableImage의 `SetSprite`는 Atlas 키가 있고 Atlas가 로드되지 않았을 때 같은 지연을 건다. 같은 키의 `SetAtlasSprite`, AddressableTexture의 `SetSprite`, `atlasKey`, `spriteKey`는 값만 기록하고 지연하지 않으므로, 첫 활성화의 로드는 `LoadOnEnable`을 따르고 이 값이 꺼져 있으면 로드하지 않는다. 한 번이라도 활성화된 뒤 비활성화한 객체는 이전처럼 로드할 수 있다.
- **숨김:** AddressableImage는 Sprite가 없을 때만 자기 Mesh를 숨긴다. Atlas 교체 중에는 이전 Sprite가 남고, 코드로 넣은 `sprite`도 그대로 그린다.
- **Texture 색:** AddressableTexture는 로딩 색을 실제로 적용했을 때만 로딩 시작 시점의 색으로 되돌린다. 코드에서 바꾼 `color`는 비활성화, 같은 키 재설정, 로딩 표시 없는 로드에서 유지된다. 로딩 색이 적용된 동안의 변경은 `originColor`, `alpha`로 한다. 이때 `color`에 직접 넣은 값은 복원에 덮인다.
- **색 애니메이션:** 로딩을 표시한 로드에서만 돈다. 표시하지 않은 로드(캐시 포함)는 Graphic을 건드리지 않는다.
- **Texture의 Sprite:** Texture2D에서 만든 Sprite는 `SpriteMeshType.FullRect`를 쓴다. uGUI는 `Use Sprite Mesh`를 켜지 않으면 사각형으로 그리므로 표시 차이가 없다. 그 옵션을 켠 경우에만 투명 영역까지 메시로 그린다.
- **OnChangeSprite:** 두 컴포넌트 모두 새 Sprite가 적용된 직후에만 발생한다. 해제, null 결과, 찾지 못한 이름, 이미 표시 중인 Sprite의 재적용에서는 발생하지 않는다.
- **alpha 차이:** 둘 다 기본 색의 알파다. AddressableImage는 언제나 `color.a`와 같다. AddressableTexture는 로딩 색이 적용된 동안 `color.a`와 다를 수 있고, 그동안의 변경은 복원 색에 반영된다.

### 두 지연의 차이

| 항목 | `Release Delay` (`UIAssetOwnership.Return`) | `AddressablesManager.ReleaseAsset(key, delay)` |
|---|---|---|
| 기다리는 동안 참조 | lease를 쥐고 있어 `GetRefCount`가 줄지 않는다 | 참조가 먼저 0이 되고 캐시만 남는다 |
| 기다리는 동안 다시 로드 | 새 lease가 참조를 하나 더한다 | 같은 항목을 재사용하고 해제 예약을 취소한다 |
| `ReleaseUnusedAssets()` | 사용 중이라 해제되지 않는다 | 즉시 해제한다 |
| 조기 종료 | `PlaySession.Cancel()`이나 종료 시 즉시 lease를 반환한다 | `ReleaseUnusedAssets()`로 비운다 |

Boundary처럼 참조가 0이어야 하는 경계는 `ReleaseUnusedAssets()`만으로 UI 지연을 끝낼 수 없다. 표시를 정리한 뒤 `PlaySession.Cancel()`로 대기 중인 lease를 돌려주거나, 지연이 끝나기를 기다린다.

### 세 로딩 체계

| 체계 | 패키지 | 쓰는 상황 | 진행률 | 소유자 |
|---|---|---|---|---|
| `LoadingIndicator` | `com.jjevol.ui` | 짧은 대기 표시와 즉시 입력 차단. 네트워크 응답, 저장, 화면 전환 중간 | 없음 | 키 참조 카운트. `Scope(key)` 권장 |
| `UIManager.AcquireLoadingAsync` | `com.jjevol.ui.addressables` | 전체 화면 로딩. 씬 진입, 다운로드, 큰 데이터 로드 | `UILoadingSession.Report` | 세션. 마지막 세션이 닫는다 |
| `UIManager.ShowLoadingUIAsync`, `HideLoadingUI` | `com.jjevol.ui.addressables` | 기존 호출 유지. 호출자가 하나일 때 | 없음 | 없음. `HideLoadingUI`가 강제로 닫는다 |
| `AddressableLoadingView`, Service, Handle | `com.jjevol.ui.addressables` | 이미지 위 오버레이. `Show Loading`으로 켠다 | 없음 | 이미지 컴포넌트 |

전체 화면 로딩이 필요한 새 코드는 세션을 쓴다.

```csharp
using var session = await ui.AcquireLoadingAsync(loadingKey, token);
session.SetMessage(message);
await work.ToUniTask(progress: session);
```

세션이 하나라도 남아 있으면 화면이 유지되고, 마지막 세션의 Dispose가 닫는다. 키가 표시 중인 로딩과 다르면 경고하고 표시 중인 화면을 공유한다. 토큰 취소는 그 호출의 세션만 끝낸다. `ShowLoadingUIAsync` 호출은 세션이 끝나도 `HideLoadingUI`까지 화면을 유지한다. `HideLoadingUI`로 닫힌 뒤 도착한 이전 호출의 실패는 그 뒤의 새 호출이 가진 화면 유지에 영향을 주지 않는다. `HideLoadingUI`와 UIManager 재초기화는 강제 닫기이며 세션을 모두 비활성으로 만든다. 대기 중에 닫히면 `IsActive`가 false인 세션을 돌려준다.

세션은 로딩 Prefab에서 `IUILoadingProgressView`를 찾아 진행률과 문구를 전달하고, 없으면 무시한다. 세션이 여럿이면 보고한 세션 중 가장 낮은 값을 표시한다. 다운로드 진행률 연결은 AR2-04 범위이며, 여기서는 `IProgress<float>`로 받을 수 있게만 둔다.

AddressableLoadingHandle은 한 번만 반환한다. 서비스는 지연 표시·prewarm·최대 idle pool을 유지하며 UIManager/소유자가 Dispose한다. KeepInstance=false 상태의 Hide는 진행 중 로딩도 취소한다. KeepInstance=true는 숨겨진 instance/lease 보유를 허용한다.

## 호환성·선택 기능

`UIEvent.Changed`로 구독한다. 버튼은 Unity `Button`에 모듈을 붙인다. `UIButtonSound`는 클릭 소리, `UIButtonLock`은 잠금 상태와 소프트락 클릭, `UIButtonStateVisual`은 상태별 표시, `UIButtonHoldRepeat`는 반복 클릭을 맡는다. 두 잠금 모두 `Button.interactable`을 꺼서 `onClick`이 실행되지 않는다. 키보드와 게임패드는 꺼진 버튼을 선택하지 못하므로 소프트락 피드백은 포인터 입력에만 나온다. 팝업 닫기 소리는 `UIPopup`의 `closeSoundKey`로 지정한다. 등록되지 않은 사운드와 재생 구독자의 예외는 버튼 클릭과 팝업 닫기를 끊지 않고, 사운드별로 경고를 한 번 남긴다.

Screen 요청이 뒤 요청으로 대체되면 풀 인스턴스는 숨기고, 그 요청이 만든 일회용 인스턴스만 반환한다. 닫히는 중인 Popup은 중복으로 보지 않으므로 같은 종류를 다시 열면 새 Popup이 뜬다. 공개 `FindPopup`은 기존처럼 닫히는 중인 Popup도 찾는다. 닫힘이 끝난 뒤의 `CloseWait()`는 저장된 결과를 바로 돌려주고, 결과 없이 닫혔으면 취소된다.

Domain Reload를 끈 Play 진입에 대비해 `UINavigationOptions`, `UIEvent`, UIManager 정적 상태, 사운드 경고 기록은 `SubsystemRegistration`에서 비운다. 게임은 이 값들을 `BeforeSceneLoad` 이후나 부트스트랩에서 설정한다.

UIPopup의 serialized `transition` 슬롯은 MonoBehaviour로 넓히고 IUITransition을 요구한다. 기존 object reference/GUID를 보존하지만, 해당 컴포넌트의 실제 SDK·assembly가 있어야 한다. DOTween Pro 구현은 별도 `com.jjevol.ui.dotween-pro`가 소유한다. 이를 no-op 전환으로 대체하지 않는다. SDK가 없는 테스트는 원래의 transition 미지정 경로를 실제 실행한 것이다. missing script/잘못된 전환 연결은 명시적으로 거부한다.

Editor는 실제 Addressables/AssetDatabase resolver, 원본 AddressableImageInspector·AddressableTextureInspector, SpriteSelector·SpriteSelectorWindow·프로젝트의 SpriteDrawUtility와 생성 메뉴를 제공한다. 두 Inspector는 기존 Appearance/Raycast/Maskable·Image Type/Fill/Preserve Aspect·Runtime/Loading·키 편집·미리보기 기능을 포함하고, 공통 GUI는 `AddressableImageInspectorBase`가 소유한다. 모든 Foldout은 접힌 상태로 시작하고, Runtime·Loading 항목에 Tooltip이 있다. Addressable로 등록되지 않은 Atlas·Sprite를 고르면 이름이 키로 저장되어 런타임에서 실패하므로 경고를 표시한다. 기본 대체 CustomEditor는 등록하지 않는다. 선택 창은 공개 SpriteAtlas.GetSprites를 사용하고 생성한 Sprite·체커 텍스처를 닫을 때 정리한다. Inspector의 Atlas preview clone도 재사용·정리한다. 원본 Inspector/helper의 이름과 GUID를 보존했다. Inspector 화면/입력의 수동 검증은 자동 테스트·컴파일 검증과 구분한다.

STEP 06-A에서 일회성 AddressableUIReferenceCleaner와 Check/Clear 메뉴, Prefab 직접 Sprite 참조를 수정·저장하던 자동 Prebuild Hook을 제거했다. 이 패키지는 빌드 전에 프로젝트 Prefab을 일괄 정리하지 않는다. 기존 Inspector의 명시적인 이미지 설정·preview 기능과 Runtime 로딩 계약은 유지한다. 과거 복원 보고서는 당시 기록으로 보존한다.

알려진 제작 제한: AddressableImage/Texture의 EditMode Preview는 Sliced/Tiled/Filled의 Runtime mesh와 차이가 있다. Inspector는 Simple이 아닌 Image Type에서 이 차이를 안내한다. C2 보완은 별도 Addressables 설계 검토에 따라 보류했으며 AE1에서 해당 Preview 경로를 수정하지 않았다.

원본 Script GUID와 기존 serialized 필드/별칭을 유지하되 assembly identity는 바뀐다. 실제 제품 Prefab/SerializeReference·원본 Controller·원격 catalog·Player/실기기·전체 스타일/입력 장치 검증은 별도다. Effect Toast/Icon adapter는 별도 `com.jjevol.effects.ui`가 소유한다.
