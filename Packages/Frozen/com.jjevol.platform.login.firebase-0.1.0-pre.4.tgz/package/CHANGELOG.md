# Changelog

## 0.1.0-pre.4 - 2026-11-09

- Only a Google link conflict switches with the link's own credential when the SDK attached none. A Google ID token can sign in again; an Apple token, nonce or authorization code, or a server auth code of an added method, works once. Such a conflict now answers `AlreadyLinkedToOtherAccount` with no conflict (detail `FirebaseAccountLinkException/no_credential`) instead of offering a switch that fails. The choice follows the Firebase provider ID `google.com`, so a project that replaces the Google method with `AddMethod` keeps it.

No public API changed.

## 0.1.0-pre.3 - 2026-11-09

A Google link conflict on an Android device answered `AlreadyLinkedToOtherAccount` with code 10 but detail `FirebaseAccountLinkException/no_credential`: the Android SDK attached no `UpdatedCredential`, so the game could not switch.

- When the SDK attaches no usable credential, the conflict keeps the link's own credential, made again from the login method's credential, and `SwitchToLinkedAccount` signs in with it. A Google ID token can sign in again. The SDK's credential is still used first; Unity added it for Apple on iOS, whose token cannot be used twice.
- `FirebaseAccountLinkException/no_credential` now means that neither credential could be made.

No public API changed.

## 0.1.0-pre.2 - 2026-11-08

Fixes a link to a method owned by another account answering `ProviderError` with code 0 on an Android device.

- The SDK's `FirebaseAccountLinkException` derives from `System.Exception`, not `FirebaseException`. The client read codes only from `FirebaseException`, so the conflict had code 0, was not recognised and reached the game as `ProviderError`. Its code is now read on its own, and a code of 0 on it is read as `CredentialAlreadyInUse`, the only error the SDK creates it for.
- A conflict is decided by the exception type and the other account's credential the SDK attached, not by the code. With a usable credential the link answers `AlreadyLinkedToOtherAccount` with a conflict for `SwitchToLinkedAccount`. Without one it answers `AlreadyLinkedToOtherAccount` with no conflict and detail `FirebaseAccountLinkException/no_credential`, because there is nothing to switch to.
- The kept conflict holds that credential, read once, and frees it when the conflict is used or discarded.
- Sign-in, unlink and token calls read the code of both SDK exception types the same way.
- The translation from SDK exceptions moved to `FirebaseErrors` and is tested with the SDK's own exception types. The provider tests now feed it the exception the SDK throws instead of an already translated one.

No public API changed.

## 0.1.0-pre.1 - 2026-11-08

New design, per `Docs/PlatformLogin/Design.md`. It replaces the mobile library's `FirebaseAuthService` and `FirebaseSdkAuthClient`. Class names and GUIDs are not kept.

- `FirebaseAccountProvider` implements `IAccountProvider`. The manager now does the busy check, the session check and saved state, which `FirebaseAuthService` and the game used to repeat.
- Login methods map to Firebase provider IDs in one table. `AddMethod` adds a method without changing this package. The `"google"`, `"apple"` and `"anonymous"` strings are gone.
- Firebase error codes become `LoginFailure`. The code stays in `ProviderCode`.
- Restoring refreshes the token with the server, so a deleted or disabled account answers `AccountInvalid` at once.
- An Apple credential no longer needs an authorization code. The nonce is still required.
- A link to a provider the same user already has answers success.
- A link conflict that arrives after a cancel is discarded.
- The Editor workaround that saves an upgraded guest is kept.
- Answers come back on the caller's context. On Unity's main thread the manager gets every answer there, not on Firebase's thread.
- `Cancel` no longer drops the answer of a running call. Firebase cannot stop it, and the manager needs the answer to follow the user it signed in. Answers are dropped only after `Dispose`.

Unity results are in `Docs/PlatformLogin/Report.md`.
