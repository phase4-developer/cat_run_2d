# JJEvol Platform Login Firebase

Local validation candidate 0.1.0-pre.4. Firebase Auth as the game account for `com.jjevol.platform.login`. Login method providers get a platform credential, and this provider signs into Firebase with it. The account's user ID is the Firebase UID.

The code is user-authored, confirmed by the user on 2026-11-08. This package has no Firebase SDK, `google-services.json` or `GoogleService-Info.plist` in it.

## Install

The Firebase Auth SDK for Unity is required and is not a package dependency. The consumer project installs it, as a `.unitypackage` or as Google's UPM packages, so that `Firebase.App.dll` and `Firebase.Auth.dll` exist. It was compiled against 13.17.0. Without them this package does not compile.

## Use

The project creates the Firebase app and passes its `FirebaseAuth`:

```csharp
LoginManager.SetAccountProvider(new FirebaseAccountProvider(FirebaseAuth.GetAuth(app), "live"));
```

The environment key separates saved login state. Use the key of `NetworkManager.EnvironmentKey`. When the project switches Firebase apps, for example from "live" to "stage" on `NetworkManager.EnvironmentChanged`, it calls `SetAccountProvider` with a new provider. The manager ends a running call and reads the state of the new environment. Disposing the old provider never signs out.

## The flow

| Call | Firebase |
|---|---|
| `SignIn(Guest)` | Uses the current anonymous user, or creates one. A signed-in social user is signed out first. |
| `SignIn(Google)`, `SignIn(Apple)` | The method provider gets the token, then `SignInWithCredentialAsync`. |
| `RestoreSession` | Uses Firebase's saved user when it has the last method, and refreshes its token so a deleted or disabled account is found now. Never creates a user. |
| `Link` | `LinkWithCredentialAsync` on the current user. A guest keeps its UID. |
| Link to a method owned by another user | Answers `AlreadyLinkedToOtherAccount` with a conflict. `SwitchToLinkedAccount` signs into the owner with the updated credential Firebase attached to the failure, or, for Google only, with the link's own credential when Firebase attached none (the Android SDK does not). Other methods' credentials work once, so they switch only with Firebase's credential. If neither can be made, it answers `AlreadyLinkedToOtherAccount` with no conflict (detail `FirebaseAccountLinkException/no_credential`). |
| `Unlink` | `UnlinkAsync` with the method's Firebase provider ID. |
| `GetToken` | `TokenAsync` of the current user. |

| `LoginMethod` | Firebase provider ID | Credential |
|---|---|---|
| `Google` | `google.com` | `GoogleAuthProvider.GetCredential(idToken, null)` |
| `Apple` | `apple.com` | `OAuthProvider.GetCredential("apple.com", idToken, rawNonce, authorizationCode)`. The nonce is required, the code is passed when present. |

Another method is added without changing this package:

```csharp
new FirebaseAccountProvider(auth, "live")
    .AddMethod(new LoginMethod("steam"), "oidc.steam", credential => OAuthProvider.GetCredential("oidc.steam", credential.Token, null, null));
```

`LoginAccount.LinkedMethods` lists the methods whose provider ID the user has. A guest has none.

## Errors

| Firebase `AuthError` | `LoginFailure` |
|---|---|
| `NetworkRequestFailed` | `NoConnection` |
| `UserNotFound`, `UserDisabled`, `UserTokenExpired`, `InvalidUserToken` | `AccountInvalid` |
| `InvalidCredential`, `RejectedCredential` | `CredentialRejected` |
| `CredentialAlreadyInUse`, `AccountExistsWithDifferentCredentials` | `AlreadyLinkedToOtherAccount` |
| `Cancelled`, `WebContextCancelled` | `Cancelled` |
| Others | `ProviderError` |

Callbacks run on the caller's context. Call the manager from Unity's main thread and every answer comes back there. Firebase finishes its tasks on its own thread.

Firebase calls cannot be stopped. `Cancel` does nothing, and a call that finishes after it still answers, so the manager can follow the user it left signed in. After `Dispose` nothing answers, and a late link conflict is discarded.

`ProviderCode` is the `AuthError` value and `Detail` the exception type. Exception messages are never passed on, because they can hold credentials. A link to a provider the same user already has answers success with `Detail` `already_linked`.

## Editor

The desktop Firebase SDK does not save a guest upgraded by a link until it signs in again. The provider signs in again with the same credential right after, without signing out the guest. Other platforms skip this.

## Trust boundary

The game's server verifies the token from `LoginManager.GetToken` with the Firebase Admin SDK on every request and takes the UID from it. Nothing the client reports proves who the player is.

## Validation

Tests are in `Tests/Editor`, in an isolated assembly, and use a fake Firebase client. They need the Firebase SDK DLLs to compile, but never call Firebase. One test runs the manager with this provider: the Google credential goes to Firebase and the Firebase UID comes back. Real Firebase sign-in needs the project's Firebase configuration and is NOT_RUN. See `Docs/PlatformLogin/Report.md`.
