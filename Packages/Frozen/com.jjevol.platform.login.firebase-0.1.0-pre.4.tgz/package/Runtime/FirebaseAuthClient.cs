using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Firebase.Auth;

namespace PlatformLibrary.Login.Firebase
{
    /// <summary>A copy of a Firebase user, taken before any await because <c>FirebaseUser</c> is a live proxy.</summary>
    internal sealed class FirebaseUserSnapshot
    {
        public FirebaseUserSnapshot(string userId, bool isAnonymous, string email, IEnumerable<string> providerIds)
        {
            UserId = userId;
            IsAnonymous = isAnonymous;
            Email = email;
            ProviderIds = new List<string>(providerIds ?? Array.Empty<string>()).AsReadOnly();
        }

        public string UserId { get; }
        public bool IsAnonymous { get; }
        public string Email { get; }
        public IReadOnlyList<string> ProviderIds { get; }

        public bool HasProvider(string providerId)
        {
            foreach (string id in ProviderIds)
                if (id == providerId) return true;
            return false;
        }
    }

    /// <summary>A login method the account provider accepts, and how its credential becomes a Firebase credential.</summary>
    internal sealed class FirebaseMethod
    {
        public FirebaseMethod(LoginMethod method, string providerId, Func<LoginCredential, Credential> createCredential)
        {
            Method = method;
            ProviderId = providerId;
            CreateCredential = createCredential;
            CanSignInAgain = providerId == FirebaseAccountProvider.GoogleProviderId;
        }

        public LoginMethod Method { get; }
        public string ProviderId { get; }
        public Func<LoginCredential, Credential> CreateCredential { get; }

        /// <summary>
        /// Whether the credential of a failed link can sign in once more, so a link conflict can switch with it when the SDK
        /// attached no credential. True only for Google: its ID token can be used again until it expires. An Apple token, a nonce,
        /// an authorization code or a server auth code works once, so other methods switch only with the SDK's credential.
        /// </summary>
        public bool CanSignInAgain { get; }
    }

    /// <summary>A Firebase failure reduced to what may leave the SDK boundary. Messages are dropped: they can hold credentials.</summary>
    internal sealed class FirebaseClientException : Exception
    {
        public FirebaseClientException(int code, string type, string conflict = null) : base("Firebase Auth error " + code)
        {
            Code = code;
            Type = type;
            Conflict = conflict;
        }

        /// <summary>The Firebase <c>AuthError</c> value, or 0.</summary>
        public int Code { get; }

        /// <summary>The exception type name, for logs.</summary>
        public string Type { get; }

        /// <summary>A handle for <see cref="IFirebaseAuthClient.SwitchAsync"/> when the credential belongs to another account.</summary>
        public string Conflict { get; }
    }

    /// <summary>Every Firebase Auth call the provider makes. Failures throw <see cref="FirebaseClientException"/>.</summary>
    internal interface IFirebaseAuthClient : IDisposable
    {
        FirebaseUserSnapshot CurrentUser { get; }
        Task<FirebaseUserSnapshot> SignInAnonymouslyAsync();
        Task<FirebaseUserSnapshot> SignInAsync(FirebaseMethod method, LoginCredential credential);
        Task<FirebaseUserSnapshot> LinkAsync(FirebaseMethod method, LoginCredential credential);
        Task<FirebaseUserSnapshot> SwitchAsync(string conflict);
        Task<FirebaseUserSnapshot> UnlinkAsync(string providerId);

        /// <summary>The current user's ID token. Forcing a refresh also checks the account with the server.</summary>
        Task<string> GetTokenAsync(bool forceRefresh);

        /// <summary>Forgets a conflict, or every conflict with null.</summary>
        void DiscardConflict(string conflict);

        void SignOut();
    }
}
