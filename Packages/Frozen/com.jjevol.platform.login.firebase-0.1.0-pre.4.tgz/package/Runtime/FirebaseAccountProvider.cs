using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Firebase.Auth;

namespace PlatformLibrary.Login.Firebase
{
    /// <summary>
    /// Firebase Auth as the game account. Guests are anonymous users, login methods sign in or link with their credential,
    /// and <see cref="GetToken"/> gives the Firebase ID token for the game's server.
    /// Google (<c>google.com</c>) and Apple (<c>apple.com</c>) are built in. <see cref="AddMethod"/> adds others.
    /// </summary>
    public sealed class FirebaseAccountProvider : IAccountProvider, IDisposable
    {
        public const string GoogleProviderId = "google.com";
        public const string AppleProviderId = "apple.com";

        private readonly IFirebaseAuthClient _client;
        private readonly Dictionary<LoginMethod, FirebaseMethod> _methods = new Dictionary<LoginMethod, FirebaseMethod>();
        private bool _disposed;

        /// <summary>
        /// <paramref name="auth"/> comes from the project's Firebase app. <paramref name="environmentKey"/> separates saved login state.
        /// Use the key of <c>NetworkManager.EnvironmentKey</c>, for example "live" or "stage". A null <paramref name="auth"/> makes the provider report <see cref="LoginFailure.NotInitialized"/>.
        /// </summary>
        public FirebaseAccountProvider(FirebaseAuth auth, string environmentKey) : this(auth == null ? null : new FirebaseSdkAuthClient(auth), environmentKey)
        {
        }

        internal FirebaseAccountProvider(IFirebaseAuthClient client, string environmentKey)
        {
            EnvironmentKey = environmentKey ?? throw new ArgumentNullException(nameof(environmentKey));
            _client = client;
            AddMethod(LoginMethod.Google, GoogleProviderId, credential => GoogleAuthProvider.GetCredential(credential.Token, null));
            AddMethod(LoginMethod.Apple, AppleProviderId, credential => OAuthProvider.GetCredential(AppleProviderId, credential.Token, credential.RawNonce, credential.AuthorizationCode));
        }

        public string EnvironmentKey { get; }

        public LoginFailure Availability => _client == null || _disposed ? LoginFailure.NotInitialized : LoginFailure.None;

        public LoginAccount Current => _client == null || _disposed ? null : ToAccount(_client.CurrentUser);

        /// <summary>
        /// Accepts another login method, or replaces a built-in one. <paramref name="firebaseProviderId"/> is the provider ID
        /// Firebase reports for it, and <paramref name="createCredential"/> turns the method's credential into a Firebase credential.
        /// </summary>
        public FirebaseAccountProvider AddMethod(LoginMethod method, string firebaseProviderId, Func<LoginCredential, Credential> createCredential)
        {
            if (method.IsNone || method == LoginMethod.Guest) throw new ArgumentException("A login method other than Guest is required.", nameof(method));
            if (string.IsNullOrEmpty(firebaseProviderId)) throw new ArgumentNullException(nameof(firebaseProviderId));
            if (createCredential == null) throw new ArgumentNullException(nameof(createCredential));
            foreach (FirebaseMethod existing in _methods.Values)
                if (existing.ProviderId == firebaseProviderId && existing.Method != method)
                    throw new ArgumentException("Firebase provider " + firebaseProviderId + " already belongs to " + existing.Method + ".", nameof(firebaseProviderId));
            _methods[method] = new FirebaseMethod(method, firebaseProviderId, createCredential);
            return this;
        }

        public void SignInGuest(Action<AccountResult> callback)
        {
            Run(callback, async () => Succeeded(await _client.SignInAnonymouslyAsync()));
        }

        public void Restore(LoginMethod method, Action<AccountResult> callback)
        {
            Run(callback, async () =>
            {
                FirebaseUserSnapshot user = _client.CurrentUser;
                if (user == null) return AccountResult.Failed(LoginFailure.NoSavedLogin, detail: "no_saved_session");
                bool matches = method == LoginMethod.Guest
                    ? user.IsAnonymous
                    : _methods.TryGetValue(method, out FirebaseMethod mapped) && user.HasProvider(mapped.ProviderId);
                if (!matches) return AccountResult.Failed(LoginFailure.NoSavedLogin, detail: "saved_session_method_mismatch");

                // A forced refresh asks the server, so a deleted or disabled account is found now and not at the first request.
                await _client.GetTokenAsync(true);
                return Succeeded(user);
            });
        }

        public void SignIn(LoginCredential credential, Action<AccountResult> callback)
        {
            Run(callback, async () =>
            {
                if (!TryMethod(credential, out FirebaseMethod method, out AccountResult rejected)) return rejected;
                return Succeeded(await _client.SignInAsync(method, credential));
            });
        }

        public void Link(LoginCredential credential, Action<AccountResult> callback)
        {
            Run(callback, async () =>
            {
                FirebaseUserSnapshot target = _client.CurrentUser;
                if (target == null) return AccountResult.Failed(LoginFailure.NotSignedIn);
                if (!TryMethod(credential, out FirebaseMethod method, out AccountResult rejected)) return rejected;
                try
                {
                    return Succeeded(await _client.LinkAsync(method, credential));
                }
                catch (FirebaseClientException exception) when (exception.Conflict != null)
                {
                    return AccountResult.LinkConflict(exception.Conflict, exception.Code, exception.Type);
                }
                catch (FirebaseClientException exception) when (exception.Code == (int)AuthError.ProviderAlreadyLinked)
                {
                    // The account already has this provider, for example from another device.
                    FirebaseUserSnapshot user = _client.CurrentUser;
                    if (user != null && user.UserId == target.UserId && user.HasProvider(method.ProviderId)) return Succeeded(user, "already_linked");
                    throw;
                }
            });
        }

        public void SwitchToLinkedAccount(string conflict, Action<AccountResult> callback)
        {
            Run(callback, async () => Succeeded(await _client.SwitchAsync(conflict)));
        }

        public void DiscardConflict(string conflict)
        {
            if (conflict != null) _client?.DiscardConflict(conflict);
        }

        public void Unlink(LoginMethod method, Action<AccountResult> callback)
        {
            Run(callback, async () =>
            {
                if (!_methods.TryGetValue(method, out FirebaseMethod mapped)) return AccountResult.Failed(LoginFailure.Unsupported, detail: "method_not_mapped");
                if (_client.CurrentUser == null) return AccountResult.Failed(LoginFailure.NotSignedIn);
                return Succeeded(await _client.UnlinkAsync(mapped.ProviderId));
            });
        }

        public void GetToken(bool forceRefresh, Action<LoginToken> callback)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            if (Availability != LoginFailure.None)
            {
                callback(LoginToken.Failed(Availability));
                return;
            }
            if (_client.CurrentUser == null)
            {
                callback(LoginToken.Failed(LoginFailure.NotSignedIn));
                return;
            }
            RunToken(forceRefresh, callback);
        }

        /// <summary>
        /// Firebase calls cannot be stopped. A call that finishes after a cancel still answers, because it may have changed
        /// the signed-in user. The manager uses that answer only to follow the session.
        /// </summary>
        public void Cancel()
        {
        }

        public void SignOut()
        {
            if (_client == null || _disposed) return;
            _client.SignOut();
        }

        /// <summary>Forgets conflicts and stops answering. Never signs out, so a saved guest account survives.</summary>
        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _client?.Dispose();
        }

        // ---- Internal ----

        private bool TryMethod(LoginCredential credential, out FirebaseMethod method, out AccountResult rejected)
        {
            method = null;
            rejected = null;
            if (credential == null || string.IsNullOrEmpty(credential.Token))
                rejected = AccountResult.Failed(LoginFailure.CredentialRejected, detail: "token_missing");
            else if (!_methods.TryGetValue(credential.Method, out method))
                rejected = AccountResult.Failed(LoginFailure.Unsupported, detail: "method_not_mapped");
            else if (credential.Method == LoginMethod.Apple && string.IsNullOrEmpty(credential.RawNonce))
                rejected = AccountResult.Failed(LoginFailure.CredentialRejected, detail: "nonce_missing");
            return rejected == null;
        }

        private void Run(Action<AccountResult> callback, Func<Task<AccountResult>> work)
        {
            if (callback == null) throw new ArgumentNullException(nameof(callback));
            if (Availability != LoginFailure.None) callback(AccountResult.Failed(Availability));
            else RunAsync(callback, work);
        }

        // The awaits keep the caller's context, so on Unity's main thread every answer comes back there.
        // Firebase completes its tasks on its own thread, and the manager must not run on that one.
        private async void RunAsync(Action<AccountResult> callback, Func<Task<AccountResult>> work)
        {
            AccountResult result;
            try
            {
                result = await work();
            }
            catch (FirebaseClientException exception)
            {
                result = AccountResult.Failed(ToFailure(exception.Code), exception.Code, exception.Type);
            }
            catch (Exception exception)
            {
                result = AccountResult.Failed(LoginFailure.ProviderError, detail: exception.GetType().Name);
            }

            if (_disposed)
            {
                if (result.Conflict != null) _client?.DiscardConflict(result.Conflict);
                return;
            }
            callback(result);
        }

        private async void RunToken(bool forceRefresh, Action<LoginToken> callback)
        {
            LoginToken token;
            try
            {
                string value = await _client.GetTokenAsync(forceRefresh);
                token = string.IsNullOrEmpty(value) ? LoginToken.Failed(LoginFailure.ProviderError, detail: "token_empty") : LoginToken.Succeeded(value);
            }
            catch (FirebaseClientException exception)
            {
                token = LoginToken.Failed(exception.Type == "session_changed" ? LoginFailure.SessionChanged : ToFailure(exception.Code), exception.Code, exception.Type);
            }
            catch (Exception exception)
            {
                token = LoginToken.Failed(LoginFailure.ProviderError, detail: exception.GetType().Name);
            }
            callback(token);
        }

        private AccountResult Succeeded(FirebaseUserSnapshot user, string detail = null) => AccountResult.Succeeded(ToAccount(user), detail);

        private LoginAccount ToAccount(FirebaseUserSnapshot user)
        {
            if (user == null) return null;
            var linked = new List<LoginMethod>();
            foreach (string providerId in user.ProviderIds)
                foreach (FirebaseMethod method in _methods.Values)
                    if (method.ProviderId == providerId && !linked.Contains(method.Method)) linked.Add(method.Method);
            return new LoginAccount(user.UserId, user.IsAnonymous, user.Email, linked);
        }

        /// <summary>Firebase <c>AuthError</c> values to <see cref="LoginFailure"/>.</summary>
        internal static LoginFailure ToFailure(int code)
        {
            switch ((AuthError)code)
            {
                case AuthError.NetworkRequestFailed: return LoginFailure.NoConnection;
                case AuthError.UserNotFound:
                case AuthError.UserDisabled:
                case AuthError.UserTokenExpired:
                case AuthError.InvalidUserToken:
                    return LoginFailure.AccountInvalid;
                case AuthError.InvalidCredential:
                case AuthError.RejectedCredential:
                    return LoginFailure.CredentialRejected;
                case AuthError.CredentialAlreadyInUse:
                case AuthError.AccountExistsWithDifferentCredentials:
                    return LoginFailure.AlreadyLinkedToOtherAccount;
                case AuthError.Cancelled:
                case AuthError.WebContextCancelled:
                    return LoginFailure.Cancelled;
                default:
                    return LoginFailure.ProviderError;
            }
        }
    }
}
