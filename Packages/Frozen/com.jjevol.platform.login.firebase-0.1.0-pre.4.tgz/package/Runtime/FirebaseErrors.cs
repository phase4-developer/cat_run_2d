using System;
using Firebase;
using Firebase.Auth;

namespace PlatformLibrary.Login.Firebase
{
    /// <summary>
    /// Turns exceptions from the Firebase Auth SDK into <see cref="FirebaseClientException"/>: a code and a type name.
    /// Messages are dropped: they can hold credentials. It reads only the SDK's exception types, so Editor tests can feed it
    /// the same exception types the SDK throws on a device.
    /// </summary>
    /// <remarks>
    /// The SDK's <c>FirebaseAccountLinkException</c> derives from <see cref="Exception"/>, not <see cref="FirebaseException"/>
    /// (firebase-unity-sdk <c>auth/src/FirebaseAccountLinkException.cs</c>, and Firebase.Auth.dll 13.17.0), so its code is read on its own.
    /// The SDK creates it only when an <c>AuthResult</c> call fails with <c>AuthError.CredentialAlreadyInUse</c>
    /// (<c>auth/src/swig/auth.i</c>, <c>SWIG_FUTURE_AUTHRESULT_GET_TASK</c>), so a code of 0 on it is read as that error.
    /// </remarks>
    internal static class FirebaseErrors
    {
        /// <summary>The type name a link conflict reports when the SDK gave no credential to switch with.</summary>
        internal const string NoConflictCredential = "FirebaseAccountLinkException/no_credential";

        /// <summary>The Firebase exception inside task and aggregate wrappers, or the innermost exception.</summary>
        internal static Exception Unwrap(Exception exception)
        {
            if (exception is AggregateException aggregate)
            {
                foreach (Exception inner in aggregate.Flatten().InnerExceptions)
                {
                    Exception value = Unwrap(inner);
                    if (IsFirebase(value)) return value;
                }
            }
            if (IsFirebase(exception) || exception?.InnerException == null) return exception;
            return Unwrap(exception.InnerException);
        }

        /// <summary>The Firebase <c>AuthError</c> value of an unwrapped exception, or 0 for an exception that is not Firebase's.</summary>
        internal static int CodeOf(Exception firebase)
        {
            switch (firebase)
            {
                case FirebaseException value: return value.ErrorCode;
                case FirebaseAccountLinkException link: return link.ErrorCode != 0 ? link.ErrorCode : (int)AuthError.CredentialAlreadyInUse;
                default: return 0;
            }
        }

        /// <summary>Any failed SDK call.</summary>
        internal static FirebaseClientException Translate(Exception exception)
        {
            if (exception is FirebaseClientException client) return client;
            Exception firebase = Unwrap(exception) ?? exception;
            return new FirebaseClientException(CodeOf(firebase), firebase?.GetType().Name);
        }

        /// <summary>
        /// A failed link. When the SDK says the credential belongs to another account, <paramref name="holdConflict"/> keeps that
        /// account's credential and answers a handle for <see cref="IFirebaseAuthClient.SwitchAsync"/>, or null when there is no
        /// credential to switch with. Without a handle the failure is still <c>CredentialAlreadyInUse</c>, but it cannot switch.
        /// </summary>
        internal static FirebaseClientException TranslateLink(Exception exception, Func<FirebaseAccountLinkException, string> holdConflict)
        {
            if (!(Unwrap(exception) is FirebaseAccountLinkException link)) return Translate(exception);
            string conflict = holdConflict(link);
            return new FirebaseClientException(CodeOf(link), conflict != null ? link.GetType().Name : NoConflictCredential, conflict);
        }

        /// <summary>
        /// The credential that signs into the other account of a link conflict: the one the SDK attached, or else the link's own
        /// credential from <paramref name="linkCredential"/>. The Android SDK attaches none for a Google link (seen on a device,
        /// 2026-11-09); Unity added <c>UpdatedCredential</c> for Apple on iOS, whose token cannot be used twice.
        /// A Google ID token can sign in again, so the link's own credential reaches the account that owns it.
        /// The caller disposes the result. Null when neither is usable.
        /// </summary>
        internal static Credential SwitchCredential(FirebaseAccountLinkException link, Func<Credential> linkCredential)
        {
            Credential attached = ConflictCredential(link);
            if (attached != null) return attached;

            Credential own;
            try { own = linkCredential?.Invoke(); }
            catch (Exception) { return null; }
            if (own == null) return null;

            bool valid;
            try { valid = own.IsValid(); }
            catch (Exception) { valid = false; }
            if (valid) return own;
            own.Dispose();
            return null;
        }

        /// <summary>
        /// The other account's credential the SDK attached to a link conflict, or null when it attached none or an invalid one.
        /// The caller disposes it. The exception must stay alive while the credential is used: the SDK result owns its data.
        /// </summary>
        internal static Credential ConflictCredential(FirebaseAccountLinkException link)
        {
            Credential credential;
            try { credential = link?.UserInfo?.UpdatedCredential; }
            catch (Exception) { return null; }
            if (credential == null) return null;

            bool valid;
            try { valid = credential.IsValid(); }
            catch (Exception) { valid = false; }
            if (valid) return credential;
            credential.Dispose();
            return null;
        }

        private static bool IsFirebase(Exception exception) => exception is FirebaseException || exception is FirebaseAccountLinkException;
    }
}
