using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Login.Firebase.Tests.Editor")]
