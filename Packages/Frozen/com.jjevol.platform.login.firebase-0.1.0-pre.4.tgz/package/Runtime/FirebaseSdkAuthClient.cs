using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Firebase.Auth;

namespace PlatformLibrary.Login.Firebase
{
    /// <summary>The Firebase Auth SDK behind <see cref="IFirebaseAuthClient"/>. Call it from the main thread.</summary>
    internal sealed class FirebaseSdkAuthClient : IFirebaseAuthClient
    {
        private readonly FirebaseAuth _auth;
        private readonly Dictionary<string, Conflict> _conflicts = new Dictionary<string, Conflict>();

        public FirebaseSdkAuthClient(FirebaseAuth auth)
        {
            _auth = auth ?? throw new ArgumentNullException(nameof(auth));
        }

        public FirebaseUserSnapshot CurrentUser => Snapshot(_auth.CurrentUser);

        public Task<FirebaseUserSnapshot> SignInAnonymouslyAsync() => Guard(async () =>
        {
            FirebaseUser user = _auth.CurrentUser;
            if (user != null && !user.IsAnonymous)
            {
                // Only an explicit guest sign-in replaces a social session.
                _auth.SignOut();
                user = null;
            }
            if (user == null)
            {
                // The AuthResult is not disposed: the SDK keeps the user it returned.
                user = (await _auth.SignInAnonymouslyAsync())?.User;
            }
            return Require(user);
        });

        public Task<FirebaseUserSnapshot> SignInAsync(FirebaseMethod method, LoginCredential credential) => Guard(async () =>
        {
            using (Credential sdkCredential = Create(method, credential))
            {
                FirebaseUser before = _auth.CurrentUser;
                string anonymousUid = before != null && before.IsAnonymous ? before.UserId : null;
                FirebaseUser user = await _auth.SignInWithCredentialAsync(sdkCredential);
                await PersistEditorUpgradeAsync(user, anonymousUid, method.ProviderId, sdkCredential);
                return Require(user);
            }
        });

        public Task<FirebaseUserSnapshot> LinkAsync(FirebaseMethod method, LoginCredential credential) => Guard(async () =>
        {
            FirebaseUser target = _auth.CurrentUser;
            if (target == null) throw new FirebaseClientException(0, "no_current_user");
            string uid = target.UserId;
            string anonymousUid = target.IsAnonymous ? uid : null;
            using (Credential sdkCredential = Create(method, credential))
            {
                FirebaseUser linked;
                try
                {
                    linked = (await target.LinkWithCredentialAsync(sdkCredential))?.User;
                }
                catch (Exception exception)
                {
                    throw FirebaseErrors.TranslateLink(exception, link => HoldConflict(link, LinkCredentialAgain(method, credential)));
                }
                await PersistEditorUpgradeAsync(linked, anonymousUid, method.ProviderId, sdkCredential);
                return Require(linked);
            }
        });

        public Task<FirebaseUserSnapshot> SwitchAsync(string conflict) => Guard(async () =>
        {
            if (conflict == null || !_conflicts.TryGetValue(conflict, out Conflict held))
                throw new FirebaseClientException(0, "unknown_conflict");
            _conflicts.Remove(conflict);
            try
            {
                if (!held.Credential.IsValid()) throw new FirebaseClientException(0, "conflict_credential_invalid");
                return Require(await _auth.SignInWithCredentialAsync(held.Credential));
            }
            finally
            {
                held.Dispose();
            }
        });

        public Task<FirebaseUserSnapshot> UnlinkAsync(string providerId) => Guard(async () =>
        {
            FirebaseUser user = _auth.CurrentUser;
            if (user == null) throw new FirebaseClientException(0, "no_current_user");
            return Require((await user.UnlinkAsync(providerId))?.User);
        });

        public Task<string> GetTokenAsync(bool forceRefresh) => Guard(async () =>
        {
            FirebaseUser user = _auth.CurrentUser;
            if (user == null) throw new FirebaseClientException(0, "no_current_user");
            string uid = user.UserId;
            string token = await user.TokenAsync(forceRefresh);
            if (_auth.CurrentUser?.UserId != uid) throw new FirebaseClientException(0, "session_changed");
            return token;
        });

        public void DiscardConflict(string conflict)
        {
            if (conflict == null)
            {
                foreach (Conflict each in _conflicts.Values) each.Dispose();
                _conflicts.Clear();
            }
            else if (_conflicts.TryGetValue(conflict, out Conflict held))
            {
                _conflicts.Remove(conflict);
                held.Dispose();
            }
        }

        public void SignOut()
        {
            DiscardConflict(null);
            _auth.SignOut();
        }

        /// <summary>Forgets conflicts only. Disposing never signs out or deletes a saved guest account.</summary>
        public void Dispose() => DiscardConflict(null);

        // Keeps the credential that signs into the other account of a link conflict. Without one there is nothing to switch to, so no handle.
        private string HoldConflict(FirebaseAccountLinkException link, Func<Credential> linkCredential)
        {
            Credential credential = FirebaseErrors.SwitchCredential(link, linkCredential);
            if (credential == null) return null;
            string handle = Guid.NewGuid().ToString("N");
            _conflicts.Add(handle, new Conflict(credential, link));
            return handle;
        }

        /// <summary>
        /// Makes the link's own credential again for a conflict the SDK attached no credential to, or null for a method whose
        /// credential works once (<see cref="FirebaseMethod.CanSignInAgain"/>). Without it such a conflict has nothing to switch with.
        /// </summary>
        internal static Func<Credential> LinkCredentialAgain(FirebaseMethod method, LoginCredential credential)
        {
            if (method == null || !method.CanSignInAgain) return null;
            return () => Recreate(method, credential);
        }

        // The link's own credential again, made anew because the one passed to the SDK is disposed after the call.
        private static Credential Recreate(FirebaseMethod method, LoginCredential credential)
        {
            try { return Create(method, credential); }
            catch (FirebaseClientException) { return null; }
        }

        private static Credential Create(FirebaseMethod method, LoginCredential credential)
        {
            Credential created;
            try { created = method.CreateCredential(credential); }
            catch (Exception exception) { throw new FirebaseClientException((int)AuthError.InvalidCredential, exception.GetType().Name); }
            if (created == null || !created.IsValid())
            {
                created?.Dispose();
                throw new FirebaseClientException((int)AuthError.InvalidCredential, "credential_invalid");
            }
            return created;
        }

        private async Task PersistEditorUpgradeAsync(FirebaseUser user, string anonymousUid, string providerId, Credential credential)
        {
#if UNITY_EDITOR
            // The desktop SDK does not save a guest account upgraded to a provider until it signs in again.
            // Signing in again with the same credential keeps the account without signing out the guest first.
            if (string.IsNullOrEmpty(anonymousUid) || user == null || user.UserId != anonymousUid || user.IsAnonymous) return;
            if (!Snapshot(user).HasProvider(providerId)) return;
            try { await user.ReauthenticateAsync(credential); }
            catch (Exception) { /* The link worked. Only its saved copy in the Editor may be stale. */ }
#else
            await Task.CompletedTask;
#endif
        }

        private static FirebaseUserSnapshot Require(FirebaseUser user)
        {
            FirebaseUserSnapshot snapshot = Snapshot(user);
            if (snapshot == null) throw new FirebaseClientException(0, "no_user_returned");
            return snapshot;
        }

        private static FirebaseUserSnapshot Snapshot(FirebaseUser user)
        {
            if (user == null) return null;
            var providers = new List<string>();
            foreach (IUserInfo info in user.ProviderData)
                if (info != null && !string.IsNullOrEmpty(info.ProviderId)) providers.Add(info.ProviderId);
            return new FirebaseUserSnapshot(user.UserId, user.IsAnonymous, user.Email, providers);
        }

        // Turns every SDK failure into a code and a type name, so no message with a credential leaves the client.
        private static async Task<T> Guard<T>(Func<Task<T>> work)
        {
            try
            {
                return await work();
            }
            catch (FirebaseClientException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw FirebaseErrors.Translate(exception);
            }
        }

        /// <summary>The other account's credential, and the SDK exception whose result owns its data.</summary>
        private sealed class Conflict : IDisposable
        {
            private readonly FirebaseAccountLinkException _owner;

            public Conflict(Credential credential, FirebaseAccountLinkException owner)
            {
                Credential = credential;
                _owner = owner;
            }

            public Credential Credential { get; }

            public void Dispose()
            {
                Credential.Dispose();
                GC.KeepAlive(_owner);
            }
        }
    }
}
