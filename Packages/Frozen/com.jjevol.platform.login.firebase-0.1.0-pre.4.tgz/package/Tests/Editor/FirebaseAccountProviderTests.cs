using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using SdkLinkException = Firebase.Auth.FirebaseAccountLinkException;

namespace PlatformLibrary.Login.Firebase.Tests
{
    public sealed class FirebaseAccountProviderTests
    {
        private sealed class FakeClient : IFirebaseAuthClient
        {
            public FirebaseUserSnapshot CurrentUser { get; set; }
            public readonly List<string> Calls = new List<string>();
            public readonly List<string> Discarded = new List<string>();
            public FirebaseMethod LastMethod;
            public LoginCredential LastCredential;
            public bool LastForce;
            public int SignOuts;
            public bool Disposed;
            public TaskCompletionSource<FirebaseUserSnapshot> User;
            public TaskCompletionSource<string> Token;

            private Task<FirebaseUserSnapshot> NextUser(string call)
            {
                Calls.Add(call);
                User = new TaskCompletionSource<FirebaseUserSnapshot>();
                return User.Task;
            }

            public Task<FirebaseUserSnapshot> SignInAnonymouslyAsync() => NextUser("anonymous");

            public Task<FirebaseUserSnapshot> SignInAsync(FirebaseMethod method, LoginCredential credential)
            {
                LastMethod = method;
                LastCredential = credential;
                return NextUser("signin:" + method.ProviderId);
            }

            public Task<FirebaseUserSnapshot> LinkAsync(FirebaseMethod method, LoginCredential credential)
            {
                LastMethod = method;
                LastCredential = credential;
                return NextUser("link:" + method.ProviderId);
            }

            public Task<FirebaseUserSnapshot> SwitchAsync(string conflict) => NextUser("switch:" + conflict);
            public Task<FirebaseUserSnapshot> UnlinkAsync(string providerId) => NextUser("unlink:" + providerId);

            public Task<string> GetTokenAsync(bool forceRefresh)
            {
                Calls.Add("token:" + forceRefresh);
                LastForce = forceRefresh;
                Token = new TaskCompletionSource<string>();
                return Token.Task;
            }

            public void DiscardConflict(string conflict) => Discarded.Add(conflict ?? "*");

            public void SignOut()
            {
                SignOuts++;
                CurrentUser = null;
            }

            public void Dispose() => Disposed = true;
        }

        private static FirebaseUserSnapshot Guest(string uid = "guest-1") => new FirebaseUserSnapshot(uid, true, null, null);
        private static FirebaseUserSnapshot Social(string uid, params string[] providers) => new FirebaseUserSnapshot(uid, false, "player@example.com", providers);

        private static LoginCredential Google(string token = "google-token") => new LoginCredential(LoginMethod.Google, "google-sub", token);
        private static LoginCredential Apple(string nonce = "raw-nonce") => new LoginCredential(LoginMethod.Apple, "apple-sub", "apple-token", "auth-code", nonce);

        private FakeClient _client;
        private FirebaseAccountProvider _provider;
        private readonly List<AccountResult> _results = new List<AccountResult>();

        /// <summary>Records posted work and runs it only when asked, like Unity's main-thread queue.</summary>
        private sealed class QueueContext : SynchronizationContext
        {
            private readonly Queue<(SendOrPostCallback, object)> _work = new Queue<(SendOrPostCallback, object)>();
            public int Pending => _work.Count;
            public override void Post(SendOrPostCallback d, object state) => _work.Enqueue((d, state));
            public void RunAll()
            {
                while (_work.Count > 0)
                {
                    var (d, state) = _work.Dequeue();
                    d(state);
                }
            }
        }

        private SynchronizationContext _savedContext;

        [SetUp]
        public void SetUp()
        {
            // Unity's test thread has a context that posts continuations to a later frame.
            // Without one, the fake's answers arrive inside SetResult and the tests stay synchronous.
            _savedContext = SynchronizationContext.Current;
            SynchronizationContext.SetSynchronizationContext(null);
            _client = new FakeClient();
            _provider = new FirebaseAccountProvider(_client, "live");
            _results.Clear();
        }

        [TearDown]
        public void TearDown() => SynchronizationContext.SetSynchronizationContext(_savedContext);

        private AccountResult Last => _results[_results.Count - 1];

        [Test]
        public void AnswersComeBackOnTheCallersContext()
        {
            var context = new QueueContext();
            SynchronizationContext.SetSynchronizationContext(context);
            _provider.SignInGuest(_results.Add);
            Task.Run(() => _client.User.SetResult(Guest())).Wait();
            Assert.AreEqual(0, _results.Count);
            Assert.Greater(context.Pending, 0);

            context.RunAll();
            Assert.AreEqual(1, _results.Count);
            Assert.AreEqual("guest-1", Last.Account.UserId);
        }

        [Test]
        public void TheEnvironmentIsRequiredAndKept()
        {
            Assert.AreEqual("live", _provider.EnvironmentKey);
            Assert.Throws<ArgumentNullException>(() => new FirebaseAccountProvider(_client, null));
        }

        [Test]
        public void WithoutFirebaseTheProviderIsNotInitialized()
        {
            var provider = new FirebaseAccountProvider((IFirebaseAuthClient)null, "live");
            Assert.AreEqual(LoginFailure.NotInitialized, provider.Availability);
            Assert.IsNull(provider.Current);
            provider.SignInGuest(_results.Add);
            Assert.AreEqual(LoginFailure.NotInitialized, Last.Failure);
            LoginToken token = default;
            provider.GetToken(false, t => token = t);
            Assert.AreEqual(LoginFailure.NotInitialized, token.Failure);
        }

        [Test]
        public void TheCurrentUserBecomesAnAccountWithKnownMethods()
        {
            Assert.IsNull(_provider.Current);
            _client.CurrentUser = Social("u1", "google.com", "apple.com", "password", "google.com");
            LoginAccount account = _provider.Current;
            Assert.AreEqual("u1", account.UserId);
            Assert.IsFalse(account.IsGuest);
            Assert.AreEqual("player@example.com", account.Email);
            CollectionAssert.AreEqual(new[] { LoginMethod.Google, LoginMethod.Apple }, account.LinkedMethods);

            _client.CurrentUser = Guest();
            Assert.IsTrue(_provider.Current.IsGuest);
            Assert.AreEqual(0, _provider.Current.LinkedMethods.Count);
        }

        [Test]
        public void GuestSignInAnswersTheAnonymousUser()
        {
            _provider.SignInGuest(_results.Add);
            CollectionAssert.AreEqual(new[] { "anonymous" }, _client.Calls);
            _client.User.SetResult(Guest("g1"));
            Assert.IsTrue(Last.Success);
            Assert.AreEqual("g1", Last.Account.UserId);
            Assert.IsTrue(Last.Account.IsGuest);
        }

        [Test]
        public void SignInUsesTheMethodsFirebaseProvider()
        {
            _provider.SignIn(Google(), _results.Add);
            Assert.AreEqual("signin:google.com", _client.Calls[0]);
            Assert.AreEqual("google-token", _client.LastCredential.Token);
            _client.User.SetResult(Social("u1", "google.com"));
            Assert.IsTrue(Last.Success);
            CollectionAssert.AreEqual(new[] { LoginMethod.Google }, Last.Account.LinkedMethods);

            _provider.SignIn(Apple(), _results.Add);
            Assert.AreEqual("signin:apple.com", _client.Calls[1]);
            Assert.AreEqual("raw-nonce", _client.LastCredential.RawNonce);
        }

        [Test]
        public void BadCredentialsAreRejectedBeforeFirebase()
        {
            _provider.SignIn(null, _results.Add);
            Assert.AreEqual(LoginFailure.CredentialRejected, Last.Failure);
            Assert.AreEqual("token_missing", Last.Detail);

            _provider.SignIn(Apple(null), _results.Add);
            Assert.AreEqual(LoginFailure.CredentialRejected, Last.Failure);
            Assert.AreEqual("nonce_missing", Last.Detail);

            _provider.SignIn(new LoginCredential(new LoginMethod("steam"), "s", "ticket"), _results.Add);
            Assert.AreEqual(LoginFailure.Unsupported, Last.Failure);
            Assert.AreEqual("method_not_mapped", Last.Detail);

            Assert.AreEqual(0, _client.Calls.Count);
        }

        [Test]
        public void AddedMethodsSignInAndShowAsLinked()
        {
            var steam = new LoginMethod("steam");
            Assert.AreSame(_provider, _provider.AddMethod(steam, "oidc.steam", _ => null));
            _provider.SignIn(new LoginCredential(steam, "s", "ticket"), _results.Add);
            Assert.AreEqual("signin:oidc.steam", _client.Calls[0]);
            _client.User.SetResult(Social("u1", "oidc.steam"));
            CollectionAssert.AreEqual(new[] { steam }, Last.Account.LinkedMethods);
        }

        [Test]
        public void AddMethodRefusesGuestAndASharedProviderId()
        {
            Assert.Throws<ArgumentException>(() => _provider.AddMethod(LoginMethod.Guest, "anonymous", _ => null));
            Assert.Throws<ArgumentException>(() => _provider.AddMethod(LoginMethod.None, "x", _ => null));
            Assert.Throws<ArgumentException>(() => _provider.AddMethod(new LoginMethod("other"), "google.com", _ => null));
            Assert.Throws<ArgumentNullException>(() => _provider.AddMethod(new LoginMethod("other"), "", _ => null));
            Assert.Throws<ArgumentNullException>(() => _provider.AddMethod(new LoginMethod("other"), "x", null));
            Assert.DoesNotThrow(() => _provider.AddMethod(LoginMethod.Google, "google.com", _ => null));
        }

        [Test]
        public void RestoreChecksTheSavedSessionWithTheServer()
        {
            _client.CurrentUser = Social("u1", "google.com");
            _provider.Restore(LoginMethod.Google, _results.Add);
            CollectionAssert.AreEqual(new[] { "token:True" }, _client.Calls);
            Assert.AreEqual(0, _results.Count);
            _client.Token.SetResult("id-token");
            Assert.IsTrue(Last.Success);
            Assert.AreEqual("u1", Last.Account.UserId);
        }

        [Test]
        public void RestoreNeedsASessionOfTheSameMethod()
        {
            _provider.Restore(LoginMethod.Google, _results.Add);
            Assert.AreEqual(LoginFailure.NoSavedLogin, Last.Failure);
            Assert.AreEqual("no_saved_session", Last.Detail);

            _client.CurrentUser = Guest();
            _provider.Restore(LoginMethod.Google, _results.Add);
            Assert.AreEqual("saved_session_method_mismatch", Last.Detail);

            _client.CurrentUser = Social("u1", "google.com");
            _provider.Restore(LoginMethod.Guest, _results.Add);
            Assert.AreEqual("saved_session_method_mismatch", Last.Detail);
            _provider.Restore(new LoginMethod("steam"), _results.Add);
            Assert.AreEqual(LoginFailure.NoSavedLogin, Last.Failure);

            Assert.AreEqual(0, _client.Calls.Count);
        }

        [Test]
        public void RestoreRestoresAGuestWithoutCreatingOne()
        {
            _client.CurrentUser = Guest("g1");
            _provider.Restore(LoginMethod.Guest, _results.Add);
            _client.Token.SetResult("id-token");
            Assert.IsTrue(Last.Success);
            Assert.IsFalse(_client.Calls.Contains("anonymous"));
        }

        [Test]
        public void ADeletedAccountIsInvalid()
        {
            _client.CurrentUser = Social("u1", "google.com");
            _provider.Restore(LoginMethod.Google, _results.Add);
            _client.Token.SetException(new FirebaseClientException(14, "FirebaseException"));
            Assert.AreEqual(LoginFailure.AccountInvalid, Last.Failure);
            Assert.AreEqual(14, Last.ProviderCode);
            Assert.AreEqual("FirebaseException", Last.Detail);
        }

        [Test]
        public void FirebaseErrorsBecomeLoginFailures()
        {
            var expected = new Dictionary<int, LoginFailure>
            {
                [19] = LoginFailure.NoConnection,
                [14] = LoginFailure.AccountInvalid,
                [5] = LoginFailure.AccountInvalid,
                [17] = LoginFailure.AccountInvalid,
                [18] = LoginFailure.AccountInvalid,
                [4] = LoginFailure.CredentialRejected,
                [65] = LoginFailure.CredentialRejected,
                [10] = LoginFailure.AlreadyLinkedToOtherAccount,
                [6] = LoginFailure.AlreadyLinkedToOtherAccount,
                [58] = LoginFailure.Cancelled,
                [56] = LoginFailure.Cancelled,
                [13] = LoginFailure.ProviderError,
                [0] = LoginFailure.ProviderError
            };
            foreach (KeyValuePair<int, LoginFailure> pair in expected)
            {
                _provider.SignIn(Google(), _results.Add);
                _client.User.SetException(new FirebaseClientException(pair.Key, "FirebaseException"));
                Assert.AreEqual(pair.Value, Last.Failure, pair.Key.ToString());
                Assert.AreEqual(pair.Key, Last.ProviderCode);
            }

            _provider.SignIn(Google(), _results.Add);
            _client.User.SetException(new InvalidOperationException("secret token text"));
            Assert.AreEqual(LoginFailure.ProviderError, Last.Failure);
            Assert.AreEqual("InvalidOperationException", Last.Detail);
        }

        [Test]
        public void LinkNeedsASignedInUser()
        {
            _provider.Link(Google(), _results.Add);
            Assert.AreEqual(LoginFailure.NotSignedIn, Last.Failure);
            Assert.AreEqual(0, _client.Calls.Count);
        }

        [Test]
        public void LinkAnswersTheUpgradedAccount()
        {
            _client.CurrentUser = Guest("g1");
            _provider.Link(Apple(), _results.Add);
            Assert.AreEqual("link:apple.com", _client.Calls[0]);
            _client.User.SetResult(Social("g1", "apple.com"));
            Assert.IsTrue(Last.Success);
            Assert.AreEqual("g1", Last.Account.UserId);
            Assert.IsFalse(Last.Account.IsGuest);
        }

        [Test]
        public void OnlyGoogleLinksCanSwitchWithTheirOwnCredential()
        {
            // The SDK client makes a link's own credential again for a conflict only when the method says it can sign in again.
            _client.CurrentUser = Guest("g1");
            _provider.Link(Google(), _results.Add);
            Assert.IsTrue(_client.LastMethod.CanSignInAgain);
            _client.User.SetResult(Guest("g1"));

            _provider.Link(Apple(), _results.Add);
            Assert.IsFalse(_client.LastMethod.CanSignInAgain);
            _client.User.SetResult(Guest("g1"));

            var games = new LoginMethod("games");
            _provider.AddMethod(games, "playgames.google.com", _ => null);
            _provider.Link(new LoginCredential(games, "p", "server-auth-code"), _results.Add);
            Assert.AreEqual("link:playgames.google.com", _client.Calls[_client.Calls.Count - 1]);
            Assert.IsFalse(_client.LastMethod.CanSignInAgain);
            _client.User.SetResult(Guest("g1"));

            // A project that replaces the Google method still makes a Google credential.
            _provider.AddMethod(LoginMethod.Google, FirebaseAccountProvider.GoogleProviderId, _ => null);
            _provider.Link(Google(), _results.Add);
            Assert.IsTrue(_client.LastMethod.CanSignInAgain);
        }

        // What the SDK client throws for the SDK's link conflict, through the same translation as on a device.
        // The SDK's code is 10, read as 10 when it is 0. A non-null conflict stands in for the credential only the device SDK fills in.
        private static FirebaseClientException SdkConflict(int code = 10, string conflict = "conflict-1") =>
            FirebaseErrors.TranslateLink(new AggregateException(new SdkLinkException(code, "secret", null)), _ => conflict);

        [Test]
        public void ACredentialOfAnotherAccountIsAConflict()
        {
            _client.CurrentUser = Guest("g1");
            _provider.Link(Google(), _results.Add);
            _client.User.SetException(SdkConflict());
            Assert.AreEqual(LoginFailure.AlreadyLinkedToOtherAccount, Last.Failure);
            Assert.AreEqual("conflict-1", Last.Conflict);
            Assert.AreEqual(10, Last.ProviderCode);

            _provider.SwitchToLinkedAccount("conflict-1", _results.Add);
            Assert.AreEqual("switch:conflict-1", _client.Calls[1]);
            _client.User.SetResult(Social("owner", "google.com"));
            Assert.AreEqual("owner", Last.Account.UserId);

            _provider.DiscardConflict("conflict-2");
            _provider.DiscardConflict(null);
            CollectionAssert.AreEqual(new[] { "conflict-2" }, _client.Discarded);
        }

        [Test]
        public void TheSdksConflictReachesTheManagerAsAConflict() => ConflictReachesTheManager(10);

        [Test]
        public void ASdkConflictWithoutACodeReachesTheManagerAsAConflict() => ConflictReachesTheManager(0);

        private void ConflictReachesTheManager(int code)
        {
            // The device log was "Link failed. Type:GOOGLE, Failure:ProviderError, ProviderCode:0, Detail:FirebaseAccountLinkException".
            var store = new Dictionary<string, string>();
            var session = new LoginSession(new ImmediateHost(), new MemoryStore(store), _ => { }, _ => { }, _ => { });
            var google = new OneShotProvider();
            session.AddProvider(google);
            session.SetAccountProvider(_provider);
            session.SignIn(LoginMethod.Guest, _ => { });
            _client.CurrentUser = Guest("g1");
            _client.User.SetResult(_client.CurrentUser);

            LoginResult linked = default;
            session.Link(LoginMethod.Google, r => linked = r);
            google.Answer(LoginCredentialResult.Succeeded(Google()));
            Assert.AreEqual("link:google.com", _client.Calls[1]);
            _client.User.SetException(SdkConflict(code));

            Assert.AreEqual(LoginFailure.AlreadyLinkedToOtherAccount, linked.Failure);
            Assert.AreEqual(10, linked.ProviderCode);
            Assert.AreEqual("FirebaseAccountLinkException", linked.Detail);
            Assert.IsTrue(session.HasLinkConflict);

            LoginResult switched = default;
            session.SwitchToLinkedAccount(r => switched = r);
            Assert.AreEqual("switch:conflict-1", _client.Calls[2]);
            _client.CurrentUser = Social("owner", "google.com");
            _client.User.SetResult(_client.CurrentUser);
            Assert.IsTrue(switched.Success);
            Assert.AreEqual("owner", session.Account.UserId);
            Assert.IsFalse(session.HasLinkConflict);
        }

        [Test]
        public void AConflictWithoutACredentialFailsWithoutAChoice()
        {
            _client.CurrentUser = Guest("g1");
            _provider.Link(Google(), _results.Add);
            _client.User.SetException(SdkConflict(conflict: null));
            Assert.AreEqual(LoginFailure.AlreadyLinkedToOtherAccount, Last.Failure);
            Assert.IsNull(Last.Conflict);
            Assert.AreEqual(10, Last.ProviderCode);
            Assert.AreEqual(FirebaseErrors.NoConflictCredential, Last.Detail);
        }

        [Test]
        public void AnAlreadyLinkedProviderOnTheSameUserIsSuccess()
        {
            _client.CurrentUser = Guest("g1");
            _provider.Link(Google(), _results.Add);
            _client.CurrentUser = Social("g1", "google.com");
            _client.User.SetException(new FirebaseClientException(15, "FirebaseException"));
            Assert.IsTrue(Last.Success);
            Assert.AreEqual("already_linked", Last.Detail);

            _client.CurrentUser = Guest("g1");
            _provider.Link(Google(), _results.Add);
            _client.User.SetException(new FirebaseClientException(15, "FirebaseException"));
            Assert.AreEqual(LoginFailure.ProviderError, Last.Failure);
            Assert.AreEqual(15, Last.ProviderCode);
        }

        [Test]
        public void ALateConflictAfterDisposeIsDiscarded()
        {
            _client.CurrentUser = Guest("g1");
            _provider.Link(Google(), _results.Add);
            _provider.Dispose();
            _client.User.SetException(SdkConflict());
            Assert.AreEqual(0, _results.Count);
            CollectionAssert.AreEqual(new[] { "conflict-1" }, _client.Discarded);
        }

        [Test]
        public void ACallFinishedAfterCancelStillAnswers()
        {
            // Firebase cannot stop the call, so the manager must learn which user it left signed in.
            _provider.SignIn(Google(), _results.Add);
            _provider.Cancel();
            _client.User.SetResult(Social("u1", "google.com"));
            Assert.AreEqual(1, _results.Count);
            Assert.AreEqual("u1", Last.Account.UserId);
        }

        [Test]
        public void UnlinkUsesTheFirebaseProviderId()
        {
            _provider.Unlink(LoginMethod.Google, _results.Add);
            Assert.AreEqual(LoginFailure.NotSignedIn, Last.Failure);
            _provider.Unlink(new LoginMethod("steam"), _results.Add);
            Assert.AreEqual(LoginFailure.Unsupported, Last.Failure);

            _client.CurrentUser = Social("u1", "google.com", "apple.com");
            _provider.Unlink(LoginMethod.Apple, _results.Add);
            Assert.AreEqual("unlink:apple.com", _client.Calls[0]);
            _client.User.SetResult(Social("u1", "google.com"));
            CollectionAssert.AreEqual(new[] { LoginMethod.Google }, Last.Account.LinkedMethods);
        }

        [Test]
        public void TokensComeFromTheCurrentUser()
        {
            LoginToken token = default;
            _provider.GetToken(false, t => token = t);
            Assert.AreEqual(LoginFailure.NotSignedIn, token.Failure);

            _client.CurrentUser = Guest();
            _provider.GetToken(true, t => token = t);
            Assert.IsTrue(_client.LastForce);
            _client.Token.SetResult("id-token");
            Assert.AreEqual("id-token", token.Value);

            _provider.GetToken(false, t => token = t);
            _client.Token.SetException(new FirebaseClientException(19, "FirebaseException"));
            Assert.AreEqual(LoginFailure.NoConnection, token.Failure);
            Assert.IsNull(token.Value);

            _provider.GetToken(false, t => token = t);
            _client.Token.SetException(new FirebaseClientException(0, "session_changed"));
            Assert.AreEqual(LoginFailure.SessionChanged, token.Failure);

            _provider.GetToken(false, t => token = t);
            _client.Token.SetResult("");
            Assert.AreEqual(LoginFailure.ProviderError, token.Failure);
        }

        [Test]
        public void SignOutAndDisposeDifferForTheSavedAccount()
        {
            _client.CurrentUser = Guest();
            _provider.SignOut();
            Assert.AreEqual(1, _client.SignOuts);

            _client.CurrentUser = Guest();
            _provider.SignInGuest(_results.Add);
            _provider.Dispose();
            _client.User.SetResult(Guest());
            Assert.AreEqual(0, _results.Count);
            Assert.IsTrue(_client.Disposed);
            Assert.AreEqual(1, _client.SignOuts);
            Assert.AreEqual(LoginFailure.NotInitialized, _provider.Availability);
            Assert.IsNull(_provider.Current);
        }

        [Test]
        public void TheManagerSignsInWithFirebaseAfterThePlatformCredential()
        {
            // The login flow: the method provider gets a Google token, then Firebase signs in with it.
            var store = new Dictionary<string, string>();
            var session = new LoginSession(new ImmediateHost(), new MemoryStore(store), _ => { }, _ => { }, _ => { });
            var google = new OneShotProvider();
            session.AddProvider(google);
            session.SetAccountProvider(_provider);
            LoginResult result = default;
            session.SignIn(LoginMethod.Google, r => result = r);

            google.Answer(LoginCredentialResult.Succeeded(Google()));
            Assert.AreEqual("signin:google.com", _client.Calls[0]);
            _client.CurrentUser = Social("firebase-uid", "google.com");
            _client.User.SetResult(_client.CurrentUser);

            Assert.IsTrue(result.Success);
            Assert.AreEqual("firebase-uid", result.Account.UserId);
            Assert.AreEqual(LoginMethod.Google, result.Account.Method);
            Assert.AreEqual("google", store[LoginStateKeys.LastMethod("live")]);
        }

        [Test]
        public void AnOfflineRestoreKeepsTheLastMethod()
        {
            var store = new Dictionary<string, string> { [LoginStateKeys.LastMethod("live")] = "google" };
            var session = new LoginSession(new ImmediateHost(), new MemoryStore(store), _ => { }, _ => { }, _ => { });
            var google = new OneShotProvider();
            session.AddProvider(google);
            session.SetAccountProvider(_provider);
            _client.CurrentUser = Social("a", "google.com");
            LoginResult result = default;
            session.RestoreSession(r => result = r);

            _client.Token.SetException(new FirebaseClientException(19, "FirebaseException"));
            Assert.AreEqual(LoginFailure.NoConnection, result.Failure);
            Assert.IsFalse(google.Asked);
            Assert.AreEqual("google", store[LoginStateKeys.LastMethod("live")]);
        }

        [Test]
        public void AfterACancelTheManagerFollowsTheUserFirebaseSignedInLate()
        {
            var store = new Dictionary<string, string>();
            var session = new LoginSession(new ImmediateHost(), new MemoryStore(store), _ => { }, _ => { }, _ => { });
            var google = new OneShotProvider();
            session.AddProvider(google);
            session.SetAccountProvider(_provider);
            session.SignIn(LoginMethod.Google, _ => { });
            google.Answer(LoginCredentialResult.Succeeded(Google()));
            _client.CurrentUser = Social("a", "google.com");
            _client.User.SetResult(_client.CurrentUser);
            Assert.AreEqual("a", session.Account.UserId);

            LoginResult cancelled = default;
            session.SignIn(LoginMethod.Google, r => cancelled = r);
            google.Answer(LoginCredentialResult.Succeeded(Google("other-token")));
            session.Cancel();
            Assert.AreEqual(LoginFailure.Cancelled, cancelled.Failure);
            Assert.AreEqual("a", session.Account.UserId);

            // Firebase finished the sign-in anyway. The manager must not keep reporting "a" while Firebase holds "b".
            _client.CurrentUser = Social("b", "google.com");
            _client.User.SetResult(_client.CurrentUser);
            Assert.AreEqual("b", session.Account.UserId);
            Assert.AreEqual(LoginFailure.Cancelled, cancelled.Failure);
        }

        private sealed class ImmediateHost : ILoginHost
        {
            public void Post(Action action) => action();
            public Action Schedule(float seconds, Action action) => () => { };
            public void LogWarning(string message) { }
            public void LogException(Exception exception) => throw exception;
        }

        private sealed class MemoryStore : ILoginStateStore
        {
            private readonly Dictionary<string, string> _values;
            public MemoryStore(Dictionary<string, string> values) => _values = values;
            public string Get(string key) => _values.TryGetValue(key, out string value) ? value : null;
            public void Set(string key, string value) => _values[key] = value;
            public void Delete(string key) => _values.Remove(key);
        }

        private sealed class OneShotProvider : ILoginProvider
        {
            private Action<LoginCredentialResult> _callback;
            public LoginMethod Method => LoginMethod.Google;
            public LoginFailure Availability => LoginFailure.None;
            public event Action CredentialRevoked { add { } remove { } }
            public bool Asked;
            public void RequestCredential(LoginCredentialRequest request, Action<LoginCredentialResult> callback)
            {
                Asked = true;
                _callback = callback;
            }
            public void Cancel() { }
            public void Answer(LoginCredentialResult result) => _callback(result);
        }
    }
}
