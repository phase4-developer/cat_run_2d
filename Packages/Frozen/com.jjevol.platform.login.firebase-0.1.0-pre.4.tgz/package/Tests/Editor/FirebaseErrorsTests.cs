using System;
using System.Threading.Tasks;
using Firebase;
using Firebase.Auth;
using NUnit.Framework;

namespace PlatformLibrary.Login.Firebase.Tests
{
    /// <summary>
    /// The layer that turns SDK exceptions into <see cref="FirebaseClientException"/>, fed with the exception types of the
    /// Firebase Auth SDK the Host installs (Firebase.Auth.dll 13.17.0). The tests build the exceptions: no Firebase project or
    /// native library runs in the Editor, so a conflict credential the SDK fills in on a device cannot be made here.
    /// </summary>
    public sealed class FirebaseErrorsTests
    {
        private const int CredentialAlreadyInUse = 10;
        private const int ProviderAlreadyLinked = 15;
        private const int NetworkRequestFailed = 19;
        private const string Secret = "secret credential text";

        private enum Path { Thrown, Awaited, Waited, NestedAggregate }

        // The SDK sets 10. 0 is what the old client logged on the device, so it is checked as well.
        private static readonly int[] Codes = { CredentialAlreadyInUse, 0 };
        private static readonly Path[] Paths = { Path.Thrown, Path.Awaited, Path.Waited, Path.NestedAggregate };

        // The SDK creates this for a link whose credential belongs to another account, with a null AuthResult only here.
        private static FirebaseAccountLinkException SdkConflict(int code) => new FirebaseAccountLinkException(code, Secret, null);

        // How a failure of an SDK task reaches the client.
        private static Exception Reach(Exception exception, Path path)
        {
            var source = new TaskCompletionSource<AuthResult>();
            source.SetException(exception);
            try
            {
                switch (path)
                {
                    case Path.Thrown: return exception;
                    case Path.Awaited: source.Task.GetAwaiter().GetResult(); break;
                    case Path.Waited: source.Task.Wait(); break;
                    case Path.NestedAggregate: return new AggregateException(new InvalidOperationException("outer"), new AggregateException(exception));
                }
            }
            catch (Exception caught)
            {
                return caught;
            }
            throw new InvalidOperationException("The task did not fail.");
        }

        [Test]
        public void TheSdksLinkExceptionIsNotAFirebaseException()
        {
            // The old client read codes only from FirebaseException, so every link conflict on a device became code 0.
            Assert.IsFalse(typeof(FirebaseException).IsAssignableFrom(typeof(FirebaseAccountLinkException)));
            Assert.AreEqual(CredentialAlreadyInUse, (int)AuthError.CredentialAlreadyInUse);
        }

        [Test]
        public void ALinkConflictWithACredentialAnswersAHandle()
        {
            foreach (int code in Codes)
            foreach (Path path in Paths)
            {
                string at = "code " + code + ", " + path;
                FirebaseAccountLinkException sdk = SdkConflict(code);
                FirebaseAccountLinkException held = null;
                FirebaseClientException result = FirebaseErrors.TranslateLink(Reach(sdk, path), link =>
                {
                    held = link;
                    return "conflict-1";
                });

                Assert.AreSame(sdk, held, at);
                Assert.AreEqual(CredentialAlreadyInUse, result.Code, at);
                Assert.AreEqual("conflict-1", result.Conflict, at);
                Assert.AreEqual("FirebaseAccountLinkException", result.Type, at);
                Assert.AreEqual(LoginFailure.AlreadyLinkedToOtherAccount, FirebaseAccountProvider.ToFailure(result.Code), at);
                StringAssert.DoesNotContain("secret", result.Message, at);
            }
        }

        [Test]
        public void ALinkConflictWithoutACredentialCannotSwitch()
        {
            foreach (int code in Codes)
            foreach (Path path in Paths)
            {
                string at = "code " + code + ", " + path;
                FirebaseClientException result = FirebaseErrors.TranslateLink(Reach(SdkConflict(code), path), _ => null);

                Assert.AreEqual(CredentialAlreadyInUse, result.Code, at);
                Assert.IsNull(result.Conflict, at);
                Assert.AreEqual(FirebaseErrors.NoConflictCredential, result.Type, at);
                Assert.AreEqual(LoginFailure.AlreadyLinkedToOtherAccount, FirebaseAccountProvider.ToFailure(result.Code), at);
            }
        }

        [Test]
        public void AConflictWithoutAnSdkResultHasNoCredential()
        {
            // Reads the SDK's own UserInfo getter: with no AuthResult it answers null without calling the native library.
            Assert.IsNull(SdkConflict(CredentialAlreadyInUse).UserInfo);
            Assert.IsNull(FirebaseErrors.ConflictCredential(SdkConflict(CredentialAlreadyInUse)));
            Assert.IsNull(FirebaseErrors.ConflictCredential(null));

            FirebaseClientException result = FirebaseErrors.TranslateLink(SdkConflict(CredentialAlreadyInUse),
                link => FirebaseErrors.ConflictCredential(link) == null ? null : "conflict-1");
            Assert.IsNull(result.Conflict);
            Assert.AreEqual(CredentialAlreadyInUse, result.Code);
        }

        [Test]
        public void WithoutAnAttachedCredentialTheLinksOwnCredentialIsAsked()
        {
            // The device case of 2026-11-09: the Android SDK attached no credential to a Google link conflict.
            int asked = 0;
            Assert.IsNull(FirebaseErrors.SwitchCredential(SdkConflict(CredentialAlreadyInUse), () =>
            {
                asked++;
                return null;
            }));
            Assert.AreEqual(1, asked);

            // A credential that cannot be made again leaves nothing to switch with, and does not throw.
            Assert.IsNull(FirebaseErrors.SwitchCredential(SdkConflict(CredentialAlreadyInUse), () => throw new InvalidOperationException(Secret)));
            Assert.IsNull(FirebaseErrors.SwitchCredential(SdkConflict(0), null));
            Assert.IsNull(FirebaseErrors.SwitchCredential(null, () => null));
        }

        [Test]
        public void AOneTimeCredentialIsNotMadeAgainForASwitch()
        {
            // The SDK client's choice for a conflict without an SDK credential. The delegate stands in for the SDK's credential factory.
            int made = 0;
            Func<LoginCredential, Credential> create = _ =>
            {
                made++;
                return null;
            };
            var credential = new LoginCredential(LoginMethod.Google, "sub", "token");

            var google = new FirebaseMethod(LoginMethod.Google, "google.com", create);
            Func<Credential> again = FirebaseSdkAuthClient.LinkCredentialAgain(google, credential);
            Assert.IsNotNull(again);
            Assert.AreEqual(0, made);
            Assert.IsNull(FirebaseErrors.SwitchCredential(SdkConflict(CredentialAlreadyInUse), again));
            Assert.AreEqual(1, made);

            // Apple and added methods hold no conflict without the SDK's credential: their token, code or nonce works once.
            foreach (FirebaseMethod once in new[]
                     {
                         new FirebaseMethod(LoginMethod.Apple, "apple.com", create),
                         new FirebaseMethod(new LoginMethod("games"), "playgames.google.com", create),
                     })
            {
                Assert.IsFalse(once.CanSignInAgain, once.ProviderId);
                Assert.IsNull(FirebaseSdkAuthClient.LinkCredentialAgain(once, credential), once.ProviderId);
                FirebaseClientException result = FirebaseErrors.TranslateLink(SdkConflict(CredentialAlreadyInUse),
                    link => FirebaseErrors.SwitchCredential(link, FirebaseSdkAuthClient.LinkCredentialAgain(once, credential)) == null ? null : "conflict-1");
                Assert.IsNull(result.Conflict, once.ProviderId);
                Assert.AreEqual(FirebaseErrors.NoConflictCredential, result.Type, once.ProviderId);
            }
            Assert.AreEqual(1, made);
            Assert.IsNull(FirebaseSdkAuthClient.LinkCredentialAgain(null, credential));
        }

        [Test]
        public void OtherLinkFailuresKeepTheirCodeAndHoldNothing()
        {
            int held = 0;
            Func<FirebaseAccountLinkException, string> hold = _ =>
            {
                held++;
                return "conflict-1";
            };

            FirebaseClientException linked = FirebaseErrors.TranslateLink(Reach(new FirebaseException(ProviderAlreadyLinked, Secret), Path.Awaited), hold);
            Assert.AreEqual(ProviderAlreadyLinked, linked.Code);
            Assert.AreEqual("FirebaseException", linked.Type);
            Assert.IsNull(linked.Conflict);

            // Code 10 on a plain FirebaseException is still the error, but the SDK attached no credential to it.
            FirebaseClientException inUse = FirebaseErrors.TranslateLink(Reach(new FirebaseException(CredentialAlreadyInUse, Secret), Path.Waited), hold);
            Assert.AreEqual(CredentialAlreadyInUse, inUse.Code);
            Assert.IsNull(inUse.Conflict);

            FirebaseClientException other = FirebaseErrors.TranslateLink(new InvalidOperationException(Secret), hold);
            Assert.AreEqual(0, other.Code);
            Assert.AreEqual("InvalidOperationException", other.Type);
            Assert.AreEqual(0, held);
        }

        [Test]
        public void EveryCallReadsBothSdkExceptionTypes()
        {
            foreach (Path path in Paths)
            {
                string at = path.ToString();
                FirebaseClientException network = FirebaseErrors.Translate(Reach(new FirebaseException(NetworkRequestFailed, Secret), path));
                Assert.AreEqual(NetworkRequestFailed, network.Code, at);
                Assert.AreEqual("FirebaseException", network.Type, at);
                Assert.AreEqual(LoginFailure.NoConnection, FirebaseAccountProvider.ToFailure(network.Code), at);

                // Sign-in and unlink go through the same SDK task code, so a link exception there keeps its code too.
                FirebaseClientException conflict = FirebaseErrors.Translate(Reach(SdkConflict(CredentialAlreadyInUse), path));
                Assert.AreEqual(CredentialAlreadyInUse, conflict.Code, at);
                Assert.AreEqual("FirebaseAccountLinkException", conflict.Type, at);
                Assert.IsNull(conflict.Conflict, at);
                StringAssert.DoesNotContain("secret", network.Message + conflict.Message, at);
            }
        }

        [Test]
        public void TranslateFindsTheSdkExceptionInsideOtherWrappers()
        {
            var inner = new InvalidOperationException("wrapper", new FirebaseException(NetworkRequestFailed, Secret));
            Assert.AreEqual(NetworkRequestFailed, FirebaseErrors.Translate(inner).Code);

            var mixed = new AggregateException(new TimeoutException(), SdkConflict(CredentialAlreadyInUse));
            Assert.AreEqual(CredentialAlreadyInUse, FirebaseErrors.Translate(mixed).Code);

            FirebaseClientException plain = FirebaseErrors.Translate(new AggregateException(new TimeoutException(Secret)));
            Assert.AreEqual(0, plain.Code);
            Assert.AreEqual("TimeoutException", plain.Type);

            var client = new FirebaseClientException(0, "no_current_user");
            Assert.AreSame(client, FirebaseErrors.Translate(client));
        }
    }
}
