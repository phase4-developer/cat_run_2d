# Changelog

## 0.1.0-pre.2 - 2026-11-08

- A development build (`Debug.isDebugBuild`, and the Editor) now loads Google's sample test units for every format, including a unit passed in the request. Release builds use the project's units as before.
- `AdMobAdSettings` has a new last parameter, `useTestAdUnitsInDevelopmentBuild`, default `true`. False uses the project's units in development builds too.
- New `AdMobTestAdUnits` with Google's Android and iOS sample units, and `AdMobAdProvider.UsesTestAdUnits`.

## 0.1.0-pre.1 - 2026-11-08

New design, per `Docs/PlatformAdsAnalytics/Design.md`. It replaces the mobile library's `ADManager`. The class name, Singleton and GUID are not kept.

- `AdMobAdProvider` implements `IAdProvider`. It is a plain object the project creates, not a Singleton.
- The `AD_PROVIDER_ADX` and `PLATFORM_ADS_DISABLED` selection is gone.
- SDK load codes become `AdFailure`, with separate Android and iOS tables.
- `childDirectedTreatment` is now a setting. Its default keeps the source behavior.

Unity tests run in `Hosts/AdsSdkValidationHost`, which needs a local plugin copy. See `Docs/PlatformAdsAnalytics/AdsReport.md`.
