# JJEvol Platform Ads AdMob

Local validation candidate 0.1.0-pre.2. Google Mobile Ads provider for `com.jjevol.platform.ads`: reward ads, interstitial ads, banners, the consent form and revenue events.

The code is user-authored, confirmed by the user on 2026-11-08. No SDK binary, App ID or project ad unit is included. The only units in the package are Google's public sample units in `AdMobTestAdUnits`.

## Install

The Google Mobile Ads Unity plugin is required and is not a package dependency. Install it in the consumer project. This package was written against plugin 10.7.0, and its assembly references `GoogleMobileAds.dll`, `GoogleMobileAds.Core.dll`, `GoogleMobileAds.Common.dll` and `GoogleMobileAds.Ump.dll`. Without them the project does not compile. The App ID goes in the plugin's own settings asset.

The assembly exists only in the Editor, Android and iOS. A project that also targets another platform guards this code in its own start code.

Installing this package does not start anything. The project registers the provider:

```csharp
var settings = new AdMobAdSettings(
    () => table.RewardAdUnitId,
    () => table.InterstitialAdUnitId,
    () => table.BannerAdUnitId);

AdManager.SetProvider(new AdMobAdProvider(settings));
AdManager.Initialize();
```

Ad units are functions, read on every request, so they may come from a table loaded later. Store differences and any other selection stay in the project.

## Settings

| Value | Default | Note |
|---|---|---|
| Rewarded, interstitial and banner ad unit | Empty | An empty unit answers `InvalidAdUnit`. |
| `childDirectedTreatment` | `true` | Tags every request as child-directed, as the source library did. This limits ads and revenue, so choose it for the game's audience. |
| `useTestAdUnitsInDevelopmentBuild` | `true` | In a development build every request uses a Google test unit. See below. |

## Test ads in development builds

When `Debug.isDebugBuild` is true (a Development Build, and always in the Editor), the provider loads Google's sample units from `AdMobTestAdUnits` instead of the project's units. They always serve test ads, so a device test cannot show a real ad or earn invalid revenue. A unit passed in `AdRequest` is replaced too. `UsesTestAdUnits` tells whether this is on, and `Initialize` logs it once.

| Format | Android | iOS |
|---|---|---|
| Rewarded | `ca-app-pub-3940256099942544/5224354917` | `ca-app-pub-3940256099942544/1712485313` |
| Interstitial | `ca-app-pub-3940256099942544/1033173712` | `ca-app-pub-3940256099942544/4411468910` |
| Banner (fixed size) | `ca-app-pub-3940256099942544/6300978111` | `ca-app-pub-3940256099942544/2934735716` |

iOS units are used when the build target is iOS, Android units otherwise. A release build always uses the project's units. To test the real units in a development build, pass `useTestAdUnitsInDevelopmentBuild: false`; Google then expects the device to be registered as a test device in AdMob. Because the project's units are not read in a development build, an empty unit is only caught in a release build.

## Requests

Requests carry the keyword `game`. Banners use `AdSize.Banner` at the bottom of the screen.

## Behavior

`Initialize` updates consent, shows the form if it is required, then starts the SDK. A failed consent update or form is logged and the start continues. If consent still does not allow requests, initialization fails with `ConsentRequired` and can be retried.

Load errors become `AdFailure` by platform, because the same number differs between Android and iOS. Every show error becomes `ShowFailed`. The SDK code stays in `ProviderCode`.

| `AdFailure` | Android | iOS |
|---|---|---|
| `InvalidAdUnit` | 1, 10 | 0 |
| `Network` | 2 | 2 |
| `NoFill` | 3, 9 | 1, 9 |
| `Timeout` | | 5 |
| `ProviderError` | Others | Others |

Server verification values are set when the ad shows, so a preloaded ad serves any user.

## Validation

Tests are in `Tests/Editor`. They need the plugin, so this package is excluded from `Tools/Validate-Current.ps1`. See `Docs/PlatformAdsAnalytics/AdsReport.md` for what has run. Real ads on a device are NOT_RUN.
