using NUnit.Framework;

namespace PlatformLibrary.Ads.AdMob.Tests
{
    public sealed class AdMobFailureMapTests
    {
        [Test]
        public void AndroidCodesMapToTheirReasons()
        {
            Assert.That(AdMobFailureMap.FromAndroidLoadError(0), Is.EqualTo(AdFailure.ProviderError));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(1), Is.EqualTo(AdFailure.InvalidAdUnit));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(2), Is.EqualTo(AdFailure.Network));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(3), Is.EqualTo(AdFailure.NoFill));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(8), Is.EqualTo(AdFailure.ProviderError));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(9), Is.EqualTo(AdFailure.NoFill));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(10), Is.EqualTo(AdFailure.InvalidAdUnit));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(11), Is.EqualTo(AdFailure.ProviderError));
        }

        [Test]
        public void IosCodesMapToTheirReasons()
        {
            Assert.That(AdMobFailureMap.FromIosLoadError(0), Is.EqualTo(AdFailure.InvalidAdUnit));
            Assert.That(AdMobFailureMap.FromIosLoadError(1), Is.EqualTo(AdFailure.NoFill));
            Assert.That(AdMobFailureMap.FromIosLoadError(2), Is.EqualTo(AdFailure.Network));
            Assert.That(AdMobFailureMap.FromIosLoadError(3), Is.EqualTo(AdFailure.ProviderError));
            Assert.That(AdMobFailureMap.FromIosLoadError(5), Is.EqualTo(AdFailure.Timeout));
            Assert.That(AdMobFailureMap.FromIosLoadError(9), Is.EqualTo(AdFailure.NoFill));
            Assert.That(AdMobFailureMap.FromIosLoadError(11), Is.EqualTo(AdFailure.ProviderError));
        }

        [Test]
        public void SameNumberMeansDifferentThingsPerPlatform()
        {
            Assert.That(AdMobFailureMap.FromAndroidLoadError(1), Is.Not.EqualTo(AdMobFailureMap.FromIosLoadError(1)));
            Assert.That(AdMobFailureMap.FromAndroidLoadError(3), Is.Not.EqualTo(AdMobFailureMap.FromIosLoadError(3)));
        }

        [Test]
        public void UnknownCodesAreProviderErrors()
        {
            Assert.That(AdMobFailureMap.FromAndroidLoadError(-1), Is.EqualTo(AdFailure.ProviderError));
            Assert.That(AdMobFailureMap.FromIosLoadError(999), Is.EqualTo(AdFailure.ProviderError));
        }
    }
}
