using System;
using GoogleMobileAds.Ump.Api;
using NUnit.Framework;

namespace PlatformLibrary.Ads.AdMob.Tests
{
    public sealed class AdMobAdProviderTests
    {
        private AdMobAdProvider _provider;

        [SetUp]
        public void SetUp()
        {
            ConsentInformation.Reset();
            _provider = new AdMobAdProvider(new AdMobAdSettings(() => "reward", () => "interstitial", () => "banner"));
        }

        [TearDown]
        public void TearDown() => ConsentInformation.Reset();

        [Test]
        public void MissingSettingsAreRejected()
        {
            Assert.Throws<ArgumentNullException>(() => new AdMobAdProvider(null));
        }

        [Test]
        public void MissingUnitsReadAsEmpty()
        {
            var settings = new AdMobAdSettings(null);

            Assert.That(settings.RewardedAdUnitId(), Is.Empty);
            Assert.That(settings.InterstitialAdUnitId(), Is.Empty);
            Assert.That(settings.BannerAdUnitId(), Is.Empty);
        }

        [Test]
        public void ChildDirectedTreatmentDefaultsToTheSourceBehavior()
        {
            Assert.That(new AdMobAdSettings(null).ChildDirectedTreatment, Is.True);
        }

        [Test]
        public void UnitsComeFromTheSettingsOnEveryRead()
        {
            string unit = "first";
            var provider = new AdMobAdProvider(new AdMobAdSettings(() => unit), isDevelopmentBuild: false);

            Assert.That(provider.RewardAdUnitId, Is.EqualTo("first"));
            unit = "second";
            Assert.That(provider.RewardAdUnitId, Is.EqualTo("second"));
        }

        [Test]
        public void TestUnitsAreTheDefaultSetting()
        {
            Assert.That(new AdMobAdSettings(null).UseTestAdUnitsInDevelopmentBuild, Is.True);
        }

        [Test]
        public void DevelopmentBuildUsesGoogleTestUnits()
        {
            var provider = new AdMobAdProvider(RealUnits(), isDevelopmentBuild: true);

            Assert.That(provider.UsesTestAdUnits, Is.True);
            Assert.That(provider.RewardAdUnitId, Is.EqualTo(AdMobTestAdUnits.Rewarded));
            Assert.That(provider.InterstitialAdUnitId, Is.EqualTo(AdMobTestAdUnits.Interstitial));
            Assert.That(provider.BannerAdUnitId, Is.EqualTo(AdMobTestAdUnits.Banner));
        }

        [Test]
        public void DevelopmentBuildReplacesAUnitPassedInTheRequest()
        {
            var provider = new AdMobAdProvider(RealUnits(), isDevelopmentBuild: true);
            var request = new AdRequest(adUnitId: "explicit-real");

            Assert.That(provider.RewardUnitFor(request), Is.EqualTo(AdMobTestAdUnits.Rewarded));
            Assert.That(provider.InterstitialUnitFor(request), Is.EqualTo(AdMobTestAdUnits.Interstitial));
            Assert.That(provider.BannerUnitFor(request), Is.EqualTo(AdMobTestAdUnits.Banner));
        }

        [Test]
        public void ReleaseBuildUsesTheProjectUnits()
        {
            var provider = new AdMobAdProvider(RealUnits(), isDevelopmentBuild: false);
            var request = new AdRequest(adUnitId: "explicit-real");

            Assert.That(provider.UsesTestAdUnits, Is.False);
            Assert.That(provider.RewardAdUnitId, Is.EqualTo("real-reward"));
            Assert.That(provider.InterstitialAdUnitId, Is.EqualTo("real-interstitial"));
            Assert.That(provider.BannerAdUnitId, Is.EqualTo("real-banner"));
            Assert.That(provider.RewardUnitFor(request), Is.EqualTo("explicit-real"));
            Assert.That(provider.InterstitialUnitFor(request), Is.EqualTo("explicit-real"));
            Assert.That(provider.BannerUnitFor(request), Is.EqualTo("explicit-real"));
        }

        [Test]
        public void TurningTestUnitsOffUsesTheProjectUnitsInADevelopmentBuild()
        {
            var settings = new AdMobAdSettings(() => "real-reward", () => "real-interstitial", () => "real-banner",
                useTestAdUnitsInDevelopmentBuild: false);
            var provider = new AdMobAdProvider(settings, isDevelopmentBuild: true);
            var request = new AdRequest(adUnitId: "explicit-real");

            Assert.That(provider.UsesTestAdUnits, Is.False);
            Assert.That(provider.RewardAdUnitId, Is.EqualTo("real-reward"));
            Assert.That(provider.InterstitialAdUnitId, Is.EqualTo("real-interstitial"));
            Assert.That(provider.BannerAdUnitId, Is.EqualTo("real-banner"));
            Assert.That(provider.RewardUnitFor(request), Is.EqualTo("explicit-real"));
        }

        [Test]
        public void TheEditorCountsAsADevelopmentBuild()
        {
            Assert.That(_provider.UsesTestAdUnits, Is.True);
        }

        [Test]
        public void TestUnitsAreGooglesPublishedSampleUnits()
        {
            Assert.That(AdMobTestAdUnits.ForRewarded(false), Is.EqualTo("ca-app-pub-3940256099942544/5224354917"));
            Assert.That(AdMobTestAdUnits.ForInterstitial(false), Is.EqualTo("ca-app-pub-3940256099942544/1033173712"));
            Assert.That(AdMobTestAdUnits.ForBanner(false), Is.EqualTo("ca-app-pub-3940256099942544/6300978111"));
            Assert.That(AdMobTestAdUnits.ForRewarded(true), Is.EqualTo("ca-app-pub-3940256099942544/1712485313"));
            Assert.That(AdMobTestAdUnits.ForInterstitial(true), Is.EqualTo("ca-app-pub-3940256099942544/4411468910"));
            Assert.That(AdMobTestAdUnits.ForBanner(true), Is.EqualTo("ca-app-pub-3940256099942544/2934735716"));
        }

        [Test]
        public void AllFormatsAreSupportedAndVerificationIsSetAtShow()
        {
            Assert.That(_provider.SupportsInterstitialAd, Is.True);
            Assert.That(_provider.SupportsBanner, Is.True);
            Assert.That(_provider.BindsServerVerificationAtLoad, Is.False);
        }

        [Test]
        public void NothingIsReadyBeforeALoad()
        {
            Assert.That(_provider.IsRewardAdReady, Is.False);
            Assert.That(_provider.IsInterstitialAdReady, Is.False);
        }

        [Test]
        public void MissingConsentBlocksRequests()
        {
            Assert.That(_provider.CanRequestAds, Is.False);
        }

        [Test]
        public void MissingConsentStopsTheSdkStart()
        {
            AdResult? result = null;

            _provider.StartSdk(value => result = value);

            Assert.That(result?.Failure, Is.EqualTo(AdFailure.ConsentRequired));
        }

        private static AdMobAdSettings RealUnits()
        {
            return new AdMobAdSettings(() => "real-reward", () => "real-interstitial", () => "real-banner");
        }

        [Test]
        public void DiscardAndHideWithNothingLoadedDoNothing()
        {
            Assert.DoesNotThrow(() =>
            {
                _provider.DiscardRewardAd();
                _provider.DiscardInterstitialAd();
                _provider.HideBanner();
            });
        }
    }
}
