using System;

namespace PlatformLibrary.Ads.AdMob
{
    /// <summary>
    /// Values the project owns. Ad units are functions because a game may read them from a table loaded later.
    /// The AdMob App ID is not here: the plugin reads it from its own settings asset.
    /// </summary>
    public sealed class AdMobAdSettings
    {
        public AdMobAdSettings(
            Func<string> rewardedAdUnitId,
            Func<string> interstitialAdUnitId = null,
            Func<string> bannerAdUnitId = null,
            bool childDirectedTreatment = true,
            bool useTestAdUnitsInDevelopmentBuild = true)
        {
            RewardedAdUnitId = rewardedAdUnitId ?? (() => string.Empty);
            InterstitialAdUnitId = interstitialAdUnitId ?? (() => string.Empty);
            BannerAdUnitId = bannerAdUnitId ?? (() => string.Empty);
            ChildDirectedTreatment = childDirectedTreatment;
            UseTestAdUnitsInDevelopmentBuild = useTestAdUnitsInDevelopmentBuild;
        }

        public Func<string> RewardedAdUnitId { get; }
        public Func<string> InterstitialAdUnitId { get; }
        public Func<string> BannerAdUnitId { get; }

        /// <summary>Tags requests as child-directed. True keeps the source library's behavior. The game's audience decides this.</summary>
        public bool ChildDirectedTreatment { get; }

        /// <summary>
        /// In a development build (and the Editor) every request uses <see cref="AdMobTestAdUnits"/> instead of the units above,
        /// so a device test never shows a real ad. Release builds always use the units above. False uses them in development builds too.
        /// </summary>
        public bool UseTestAdUnitsInDevelopmentBuild { get; }
    }
}
