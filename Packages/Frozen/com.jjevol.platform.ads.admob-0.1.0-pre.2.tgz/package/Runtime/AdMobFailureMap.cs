namespace PlatformLibrary.Ads.AdMob
{
    /// <summary>
    /// Google Mobile Ads load error codes. The same number means different things on Android
    /// (AdRequest.ERROR_CODE_*) and iOS (GADErrorCode), so each platform has its own table.
    /// </summary>
    internal static class AdMobFailureMap
    {
        public static AdFailure FromAndroidLoadError(int code)
        {
            switch (code)
            {
                case 1: // INVALID_REQUEST: wrong ad unit
                case 10: // REQUEST_ID_MISMATCH
                    return AdFailure.InvalidAdUnit;
                case 2: // NETWORK_ERROR
                    return AdFailure.Network;
                case 3: // NO_FILL
                case 9: // MEDIATION_NO_FILL
                    return AdFailure.NoFill;
                default:
                    return AdFailure.ProviderError;
            }
        }

        public static AdFailure FromIosLoadError(int code)
        {
            switch (code)
            {
                case 0: // GADErrorInvalidRequest
                    return AdFailure.InvalidAdUnit;
                case 1: // GADErrorNoFill
                case 9: // GADErrorMediationNoFillError
                    return AdFailure.NoFill;
                case 2: // GADErrorNetworkError
                    return AdFailure.Network;
                case 5: // GADErrorTimeout
                    return AdFailure.Timeout;
                default:
                    return AdFailure.ProviderError;
            }
        }
    }
}
