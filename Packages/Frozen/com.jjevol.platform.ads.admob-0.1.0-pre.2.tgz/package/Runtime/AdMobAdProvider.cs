using System;
using GoogleMobileAds.Api;
using GoogleMobileAds.Common;
using GoogleMobileAds.Ump.Api;
using UnityEngine;
using GmaAdRequest = GoogleMobileAds.Api.AdRequest;

namespace PlatformLibrary.Ads.AdMob
{
    /// <summary>Google Mobile Ads with its consent form. Register it with <see cref="AdManager.SetProvider"/>.</summary>
    public sealed class AdMobAdProvider : IAdProvider
    {
        private const string PlatformName = "AdMob";
        private const double MicrosPerUnit = 1000000d;

        private readonly AdMobAdSettings _settings;
        private readonly bool _useTestAdUnits;

        private RewardedAd _rewardAd;
        private InterstitialAd _interstitialAd;
        private BannerView _banner;
        private int _rewardLoadVersion;
        private int _interstitialLoadVersion;
        private string _rewardPlacement = string.Empty;
        private string _interstitialPlacement = string.Empty;

        public AdMobAdProvider(AdMobAdSettings settings)
            : this(settings, Debug.isDebugBuild)
        {
        }

        internal AdMobAdProvider(AdMobAdSettings settings, bool isDevelopmentBuild)
        {
            _settings = settings ?? throw new ArgumentNullException(nameof(settings));
            _useTestAdUnits = isDevelopmentBuild && settings.UseTestAdUnitsInDevelopmentBuild;
        }

        public event Action<AdRevenue> RevenuePaid;

        public bool SupportsInterstitialAd => true;
        public bool SupportsBanner => true;
        public bool BindsServerVerificationAtLoad => false;
        public bool CanRequestAds => ConsentInformation.CanRequestAds();

        /// <summary>True in a development build unless the settings turned it off. Every request then loads a Google test unit.</summary>
        public bool UsesTestAdUnits => _useTestAdUnits;

        public string RewardAdUnitId => _useTestAdUnits ? AdMobTestAdUnits.Rewarded : _settings.RewardedAdUnitId();
        public string InterstitialAdUnitId => _useTestAdUnits ? AdMobTestAdUnits.Interstitial : _settings.InterstitialAdUnitId();
        public string BannerAdUnitId => _useTestAdUnits ? AdMobTestAdUnits.Banner : _settings.BannerAdUnitId();
        public bool IsRewardAdReady => _rewardAd != null && _rewardAd.CanShowAd();
        public bool IsInterstitialAdReady => _interstitialAd != null && _interstitialAd.CanShowAd();

        public void Initialize(Action<AdResult> completed)
        {
            if (_useTestAdUnits) Debug.Log("[AdMob] Development build: every request uses a Google test ad unit.");

            MobileAdsEventExecutor.Initialize();

            ConsentInformation.Update(new ConsentRequestParameters(), error => RunOnMainThread(() =>
            {
                if (error != null)
                {
                    Debug.LogWarning("[AdMob] Consent info update failed: " + error.Message);
                    StartSdk(completed);
                    return;
                }

                ConsentForm.LoadAndShowConsentFormIfRequired(formError => RunOnMainThread(() =>
                {
                    if (formError != null) Debug.LogWarning("[AdMob] Consent form failed: " + formError.Message);
                    StartSdk(completed);
                }));
            }));
        }

        public void LoadRewardAd(AdRequest request, Action<AdResult> completed)
        {
            string adUnitId = RewardUnitFor(request);
            int version = ++_rewardLoadVersion;

            RewardedAd.Load(adUnitId, CreateRequest(), (ad, error) => RunOnMainThread(() =>
            {
                if (version != _rewardLoadVersion)
                {
                    ad?.Destroy();
                    return;
                }

                if (ad == null || error != null)
                {
                    completed(ToFailure(error));
                    return;
                }

                _rewardAd = ad;
                ad.OnAdPaid += value => RaiseRevenuePaid(adUnitId, "REWARDED", value, _rewardPlacement);
                completed(AdResult.Succeeded());
            }));
        }

        public void ShowRewardAd(AdRequest request, IAdShowListener listener)
        {
            _rewardPlacement = request.Placement;
            ApplyServerVerification(request);

            _rewardAd.OnAdFullScreenContentClosed += listener.Closed;
            _rewardAd.OnAdFullScreenContentFailed += error => ReportShowFailure(listener, error);
            _rewardAd.Show(reward =>
            {
                if (reward != null) listener.RewardEarned(reward.Type, reward.Amount);
            });
        }

        public void DiscardRewardAd()
        {
            _rewardLoadVersion++;
            _rewardAd?.Destroy();
            _rewardAd = null;
        }

        public void LoadInterstitialAd(AdRequest request, Action<AdResult> completed)
        {
            string adUnitId = InterstitialUnitFor(request);
            int version = ++_interstitialLoadVersion;

            InterstitialAd.Load(adUnitId, CreateRequest(), (ad, error) => RunOnMainThread(() =>
            {
                if (version != _interstitialLoadVersion)
                {
                    ad?.Destroy();
                    return;
                }

                if (ad == null || error != null)
                {
                    completed(ToFailure(error));
                    return;
                }

                _interstitialAd = ad;
                ad.OnAdPaid += value => RaiseRevenuePaid(adUnitId, "INTERSTITIAL", value, _interstitialPlacement);
                completed(AdResult.Succeeded());
            }));
        }

        public void ShowInterstitialAd(AdRequest request, IAdShowListener listener)
        {
            _interstitialPlacement = request.Placement;

            _interstitialAd.OnAdFullScreenContentClosed += listener.Closed;
            _interstitialAd.OnAdFullScreenContentFailed += error => ReportShowFailure(listener, error);
            _interstitialAd.Show();
        }

        public void DiscardInterstitialAd()
        {
            _interstitialLoadVersion++;
            _interstitialAd?.Destroy();
            _interstitialAd = null;
        }

        public void ShowBanner(AdRequest request, Action<AdResult> completed)
        {
            HideBanner();

            string adUnitId = BannerUnitFor(request);
            string placement = request.Placement;
            var banner = new BannerView(adUnitId, AdSize.Banner, AdPosition.Bottom);
            banner.OnAdPaid += value => RaiseRevenuePaid(adUnitId, "BANNER", value, placement);
            banner.OnBannerAdLoaded += () => completed(AdResult.Succeeded());
            banner.OnBannerAdLoadFailed += error => completed(ToFailure(error));
            _banner = banner;
            banner.LoadAd(CreateRequest());
        }

        public void HideBanner()
        {
            _banner?.Destroy();
            _banner = null;
        }

        internal void StartSdk(Action<AdResult> completed)
        {
            if (!ConsentInformation.CanRequestAds())
            {
                completed(AdResult.Failed(AdFailure.ConsentRequired, 0, "CONSENT_REQUIRED"));
                return;
            }

            var configuration = new RequestConfiguration();
            if (_settings.ChildDirectedTreatment)
                configuration.TagForChildDirectedTreatment = TagForChildDirectedTreatment.True;

            MobileAds.SetRequestConfiguration(configuration);
            MobileAds.SetiOSAppPauseOnBackground(true);
            MobileAds.Initialize(status => completed(AdResult.Succeeded()));
        }

        // A unit the game passes in the request is replaced too, so no path loads a real unit in a development build.
        internal string RewardUnitFor(AdRequest request) => _useTestAdUnits ? AdMobTestAdUnits.Rewarded : request.AdUnitId;
        internal string InterstitialUnitFor(AdRequest request) => _useTestAdUnits ? AdMobTestAdUnits.Interstitial : request.AdUnitId;
        internal string BannerUnitFor(AdRequest request) => _useTestAdUnits ? AdMobTestAdUnits.Banner : request.AdUnitId;

        private static GmaAdRequest CreateRequest()
        {
            var request = new GmaAdRequest();
            request.Keywords.Add("game");
            return request;
        }

        private void ApplyServerVerification(AdRequest request)
        {
            if (!request.HasServerSideVerificationData) return;

            var options = new ServerSideVerificationOptions();
            if (!string.IsNullOrEmpty(request.UserId)) options.UserId = request.UserId;
            if (!string.IsNullOrEmpty(request.CustomData)) options.CustomData = request.CustomData;
            _rewardAd.SetServerSideVerificationOptions(options);
        }

        private void RaiseRevenuePaid(string adUnitId, string adFormat, AdValue value, string placement)
        {
            if (value == null) return;
            RevenuePaid?.Invoke(new AdRevenue(PlatformName, PlatformName, adUnitId, adFormat, value.Value / MicrosPerUnit, value.CurrencyCode, placement));
        }

        private static AdResult ToFailure(LoadAdError error)
        {
            if (error == null) return AdResult.Failed(AdFailure.ProviderError, 0, "LOAD_RETURNED_NO_AD");

            int code = error.GetCode();
            AdFailure failure = Application.platform == RuntimePlatform.IPhonePlayer
                ? AdMobFailureMap.FromIosLoadError(code)
                : AdMobFailureMap.FromAndroidLoadError(code);
            return AdResult.Failed(failure, code, error.GetMessage());
        }

        private static void ReportShowFailure(IAdShowListener listener, AdError error)
        {
            listener.Failed(AdFailure.ShowFailed, error != null ? error.GetCode() : 0, error?.GetMessage());
        }

        // The SDK may call back from another thread. The consent form and the ad fields need the main one.
        private static void RunOnMainThread(Action action)
        {
            MobileAdsEventExecutor.ExecuteInUpdate(action);
        }
    }
}
