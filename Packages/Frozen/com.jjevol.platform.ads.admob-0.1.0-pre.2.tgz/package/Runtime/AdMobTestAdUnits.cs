namespace PlatformLibrary.Ads.AdMob
{
    /// <summary>
    /// Google's published sample ad units. They always serve test ads and never pay, so a development build
    /// on a device cannot show a real ad. Banners use the fixed-size unit because the provider loads <c>AdSize.Banner</c>.
    /// </summary>
    public static class AdMobTestAdUnits
    {
        public const string AndroidRewarded = "ca-app-pub-3940256099942544/5224354917";
        public const string AndroidInterstitial = "ca-app-pub-3940256099942544/1033173712";
        public const string AndroidBanner = "ca-app-pub-3940256099942544/6300978111";

        public const string IosRewarded = "ca-app-pub-3940256099942544/1712485313";
        public const string IosInterstitial = "ca-app-pub-3940256099942544/4411468910";
        public const string IosBanner = "ca-app-pub-3940256099942544/2934735716";

        /// <summary>The units for the build target: iOS units on iOS, Android units everywhere else.</summary>
        public static string Rewarded => ForRewarded(IsIosTarget);
        public static string Interstitial => ForInterstitial(IsIosTarget);
        public static string Banner => ForBanner(IsIosTarget);

        internal static string ForRewarded(bool ios) => ios ? IosRewarded : AndroidRewarded;
        internal static string ForInterstitial(bool ios) => ios ? IosInterstitial : AndroidInterstitial;
        internal static string ForBanner(bool ios) => ios ? IosBanner : AndroidBanner;

        private static bool IsIosTarget
        {
            get
            {
#if UNITY_IOS
                return true;
#else
                return false;
#endif
            }
        }
    }
}
