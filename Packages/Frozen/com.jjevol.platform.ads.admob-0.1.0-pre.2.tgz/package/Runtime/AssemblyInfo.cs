using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Ads.AdMob.Tests.Editor")]
