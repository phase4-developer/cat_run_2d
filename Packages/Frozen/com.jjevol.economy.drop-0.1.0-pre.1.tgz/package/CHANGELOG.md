# Changelog

## 0.1.0-pre.1 - 2026-11-09

- New package. Drop tables and random box tables are one loot graph: a table is a list of slots, each slot picks one weighted entry, and an entry is a reward, a "no reward" outcome or a reference to another table (Expand rolls it in place, Grant gives it as an item).
- Rolling, reward previews, searches and chances read the same validated graph. Nested chances are normalized at every level, so shown percentages match the roll whatever the weight sums are.
- Weights are exact decimals, scaled to whole numbers per slot. Randomness comes only from `ILootRandom`.
- `LootCatalogBuilder.Build` rejects missing references, Expand loops, too deep chains, negative or overflowing weights, bad quantity ranges, zero-roll Expand references and slot totals that differ from `expectedSlotWeight`.
- `RollDetailed` reports each top-level slot pick with its rewards, so a game can count pity streaks per slot.
- `LootTsv.AddRows` reads TSV rows through a game-owned column layout.
- Connects to `ConsumeDataGameExtensions.DropReward` and `GetDropList` through `RollResolver` and `PreviewResolver`.
- The graph check walks its own stack, so a very long chain is reported (once, at its top) instead of overflowing. Chances work out each nested table once per call and add up its lines that give the same reward, so shared sub-tables do not multiply the work.
- TSV: exponent weights are rejected, a fixed-type layout requires its item column, and `tableTag` runs once per table per call even when it returns null.

Unity 6000.3.9f1 on Hosts/EconomyDropValidationHost: compile and EditMode 43/43 passed (runner job economy-drop-3). PlayMode and Player are NOT_RUN; the package has no PlayMode tests.
