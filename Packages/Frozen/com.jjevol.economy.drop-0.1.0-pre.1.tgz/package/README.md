# JJEvol Economy Drop

`com.jjevol.economy.drop@0.1.0-pre.1`은 드롭 표와 랜덤박스 표를 하나의 확률 그래프로 다루는 Economy 하위 패키지다. 추첨, 받을 수 있는 보상 목록, 보상 검색, 확률 계산과 표 검증이 모두 같은 그래프를 읽으므로 화면에 보이는 확률과 실제 추첨이 어긋나지 않는다. Unity 6000.3.9f1 기준 로컬 검증 후보다.

필수: `com.jjevol.economy@0.1.0-pre.4`(`ConsumeData`, `ConsumeTypeId`), `com.jjevol.tables@0.1.0-pre.2`(`TSVRow`), Unity Newtonsoft JSON 3.2.2. economy의 전이 의존성(`com.jjevol.data`, `com.jjevol.save`)도 manifest에 함께 적는다.

## 모델

| 개념 | 뜻 |
|---|---|
| `LootKind` | 게임이 표로 등록한 `ConsumeTypeId`. 숫자는 게임이 정한다 |
| `LootNestedMode.Expand` | 다른 표가 이 종류를 가리키면 그 자리에서 수량만큼 다시 굴린다(드롭 묶음) |
| `LootNestedMode.Grant` | 다른 표가 가리키면 그 자체가 보상이다(나중에 여는 상자 아이템). 맨 위에서 `Roll`하면 연다 |
| `LootTable` | 슬롯 목록. 한 번 굴리면 슬롯마다 한 줄씩 뽑는다. 드롭은 슬롯 1개, 박스는 보상 줄마다 슬롯 1개 |
| `LootSlot` | 비중으로 한 줄을 고르는 목록 |
| `LootEntry` | 한 줄. 비중(`decimal`)과 결과(종류·ID·Min..Max). 종류 0은 비중만 차지하는 「꽝」이다. Expand 종류면 Min..Max는 굴리는 횟수다 |

비중은 정확한 10진수다. 25, 0.5, 33.33처럼 적으면 슬롯마다 같은 배율의 정수로 바꿔 추첨하므로 부동소수 오차가 없다. 비중 합이 100일 필요는 없고 슬롯마다 합으로 나눈다. 합을 강제하려면 `AddKind`의 `expectedSlotWeight`를 준다.

## 시작

```csharp
// 숫자는 게임의 서버 enum 값이다. 패키지는 의미를 모른다.
var drop = new ConsumeTypeId((int)GameConsume.Drop);
var box = new ConsumeTypeId((int)GameConsume.RandomBox);

LootCatalog loot = new LootCatalogBuilder()
    .AddKind(drop, LootNestedMode.Expand)
    .AddKind(box, LootNestedMode.Grant, expectedSlotWeight: 100m)
    // 컬럼 이름은 게임 표에 맞춰 바꾼다. 아래는 기본값을 쓴 경우다.
    .AddRows(GameTableSource.Current.Load("drop"), new LootTsvLayout(drop),
        tableTag: row => new DropInfo(row))         // 이름·아이콘 같은 게임 메타데이터
    .AddRows(GameTableSource.Current.Load("box"), new LootTsvLayout(box)
    {
        SlotColumn = "slot",                        // 박스는 보상 줄마다 슬롯
        TypeColumn = null, FixedType = drop, ItemColumn = "drop", // 박스 줄은 드롭 묶음을 가리킨다
    })
    .Build();                                       // 오류가 하나라도 있으면 LootValidationException

var random = new SystemLootRandom();                // 시험·재현에는 시드나 직접 만든 ILootRandom
List<ConsumeData> rewards = loot.Roll(reward, random);
```

economy의 연결 지점에 그대로 꽂을 수 있다.

```csharp
List<ConsumeData> granted = reward.DropReward(loot.RollResolver(random));
List<ConsumeData> preview = reward.GetDropList(loot.PreviewResolver());          // 전체
List<ConsumeData> onlyGems = reward.GetDropList(loot.PreviewResolver(), gemType); // 그 종류만
```

## 기능

| 할 일 | API |
|---|---|
| 굴리기 | `Roll(ConsumeData, ILootRandom)`, `RollTable(key, random, times)`, 슬롯별 결과가 필요하면 `RollDetailed`(천장 셈 등). 범위 수량은 굴려서 정한다. 표가 아닌 보상은 범위만 정해 그대로 돌려준다 |
| 받을 수 있는 보상 | `PossibleRewards(source 또는 key, include)`. 중복 없이 표 순서. Expand는 펼치고 Grant는 보상으로 둔다. 비중 0·꽝은 뺀다 |
| 찾기 | `Contains`, `Find`(종류 또는 조건식). 펼친 하위 표까지 본다 |
| 확률 | `Chances(key, slotId)`, `Chances(source)`. 단계마다 합으로 나눈 정확한 `Probability`(0..1)와 `Percentage`, 하위 표 굴림 횟수를 반영한 `ExpectedCount` |
| 묶어서 보기 | `RateGroupsBySlot(key)`(슬롯별 합본), `RateGroupsByEntry(key, slot)`(박스 줄별), `LootChances.GroupBy(chances, 키)`(등급 등) |
| 정렬·합치기 | `LootChances.Merge`, `LootChances.Sort(list, ByType 또는 ByProbability, grade)`, `LootChances.GradeFrom(presentationProvider)` |
| 구조 조회 | `GetTable`, `TryGetTable`, `LootTable.Slots`·`HasMultipleSlots`·`Tag`, `LootSlot.TotalWeight`·`FindEntryIndex`·`ShareOf` |
| 검증 | `LootCatalogBuilder.Validate()`, `Build()`, `LootCatalog.Issues`(경고) |

`Probability`는 맨 위 슬롯을 한 번 뽑을 때의 확률이다. 하위 표를 여러 번 굴리면 그 횟수는 `ExpectedCount`에만 들어간다. 박스 슬롯이 여러 개면 슬롯마다 따로 합이 1이다. 하위 표 안에서 같은 보상·범위를 주는 줄은 하나로 더한다. 그래서 펼쳐지는 하위 표에 슬롯이 여러 개면 그 보상의 `Probability`는 「한 번이라도 나올 확률」이 아니라 기대 등장 횟수다(슬롯 두 개가 각각 50%면 1.0). 드롭처럼 슬롯이 1개인 하위 표에서는 둘이 같다. 하위 표는 호출마다 한 번만 계산하므로 여러 표가 같은 하위 표를 가리켜도 계산량이 늘지 않는다.

## 검증 규칙

`Build()`는 표 전체를 한 번에 본다. 줄을 넣는 순서는 상관없다.

| 코드 | 수준 | 내용 |
|---|---|---|
| `UnregisteredKind` | 오류 | 등록하지 않은 종류로 표를 만들었다 |
| `MissingTable` | 오류 | 가리킨 표가 없다(Expand·Grant 모두) |
| `Cycle` | 오류 | Expand 참조가 돌아온다. 추첨 중 무한 재귀를 막는다. Grant 참조는 굴리지 않으므로 순환이어도 된다 |
| `DepthLimit` | 오류 | Expand가 `LootCatalog.MaxDepth`(32)단계보다 깊다. 사슬마다 맨 위 표에 한 번 알린다 |
| `NegativeWeight`, `WeightOverflow` | 오류 | 음수 비중, 정수로 바꿀 수 없는 비중 |
| `SlotWeightMismatch` | 오류 | `expectedSlotWeight`와 합이 다르다 |
| `InvalidQuantityRange`, `NegativeQuantity` | 오류 | Min > Max, 음수 수량 |
| `NestedRollsNotPositive` | 오류 | Expand를 0번 굴린다. 꽝이면 종류 0을 쓴다 |
| `ZeroTotalWeight` | 경고 | 슬롯에서 아무것도 나오지 않는다 |
| `DuplicateEntryId` | 경고 | 한 표에 같은 0 아닌 줄 ID가 있다 |

TSV 형식 오류(필수 칸 없음, 숫자 아님, 지수 표기 비중, Min/Max 한쪽만, 고정 종류인데 아이템 컬럼 없음)는 `AddRows`가 줄 번호와 함께 `InvalidDataException`으로 알린다.

## 게임이 맡을 일

- 어떤 `ConsumeTypeId`가 드롭·박스인지, Expand·Grant 중 무엇인지 등록한다.
- 표 이름과 컬럼 이름을 `LootTsvLayout`에 적는다. 기본 컬럼 이름(`table`, `weight`, `type`, `item`, `amount`, `amountMin`, `amountMax`, `id`)은 예시일 뿐이다.
- 이름·아이콘·등급은 `Tag`나 economy의 `IConsumePresentationProvider`로 게임이 준다. 패키지는 `Tag`를 읽지 않는다.
- 서버가 추첨하는 게임은 서버와 같은 표를 읽어 확률 표시와 로컬 시뮬레이션에 쓴다. 서버 결과를 대신하지 않는다.
- 위·변조 방지가 필요하면 게임이 감싼다. 패키지는 유료 보호 라이브러리를 쓰지 않는다.

## 주의

- `SystemLootRandom`은 스레드 안전하지 않다. 스레드마다 하나씩 쓴다.
- `Roll`은 결과를 합치지 않는다. 필요하면 economy의 `ConsumeDataExt.MergeList`를 쓴다.
- 결과 수량이 0인 보상은 목록에 넣지 않는다(표가 아닌 보상의 `Roll`은 예외로 그대로 돌려준다).
- `Contains`·`Find`·`PossibleRewards`·확률은 비중 0인 줄을 보지 않는다. 실제로 나올 수 있는 것만 다룬다.
- 확률 표시의 반올림 자릿수는 UI가 정한다. 패키지는 `decimal` 그대로 준다.
