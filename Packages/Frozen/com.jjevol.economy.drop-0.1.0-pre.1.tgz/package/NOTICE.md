# Provenance and distribution boundary

New code written in this Framework on 2026-11-09 at the user's request. The requirements (weighted drop groups, multi-line random boxes, previews, chance display, table checks) were taken from the behavior of an existing game the user works on. No code, table names, column names, IDs or data from that game were copied; type numbers in tests are synthetic.

No CodeStage, SGuard, Spine or other paid Vendor source is used. Unity Newtonsoft JSON, Economy and Tables are declared dependencies.

This is an unfrozen local validation candidate. Publishing, packaging for distribution and installing into existing games remain separate steps.
