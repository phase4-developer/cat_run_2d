using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace jjevol
{
    /// <summary>Which TSV columns hold each part of a loot row. Column names belong to the game; the defaults are neutral.</summary>
    public sealed class LootTsvLayout
    {
        public LootTsvLayout(ConsumeTypeId kind)
        {
            if (kind.Value == 0) throw new ArgumentException("Type 0 cannot be a loot type.", nameof(kind));
            Kind = kind;
        }

        /// <summary>The loot type of the tables these rows build.</summary>
        public ConsumeTypeId Kind { get; }
        public string TableColumn { get; set; } = "table";
        /// <summary>Null puts every row of a table in slot 0 (a single pick).</summary>
        public string SlotColumn { get; set; }
        /// <summary>Optional row ID. Missing or empty means 0.</summary>
        public string EntryColumn { get; set; } = "id";
        /// <summary>Exact decimal text such as 25, 0.5 or 12.75. Exponent notation is rejected.</summary>
        public string WeightColumn { get; set; } = "weight";
        /// <summary>Outcome type. Type 0 is "no reward". Null uses FixedType for every row; then ItemColumn must exist and an empty item or an ID of 0 or less is "no reward".</summary>
        public string TypeColumn { get; set; } = "type";
        public ConsumeTypeId FixedType { get; set; }
        public string ItemColumn { get; set; } = "item";
        /// <summary>A single quantity. When it is missing or empty, MinColumn and MaxColumn are read; when both are missing, the quantity is 1.</summary>
        public string AmountColumn { get; set; } = "amount";
        public string MinColumn { get; set; } = "amountMin";
        public string MaxColumn { get; set; } = "amountMax";
        /// <summary>Required only for named (non-numeric) type text.</summary>
        public Func<string, ConsumeTypeId> ParseType { get; set; }
    }

    public static class LootTsv
    {
        /// <summary>Adds one entry per row. tableTag runs once per table in this call, on its first row, when the table has no tag yet.
        /// Malformed rows throw InvalidDataException naming the row; data rules (weights, references, loops) are checked by Build.</summary>
        public static LootCatalogBuilder AddRows(this LootCatalogBuilder builder, IEnumerable<TSVRow> rows, LootTsvLayout layout,
            Func<TSVRow, object> tableTag = null, Func<TSVRow, object> entryTag = null)
        {
            if (builder == null) throw new ArgumentNullException(nameof(builder));
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            if (layout == null) throw new ArgumentNullException(nameof(layout));
            if (layout.TypeColumn == null && layout.FixedType.Value == 0) throw new ArgumentException("Set TypeColumn or FixedType.", nameof(layout));

            var tagged = new HashSet<LootTableKey>();
            int index = 0;
            foreach (TSVRow row in rows)
            {
                index++;
                if (row == null) throw new InvalidDataException("Loot row " + index + " is null.");
                try
                {
                    var key = new LootTableKey(layout.Kind, RequiredInt(row, layout.TableColumn));
                    int slot = layout.SlotColumn == null ? 0 : OptionalInt(row, layout.SlotColumn, 0);
                    int entryId = layout.EntryColumn == null ? 0 : OptionalInt(row, layout.EntryColumn, 0);
                    decimal weight = Weight(row, layout.WeightColumn);
                    object tag = entryTag?.Invoke(row);

                    LootEntry entry;
                    ConsumeTypeId type = layout.TypeColumn == null ? layout.FixedType : Type(row, layout.TypeColumn, layout.ParseType);
                    int item = layout.TypeColumn == null ? FixedItem(row, layout.ItemColumn) : (type.Value == 0 ? 0 : RequiredInt(row, layout.ItemColumn));
                    if (type.Value == 0 || (layout.TypeColumn == null && item <= 0))
                        entry = LootEntry.Nothing(weight, entryId, tag);
                    else
                    {
                        Quantity(row, layout, out long min, out long max);
                        entry = new LootEntry(entryId, weight, type, item, min, max, tag);
                    }

                    builder.AddEntry(key, slot, entry);
                    if (tableTag != null && tagged.Add(key) && !builder.HasTag(key)) builder.SetTag(key, tableTag(row));
                }
                catch (Exception exception) when (exception is FormatException || exception is OverflowException || exception is InvalidDataException)
                {
                    throw new InvalidDataException("Loot row " + index + ": " + exception.Message, exception);
                }
            }
            return builder;
        }

        private static string Text(TSVRow row, string column)
        {
            if (column == null || !row.Contains(column)) return null;
            string value = row.Get(column);
            return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        }

        private static int RequiredInt(TSVRow row, string column)
            => int.Parse(Text(row, column) ?? throw new InvalidDataException("Column '" + column + "' is required."), NumberStyles.Integer, CultureInfo.InvariantCulture);

        private static int OptionalInt(TSVRow row, string column, int fallback)
        {
            string text = Text(row, column);
            return text == null ? fallback : int.Parse(text, NumberStyles.Integer, CultureInfo.InvariantCulture);
        }

        // Under a fixed type an empty item cell means "no reward", but the column itself must exist so a misspelt name is not silent.
        private static int FixedItem(TSVRow row, string column)
        {
            if (column == null || !row.Contains(column)) throw new InvalidDataException("Column '" + column + "' is required.");
            return OptionalInt(row, column, 0);
        }

        private static long? OptionalLong(TSVRow row, string column)
        {
            string text = Text(row, column);
            return text == null ? (long?)null : long.Parse(text, NumberStyles.Integer, CultureInfo.InvariantCulture);
        }

        private static decimal Weight(TSVRow row, string column)
            => decimal.Parse(Text(row, column) ?? throw new InvalidDataException("Column '" + column + "' is required."),
                NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);

        private static ConsumeTypeId Type(TSVRow row, string column, Func<string, ConsumeTypeId> parse)
        {
            string text = Text(row, column) ?? throw new InvalidDataException("Column '" + column + "' is required.");
            char first = text[0];
            if (first == '+' || first == '-' || (first >= '0' && first <= '9'))
                return new ConsumeTypeId(int.Parse(text, NumberStyles.Integer, CultureInfo.InvariantCulture));
            if (parse == null) throw new FormatException("The named type '" + text + "' needs LootTsvLayout.ParseType.");
            return parse(text);
        }

        private static void Quantity(TSVRow row, LootTsvLayout layout, out long min, out long max)
        {
            long? amount = OptionalLong(row, layout.AmountColumn);
            if (amount.HasValue) { min = max = amount.Value; return; }
            long? low = OptionalLong(row, layout.MinColumn), high = OptionalLong(row, layout.MaxColumn);
            if (low.HasValue != high.HasValue)
                throw new InvalidDataException("Columns '" + layout.MinColumn + "' and '" + layout.MaxColumn + "' must both be set.");
            min = low ?? 1;
            max = high ?? 1;
        }
    }
}
