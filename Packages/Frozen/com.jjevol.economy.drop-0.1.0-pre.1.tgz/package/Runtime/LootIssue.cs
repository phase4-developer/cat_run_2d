using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace jjevol
{
    public enum LootIssueSeverity
    {
        /// <summary>The catalog still builds; the data is probably not what was meant.</summary>
        Warning,
        /// <summary>The catalog does not build.</summary>
        Error,
    }

    public enum LootIssueCode
    {
        /// <summary>A table uses a type that was not registered with AddKind.</summary>
        UnregisteredKind,
        /// <summary>An entry names a loot table that does not exist.</summary>
        MissingTable,
        /// <summary>Expand references loop back to a table already being rolled.</summary>
        Cycle,
        /// <summary>Expand references are nested deeper than LootCatalog.MaxDepth.</summary>
        DepthLimit,
        NegativeWeight,
        /// <summary>No entry of the slot can be chosen, so the slot never gives anything.</summary>
        ZeroTotalWeight,
        /// <summary>The slot total differs from the kind's ExpectedSlotWeight.</summary>
        SlotWeightMismatch,
        /// <summary>The weights cannot be turned into exact whole numbers within the long range.</summary>
        WeightOverflow,
        /// <summary>Min is greater than Max.</summary>
        InvalidQuantityRange,
        NegativeQuantity,
        /// <summary>An Expand reference would roll its table zero times. Use a "no reward" entry instead.</summary>
        NestedRollsNotPositive,
        /// <summary>Two entries of one table share a non-zero entry ID.</summary>
        DuplicateEntryId,
    }

    public sealed class LootIssue
    {
        public LootIssueCode Code { get; }
        public LootIssueSeverity Severity { get; }
        public LootTableKey Table { get; }
        public int? SlotId { get; }
        public int? EntryId { get; }
        public string Message { get; }

        internal LootIssue(LootIssueCode code, LootIssueSeverity severity, LootTableKey table, int? slotId, int? entryId, string message)
        {
            Code = code; Severity = severity; Table = table; SlotId = slotId; EntryId = entryId; Message = message;
        }

        public override string ToString()
        {
            string where = "table " + Table;
            if (SlotId.HasValue) where += " slot " + SlotId.Value.ToString(CultureInfo.InvariantCulture);
            if (EntryId.HasValue) where += " entry " + EntryId.Value.ToString(CultureInfo.InvariantCulture);
            return Severity + " " + Code + " (" + where + "): " + Message;
        }
    }

    public sealed class LootValidationException : Exception
    {
        public IReadOnlyList<LootIssue> Issues { get; }

        internal LootValidationException(IReadOnlyList<LootIssue> issues)
            : base("The loot catalog has " + issues.Count(issue => issue.Severity == LootIssueSeverity.Error).ToString(CultureInfo.InvariantCulture)
                + " error(s):" + Environment.NewLine + string.Join(Environment.NewLine, issues.Where(issue => issue.Severity == LootIssueSeverity.Error)))
        {
            Issues = issues;
        }
    }
}
