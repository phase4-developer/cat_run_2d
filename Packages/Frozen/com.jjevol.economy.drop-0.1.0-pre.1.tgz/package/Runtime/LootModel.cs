using System;
using System.Collections.Generic;
using System.Globalization;

namespace jjevol
{
    /// <summary>One loot table: a registered loot type and the game's table ID.</summary>
    public readonly struct LootTableKey : IEquatable<LootTableKey>
    {
        public ConsumeTypeId Kind { get; }
        public int Id { get; }
        public LootTableKey(ConsumeTypeId kind, int id) { Kind = kind; Id = id; }
        public bool Equals(LootTableKey other) => Kind == other.Kind && Id == other.Id;
        public override bool Equals(object other) => other is LootTableKey key && Equals(key);
        public override int GetHashCode() => unchecked(Kind.Value * 397) ^ Id;
        public override string ToString() => Kind.ToString() + "_" + Id.ToString(CultureInfo.InvariantCulture);
        public static bool operator ==(LootTableKey left, LootTableKey right) => left.Equals(right);
        public static bool operator !=(LootTableKey left, LootTableKey right) => !left.Equals(right);
    }

    /// <summary>What happens when an entry of another table names this loot type.</summary>
    public enum LootNestedMode
    {
        /// <summary>The referenced table is rolled in place, quantity times.</summary>
        Expand,
        /// <summary>The reference itself is the reward (for example a box item the player opens later).</summary>
        Grant,
    }

    /// <summary>A consume type the game registered as a loot table type.</summary>
    public sealed class LootKind
    {
        public ConsumeTypeId TypeId { get; }
        public LootNestedMode NestedMode { get; }
        /// <summary>When set, every slot of this kind must have exactly this total weight.</summary>
        public decimal? ExpectedSlotWeight { get; }

        public LootKind(ConsumeTypeId typeId, LootNestedMode nestedMode, decimal? expectedSlotWeight = null)
        {
            if (typeId.Value == 0) throw new ArgumentException("Type 0 means no reward and cannot be a loot type.", nameof(typeId));
            if (expectedSlotWeight.HasValue && expectedSlotWeight.Value <= 0) throw new ArgumentOutOfRangeException(nameof(expectedSlotWeight));
            TypeId = typeId; NestedMode = nestedMode; ExpectedSlotWeight = expectedSlotWeight;
        }
    }

    /// <summary>One weighted row. Type 0 is an explicit "no reward" outcome that still holds weight.
    /// For an Expand loot type, Min..Max is how many times the referenced table is rolled.</summary>
    public sealed class LootEntry
    {
        public int EntryId { get; }
        public decimal Weight { get; }
        public ConsumeTypeId TypeId { get; }
        public int ItemId { get; }
        public long Min { get; }
        public long Max { get; }
        public object Tag { get; }
        public bool IsNothing => TypeId.Value == 0;

        public LootEntry(int entryId, decimal weight, ConsumeTypeId typeId, int itemId, long min, long max, object tag = null)
        {
            EntryId = entryId; Weight = weight; TypeId = typeId; Tag = tag;
            if (typeId.Value == 0) { ItemId = 0; Min = 0; Max = 0; }
            else { ItemId = itemId; Min = min; Max = max; }
        }

        public static LootEntry Nothing(decimal weight, int entryId = 0, object tag = null)
            => new LootEntry(entryId, weight, default, 0, 0, 0, tag);

        public static LootEntry Of(ConsumeData outcome, decimal weight, int entryId = 0, object tag = null)
        {
            if (outcome == null) throw new ArgumentNullException(nameof(outcome));
            return new LootEntry(entryId, weight, outcome.TypeId, outcome.ItemId, outcome.Min, outcome.Max, tag);
        }

        /// <summary>The outcome as a quantity range, or null for "no reward".</summary>
        public ConsumeData Outcome => IsNothing ? null : new ConsumeData(TypeId, ItemId, Min, Max);
        internal LootTableKey Reference => new LootTableKey(TypeId, ItemId);
    }

    /// <summary>One independent pick: exactly one entry is chosen by weight each time the table is rolled.</summary>
    public sealed class LootSlot
    {
        private readonly LootEntry[] _entries;
        private readonly long[] _cumulative;

        public int SlotId { get; }
        public IReadOnlyList<LootEntry> Entries => _entries;
        public decimal TotalWeight { get; }
        internal long ScaledTotal => _cumulative.Length == 0 ? 0 : _cumulative[_cumulative.Length - 1];

        internal LootSlot(int slotId, LootEntry[] entries, decimal totalWeight, long[] cumulative)
        {
            SlotId = slotId; _entries = entries; TotalWeight = totalWeight; _cumulative = cumulative;
        }

        public int FindEntryIndex(int entryId)
        {
            for (int i = 0; i < _entries.Length; i++)
                if (_entries[i].EntryId == entryId) return i;
            return -1;
        }

        /// <summary>The chance of one pick choosing this entry, 0..1.</summary>
        public decimal ShareOf(LootEntry entry)
        {
            if (entry == null) throw new ArgumentNullException(nameof(entry));
            return TotalWeight <= 0 || entry.Weight <= 0 ? 0m : entry.Weight / TotalWeight;
        }

        internal LootEntry Pick(ILootRandom random)
        {
            long total = ScaledTotal;
            if (total <= 0) return null;
            long r = random.NextLong(total);
            if (r < 0 || r >= total) throw new InvalidOperationException("The random source returned a value outside [0, maxExclusive).");
            int low = 0, high = _cumulative.Length - 1;
            while (low < high)
            {
                int mid = (low + high) / 2;
                if (r < _cumulative[mid]) high = mid; else low = mid + 1;
            }
            return _entries[low];
        }
    }

    /// <summary>One top-level slot pick from LootCatalog.RollDetailed.</summary>
    public sealed class LootPick
    {
        private readonly ConsumeData[] _rewards;
        public LootTableKey Table { get; }
        /// <summary>0-based roll number when the table was rolled several times.</summary>
        public long Roll { get; }
        public int SlotId { get; }
        /// <summary>The chosen entry's ID, or 0 when the slot had no positive weight.</summary>
        public int EntryId { get; }
        /// <summary>True when the pick chose "no reward" or the slot had nothing to choose.</summary>
        public bool IsNothing { get; }
        /// <summary>Rewards produced through this pick, nested tables included. Copies.</summary>
        public IReadOnlyList<ConsumeData> Rewards => Array.ConvertAll(_rewards, reward => reward.Clone());

        internal LootPick(LootTableKey table, long roll, int slotId, LootEntry entry, List<ConsumeData> rewards)
        {
            Table = table; Roll = roll; SlotId = slotId;
            EntryId = entry?.EntryId ?? 0;
            IsNothing = entry == null || entry.IsNothing;
            _rewards = rewards.ToArray();
        }
    }

    /// <summary>A loot table: every slot is picked once per roll. A drop table has one slot; a box has one per reward line.</summary>
    public sealed class LootTable
    {
        private readonly LootSlot[] _slots;
        public LootTableKey Key { get; }
        public IReadOnlyList<LootSlot> Slots => _slots;
        /// <summary>Game metadata (name, icon, grade source). The package never reads it.</summary>
        public object Tag { get; }
        public bool HasMultipleSlots => _slots.Length > 1;

        internal LootTable(LootTableKey key, LootSlot[] slots, object tag) { Key = key; _slots = slots; Tag = tag; }

        public bool TryGetSlot(int slotId, out LootSlot slot)
        {
            foreach (LootSlot candidate in _slots)
                if (candidate.SlotId == slotId) { slot = candidate; return true; }
            slot = null;
            return false;
        }

        public LootSlot GetSlot(int slotId)
            => TryGetSlot(slotId, out LootSlot slot) ? slot : throw new KeyNotFoundException("Loot table " + Key + " has no slot " + slotId.ToString(CultureInfo.InvariantCulture) + ".");
    }
}
