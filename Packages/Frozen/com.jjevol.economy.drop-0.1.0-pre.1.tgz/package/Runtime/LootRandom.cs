using System;

namespace jjevol
{
    /// <summary>The only source of randomness for rolls. Inject a seeded or recorded source for tests and replays.</summary>
    public interface ILootRandom
    {
        /// <summary>A uniform value in [0, maxExclusive). maxExclusive is always positive.</summary>
        long NextLong(long maxExclusive);
    }

    /// <summary>System.Random based source. Not thread-safe; use one instance per thread.</summary>
    public sealed class SystemLootRandom : ILootRandom
    {
        private readonly Random _random;
        private readonly byte[] _buffer = new byte[8];

        public SystemLootRandom() { _random = new Random(); }
        public SystemLootRandom(int seed) { _random = new Random(seed); }

        public long NextLong(long maxExclusive)
        {
            if (maxExclusive <= 0) throw new ArgumentOutOfRangeException(nameof(maxExclusive));
            if (maxExclusive <= int.MaxValue) return _random.Next((int)maxExclusive);

            // Rejection sampling keeps every value equally likely above the int range.
            ulong range = (ulong)maxExclusive;
            ulong bucket = ulong.MaxValue / range;
            ulong limit = bucket * range;
            ulong value;
            do
            {
                _random.NextBytes(_buffer);
                value = BitConverter.ToUInt64(_buffer, 0);
            }
            while (value >= limit);
            return (long)(value % range);
        }
    }
}
