using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace jjevol
{
    /// <summary>Collects kinds and rows, then validates the whole graph once. Rows can be added in any order.</summary>
    public sealed class LootCatalogBuilder
    {
        private sealed class TableDraft
        {
            internal object Tag;
            internal readonly List<int> SlotOrder = new List<int>();
            internal readonly Dictionary<int, List<LootEntry>> Slots = new Dictionary<int, List<LootEntry>>();
        }

        private readonly Dictionary<ConsumeTypeId, LootKind> _kinds = new Dictionary<ConsumeTypeId, LootKind>();
        private readonly List<LootTableKey> _tableOrder = new List<LootTableKey>();
        private readonly Dictionary<LootTableKey, TableDraft> _tables = new Dictionary<LootTableKey, TableDraft>();

        public LootCatalogBuilder AddKind(ConsumeTypeId typeId, LootNestedMode nestedMode, decimal? expectedSlotWeight = null)
            => AddKind(new LootKind(typeId, nestedMode, expectedSlotWeight));

        public LootCatalogBuilder AddKind(LootKind kind)
        {
            if (kind == null) throw new ArgumentNullException(nameof(kind));
            if (_kinds.ContainsKey(kind.TypeId)) throw new ArgumentException("Loot type " + kind.TypeId + " is already registered.", nameof(kind));
            _kinds.Add(kind.TypeId, kind);
            return this;
        }

        public LootCatalogBuilder AddEntry(LootTableKey table, int slotId, LootEntry entry)
        {
            if (entry == null) throw new ArgumentNullException(nameof(entry));
            TableDraft draft = Draft(table);
            if (!draft.Slots.TryGetValue(slotId, out List<LootEntry> entries))
            {
                entries = new List<LootEntry>();
                draft.Slots.Add(slotId, entries);
                draft.SlotOrder.Add(slotId);
            }
            entries.Add(entry);
            return this;
        }

        /// <summary>Attach game metadata to a table. A table needs at least one entry to exist.</summary>
        public LootCatalogBuilder SetTag(LootTableKey table, object tag)
        {
            Draft(table).Tag = tag;
            return this;
        }

        public bool HasTag(LootTableKey table) => _tables.TryGetValue(table, out TableDraft draft) && draft.Tag != null;

        private TableDraft Draft(LootTableKey table)
        {
            if (!_tables.TryGetValue(table, out TableDraft draft))
            {
                draft = new TableDraft();
                _tables.Add(table, draft);
                _tableOrder.Add(table);
            }
            return draft;
        }

        public IReadOnlyList<LootIssue> Validate() => Compile(out _);

        /// <summary>Builds an immutable catalog. Throws LootValidationException when any Error issue exists; warnings stay on LootCatalog.Issues.</summary>
        public LootCatalog Build()
        {
            List<LootIssue> issues = Compile(out Dictionary<LootTableKey, LootTable> tables);
            if (issues.Any(issue => issue.Severity == LootIssueSeverity.Error)) throw new LootValidationException(issues);
            return new LootCatalog(new Dictionary<ConsumeTypeId, LootKind>(_kinds), _tableOrder.Select(key => tables[key]).ToArray(), issues);
        }

        private List<LootIssue> Compile(out Dictionary<LootTableKey, LootTable> tables)
        {
            var issues = new List<LootIssue>();
            tables = new Dictionary<LootTableKey, LootTable>();

            foreach (LootTableKey key in _tableOrder)
            {
                TableDraft draft = _tables[key];
                if (draft.SlotOrder.Count == 0)
                {
                    issues.Add(new LootIssue(LootIssueCode.MissingTable, LootIssueSeverity.Error, key, null, null, "A tag was set but the table has no entries."));
                    continue;
                }
                _kinds.TryGetValue(key.Kind, out LootKind kind);
                if (kind == null)
                    issues.Add(new LootIssue(LootIssueCode.UnregisteredKind, LootIssueSeverity.Error, key, null, null, "Type " + key.Kind + " is not a registered loot type."));

                var seenIds = new HashSet<int>();
                var slots = new List<LootSlot>();
                foreach (int slotId in draft.SlotOrder)
                {
                    LootEntry[] entries = draft.Slots[slotId].ToArray();
                    foreach (LootEntry entry in entries)
                    {
                        if (entry.EntryId != 0 && !seenIds.Add(entry.EntryId))
                            issues.Add(new LootIssue(LootIssueCode.DuplicateEntryId, LootIssueSeverity.Warning, key, slotId, entry.EntryId, "The entry ID is used more than once in this table."));
                        CheckEntry(key, slotId, entry, issues);
                    }
                    slots.Add(CompileSlot(key, kind, slotId, entries, issues));
                }
                tables.Add(key, new LootTable(key, slots.ToArray(), draft.Tag));
            }

            CheckGraph(tables, issues);
            return issues;
        }

        private void CheckEntry(LootTableKey key, int slotId, LootEntry entry, List<LootIssue> issues)
        {
            if (entry.Weight < 0)
                issues.Add(new LootIssue(LootIssueCode.NegativeWeight, LootIssueSeverity.Error, key, slotId, entry.EntryId, "Weight " + entry.Weight.ToString(CultureInfo.InvariantCulture) + " is negative."));
            if (entry.IsNothing) return;
            if (entry.Min > entry.Max)
                issues.Add(new LootIssue(LootIssueCode.InvalidQuantityRange, LootIssueSeverity.Error, key, slotId, entry.EntryId, "Min is greater than Max."));
            if (entry.Min < 0)
                issues.Add(new LootIssue(LootIssueCode.NegativeQuantity, LootIssueSeverity.Error, key, slotId, entry.EntryId, "A loot quantity cannot be negative."));
            if (!_kinds.TryGetValue(entry.TypeId, out LootKind target)) return;
            if (!_tables.TryGetValue(entry.Reference, out TableDraft referenced) || referenced.SlotOrder.Count == 0)
                issues.Add(new LootIssue(LootIssueCode.MissingTable, LootIssueSeverity.Error, key, slotId, entry.EntryId, "Loot table " + entry.Reference + " does not exist."));
            if (target.NestedMode == LootNestedMode.Expand && entry.Max <= 0)
                issues.Add(new LootIssue(LootIssueCode.NestedRollsNotPositive, LootIssueSeverity.Error, key, slotId, entry.EntryId, "Expanding " + entry.Reference + " zero times never gives anything."));
        }

        private static LootSlot CompileSlot(LootTableKey key, LootKind kind, int slotId, LootEntry[] entries, List<LootIssue> issues)
        {
            decimal total = 0;
            int scale = 0;
            bool valid = true;
            foreach (LootEntry entry in entries)
            {
                if (entry.Weight < 0) { valid = false; continue; }
                try { total += entry.Weight; }
                catch (OverflowException) { valid = false; }
                scale = Math.Max(scale, (decimal.GetBits(entry.Weight)[3] >> 16) & 0xFF);
            }

            var cumulative = new long[valid ? entries.Length : 0];
            if (valid)
            {
                try
                {
                    decimal factor = 1;
                    for (int i = 0; i < scale; i++) factor *= 10;
                    long running = 0;
                    for (int i = 0; i < entries.Length; i++)
                    {
                        decimal scaled = entries[i].Weight * factor;
                        if (decimal.Truncate(scaled) != scaled) throw new OverflowException();
                        running = checked(running + decimal.ToInt64(scaled));
                        cumulative[i] = running;
                    }
                }
                catch (OverflowException)
                {
                    issues.Add(new LootIssue(LootIssueCode.WeightOverflow, LootIssueSeverity.Error, key, slotId, null, "The weights do not fit exact whole numbers in the long range."));
                    cumulative = new long[0];
                }
            }

            if (valid && total == 0)
                issues.Add(new LootIssue(LootIssueCode.ZeroTotalWeight, LootIssueSeverity.Warning, key, slotId, null, "No entry has a positive weight, so this slot never gives anything."));
            if (valid && kind?.ExpectedSlotWeight is decimal expected && total != expected)
                issues.Add(new LootIssue(LootIssueCode.SlotWeightMismatch, LootIssueSeverity.Error, key, slotId, null,
                    "The slot total " + total.ToString(CultureInfo.InvariantCulture) + " is not " + expected.ToString(CultureInfo.InvariantCulture) + "."));
            return new LootSlot(slotId, entries, valid ? total : 0, cumulative);
        }

        // Only Expand references recurse during a roll; Grant references are leaves.
        // The walk keeps its own stack so a very long chain in the data is reported instead of overflowing the call stack.
        private void CheckGraph(Dictionary<LootTableKey, LootTable> tables, List<LootIssue> issues)
        {
            var state = new Dictionary<LootTableKey, int>(); // 1 = on the path, 2 = done
            var height = new Dictionary<LootTableKey, int>();
            var path = new List<LootTableKey>();
            var stack = new List<GraphFrame>();
            var edges = new Dictionary<LootTableKey, List<LootTableKey>>();
            var reported = new HashSet<string>();

            void Enter(LootTableKey key)
            {
                state[key] = 1;
                path.Add(key);
                var children = new List<LootTableKey>();
                foreach (LootSlot slot in tables[key].Slots)
                    foreach (LootEntry entry in slot.Entries)
                    {
                        if (entry.IsNothing || !_kinds.TryGetValue(entry.TypeId, out LootKind kind) || kind.NestedMode != LootNestedMode.Expand) continue;
                        if (tables.ContainsKey(entry.Reference)) children.Add(entry.Reference);
                    }
                edges[key] = children;
                stack.Add(new GraphFrame(key, children));
            }

            foreach (LootTableKey root in tables.Keys.ToList())
            {
                if (state.ContainsKey(root)) continue;
                Enter(root);
                while (stack.Count > 0)
                {
                    GraphFrame top = stack[stack.Count - 1];
                    if (top.Next < top.Children.Count)
                    {
                        LootTableKey child = top.Children[top.Next++];
                        if (!state.TryGetValue(child, out int seen)) { Enter(child); continue; }
                        if (seen == 2) { top.Deepest = Math.Max(top.Deepest, height[child] + 1); continue; }
                        int start = path.IndexOf(child);
                        List<LootTableKey> loop = path.Skip(start).Concat(new[] { child }).ToList();
                        string text = string.Join(" -> ", loop);
                        string signature = string.Join(",", loop.Skip(1).Select(item => item.ToString()).OrderBy(item => item, StringComparer.Ordinal));
                        if (reported.Add(signature))
                            issues.Add(new LootIssue(LootIssueCode.Cycle, LootIssueSeverity.Error, child, null, null, "Expand references loop: " + text + "."));
                        top.Deepest = Math.Max(top.Deepest, 1);
                        continue;
                    }
                    stack.RemoveAt(stack.Count - 1);
                    path.RemoveAt(path.Count - 1);
                    state[top.Key] = 2;
                    height[top.Key] = top.Deepest;
                    if (stack.Count > 0)
                    {
                        GraphFrame parent = stack[stack.Count - 1];
                        parent.Deepest = Math.Max(parent.Deepest, top.Deepest + 1);
                    }
                }
            }
            // Report only the top of each too-deep chain; the tables under it are covered by the same issue.
            var tooDeep = new HashSet<LootTableKey>(tables.Keys.Where(key => height[key] > LootCatalog.MaxDepth));
            var under = new HashSet<LootTableKey>(tooDeep.SelectMany(key => edges[key]).Where(tooDeep.Contains));
            foreach (LootTableKey key in tables.Keys)
                if (tooDeep.Contains(key) && !under.Contains(key))
                    issues.Add(new LootIssue(LootIssueCode.DepthLimit, LootIssueSeverity.Error, key, null, null,
                        "Expand references are nested deeper than " + LootCatalog.MaxDepth.ToString(CultureInfo.InvariantCulture) + " levels."));
        }

        private sealed class GraphFrame
        {
            public GraphFrame(LootTableKey key, List<LootTableKey> children) { Key = key; Children = children; }
            public LootTableKey Key { get; }
            public List<LootTableKey> Children { get; }
            public int Next;
            public int Deepest;
        }
    }
}
