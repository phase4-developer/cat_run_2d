using System;
using System.Collections.Generic;
using System.Linq;

namespace jjevol
{
    /// <summary>The chance of one reward outcome. Probability is per pick of the top slot; nested tables are normalized at
    /// every level. ExpectedCount also counts how many times nested tables are rolled (the average of Min..Max).
    /// Inside a nested table, lines that give the same reward and range are added together, across its slots too, so when an
    /// expanded table has several slots Probability is the expected number of times the reward comes up, not the chance of
    /// seeing it at least once. With single-slot nested tables (the usual drop) the two are the same.</summary>
    public sealed class LootChance
    {
        public ConsumeTypeId TypeId { get; }
        public int ItemId { get; }
        public long Min { get; }
        public long Max { get; }
        public decimal Probability { get; }
        public decimal Percentage => Probability * 100m;
        public decimal ExpectedCount { get; }
        /// <summary>The top-level slot this chance belongs to.</summary>
        public int SlotId { get; }
        /// <summary>The entry of the top-level slot this chance comes through.</summary>
        public int EntryId { get; }

        public LootChance(ConsumeTypeId typeId, int itemId, long min, long max, decimal probability, decimal expectedCount, int slotId, int entryId)
        {
            TypeId = typeId; ItemId = itemId; Min = min; Max = max;
            Probability = probability; ExpectedCount = expectedCount; SlotId = slotId; EntryId = entryId;
        }

        public ConsumeData Reward => new ConsumeData(TypeId, ItemId, Min, Max);
        internal (int, ConsumeTypeId, int, long, long) MergeKey => (SlotId, TypeId, ItemId, Min, Max);
    }

    /// <summary>A display group of chances: one slot, one top-level entry, or one key such as grade.</summary>
    public sealed class LootRateGroup
    {
        public LootTableKey Table { get; }
        public int SlotId { get; }
        /// <summary>The top-level entry for RateGroupsByEntry, otherwise 0.</summary>
        public int EntryId { get; }
        /// <summary>The grouping key for LootChances.GroupBy (for example grade), otherwise 0.</summary>
        public int GroupKey { get; }
        /// <summary>The chance that a top-level pick lands on an entry of this group, 0..1.</summary>
        public decimal Probability { get; }
        public decimal Percentage => Probability * 100m;
        public IReadOnlyList<LootChance> Chances { get; }
        /// <summary>The first chance's type, or the default ID when the group is empty.</summary>
        public ConsumeTypeId RewardType => Chances.Count > 0 ? Chances[0].TypeId : default;

        public LootRateGroup(LootTableKey table, int slotId, int entryId, int groupKey, decimal probability, IReadOnlyList<LootChance> chances)
        {
            Table = table; SlotId = slotId; EntryId = entryId; GroupKey = groupKey; Probability = probability;
            Chances = chances ?? throw new ArgumentNullException(nameof(chances));
        }
    }

    public enum LootChanceOrder
    {
        /// <summary>Type ascending, then grade descending, then item ID descending.</summary>
        ByType,
        /// <summary>Probability ascending, then the ByType order.</summary>
        ByProbability,
    }

    public sealed partial class LootCatalog
    {
        /// <summary>Chances of one slot, or of every slot when slotId is null (each slot is normalized on its own).
        /// Not merged: the same reward reached through two entries appears twice. Use LootChances.Merge.</summary>
        public List<LootChance> Chances(LootTableKey key, int? slotId = null)
        {
            LootTable table = GetTable(key);
            if (slotId.HasValue) table.GetSlot(slotId.Value);
            var result = new List<LootChance>();
            var memo = new Dictionary<LootTableKey, List<LootChance>>();
            foreach (LootSlot slot in table.Slots)
            {
                if (slotId.HasValue && slot.SlotId != slotId.Value) continue;
                foreach (LootEntry entry in slot.Entries)
                    AddChances(slot, entry, 1m, 1m, slot.SlotId, entry.EntryId, result, 0, memo);
            }
            return result;
        }

        /// <summary>Chances of opening a consume once. A plain reward is certain.</summary>
        public List<LootChance> Chances(ConsumeData source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            LootTable table = TableOf(source);
            if (table == null) return new List<LootChance> { new LootChance(source.TypeId, source.ItemId, source.Min, source.Max, 1m, 1m, 0, 0) };
            return Chances(table.Key);
        }

        /// <summary>One merged group per slot. Probability is the share of picks that land on an entry able to give something
        /// ("no reward" and zero-weight entries are left out; a nested table can still come up empty).</summary>
        public List<LootRateGroup> RateGroupsBySlot(LootTableKey key)
        {
            LootTable table = GetTable(key);
            var groups = new List<LootRateGroup>();
            var memo = new Dictionary<LootTableKey, List<LootChance>>();
            foreach (LootSlot slot in table.Slots)
            {
                decimal share = 0;
                var chances = new List<LootChance>();
                foreach (LootEntry entry in slot.Entries)
                {
                    var part = new List<LootChance>();
                    AddChances(slot, entry, 1m, 1m, slot.SlotId, entry.EntryId, part, 0, memo);
                    if (part.Count == 0) continue;
                    share += slot.ShareOf(entry);
                    chances.AddRange(part);
                }
                if (chances.Count > 0) groups.Add(new LootRateGroup(key, slot.SlotId, 0, 0, share, LootChances.Merge(chances)));
            }
            return groups;
        }

        /// <summary>One group per top-level entry of a slot (for example per box line), each with its own entry ID.</summary>
        public List<LootRateGroup> RateGroupsByEntry(LootTableKey key, int slotId)
        {
            LootSlot slot = GetTable(key).GetSlot(slotId);
            var groups = new List<LootRateGroup>();
            var memo = new Dictionary<LootTableKey, List<LootChance>>();
            foreach (LootEntry entry in slot.Entries)
            {
                var part = new List<LootChance>();
                AddChances(slot, entry, 1m, 1m, slot.SlotId, entry.EntryId, part, 0, memo);
                if (part.Count > 0) groups.Add(new LootRateGroup(key, slotId, entry.EntryId, 0, slot.ShareOf(entry), part));
            }
            return groups;
        }

        // Chances of one roll of a nested table, computed once per call and merged by reward, so tables that share
        // sub-tables (a diamond of references) stay linear in size instead of doubling at every level.
        private List<LootChance> TableChances(LootTableKey key, Dictionary<LootTableKey, List<LootChance>> memo, int depth)
        {
            if (memo.TryGetValue(key, out List<LootChance> known)) return known;
            var all = new List<LootChance>();
            foreach (LootSlot slot in GetTable(key).Slots)
                foreach (LootEntry entry in slot.Entries)
                    AddChances(slot, entry, 1m, 1m, slot.SlotId, entry.EntryId, all, depth, memo);
            var merged = new List<LootChance>();
            var index = new Dictionary<(ConsumeTypeId, int, long, long), int>();
            foreach (LootChance chance in all)
            {
                var rewardKey = (chance.TypeId, chance.ItemId, chance.Min, chance.Max);
                if (index.TryGetValue(rewardKey, out int at))
                {
                    LootChance first = merged[at];
                    merged[at] = new LootChance(first.TypeId, first.ItemId, first.Min, first.Max,
                        first.Probability + chance.Probability, first.ExpectedCount + chance.ExpectedCount, 0, 0);
                }
                else
                {
                    index[rewardKey] = merged.Count;
                    merged.Add(chance);
                }
            }
            memo[key] = merged;
            return merged;
        }

        private void AddChances(LootSlot slot, LootEntry entry, decimal probability, decimal expected, int topSlot, int topEntry,
            List<LootChance> result, int depth, Dictionary<LootTableKey, List<LootChance>> memo)
        {
            if (depth > MaxDepth) throw new InvalidOperationException("Loot expansion exceeded the depth limit.");
            decimal share = slot.ShareOf(entry);
            if (share <= 0 || entry.IsNothing) return;
            decimal p = probability * share, e = expected * share;
            if (!Expands(entry))
            {
                result.Add(new LootChance(entry.TypeId, entry.ItemId, entry.Min, entry.Max, p, e, topSlot, topEntry));
                return;
            }
            decimal rolls = ((decimal)entry.Min + entry.Max) / 2m;
            foreach (LootChance nested in TableChances(entry.Reference, memo, depth + 1))
                result.Add(new LootChance(nested.TypeId, nested.ItemId, nested.Min, nested.Max,
                    p * nested.Probability, e * rolls * nested.ExpectedCount, topSlot, topEntry));
        }
    }

    public static class LootChances
    {
        /// <summary>Adds up chances of the same slot and the same reward range. Keeps the first entry ID and the first-seen order.</summary>
        public static List<LootChance> Merge(IEnumerable<LootChance> chances)
        {
            if (chances == null) throw new ArgumentNullException(nameof(chances));
            var order = new List<(int, ConsumeTypeId, int, long, long)>();
            var merged = new Dictionary<(int, ConsumeTypeId, int, long, long), LootChance>();
            foreach (LootChance chance in chances)
            {
                if (chance == null) throw new ArgumentException("The chance list contains a null entry.", nameof(chances));
                var key = chance.MergeKey;
                if (merged.TryGetValue(key, out LootChance current))
                    merged[key] = new LootChance(current.TypeId, current.ItemId, current.Min, current.Max,
                        current.Probability + chance.Probability, current.ExpectedCount + chance.ExpectedCount, current.SlotId, current.EntryId);
                else { merged.Add(key, chance); order.Add(key); }
            }
            return order.Select(key => merged[key]).ToList();
        }

        /// <summary>Merges, then groups by a key (for example grade). Groups run from the highest key down; inside a group,
        /// chances run from the highest probability down.</summary>
        public static List<LootRateGroup> GroupBy(IEnumerable<LootChance> chances, Func<LootChance, int> groupKey, LootTableKey table = default, int slotId = 0)
        {
            if (groupKey == null) throw new ArgumentNullException(nameof(groupKey));
            return Merge(chances)
                .GroupBy(groupKey)
                .OrderByDescending(group => group.Key)
                .Select(group =>
                {
                    List<LootChance> items = group.OrderByDescending(chance => chance.Probability).ToList();
                    return new LootRateGroup(table, slotId, 0, group.Key, items.Sum(chance => chance.Probability), items);
                })
                .ToList();
        }

        /// <summary>Sorts in place. Grade is read through the given selector; without one every grade is equal.</summary>
        public static void Sort(List<LootChance> chances, LootChanceOrder order, Func<LootChance, int> grade = null)
        {
            if (chances == null) throw new ArgumentNullException(nameof(chances));
            grade ??= _ => 0;
            int ByType(LootChance x, LootChance y)
            {
                int c = x.TypeId.Value.CompareTo(y.TypeId.Value);
                if (c != 0) return c;
                c = grade(y).CompareTo(grade(x));
                return c != 0 ? c : y.ItemId.CompareTo(x.ItemId);
            }
            Comparison<LootChance> comparison = order == LootChanceOrder.ByProbability
                ? (x, y) => { int c = x.Probability.CompareTo(y.Probability); return c != 0 ? c : ByType(x, y); }
                : ByType;
            // List.Sort is not stable; keep equal items in their original order.
            List<LootChance> sorted = chances.Select((chance, index) => (chance, index))
                .OrderBy(item => item, Comparer<(LootChance chance, int index)>.Create((a, b) => { int c = comparison(a.chance, b.chance); return c != 0 ? c : a.index.CompareTo(b.index); }))
                .Select(item => item.chance).ToList();
            chances.Clear();
            chances.AddRange(sorted);
        }

        /// <summary>Grade from the game's presentation provider; unresolved pairs count as grade 1.</summary>
        public static Func<LootChance, int> GradeFrom(IConsumePresentationProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            return chance => provider.TryResolve(chance.TypeId, chance.ItemId, out ConsumePresentation presentation) ? presentation.Grade : 1;
        }
    }
}
