using System;
using System.Collections.Generic;
using System.Linq;

namespace jjevol
{
    /// <summary>Validated, immutable loot tables. Rolling, previews, searches and probabilities all read the same graph,
    /// so the shown chances always describe the actual roll.</summary>
    public sealed partial class LootCatalog
    {
        /// <summary>The deepest allowed chain of Expand references.</summary>
        public const int MaxDepth = 32;

        private readonly Dictionary<ConsumeTypeId, LootKind> _kinds;
        private readonly LootTable[] _tables;
        private readonly Dictionary<LootTableKey, LootTable> _byKey;

        public IReadOnlyCollection<LootKind> Kinds => _kinds.Values;
        public IReadOnlyList<LootTable> Tables => _tables;
        /// <summary>Warnings found while building. Errors stop the build instead.</summary>
        public IReadOnlyList<LootIssue> Issues { get; }

        internal LootCatalog(Dictionary<ConsumeTypeId, LootKind> kinds, LootTable[] tables, IReadOnlyList<LootIssue> issues)
        {
            _kinds = kinds; _tables = tables; Issues = issues;
            _byKey = tables.ToDictionary(table => table.Key);
        }

        public bool IsLootType(ConsumeTypeId typeId) => _kinds.ContainsKey(typeId);
        public bool TryGetKind(ConsumeTypeId typeId, out LootKind kind) => _kinds.TryGetValue(typeId, out kind);
        public bool TryGetTable(LootTableKey key, out LootTable table) => _byKey.TryGetValue(key, out table);

        public LootTable GetTable(LootTableKey key)
            => _byKey.TryGetValue(key, out LootTable table) ? table : throw new KeyNotFoundException("Loot table " + key + " does not exist.");

        /// <summary>True when the consume names a loot table that exists.</summary>
        public bool TryGetTable(ConsumeData data, out LootTable table)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            table = null;
            return IsLootType(data.TypeId) && _byKey.TryGetValue(new LootTableKey(data.TypeId, data.ItemId), out table);
        }

        private bool Expands(LootEntry entry)
            => !entry.IsNothing && _kinds.TryGetValue(entry.TypeId, out LootKind kind) && kind.NestedMode == LootNestedMode.Expand;

        private LootTable TableOf(ConsumeData source)
        {
            if (!IsLootType(source.TypeId)) return null;
            return GetTable(new LootTableKey(source.TypeId, source.ItemId));
        }

        // ---------------------------------------------------------------- rolling

        /// <summary>Opens a consume. A loot type is rolled Quantity times (a range quantity is rolled first), whatever its
        /// nested mode; inner Grant references stay as rewards. Any other consume comes back with its range resolved.</summary>
        public List<ConsumeData> Roll(ConsumeData source, ILootRandom random)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (random == null) throw new ArgumentNullException(nameof(random));
            LootTable table = TableOf(source);
            if (table == null)
            {
                ConsumeData plain = source.Clone();
                if (plain.IsRandomVal) plain.SetConsumeVal(ResolveRange(plain.Min, plain.Max, random));
                return new List<ConsumeData> { plain };
            }
            if (source.Min < 0) throw new ArgumentException("A loot table cannot be opened a negative number of times.", nameof(source));
            var result = new List<ConsumeData>();
            long times = ResolveRange(source.Min, source.Max, random);
            for (long i = 0; i < times; i++) RollInto(table, random, result, 0);
            return result;
        }

        public List<ConsumeData> RollTable(LootTableKey key, ILootRandom random, long times = 1)
        {
            if (random == null) throw new ArgumentNullException(nameof(random));
            if (times < 0) throw new ArgumentOutOfRangeException(nameof(times));
            LootTable table = GetTable(key);
            var result = new List<ConsumeData>();
            for (long i = 0; i < times; i++) RollInto(table, random, result, 0);
            return result;
        }

        /// <summary>Rolls a table and reports each top-level slot pick with the rewards it produced (nested tables included).
        /// The rewards are the same as RollTable for the same random values. Use it when the game needs to know which slot
        /// gave what, for example to count pity (guarantee) streaks per slot.</summary>
        public List<LootPick> RollDetailed(LootTableKey key, ILootRandom random, long times = 1)
        {
            if (random == null) throw new ArgumentNullException(nameof(random));
            if (times < 0) throw new ArgumentOutOfRangeException(nameof(times));
            LootTable table = GetTable(key);
            var picks = new List<LootPick>();
            for (long roll = 0; roll < times; roll++)
                foreach (LootSlot slot in table.Slots)
                {
                    var rewards = new List<ConsumeData>();
                    LootEntry entry = RollSlot(slot, random, rewards, 0);
                    picks.Add(new LootPick(key, roll, slot.SlotId, entry, rewards));
                }
            return picks;
        }

        private void RollInto(LootTable table, ILootRandom random, List<ConsumeData> result, int depth)
        {
            if (depth > MaxDepth) throw new InvalidOperationException("Loot expansion exceeded the depth limit.");
            foreach (LootSlot slot in table.Slots) RollSlot(slot, random, result, depth);
        }

        private LootEntry RollSlot(LootSlot slot, ILootRandom random, List<ConsumeData> result, int depth)
        {
            LootEntry entry = slot.Pick(random);
            if (entry == null || entry.IsNothing) return entry;
            long amount = ResolveRange(entry.Min, entry.Max, random);
            if (Expands(entry))
            {
                LootTable child = GetTable(entry.Reference);
                for (long i = 0; i < amount; i++) RollInto(child, random, result, depth + 1);
            }
            else if (amount != 0)
                result.Add(new ConsumeData(entry.TypeId, entry.ItemId, amount));
            return entry;
        }

        private static long ResolveRange(long min, long max, ILootRandom random)
        {
            if (min == max) return min;
            if (min > max) throw new InvalidOperationException("Min is greater than Max.");
            long span;
            try { span = checked(checked(max - min) + 1); }
            catch (OverflowException) { throw new InvalidOperationException("The quantity range is too wide to roll."); }
            long offset = random.NextLong(span);
            if (offset < 0 || offset >= span) throw new InvalidOperationException("The random source returned a value outside [0, maxExclusive).");
            return min + offset;
        }

        // ---------------------------------------------------------------- previews and searches

        /// <summary>Every reward a consume can give, once each, in table order. Nested Expand tables are opened,
        /// Grant references are listed as rewards, zero-weight and "no reward" entries are left out.</summary>
        public List<ConsumeData> PossibleRewards(ConsumeData source, Func<ConsumeData, bool> include = null)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            LootTable table = TableOf(source);
            if (table == null) return include == null || include(source.Clone()) ? new List<ConsumeData> { source.Clone() } : new List<ConsumeData>();
            return PossibleRewards(table.Key, include);
        }

        public List<ConsumeData> PossibleRewards(LootTableKey key, Func<ConsumeData, bool> include = null)
        {
            var result = new List<ConsumeData>();
            var seen = new HashSet<(ConsumeTypeId, int, long, long)>();
            foreach (LootEntry entry in Leaves(GetTable(key), new HashSet<LootTableKey>()))
            {
                ConsumeData reward = entry.Outcome;
                if (include != null && !include(reward.Clone())) continue;
                if (seen.Add((entry.TypeId, entry.ItemId, entry.Min, entry.Max))) result.Add(reward);
            }
            return result;
        }

        public bool Contains(ConsumeData source, Func<ConsumeData, bool> predicate) => Find(source, predicate) != null;
        public bool Contains(ConsumeData source, ConsumeTypeId typeId) => Find(source, typeId) != null;
        public bool Contains(LootTableKey key, Func<ConsumeData, bool> predicate) => Find(key, predicate) != null;
        public bool Contains(LootTableKey key, ConsumeTypeId typeId) => Find(key, typeId) != null;
        public ConsumeData Find(ConsumeData source, ConsumeTypeId typeId) => Find(source, data => data.TypeId == typeId);
        public ConsumeData Find(LootTableKey key, ConsumeTypeId typeId) => Find(key, data => data.TypeId == typeId);

        /// <summary>The first reward the consume can give that matches, as a quantity range, or null.</summary>
        public ConsumeData Find(ConsumeData source, Func<ConsumeData, bool> predicate)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));
            LootTable table = TableOf(source);
            if (table == null) return predicate(source.Clone()) ? source.Clone() : null;
            return Find(table.Key, predicate);
        }

        public ConsumeData Find(LootTableKey key, Func<ConsumeData, bool> predicate)
        {
            if (predicate == null) throw new ArgumentNullException(nameof(predicate));
            foreach (LootEntry entry in Leaves(GetTable(key), new HashSet<LootTableKey>()))
            {
                ConsumeData reward = entry.Outcome;
                if (predicate(reward.Clone())) return reward;
            }
            return null;
        }

        // Reachable reward entries with a positive weight. The graph is acyclic; the set only skips repeated subtrees.
        private IEnumerable<LootEntry> Leaves(LootTable table, HashSet<LootTableKey> visited)
        {
            if (!visited.Add(table.Key)) yield break;
            foreach (LootSlot slot in table.Slots)
                foreach (LootEntry entry in slot.Entries)
                {
                    if (entry.IsNothing || entry.Weight <= 0) continue;
                    if (Expands(entry))
                    {
                        foreach (LootEntry leaf in Leaves(GetTable(entry.Reference), visited)) yield return leaf;
                    }
                    else yield return entry;
                }
        }

        // ---------------------------------------------------------------- economy connection

        /// <summary>For ConsumeDataGameExtensions.DropReward.</summary>
        public Func<ConsumeData, List<ConsumeData>> RollResolver(ILootRandom random)
        {
            if (random == null) throw new ArgumentNullException(nameof(random));
            return data => Roll(data, random);
        }

        /// <summary>For ConsumeDataGameExtensions.GetDropList. A default filter lists every reward; otherwise only that type.</summary>
        public Func<ConsumeData, ConsumeTypeId, List<ConsumeData>> PreviewResolver()
            => (data, filter) => PossibleRewards(data, filter.Value == 0 ? null : (Func<ConsumeData, bool>)(reward => reward.TypeId == filter));
    }
}
