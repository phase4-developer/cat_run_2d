using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using static jjevol.Tests.LootTestKit;

namespace jjevol.Tests
{
    public sealed class LootCatalogTests
    {
        // ------------------------------------------------------------ rolling

        [Test] public void PickUsesCumulativeWeightBoundaries()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 30))
                .AddEntry(PickTable(1), 0, Reward(Gem, 2, 10))
                .Build();
            Assert.AreEqual(Coin, catalog.RollTable(PickTable(1), new QueueRandom(29))[0].TypeId);
            Assert.AreEqual(Gem, catalog.RollTable(PickTable(1), new QueueRandom(30))[0].TypeId);
            Assert.AreEqual(Gem, catalog.RollTable(PickTable(1), new QueueRandom(39))[0].TypeId);
        }

        [Test] public void NestedRollCountIsUsed()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 1, 3))
                .AddEntry(PickTable(2), 0, Reward(Coin, 5, 1, 7))
                .Build();
            List<ConsumeData> rewards = catalog.RollTable(PickTable(1), new QueueRandom(0, 0, 0, 0));
            Assert.AreEqual(3, rewards.Count);
            Assert.IsTrue(rewards.All(reward => reward.TypeId == Coin && reward.Quantity == 7));
        }

        [Test] public void NestedRollRangeIsRolledFirst()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 1, 1, 3))
                .AddEntry(PickTable(2), 0, Reward(Coin, 5, 1))
                .Build();
            var random = new QueueRandom(0, 1, 0, 0); // pick, rolls 1+1=2, two child picks
            Assert.AreEqual(2, catalog.RollTable(PickTable(1), random).Count);
            Assert.AreEqual(new long[] { 1, 3, 1, 1 }, random.Bounds.ToArray());
        }

        [Test] public void QuantityRangeIsResolved()
        {
            LootCatalog catalog = Builder().AddEntry(PickTable(1), 0, Reward(Coin, 1, 1, 10, 20)).Build();
            ConsumeData reward = catalog.RollTable(PickTable(1), new QueueRandom(0, 4)).Single();
            Assert.AreEqual(14L, reward.Quantity);
            Assert.IsFalse(reward.IsRandomVal);
        }

        [Test] public void NothingEntryHoldsWeightAndGivesNothing()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, LootEntry.Nothing(25))
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 75))
                .Build();
            Assert.AreEqual(0, catalog.RollTable(PickTable(1), new QueueRandom(24)).Count);
            Assert.AreEqual(1, catalog.RollTable(PickTable(1), new QueueRandom(25)).Count);
            Assert.AreEqual(0.75m, catalog.Chances(PickTable(1)).Single().Probability);
        }

        [Test] public void ZeroWeightEntryIsNeverPickedNorListed()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Gem, 9, 0))
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 5))
                .Build();
            Assert.AreEqual(Coin, catalog.RollTable(PickTable(1), new QueueRandom(0)).Single().TypeId);
            Assert.AreEqual(1, catalog.PossibleRewards(PickTable(1)).Count);
            Assert.IsFalse(catalog.Contains(PickTable(1), Gem));
            Assert.AreEqual(1, catalog.Chances(PickTable(1)).Count);
        }

        [Test] public void EverySlotPicksOnce()
        {
            LootCatalog catalog = Builder()
                .AddEntry(ChestTable(1), 1, Reward(Coin, 1, 100))
                .AddEntry(ChestTable(1), 2, Reward(Gem, 2, 40, entryId: 7))
                .AddEntry(ChestTable(1), 2, Reward(Gear, 3, 60, entryId: 8))
                .Build();
            LootTable chest = catalog.GetTable(ChestTable(1));
            Assert.IsTrue(chest.HasMultipleSlots);
            Assert.AreEqual(100m, chest.GetSlot(2).TotalWeight);
            Assert.AreEqual(1, chest.GetSlot(2).FindEntryIndex(8));
            Assert.AreEqual(-1, chest.GetSlot(2).FindEntryIndex(99));
            List<ConsumeData> rewards = catalog.RollTable(ChestTable(1), new QueueRandom(0, 50));
            Assert.AreEqual(new[] { Coin, Gear }, rewards.Select(reward => reward.TypeId).ToArray());
        }

        [Test] public void GrantReferenceStaysARewardButTopLevelOpensIt()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Chest, 4, 1, 2))
                .AddEntry(ChestTable(4), 0, Reward(Gem, 1, 1, 5))
                .Build();
            ConsumeData granted = catalog.RollTable(PickTable(1), new QueueRandom(0)).Single();
            Assert.AreEqual(Chest, granted.TypeId);
            Assert.AreEqual(2L, granted.Quantity);
            List<ConsumeData> opened = catalog.Roll(granted, new QueueRandom(0, 0));
            Assert.AreEqual(2, opened.Count);
            Assert.IsTrue(opened.All(reward => reward.TypeId == Gem && reward.Quantity == 5));
        }

        [Test] public void DetailedRollReportsEachSlotPick()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(9), 0, Reward(Gem, 1, 1, 2))
                .AddEntry(ChestTable(1), 1, Reward(Pick, 9, 1, 2, entryId: 11))
                .AddEntry(ChestTable(1), 2, LootEntry.Nothing(1, 21))
                .AddEntry(ChestTable(1), 2, Reward(Coin, 1, 1, entryId: 22))
                .Build();
            List<LootPick> picks = catalog.RollDetailed(ChestTable(1), new QueueRandom(0, 0, 0, 0, 0, 0, 0, 1), 2);
            Assert.AreEqual(4, picks.Count);
            Assert.AreEqual(new long[] { 0, 0, 1, 1 }, picks.Select(p => p.Roll).ToArray());
            Assert.AreEqual(new[] { 11, 21, 11, 22 }, picks.Select(p => p.EntryId).ToArray());
            Assert.IsTrue(picks[1].IsNothing);
            Assert.AreEqual(0, picks[1].Rewards.Count);
            Assert.AreEqual(2, picks[0].Rewards.Count, "Nested rewards belong to the top-level pick.");
            Assert.AreEqual(Coin, picks[3].Rewards.Single().TypeId);
        }

        [Test] public void PlainConsumePassesThroughWithItsRangeResolved()
        {
            LootCatalog catalog = Builder().AddEntry(PickTable(1), 0, Reward(Coin, 1, 1)).Build();
            var plain = new ConsumeData(Gem, 3, 2, 6);
            ConsumeData result = catalog.Roll(plain, new QueueRandom(1)).Single();
            Assert.AreEqual(3L, result.Quantity);
            Assert.AreEqual(2L, plain.Min, "The source is not changed.");
        }

        [Test] public void UnknownTableThrowsAClearError()
        {
            LootCatalog catalog = Builder().AddEntry(PickTable(1), 0, Reward(Coin, 1, 1)).Build();
            var error = Assert.Throws<KeyNotFoundException>(() => catalog.Roll(new ConsumeData(Pick, 99, 1), new QueueRandom()));
            StringAssert.Contains(Pick + "_99", error.Message);
        }

        [Test] public void DecimalWeightsAreExact()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 0.5m))
                .AddEntry(PickTable(1), 0, Reward(Gem, 2, 1.25m))
                .Build();
            var random = new QueueRandom(49);
            Assert.AreEqual(Coin, catalog.RollTable(PickTable(1), random).Single().TypeId);
            Assert.AreEqual(175L, random.Bounds.Single());
            Assert.AreEqual(Gem, catalog.RollTable(PickTable(1), new QueueRandom(50)).Single().TypeId);
        }

        // ------------------------------------------------------------ probabilities

        [Test] public void NestedChancesAreNormalizedWhenWeightsDoNotSumTo100()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 30))
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 30))
                .AddEntry(PickTable(2), 0, Reward(Gem, 1, 1))
                .AddEntry(PickTable(2), 0, Reward(Gear, 1, 3))
                .Build();
            List<LootChance> chances = catalog.Chances(PickTable(1));
            Assert.AreEqual(0.5m, chances.Single(c => c.TypeId == Coin).Probability);
            Assert.AreEqual(0.125m, chances.Single(c => c.TypeId == Gem).Probability);
            Assert.AreEqual(0.375m, chances.Single(c => c.TypeId == Gear).Probability);
            Assert.AreEqual(1m, chances.Sum(c => c.Probability));
        }

        [Test] public void ChancesMatchEveryPossibleRoll()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 2))
                .AddEntry(PickTable(1), 0, LootEntry.Nothing(1))
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 3))
                .AddEntry(PickTable(2), 0, Reward(Gem, 1, 1))
                .AddEntry(PickTable(2), 0, Reward(Gear, 1, 4))
                .Build();
            var counts = new Dictionary<ConsumeTypeId, decimal>();
            for (long r1 = 0; r1 < 6; r1++)
                for (long r2 = 0; r2 < 5; r2++)
                {
                    var random = new QueueRandom(r1, r2);
                    foreach (ConsumeData reward in catalog.RollTable(PickTable(1), random))
                        counts[reward.TypeId] = (counts.TryGetValue(reward.TypeId, out decimal n) ? n : 0) + 1;
                }
            foreach (LootChance chance in LootChances.Merge(catalog.Chances(PickTable(1))))
                Assert.AreEqual(chance.Probability, counts[chance.TypeId] / 30m, chance.TypeId.ToString());
        }

        [Test] public void ExpectedCountIncludesNestedRolls()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 1, 1, 3))
                .AddEntry(PickTable(2), 0, Reward(Coin, 1, 1))
                .Build();
            LootChance chance = catalog.Chances(PickTable(1)).Single();
            Assert.AreEqual(1m, chance.Probability);
            Assert.AreEqual(2m, chance.ExpectedCount);
        }

        [Test] public void SlotGroupsAndEntryGroups()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(9), 0, Reward(Coin, 1, 1))
                .AddEntry(PickTable(9), 0, Reward(Gem, 1, 1))
                .AddEntry(ChestTable(1), 1, Reward(Pick, 9, 60, entryId: 101))
                .AddEntry(ChestTable(1), 1, Reward(Coin, 1, 20, entryId: 102))
                .AddEntry(ChestTable(1), 1, LootEntry.Nothing(20, 103))
                .AddEntry(ChestTable(1), 2, Reward(Gear, 1, 100, entryId: 201))
                .Build();

            List<LootRateGroup> bySlot = catalog.RateGroupsBySlot(ChestTable(1));
            Assert.AreEqual(2, bySlot.Count);
            Assert.AreEqual(0.8m, bySlot[0].Probability);
            LootChance coin = bySlot[0].Chances.Single(c => c.TypeId == Coin);
            Assert.AreEqual(0.5m, coin.Probability, "0.6 * 0.5 + 0.2, merged across entries");

            List<LootRateGroup> byEntry = catalog.RateGroupsByEntry(ChestTable(1), 1);
            Assert.AreEqual(new[] { 101, 102 }, byEntry.Select(g => g.EntryId).ToArray());
            Assert.AreEqual(0.6m, byEntry[0].Probability);
            Assert.AreEqual(0.3m, byEntry[0].Chances.Single(c => c.TypeId == Gem).Probability);
        }

        [Test] public void GroupByGradeAndSortOrders()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 50))
                .AddEntry(PickTable(1), 0, Reward(Gem, 2, 10))
                .AddEntry(PickTable(1), 0, Reward(Gem, 3, 40))
                .Build();
            Func<LootChance, int> grade = chance => chance.TypeId == Gem ? 3 : 1;
            List<LootRateGroup> groups = LootChances.GroupBy(catalog.Chances(PickTable(1)), grade, PickTable(1));
            Assert.AreEqual(new[] { 3, 1 }, groups.Select(g => g.GroupKey).ToArray());
            Assert.AreEqual(new[] { 3, 2 }, groups[0].Chances.Select(c => c.ItemId).ToArray());
            Assert.AreEqual(0.5m, groups[0].Probability);

            List<LootChance> list = catalog.Chances(PickTable(1));
            LootChances.Sort(list, LootChanceOrder.ByProbability, grade);
            Assert.AreEqual(new[] { 2, 3, 1 }, list.Select(c => c.ItemId).ToArray());
            LootChances.Sort(list, LootChanceOrder.ByType, grade);
            Assert.AreEqual(new[] { 1, 3, 2 }, list.Select(c => c.ItemId).ToArray());
        }

        [Test] public void GradeFromPresentationDefaultsToOne()
        {
            Func<LootChance, int> grade = LootChances.GradeFrom(new GradeProvider());
            Assert.AreEqual(5, grade(new LootChance(Gem, 1, 1, 1, 1, 1, 0, 0)));
            Assert.AreEqual(1, grade(new LootChance(Coin, 1, 1, 1, 1, 1, 0, 0)));
        }

        private sealed class GradeProvider : IConsumePresentationProvider
        {
            public bool TryResolve(ConsumeTypeId typeId, int itemId, out ConsumePresentation presentation)
            {
                presentation = new ConsumePresentation(grade: 5);
                return typeId == Gem;
            }
            public ConsumePresentation Resolve(ConsumeData data) => default;
        }

        // ------------------------------------------------------------ previews and searches

        [Test] public void PossibleRewardsOpenExpandAndKeepGrant()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 1))
                .AddEntry(PickTable(1), 0, Reward(Chest, 3, 1))
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 1, 5, 9))
                .AddEntry(PickTable(2), 0, Reward(Gem, 4, 1))
                .AddEntry(PickTable(2), 0, Reward(Coin, 1, 1, 5, 9))
                .AddEntry(ChestTable(3), 0, Reward(Gear, 1, 1))
                .Build();
            List<ConsumeData> rewards = catalog.PossibleRewards(new ConsumeData(Pick, 1, 4));
            Assert.AreEqual(new[] { Gem, Coin, Chest }, rewards.Select(r => r.TypeId).ToArray(), "Distinct, table order");
            Assert.AreEqual(9L, rewards[1].Max);
            Assert.AreEqual(1, catalog.PossibleRewards(PickTable(1), r => r.TypeId == Gem).Count);
        }

        [Test] public void FindSearchesNestedTablesWithAPredicate()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 1))
                .AddEntry(PickTable(2), 0, Reward(Gear, 44, 1, 2, 3))
                .Build();
            Assert.IsTrue(catalog.Contains(PickTable(1), r => r.TypeId == Gear && r.ItemId == 44));
            ConsumeData found = catalog.Find(new ConsumeData(Pick, 1, 1), Gear);
            Assert.AreEqual(2L, found.Min);
            Assert.AreEqual(3L, found.Max);
            Assert.IsNull(catalog.Find(PickTable(1), Coin));
            Assert.IsTrue(catalog.Contains(new ConsumeData(Coin, 1, 1), Coin), "A plain consume matches itself.");
        }

        [Test] public void EconomyExtensionsUseTheCatalog()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 1, 3))
                .AddEntry(PickTable(1), 0, Reward(Gem, 1, 1))
                .Build();
            List<ConsumeData> dropped = new ConsumeData(Pick, 1, 2).DropReward(catalog.RollResolver(new QueueRandom(0, 1)));
            Assert.AreEqual(new[] { Coin, Gem }, dropped.Select(r => r.TypeId).ToArray());
            List<ConsumeData> gems = new ConsumeData(Pick, 1, 1).GetDropList(catalog.PreviewResolver(), Gem);
            Assert.AreEqual(Gem, gems.Single().TypeId);
            Assert.AreEqual(2, new ConsumeData(Pick, 1, 1).GetDropList(catalog.PreviewResolver()).Count);
        }

        // ------------------------------------------------------------ validation

        [Test] public void LoopIsAnErrorNotAStackOverflow()
        {
            LootCatalogBuilder builder = Builder()
                .AddEntry(PickTable(1), 0, Reward(Pick, 2, 1))
                .AddEntry(PickTable(2), 0, Reward(Pick, 3, 1))
                .AddEntry(PickTable(3), 0, Reward(Pick, 1, 1));
            var error = Assert.Throws<LootValidationException>(() => builder.Build());
            StringAssert.Contains("->", Single(error.Issues, LootIssueCode.Cycle).Message);
        }

        [Test] public void GrantReferenceLoopIsAllowed()
        {
            LootCatalog catalog = Builder()
                .AddEntry(ChestTable(1), 0, Reward(Chest, 2, 1))
                .AddEntry(ChestTable(2), 0, Reward(Chest, 1, 1))
                .Build();
            Assert.AreEqual(Chest, catalog.RollTable(ChestTable(1), new QueueRandom(0)).Single().TypeId);
        }

        [Test] public void MissingReferenceIsAnError()
        {
            var error = Assert.Throws<LootValidationException>(() => Builder().AddEntry(PickTable(1), 0, Reward(Chest, 8, 1)).Build());
            Assert.AreEqual(1, Single(error.Issues, LootIssueCode.MissingTable).Table.Id);
        }

        [Test] public void SlotWeightMustMatchWhenTheKindAsksForIt()
        {
            Assert.DoesNotThrow(() => Builder(100m)
                .AddEntry(ChestTable(1), 0, Reward(Coin, 1, 33.33m))
                .AddEntry(ChestTable(1), 0, Reward(Gem, 1, 33.33m))
                .AddEntry(ChestTable(1), 0, Reward(Gear, 1, 33.34m))
                .Build());
            var error = Assert.Throws<LootValidationException>(() => Builder(100m)
                .AddEntry(ChestTable(1), 0, Reward(Coin, 1, 33.33m))
                .AddEntry(ChestTable(1), 0, Reward(Gem, 1, 33.33m))
                .Build());
            Single(error.Issues, LootIssueCode.SlotWeightMismatch);
        }

        [Test] public void EntryProblemsAreReportedTogether()
        {
            var builder = new LootCatalogBuilder().AddKind(Pick, LootNestedMode.Expand)
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, -1))
                .AddEntry(PickTable(1), 0, new LootEntry(0, 1, Gem, 1, 5, 2))
                .AddEntry(PickTable(1), 0, new LootEntry(0, 1, Gear, 1, -3, -1))
                .AddEntry(PickTable(1), 0, new LootEntry(0, 1, Pick, 2, 0, 0))
                .AddEntry(PickTable(2), 0, Reward(Coin, 1, 1))
                .AddEntry(new LootTableKey(Gem, 1), 0, Reward(Coin, 1, 1));
            IReadOnlyList<LootIssue> issues = builder.Validate();
            Single(issues, LootIssueCode.NegativeWeight);
            Single(issues, LootIssueCode.InvalidQuantityRange);
            Single(issues, LootIssueCode.NegativeQuantity);
            Single(issues, LootIssueCode.NestedRollsNotPositive);
            Single(issues, LootIssueCode.UnregisteredKind);
            Assert.Throws<LootValidationException>(() => builder.Build());
        }

        [Test] public void WarningsDoNotStopTheBuild()
        {
            LootCatalog catalog = Builder()
                .AddEntry(PickTable(1), 0, Reward(Coin, 1, 0, entryId: 5))
                .AddEntry(PickTable(1), 0, Reward(Gem, 1, 0, entryId: 5))
                .Build();
            Assert.AreEqual(LootIssueSeverity.Warning, Single(catalog.Issues, LootIssueCode.ZeroTotalWeight).Severity);
            Single(catalog.Issues, LootIssueCode.DuplicateEntryId);
            Assert.AreEqual(0, catalog.RollTable(PickTable(1), new QueueRandom()).Count);
        }

        private static LootCatalogBuilder Chain(int expandEdges)
        {
            LootCatalogBuilder builder = Builder();
            for (int i = 0; i < expandEdges; i++) builder.AddEntry(PickTable(i), 0, Reward(Pick, i + 1, 1));
            return builder.AddEntry(PickTable(expandEdges), 0, Reward(Coin, 1, 1));
        }

        [Test] public void ChainAtTheDepthLimitBuildsAndRolls()
        {
            LootCatalog catalog = Chain(LootCatalog.MaxDepth).Build();
            Assert.AreEqual(Coin, catalog.RollTable(PickTable(0), new SystemLootRandom(3)).Single().TypeId);
            Assert.AreEqual(1m, catalog.Chances(PickTable(0)).Single().Probability);
        }

        [Test] public void ChainOneOverTheLimitIsReportedAtItsTop()
        {
            var error = Assert.Throws<LootValidationException>(() => Chain(LootCatalog.MaxDepth + 1).Build());
            Assert.AreEqual(PickTable(0), Single(error.Issues, LootIssueCode.DepthLimit).Table);
        }

        [Test] public void VeryLongChainIsReportedWithoutOverflow()
        {
            var error = Assert.Throws<LootValidationException>(() => Chain(50000).Build());
            Assert.AreEqual(PickTable(0), Single(error.Issues, LootIssueCode.DepthLimit).Table);
        }

        // Every level points twice at the next one: 2^32 paths, but each table is worked out once.
        [Test] public void SharedSubTablesAreNotWalkedPerPath()
        {
            LootCatalogBuilder builder = Builder();
            for (int i = 0; i < LootCatalog.MaxDepth; i++)
                builder.AddEntry(PickTable(i), 0, Reward(Pick, i + 1, 1, entryId: 1)).AddEntry(PickTable(i), 0, Reward(Pick, i + 1, 1, entryId: 2));
            LootCatalog catalog = builder.AddEntry(PickTable(LootCatalog.MaxDepth), 0, Reward(Coin, 1, 1)).Build();

            List<LootChance> chances = catalog.Chances(PickTable(0));
            Assert.AreEqual(new[] { 1, 2 }, chances.Select(c => c.EntryId).ToArray());
            Assert.AreEqual(1m, chances.Sum(c => c.Probability));
            Assert.AreEqual(1m, catalog.RateGroupsBySlot(PickTable(0)).Single().Chances.Single().Probability);
            Assert.AreEqual(2, catalog.RateGroupsByEntry(PickTable(0), 0).Count);
            Assert.AreEqual(Coin, catalog.PossibleRewards(PickTable(0)).Single().TypeId);
        }

        [Test] public void DeepChainIsAnError()
        {
            LootCatalogBuilder builder = Builder();
            for (int i = 0; i <= LootCatalog.MaxDepth + 1; i++) builder.AddEntry(PickTable(i), 0, Reward(Pick, i + 1, 1));
            builder.AddEntry(PickTable(LootCatalog.MaxDepth + 2), 0, Reward(Coin, 1, 1));
            var error = Assert.Throws<LootValidationException>(() => builder.Build());
            Assert.IsTrue(Has(error.Issues, LootIssueCode.DepthLimit));
            Assert.IsFalse(Has(error.Issues, LootIssueCode.Cycle));
        }

        [Test] public void KindsAreRegisteredOnce()
        {
            Assert.Throws<ArgumentException>(() => Builder().AddKind(Pick, LootNestedMode.Grant));
            Assert.Throws<ArgumentException>(() => new LootCatalogBuilder().AddKind(default, LootNestedMode.Expand));
        }

        // ------------------------------------------------------------ random source

        [Test] public void SystemRandomIsSeededAndInRange()
        {
            var a = new SystemLootRandom(7);
            var b = new SystemLootRandom(7);
            long big = (long)int.MaxValue * 4 + 3;
            for (int i = 0; i < 200; i++)
            {
                long x = a.NextLong(big);
                Assert.AreEqual(x, b.NextLong(big));
                Assert.IsTrue(x >= 0 && x < big);
                long y = a.NextLong(3);
                Assert.AreEqual(y, b.NextLong(3));
                Assert.IsTrue(y >= 0 && y < 3);
            }
            Assert.Throws<ArgumentOutOfRangeException>(() => a.NextLong(0));
        }

        [Test] public void OutOfRangeRandomIsRejected()
        {
            LootCatalog catalog = Builder().AddEntry(PickTable(1), 0, Reward(Coin, 1, 2)).Build();
            Assert.Throws<InvalidOperationException>(() => catalog.RollTable(PickTable(1), new BrokenRandom()));
        }

        private sealed class BrokenRandom : ILootRandom
        {
            public long NextLong(long maxExclusive) => maxExclusive;
        }
    }
}
