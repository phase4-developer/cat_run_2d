using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using static jjevol.Tests.LootTestKit;

namespace jjevol.Tests
{
    public sealed class LootTsvTests
    {
        private static List<TSVRow> Rows(params string[] lines) => TSVRow.FromTsv(string.Join("\n", lines));

        [Test] public void PickRowsWithTypedOutcomes()
        {
            List<TSVRow> rows = Rows(
                "id\ttable\tweight\ttype\titem\tamount\tamountMin\tamountMax\ticon",
                "1\t5\t40\t11\t1\t\t10\t20\tcoin_icon",
                "2\t5\t35.5\t70\t6\t2\t\t\t",
                "3\t5\t24.5\t0\t\t\t\t\t",
                "4\t6\t1\t12\t9\t\t\t\t");
            LootCatalog catalog = Builder().AddRows(rows, new LootTsvLayout(Pick), row => row.GetString("icon")).Build();

            LootSlot slot = catalog.GetTable(PickTable(5)).GetSlot(0);
            Assert.AreEqual(3, slot.Entries.Count);
            Assert.AreEqual(100m, slot.TotalWeight);
            Assert.AreEqual(10L, slot.Entries[0].Min);
            Assert.AreEqual(20L, slot.Entries[0].Max);
            Assert.AreEqual(2L, slot.Entries[1].Max, "A single amount sets both ends.");
            Assert.IsTrue(slot.Entries[2].IsNothing);
            Assert.AreEqual(1L, catalog.GetTable(PickTable(6)).GetSlot(0).Entries[0].Min, "No amount columns means 1.");
            Assert.AreEqual("coin_icon", catalog.GetTable(PickTable(5)).Tag);
        }

        [Test] public void BoxRowsWithAFixedTypeAndSlots()
        {
            List<TSVRow> pickRows = Rows("table\tweight\ttype\titem", "8\t1\t11\t1");
            List<TSVRow> boxRows = Rows(
                "id\tbox\tline\tweight\tdrop\tamountMin\tamountMax",
                "1\t3\t1\t70\t8\t1\t2",
                "2\t3\t1\t30\t0\t\t",
                "3\t3\t2\t100\t8\t1\t1");
            var layout = new LootTsvLayout(Chest)
            {
                TableColumn = "box", SlotColumn = "line", TypeColumn = null, FixedType = Pick, ItemColumn = "drop",
            };
            LootCatalog catalog = Builder(100m).AddRows(pickRows, new LootTsvLayout(Pick)).AddRows(boxRows, layout).Build();

            LootTable box = catalog.GetTable(ChestTable(3));
            Assert.AreEqual(new[] { 1, 2 }, box.Slots.Select(s => s.SlotId).ToArray());
            Assert.IsTrue(box.GetSlot(1).Entries[1].IsNothing, "An item ID of 0 under a fixed type is no reward.");
            Assert.AreEqual(Pick, box.GetSlot(1).Entries[0].TypeId);
            Assert.AreEqual(0.7m, catalog.RateGroupsBySlot(ChestTable(3))[0].Probability);
        }

        // Both kinds can use one column layout; a box line can give a reward directly or go through a pick table.
        [Test] public void OneColumnLayoutForPicksAndBoxes()
        {
            List<TSVRow> pickRows = Rows(
                "id\tset\tkind\tref\tqtyLow\tqtyHigh\tweight",
                "1\t1\t11\t1\t5\t5\t7000",
                "2\t1\t0\t0\t0\t0\t3000");
            List<TSVRow> boxRows = Rows(
                "id\tbundle\tline\tkind\tref\tqtyLow\tqtyHigh\tweight",
                "1\t1\t1\t70\t1\t2\t2\t10000",
                "2\t1\t2\t12\t4\t1\t3\t2500",
                "3\t1\t2\t0\t0\t0\t0\t7500");
            LootTsvLayout Shape(ConsumeTypeId kind, string table, string slot) => new LootTsvLayout(kind)
            {
                TableColumn = table, SlotColumn = slot, TypeColumn = "kind", ItemColumn = "ref",
                AmountColumn = null, MinColumn = "qtyLow", MaxColumn = "qtyHigh",
            };
            LootCatalog catalog = Builder()
                .AddRows(pickRows, Shape(Pick, "set", null))
                .AddRows(boxRows, Shape(Chest, "bundle", "line"))
                .Build();

            Assert.IsTrue(catalog.GetTable(PickTable(1)).GetSlot(0).Entries[1].IsNothing, "Type 0 with zero cells is no reward.");
            List<LootRateGroup> lines = catalog.RateGroupsBySlot(ChestTable(1));
            Assert.AreEqual(1m, lines[0].Probability, "Line 1 always lands on the pick-table entry.");
            Assert.AreEqual(0.7m, lines[0].Chances.Single().Probability, "30% of each run is empty.");
            Assert.AreEqual(1.4m, lines[0].Chances.Single().ExpectedCount, "Two runs.");
            Assert.AreEqual(0.25m, lines[1].Probability);
            List<ConsumeData> rewards = catalog.RollTable(ChestTable(1), new QueueRandom(0, 0, 6999, 0, 1));
            Assert.AreEqual(new[] { Coin, Coin, Gem }, rewards.Select(r => r.TypeId).ToArray());
            Assert.AreEqual(2L, rewards[2].Quantity);
        }

        [Test] public void NamedTypesNeedAParser()
        {
            List<TSVRow> rows = Rows("table\tweight\ttype\titem", "1\t1\tCoin\t1");
            var error = Assert.Throws<InvalidDataException>(() => Builder().AddRows(rows, new LootTsvLayout(Pick)));
            StringAssert.Contains("row 1", error.Message);
            LootCatalog catalog = Builder().AddRows(rows, new LootTsvLayout(Pick) { ParseType = name => name == "Coin" ? Coin : default }).Build();
            Assert.AreEqual(Coin, catalog.GetTable(PickTable(1)).GetSlot(0).Entries[0].TypeId);
        }

        [Test] public void MalformedRowsNameTheRow()
        {
            var missingWeight = Assert.Throws<InvalidDataException>(() => Builder().AddRows(Rows("table\ttype\titem", "1\t11\t1", "2\t11\t1"), new LootTsvLayout(Pick)));
            StringAssert.Contains("row 1", missingWeight.Message);
            var halfRange = Assert.Throws<InvalidDataException>(() => Builder().AddRows(Rows("table\tweight\ttype\titem\tamountMin", "1\t1\t11\t1\t", "1\t1\t11\t1\t3"), new LootTsvLayout(Pick)));
            StringAssert.Contains("row 2", halfRange.Message);
        }

        [Test] public void ExponentWeightIsRejected()
        {
            var error = Assert.Throws<InvalidDataException>(() => Builder().AddRows(Rows("table\tweight\ttype\titem", "1\t1e-30\t11\t1"), new LootTsvLayout(Pick)));
            StringAssert.Contains("row 1", error.Message);
        }

        [Test] public void FixedTypeNeedsTheItemColumn()
        {
            List<TSVRow> rows = Rows("box\tweight\tpick", "1\t1\t3");
            var layout = new LootTsvLayout(Chest) { TableColumn = "box", TypeColumn = null, FixedType = Pick, ItemColumn = "drop" };
            var error = Assert.Throws<InvalidDataException>(() => Builder().AddRows(rows, layout));
            StringAssert.Contains("'drop'", error.Message);
        }

        [Test] public void TableTagRunsOncePerTableEvenWhenItReturnsNull()
        {
            List<TSVRow> rows = Rows("table\tweight\ttype\titem", "1\t1\t11\t1", "1\t1\t11\t2", "2\t1\t11\t1", "1\t1\t11\t3");
            int calls = 0;
            Builder().AddRows(rows, new LootTsvLayout(Pick), row => { calls++; return null; });
            Assert.AreEqual(2, calls);
        }
    }
}
