using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace jjevol.Tests
{
    // Synthetic types only. Numbers are arbitrary and belong to no game.
    internal static class LootTestKit
    {
        internal static readonly ConsumeTypeId Coin = new ConsumeTypeId(11);
        internal static readonly ConsumeTypeId Gem = new ConsumeTypeId(12);
        internal static readonly ConsumeTypeId Gear = new ConsumeTypeId(13);
        internal static readonly ConsumeTypeId Pick = new ConsumeTypeId(70);  // Expand
        internal static readonly ConsumeTypeId Chest = new ConsumeTypeId(71); // Grant

        internal static LootTableKey PickTable(int id) => new LootTableKey(Pick, id);
        internal static LootTableKey ChestTable(int id) => new LootTableKey(Chest, id);

        internal static LootCatalogBuilder Builder(decimal? chestSlotWeight = null)
            => new LootCatalogBuilder().AddKind(Pick, LootNestedMode.Expand).AddKind(Chest, LootNestedMode.Grant, chestSlotWeight);

        internal static LootEntry Reward(ConsumeTypeId type, int item, decimal weight, long min = 1, long max = -1, int entryId = 0)
            => new LootEntry(entryId, weight, type, item, min, max < 0 ? min : max);

        internal static LootIssue Single(IReadOnlyList<LootIssue> issues, LootIssueCode code)
        {
            LootIssue found = null;
            foreach (LootIssue issue in issues)
                if (issue.Code == code) { Assert.IsNull(found, "More than one " + code); found = issue; }
            Assert.IsNotNull(found, "No " + code + " issue");
            return found;
        }

        internal static bool Has(IReadOnlyList<LootIssue> issues, LootIssueCode code)
        {
            foreach (LootIssue issue in issues) if (issue.Code == code) return true;
            return false;
        }
    }

    /// <summary>Returns queued values in order and checks each against the requested bound.</summary>
    internal sealed class QueueRandom : ILootRandom
    {
        private readonly Queue<long> _values;
        internal readonly List<long> Bounds = new List<long>();
        internal QueueRandom(params long[] values) { _values = new Queue<long>(values); }
        internal int Remaining => _values.Count;

        public long NextLong(long maxExclusive)
        {
            Bounds.Add(maxExclusive);
            if (_values.Count == 0) throw new InvalidOperationException("The test queued too few random values.");
            long value = _values.Dequeue();
            Assert.IsTrue(value >= 0 && value < maxExclusive, "Queued value " + value + " is outside [0, " + maxExclusive + ").");
            return value;
        }
    }
}
