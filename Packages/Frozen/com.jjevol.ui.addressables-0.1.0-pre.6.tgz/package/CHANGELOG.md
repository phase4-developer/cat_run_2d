# Changelog

## 0.1.0-pre.6 - 2026-11-11

- `UIAddress`, `UIAddressIdAttribute` and `UIIdConstants` (with the `[UIAddressId]` drawer and its tests), `IScreenData` and `IPopupData` moved to `com.jjevol.ui.contracts`. Namespace, names, the menu and the GUIDs of moved files are unchanged. A game assembly definition that uses them needs a `JJEvol.UI.Contracts.Runtime` reference; Assembly-CSharp gets it automatically.
- Depends on `com.jjevol.ui.contracts` 0.1.0-pre.1 and `com.jjevol.ui` 0.1.0-pre.3.

## 0.1.0-pre.5 - 2026-11-10

- `GameObject/UI/AddressableImage` and `GameObject/UI/AddressableTexture` are now `GameObject/UI/JJEvol/Addressable Image` and `Addressable Texture`. `JJEvol/UI/Generate UI ID Constants` is unchanged. Framework menus are grouped by feature under one `JJEvol/` root (Editor menus), `Assets/Create/JJEvol/` (asset menus) and `GameObject/UI/JJEvol/` (UI objects). Only the menu path changed; class names, serialized fields and GUIDs are unchanged, so existing assets keep working.
- Tests only. The atlas preview tests count a clone as any `step11_` sprite that is not a saved asset, not by `(Clone)` in its name, which stays 0 on Unity 6.7. A failing count lists the `step11_` sprites in memory. Runtime and Editor code are unchanged by this. It was listed as Unreleased while the version stayed 0.1.0-pre.4 to match the first delivery bundle tgz.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.4 - 2026-11-07

- Breaking: `UIScreenTypes`, `UIPopupTypes` and `UIHudTypes` are removed. Screens, Popups and HUDs use game-owned string IDs. Addresses stay `UIScreen_{id}`, `UIPopup_{id}` and `UIHud_{id}`.
- Added `UIAddress`, `[UIAddressId]` with an Inspector dropdown, and `JJEvol/UI/Generate UI ID Constants`.
- Breaking: `UICommonBtn`, `SoundType`, `IUIInteractable` and `IUIDisable` are removed. Added `UIButtonLock`, `UIButtonSound`, `UIButtonStateVisual` and `UIButtonHoldRepeat` for Unity `Button`.
- `UIPopup` plays its optional `closeSoundKey` instead of a fixed sound.
- `UIEvent.Trigger` takes a string ID in place of the two enum overloads.

## 0.1.0-pre.3 - 2026-11-06

- Added `UIManager.AcquireLoadingAsync` and `UILoadingSession` for owned, reference counted full screen loading.
- Extracted shared image loading, preview mesh and Inspector code. Prefabs still keep only string keys.
- `Show Loading` is now the only loading switch, and loading display no longer blocks the image load.
- Fixed sound exceptions interrupting input, replaced Screen requests, closing Popup reopen, `CloseWait` results and lease leaks on never activated objects.
- Inspector warns about assets that are not Addressable.
- Added `AddressableImage.IsLoadDeferred` and `AddressableTexture.IsLoadDeferred`.

Unity tests for this candidate are NOT_RUN.
