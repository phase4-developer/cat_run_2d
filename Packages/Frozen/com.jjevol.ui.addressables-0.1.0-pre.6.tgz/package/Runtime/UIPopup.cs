//수정
using Cysharp.Threading.Tasks;
using System;
using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    public class UIPopup : UIBase
    {
        [Serializable]
        public struct CanvasGroupInfo
        {
            public CanvasGroup CanvasGroup;
            public bool Interactable;
            public bool BlocksRaycasts;
        }

        public bool IsOpen => isOpen;

        protected void SetContentsDirty()
        {
            foreach (UIBase ui in GetComponentsInChildren<UIBase>())
                if (ui.isActiveAndEnabled) ui.SetDirty();
        }

        [SerializeField] private MonoBehaviour transition;
        private IUITransition Transition => transition != null ? transition as IUITransition ?? throw new InvalidOperationException("The assigned transition must implement IUITransition; install the matching vendor integration.") : null;
        [SerializeField] private UIDynamicCanvasBinder canvasBinder;

        [Header("HUD Settings")]
        public UIHudSettings hudSettings = new UIHudSettings();

        private bool isOpen = false;

        [UIAddressId(UIAddress.PopupPrefix)] public string PopupType;
        [SerializeField] private string closeSoundKey;

        /// <summary>
        /// 팝업 결과를 외부에서 기다릴 수 있게 하는 TaskCompletionSource.
        /// </summary>
        private UniTaskCompletionSource<bool> m_resultSource;

        /// <summary>
        /// Hide Transition 완료 후 CloseWait에 전달할 결과.
        /// null이면 명시적인 Close 결과가 없는 Hide로 보고 CloseWait을 취소한다.
        /// </summary>
        private bool? _pendingCloseResult;

        /// <summary>
        /// 닫힘이 끝난 뒤의 CloseWait 호출이 영원히 기다리지 않도록 마지막 결과를 보존한다.
        /// _closeResult가 null이면 결과 없이 닫힌 것이므로 취소로 돌려준다.
        /// </summary>
        private bool _closeFinished;
        private bool? _closeResult;

        public IPopupData popupData { get; private set; }

        private CanvasGroupInfo popupCanvasGroup;
        private bool hasPopupCanvasGroup;

        public bool IsTransitioning => transition != null && Transition.IsTransitioning;

        /// <summary>
        /// 컴포넌트 참조와 CanvasGroup 상태를 초기화한다.
        /// </summary>
        protected virtual void Awake()
        {
            if (!transition) foreach (var component in GetComponents<MonoBehaviour>())
            {
                if(component==null)throw new InvalidOperationException("This popup contains a missing script. Install its required transition/integration before use.");
                if(component is IUITransition) { transition = component; break; }
            }
            if (!canvasBinder) canvasBinder = GetComponent<UIDynamicCanvasBinder>();

            InitCanvasGroup();
        }

        /// <summary>
        /// 자식 CanvasGroup들의 원래 입력 상태를 저장한다.
        /// </summary>
        private void InitCanvasGroup()
        {
            CanvasGroup targetCanvasGroup = null;

            if (transition != null)
                targetCanvasGroup = Transition.TargetCanvasGroup;

            if (targetCanvasGroup == null)
                targetCanvasGroup = FindTopCanvasGroup();

            if (targetCanvasGroup == null)
            {
                hasPopupCanvasGroup = false;
                return;
            }

            popupCanvasGroup.CanvasGroup = targetCanvasGroup;
            popupCanvasGroup.Interactable = targetCanvasGroup.interactable;
            popupCanvasGroup.BlocksRaycasts = targetCanvasGroup.blocksRaycasts;

            hasPopupCanvasGroup = true;
        }

        private CanvasGroup FindTopCanvasGroup()
        {
            CanvasGroup[] groups = GetComponentsInChildren<CanvasGroup>(true);
            if (groups == null || groups.Length == 0)
                return null;

            CanvasGroup topCanvasGroup = null;
            int topDepth = int.MaxValue;

            for (int i = 0; i < groups.Length; i++)
            {
                CanvasGroup group = groups[i];
                if (group == null)
                    continue;

                int depth = GetDepthFromPopupRoot(group.transform);
                if (depth < 0)
                    continue;

                if (depth < topDepth)
                {
                    topDepth = depth;
                    topCanvasGroup = group;
                }
            }

            return topCanvasGroup;
        }

        private int GetDepthFromPopupRoot(Transform target)
        {
            int depth = 0;
            Transform current = target;

            while (current != null)
            {
                if (current == transform)
                    return depth;

                current = current.parent;
                depth++;
            }

            return -1;
        }

        /// <summary>
        /// 팝업 내부 CanvasGroup 입력 가능 상태를 변경한다.
        /// Show Transition 중에는 입력을 막고, 완료 후 원래 상태로 되돌린다.
        /// </summary>
        public void SetCanvasGroupInteractable(bool interactable)
        {
            if (!hasPopupCanvasGroup) return;
            if (popupCanvasGroup.CanvasGroup == null) return;

            popupCanvasGroup.CanvasGroup.interactable = interactable ? popupCanvasGroup.Interactable : false;
            popupCanvasGroup.CanvasGroup.blocksRaycasts = interactable ? popupCanvasGroup.BlocksRaycasts : false;
        }

        /// <summary>
        /// 팝업을 표시한다.
        /// Show Transition이 끝나기 전까지는 내부 버튼/백판 클릭을 막는다.
        /// </summary>
        public override void ShowUI()
        {
            if (isOpen) return;

            if (canvasBinder) canvasBinder.BindToDynamicOnce();

            isOpen = true;
            _pendingCloseResult = null;
            _closeFinished = false;
            _closeResult = null;

            base.ShowUI();

            SetCanvasGroupInteractable(false);

            if (transition != null)
            {
                Transition.ShowCompleted.RemoveListener(OnShowTransitionComplete);
                Transition.ShowCompleted.AddListener(OnShowTransitionComplete);
                Transition.OnWindowAdded();

                SetCanvasGroupInteractable(false);
            }
            else
            {
                OnShowTransitionComplete();
            }

            if(UIManager.HasInstance)UIManager.Instance.UpdateGlobalHudState(this);
        }

        /// <summary>
        /// 팝업을 숨긴다.
        /// Hide Transition이 끝난 뒤 onHide와 CloseWait 결과를 처리한다.
        /// </summary>
        public override void HideUI()
        {
            if (!isOpen) return;

            isOpen = false;

            SetCanvasGroupInteractable(false);

            if (transition != null)
            {
                Transition.HideCompleted.RemoveListener(OnHideTransitionComplete);
                Transition.HideCompleted.AddListener(OnHideTransitionComplete);
                Transition.OnWindowRemove();
            }
            else
            {
                OnHideTransitionComplete();
            }
        }

        /// <summary>
        /// 팝업 UI를 제거한다.
        /// ReleaseHandle이 있으면 Addressables Release를 사용한다.
        /// </summary>
        public virtual void DestroyUI()
        {
            if (m_ReleaseHandle != null)
            {
                m_ReleaseHandle.Release(this);
            }
            else
            {
                Destroy(gameObject);
            }
        }

        /// <summary>
        /// Show Transition 완료 후 팝업 입력을 활성화한다.
        /// </summary>
        private void OnShowTransitionComplete()
        {
            if (transition != null)
                Transition.ShowCompleted.RemoveListener(OnShowTransitionComplete);

            if (!isOpen)
                return;

            SetCanvasGroupInteractable(true);
        }

        /// <summary>
        /// Hide Transition 완료 후 팝업 제거와 CloseWait 결과를 처리한다.
        /// </summary>
        private void OnHideTransitionComplete()
        {
            if (transition != null)
                Transition.HideCompleted.RemoveListener(OnHideTransitionComplete);

            onHide?.Invoke(this);

            if(UIManager.HasInstance)UIManager.Instance.RefreshGlobalHudState();

            CompleteCloseWait();

            DestroyUI();
        }

        /// <summary>
        /// 팝업 데이터를 설정하고 표시한다.
        /// </summary>
        public void ShowUI(IPopupData popupData)
        {
            this.popupData = popupData;

            ShowUI();
        }

        /// <summary>
        /// 팝업을 닫는다.
        /// 사용자 입력 기반의 일반 닫기는 Transition 중이면 무시한다.
        /// </summary>
        public void ClosePopup(bool result = true)
        {
            if (!IsOpen)
                return;

            if (IsTransitioning)
                return;

            _pendingCloseResult = result;

            HideUI();
        }

        /// <summary>
        /// Transition 상태와 관계없이 팝업 닫힘 흐름을 즉시 완료한다.
        /// 화면 전환, 씬 이동, 전체 팝업 닫기처럼 시스템 강제 정리 상황에서 사용한다.
        /// </summary>
        public void ForceClosePopup(bool result = false)
        {
            if (!IsOpen && !IsTransitioning)
                return;

            _pendingCloseResult = result;
            isOpen = false;

            SetCanvasGroupInteractable(false);
            StopTransitionForImmediateAction();

            onHide?.Invoke(this);

            if(UIManager.HasInstance)UIManager.Instance.RefreshGlobalHudState();

            CompleteCloseWait();

            DestroyUI();
        }

        /// <summary>
        /// 닫기 흐름을 타지 않고 UI 객체를 즉시 파괴한다.
        /// DestroyAllImmediately 전용이다.
        /// onHide는 호출하지 않는다.
        /// </summary>
        public void DestroyPopupImmediately()
        {
            isOpen = false;

            SetCanvasGroupInteractable(false);
            StopTransitionForImmediateAction();

            CancelCloseWait();

            DestroyUI();
        }

        /// <summary>
        /// 진행 중인 Transition과 관련 이벤트 연결을 즉시 해제한다.
        /// </summary>
        private void StopTransitionForImmediateAction()
        {
            if (transition == null)
                return;

            Transition.ShowCompleted.RemoveListener(OnShowTransitionComplete);
            Transition.HideCompleted.RemoveListener(OnHideTransitionComplete);
            Transition.ForceStopTransition();
        }

        /// <summary>
        /// CloseWait을 닫힘 결과로 완료한다.
        /// </summary>
        private void CompleteCloseWait()
        {
            var source=m_resultSource;
            var result=_pendingCloseResult;
            _pendingCloseResult=null;
            _closeFinished=true;
            _closeResult=result;
            if (source?.Task.Status.IsCompleted() == false)
            {
                if (result.HasValue)
                    source.TrySetResult(result.Value);
                else
                    source.TrySetCanceled();
            }

        }

        /// <summary>
        /// CloseWait을 취소한다.
        /// 즉시 파괴처럼 닫힘 결과가 아닌 경우 사용한다.
        /// </summary>
        private void CancelCloseWait()
        {
            if (m_resultSource?.Task.Status.IsCompleted() == false)
                m_resultSource.TrySetCanceled();

            _pendingCloseResult = null;
            _closeFinished = true;
        }

        /// <summary>
        /// 팝업이 닫길 때까지 외부에서 await 가능하게 한다.
        /// 이미 닫힌 뒤에 호출하면 저장된 결과를 바로 돌려주고, 결과 없이 닫혔으면 취소된다.
        /// </summary>
        public UniTask<bool> CloseWait()
        {
            if(_closeFinished)return _closeResult.HasValue?UniTask.FromResult(_closeResult.Value):UniTask.FromCanceled<bool>();
            if(m_resultSource==null||m_resultSource.Task.Status.IsCompleted())m_resultSource = new UniTaskCompletionSource<bool>();
            return m_resultSource.Task;
        }
        protected override void OnDisable()
        {
            bool wasOpen=isOpen;
            isOpen=false;
            StopTransitionForImmediateAction();
            CancelCloseWait();
            if(wasOpen)onHide?.Invoke(this);
            base.OnDisable();
        }
        protected override void OnDestroy()
        {
            StopTransitionForImmediateAction();
            CancelCloseWait();
            base.OnDestroy();
        }

        /// <summary>
        /// 백버튼 요청을 처리한다.
        /// 기본은 닫기 허용이다.
        /// </summary>
        public virtual UniTask<bool> OnBackRequestAsync()
        {
            return UniTask.FromResult(true);
        }

        /// <summary>
        /// 닫기 버튼/백판 클릭을 처리한다.
        /// 사용자 입력으로 닫는 경우에는 Transition 중 닫히지 않게 한다.
        /// </summary>

        public void OnClickCloseBtn()
        {
            OnClickCloseBtnAsync().Forget();
        }

        private async UniTask OnClickCloseBtnAsync()
        {
            if (!IsOpen || IsTransitioning) return;

            UISoundPlayback.PlaySfx(closeSoundKey);

            if (await OnBackRequestAsync())
                ClosePopup();
        }
    }
}
