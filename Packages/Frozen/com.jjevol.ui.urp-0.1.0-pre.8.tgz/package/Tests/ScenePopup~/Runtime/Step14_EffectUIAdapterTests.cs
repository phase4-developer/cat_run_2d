//추가
using jjevol.Effect;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Cysharp.Threading.Tasks;
using jjevol.Audio;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.U2D;
using Object=UnityEngine.Object;

namespace jjevol.Step17.EffectUI.Tests
{
    [PrebuildSetup("jjevol.Step17.EffectUI.Tests.AdapterFixtureSetup")]
    public sealed class EffectUIAdapterTests
    {
        protected EffectManager Manager;
        protected AddressablesManager ResourcesManager;
        protected readonly List<GameObject> Objects=new();
        readonly List<AsyncOperationHandle> _assets=new();
        readonly List<Gate> _gates=new();
        readonly List<IResourceLocator> _locators=new();
        readonly List<Scene> _scenes=new();
        TMP_Settings _prior,_settings;TMP_FontAsset _font;Canvas _canvas;
        readonly List<PrefabCounter> _prefabProviders=new();
        PrefabCounter _prefabs;
        sealed class PrefabCounter:IEffectPrefabProvider
        {
            readonly AddressablesEffectPrefabProvider _real=new();
            public int Loads,Returns,Active;
            public async UniTask<EffectPrefabLease> LoadAsync(string key,CancellationToken token)
            {
                var lease=await _real.LoadAsync(key,token);if(lease==null)return null;Loads++;Active++;
                return new EffectPrefabLease(lease.Prefab,()=>{Returns++;Active--;lease.Dispose();});
            }
        }
        sealed class Gate:ResourceProviderBase
        {
            readonly Object _asset;readonly string _id="step14-gate-"+Guid.NewGuid().ToString("N");
            public override string ProviderId=>_id;
            public readonly List<ProvideHandle> Pending=new();public int Loads,Returns;public bool Open,Fail;
            public Gate(Object asset)=>_asset=asset;
            public override void Provide(ProvideHandle handle)
            {
                Loads++;
                if(Fail)handle.Complete<SpriteAtlas>(null,false,new InvalidOperationException("STEP14_expected_atlas_failure"));
                else if(Open)handle.Complete(_asset,true,null);else Pending.Add(handle);
            }
            public void Finish(){Open=true;var pending=Pending.ToArray();Pending.Clear();foreach(var h in pending)h.Complete(_asset,true,null);}
            public override void Release(IResourceLocation location,object asset)=>Returns++;
        }
        protected static T Get<T>(object target,string name)=>(T)target.GetType().GetField(name,BindingFlags.NonPublic|BindingFlags.Instance).GetValue(target);
        protected static void Set(object target,string name,object value)=>target.GetType().GetField(name,BindingFlags.NonPublic|BindingFlags.Instance).SetValue(target,value);
        protected static IEnumerator Done(Task task)
        {
            float end=Time.realtimeSinceStartup+12;while(!task.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;
            Assert.That(task.IsCompleted,Is.True,"SDK operation must finish");if(task.IsFaulted)throw task.Exception.GetBaseException();Assert.That(task.IsCanceled,Is.False);
        }
        protected static IEnumerator Until(Func<bool> predicate,float seconds=5)
        {float end=Time.realtimeSinceStartup+seconds;while(!predicate()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(predicate(),Is.True);}
        protected GameObject New(string name,params Type[] components){var go=new GameObject(name,components);Objects.Add(go);return go;}
        protected Task<EffectHandle> Play(string key="Step14/Toast",string icon="",bool loop=true,Transform parent=null,Action callback=null)
            =>Manager.PlayAsync(new EffectRequest(key,loop:loop,icon:icon,parent:parent?parent:_canvas.transform,callBack:callback)).AsTask();
        void NewManager()
        {
            Manager=New("actual effect manager").AddComponent<EffectManager>();_prefabs=new PrefabCounter();_prefabProviders.Add(_prefabs);Manager.SetPrefabProvider(_prefabs);
        }
        IEnumerator NativeGate(string key)
        {
            var source=Addressables.LoadAssetAsync<SpriteAtlas>("Step14/Atlas");_assets.Add(source);yield return Done(source.Task);
            var gate=new Gate(source.Result);_gates.Add(gate);Addressables.ResourceManager.ResourceProviders.Add(gate);
            var locator=new ResourceLocationMap("step14-locator-"+Guid.NewGuid().ToString("N"));locator.Add(key,new ResourceLocationBase(key,key,gate.ProviderId,typeof(SpriteAtlas)));
            Addressables.AddResourceLocator(locator);_locators.Add(locator);
        }
        IEnumerator NativeTextureGate(string key)
        {
            var source=Addressables.LoadAssetAsync<Texture2D>("Step14/TextureA");_assets.Add(source);yield return Done(source.Task);
            var gate=new Gate(source.Result);_gates.Add(gate);Addressables.ResourceManager.ResourceProviders.Add(gate);
            var locator=new ResourceLocationMap("step14-texture-"+Guid.NewGuid().ToString("N"));locator.Add(key,new ResourceLocationBase(key,key,gate.ProviderId,typeof(Texture2D)));
            Addressables.AddResourceLocator(locator);_locators.Add(locator);
        }
        [UnitySetUp]public IEnumerator Setup()
        {
            Time.timeScale=1;EffectManager.applicationIsQuitting=false;AddressablesManager.applicationIsQuitting=false;AudioManager.applicationIsQuitting=false;
            var init=Addressables.InitializeAsync(false);yield return Done(init.Task);Addressables.Release(init);
            ResourcesManager=AddressablesManager.Instance;
            NewManager();
            _canvas=New("actual Canvas",typeof(RectTransform),typeof(Canvas)).GetComponent<Canvas>();_canvas.renderMode=RenderMode.ScreenSpaceOverlay;
            var field=typeof(TMP_Settings).GetField("s_Instance",BindingFlags.NonPublic|BindingFlags.Static);_prior=(TMP_Settings)field.GetValue(null);
            _settings=ScriptableObject.CreateInstance<TMP_Settings>();_font=TMP_FontAsset.CreateFontAsset("Arial","Regular",32);Assert.That(_font,Is.Not.Null);
            Set(_settings,"m_defaultFontAsset",_font);field.SetValue(null,_settings);
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {
            Time.timeScale=1;foreach(var gate in _gates)gate.Finish();yield return null;
            foreach(var go in Objects)if(go)Object.Destroy(go);Objects.Clear();
            foreach(var scene in _scenes)if(scene.IsValid()&&scene.isLoaded)yield return SceneManager.UnloadSceneAsync(scene);_scenes.Clear();
            yield return null;yield return null;yield return null;
            foreach(var provider in _prefabProviders){yield return Until(()=>provider.Active==0);Assert.That(provider.Returns,Is.EqualTo(provider.Loads));}_prefabProviders.Clear();
            foreach(var gate in _gates)
            {
                if(gate.Fail)Assert.That(gate.Returns,Is.Zero,"Failed Provide delivered no asset; SDK only invokes Release for a successful result");
                else yield return Until(()=>gate.Returns==gate.Loads);
                Addressables.ResourceManager.ResourceProviders.Remove(gate);
            }
            foreach(var locator in _locators)Addressables.RemoveResourceLocator(locator);_locators.Clear();_gates.Clear();
            foreach(var asset in _assets)if(asset.IsValid())Addressables.Release(asset);_assets.Clear();
            Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.Zero);Assert.That(ResourcesManager.GetRefCount("Step14/TextureA"),Is.Zero);Assert.That(ResourcesManager.GetRefCount("Step14/TextureB"),Is.Zero);
            if(ResourcesManager)Object.Destroy(ResourcesManager.gameObject);yield return null;
            typeof(TMP_Settings).GetField("s_Instance",BindingFlags.NonPublic|BindingFlags.Static).SetValue(null,_prior);
            if(_font){if(_font.material)Object.Destroy(_font.material);foreach(var texture in _font.atlasTextures)if(texture)Object.Destroy(texture);Object.Destroy(_font);}Object.Destroy(_settings);yield return null;
        }
        [UnityTest]public IEnumerator ForeignSpriteCannotSatisfyPendingIconRequest()
        {
            yield return NativeGate("Step14/DelayedAtlas");
            var external=Addressables.LoadAssetAsync<Sprite>("Step14/DirectSprite");_assets.Add(external);yield return Done(external.Task);
            var play=Play("Step14/DelayedIcon","icon_red");yield return Done(play);
            var behaviour=play.Result.GetComponentInChildren<EffectIconBehaviour>();var image=Get<AddressableImage>(behaviour,"_iconImage");
            image.sprite=external.Result;yield return null;yield return null;
            Assert.That(behaviour.IsFinished,Is.False,"A nonnull foreign/old Sprite is not this request's load success");
            _gates[0].Finish();yield return Until(()=>behaviour.IsFinished);Assert.That(image.sprite.name.Replace("(Clone)",""),Is.EqualTo("icon_red"));
        }
        [UnityTest]public IEnumerator MissingSpriteFinishesItsAttemptWithoutUsingAnOldImage()
        {
            var play=Play("Step14/Icon","not_in_fixture_atlas");yield return Done(play);
            var behaviour=play.Result.GetComponentInChildren<EffectIconBehaviour>();
            yield return new WaitForSecondsRealtime(.5f);
            Assert.That(behaviour.IsFinished,Is.True,"Missing Sprite must terminate, not wait until object destruction");
            Assert.That(Get<AddressableImage>(behaviour,"_iconImage").sprite,Is.Null);
        }
        [UnityTest]public IEnumerator EmptyToastIconReplacesPreviousDataAndStopReturnsTextureLease()
        {
            var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;
            toast.SetData("icon_red","first");toast.SetCharacterData("Step14/TextureA","skill one");
            var image=Get<AddressableImage>(toast,"iconSprite");var texture=Get<AddressableTexture>(toast,"characterTexture");
            yield return Until(()=>image.sprite&&texture.sprite);toast.SetData("","second");
            Assert.That(image.sprite,Is.Null,"Empty icon must not retain the previous request's Sprite");
            Assert.That(Get<TMP_Text>(toast,"messageText").text,Is.EqualTo("second"));
            toast.StopAndClear();yield return null;yield return null;
            Assert.That(ResourcesManager.GetRefCount("Step14/TextureA"),Is.Zero);
        }
        [UnityTest]public IEnumerator PausedToastDoesNotCompleteFromTheFiveSecondTimeout()
        {
            var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;int completed=0;
            toast.Play(0,false,()=>completed++);toast.SetPaused(true);yield return new WaitForSecondsRealtime(5.3f);
            Assert.That(completed,Is.Zero,"Pause must suspend the completion timeout as well as Animator time");
            toast.SetPaused(false);yield return Until(()=>completed==1);yield return null;Assert.That(completed,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator ToastUpdatesTextIconsTexturesAndRealTmpGeometry()
        {
            var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;
            var icon=Get<AddressableImage>(toast,"iconSprite");var character=Get<AddressableTexture>(toast,"characterTexture");
            var message=Get<TMP_Text>(toast,"messageText");var skill=Get<TMP_Text>(toast,"skillNameText");
            toast.SetData("icon_red","first message");toast.SetCharacterData("Step14/TextureA","first skill");yield return Until(()=>icon.sprite&&character.sprite);
            var oldIcon=icon.sprite;var oldCharacter=character.sprite;
            toast.SetData("icon_blue","second message");toast.SetCharacterData("Step14/TextureB","second skill");
            yield return Until(()=>icon.sprite&&icon.sprite.name.StartsWith("icon_blue")&&character.spriteKey=="Step14/TextureB"&&character.sprite);
            yield return null;yield return null;Assert.That(oldIcon==null&&oldCharacter==null,Is.True,"UI-owned native Sprite clones must be destroyed");
            Assert.That(message.text,Is.EqualTo("second message"));Assert.That(skill.text,Is.EqualTo("second skill"));
            Canvas.ForceUpdateCanvases();message.ForceMeshUpdate();Assert.That(message.textInfo.meshInfo.Sum(m=>m.vertexCount),Is.GreaterThan(0));
            Assert.That(Get<Animator>(toast,"_animator").GetCurrentAnimatorStateInfo(0).IsName("Play"),Is.True);
            Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.EqualTo(1));Assert.That(ResourcesManager.GetRefCount("Step14/TextureA"),Is.Zero);
        }
        [UnityTest]public IEnumerator NaturalCompletionReturnsPoolAndNextMessageUsesTheSameInstance()
        {
            int returned=0;var first=Play(loop:false,callback:()=>returned++);yield return Done(first);
            var toast=(ToastMessageEffectRenderer)first.Result.Renderer;toast.SetData("icon_red","one");
            yield return Until(()=>!first.Result.gameObject.activeSelf);Assert.That(returned,Is.EqualTo(1));Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.Zero);
            var second=Play(loop:false,callback:()=>returned++);yield return Done(second);Assert.That(second.Result,Is.SameAs(first.Result));Assert.That(second.Result.Renderer,Is.SameAs(toast));
            toast.SetData("icon_blue","two");yield return Until(()=>!second.Result.gameObject.activeSelf);yield return null;
            Assert.That(returned,Is.EqualTo(2));Assert.That(Get<TMP_Text>(toast,"messageText").text,Is.EqualTo("two"));
        }
        [UnityTest]public IEnumerator StoppedWaiterCannotCompleteTheReusedToastPlayback()
        {
            var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;int old=0,current=0;
            toast.Play(0,false,()=>old++);yield return new WaitForSecondsRealtime(.12f);toast.StopAndClear();
            toast.Play(0,false,()=>current++);yield return Until(()=>current==1);yield return new WaitForSecondsRealtime(.2f);
            Assert.That(old,Is.Zero);Assert.That(current,Is.EqualTo(1));toast.StopAndClear();Assert.That(Get<Animator>(toast,"_animator").speed,Is.Zero);
        }
        [UnityTest]public IEnumerator CompletionCanStartAnotherPlaybackWithoutLosingItsWaiter()
        {
            var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;int count=0;
            toast.Play(0,false,()=>{count++;toast.Play(0,false,()=>count++);});yield return Until(()=>count==2);yield return new WaitForSecondsRealtime(.2f);
            Assert.That(count,Is.EqualTo(2));
        }
        [UnityTest]public IEnumerator UnscaledPlaybackCompletesAtTimeScaleZeroAndLoopDoesNotAutoComplete()
        {
            var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;int count=0;
            toast.SetUnscaledTime(true);Time.timeScale=0;toast.Play(0,false,()=>count++);yield return Until(()=>count==1);
            toast.Play(0,true,()=>count++);yield return new WaitForSecondsRealtime(1f);Assert.That(count,Is.EqualTo(1));toast.StopAndClear();
        }
        [UnityTest]public IEnumerator LateCharacterLoadCannotOverwriteReplacementOrSurviveDespawn()
        {
            yield return NativeTextureGate("Step14/DelayedTexture");var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;
            var character=Get<AddressableTexture>(toast,"characterTexture");toast.SetCharacterData("Step14/DelayedTexture","old");yield return Until(()=>_gates[0].Pending.Count>0);
            toast.SetCharacterData("Step14/TextureB","new");yield return Until(()=>character.sprite&&character.spriteKey=="Step14/TextureB");var current=character.sprite;
            _gates[0].Finish();yield return Until(()=>_gates[0].Returns==_gates[0].Loads);
            Assert.That(character.sprite,Is.SameAs(current));Assert.That(Get<TMP_Text>(toast,"skillNameText").text,Is.EqualTo("new"));
            Manager.Despawn(play.Result);yield return null;yield return null;Assert.That(character.sprite,Is.Null);Assert.That(ResourcesManager.GetRefCount("Step14/TextureB"),Is.Zero);
        }
        [UnityTest]public IEnumerator LoadedIconRemainsVisibleAfterBehaviourRecycleThenReturnsOnDespawn()
        {
            var play=Play("Step14/Icon","icon_red");yield return Done(play);var behaviour=play.Result.GetComponentInChildren<EffectIconBehaviour>();
            yield return Until(()=>behaviour.IsFinished&&behaviour.LoadSucceeded);var image=Get<AddressableImage>(behaviour,"_iconImage");var sprite=image.sprite;
            yield return null;yield return null;Assert.That(behaviour.enabled,Is.False,"Core recycles completed loading behaviours");Assert.That(image.sprite,Is.SameAs(sprite));
            behaviour.End();Assert.That(image.sprite,Is.SameAs(sprite),"Automatic End is not Effect shutdown");
            Manager.Despawn(play.Result);yield return null;yield return null;Assert.That(image.sprite,Is.Null);Assert.That(sprite==null,Is.True);Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.Zero);
        }
        [UnityTest]public IEnumerator DelayedIconReuseCannotFinishOrPaintThePreviousRequest()
        {
            yield return NativeGate("Step14/DelayedAtlas");var first=Play("Step14/DelayedIcon","icon_red");yield return Done(first);
            yield return Until(()=>_gates[0].Pending.Count>0);Manager.Despawn(first.Result);
            var second=Play("Step14/DelayedIcon","icon_blue");yield return Done(second);Assert.That(second.Result,Is.SameAs(first.Result));
            var behaviour=second.Result.GetComponentInChildren<EffectIconBehaviour>();yield return null;Assert.That(behaviour.IsFinished,Is.False);
            _gates[0].Finish();yield return Until(()=>behaviour.IsFinished&&behaviour.LoadSucceeded);
            Assert.That(Get<AddressableImage>(behaviour,"_iconImage").sprite.name.Replace("(Clone)",""),Is.EqualTo("icon_blue"));
        }
        IEnumerator RetirePending(bool stop)
        {
            yield return NativeGate("Step14/DelayedAtlas");var play=Play("Step14/DelayedIcon","icon_red");yield return Done(play);
            var behaviour=play.Result.GetComponentInChildren<EffectIconBehaviour>();yield return Until(()=>_gates[0].Pending.Count>0);
            if(stop)play.Result.Stop();else behaviour.End();yield return null;_gates[0].Finish();
            yield return Until(()=>_gates[0].Returns==_gates[0].Loads);Assert.That(behaviour.IsFinished,Is.True);Assert.That(behaviour.LoadSucceeded,Is.False);
            Assert.That(Get<AddressableImage>(behaviour,"_iconImage").sprite,Is.Null);Manager.Despawn(play.Result);
        }
        [UnityTest]public IEnumerator StopDuringPendingIconLoadRetiresItsRequest()=>RetirePending(true);
        [UnityTest]public IEnumerator EndDuringPendingIconLoadRetiresItsRequest()=>RetirePending(false);
        [UnityTest]public IEnumerator SceneUnloadCancelsPendingIconTextureAndCompletion()
        {
            yield return NativeGate("Step14/DelayedAtlas");yield return NativeTextureGate("Step14/DelayedTexture");
            var scene=SceneManager.CreateScene("step14_scene_"+Guid.NewGuid().ToString("N"));_scenes.Add(scene);
            var parent=New("scene UI root",typeof(RectTransform),typeof(Canvas));SceneManager.MoveGameObjectToScene(parent,scene);
            var icon=Play("Step14/DelayedIcon","icon_red",parent:parent.transform);yield return Done(icon);
            var toastPlay=Play(parent:parent.transform);yield return Done(toastPlay);var toast=(ToastMessageEffectRenderer)toastPlay.Result.Renderer;int completed=0;
            toast.SetCharacterData("Step14/DelayedTexture","pending");toast.Play(0,false,()=>completed++);
            yield return Until(()=>_gates.All(g=>g.Pending.Count>0));yield return SceneManager.UnloadSceneAsync(scene);foreach(var gate in _gates)gate.Finish();
            yield return null;yield return null;yield return Until(()=>_prefabs.Active==0);
            Assert.That(icon.Result==null&&toastPlay.Result==null,Is.True);Assert.That(completed,Is.Zero);
        }
        [UnityTest]public IEnumerator ManagerDisableReuseAndDestroyReinitializeKeepIndependentOwners()
        {
            yield return NativeTextureGate("Step14/DelayedTexture");var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;
            toast.SetCharacterData("Step14/DelayedTexture","old");yield return Until(()=>_gates[0].Pending.Count>0);Manager.gameObject.SetActive(false);yield return null;
            Manager.gameObject.SetActive(true);var reused=Play();yield return Done(reused);Assert.That(reused.Result,Is.SameAs(play.Result));toast.SetCharacterData("Step14/TextureB","new");
            yield return Until(()=>Get<AddressableTexture>(toast,"characterTexture").sprite);_gates[0].Finish();yield return Until(()=>_gates[0].Returns==_gates[0].Loads);
            Assert.That(Get<AddressableTexture>(toast,"characterTexture").spriteKey,Is.EqualTo("Step14/TextureB"));
            var general=AddressableScope.GetPrefab("Step14/Toast").AsTask();yield return Done(general);
            try
            {
                Object.Destroy(Manager.gameObject);yield return null;yield return null;yield return Until(()=>_prefabs.Active==0);
                Assert.That(general.Result.Asset,Is.Not.Null);Assert.That(ResourcesManager.GetRefCount("Step14/Toast"),Is.EqualTo(1));
                NewManager();var fresh=Play();yield return Done(fresh);Assert.That(fresh.Result,Is.Not.Null);
            }
            finally{general.Result.Dispose();}
        }
        [UnityTest]public IEnumerator IdleCullReturnsTheRealPrefabLeaseAfterImageLeaseReturn()
        {
            Manager.SetPoolProfile("Step14/Icon",0,4,.1f);var play=Play("Step14/Icon","icon_red");yield return Done(play);
            var behaviour=play.Result.GetComponentInChildren<EffectIconBehaviour>();yield return Until(()=>behaviour.LoadSucceeded);Manager.Despawn(play.Result);
            yield return null;yield return null;Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.Zero);
            yield return Until(()=>_prefabs.Active==0);Assert.That(play.Result==null,Is.True);Assert.That(_prefabs.Returns,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator SuppliedSpriteIsNotDestroyedWhenToastReturnsItsLease()
        {
            var external=Addressables.LoadAssetAsync<Sprite>("Step14/DirectSprite");_assets.Add(external);yield return Done(external.Task);
            var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;toast.SetCharacterData("Step14/DirectSprite","native sprite");
            var image=Get<AddressableTexture>(toast,"characterTexture");yield return Until(()=>image.sprite);Assert.That(image.sprite,Is.SameAs(external.Result));
            toast.StopAndClear();yield return null;Assert.That(external.Result,Is.Not.Null);Assert.That(ResourcesManager.GetRefCount("Step14/DirectSprite"),Is.Zero);
        }
        [UnityTest]public IEnumerator TwentyPooledRunsDoNotRetainOldImagesOrDoubleReturn()
        {
            EffectHandle previous=null;int callbacks=0;
            for(int i=0;i<20;i++)
            {
                var play=Play(callback:()=>callbacks++);yield return Done(play);if(previous)Assert.That(play.Result,Is.SameAs(previous));previous=play.Result;
                var toast=(ToastMessageEffectRenderer)play.Result.Renderer;toast.SetData(i%2==0?"icon_red":"icon_blue","message "+i);toast.SetCharacterData(i%2==0?"Step14/TextureA":"Step14/TextureB","skill "+i);
                yield return Until(()=>Get<AddressableImage>(toast,"iconSprite").sprite&&Get<AddressableTexture>(toast,"characterTexture").sprite);
                Manager.Despawn(play.Result);Manager.Despawn(play.Result);yield return null;yield return null;
                Assert.That(callbacks,Is.EqualTo(i+1));Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.Zero);Assert.That(ResourcesManager.GetRefCount("Step14/TextureA"),Is.Zero);Assert.That(ResourcesManager.GetRefCount("Step14/TextureB"),Is.Zero);
            }
            Assert.That(_prefabs.Loads,Is.EqualTo(1));Assert.That(_prefabs.Active,Is.EqualTo(1),"Idle cache retains only the Prefab lease until Manager destruction");
        }
        [UnityTest]public IEnumerator AudioUiEffectAndGeneralResourceLeasesCoexist()
        {
            var general=AddressableScope.Get<AudioClip>("Step14/Audio").AsTask();yield return Done(general);using var clips=new AddressablesClipProvider();
            var audio=New("actual audio manager").AddComponent<AudioManager>();audio.SetProvider(clips);if(!Object.FindAnyObjectByType<AudioListener>())New("listener",typeof(AudioListener));
            try
            {
                var sound=audio.PlayAsync("Step14/Audio",loop:true,debounce:0);yield return Done(sound);Assert.That(sound.Result.isPlaying,Is.True);
                var effect=Play();yield return Done(effect);var toast=(ToastMessageEffectRenderer)effect.Result.Renderer;toast.SetData("icon_red","coexist");
                yield return Until(()=>Get<AddressableImage>(toast,"iconSprite").sprite);
                Assert.That(ResourcesManager.TryGetLoadedAsset<AudioClip>("Step14/Audio",out var peek),Is.True);Assert.That(ResourcesManager.GetRefCount("Step14/Audio"),Is.EqualTo(1));
                Assert.That(ResourcesManager.GetAsset<AudioClip>("Step14/Audio"),Is.SameAs(peek));Assert.That(ResourcesManager.GetRefCount("Step14/Audio"),Is.EqualTo(2));AddressablesManager.ReleaseAsset("Step14/Audio");
                audio.StopAll();Assert.That(clips.ActiveLeaseCount,Is.Zero);Assert.That(general.Result.Asset,Is.Not.Null);Manager.Despawn(effect.Result);
            }
            finally{general.Result.Dispose();audio.StopAll();}
            Assert.That(ResourcesManager.GetRefCount("Step14/Audio"),Is.Zero);
        }
        [UnityTest]public IEnumerator SdkAtlasFailureTerminatesWithoutAFalseSuccess()
        {
            yield return NativeGate("Step14/DelayedAtlas");_gates[0].Fail=true;
            LogAssert.Expect(LogType.Error,new Regex("STEP14_expected_atlas_failure"));
            var play=Play("Step14/DelayedIcon","icon_red");yield return Done(play);var behaviour=play.Result.GetComponentInChildren<EffectIconBehaviour>();
            yield return Until(()=>behaviour.IsFinished);Assert.That(behaviour.LoadSucceeded,Is.False);Assert.That(Get<AddressableImage>(behaviour,"_iconImage").sprite,Is.Null);
            Assert.That(ResourcesManager.GetRefCount("Step14/DelayedAtlas"),Is.Zero);Assert.That(AddressablesManager.IsLoaded("Step14/DelayedAtlas"),Is.False);
        }
        [UnityTest]public IEnumerator DefaultImageAutoLoadOnEnableCannotRestoreAnOldPooledIcon()
        {
            var first=Play("Step14/Icon","icon_red");yield return Done(first);var behaviour=first.Result.GetComponentInChildren<EffectIconBehaviour>();
            yield return Until(()=>behaviour.LoadSucceeded);var image=Get<AddressableImage>(behaviour,"_iconImage");Set(image,"m_LoadOnEnable",true);
            Manager.Despawn(first.Result);yield return null;yield return null;Assert.That(image.sprite,Is.Null);Assert.That(image.atlasKey,Is.EqualTo("Step14/Atlas"));
            var next=Play("Step14/Icon","icon_blue");yield return Done(next);Assert.That(next.Result,Is.SameAs(first.Result));
            yield return Until(()=>behaviour.LoadSucceeded);Assert.That(image.sprite.name.Replace("(Clone)",""),Is.EqualTo("icon_blue"));Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator LateToastAtlasCannotReplaceTheNewMessageOrSprite()
        {
            yield return NativeGate("Step14/DelayedAtlas");var play=Play();yield return Done(play);var toast=(ToastMessageEffectRenderer)play.Result.Renderer;
            var image=Get<AddressableImage>(toast,"iconSprite");Set(image,"m_AtlasKey","Step14/DelayedAtlas");
            toast.SetData("icon_red","old message");yield return Until(()=>_gates[0].Pending.Count>0);
            toast.SetData("icon_blue","current message");Assert.That(Get<TMP_Text>(toast,"messageText").text,Is.EqualTo("current message"));
            _gates[0].Finish();yield return Until(()=>image.sprite&&image.sprite.name.StartsWith("icon_blue"));yield return null;
            Assert.That(Get<TMP_Text>(toast,"messageText").text,Is.EqualTo("current message"));Assert.That(image.sprite.name.Replace("(Clone)",""),Is.EqualTo("icon_blue"));
        }
        [UnityTest]public IEnumerator ToastStopWhileImagesArePendingPreventsLatePaintAndCompletion()
        {
            yield return NativeGate("Step14/DelayedAtlas");yield return NativeTextureGate("Step14/DelayedTexture");var play=Play();yield return Done(play);
            var toast=(ToastMessageEffectRenderer)play.Result.Renderer;var icon=Get<AddressableImage>(toast,"iconSprite");var character=Get<AddressableTexture>(toast,"characterTexture");Set(icon,"m_AtlasKey","Step14/DelayedAtlas");
            int completed=0;toast.SetData("icon_red","pending");toast.SetCharacterData("Step14/DelayedTexture","pending skill");toast.Play(0,false,()=>completed++);
            yield return Until(()=>_gates.All(g=>g.Pending.Count>0));toast.StopAndClear();foreach(var gate in _gates)gate.Finish();
            yield return Until(()=>_gates.All(g=>g.Returns==g.Loads));yield return new WaitForSecondsRealtime(.9f);
            Assert.That(icon.sprite,Is.Null);Assert.That(character.sprite,Is.Null);Assert.That(completed,Is.Zero);
        }
        [UnityTest]public IEnumerator EmptyIconOnAReusedHandleClearsThePreviousSuccessfulRequest()
        {
            var first=Play("Step14/Icon","icon_red");yield return Done(first);var behaviour=first.Result.GetComponentInChildren<EffectIconBehaviour>();
            yield return Until(()=>behaviour.LoadSucceeded);Manager.Despawn(first.Result);yield return null;
            var second=Play("Step14/Icon","");yield return Done(second);Assert.That(second.Result,Is.SameAs(first.Result));
            Assert.That(behaviour.IsFinished,Is.True);Assert.That(behaviour.LoadSucceeded,Is.False);Assert.That(Get<AddressableImage>(behaviour,"_iconImage").sprite,Is.Null);Assert.That(ResourcesManager.GetRefCount("Step14/Atlas"),Is.Zero);
        }
    }
}

//추가 종료
