using jjevol.Effect;
//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;
namespace jjevol.Step17.Effect.DOTweenPro.Tests
{
    [PrebuildSetup("jjevol.Step17.Fixtures.Effect.EffectFixtureSetup")]
    public sealed class EffectSdkTests
    {
        readonly List<GameObject> _objects=new();EffectManager _manager;Leases _leases;
        sealed class Leases:IEffectPrefabProvider
        {
            readonly AddressablesEffectPrefabProvider _sdk=new();public int Loads,Returns;
            public async UniTask<EffectPrefabLease> LoadAsync(string key,CancellationToken token){var lease=await _sdk.LoadAsync(key,token);if(lease==null)return null;Loads++;return new EffectPrefabLease(lease.Prefab,()=>{Returns++;lease.Dispose();});}
        }
        static IEnumerator Done(Task t){float end=Time.realtimeSinceStartup+10;while(!t.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;Assert.That(t.IsCompleted,Is.True);if(t.IsFaulted)throw t.Exception.GetBaseException();Assert.That(t.IsCanceled,Is.False);}
        static IEnumerator Until(Func<bool> p){float end=Time.realtimeSinceStartup+8;while(!p()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(p(),Is.True);}
        [UnitySetUp]public IEnumerator Setup(){Time.timeScale=1;EffectManager.applicationIsQuitting=false;DOTween.Init(false,true,LogBehaviour.ErrorsOnly);var init=Addressables.InitializeAsync(false);yield return Done(init.Task);Addressables.Release(init);var go=new GameObject("manager");_objects.Add(go);_manager=go.AddComponent<EffectManager>();_leases=new Leases();_manager.SetPrefabProvider(_leases);}
        [UnityTearDown]public IEnumerator Cleanup(){Time.timeScale=1;foreach(var o in _objects)if(o)Object.Destroy(o);_objects.Clear();yield return null;yield return null;yield return Until(()=>_leases.Returns==_leases.Loads);int active=DOTween.TotalActiveTweens();DOTween.KillAll(false);Assert.That(active,Is.Zero);}
        [UnityTest]public IEnumerator ActualPrefabParticlePauseResumeAndIdleLeaseReturn()
        {
            _manager.SetPoolProfile("Step16/Effect",0,4,.08f);int done=0;var play=_manager.PlayAsync(new EffectRequest("Step16/Effect",callBack:()=>done++)).AsTask();yield return Done(play);Assert.That(play.Result.Renderer,Is.TypeOf<DOTweenEffectRenderer>());var particle=play.Result.GetComponentInChildren<ParticleSystem>();Assert.That(particle.isPlaying,Is.True);play.Result.Pause();yield return new WaitForSecondsRealtime(.3f);Assert.That(done,Is.Zero);play.Result.Resume();yield return Until(()=>done==1);yield return Until(()=>_leases.Returns==1);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        [UnityTest]public IEnumerator AutomaticOriginalRootFallbackUsesTheOptionalFactoryOnce()
        {
            DOTweenEffectAdapter.Register();DOTweenEffectAdapter.Register();var play=_manager.PlayAsync(new EffectRequest("Step16/AutoEffect",loop:true)).AsTask();yield return Done(play);Assert.That(play.Result.Renderer,Is.TypeOf<DOTweenEffectRenderer>());Assert.That(play.Result.GetComponentsInChildren<DOTweenEffectRenderer>().Length,Is.EqualTo(1));_manager.Despawn(play.Result);
        }
        [UnityTest]public IEnumerator ReusingOneHandleTwentyTimesHasNoOldCompletionOrLiveTween()
        {
            EffectHandle previous=null;int count=0;
            for(int i=0;i<20;i++){var play=_manager.PlayAsync(new EffectRequest("Step16/Effect",loop:true,callBack:()=>count++)).AsTask();yield return Done(play);if(previous)Assert.That(play.Result,Is.SameAs(previous));previous=play.Result;yield return null;_manager.Despawn(play.Result);_manager.Despawn(play.Result);Assert.That(count,Is.EqualTo(i+1));Assert.That(DOTween.TotalActiveTweens(),Is.Zero);}
            Assert.That(_leases.Loads,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator SceneUnloadRetiresPrefabLeaseAndAllNativeTweens()
        {
            var scene=SceneManager.CreateScene("Step16 Pro Effect scene");var parent=new GameObject("scene parent");_objects.Add(parent);SceneManager.MoveGameObjectToScene(parent,scene);var play=_manager.PlayAsync(new EffectRequest("Step16/Effect",loop:true,parent:parent.transform)).AsTask();yield return Done(play);yield return SceneManager.UnloadSceneAsync(scene);yield return Until(()=>_leases.Returns==1);Assert.That(play.Result==null,Is.True);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        [UnityTest]public IEnumerator DestroyManagerDuringPlaybackReturnsNativePrefabAndStopsTween()
        {
            var play=_manager.PlayAsync(new EffectRequest("Step16/Effect",loop:true)).AsTask();yield return Done(play);Object.Destroy(_manager.gameObject);yield return null;yield return null;yield return Until(()=>_leases.Returns==1);Assert.That(play.Result==null,Is.True);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
    }
}
//추가 종료
