//추가
using System;
using System.IO;
using DG.Tweening;
using jjevol.Effect.Renderers;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;
namespace jjevol.Step17.Fixtures.Effect
{
    public sealed class EffectFixtureSetup:IPrebuildSetup
    {
        const string Root="Assets/Step16DOTweenFixtures";
        public void Setup()
        {
            string p=Path.GetFullPath(Path.Combine(Application.dataPath,"..")).Replace('\\','/');if(!p.EndsWith("/.local/scene-popup-validation/IntegrationHost")&&!p.EndsWith("/.local/scene-popup-validation/IntegrationHost"))throw new InvalidOperationException("Only new STEP16 Effect/Integration Host may be authored");
            if(!AssetDatabase.IsValidFolder(Root))AssetDatabase.CreateFolder("Assets",Path.GetFileName(Root));
            var settings=AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(Root+"/Settings.asset")??AddressableAssetSettings.Create(Root,"Settings",true,true);AddressableAssetSettingsDefaultObject.Settings=settings;for(int i=0;i<settings.DataBuilders.Count;i++)if(settings.DataBuilders[i] is BuildScriptFastMode)settings.ActivePlayModeDataBuilderIndex=i;
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));if(File.Exists(Root+"/Effect.prefab"))return;
            void Register(string path,string key)=>settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path),settings.DefaultGroup).address=key;
            foreach(bool explicitRenderer in new[]{true,false})
            {
                var root=new GameObject("independent Pro Effect");root.SetActive(false);var target=new GameObject("target");target.transform.SetParent(root.transform,false);
                var a=root.AddComponent<DOTweenAnimation>();a.autoGenerate=false;a.autoPlay=false;a.autoKill=false;a.isValid=true;a.target=target.transform;a.targetType=DOTweenAnimation.TargetType.Transform;a.animationType=DOTweenAnimation.AnimationType.LocalMove;a.duration=.2f;a.endValueV3=new Vector3(2,0,0);a.easeType=Ease.Linear;
                var particle=new GameObject("actual particles",typeof(ParticleSystem));particle.transform.SetParent(root.transform,false);var ps=particle.GetComponent<ParticleSystem>();var main=ps.main;main.playOnAwake=false;main.duration=.12f;main.startLifetime=.06f;main.loop=false;
                if(explicitRenderer)root.AddComponent<DOTweenEffectRenderer>();root.SetActive(true);string path=Root+"/"+(explicitRenderer?"Effect":"AutoEffect")+".prefab";PrefabUtility.SaveAsPrefabAsset(root,path);Object.DestroyImmediate(root);Register(path,explicitRenderer?"Step16/Effect":"Step16/AutoEffect");
            }
            string wave=Root+"/Audio.wav";using(var writer=new BinaryWriter(File.Create(wave))){int count=4410;writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));writer.Write(36+count*2);writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));writer.Write(16);writer.Write((short)1);writer.Write((short)1);writer.Write(44100);writer.Write(88200);writer.Write((short)2);writer.Write((short)16);writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));writer.Write(count*2);for(int i=0;i<count;i++)writer.Write((short)(Math.Sin(i*2*Math.PI*220/44100)*2000));}AssetDatabase.ImportAsset(wave);Register(wave,"Step16/Audio");EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();AssetDatabase.Refresh();
        }
    }
}
//추가 종료
