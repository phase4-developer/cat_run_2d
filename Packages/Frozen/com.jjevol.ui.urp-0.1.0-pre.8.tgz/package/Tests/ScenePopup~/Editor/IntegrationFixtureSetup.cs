//추가
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.TestTools;
namespace jjevol.DOTweenIntegration.Tests
{
    public sealed class IntegrationFixtureSetup:IPrebuildSetup
    {
        public void Setup()
        {
            if(!Path.GetFullPath(Application.dataPath).Replace('\\','/').EndsWith("/.local/scene-popup-validation/IntegrationHost/Assets"))throw new InvalidOperationException("Only new STEP16 IntegrationHost");
            new jjevol.Step17.Fixtures.UI.TransitionFixtureSetup().Setup();new jjevol.Step17.Fixtures.Effect.EffectFixtureSetup().Setup();
            const string root="Assets/Step16DOTweenFixtures";var pipeline=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(root+"/Pipeline.asset");
            if(!pipeline){var renderer=ScriptableObject.CreateInstance<UniversalRendererData>();AssetDatabase.CreateAsset(renderer,root+"/Renderer.asset");pipeline=UniversalRenderPipelineAsset.Create(renderer);pipeline.msaaSampleCount=1;pipeline.supportsHDR=false;AssetDatabase.CreateAsset(pipeline,root+"/Pipeline.asset");}
            GraphicsSettings.defaultRenderPipeline=pipeline;QualitySettings.renderPipeline=pipeline;AssetDatabase.SaveAssets();
        }
    }
}
//추가 종료
