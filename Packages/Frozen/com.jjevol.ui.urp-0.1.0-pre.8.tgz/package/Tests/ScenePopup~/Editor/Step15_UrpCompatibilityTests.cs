//추가
using System;
using System.Reflection;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering.Universal;

namespace jjevol.Step17.URP.Tests
{
    public sealed class UrpCompatibilityTests
    {
        [Test]public void OriginalScriptGuidAndPublicContractArePreserved()
        {
            const string guid="1dc16205668f7f741a7bd97f16a022fb";string path=AssetDatabase.GUIDToAssetPath(guid);StringAssert.EndsWith("com.jjevol.ui.urp/Runtime/UIManagerCreater.cs",path);
            var script=AssetDatabase.LoadAssetAtPath<MonoScript>(path);Assert.That(script.GetClass(),Is.EqualTo(typeof(UIManagerCreater)));Assert.That(typeof(UIManagerCreater).BaseType,Is.EqualTo(typeof(Singleton<UIManagerCreater>)));
            foreach(var name in new[]{"mainCamera","cashScreenTypes","cashHudTypes","createId"})Assert.That(typeof(UIManagerCreater).GetField(name,BindingFlags.Instance|BindingFlags.Public),Is.Not.Null,name);
            Assert.That(typeof(UIManagerCreater).GetMethod("StartInitAsync",Type.EmptyTypes).ReturnType.FullName,Is.EqualTo("Cysharp.Threading.Tasks.UniTask"));
        }
        [Test]public void OriginalSerializedFieldNamesRemainAvailable()
        {
            var go=new GameObject("serialization contract");try{var creator=go.AddComponent<UIManagerCreater>();var so=new SerializedObject(creator);foreach(var name in new[]{"mainCamera","cashScreenTypes","cashHudTypes","createId"})Assert.That(so.FindProperty(name),Is.Not.Null,name);Assert.That(so.FindProperty("uiManagerAddress").stringValue,Is.EqualTo("UIManager"));}finally{UnityEngine.Object.DestroyImmediate(go);}
        }
        [Test]public void InstalledUrpAndAssemblyIdentityMatchValidatedCombination()
        {
            var info=UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(UniversalAdditionalCameraData).Assembly);Assert.That(info.version,Is.EqualTo("17.3.0"));Assert.That(Application.unityVersion,Is.EqualTo("6000.3.9f1"));Assert.That(typeof(UIManagerCreater).Assembly.GetName().Name,Is.EqualTo("JJEvol.UI.URP.Runtime"));
        }
        [Test]public void NativePrefabReloadRetainsScriptReferenceAndFourOriginalFields()
        {
            if(!Path.GetFullPath(Application.dataPath).Replace('\\','/').EndsWith("/.local/scene-popup-validation/IntegrationHost/Assets"))throw new InvalidOperationException("Only the STEP15 isolated Host may author the fixture");
            const string path="Assets/Step15BootstrapSerialization.prefab";var go=new GameObject("serialization fixture");
            try
            {
                var camera=new GameObject("camera",typeof(Camera));camera.transform.SetParent(go.transform);var c=go.AddComponent<UIManagerCreater>();c.mainCamera=camera.GetComponent<Camera>();c.cashScreenTypes=new List<string>{"IntroScreen"};c.cashHudTypes=new List<string>{"MainMenuHud"};c.createId=157;
                PrefabUtility.SaveAsPrefabAsset(go,path);UnityEngine.Object.DestroyImmediate(go);AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceUpdate);var restored=AssetDatabase.LoadAssetAtPath<GameObject>(path).GetComponent<UIManagerCreater>();
                Assert.That(restored.mainCamera.name,Is.EqualTo("camera"));Assert.That(restored.cashScreenTypes,Is.EqualTo(new[]{"IntroScreen"}));Assert.That(restored.cashHudTypes,Is.EqualTo(new[]{"MainMenuHud"}));Assert.That(restored.createId,Is.EqualTo(157));
                Assert.That(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(MonoScript.FromMonoBehaviour(restored))),Is.EqualTo("1dc16205668f7f741a7bd97f16a022fb"));
            }
            finally{if(go)UnityEngine.Object.DestroyImmediate(go);AssetDatabase.DeleteAsset(path);}
        }
        [Test]public void InstalledJjevolPackagesHaveNoActiveGuidOrAssemblyDuplicates()
        {
            var guids=new Dictionary<string,string>();var assemblies=new Dictionary<string,string>();
            foreach(var package in UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages().Where(p=>p.name.StartsWith("com.jjevol.")||p.name=="com.artress.managed-addressables"))
                foreach(string path in Directory.EnumerateFiles(package.resolvedPath,"*",SearchOption.AllDirectories))
                {
                    if(path.Replace('\\','/').Split('/').Any(part=>part.EndsWith("~")))continue;
                    if(path.EndsWith(".meta"))
                    {
                        string line=File.ReadLines(path).FirstOrDefault(s=>s.StartsWith("guid: "));if(line==null)continue;string guid=line.Substring(6).Trim();
                        Assert.That(guids.TryGetValue(guid,out var previous),Is.False,$"{guid}: {previous} / {path}");guids[guid]=path;
                    }
                    if(path.EndsWith(".asmdef"))
                    {
                        var match=System.Text.RegularExpressions.Regex.Match(File.ReadAllText(path),"\\\"name\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");Assert.That(match.Success,Is.True,path);string name=match.Groups[1].Value;
                        Assert.That(assemblies.TryGetValue(name,out var previous),Is.False,$"{name}: {previous} / {path}");assemblies[name]=path;
                    }
                }
            Assert.That(guids.Count,Is.GreaterThan(100));Assert.That(assemblies.ContainsKey("JJEvol.UI.URP.Runtime"),Is.True);
        }
    }
}
//추가 종료
