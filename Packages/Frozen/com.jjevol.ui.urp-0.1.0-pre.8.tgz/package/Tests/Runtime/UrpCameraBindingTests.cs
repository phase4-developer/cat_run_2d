using System;
using System.Collections;
using System.Linq;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using UnityEngine.TestTools;
using UnityEngine.TestTools.Constraints;
using Is = UnityEngine.TestTools.Constraints.Is;

namespace jjevol.UI.URP.Tests
{
    public sealed partial class UrpBootstrapTests
    {
        Action LateUpdateOf(UIManagerCreater creator) => (Action)Delegate.CreateDelegate(typeof(Action), creator, "LateUpdate");

        [UnityTest]public IEnumerator UnchangedBindingAllocatesNothingInLateUpdate()
        {
            yield return Done(_creator.StartInitAsync().AsTask());
            var tick=LateUpdateOf(_creator);
            tick();tick();
            TestDelegate frame=()=>tick();
            Assert.That(frame,Is.Not.AllocatingGCMemory(),"An unchanged binding must not traverse Canvases with allocation every frame.");
            Assert.That(_creator.IsInitialized,Is.True);
        }
        // Canvas.renderMode reads ScreenSpaceOverlay until a camera is set, so the scan only sees a Canvas that already has one.
        [UnityTest]public IEnumerator NewRootCanvasIsCheckedWithoutReinitialization()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;
            var late=New("late root canvas",typeof(RectTransform),typeof(Canvas));late.transform.SetParent(ui.transform,false);
            var canvas=late.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceCamera;canvas.worldCamera=Camera("late canvas camera");
            Assert.That(canvas.isRootCanvas,Is.True);
            yield return Until(()=>!_creator.IsInitialized);
            StringAssert.Contains("different Camera",_creator.LastInitializationError.Message);
        }
        // A code-made ScreenSpaceCamera Canvas with no camera is bound to the UI Camera with one warning; a real Overlay Canvas stays as it is.
        [UnityTest]public IEnumerator CameralessScreenSpaceCameraCanvasIsBoundWithOneWarning()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;
            var overlay=New("late overlay canvas",typeof(RectTransform),typeof(Canvas)).GetComponent<Canvas>();overlay.transform.SetParent(ui.transform,false);
            overlay.renderMode=RenderMode.ScreenSpaceOverlay;
            var first=New("late cameraless canvas",typeof(RectTransform),typeof(Canvas)).GetComponent<Canvas>();first.transform.SetParent(ui.transform,false);
            first.renderMode=RenderMode.ScreenSpaceCamera;
            Assert.That(first.worldCamera,Is.Null);
            LogAssert.Expect(LogType.Warning,new System.Text.RegularExpressions.Regex("had no camera and was bound to the UI Camera"));
            yield return Until(()=>first.worldCamera==ui.UICamera);
            Assert.That(first.renderMode,Is.EqualTo(RenderMode.ScreenSpaceCamera));
            Assert.That(overlay.worldCamera,Is.Null);
            Assert.That(overlay.renderMode,Is.EqualTo(RenderMode.ScreenSpaceOverlay));
            var second=New("second cameraless canvas",typeof(RectTransform),typeof(Canvas)).GetComponent<Canvas>();second.transform.SetParent(ui.transform,false);
            second.renderMode=RenderMode.ScreenSpaceCamera;
            yield return Until(()=>second.worldCamera==ui.UICamera);
            LogAssert.NoUnexpectedReceived();
            Assert.That(_creator.IsInitialized,Is.True);
            _creator.Shutdown();
            Assert.That(first.worldCamera,Is.Null,"Shutdown returns the borrowed camera reference.");
            Assert.That(second.worldCamera,Is.Null);
        }
        [UnityTest]public IEnumerator StackChangeIsRepairedWithoutReinitialization()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;
            var stack=_base.GetUniversalAdditionalCameraData().cameraStack;stack.Add(ui.UICamera);stack.Add(null);
            yield return Until(()=>stack.Count(item=>item==ui.UICamera)==1&&!stack.Contains(null));
            Assert.That(_creator.IsInitialized,Is.True);
        }
        [UnityTest]public IEnumerator DestroyedBaseIsDetectedInLateUpdate()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;var next=Camera("late replacement Base");next.tag="MainCamera";
            UnityEngine.Object.Destroy(_base.gameObject);
            yield return Until(()=>_creator.mainCamera==next);
            Assert.That(next.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==ui.UICamera),Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator RenderTypeChangeIsRestoredInLateUpdate()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var data=UIManager.Instance.UICamera.GetUniversalAdditionalCameraData();
            data.renderType=CameraRenderType.Base;
            yield return Until(()=>data.renderType==CameraRenderType.Overlay);
        }
        [UnityTest]public IEnumerator InvalidBaseRenderTypeStillFailsInLateUpdate()
        {
            yield return Done(_creator.StartInitAsync().AsTask());
            _base.GetUniversalAdditionalCameraData().renderType=CameraRenderType.Overlay;
            LogAssert.Expect(LogType.Warning,new System.Text.RegularExpressions.Regex("Camera reconnect failed"));
            yield return Until(()=>!_creator.IsInitialized);
            StringAssert.Contains("must be URP Base",_creator.LastInitializationError.Message);
        }
    }
}
