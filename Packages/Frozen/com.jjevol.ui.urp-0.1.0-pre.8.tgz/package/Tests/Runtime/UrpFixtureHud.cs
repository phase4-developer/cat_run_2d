//추가
namespace jjevol.UI.URP.Tests
{
    public sealed class UrpFixtureHud:UIHudBase { }
}
//추가 종료
