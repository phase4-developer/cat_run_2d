//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.UI.URP.Tests
{
    [PrebuildSetup("jjevol.UI.URP.Tests.UrpFixtureSetup")]
    [PostBuildCleanup("jjevol.UI.URP.Tests.UrpFixtureSetup")]
    public sealed partial class UrpBootstrapTests
    {
        readonly List<GameObject> _objects=new();
        readonly List<AsyncOperationHandle<SceneInstance>> _scenes=new();
        readonly List<AsyncOperationHandle> _assets=new();
        readonly List<Gate> _gates=new();readonly List<IResourceLocator> _locators=new();
        readonly List<AsyncOperationHandle<GameObject>> _external=new();
        readonly List<Scene> _temporary=new();
        Instances _instances;RenderPipelineAsset _priorPipeline,_priorQuality;
        UIManagerCreater _creator;Camera _base;AddressablesManager _resources;
        sealed class Instances:IInstanceProvider
        {
            public readonly IInstanceProvider Inner;public int Created,Returned,Roots;public readonly HashSet<GameObject> Live=new();
            public Instances(IInstanceProvider inner)=>Inner=inner;
            public GameObject ProvideInstance(ResourceManager rm,AsyncOperationHandle<GameObject> handle,InstantiationParameters p){var go=Inner.ProvideInstance(rm,handle,p);Live.Add(go);Created++;if(go.GetComponent<UIManager>())Roots++;return go;}
            public void ReleaseInstance(ResourceManager rm,GameObject go){Live.Remove(go);Returned++;Inner.ReleaseInstance(rm,go);}
        }
        sealed class Gate:ResourceProviderBase
        {
            readonly GameObject _asset;readonly string _id="step15-"+Guid.NewGuid().ToString("N");
            public override string ProviderId=>_id;
            public readonly List<ProvideHandle> Pending=new();public bool Open;public int Loads,Returns;
            public Gate(GameObject asset)=>_asset=asset;
            public override void Provide(ProvideHandle handle){Loads++;if(Open)handle.Complete(_asset,true,null);else Pending.Add(handle);}
            public void Finish(){Open=true;var copy=Pending.ToArray();Pending.Clear();foreach(var h in copy)h.Complete(_asset,true,null);}
            public override void Release(IResourceLocation location,object asset)=>Returns++;
        }
        static void Provider(IInstanceProvider p){var impl=typeof(Addressables).GetProperty("s_Addressables",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);impl.GetType().GetProperty("InstanceProvider").SetValue(impl,p);}
        // Each initialization that was not shared takes a generation, so this counts them.
        int Initializations=>Field<int>(_creator,"_generation");
        GameObject New(string name,params Type[] components){var go=new GameObject(name,components);_objects.Add(go);return go;}
        Camera Camera(string name){var camera=New(name,typeof(Camera),typeof(UniversalAdditionalCameraData)).GetComponent<Camera>();camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=Color.blue;camera.cullingMask=0;camera.allowHDR=false;camera.orthographic=true;camera.orthographicSize=1;camera.nearClipPlane=.1f;camera.farClipPlane=50;camera.transform.position=new Vector3(0,0,-10);return camera;}
        static IEnumerator Done(Task t){float end=Time.realtimeSinceStartup+15;while(!t.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;Assert.That(t.IsCompleted,Is.True);if(t.IsFaulted)throw t.Exception.GetBaseException();Assert.That(t.IsCanceled,Is.False);}
        static IEnumerator Until(Func<bool> predicate){float end=Time.realtimeSinceStartup+15;while(!predicate()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(predicate(),Is.True,"Condition must complete within 15 seconds");}
        // UniTask 2.5.10 AsTask wraps cancellation with TaskCompletionSource.SetException.
        static void Canceled(Task task){Assert.That(task.IsCompleted,Is.True);Assert.That(task.Exception?.GetBaseException(),Is.InstanceOf<OperationCanceledException>());}
        IEnumerator DelayedManager()
        {
            var source=Addressables.LoadAssetAsync<GameObject>("UIManager");_assets.Add(source);yield return Done(source.Task);
            var gate=new Gate(source.Result);_gates.Add(gate);Addressables.ResourceManager.ResourceProviders.Add(gate);
            var locator=new ResourceLocationMap(gate.ProviderId);locator.Add("Step15/DelayedManager",new ResourceLocationBase("Step15/DelayedManager","Step15/DelayedManager",gate.ProviderId,typeof(GameObject)));
            Addressables.AddResourceLocator(locator);_locators.Add(locator);_creator.UIManagerAddress="Step15/DelayedManager";
        }
        [UnitySetUp]public IEnumerator Setup()
        {
            UIManager.applicationIsQuitting=false;AddressablesManager.applicationIsQuitting=false;Time.timeScale=1;
            _priorPipeline=GraphicsSettings.defaultRenderPipeline;_priorQuality=QualitySettings.renderPipeline;
            var pipeline=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>("Assets/Step15URPFixtures/Pipeline.asset");GraphicsSettings.defaultRenderPipeline=pipeline;QualitySettings.renderPipeline=pipeline;
            var init=Addressables.InitializeAsync(false);yield return Done(init.Task);Addressables.Release(init);
            _instances=new Instances(Addressables.InstanceProvider);Provider(_instances);_resources=AddressablesManager.Instance;
            _base=Camera("Base Camera");_base.tag="MainCamera";
            _creator=New("bootstrap").AddComponent<UIManagerCreater>();_creator.mainCamera=_base;_creator.cashScreenTypes=new List<string>{"IntroScreen"};_creator.cashHudTypes=new List<string>{"MainMenuHud"};
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {
            foreach(var gate in _gates)gate.Finish();yield return null;
            foreach(var obj in _objects)if(obj)Object.Destroy(obj);_objects.Clear();yield return null;yield return null;yield return null;
            foreach(var operation in _external)if(operation.IsValid())Addressables.ReleaseInstance(operation);_external.Clear();yield return null;yield return null;
            int leaked=_instances.Live.Count;
            // Failure cleanup does not mask a leak: assertion below uses the pre-cleanup count.
            foreach(var instance in _instances.Live.ToArray())Addressables.ReleaseInstance(instance);yield return null;yield return null;
            foreach(var gate in _gates){yield return Until(()=>gate.Loads==gate.Returns);Addressables.ResourceManager.ResourceProviders.Remove(gate);}_gates.Clear();
            foreach(var locator in _locators)Addressables.RemoveResourceLocator(locator);_locators.Clear();
            foreach(var asset in _assets)if(asset.IsValid())Addressables.Release(asset);_assets.Clear();
            foreach(var h in _scenes)if(h.IsValid()&&h.Result.Scene.isLoaded){var unload=Addressables.UnloadSceneAsync(h);yield return unload;}_scenes.Clear();
            foreach(var scene in _temporary)if(scene.IsValid()&&scene.isLoaded)yield return SceneManager.UnloadSceneAsync(scene);_temporary.Clear();
            _resources.AfterSceneReload=null;
            Provider(_instances.Inner);if(_resources)Object.Destroy(_resources.gameObject);yield return null;
            GraphicsSettings.defaultRenderPipeline=_priorPipeline;QualitySettings.renderPipeline=_priorQuality;
            Assert.That(leaked,Is.Zero,"Owned SDK instances must return before fixture fallback cleanup");
            Assert.That(_instances.Returned,Is.EqualTo(_instances.Created));
        }
        [UnityTest]public IEnumerator CreatorDestroyMustReturnOwnedUiRootAndChildInstances()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;
            yield return Done(ui.SpawnUIPopupAsync("YesNoPopup").AsTask());yield return Done(ui.hudManager.CachingHudAsync(new List<string>{"MainMenuHud"}).AsTask());
            Object.Destroy(_creator.gameObject);yield return null;yield return null;yield return null;
            Assert.That(_instances.Live.Count,Is.Zero,"Bootstrap must return its root SDK Handle separately from UIManager child Handles");
        }
        [UnityTest]public IEnumerator NewSceneMustRebindExistingUiOverlayWithoutDuplicateInitialization()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;var oldBase=_base;
            var load=_resources.LoadSceneAsync("Step15/NextScene",LoadSceneMode.Additive);_scenes.Add(load);yield return Done(load.Task);
            var next=load.Result.Scene.GetRootGameObjects().SelectMany(go=>go.GetComponentsInChildren<Camera>()).Single();_creator.mainCamera=next;SceneManager.SetActiveScene(load.Result.Scene);
            _resources.AfterSceneReload=()=>_creator.StartInitAsync();yield return Done(_resources.AfterSceneReload().AsTask());
            Assert.That(next.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==ui.UICamera),Is.EqualTo(1));
            Assert.That(oldBase.GetUniversalAdditionalCameraData().cameraStack.Contains(ui.UICamera),Is.False);Assert.That(UIManager.Instance,Is.SameAs(ui));
        }
        [UnityTest]public IEnumerator ConcurrentCallsWaitForReadyScreenPopupAndHudWithOneRoot()
        {
            var first=_creator.StartInitAsync().AsTask();var second=_creator.StartInitAsync().AsTask();yield return Done(Task.WhenAll(first,second));
            Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(1));Assert.That(Initializations,Is.EqualTo(1));
            Assert.That(UIManager.Instance.GetComponentInChildren<Canvas>().worldCamera,Is.SameAs(UIManager.Instance.UICamera));
            Assert.That(UIManager.Instance.screenManager.screenPool.ContainsKey("IntroScreen"),Is.True);
            var screen=UIManager.Instance.screenManager.ChangeUIScreenAsync("IntroScreen").AsTask();yield return Done(screen);Assert.That(screen.Result,Is.Not.Null);Assert.That(screen.Result.IsVisible,Is.True);
            var popup=UIManager.Instance.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);Assert.That(popup.Result,Is.Not.Null);
            Assert.That(Object.FindObjectsByType<UrpFixtureHud>(FindObjectsInactive.Include,FindObjectsSortMode.None).Length,Is.EqualTo(1));
            yield return Done(_creator.StartInitAsync().AsTask());Assert.That(Initializations,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator StackPrunesNullAndOwnDuplicatesWhilePreservingOtherOverlay()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;var other=Camera("other overlay");other.GetUniversalAdditionalCameraData().renderType=CameraRenderType.Overlay;
            var stack=_base.GetUniversalAdditionalCameraData().cameraStack;stack.Add(null);stack.Add(ui.UICamera);stack.Add(other);stack.Add(ui.UICamera);
            yield return Done(_creator.StartInitAsync().AsTask());Assert.That(stack.Count(c=>c==ui.UICamera),Is.EqualTo(1));Assert.That(stack.Contains(null),Is.False);Assert.That(stack.Contains(other),Is.True);
            Assert.That(stack[0],Is.SameAs(ui.UICamera),"Repeat initialization preserves the original UI position rather than reordering other overlays");
            _creator.Shutdown();Assert.That(stack.Contains(other),Is.True);Assert.That(stack.Any(c=>c==ui.UICamera),Is.False);
        }
        [UnityTest]public IEnumerator DestroyedBaseReconnectsToNewTaggedSceneCamera()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;var next=Camera("replacement Base");next.tag="MainCamera";
            Object.Destroy(_base.gameObject);yield return null;yield return null;yield return Done(_creator.StartInitAsync().AsTask());
            Assert.That(_creator.mainCamera,Is.SameAs(next));Assert.That(next.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==ui.UICamera),Is.EqualTo(1));Assert.That(_instances.Roots,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator BorrowedUiRootRemainsOwnedByExternalSdkCaller()
        {
            var root=Addressables.InstantiateAsync("UIManager");_external.Add(root);yield return Done(root.Task);var ui=root.Result.GetComponent<UIManager>();
            yield return Done(_creator.StartInitAsync().AsTask());_creator.Shutdown();yield return null;yield return null;
            Assert.That(ui,Is.Not.Null);Assert.That(root.IsValid(),Is.True);Assert.That(_instances.Live.Contains(root.Result),Is.True);Assert.That(ui.UICamera.GetUniversalAdditionalCameraData().renderType,Is.EqualTo(CameraRenderType.Base));
            Assert.That(_base.GetUniversalAdditionalCameraData().cameraStack.Contains(ui.UICamera),Is.False);
        }
        [UnityTest]public IEnumerator ShutdownThenImmediateRestartDoesNotBorrowDyingSingleton()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var old=UIManager.Instance;_creator.Shutdown();yield return Done(_creator.StartInitAsync().AsTask());
            Assert.That(old==null,Is.True);Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(2));
        }
        [UnityTest]public IEnumerator DisableEnableAllowsFreshInitialization()
        {
            yield return Done(_creator.StartInitAsync().AsTask());_creator.enabled=false;yield return null;yield return null;Assert.That(_instances.Live.Count,Is.Zero);
            _creator.enabled=true;yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(2));
        }
        [UnityTest]public IEnumerator CallerCancellationDoesNotRetireSharedInitialization()
        {
            yield return DelayedManager();using var token=new CancellationTokenSource();var one=_creator.StartInitAsync(token.Token).AsTask();var shared=_creator.StartInitAsync().AsTask();yield return Until(()=>_gates[0].Pending.Count>0);
            token.Cancel();yield return Until(()=>one.IsCompleted);Canceled(one);Assert.That(shared.IsCompleted,Is.False);
            _gates[0].Finish();yield return Done(shared);Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator DestroyDuringNativeInstantiationReturnsLateRootAndItsHandle()
        {
            yield return DelayedManager();var pending=_creator.StartInitAsync().AsTask();yield return Until(()=>_gates[0].Pending.Count>0);Object.Destroy(_creator.gameObject);yield return null;
            _gates[0].Finish();yield return Until(()=>pending.IsCompleted);yield return Until(()=>_gates[0].Loads==_gates[0].Returns);yield return null;yield return null;
            Canceled(pending);Assert.That(_instances.Roots,Is.EqualTo(1));Assert.That(_instances.Live.Count,Is.Zero);
        }
        [UnityTest]public IEnumerator RestartWhileOldNativeLoadPendingDrainsBeforeCreatingFreshRoot()
        {
            yield return DelayedManager();var old=_creator.StartInitAsync().AsTask();yield return Until(()=>_gates[0].Pending.Count>0);_creator.Shutdown();var current=_creator.StartInitAsync().AsTask();yield return null;
            Canceled(old);Assert.That(current.IsCompleted,Is.False);_gates[0].Finish();yield return Done(current);yield return null;
            Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(2));Assert.That(_instances.Live.Count(go=>go.GetComponent<UIManager>()),Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator MissingAddressReportsFailureAndAllowsRetry()
        {
            _creator.UIManagerAddress="STEP15_missing_key";LogAssert.Expect(LogType.Error,new Regex("InvalidKeyException"));var fail=_creator.StartInitAsync().AsTask();yield return Until(()=>fail.IsCompleted);
            Assert.That(fail.IsFaulted,Is.True);Assert.That(_creator.IsInitialized,Is.False);Assert.That(_creator.LastInitializationError,Is.Not.Null);Assert.That(_instances.Live.Count,Is.Zero);
            _creator.UIManagerAddress="UIManager";yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.LastInitializationError,Is.Null);Assert.That(_creator.IsInitialized,Is.True);
        }
        [UnityTest]public IEnumerator NullCacheListsPreserveOptionalCachingAndInitialScreen()
        {
            _creator.cashScreenTypes=null;_creator.cashHudTypes=null;yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.IsInitialized,Is.True);var screens=UIManager.Instance.screenManager;Assert.That(screens.screenPool,Is.Empty);
            var screen=screens.ChangeUIScreenAsync("IntroScreen").AsTask();yield return Done(screen);Assert.That(screen.Result,Is.Not.Null);Assert.That(screens.screenPool.ContainsKey("IntroScreen"),Is.True);
        }
        [UnityTest]public IEnumerator MissingPipelineExplicitlyFailsBeforeSdkInstantiation()
        {
            GraphicsSettings.defaultRenderPipeline=null;QualitySettings.renderPipeline=null;var task=_creator.StartInitAsync().AsTask();yield return Until(()=>task.IsCompleted);
            Assert.That(task.IsFaulted,Is.True);StringAssert.Contains("URP Render Pipeline Asset",task.Exception.GetBaseException().Message);Assert.That(_instances.Created,Is.Zero);
        }
        [UnityTest]public IEnumerator OverlayConfiguredAsMainCameraFailsAndReturnsOwnedUi()
        {
            _base.GetUniversalAdditionalCameraData().renderType=CameraRenderType.Overlay;var task=_creator.StartInitAsync().AsTask();yield return Until(()=>task.IsCompleted);yield return null;yield return null;
            Assert.That(task.IsFaulted,Is.True);StringAssert.Contains("must be URP Base",task.Exception.GetBaseException().Message);Assert.That(_instances.Live.Count,Is.Zero);
        }
        [UnityTest]public IEnumerator ActualIncompatible2DAndUniversalRendererTypesAreRejected()
        {
            _base.enabled=false;var data=_base.GetUniversalAdditionalCameraData();data.SetRenderer(1);Assert.That(data.scriptableRenderer.SupportsCameraStackingType(CameraRenderType.Base),Is.True,"URP 17.3 Renderer2D supports stacking but its type differs from the UI UniversalRenderer");
            var task=_creator.StartInitAsync().AsTask();yield return Until(()=>task.IsCompleted);yield return null;yield return null;
            Assert.That(task.IsFaulted,Is.True);StringAssert.Contains("compatible URP Renderer types",task.Exception.GetBaseException().Message);Assert.That(_instances.Live.Count,Is.Zero);
        }
        [UnityTest]public IEnumerator ActualDeferredRendererWithoutOverlaySupportFailsExplicitly()
        {
            var root=Addressables.InstantiateAsync("UIManager");_external.Add(root);yield return Done(root.Task);var ui=root.Result.GetComponent<UIManager>();var data=ui.UICamera.GetUniversalAdditionalCameraData();data.SetRenderer(2);
            Assert.That(data.scriptableRenderer.SupportsCameraStackingType(CameraRenderType.Overlay),Is.False,"Actual URP Deferred Renderer supports Base only");
            var task=_creator.StartInitAsync().AsTask();yield return Until(()=>task.IsCompleted);Assert.That(task.IsFaulted,Is.True);StringAssert.Contains("does not support",task.Exception.GetBaseException().Message);Assert.That(root.Result,Is.Not.Null);
        }
        [UnityTest]public IEnumerator OriginalOverlayCanvasWithoutCameraIsPreservedForBorrowedUi()
        {
            var root=Addressables.InstantiateAsync("UIManager");_external.Add(root);yield return Done(root.Task);var canvas=root.Result.GetComponentInChildren<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.worldCamera=null;
            yield return Done(_creator.StartInitAsync().AsTask());Assert.That(canvas.renderMode,Is.EqualTo(RenderMode.ScreenSpaceOverlay));Assert.That(canvas.worldCamera,Is.Null);_creator.Shutdown();Assert.That(canvas.worldCamera,Is.Null);
        }
        [UnityTest]public IEnumerator RootCanvasWithWrongCameraFailsWithoutReleasingBorrowedRoot()
        {
            var root=Addressables.InstantiateAsync("UIManager");_external.Add(root);yield return Done(root.Task);root.Result.GetComponentInChildren<Canvas>().worldCamera=_base;
            var task=_creator.StartInitAsync().AsTask();yield return Until(()=>task.IsCompleted);Assert.That(task.IsFaulted,Is.True);StringAssert.Contains("different Camera",task.Exception.GetBaseException().Message);
            Assert.That(root.Result,Is.Not.Null);Assert.That(_base.GetUniversalAdditionalCameraData().cameraStack.Count,Is.Zero);
        }
        [UnityTest]public IEnumerator OriginalNullMainCameraStandaloneUiModeIsPreserved()
        {
            _creator.mainCamera=null;yield return Done(_creator.StartInitAsync().AsTask());Assert.That(UIManager.Instance.UICamera.GetUniversalAdditionalCameraData().renderType,Is.EqualTo(CameraRenderType.Base));Assert.That(_creator.IsInitialized,Is.True);
        }
        [UnityTest]public IEnumerator DuplicateCreatorCannotStealOwnershipOrClearPrimarySingleton()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var duplicate=New("duplicate bootstrap").AddComponent<UIManagerCreater>();var task=duplicate.StartInitAsync().AsTask();yield return Until(()=>task.IsCompleted);
            Assert.That(task.IsFaulted,Is.True);Object.Destroy(duplicate.gameObject);yield return null;Assert.That(UIManagerCreater.Instance,Is.SameAs(_creator));Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator SceneChangeDuringPendingRootRetiresOldWaitAndInitializesNewScene()
        {
            yield return DelayedManager();var old=_creator.StartInitAsync().AsTask();yield return Until(()=>_gates[0].Pending.Count>0);var scene=SceneManager.CreateScene("Step15_pending_scene");_temporary.Add(scene);SceneManager.SetActiveScene(scene);
            var current=_creator.StartInitAsync().AsTask();_gates[0].Finish();yield return Done(current);Canceled(old);Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator NativeSceneReloadCoalescesBootstrapAndExistingResourceHook()
        {
            Object.DontDestroyOnLoad(_creator.gameObject);int hooks=0;
            Func<UniTask> hook=()=>{hooks++;return _creator.StartInitAsync();};_resources.AfterSceneReload=hook;
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;
            var first=_resources.LoadSceneAsync("Step15/NextScene",LoadSceneMode.Single);_scenes.Add(first);yield return Done(first.Task);yield return Done(_creator.StartInitAsync().AsTask());
            Assert.That(UIManager.Instance,Is.SameAs(ui));Assert.That(_creator.mainCamera,Is.Not.Null);Assert.That(Initializations,Is.EqualTo(2));
            yield return _resources.ReloadActiveSceneAsync();yield return Done(_creator.StartInitAsync().AsTask());
            Assert.That(_resources.AfterSceneReload,Is.SameAs(hook));Assert.That(hooks,Is.EqualTo(1));Assert.That(Initializations,Is.EqualTo(3));Assert.That(_instances.Roots,Is.EqualTo(1));
            Assert.That(_creator.mainCamera.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==ui.UICamera),Is.EqualTo(1));
            // Preserve a neutral Scene for the Unity test runner before unloading the final SDK Scene.
            var neutral=SceneManager.CreateScene("Step15_return_scene");SceneManager.SetActiveScene(neutral);_creator.Shutdown();
            foreach(var loaded in _resources.loadedScenes.ToArray())yield return Done(_resources.UnloadSceneAsync(loaded).Task);
        }
        [UnityTest]public IEnumerator CreatorThatWasNeverStartedIgnoresSceneChangesAndCreatesNoManager()
        {
            Object.DontDestroyOnLoad(_creator.gameObject);
            var load=_resources.LoadSceneAsync("Step15/NextScene",LoadSceneMode.Single);_scenes.Add(load);yield return Done(load.Task);yield return null;yield return null;
            // Preserve a neutral Scene for the Unity test runner before unloading the final SDK Scene.
            var neutral=SceneManager.CreateScene("Step15_unstarted_"+Guid.NewGuid().ToString("N"));SceneManager.SetActiveScene(neutral);
            foreach(var loaded in _resources.loadedScenes.ToArray())yield return Done(_resources.UnloadSceneAsync(loaded).Task);
            Assert.That(_creator.IsStarted,Is.False);Assert.That(_creator.IsInitialized,Is.False);Assert.That(Initializations,Is.Zero);Assert.That(UIManager.HasInstance,Is.False);Assert.That(_instances.Roots,Is.Zero);
        }
        [UnityTest]public IEnumerator StartedCreatorInitializesAgainOnSceneChange()
        {
            yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.IsStarted,Is.True);var ui=UIManager.Instance;
            var load=_resources.LoadSceneAsync("Step15/NextScene",LoadSceneMode.Additive);_scenes.Add(load);yield return Done(load.Task);
            SceneManager.SetActiveScene(load.Result.Scene);
            yield return Until(()=>_creator.IsInitialized&&Field<Scene>(_creator,"_readyScene")==load.Result.Scene);
            Assert.That(Initializations,Is.EqualTo(2),"The scene change alone must restart initialization.");Assert.That(UIManager.Instance,Is.SameAs(ui));Assert.That(_instances.Roots,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator ShutdownClearsIsStarted()
        {
            Assert.That(_creator.IsStarted,Is.False);yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.IsStarted,Is.True);
            _creator.Shutdown();Assert.That(_creator.IsStarted,Is.False);
        }
    }
}
//추가 종료
