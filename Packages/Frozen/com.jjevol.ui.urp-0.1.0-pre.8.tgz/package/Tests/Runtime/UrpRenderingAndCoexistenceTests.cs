//추가
using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Threading;
using Cysharp.Threading.Tasks;
using jjevol.Audio;
using jjevol.Effect;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.UI.URP.Tests
{
    public sealed partial class UrpBootstrapTests
    {
        sealed class PrefabLeases:IEffectPrefabProvider
        {
            readonly AddressablesEffectPrefabProvider _sdk=new();public int Loads,Returns;
            public async UniTask<EffectPrefabLease> LoadAsync(string key,CancellationToken token)
            {
                var lease=await _sdk.LoadAsync(key,token);if(lease==null)return null;Loads++;
                return new EffectPrefabLease(lease.Prefab,()=>{Returns++;lease.Dispose();});
            }
        }
        static T Field<T>(object target,string name)=>(T)target.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(target);
        static Texture2D Read(RenderTexture target)
        {
            var prior=RenderTexture.active;RenderTexture.active=target;var image=new Texture2D(target.width,target.height,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,target.width,target.height),0,0);image.Apply();RenderTexture.active=prior;return image;
        }
        [UnityTest]public IEnumerator RealUrpStackCompositesRedUiOverBlueBaseIntoRenderTexture()
        {
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;yield return Done(ui.screenManager.ChangeUIScreenAsync("IntroScreen").AsTask());Canvas.ForceUpdateCanvases();yield return null;yield return null;
            var canvas=ui.GetComponentInChildren<Canvas>();canvas.updateRectTransformForStandalone=StandaloneRenderResize.Enabled;
            var target=new RenderTexture(256,256,24,RenderTextureFormat.ARGB32);target.Create();Texture2D composed=null,baseOnly=null;
            // URP's Game-camera path assumes the normal Game view already emitted native UI geometry.
            // A batch/manual StandardRequest has no Game view; use the public SDK emission API before culling.
            Action<ScriptableRenderContext,Camera> emit=(context,camera)=>ScriptableRenderContext.EmitGeometryForCamera(camera);
            RenderPipelineManager.beginCameraRendering+=emit;
            try
            {
                _base.targetTexture=target;_base.aspect=1;ui.UICamera.aspect=1;
                Canvas.ForceUpdateCanvases();yield return null;yield return null;
                Assert.That(RenderPipeline.SupportsRenderRequest(_base,new RenderPipeline.StandardRequest{destination=target}),Is.True);
                RenderPipeline.SubmitRenderRequest(_base,new RenderPipeline.StandardRequest{destination=target});composed=Read(target);
                ui.UICamera.enabled=false;RenderPipeline.SubmitRenderRequest(_base,new RenderPipeline.StandardRequest{destination=target});baseOnly=Read(target);ui.UICamera.enabled=true;
                var center=composed.GetPixel(128,128);var corner=composed.GetPixel(8,8);var baseline=baseOnly.GetPixel(128,128);
                // Evidence stays inside the Host, outside Assets, Packages and ProjectSettings.
                string folder=Path.GetFullPath(Path.Combine(Application.dataPath,"..","Logs","UrpRendering"));Directory.CreateDirectory(folder);File.WriteAllBytes(Path.Combine(folder,"urp-stack-composed.png"),composed.EncodeToPNG());File.WriteAllBytes(Path.Combine(folder,"urp-base-only.png"),baseOnly.EncodeToPNG());
                Debug.Log($"STEP15 pixels center={center} corner={corner} baseline={baseline}");
                Assert.That(center.r,Is.GreaterThan(.8f));Assert.That(center.b,Is.LessThan(.2f));Assert.That(corner.b,Is.GreaterThan(.8f));Assert.That(baseline.b,Is.GreaterThan(.8f));Assert.That(baseline.r,Is.LessThan(.2f));
            }
            finally{RenderPipelineManager.beginCameraRendering-=emit;_base.targetTexture=null;if(composed)Object.Destroy(composed);if(baseOnly)Object.Destroy(baseOnly);target.Release();Object.Destroy(target);}
        }
        [UnityTest]public IEnumerator BootstrapShutdownReturnsUiImageAndEffectLeasesWithoutReleasingAudioOwner()
        {
            AudioManager.applicationIsQuitting=false;EffectManager.applicationIsQuitting=false;
            yield return Done(_creator.StartInitAsync().AsTask());var ui=UIManager.Instance;
            var effect=New("coexist effect manager").AddComponent<EffectManager>();var prefabs=new PrefabLeases();effect.SetPrefabProvider(prefabs);
            using var clips=new AddressablesClipProvider();var audio=New("coexist audio manager").AddComponent<AudioManager>();audio.SetProvider(clips);if(!Object.FindAnyObjectByType<AudioListener>())New("listener",typeof(AudioListener));
            var general=AddressableScope.Get<AudioClip>("Step15/Audio").AsTask();yield return Done(general);
            try
            {
                var sound=audio.PlayAsync("Step15/Audio",loop:true,debounce:0);yield return Done(sound);Assert.That(sound.Result.isPlaying,Is.True);
                effect.SetPoolProfile("Step15/Toast",0,4,.1f);effect.SetPoolProfile("Step15/Icon",0,4,.1f);
                var toastTask=effect.PlayAsync(new EffectRequest("Step15/Toast",loop:true,parent:ui.EffectRoot)).AsTask();yield return Done(toastTask);
                var toast=(ToastMessageEffectRenderer)toastTask.Result.Renderer;toast.SetData("urp_icon","STEP15 actual TMP");toast.SetCharacterData("Step15/Texture","character");
                var image=Field<AddressableImage>(toast,"iconSprite");var character=Field<AddressableTexture>(toast,"characterTexture");yield return Until(()=>image.sprite&&character.sprite);
                var message=Field<TMP_Text>(toast,"messageText");message.ForceMeshUpdate();Assert.That(message.textInfo.characterCount,Is.GreaterThan(0));
                var iconTask=effect.PlayAsync(new EffectRequest("Step15/Icon",loop:true,icon:"urp_icon",parent:ui.EffectRoot)).AsTask();yield return Done(iconTask);
                var icon=iconTask.Result.GetComponentInChildren<EffectIconBehaviour>();yield return Until(()=>icon.LoadSucceeded);Assert.That(Field<AddressableImage>(icon,"_iconImage").sprite.name.StartsWith("urp_icon"),Is.True);
                Assert.That(_resources.GetRefCount("Step15/Atlas"),Is.EqualTo(2));Assert.That(_resources.GetRefCount("Step15/Texture"),Is.EqualTo(1));
                _creator.Shutdown();yield return null;yield return null;yield return Until(()=>!toastTask.Result&&!iconTask.Result);
                yield return Until(()=>prefabs.Returns==prefabs.Loads);Assert.That(prefabs.Loads,Is.EqualTo(2));Assert.That(prefabs.Returns,Is.EqualTo(2));
                Assert.That(_resources.GetRefCount("Step15/Atlas"),Is.Zero);Assert.That(_resources.GetRefCount("Step15/Texture"),Is.Zero);
                Assert.That(clips.ActiveLeaseCount,Is.EqualTo(1));Assert.That(sound.Result.isPlaying,Is.True);Assert.That(general.Result.Asset,Is.Not.Null);
                Assert.That(_resources.TryGetLoadedAsset<AudioClip>("Step15/Audio",out var peek),Is.True);Assert.That(_resources.GetRefCount("Step15/Audio"),Is.EqualTo(1));
                Assert.That(_resources.GetAsset<AudioClip>("Step15/Audio"),Is.SameAs(peek));Assert.That(_resources.GetRefCount("Step15/Audio"),Is.EqualTo(2));AddressablesManager.ReleaseAsset("Step15/Audio");
                audio.StopAll();Assert.That(clips.ActiveLeaseCount,Is.Zero);Assert.That(general.Result.Asset,Is.Not.Null);
            }
            finally{audio.StopAll();general.Result.Dispose();}
            Assert.That(_resources.GetRefCount("Step15/Audio"),Is.Zero);
        }
    }
}
//추가 종료
