//추가
using System;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;
using UnityEngine.U2D;
using UnityEditor.U2D;
using UnityEditor.Animations;
using jjevol.Effect;
using jjevol.Effect.Renderers;
using Object=UnityEngine.Object;

namespace jjevol.UI.URP.Tests
{
    /// Authors the STEP15 fixture before a run and puts back the project settings it changed after the run.
    /// The snapshot lives in SessionState so it survives the domain reload of entering Play Mode.
    public sealed class UrpFixtureSetup:IPrebuildSetup,IPostBuildCleanup
    {
        public const string Root="Assets/Step15URPFixtures";
        const string DefaultObjectPath="Assets/AddressableAssetsData/DefaultObject.asset";
        const string SnapshotKey="jjevol.UI.URP.Tests.SettingsSnapshot";
        static string Guid(Object asset)=>asset?AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(asset)):"";
        static T Load<T>(string guid) where T:Object=>string.IsNullOrEmpty(guid)?null:AssetDatabase.LoadAssetAtPath<T>(AssetDatabase.GUIDToAssetPath(guid));
        // Keeps the first snapshot when a run that never cleaned up left one in this session.
        static void Capture()
        {
            if(!string.IsNullOrEmpty(SessionState.GetString(SnapshotKey,"")))return;
            bool hadDefaultObject=File.Exists(DefaultObjectPath);
            string addressables=hadDefaultObject?Guid(AddressableAssetSettingsDefaultObject.GetSettings(false)):"";
            SessionState.SetString(SnapshotKey,string.Join("|",Guid(GraphicsSettings.defaultRenderPipeline),Guid(QualitySettings.renderPipeline),((int)EditorSettings.spritePackerMode).ToString(),hadDefaultObject?"1":"0",addressables));
        }
        static void Restore()
        {
            string snapshot=SessionState.GetString(SnapshotKey,"");if(string.IsNullOrEmpty(snapshot))return;
            var parts=snapshot.Split('|');
            GraphicsSettings.defaultRenderPipeline=Load<RenderPipelineAsset>(parts[0]);QualitySettings.renderPipeline=Load<RenderPipelineAsset>(parts[1]);
            EditorSettings.spritePackerMode=(SpritePackerMode)int.Parse(parts[2]);
            if(parts[3]=="1")AddressableAssetSettingsDefaultObject.Settings=Load<AddressableAssetSettings>(parts[4]);
            else if(File.Exists(DefaultObjectPath))AssetDatabase.DeleteAsset(DefaultObjectPath);
            AssetDatabase.SaveAssets();SessionState.EraseString(SnapshotKey);
        }
        public void Cleanup()=>Restore();
        static void Guard()
        {
            string project=Path.GetFullPath(Path.Combine(Application.dataPath,"..")).Replace('\\','/');
            if(!project.EndsWith("/.local/ui-urp-validation/IntegrationHost",StringComparison.OrdinalIgnoreCase)&&!project.Contains("/.local/validation-current/")&&!project.EndsWith("/.local/qa/Hosts/CombinedValidationHost",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Only the new STEP15 IntegrationHost may be authored");
        }
        public static void ImportTMP()
        {
            Guard();if(Shader.Find("TextMeshPro/Mobile/Distance Field")){EditorApplication.Exit(0);return;}
            var package=UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TMP_Text).Assembly);
            AssetDatabase.ImportPackage(Path.Combine(package.resolvedPath,"Package Resources","TMP Essential Resources.unitypackage"),false);
            double end=EditorApplication.timeSinceStartup+120;EditorApplication.CallbackFunction done=null;
            done=()=>{if(Shader.Find("TextMeshPro/Mobile/Distance Field")&&!EditorApplication.isUpdating&&!EditorApplication.isCompiling){EditorApplication.update-=done;EditorApplication.Exit(0);}else if(EditorApplication.timeSinceStartup>end){EditorApplication.update-=done;Debug.LogError("TMP import timeout");EditorApplication.Exit(1);}};EditorApplication.update+=done;
        }
        public static void RebuildOwnFixtures()
        {
            Guard();if(AssetDatabase.IsValidFolder(Root)&&!AssetDatabase.DeleteAsset(Root))throw new InvalidOperationException("Cannot recreate own fixture folder");
            try{new UrpFixtureSetup().Setup();}finally{Restore();}
        }
        // A failure after Capture would skip Cleanup, so put the Host's settings back before rethrowing.
        public void Setup()
        {
            Guard();Capture();
            try{Build();}catch{Restore();throw;}
        }
        void Build()
        {
            // The STEP15 atlas only packs in Play Mode with V2 on. Set it for every run, not only when the fixture is authored, since Cleanup puts the Host's mode back.
            EditorSettings.spritePackerMode=SpritePackerMode.SpriteAtlasV2;
            if(!Shader.Find("TextMeshPro/Mobile/Distance Field"))throw new InvalidOperationException("Import TMP before tests");
            if(AssetDatabase.IsValidFolder(Root))
            {
                var current=AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(Root+"/Settings.asset");if(!current)throw new InvalidOperationException("Fixture incomplete");AddressableAssetSettingsDefaultObject.Settings=current;
                Supplement(current);
                SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(current)));return;
            }
            AssetDatabase.CreateFolder("Assets",Path.GetFileName(Root));
            var authoringScene=SceneManager.GetActiveScene();
            if(string.IsNullOrEmpty(authoringScene.path))EditorSceneManager.SaveScene(authoringScene,Root+"/Authoring.unity");
            var renderer=ScriptableObject.CreateInstance<UniversalRendererData>();AssetDatabase.CreateAsset(renderer,Root+"/Renderer.asset");
            var pipeline=UniversalRenderPipelineAsset.Create(renderer);pipeline.msaaSampleCount=1;pipeline.supportsHDR=false;AssetDatabase.CreateAsset(pipeline,Root+"/Pipeline.asset");
            GraphicsSettings.defaultRenderPipeline=pipeline;QualitySettings.renderPipeline=pipeline;
            var settings=AddressableAssetSettings.Create(Root,"Settings",true,true);AddressableAssetSettingsDefaultObject.Settings=settings;
            for(int i=0;i<settings.DataBuilders.Count;i++)if(settings.DataBuilders[i] is BuildScriptFastMode)settings.ActivePlayModeDataBuilderIndex=i;
            void Register(string path,string key)=>settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path),settings.DefaultGroup).address=key;
            GameObject Rect(string name,Transform parent=null){var go=new GameObject(name,typeof(RectTransform));go.layer=5;if(parent)go.transform.SetParent(parent,false);var rt=(RectTransform)go.transform;rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.sizeDelta=Vector2.zero;return go;}
            foreach(var type in new[]{"IntroScreen","LobbyScreen"})
            {
                var root=Rect("screen");root.AddComponent<UIScreen>().ScreenType=type;var image=Rect("center UI pixel",root.transform).AddComponent<Image>();image.color=Color.red;image.rectTransform.anchorMin=Vector2.one*.25f;image.rectTransform.anchorMax=Vector2.one*.75f;
                string path=Root+"/"+type+".prefab";PrefabUtility.SaveAsPrefabAsset(root,path);Object.DestroyImmediate(root);Register(path,"UIScreen_"+type);
            }
            var popup=Rect("popup");popup.AddComponent<CanvasGroup>();popup.AddComponent<UIPopup>();PrefabUtility.SaveAsPrefabAsset(popup,Root+"/Popup.prefab");Object.DestroyImmediate(popup);Register(Root+"/Popup.prefab","UIPopup_YesNoPopup");
            var hud=Rect("HUD");hud.AddComponent<UrpFixtureHud>();PrefabUtility.SaveAsPrefabAsset(hud,Root+"/Hud.prefab");Object.DestroyImmediate(hud);Register(Root+"/Hud.prefab","UIHud_MainMenuHud");
            BuildManagerFixture();
            Register(Root+"/UIManager.prefab","UIManager");
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);var sceneCam=new GameObject("scene main camera",typeof(Camera),typeof(UniversalAdditionalCameraData));sceneCam.tag="MainCamera";sceneCam.GetComponent<Camera>().backgroundColor=Color.blue;SceneManager.MoveGameObjectToScene(sceneCam,scene);EditorSceneManager.SaveScene(scene,Root+"/NextScene.unity");EditorSceneManager.CloseScene(scene,true);Register(Root+"/NextScene.unity","Step15/NextScene");
            EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();AssetDatabase.Refresh();
            Supplement(settings);
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
        }
        static void Supplement(AddressableAssetSettings settings)
        {
            if(AssetDatabase.LoadAssetAtPath<GameObject>(Root+"/UIManager.prefab").GetComponent<Canvas>())BuildManagerFixture();
            string whitePath=Root+"/White.asset";var white=AssetDatabase.LoadAssetAtPath<Texture2D>(whitePath);
            if(!white){white=new Texture2D(4,4);var pixels=new Color[16];Array.Fill(pixels,Color.white);white.SetPixels(pixels);white.Apply();AssetDatabase.CreateAsset(white,whitePath);var sprite=Sprite.Create(white,new Rect(0,0,4,4),Vector2.one*.5f);sprite.name="independent_white";AssetDatabase.AddObjectToAsset(sprite,white);}
            var whiteSprite=Array.Find(AssetDatabase.LoadAllAssetsAtPath(whitePath),a=>a is Sprite) as Sprite;
            foreach(var type in new[]{"IntroScreen","LobbyScreen"}){var contents=PrefabUtility.LoadPrefabContents(Root+"/"+type+".prefab");contents.GetComponentInChildren<Image>().sprite=whiteSprite;PrefabUtility.SaveAsPrefabAsset(contents,Root+"/"+type+".prefab");PrefabUtility.UnloadPrefabContents(contents);}
            var pipeline=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(Root+"/Pipeline.asset");
            if(!File.Exists(Root+"/DeferredRenderer.asset"))
            {
                var deferred=ScriptableObject.CreateInstance<UniversalRendererData>();deferred.renderingMode=RenderingMode.Deferred;AssetDatabase.CreateAsset(deferred,Root+"/DeferredRenderer.asset");
                var so=new SerializedObject(pipeline);var list=so.FindProperty("m_RendererDataList");list.arraySize=3;list.GetArrayElementAtIndex(2).objectReferenceValue=deferred;so.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(pipeline);
            }
            if(!File.Exists(Root+"/Renderer2D.asset"))
            {
                var data=ScriptableObject.CreateInstance<Renderer2DData>();AssetDatabase.CreateAsset(data,Root+"/Renderer2D.asset");
                var so=new SerializedObject(pipeline);var list=so.FindProperty("m_RendererDataList");if(list.arraySize<2)list.arraySize=2;list.GetArrayElementAtIndex(1).objectReferenceValue=data;so.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(pipeline);
            }
            if(File.Exists(Root+"/Toast.prefab")){AssetDatabase.SaveAssets();return;}
            void Register(string path,string key)=>settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path),settings.DefaultGroup).address=key;
            void Field(Object target,string name,Object value){var so=new SerializedObject(target);so.FindProperty(name).objectReferenceValue=value;so.ApplyModifiedPropertiesWithoutUndo();}
            var texture=new Texture2D(16,16);var colors=new Color[256];Array.Fill(colors,Color.green);texture.SetPixels(colors);texture.Apply();
            File.WriteAllBytes(Root+"/urp_icon.png",texture.EncodeToPNG());AssetDatabase.CreateAsset(texture,Root+"/Texture.asset");Register(Root+"/Texture.asset","Step15/Texture");AssetDatabase.ImportAsset(Root+"/urp_icon.png");
            var importer=(TextureImporter)AssetImporter.GetAtPath(Root+"/urp_icon.png");importer.textureType=TextureImporterType.Sprite;importer.spriteImportMode=SpriteImportMode.Single;importer.textureCompression=TextureImporterCompression.Uncompressed;importer.SaveAndReimport();
            var atlas=new SpriteAtlasAsset();atlas.Add(new Object[]{AssetDatabase.LoadAssetAtPath<Texture2D>(Root+"/urp_icon.png")});SpriteAtlasAsset.Save(atlas,Root+"/Atlas.spriteatlasv2");AssetDatabase.ImportAsset(Root+"/Atlas.spriteatlasv2");Register(Root+"/Atlas.spriteatlasv2","Step15/Atlas");
            var clip=new AnimationClip{name="independent UI effect"};clip.SetCurve("",typeof(Transform),"localPosition.x",AnimationCurve.Linear(0,0,.5f,1));AssetDatabase.CreateAsset(clip,Root+"/Motion.anim");
            var controller=AnimatorController.CreateAnimatorControllerAtPath(Root+"/Effect.controller");var state=controller.layers[0].stateMachine.AddState("Play");state.motion=clip;controller.layers[0].stateMachine.defaultState=state;
            foreach(string kind in new[]{"Toast","Icon"})
            {
                var root=new GameObject(kind,typeof(RectTransform));root.layer=5;root.SetActive(false);var animator=root.AddComponent<Animator>();animator.runtimeAnimatorController=controller;animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
                var child=new GameObject("icon",typeof(RectTransform));child.transform.SetParent(root.transform,false);child.layer=5;var image=child.AddComponent<AddressableImage>();
                var im=new SerializedObject(image);im.FindProperty("m_AtlasKey").stringValue="Step15/Atlas";im.FindProperty("m_LoadOnEnable").boolValue=false;im.ApplyModifiedPropertiesWithoutUndo();
                if(kind=="Toast")
                {
                    var renderer=root.AddComponent<ToastMessageEffectRenderer>();Field(renderer,"iconSprite",image);Field(renderer,"_animator",animator);
                    var message=new GameObject("message",typeof(RectTransform));message.transform.SetParent(root.transform,false);message.layer=5;Field(renderer,"messageText",message.AddComponent<TextMeshProUGUI>());
                    var character=new GameObject("character",typeof(RectTransform));character.transform.SetParent(root.transform,false);character.layer=5;var img=character.AddComponent<AddressableTexture>();var cs=new SerializedObject(img);cs.FindProperty("m_LoadOnEnable").boolValue=false;cs.FindProperty("m_ShowLoading").boolValue=false;cs.FindProperty("m_FadeColorDuration").floatValue=0;cs.ApplyModifiedPropertiesWithoutUndo();Field(renderer,"characterTexture",img);
                    var so=new SerializedObject(renderer);so.FindProperty("_playStateName").stringValue="Play";so.ApplyModifiedPropertiesWithoutUndo();
                }
                else{var renderer=root.AddComponent<AnimatorEffectRenderer>();Field(renderer,"animator",animator);var behaviour=root.AddComponent<EffectIconBehaviour>();Field(behaviour,"_iconImage",image);}
                root.SetActive(true);PrefabUtility.SaveAsPrefabAsset(root,Root+"/"+kind+".prefab");Object.DestroyImmediate(root);Register(Root+"/"+kind+".prefab","Step15/"+kind);
            }
            string wave=Root+"/Audio.wav";using(var writer=new BinaryWriter(File.Create(wave))){int count=4410;writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));writer.Write(36+count*2);writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));writer.Write(16);writer.Write((short)1);writer.Write((short)1);writer.Write(44100);writer.Write(88200);writer.Write((short)2);writer.Write((short)16);writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));writer.Write(count*2);for(int i=0;i<count;i++)writer.Write((short)(Math.Sin(i*2*Math.PI*220/44100)*2000));}
            AssetDatabase.ImportAsset(wave);Register(wave,"Step15/Audio");EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();AssetDatabase.Refresh();
        }
        static void BuildManagerFixture()
        {
            // Camera is a sibling of the Canvas: nesting it under its own camera-space Canvas
            // creates a circular layout/camera transform and can serialize zero Canvas scale.
            GameObject Rect(string name,Transform parent){var go=new GameObject(name,typeof(RectTransform));go.layer=5;go.transform.SetParent(parent,false);var rt=(RectTransform)go.transform;rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.sizeDelta=Vector2.zero;return go;}
            var root=new GameObject("UIManager");root.SetActive(false);var manager=root.AddComponent<UIManager>();
            var cameraObject=new GameObject("UI Camera",typeof(Camera),typeof(UniversalAdditionalCameraData));cameraObject.transform.SetParent(root.transform,false);cameraObject.transform.localPosition=new Vector3(0,0,-10);
            var camera=cameraObject.GetComponent<Camera>();camera.orthographic=true;camera.orthographicSize=1;camera.nearClipPlane=.1f;camera.farClipPlane=50;camera.cullingMask=1<<5;camera.allowHDR=false;
            var canvas=Rect("UI Canvas",root.transform).AddComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceCamera;canvas.worldCamera=camera;canvas.planeDistance=1;
            var screens=Rect("screens",canvas.transform);var popups=Rect("popups",canvas.transform);Rect("Backboard",popups.transform).AddComponent<Image>();var huds=Rect("HUDs",canvas.transform);huds.AddComponent<Canvas>();var effects=Rect("effects",canvas.transform);var loading=Rect("loading",canvas.transform);
            var so=new SerializedObject(manager);foreach(var pair in new[]{("uiCamera",(Object)camera),("screenRoot",screens.transform),("popupRoot",popups.transform),("hudRoot",huds.transform),("effectRoot",effects.transform),("loadingRoot",loading.transform)})so.FindProperty(pair.Item1).objectReferenceValue=pair.Item2;so.ApplyModifiedPropertiesWithoutUndo();
            root.SetActive(true);Canvas.ForceUpdateCanvases();
            // Batch Editor has no Game view layout during asset authoring; save valid independent geometry.
            var rect=(RectTransform)canvas.transform;rect.sizeDelta=new Vector2(640,480);rect.localScale=Vector3.one*(2f/480f);rect.localPosition=new Vector3(0,0,-9);
            PrefabUtility.SaveAsPrefabAsset(root,Root+"/UIManager.prefab");Object.DestroyImmediate(root);
        }
    }
}
//추가 종료
