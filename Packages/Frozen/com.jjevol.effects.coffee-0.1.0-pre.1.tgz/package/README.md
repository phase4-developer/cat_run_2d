# JJEvol Coffee UI Particle Scale

Optional UPM `com.jjevol.effects.coffee@0.1.0-pre.1`. The sole production component is the original **global `SyncUIParticleScale`**. No new renderer or manager is provided. Coffee SDK source and game content are not bundled.

Runtime dependencies: **Coffee UI Particle 4.11.3**, **UniTask 2.5.11**, **uGUI 2.0.0**, Unity **6000.3.9f1**. Consumers must separately supply Coffee from their approved package source. The tested local SDK is MIT licensed, commit `c54f63cb18a22382215b142b63e232f0f86fff58`; its existing copyright and LICENSE are retained in isolated SDK copies. UI Material Property Injector is not required by this helper or the tested Coffee package.

Assembly `JJEvol.Effects.Coffee.Runtime` references `Coffee.UIParticle`, `UniTask`, and `Unity.ugui`. It does not require Effects Core, UI Navigation, URP, Economy, Audio, or Resources. SDK and rendering pipeline selection remain consumer choices.

## Existing behavior

Attach to the same RectTransform as a real `Coffee.UIExtensions.UIParticle`. `RequireComponent` and `ExecuteAlways` are preserved. Configure the layout and `UIParticle.scale3D`, then use **Capture Current Status** / `CaptureReference()` to serialize the reference. Private serialized fields are **baseSize : Vector2**, **baseScale3D : Vector3**. Script GUID remains **e0233d3e1d651b441a7ce3cf59625196**.

For width ratio X and height ratio Y, output scale is:

```text
(baseScale3D.x * X, baseScale3D.y * Y, baseScale3D.z * (X + Y) / 2)
```

RectTransform dimension changes and Editor updates apply the ratio. Runtime Start waits for LastPostLateUpdate and captures if its existing reference-size condition requires it. Invalid/nonpositive reference dimensions prevent scale calculation. The helper changes `UIParticle.scale3D`, not the parent's layout, anchors, or Transform scale. Coffee's own autoScalingMode, CanvasScaler, hierarchy scale and material still affect final rendering; this component does not replace those SDK policies.

The only production fix adds a destroyed-component check after the existing Start yield. A real SDK/PlayerLoop test reproduced an already-entered Start writing to a surviving UIParticle after its helper was destroyed. No scale formula, public API, field, particle simulation, or pooling policy was changed. Original CP949/CRLF and meta are retained.

## Effects Core usage

This helper is independent of `IEffectRenderer` / `IEffectBehaviour`. For an EffectManager prefab, explicitly include the existing **ParticleEffectRenderer** on the prefab root, with the real ParticleSystem beneath it. Existing EffectHandle remains a separate wrapper; access the particle root through `handle.Renderer.Root`.

Mobile EffectManager had a Coffee-specific auto-selection branch. The extracted Core rejects unregistered vendor root fallbacks; installing this scale helper does not register a new renderer. Explicit ParticleEffectRenderer selects the existing supported path without changing Core. An automatic Coffee factory was not added to broaden a one-component extraction.

Tests use isolated addressable prefabs, procedural texture/material, real Coffee SDK, native Canvas/Camera/ParticleSystem, and existing prefab leases. Test-only optional coexistence code is archived under `Tests/Coexist~` and copied only into the new validation Host. No paid SDK is in this UPM. Validation scope is in the Framework `Docs/Guide/Verification.md`; Player/device/product assets and all shader/material combinations are separate verification.
