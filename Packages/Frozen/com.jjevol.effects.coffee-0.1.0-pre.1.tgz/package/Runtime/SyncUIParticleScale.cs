using Coffee.UIExtensions;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

[ExecuteAlways] // ������ ��忡���� �ǽð� Ȯ�� ����
[RequireComponent(typeof(UIParticle), typeof(RectTransform))]
public class SyncUIParticleScale : MonoBehaviour
{
    [SerializeField] private Vector2 baseSize;
    [SerializeField] private Vector3 baseScale3D;

    private UIParticle uiParticle;
    private RectTransform rectTransform;
    private bool isInitialized = false;

    void Awake()
    {
        uiParticle = GetComponent<UIParticle>();
        rectTransform = GetComponent<RectTransform>();
    }

    async void Start()
    {
        if (!Application.isPlaying) return;

        // ��Ÿ��: ���̾ƿ� Ȯ�� ���
        await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);

        //�߰�
        if (!this) return;
        //�߰� ����

        if (baseSize == Vector2.zero || baseSize.x <= 0)
        {
            CaptureReference();
        }

        isInitialized = true;
        UpdateScale();
    }

    void OnEnable()
    {
        if (isInitialized || !Application.isPlaying)
        {
            UpdateScale();
        }
    }

    void OnValidate()
    {
        if (uiParticle == null) uiParticle = GetComponent<UIParticle>();
        if (rectTransform == null) rectTransform = GetComponent<RectTransform>();
    }

    [ContextMenu("Capture Current Status")]
    public void CaptureReference()
    {
        if (rectTransform == null) rectTransform = GetComponent<RectTransform>();
        if (uiParticle == null) uiParticle = GetComponent<UIParticle>();

        // RectTransform�� ���� '����' �ȼ� ����� ����
        baseSize = rectTransform.rect.size;
        baseScale3D = uiParticle.scale3D;

#if UNITY_EDITOR
        if (!Application.isPlaying)
        {
            UnityEditor.EditorUtility.SetDirty(this);
            // ������ ����� ���� Ʈ����
            UnityEditor.SceneManagement.PrefabStage stage = UnityEditor.SceneManagement.PrefabStageUtility.GetCurrentPrefabStage();
            if (stage != null)
            {
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(stage.scene);
            }
        }
#endif
    }

    void OnRectTransformDimensionsChange()
    {
        UpdateScale();
    }

    private void UpdateScale()
    {
        if (rectTransform == null || uiParticle == null || baseSize.x <= 0 || baseSize.y <= 0) return;

        float ratioX = rectTransform.rect.width / baseSize.x;
        float ratioY = rectTransform.rect.height / baseSize.y;

        // 3D ��� ���ο� ������� scale3D�� �ǵ帮�� ���� Ȯ���մϴ�.
        uiParticle.scale3D = new Vector3(
            baseScale3D.x * ratioX,
            baseScale3D.y * ratioY,
            baseScale3D.z * ((ratioX + ratioY) * 0.5f)
        );
    }

#if UNITY_EDITOR
    void Update()
    {
        if (!Application.isPlaying) UpdateScale();
    }
#endif
}