//추가
using System;
using System.Linq;
using System.Reflection;
using Coffee.UIExtensions;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Effect.Coffee.Tests
{
    public sealed class ContractTests
    {
        [Test] public void OriginalGlobalTypeGuidAndFieldsArePreserved()
        {
            Assert.That(typeof(SyncUIParticleScale).FullName, Is.EqualTo("SyncUIParticleScale"));
            Assert.That(typeof(SyncUIParticleScale).GetMethod("CaptureReference", Type.EmptyTypes), Is.Not.Null);
            Assert.That(AssetDatabase.GUIDToAssetPath("e0233d3e1d651b441a7ce3cf59625196"),
                Is.EqualTo("Packages/com.jjevol.effects.coffee/Runtime/SyncUIParticleScale.cs"));
            var fields = typeof(SyncUIParticleScale).GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .Where(f => f.GetCustomAttribute<SerializeField>() != null).OrderBy(f => f.Name).ToArray();
            Assert.That(fields.Select(f => f.Name), Is.EqualTo(new[] { "baseScale3D", "baseSize" }));
            Assert.That(fields[0].FieldType, Is.EqualTo(typeof(Vector3))); Assert.That(fields[1].FieldType, Is.EqualTo(typeof(Vector2)));
        }
        [Test] public void HelperOnlyReferencesActualSdkAndDoesNotRequireEffectsOrNavigation()
        {
            var refs = typeof(SyncUIParticleScale).Assembly.GetReferencedAssemblies().Select(x => x.Name).ToArray();
            Assert.That(refs, Does.Contain("Coffee.UIParticle")); Assert.That(refs, Does.Contain("UniTask"));
            Assert.That(refs, Does.Not.Contain("JJEvol.Effects.Runtime")); Assert.That(refs, Does.Not.Contain("JJEvol.UI.Addressables.Runtime"));
            Assert.That(typeof(jjevol.Effect.EffectHandle).Assembly.GetReferencedAssemblies().Select(x => x.Name), Does.Not.Contain("Coffee.UIParticle"));
        }
        [Test] public void EditorCaptureAndResizePreserveTheOriginalRatioFormula()
        {
            var root = new GameObject("Independent editor Canvas", typeof(Canvas));
            try
            {
                var child = new GameObject("Independent helper", typeof(RectTransform)); child.transform.SetParent(root.transform, false);
                var rect = child.GetComponent<RectTransform>(); rect.sizeDelta = new Vector2(100, 80);
                var ui = child.AddComponent<UIParticle>(); ui.autoScalingMode = UIParticle.AutoScalingMode.None; ui.scale3D = new Vector3(2, 3, 4);
                var helper = child.AddComponent<SyncUIParticleScale>(); helper.CaptureReference();
                rect.sizeDelta = new Vector2(200, 240);
                Assert.That(ui.scale3D.x, Is.EqualTo(4).Within(.001)); Assert.That(ui.scale3D.y, Is.EqualTo(9).Within(.001)); Assert.That(ui.scale3D.z, Is.EqualTo(10).Within(.001));
            }
            finally { UnityEngine.Object.DestroyImmediate(root); }
        }
    }
}
//추가 종료
