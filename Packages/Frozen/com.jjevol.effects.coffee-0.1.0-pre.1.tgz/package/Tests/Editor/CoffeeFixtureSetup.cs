//추가
using System;
using System.IO;
using Coffee.UIExtensions;
using jjevol.Effect.Renderers;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Coffee.Tests
{
    public sealed class CoffeeFixtureSetup : IPrebuildSetup
    {
        public const string Root = "Assets/Step19CoffeeFixtures";
        public void Setup()
        {
            var project = Path.GetFullPath(Path.Combine(Application.dataPath, "..")).Replace('\\', '/');
            if (!project.EndsWith("/.local/coffee-validation/AdapterHost") && !project.EndsWith("/.local/coffee-validation/IntegrationHost"))
                throw new InvalidOperationException("Only new STEP19 Hosts may be authored.");
            if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", Path.GetFileName(Root));
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            if (!settings) settings = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(Root + "/Settings.asset")
                ?? AddressableAssetSettings.Create(Root, "Settings", true, true);
            AddressableAssetSettingsDefaultObject.Settings = settings;
            for (int i = 0; i < settings.DataBuilders.Count; i++)
                if (settings.DataBuilders[i] is BuildScriptFastMode) settings.ActivePlayModeDataBuilderIndex = i;
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:" + AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
            if (File.Exists(Root + "/FixtureVersion.txt") && File.ReadAllText(Root + "/FixtureVersion.txt") == "2") return;
            var texture = AssetDatabase.LoadAssetAtPath<Texture2D>(Root + "/White.asset") ?? new Texture2D(8, 8) { name = "Independent white particle" };
            var pixels = new Color[64]; for (int i = 0; i < pixels.Length; i++) pixels[i] = Color.white;
            texture.SetPixels(pixels); texture.Apply(); if (!AssetDatabase.Contains(texture)) AssetDatabase.CreateAsset(texture, Root + "/White.asset");
            var shader = Shader.Find("UI/Default"); if (!shader) throw new InvalidOperationException("Real uGUI UI/Default shader missing.");
            var material = AssetDatabase.LoadAssetAtPath<Material>(Root + "/Particle.mat") ?? new Material(shader) { mainTexture = texture, name = "Independent UI particle material" };
            if (!AssetDatabase.Contains(material)) AssetDatabase.CreateAsset(material, Root + "/Particle.mat");
            var root = new GameObject("Independent Coffee Effect", typeof(RectTransform)); root.SetActive(false);
            var rect = root.GetComponent<RectTransform>(); rect.sizeDelta = new Vector2(100, 80);
            var ui = root.AddComponent<UIParticle>(); ui.autoScalingMode = UIParticle.AutoScalingMode.None;
            ui.scale3D = new Vector3(2, 3, 4); ui.meshSharing = UIParticle.MeshSharing.None; ui.maskable = true;
            var emitter = new GameObject("Actual emitter", typeof(ParticleSystem)); emitter.transform.SetParent(root.transform, false);
            var ps = emitter.GetComponent<ParticleSystem>(); var main = ps.main;
            main.playOnAwake = false; main.loop = false; main.duration = .2f; main.startLifetime = .15f;
            main.startSpeed = 0; main.startSize = 4; main.startColor = Color.red; main.maxParticles = 32;
            main.simulationSpace = ParticleSystemSimulationSpace.Local; main.scalingMode = ParticleSystemScalingMode.Hierarchy;
            var shape = ps.shape; shape.enabled = false;
            var emission = ps.emission; emission.rateOverTime = 15;
            var pr = ps.GetComponent<ParticleSystemRenderer>(); pr.sharedMaterial = material;
            root.AddComponent<SyncUIParticleScale>().CaptureReference();
            root.AddComponent<ParticleEffectRenderer>(); ui.RefreshParticles();
            // Asset values, not scene or game content; actual SDK renderer receives the material above.
            root.SetActive(true);
            string path = Root + "/Particle.prefab"; PrefabUtility.SaveAsPrefabAsset(root, path); Object.DestroyImmediate(root);
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), settings.DefaultGroup).address = "Step19/Particle";
            File.WriteAllText(Root + "/FixtureVersion.txt", "2");
            EditorUtility.SetDirty(settings); AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
        }
    }
}
//추가 종료
