"""Audit STEP19 evidence and preservation; never installs SDKs or mutates Git.

Workspace-specific: requires the initial .local/step19 baseline and completed
new .local/coffee-validation Hosts. Writes only Docs/CoffeeExtraction evidence.
Run from Framework: python -B Packages/com.jjevol.effects.coffee/Tests/Tools~/verify.py
"""
import hashlib
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
WORK = ROOT / '.local/step19'
RUNS = ROOT / '.local/coffee-validation'
DOC = ROOT / 'Docs/CoffeeExtraction'
PKG = ROOT / 'Packages/com.jjevol.effects.coffee'
MOBILE = Path('C:/Project/jjevol_library_mobile')
SDK = MOBILE / 'Library/PackageCache/com.coffee.ui-particle@c54f63cb18a2'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(root), *args], text=True).strip()


def save(name, obj):
    (DOC / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def scan(paths):
    guids, assemblies = {}, {}
    for root in paths:
        for path in root.rglob('*'):
            if any(part.endswith('~') for part in path.relative_to(root).parts):
                continue
            if path.suffix == '.meta':
                found = re.search(r'^guid: ([a-f0-9]+)', path.read_text(encoding='utf-8-sig', errors='replace'), re.M)
                if found:
                    guids.setdefault(found[1], []).append(str(path))
            elif path.suffix == '.asmdef':
                name = json.loads(path.read_text(encoding='utf-8-sig'))['name']
                assemblies.setdefault(name, []).append(str(path))
    duplicates = lambda obj: {key: value for key, value in obj.items() if len(value) > 1}
    assert not duplicates(guids), duplicates(guids)
    assert not duplicates(assemblies), duplicates(assemblies)
    return dict(sourceRoots=[str(path) for path in paths], guids=len(guids), assemblies=len(assemblies), guidDuplicates={}, assemblyDuplicates={})


def main():
    DOC.mkdir(parents=True, exist_ok=True)
    baseline = json.loads((WORK / 'baseline.json').read_text(encoding='utf-8'))
    moved = 'Packages/com.jjevol.effects/Integrations~/SyncUIParticleScale.cs'
    moved_paths = {moved, moved + '.meta'}
    for name, expected in baseline['tracked'].items():
        if name not in moved_paths:
            assert sha(ROOT / name) == expected, 'Protected tracked file changed: ' + name
    for name, expected in baseline['untracked'].items():
        assert sha(ROOT / name) == expected, 'Protected previous candidate/document changed: ' + name
    assert set(git(ROOT, 'diff', '--name-only').splitlines()) == set(baseline['missing']) | moved_paths
    assert not (ROOT / moved).exists() and not (ROOT / (moved + '.meta')).exists()
    assert git(ROOT, 'rev-parse', 'HEAD') == baseline['head']
    assert git(ROOT, 'branch', '--show-current') == baseline['branch']
    assert not git(ROOT, 'diff', '--cached', '--name-only')
    assert git(MOBILE, 'rev-parse', 'HEAD') == baseline['mobileHead']
    assert git(MOBILE, 'status', '--short') == baseline['mobileStatus']

    original = WORK / 'SyncUIParticleScale.before.cs'
    source = PKG / 'Runtime/SyncUIParticleScale.cs'
    addition = '\r\n        //추가\r\n        if (!this) return;\r\n        //추가 종료\r\n'.encode('cp949')
    anchor = b'        await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);\r\n'
    assert source.read_bytes() == original.read_bytes().replace(anchor, anchor + addition)
    assert sha(PKG / 'Runtime/SyncUIParticleScale.cs.meta') == sha(WORK / 'SyncUIParticleScale.before.cs.meta')
    assert original.read_bytes() == (MOBILE / 'Assets/Common/Script/Effects/SyncUIParticleScale.cs').read_bytes()
    assert source.read_bytes().decode('cp949').encode('cp949') == source.read_bytes()
    sdk_original = json.loads((WORK / 'sdk-baseline.json').read_text(encoding='utf-8'))
    for name, expected in sdk_original.items():
        assert sha(SDK / name) == expected, 'Original SDK changed: ' + name
    old_mobile = json.loads((ROOT / '.local/step14/mobile-baseline.json').read_text(encoding='utf-8'))
    for name, expected in old_mobile['files'].items():
        assert sha(Path(name)) == expected, 'Previously fingerprinted mobile file changed: ' + name

    sdk_copies, hosts = {}, {}
    for host_name in ('CoreHost', 'AdapterHost', 'IntegrationHost'):
        host = RUNS / host_name
        manifest = json.loads((host / 'Packages/manifest.json').read_text(encoding='utf-8'))
        lock = json.loads((host / 'Packages/packages-lock.json').read_text(encoding='utf-8'))
        assert not any('spine' in name for name in manifest['dependencies'])
        assert not any('spine' in name for name in lock['dependencies'])
        if host_name != 'CoreHost':
            copy = host / 'Packages/LocalSDK/com.coffee.ui-particle'
            files = {}
            for name, expected in sdk_original.items():
                if (copy / name).is_file():
                    assert sha(copy / name) == expected, 'Host SDK copy modified: ' + host_name + '/' + name
                    files[name] = expected
            for folder in ('Runtime', 'Shaders'):
                assert set(path.relative_to(copy).as_posix() for path in (copy / folder).rglob('*') if path.is_file()) == {name for name in sdk_original if name.startswith(folder + '/')}
            assert (copy / 'LICENSE.md').read_bytes() == (SDK / 'LICENSE.md').read_bytes()
            sdk_copies[host_name] = files
            assert manifest['dependencies']['com.jjevol.effects.coffee'].startswith('file:')
        else:
            assert 'com.coffee.ui-particle' not in manifest['dependencies'] and 'com.jjevol.effects.coffee' not in manifest['dependencies']
            log = (host / 'core-compile.log').read_text(encoding='utf-8', errors='replace')
            assert 'Application will terminate with return code 0' in log and not re.search(r'error CS\d+', log)
        # Registered source packages from the fresh Host cache, selected local packages,
        # real Coffee/DOTween sources and the copied test harness. Never scan old Hosts.
        roots = [host / 'Assets']
        cache = host / 'Library/PackageCache'
        for package in cache.iterdir():
            info = package / 'package.json'
            if not info.is_file():
                continue
            name = json.loads(info.read_text(encoding='utf-8-sig'))['name']
            if name.startswith(('com.jjevol.', 'com.artress.')):
                roots.append(package)
        for name, version in manifest['dependencies'].items():
            if version.startswith('file:') and not version.endswith('.tgz'):
                resolved = (host / 'Packages' / version[5:]).resolve()
                if resolved.is_dir():
                    roots.append(resolved)
        roots = list(dict.fromkeys(roots))
        hosts[host_name] = scan(roots)

    dotween_target = RUNS / 'IntegrationHost/Assets/Plugins/Demigiant'
    dotween_source = MOBILE / 'Assets/Plugins/Demigiant'
    dotween_files, generated_dotween_folder_metas = {}, {}
    for path in dotween_target.rglob('*'):
        if path.is_file():
            relative = path.relative_to(dotween_target).as_posix()
            if relative in ('DOTween.meta', 'DOTweenPro.meta'):
                # copytree copied each Runtime folder, not its parent folder meta.
                # Unity generated these two Host-only folder identities. All
                # SDK C#/DLL/license and their original script metas remain strict.
                generated_dotween_folder_metas[relative] = sha(path)
                continue
            assert sha(path) == sha(dotween_source / relative), 'DOTween SDK was modified: ' + relative
            dotween_files[relative] = sha(path)
    sdk_meta = json.loads((SDK / 'package.json').read_text(encoding='utf-8'))
    assert sdk_meta['version'] == '4.11.3' and sdk_meta['license'] == 'MIT'
    assert not list(PKG.rglob('*.dll'))
    source_text = source.read_bytes().decode('cp949')
    assert re.findall(r'public void (\w+)\(', source_text) == ['CaptureReference']
    assert re.findall(r'\[SerializeField\] private (\w+) (\w+);', source_text) == [('Vector2', 'baseSize'), ('Vector3', 'baseScale3D')]
    package = json.loads((PKG / 'package.json').read_text(encoding='utf-8'))
    assert set(package['dependencies']) == {'com.coffee.ui-particle', 'com.cysharp.unitask', 'com.unity.ugui'}

    # Include preserved integrations in the repository-wide duplicate GUID audit.
    all_guids, all_assemblies = {}, {}
    for path in (ROOT / 'Packages').rglob('*.meta'):
        found = re.search(r'^guid: ([a-f0-9]+)', path.read_text(encoding='utf-8-sig', errors='replace'), re.M)
        if found:
            all_guids.setdefault(found[1], []).append(str(path))
    for path in (ROOT / 'Packages').rglob('*.asmdef'):
        if not any(part.endswith('~') for part in path.parts):
            all_assemblies.setdefault(json.loads(path.read_text(encoding='utf-8-sig'))['name'], []).append(str(path))
    assert all(len(paths) == 1 for paths in all_guids.values())
    assert all(len(paths) == 1 for paths in all_assemblies.values())
    for path in [PKG] + list(PKG.rglob('*')):
        assert path.suffix == '.meta' or Path(str(path) + '.meta').exists(), 'Missing meta: ' + str(path)
    seal = ROOT / 'Snapshots/20261031-step12-local-candidate-1/SHA256SUMS.json'
    assert sha(seal) == 'c39f92b858e5dc7c72741d444fa87f5fb1135ad940e2d4ca344fb41f06890fc4'
    checked = subprocess.run(['C:/Users/PC/AppData/Local/Programs/Python/Python313/python.exe', '-B', str(seal.parent / 'Installer/verify_candidate.py'), str(seal.parent)], capture_output=True, text=True, check=True)
    snapshot = json.loads(checked.stdout)

    final_cases, results = {}, []
    final_runs = {'final-contracts': 3, 'after-native': 14, 'coexist-selected': 12}
    for file in sorted(RUNS.glob('*.xml')):
        result = ET.parse(file).getroot()
        row = dict(name=file.stem, total=int(result.attrib['total']), passed=int(result.attrib['passed']), failed=int(result.attrib['failed']), skipped=int(result.attrib['skipped']), result=result.attrib['result'], sha256=sha(file), final=file.stem in final_runs)
        if row['final']:
            assert row['total'] == final_runs[file.stem] and row['failed'] == 0 and row['skipped'] == 0
            for case in result.iter('test-case'):
                assert case.attrib['result'] == 'Passed'
                final_cases[case.attrib['fullname']] = dict(result='Passed', sourceRun=file.stem)
        row['failures'] = [dict(name=case.attrib['fullname'], message=case.findtext('failure/message')) for case in result.iter('test-case') if case.attrib.get('result') == 'Failed']
        row['outputs'] = {case.attrib['fullname']: case.findtext('output') for case in result.iter('test-case') if case.findtext('output')}
        results.append(row)
    assert len(final_cases) == 29
    failed = ET.parse(RUNS / 'before-deferred-start.xml').getroot()
    assert int(failed.attrib['failed']) == 1
    before_case = next(failed.iter('test-case'))
    assert before_case.attrib['fullname'] in final_cases
    assert 'But was:  2.0f' in before_case.findtext('failure/message')
    old_scene = ROOT / 'Packages/com.jjevol.ui.urp/Tests/ScenePopup~/Runtime/Step16IntegrationTests.cs'
    new_scene = PKG / 'Tests/Coexist~/Runtime/Step16IntegrationTests.cs'
    def scene_body(path):
        text = path.read_text(encoding='utf-8')
        start = text.index('        [UnityTest]public IEnumerator ActualSceneSwitchRebindsStep15AndStopsOldPopupAndSceneEffect()')
        return text[start:text.index('\n        }', start) + len('\n        }')]
    assert scene_body(old_scene) == scene_body(new_scene)

    evidence = DOC / 'Validation'
    evidence.mkdir(exist_ok=True)
    for file in list(RUNS.glob('*.xml')) + list(RUNS.glob('*.log')):
        shutil.copyfile(file, evidence / file.name)
    shutil.copyfile(RUNS / 'CoreHost/core-compile.log', evidence / 'core-compile.log')
    for host_name in hosts:
        target = evidence / host_name
        target.mkdir(exist_ok=True)
        for name in ('manifest.json', 'packages-lock.json'):
            shutil.copyfile(RUNS / host_name / 'Packages' / name, target / name)
    images = {}
    for host_name in ('AdapterHost', 'IntegrationHost'):
        for file in (RUNS / host_name / 'Artifacts').glob('*.png'):
            shutil.copyfile(file, evidence / file.name)
            images[file.name] = sha(file)
    save('Preservation.json', dict(head=baseline['head'], branch=baseline['branch'], indexEmpty=True,
         protectedTracked=len(baseline['tracked']) - 2, protectedPriorUntracked=len(baseline['untracked']),
         previousMissingPreserved=baseline['missing'], approvedMovedPaths=sorted(moved_paths),
         mobileHead=baseline['mobileHead'], mobileStatus=baseline['mobileStatus'], mobileBaselineAt=baseline['at'],
         mobileGitUnchangedFromStep19Start=True, mobileCommonFilesVerified=len(old_mobile['files']),
         sdkOriginalFilesVerified=len(sdk_original), originalScriptGuid='e0233d3e1d651b441a7ce3cf59625196',
         originalMetaUnchanged=True, originalSourceSha256=sha(original), sourceSha256=sha(source),
         onlyProductionChange='Destroyed-object guard after the existing Start yield', encoding='CP949/CRLF',
         repositoryGuidCount=len(all_guids), activeAssemblyCount=len(all_assemblies), guidDuplicates=0, assemblyDuplicates=0,
         hostAudits=hosts, snapshotSealSha256=sha(seal), snapshot=snapshot,
         step17BootstrapSha256=sha(ROOT / 'Packages/com.jjevol.ui.urp/Runtime/UIManagerCreater.cs'),
         originalSceneFailureAssertionPreserved=True, spineCandidateAndBlockedDocumentsUnchanged=True))
    save('SDKInspection.json', dict(name=sdk_meta['name'], version=sdk_meta['version'], license=sdk_meta['license'],
         source=str(SDK), fingerprint=sdk_meta['_fingerprint'], commit='c54f63cb18a22382215b142b63e232f0f86fff58',
         sdkAssembly=json.loads((SDK / 'Runtime/Coffee.UIParticle.asmdef').read_text(encoding='utf-8-sig')),
         licenseSha256=sha(SDK / 'LICENSE.md'), sdkCopies=sdk_copies, sdkIncludedInFrameworkUPM=False,
         propertyInjectorRequired=False, sdkUpdated=False, downloaded=False, dotweenFiles=dotween_files,
         generatedDotweenHostFolderMetas=generated_dotween_folder_metas))
    save('ValidationEvidence.json', dict(unity='6000.3.9f1', addressables='4.0.1', ugui='2.0.0', urp='17.3.0',
         uniTask='2.5.10', uniTaskCommit='f213ff497e4ff462a77319cf677cf20cc0860ca9',
         coreWithoutAdapterCompile='PASS', finalTests=29, finalPassed=29, finalFailed=0, finalSkipped=0,
         editMode=3, adapterPlayMode=14, coexistPlayMode=12, cases=final_cases, runs=results,
         reproducedProductionDefects=1, fixtureFailuresAreNotProductionDefects=True,
         rendering=dict(builtIn=dict(fullRedPixels=1600, maskedRedPixels=144), urp=dict(fullRedPixels=1600, maskedRedPixels=144), imageHashes=images),
         sdkNativeExecution=True, player='NOT_RUN', device='NOT_RUN', productAssets='NOT_RUN', remoteContent='NOT_RUN',
         longTermMemoryProfiling='NOT_RUN', allSdkMeshSharingModes='NOT_RUN', spine='BLOCKED unchanged'))
    save('PackageFiles.json', dict(package=package, files={path.relative_to(ROOT).as_posix(): sha(path) for path in [Path(str(PKG) + '.meta')] + sorted(PKG.rglob('*')) if path.is_file()}))
    print(json.dumps(dict(finalTests=29, passed=29, failed=0, protectedTracked=len(baseline['tracked']) - 2,
                         protectedPriorUntracked=len(baseline['untracked']), sdkFiles=len(sdk_original),
                         hostGuidAndAssemblyDuplicates=0, mobileGitUnchanged=True, snapshot=snapshot)))


if __name__ == '__main__':
    main()
