//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using jjevol.Audio;
using jjevol.Effect;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;
namespace jjevol.DOTweenIntegration.Tests
{
    [PrebuildSetup("jjevol.Step19.Coffee.Coexist.AllFixtureSetup")]
    public sealed class IntegrationTests
    {
        readonly List<GameObject> _objects=new();readonly List<AsyncOperationHandle<SceneInstance>> _scenes=new();UIManagerCreater _creator;Camera _base;AddressablesManager _resources;Instances _instances;EffectManager _effects;Prefabs _prefabs;
        sealed class Instances:IInstanceProvider
        {
            public readonly IInstanceProvider Inner;public int Created,Returned,UiRoots;
            public Instances(IInstanceProvider p)=>Inner=p;
            public GameObject ProvideInstance(ResourceManager rm,AsyncOperationHandle<GameObject> h,InstantiationParameters p){var go=Inner.ProvideInstance(rm,h,p);Created++;if(go.GetComponent<UIManager>())UiRoots++;return go;}
            public void ReleaseInstance(ResourceManager rm,GameObject go){Returned++;Inner.ReleaseInstance(rm,go);}
        }
        sealed class Prefabs:IEffectPrefabProvider
        {
            readonly AddressablesEffectPrefabProvider _sdk=new();public int Loads,Returns;
            public async UniTask<EffectPrefabLease> LoadAsync(string key,CancellationToken token){var lease=await _sdk.LoadAsync(key,token);if(lease==null)return null;Loads++;return new EffectPrefabLease(lease.Prefab,()=>{Returns++;lease.Dispose();});}
        }
        static IEnumerator Done(Task task){float end=Time.realtimeSinceStartup+15;while(!task.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;Assert.That(task.IsCompleted,Is.True);if(task.IsFaulted)throw task.Exception.GetBaseException();Assert.That(task.IsCanceled,Is.False);}
        static IEnumerator Until(Func<bool> p){float end=Time.realtimeSinceStartup+8;while(!p()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(p(),Is.True);}
        GameObject New(string name,params Type[] types){var go=new GameObject(name,types);_objects.Add(go);return go;}
        static void Provider(IInstanceProvider p){var impl=typeof(Addressables).GetProperty("s_Addressables",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);impl.GetType().GetProperty("InstanceProvider").SetValue(impl,p);}
        [UnitySetUp]public IEnumerator Setup()
        {
            Time.timeScale=1;UIManager.applicationIsQuitting=false;AddressablesManager.applicationIsQuitting=false;AudioManager.applicationIsQuitting=false;EffectManager.applicationIsQuitting=false;
            DOTween.Init(false,true,LogBehaviour.ErrorsOnly);var init=Addressables.InitializeAsync(false);yield return Done(init.Task);Addressables.Release(init);_instances=new Instances(Addressables.InstanceProvider);Provider(_instances);_resources=AddressablesManager.Instance;
            _base=New("Base Camera",typeof(Camera),typeof(UniversalAdditionalCameraData)).GetComponent<Camera>();_base.tag="MainCamera";
            _creator=New("STEP15 bootstrap").AddComponent<UIManagerCreater>();Object.DontDestroyOnLoad(_creator.gameObject);_creator.mainCamera=_base;_creator.cashScreenTypes=new List<string>{"IntroScreen"};_creator.cashHudTypes=new List<string>();
            _effects=New("effect manager").AddComponent<EffectManager>();_prefabs=new Prefabs();_effects.SetPrefabProvider(_prefabs);yield return Done(_creator.StartInitAsync().AsTask());yield return Done(UIManager.Instance.screenManager.ChangeUIScreenAsync("IntroScreen").AsTask());
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {
            Time.timeScale=1;foreach(var o in _objects)if(o)Object.Destroy(o);_objects.Clear();yield return null;yield return null;yield return Until(()=>_prefabs.Returns==_prefabs.Loads);
            foreach(var h in _scenes)if(h.IsValid()&&h.Result.Scene.isLoaded)yield return Addressables.UnloadSceneAsync(h);_scenes.Clear();Provider(_instances.Inner);if(_resources)Object.Destroy(_resources.gameObject);yield return null;yield return null;
            int active=DOTween.TotalActiveTweens();DOTween.KillAll(false);Assert.That(active,Is.Zero);Assert.That(_instances.Returned,Is.EqualTo(_instances.Created),"Bootstrap root and existing UI child SDK handles have separate balanced owners");
        }
        //추가
        [UnityTest]public IEnumerator CoffeeToastIconAndDotweenShareCanvasThenReturnTheirOwnPrefabAndImageLeases()
        {
            var scene=SceneManager.CreateScene("STEP19 independent mixed Effects scene");
            try
            {
                var canvas=New("Scene Coffee Canvas",typeof(RectTransform),typeof(Canvas)).GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceCamera;canvas.worldCamera=UIManager.Instance.UICamera;canvas.planeDistance=5;SceneManager.MoveGameObjectToScene(canvas.gameObject,scene);
                var coffee=_effects.PlayAsync(new EffectRequest("Step19/Particle",loop:true,parent:canvas.transform)).AsTask();yield return Done(coffee);
                var ui=coffee.Result.Renderer.Root.GetComponent<Coffee.UIExtensions.UIParticle>();((RectTransform)ui.transform).sizeDelta=new Vector2(200,160);
                var tween=_effects.PlayAsync(new EffectRequest("Step16/Effect",loop:true,parent:canvas.transform)).AsTask();yield return Done(tween);
                var toast=_effects.PlayAsync(new EffectRequest("Step14/Toast",loop:true,parent:canvas.transform)).AsTask();yield return Done(toast);
                ((jjevol.Effect.Renderers.ToastMessageEffectRenderer)toast.Result.Renderer).SetData("icon_red","Coffee coexistence");
                var icon=_effects.PlayAsync(new EffectRequest("Step14/Icon",loop:true,parent:canvas.transform,icon:"icon_blue")).AsTask();yield return Done(icon);
                yield return Until(()=>ui.GetComponentsInChildren<UnityEngine.UI.MaskableGraphic>().Any(g=>g.GetType().Name=="UIParticleRenderer"&&g.canvasRenderer.GetMesh()&&g.canvasRenderer.GetMesh().vertexCount>0));
                Assert.That(ui.scale3D.x,Is.EqualTo(4).Within(.001));Assert.That(ui.scale3D.y,Is.EqualTo(6).Within(.001));Assert.That(DOTween.TotalActiveTweens(),Is.GreaterThan(0));
                yield return Until(()=>icon.Result.GetComponentInChildren<AddressableImage>().sprite!=null);
                Assert.That(_resources.GetRefCount("Step14/Atlas"),Is.GreaterThan(0));
                yield return SceneManager.UnloadSceneAsync(scene);yield return Until(()=>_prefabs.Returns==4);
                Assert.That(coffee.Result==null&&tween.Result==null&&toast.Result==null&&icon.Result==null,Is.True);
                Assert.That(DOTween.TotalActiveTweens(),Is.Zero);Assert.That(_resources.GetRefCount("Step14/Atlas"),Is.Zero);Assert.That(UIManager.Instance,Is.Not.Null);
            }
            finally{if(scene.IsValid()&&scene.isLoaded)SceneManager.UnloadSceneAsync(scene);}
        }
        //추가 종료
        [UnityTest]public IEnumerator ActualUrpPopupEffectAudioAndGeneralResourceOwnersCoexist()
        {
            var ui=UIManager.Instance;Assert.That(_base.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==ui.UICamera),Is.EqualTo(1));var popup=ui.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);Assert.That(popup.Result.GetComponent<UITransition>(),Is.Not.Null);
            var effect=_effects.PlayAsync(new EffectRequest("Step16/Effect",loop:true,parent:ui.EffectRoot)).AsTask();yield return Done(effect);
            using var clips=new AddressablesClipProvider();var audio=New("audio").AddComponent<AudioManager>();audio.SetProvider(clips);if(!Object.FindAnyObjectByType<AudioListener>())New("listener",typeof(AudioListener));var general=AddressableScope.Get<AudioClip>("Step16/Audio").AsTask();yield return Done(general);
            try
            {
                var sound=audio.PlayAsync("Step16/Audio",loop:true,debounce:0);yield return Done(sound);Assert.That(sound.Result.isPlaying,Is.True);yield return Until(()=>!popup.Result.IsTransitioning);Assert.That(popup.Result.GetComponent<CanvasGroup>().alpha,Is.EqualTo(1).Within(.01f));
                Assert.That(_resources.TryGetLoadedAsset<AudioClip>("Step16/Audio",out var peek),Is.True);Assert.That(_resources.GetRefCount("Step16/Audio"),Is.EqualTo(1));Assert.That(_resources.GetAsset<AudioClip>("Step16/Audio"),Is.SameAs(peek));Assert.That(_resources.GetRefCount("Step16/Audio"),Is.EqualTo(2));AddressablesManager.ReleaseAsset("Step16/Audio");
                _creator.Shutdown();yield return null;yield return null;yield return Until(()=>_prefabs.Returns==_prefabs.Loads);Assert.That(effect.Result==null,Is.True);Assert.That(sound.Result.isPlaying,Is.True);Assert.That(clips.ActiveLeaseCount,Is.EqualTo(1));audio.StopAll();Assert.That(clips.ActiveLeaseCount,Is.Zero);Assert.That(general.Result.Asset,Is.Not.Null);
                yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_instances.UiRoots,Is.EqualTo(2));Assert.That(_creator.IsInitialized,Is.True);
            }
            finally{audio.StopAll();general.Result.Dispose();}
            Assert.That(_resources.GetRefCount("Step16/Audio"),Is.Zero);
        }
        [UnityTest]public IEnumerator ActualSceneSwitchRebindsStep15AndStopsOldPopupAndSceneEffect()
        {
            var ui=UIManager.Instance;var popup=ui.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);int oldShow=0;popup.Result.GetComponent<UITransition>().onShowComplete.AddListener(()=>oldShow++);
            var load=_resources.LoadSceneAsync("Step16/Scene",LoadSceneMode.Additive);_scenes.Add(load);yield return Done(load.Task);var next=load.Result.Scene.GetRootGameObjects().SelectMany(g=>g.GetComponentsInChildren<Camera>()).Single();_creator.mainCamera=next;SceneManager.SetActiveScene(load.Result.Scene);yield return Done(_creator.StartInitAsync().AsTask());
            Assert.That(UIManager.Instance,Is.SameAs(ui));Assert.That(_instances.UiRoots,Is.EqualTo(1));Assert.That(oldShow,Is.Zero);Assert.That(next.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==ui.UICamera),Is.EqualTo(1));Assert.That(_base.GetUniversalAdditionalCameraData().cameraStack.Contains(ui.UICamera),Is.False);
            var parent=New("scene effect parent");SceneManager.MoveGameObjectToScene(parent,load.Result.Scene);var effect=_effects.PlayAsync(new EffectRequest("Step16/Effect",loop:true,parent:parent.transform)).AsTask();yield return Done(effect);
            _creator.mainCamera=_base;SceneManager.SetActiveScene(_base.gameObject.scene);yield return Done(_creator.StartInitAsync().AsTask());var unload=_resources.UnloadSceneAsync(load.Result);yield return Done(unload.Task);yield return Until(()=>_prefabs.Returns==1);Assert.That(effect.Result==null,Is.True);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        [UnityTest]public IEnumerator CreatorDisableDuringTransitionReturnsAllUiAndStopsNativeTween()
        {
            var popup=UIManager.Instance.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);int complete=0;popup.Result.GetComponent<UITransition>().onShowComplete.AddListener(()=>complete++);_creator.enabled=false;yield return new WaitForSecondsRealtime(.45f);
            Assert.That(complete,Is.Zero);Assert.That(_instances.Created,Is.EqualTo(_instances.Returned));Assert.That(DOTween.TotalActiveTweens(),Is.Zero);_creator.enabled=true;yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.IsInitialized,Is.True);
        }
        [UnityTest]public IEnumerator ExplicitGameClosePolicyRebindsSceneAndReturnsAllNativeOwners()
        {
            var load=_resources.LoadSceneAsync("Step16/Scene",LoadSceneMode.Additive);_scenes.Add(load);yield return Done(load.Task);
            var ui=UIManager.Instance;var popup=ui.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);Assert.That(popup.Result.IsTransitioning,Is.True);int old=0;popup.Result.GetComponent<UITransition>().onShowComplete.AddListener(()=>old++);
            // Consumer-owned Scene policy through the existing API; no protected Bootstrap/Core edit.
            ui.popupManager.ForceCloseAllPopups();var next=load.Result.Scene.GetRootGameObjects().SelectMany(g=>g.GetComponentsInChildren<Camera>()).Single();_creator.mainCamera=next;SceneManager.SetActiveScene(load.Result.Scene);yield return Done(_creator.StartInitAsync().AsTask());
            Assert.That(old,Is.Zero);Assert.That(ui.popupManager.ActivePopups.Count,Is.Zero);Assert.That(_instances.UiRoots,Is.EqualTo(1));Assert.That(next.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==ui.UICamera),Is.EqualTo(1));
            var parent=New("scene effect parent");SceneManager.MoveGameObjectToScene(parent,load.Result.Scene);var effect=_effects.PlayAsync(new EffectRequest("Step16/Effect",loop:true,parent:parent.transform)).AsTask();yield return Done(effect);
            _creator.mainCamera=_base;SceneManager.SetActiveScene(_base.gameObject.scene);yield return Done(_creator.StartInitAsync().AsTask());var unload=_resources.UnloadSceneAsync(load.Result);yield return Done(unload.Task);yield return Until(()=>_prefabs.Returns==1);Assert.That(effect.Result==null,Is.True);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        [UnityTest]public IEnumerator UiManagerDisableStopsPopupAndCanReinitializeTheSameOwnedRoot()
        {
            var ui=UIManager.Instance;var popup=ui.SpawnUIPopupAsync("YesNoPopup").AsTask();yield return Done(popup);int completed=0;popup.Result.GetComponent<UITransition>().onShowComplete.AddListener(()=>completed++);ui.gameObject.SetActive(false);yield return new WaitForSecondsRealtime(.4f);
            Assert.That(completed,Is.Zero);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);Assert.That(_instances.Created-_instances.Returned,Is.EqualTo(1),"Disabled owned UI root is retained; its child SDK instances are returned");
            ui.gameObject.SetActive(true);yield return Done(_creator.StartInitAsync().AsTask());Assert.That(UIManager.Instance,Is.SameAs(ui));Assert.That(_instances.UiRoots,Is.EqualTo(1));Assert.That(_creator.IsInitialized,Is.True);
        }
    }
}
//추가 종료
