//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.ScenePopup.Tests
{
    [PrebuildSetup("jjevol.Step19.Coffee.Coexist.AllFixtureSetup")]
    public sealed class ScenePopupTests
    {
        readonly List<GameObject> _objects=new();readonly List<Scene> _scenes=new();readonly List<AsyncOperationHandle<GameObject>> _external=new();
        readonly List<AsyncOperationHandle> _assets=new();readonly List<PrefabGate> _prefabGates=new();readonly List<IResourceLocator> _locators=new();
        UIManagerCreater _creator;UIManager _ui;Camera _base;AddressablesManager _resources;Instances _instances;
        sealed class Instances:IInstanceProvider
        {
            public readonly IInstanceProvider Inner;public int Created,Returned,PopupCreated,PopupReturned,Roots;readonly Dictionary<GameObject,bool> _live=new();
            public Instances(IInstanceProvider inner)=>Inner=inner;
            public GameObject ProvideInstance(ResourceManager rm,AsyncOperationHandle<GameObject> h,InstantiationParameters p){var go=Inner.ProvideInstance(rm,h,p);bool popup=go.GetComponent<UIPopup>();_live.Add(go,popup);Created++;if(popup)PopupCreated++;if(go.GetComponent<UIManager>())Roots++;return go;}
            public void ReleaseInstance(ResourceManager rm,GameObject go){Assert.That(_live.Remove(go,out bool popup),Is.True,"SDK instance may return exactly once");Returned++;if(popup)PopupReturned++;Inner.ReleaseInstance(rm,go);}
        }
        sealed class PrefabGate:ResourceProviderBase
        {
            readonly GameObject _prefab;readonly string _id="Step17-"+Guid.NewGuid().ToString("N");public override string ProviderId=>_id;
            public readonly List<ProvideHandle> Pending=new();public int Loads,Returns;
            public PrefabGate(GameObject prefab)=>_prefab=prefab;
            public override void Provide(ProvideHandle h){Loads++;Pending.Add(h);}
            public void Open(){var pending=Pending.ToArray();Pending.Clear();foreach(var h in pending)h.Complete(_prefab,true,null);}
            public override void Release(IResourceLocation location,object asset)=>Returns++;
        }
        static IEnumerator Done(Task t){float end=Time.realtimeSinceStartup+15;while(!t.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;Assert.That(t.IsCompleted,Is.True);if(t.IsFaulted)throw t.Exception.GetBaseException();Assert.That(t.IsCanceled,Is.False);}
        static IEnumerator Until(Func<bool> p){float end=Time.realtimeSinceStartup+10;while(!p()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(p(),Is.True);}
        static void Provider(IInstanceProvider p){var impl=typeof(Addressables).GetProperty("s_Addressables",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);impl.GetType().GetProperty("InstanceProvider").SetValue(impl,p);}
        static void Invoke(UIManagerCreater c,string method,params object[] args)=>typeof(UIManagerCreater).GetMethod(method,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(c,args);
        GameObject New(string name,params Type[] types){var go=new GameObject(name,types);_objects.Add(go);return go;}
        Camera Camera(string name){var c=New(name,typeof(Camera),typeof(UniversalAdditionalCameraData)).GetComponent<Camera>();c.tag="MainCamera";return c;}
        (Scene scene,Camera camera) Next(){var scene=SceneManager.CreateScene("STEP17_"+Guid.NewGuid().ToString("N"));_scenes.Add(scene);var camera=Camera("next Base");SceneManager.MoveGameObjectToScene(camera.gameObject,scene);return(scene,camera);}
        Task<UIPopup> Popup()=>_ui.SpawnUIPopupAsync("YesNoPopup",checkSamePopup:false).AsTask();
        // Initialization has no Screen step any more, so a cached Screen's load is what holds it open.
        IEnumerator HoldCaching(string id,Action<PrefabGate> received)
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIScreen_IntroScreen");_assets.Add(prefab);yield return Done(prefab.Task);var gate=new PrefabGate(prefab.Result);_prefabGates.Add(gate);Addressables.ResourceManager.ResourceProviders.Add(gate);
            string key=UIAddress.Screen(id);var locator=new ResourceLocationMap(gate.ProviderId);locator.Add(key,new ResourceLocationBase(key,key,gate.ProviderId,typeof(GameObject)));Addressables.AddResourceLocator(locator);_locators.Add(locator);
            _creator.cashScreenTypes=new List<string>{"IntroScreen",id};received(gate);
        }
        [UnitySetUp]public IEnumerator Setup()
        {
            Time.timeScale=1;UIManager.applicationIsQuitting=false;AddressablesManager.applicationIsQuitting=false;DOTween.Init(false,true,LogBehaviour.ErrorsOnly);var init=Addressables.InitializeAsync(false);yield return Done(init.Task);Addressables.Release(init);_instances=new Instances(Addressables.InstanceProvider);Provider(_instances);_resources=AddressablesManager.Instance;
            _base=Camera("original Base");_creator=New("Scene bootstrap").AddComponent<UIManagerCreater>();Object.DontDestroyOnLoad(_creator.gameObject);_creator.mainCamera=_base;_creator.cashScreenTypes=new List<string>{"IntroScreen"};_creator.cashHudTypes=new List<string>();yield return Done(_creator.StartInitAsync().AsTask());_ui=UIManager.Instance;yield return Done(_ui.screenManager.ChangeUIScreenAsync("IntroScreen").AsTask());
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {
            Time.timeScale=1;foreach(var gate in _prefabGates)gate.Open();
            foreach(var go in _objects)if(go)Object.Destroy(go);_objects.Clear();yield return null;yield return null;yield return null;
            foreach(var h in _external)if(h.IsValid())Addressables.ReleaseInstance(h);_external.Clear();yield return null;yield return null;
            foreach(var gate in _prefabGates){yield return Until(()=>gate.Loads==gate.Returns);Addressables.ResourceManager.ResourceProviders.Remove(gate);}_prefabGates.Clear();foreach(var locator in _locators)Addressables.RemoveResourceLocator(locator);_locators.Clear();foreach(var h in _assets)if(h.IsValid())Addressables.Release(h);_assets.Clear();
            foreach(var s in _scenes)if(s.IsValid()&&s.isLoaded)yield return SceneManager.UnloadSceneAsync(s);_scenes.Clear();Provider(_instances.Inner);if(_resources)Object.Destroy(_resources.gameObject);yield return null;
            int tweens=DOTween.TotalActiveTweens();DOTween.KillAll(false);Assert.That(tweens,Is.Zero);Assert.That(_instances.Returned,Is.EqualTo(_instances.Created));
        }
        [UnityTest]public IEnumerator SameSceneCallsKeepTransitioningPopupAndItsWaiter()
        {
            var p=Popup();yield return Done(p);var wait=p.Result.CloseWait().AsTask();yield return Done(_creator.StartInitAsync().AsTask());yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_ui.popupManager.ActivePopups.Contains(p.Result),Is.True);Assert.That(wait.IsCompleted,Is.False);Assert.That(_instances.PopupReturned,Is.Zero);
        }
        [UnityTest]public IEnumerator SameSceneCallsKeepCompletedPopup()
        {
            var p=Popup();yield return Done(p);yield return Until(()=>!p.Result.IsTransitioning);yield return Done(_creator.StartInitAsync().AsTask());Assert.That(p.Result.IsOpen,Is.True);Assert.That(_instances.PopupReturned,Is.Zero);
        }
        [UnityTest]public IEnumerator SceneBoundaryClosesMixedPopupsAndCompletesBothWaitersFalse()
        {
            var normal=Popup();yield return Done(normal);yield return Until(()=>!normal.Result.IsTransitioning);var active=Popup();yield return Done(active);Assert.That(active.Result.IsTransitioning,Is.True);
            var wait1=normal.Result.CloseWait().AsTask();var wait2=active.Result.CloseWait().AsTask();var screen=_ui.screenManager.CurrentScreen;var screens=_ui.screenManager;var hud=_ui.hudManager;var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);yield return Done(_creator.StartInitAsync().AsTask());yield return Done(Task.WhenAll(wait1,wait2));yield return null;yield return null;
            Assert.That(wait1.Result||wait2.Result,Is.False);Assert.That(_ui.popupManager.ActivePopups.Count,Is.Zero);Assert.That(_instances.PopupReturned,Is.EqualTo(2));Assert.That(DOTween.TotalActiveTweens(),Is.Zero);Assert.That(UIManager.Instance,Is.SameAs(_ui));Assert.That(_ui.screenManager,Is.SameAs(screens));Assert.That(_ui.hudManager,Is.SameAs(hud));Assert.That(_ui.screenManager.CurrentScreen,Is.SameAs(screen));Assert.That(_instances.Roots,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator DuplicateAndStaleSceneCallbacksDoNotCloseANewScenePopup()
        {
            var oldScene=SceneManager.GetActiveScene();var old=Popup();yield return Done(old);var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);yield return Done(_creator.StartInitAsync().AsTask());var current=Popup();yield return Done(current);
            Invoke(_creator,"_OnSceneLoaded",next.scene,LoadSceneMode.Single);Invoke(_creator,"OnActiveSceneChanged",oldScene,next.scene);Invoke(_creator,"_OnSceneLoaded",oldScene,LoadSceneMode.Single);Invoke(_creator,"OnActiveSceneChanged",next.scene,oldScene);yield return Done(_creator.StartInitAsync().AsTask());yield return null;
            Assert.That(current.Result.IsOpen,Is.True);Assert.That(_ui.popupManager.ActivePopups.Contains(current.Result),Is.True);Assert.That(_instances.PopupReturned,Is.EqualTo(1));Assert.That(next.camera.GetUniversalAdditionalCameraData().cameraStack.Count(c=>c==_ui.UICamera),Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator NewPopupOpenedDuringSceneInitializationSurvivesItsLateCompletion()
        {
            var old=Popup();yield return Done(old);PrefabGate gate=null;yield return HoldCaching("Step17HeldScreen",held=>gate=held);var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);var pending=_creator.StartInitAsync().AsTask();yield return Until(()=>gate.Pending.Count>0);Assert.That(_instances.PopupReturned,Is.EqualTo(1));var current=Popup();yield return Done(current);var wait=current.Result.CloseWait().AsTask();gate.Open();yield return Done(pending);yield return null;yield return null;
            Assert.That(current.Result.IsOpen,Is.True);Assert.That(wait.IsCompleted,Is.False);Assert.That(_instances.PopupReturned,Is.EqualTo(1));
        }
        [UnityTest]public IEnumerator ReentrantShutdownDuringSceneCloseReturnsOwnedRootOnlyOnce()
        {
            var old=Popup();yield return Done(old);old.Result.onHide.AddListener(_=>_creator.Shutdown());var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);yield return null;yield return null;yield return null;
            Assert.That(_creator.IsInitialized,Is.False);Assert.That(_instances.Returned,Is.EqualTo(_instances.Created));Assert.That(DOTween.TotalActiveTweens(),Is.Zero);yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.IsInitialized,Is.True);Assert.That(_instances.Roots,Is.EqualTo(2));
        }
        [UnityTest]public IEnumerator ReentrantDisableDuringSceneCloseCannotContinueOldInitialization()
        {
            var old=Popup();yield return Done(old);old.Result.onHide.AddListener(_=>_creator.enabled=false);var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);yield return null;yield return null;yield return null;Assert.That(_creator.enabled,Is.False);Assert.That(_instances.Returned,Is.EqualTo(_instances.Created));_creator.enabled=true;yield return Done(_creator.StartInitAsync().AsTask());Assert.That(_creator.IsInitialized,Is.True);
        }
        [UnityTest]public IEnumerator ReentrantDestroyDuringSceneCloseCancelsLateWork()
        {
            var old=Popup();yield return Done(old);old.Result.onHide.AddListener(_=>Object.Destroy(_creator.gameObject));var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);yield return null;yield return null;yield return null;Assert.That(_instances.Returned,Is.EqualTo(_instances.Created));Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        [UnityTest]public IEnumerator BorrowedGameUiRootRemainsOwnedByItsExternalSdkCaller()
        {
            _creator.Shutdown();yield return null;yield return null;var root=Addressables.InstantiateAsync("UIManager");_external.Add(root);yield return Done(root.Task);yield return Done(_creator.StartInitAsync().AsTask());_ui=UIManager.Instance;var popup=Popup();yield return Done(popup);var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);yield return Done(_creator.StartInitAsync().AsTask());yield return null;_creator.Shutdown();yield return null;
            Assert.That(root.IsValid(),Is.True);Assert.That(root.Result,Is.Not.Null);Assert.That(_ui.gameObject.activeSelf,Is.True);Assert.That(_instances.PopupReturned,Is.EqualTo(1));Assert.That(_instances.Created-_instances.Returned,Is.GreaterThan(0));
        }
        [UnityTest]public IEnumerator SceneChangeCancelsInflightPopupAndReturnsItsLateNativeInstance()
        {
            var prefab=Addressables.LoadAssetAsync<GameObject>("UIPopup_YesNoPopup");_assets.Add(prefab);yield return Done(prefab.Task);var gate=new PrefabGate(prefab.Result);_prefabGates.Add(gate);Addressables.ResourceManager.ResourceProviders.Add(gate);
            var type="Step17GatedPopup";string key=UIPopupManager.GetAddressableKey(type);var locator=new ResourceLocationMap(gate.ProviderId);locator.Add(key,new ResourceLocationBase(key,key,gate.ProviderId,typeof(GameObject)));Addressables.AddResourceLocator(locator);_locators.Add(locator);
            var old=_ui.popupManager.RequestPopup(type,null,false).AsTask();yield return Until(()=>gate.Pending.Count>0);var next=Next();_creator.mainCamera=next.camera;SceneManager.SetActiveScene(next.scene);yield return Done(_creator.StartInitAsync().AsTask());yield return Until(()=>old.IsCompleted);Assert.That(old.Exception?.GetBaseException(),Is.InstanceOf<OperationCanceledException>());
            var current=Popup();gate.Open();yield return Done(current);yield return Until(()=>gate.Returns==gate.Loads);Assert.That(_instances.PopupCreated,Is.EqualTo(2));Assert.That(_instances.PopupReturned,Is.EqualTo(1));Assert.That(current.Result.IsOpen,Is.True);
        }
        [UnityTest]public IEnumerator RapidSceneGenerationsCannotCloseTheNewestPopupFromAnOldCompletion()
        {
            var b=Next();var c=Next();PrefabGate gateB=null,gateC=null;yield return HoldCaching("Step17HeldB",held=>gateB=held);
            _creator.mainCamera=b.camera;SceneManager.SetActiveScene(b.scene);var pendingB=_creator.StartInitAsync().AsTask();yield return Until(()=>gateB.Pending.Count>0);var popupB=Popup();yield return Done(popupB);
            yield return HoldCaching("Step17HeldC",held=>gateC=held);_creator.mainCamera=c.camera;SceneManager.SetActiveScene(c.scene);var pendingC=_creator.StartInitAsync().AsTask();yield return Until(()=>gateC.Pending.Count>0);var popupC=Popup();yield return Done(popupC);gateB.Open();yield return null;yield return null;Assert.That(pendingB.IsCompleted,Is.True);Assert.That(pendingB.Exception?.GetBaseException(),Is.InstanceOf<OperationCanceledException>());Assert.That(popupC.Result.IsOpen,Is.True);
            gateC.Open();yield return Done(pendingC);Assert.That(popupC.Result.IsOpen,Is.True);Assert.That(_instances.PopupReturned,Is.EqualTo(1));Assert.That(c.camera.GetUniversalAdditionalCameraData().cameraStack.Count(x=>x==_ui.UICamera),Is.EqualTo(1));
        }
    }
}
//추가 종료
