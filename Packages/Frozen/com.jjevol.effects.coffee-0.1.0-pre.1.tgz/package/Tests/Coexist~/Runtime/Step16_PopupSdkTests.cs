//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using DG.Tweening;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;
namespace jjevol.Step17.UI.DOTweenPro.Tests
{
    [PrebuildSetup("jjevol.Step19.Coffee.Coexist.AllFixtureSetup")]
    public sealed class PopupSdkTests
    {
        readonly List<AsyncOperationHandle<GameObject>> _roots=new();readonly List<GameObject> _objects=new();
        static IEnumerator Done(Task t){float end=Time.realtimeSinceStartup+10;while(!t.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;Assert.That(t.IsCompleted,Is.True);if(t.IsFaulted)throw t.Exception.GetBaseException();Assert.That(t.IsCanceled,Is.False);}
        static IEnumerator Until(Func<bool> p){float end=Time.realtimeSinceStartup+6;while(!p()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(p(),Is.True);}
        [UnitySetUp]public IEnumerator Setup(){Time.timeScale=1;DOTween.Init(false,true,LogBehaviour.ErrorsOnly);var init=Addressables.InitializeAsync(false);yield return Done(init.Task);Addressables.Release(init);}
        IEnumerator Root(){var h=Addressables.InstantiateAsync("UIPopup_YesNoPopup");_roots.Add(h);yield return Done(h.Task);}
        [UnityTearDown]public IEnumerator Cleanup(){Time.timeScale=1;foreach(var h in _roots)if(h.IsValid())Addressables.ReleaseInstance(h);_roots.Clear();foreach(var o in _objects)if(o)Object.Destroy(o);_objects.Clear();yield return null;yield return null;int count=DOTween.TotalActiveTweens();DOTween.KillAll(false);Assert.That(count,Is.Zero);}
        [UnityTest]public IEnumerator ActualPrefabTmpAnimatorTriggerAndProShowHideWorkThroughPopup()
        {
            yield return Root();var root=_roots[0].Result;var popup=root.GetComponent<UIPopup>();popup.Initialize(new Pool());var transition=root.GetComponent<UITransition>();int shown=0,hidden=0;transition.onShowComplete.AddListener(()=>shown++);transition.onHideComplete.AddListener(()=>hidden++);
            var canvas=new GameObject("Canvas",typeof(RectTransform),typeof(Canvas));_objects.Add(canvas);canvas.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;root.transform.SetParent(canvas.transform,false);
            float start=Time.realtimeSinceStartup;popup.ShowUI();yield return Until(()=>shown==1);Assert.That(Time.realtimeSinceStartup-start,Is.GreaterThan(.24f));var animator=root.GetComponentInChildren<Animator>();Assert.That(animator.GetCurrentAnimatorStateInfo(0).IsName("Play"),Is.True);Assert.That(animator.updateMode,Is.EqualTo(AnimatorUpdateMode.UnscaledTime));
            var tmp=root.GetComponentInChildren<TMP_Text>();tmp.ForceMeshUpdate();Assert.That(tmp.textInfo.characterCount,Is.GreaterThan(0));Assert.That(root.GetComponentInChildren<DOTweenAnimation>().transform.localPosition.x,Is.EqualTo(2).Within(.03f));
            popup.HideUI();yield return Until(()=>hidden==1);Assert.That(root.activeSelf,Is.False);
            // Native Sequence auto-kill retires after the completion callback returns to the SDK update.
            yield return null;Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
            popup.ShowUI();yield return Until(()=>shown==2);popup.ForceClosePopup();Assert.That(root.activeSelf,Is.False);
        }
        [UnityTest]public IEnumerator DestroyDuringNativePopupShowHasNoLateCompletionOrTween()
        {
            yield return Root();var root=_roots[0].Result;var transition=root.GetComponent<UITransition>();int done=0;transition.onShowComplete.AddListener(()=>done++);root.GetComponent<UIPopup>().ShowUI();yield return null;Addressables.ReleaseInstance(_roots[0]);_roots.Clear();yield return new WaitForSecondsRealtime(.4f);
            Assert.That(done,Is.Zero);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        [UnityTest]public IEnumerator SceneUnloadStopsTheActualPopupTransition()
        {
            yield return Root();var scene=SceneManager.CreateScene("Step16 popup scene");var root=_roots[0].Result;SceneManager.MoveGameObjectToScene(root,scene);int done=0;root.GetComponent<UITransition>().onShowComplete.AddListener(()=>done++);root.GetComponent<UIPopup>().ShowUI();yield return null;yield return SceneManager.UnloadSceneAsync(scene);yield return new WaitForSecondsRealtime(.35f);
            Assert.That(done,Is.Zero);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        sealed class Pool:IUIReleaseHandle{public void Release(UIBase ui)=>ui.gameObject.SetActive(false);}
    }
}
//추가 종료
