//추가
using System;
using System.Collections;
using System.IO;
using System.Linq;
using Coffee.UIExtensions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace jjevol.Step19.Coffee.Coexist
{
    [PrebuildSetup("jjevol.Step19.Coffee.Coexist.AllFixtureSetup")]
    public sealed class UrpCoffeeRenderingTests
    {
        [UnityTest] public IEnumerator RealUrpCameraRendersTheCoffeeMeshAndStencilClipping()
        {
            var loaded = Addressables.LoadAssetAsync<GameObject>("Step19/Particle"); yield return loaded;
            Assert.That(loaded.Result, Is.Not.Null);
            var cameraRoot = new GameObject("Independent URP Camera", typeof(Camera), typeof(UniversalAdditionalCameraData));
            var camera = cameraRoot.GetComponent<Camera>(); camera.enabled = false; camera.transform.position = new Vector3(0, 0, -10);
            camera.orthographic = true; camera.orthographicSize = 64; camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = Color.black;
            var canvasRoot = new GameObject("Independent URP Canvas", typeof(RectTransform), typeof(Canvas));
            var canvas = canvasRoot.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceCamera; canvas.worldCamera = camera; canvas.planeDistance = 5;
            var target = new RenderTexture(128, 128, 24); target.Create(); camera.targetTexture = target;
            var root = Object.Instantiate(loaded.Result, canvas.transform, false);
            var ui = root.GetComponent<UIParticle>(); ui.scale3D = Vector3.one; root.GetComponent<SyncUIParticleScale>().CaptureReference();
            var ps = root.GetComponentInChildren<ParticleSystem>(); var main = ps.main; main.loop = true; main.startSize = 40; main.startLifetime = 10;
            var emission = ps.emission; emission.rateOverTime = 0; ui.Play(); ps.Emit(1);
            Action<ScriptableRenderContext, Camera> emit = (context, view) => ScriptableRenderContext.EmitGeometryForCamera(view);
            RenderPipelineManager.beginCameraRendering += emit;
            try
            {
                Assert.That(GraphicsSettings.currentRenderPipeline, Is.TypeOf<UniversalRenderPipelineAsset>());
                for (int i = 0; i < 4; i++) { Canvas.ForceUpdateCanvases(); yield return null; }
                var request = new RenderPipeline.StandardRequest { destination = target };
                Assert.That(RenderPipeline.SupportsRenderRequest(camera, request), Is.True);
                int Read(string filename)
                {
                    Canvas.ForceUpdateCanvases(); RenderPipeline.SubmitRenderRequest(camera, request);
                    var previous = RenderTexture.active; RenderTexture.active = target;
                    var image = new Texture2D(128, 128, TextureFormat.RGB24, false);
                    try
                    {
                        image.ReadPixels(new Rect(0, 0, 128, 128), 0, 0); image.Apply();
                        string folder = Path.GetFullPath(Path.Combine(Application.dataPath, "../Artifacts")); Directory.CreateDirectory(folder);
                        File.WriteAllBytes(Path.Combine(folder, filename + ".png"), image.EncodeToPNG());
                        return image.GetPixels32().Count(c => c.r > 100 && c.g < 80 && c.b < 80);
                    }
                    finally { RenderTexture.active = previous; Object.Destroy(image); }
                }
                int full = Read("UrpParticleFull"); Assert.That(full, Is.GreaterThan(100));
                var mask = new GameObject("Independent URP mask", typeof(RectTransform), typeof(Image), typeof(Mask)); mask.transform.SetParent(canvas.transform, false);
                mask.GetComponent<RectTransform>().sizeDelta = new Vector2(12, 12); mask.GetComponent<Mask>().showMaskGraphic = false; root.transform.SetParent(mask.transform, false);
                Canvas.ForceUpdateCanvases(); yield return null; yield return null;
                int clipped = Read("UrpParticleMasked"); Assert.That(clipped, Is.GreaterThan(0)); Assert.That(clipped, Is.LessThan(full / 2));
                TestContext.WriteLine("URP real SDK red pixels full=" + full + ", clipped=" + clipped);
            }
            finally
            {
                RenderPipelineManager.beginCameraRendering -= emit; camera.targetTexture = null;
                Object.Destroy(canvasRoot); Object.Destroy(cameraRoot); target.Release(); Object.Destroy(target); Addressables.Release(loaded);
            }
            yield return null; yield return null;
        }
    }
}
//추가 종료
