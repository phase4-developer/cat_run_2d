//추가
using UnityEngine.TestTools;
namespace jjevol.Step19.Coffee.Coexist
{
    public sealed class AllFixtureSetup : IPrebuildSetup
    {
        public void Setup()
        {
            new jjevol.Step17.EffectUI.Tests.AdapterFixtureSetup().Setup();
            new jjevol.DOTweenIntegration.Tests.IntegrationFixtureSetup().Setup();
            new jjevol.Effect.Coffee.Tests.CoffeeFixtureSetup().Setup();
        }
    }
}
//추가 종료
