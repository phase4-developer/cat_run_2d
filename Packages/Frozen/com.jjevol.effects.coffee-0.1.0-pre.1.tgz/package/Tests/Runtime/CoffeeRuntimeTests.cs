//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Coffee.UIExtensions;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Coffee.Tests
{
    // Retires a real Unity component during Update.
    public sealed class RetireDeferredStart : MonoBehaviour
    {
        public SyncUIParticleScale Target;
        public UIParticle Particle;
        public Vector3 Replacement;
        void Update()
        {
            if (!Target) return;
            Object.DestroyImmediate(Target);
            Particle.scale3D = Replacement;
            enabled = false;
        }
    }

    [PrebuildSetup("jjevol.Effect.Coffee.Tests.CoffeeFixtureSetup")]
    public sealed class CoffeeRuntimeTests
    {
        const string Key = "Step19/Particle";
        readonly List<Object> _objects = new();
        readonly List<Scene> _scenes = new();
        AsyncOperationHandle<GameObject> _asset;
        EffectManager _manager;
        Leases _leases;
        int _activeBefore;
        sealed class Leases : IEffectPrefabProvider
        {
            readonly AddressablesEffectPrefabProvider _sdk = new();
            public int Loads, Returns;
            public async UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token)
            {
                var lease = await _sdk.LoadAsync(key, token); if (lease == null) return null;
                Loads++;
                return new EffectPrefabLease(lease.Prefab, () => { Returns++; lease.Dispose(); });
            }
        }
        static int ActiveSdkParticles => (int)typeof(UIParticle).Assembly.GetType("Coffee.UIExtensions.UIParticleUpdater")
            .GetProperty("uiParticleCount", BindingFlags.Static | BindingFlags.Public).GetValue(null);
        static void Set(object value, string name, object data) => value.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).SetValue(value, data);
        static IEnumerator Done(Task task)
        {
            float end = Time.realtimeSinceStartup + 12;
            while (!task.IsCompleted && Time.realtimeSinceStartup < end) yield return null;
            Assert.That(task.IsCompleted, Is.True, "Real SDK operation completed");
            if (task.IsFaulted) throw task.Exception.GetBaseException(); Assert.That(task.IsCanceled, Is.False);
        }
        static IEnumerator Until(Func<bool> condition, string message = "Native state reached")
        {
            float end = Time.realtimeSinceStartup + 6;
            while (!condition() && Time.realtimeSinceStartup < end) { Canvas.ForceUpdateCanvases(); yield return null; }
            Assert.That(condition(), Is.True, message);
        }
        GameObject New(string name, params Type[] components)
        {
            var go = new GameObject(name, components); _objects.Add(go); return go;
        }
        Canvas CanvasRoot()
        {
            var canvas = New("Independent Canvas", typeof(RectTransform), typeof(Canvas)).GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay; return canvas;
        }
        GameObject Instance(Transform parent, bool active = true)
        {
            var go = Object.Instantiate(_asset.Result, parent, false); _objects.Add(go); go.SetActive(active); return go;
        }
        static MaskableGraphic Generated(UIParticle particle)
            => particle.GetComponentsInChildren<MaskableGraphic>(true).FirstOrDefault(x => x.GetType().Name == "UIParticleRenderer");
        static int Vertices(UIParticle particle)
        {
            var graphic = Generated(particle); if (!graphic) return 0;
            var mesh = graphic.canvasRenderer.GetMesh(); return mesh ? mesh.vertexCount : 0;
        }
        static void Scale(UIParticle ui, Vector3 expected)
        {
            Assert.That(ui.scale3D.x, Is.EqualTo(expected.x).Within(.001));
            Assert.That(ui.scale3D.y, Is.EqualTo(expected.y).Within(.001));
            Assert.That(ui.scale3D.z, Is.EqualTo(expected.z).Within(.001));
        }
        [UnitySetUp] public IEnumerator Setup()
        {
            Time.timeScale = 1; EffectManager.applicationIsQuitting = false; _activeBefore = ActiveSdkParticles;
            var init = Addressables.InitializeAsync(false); yield return Done(init.Task); Addressables.Release(init);
            _asset = Addressables.LoadAssetAsync<GameObject>(Key); yield return Done(_asset.Task); Assert.That(_asset.Result, Is.Not.Null);
            _manager = New("Native Effect Manager").AddComponent<EffectManager>(); _leases = new Leases(); _manager.SetPrefabProvider(_leases);
        }
        [UnityTearDown] public IEnumerator Cleanup()
        {
            Time.timeScale = 1;
            foreach (var value in _objects) if (value) Object.Destroy(value); _objects.Clear();
            yield return null; yield return null;
            foreach (var scene in _scenes) if (scene.IsValid() && scene.isLoaded) yield return SceneManager.UnloadSceneAsync(scene); _scenes.Clear();
            yield return Until(() => _leases.Returns == _leases.Loads, "All native prefab leases returned once");
            if (_asset.IsValid()) Addressables.Release(_asset);
            yield return Until(() => ActiveSdkParticles == _activeBefore, "SDK active registration returned to baseline");
        }
        [UnityTest] public IEnumerator RuntimeAutoCaptureThenAnisotropicResizeUsesOriginalFormula()
        {
            var go = Instance(CanvasRoot().transform, false); var helper = go.GetComponent<SyncUIParticleScale>();
            Set(helper, "baseSize", Vector2.zero); Set(helper, "baseScale3D", Vector3.zero); go.SetActive(true);
            yield return null; yield return null;
            go.GetComponent<RectTransform>().sizeDelta = new Vector2(200, 240); Scale(go.GetComponent<UIParticle>(), new Vector3(4, 9, 10));
        }
        [UnityTest] public IEnumerator SerializedReferenceResizesWithoutCumulativeMultiplication()
        {
            var go = Instance(CanvasRoot().transform); yield return null; yield return null;
            var rect = go.GetComponent<RectTransform>(); var ui = go.GetComponent<UIParticle>();
            for (int i = 0; i < 20; i++) { rect.sizeDelta = new Vector2(200, 240); Scale(ui, new Vector3(4, 9, 10)); rect.sizeDelta = new Vector2(100, 80); Scale(ui, new Vector3(2, 3, 4)); }
        }
        [UnityTest] public IEnumerator ParentAndWorldCanvasDimensionsUpdateAStretchedHelper()
        {
            var canvas = CanvasRoot(); canvas.renderMode = RenderMode.WorldSpace;
            var parent = canvas.GetComponent<RectTransform>(); parent.sizeDelta = new Vector2(100, 80);
            var go = Instance(parent); var rect = go.GetComponent<RectTransform>(); rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one; rect.sizeDelta = Vector2.zero;
            yield return null; yield return null; parent.sizeDelta = new Vector2(200, 240); Canvas.ForceUpdateCanvases();
            Scale(go.GetComponent<UIParticle>(), new Vector3(4, 9, 10));
        }
        [UnityTest] public IEnumerator ExplicitRecaptureChangesTheReferenceWithoutChangingLayout()
        {
            var go = Instance(CanvasRoot().transform); yield return null; yield return null;
            var rect = go.GetComponent<RectTransform>(); rect.sizeDelta = new Vector2(200, 160);
            var ui = go.GetComponent<UIParticle>(); ui.scale3D = new Vector3(6, 8, 10); go.GetComponent<SyncUIParticleScale>().CaptureReference();
            rect.sizeDelta = new Vector2(100, 80); Scale(ui, new Vector3(3, 4, 5));
            Assert.That(rect.anchorMin, Is.EqualTo(Vector2.one * .5f)); Assert.That(rect.localScale, Is.EqualTo(Vector3.one));
        }
        [UnityTest] public IEnumerator TwentyEnableDisableCyclesDoNotAccumulateScaleOrSdkRegistrations()
        {
            var go = Instance(CanvasRoot().transform); var ui = go.GetComponent<UIParticle>(); yield return null; yield return null;
            for (int i = 0; i < 20; i++)
            {
                go.SetActive(false); Assert.That(ActiveSdkParticles, Is.EqualTo(_activeBefore));
                go.GetComponent<RectTransform>().sizeDelta = new Vector2(200, 160); go.SetActive(true); Scale(ui, new Vector3(4, 6, 8));
                Assert.That(ActiveSdkParticles, Is.EqualTo(_activeBefore + 1)); yield return null;
            }
        }
        [UnityTest] public IEnumerator DestroyedHelperCannotApplyItsOldDeferredStartToTheRemainingUiParticle()
        {
            var go = Instance(CanvasRoot().transform); var retire = go.AddComponent<RetireDeferredStart>();
            retire.Target = go.GetComponent<SyncUIParticleScale>(); retire.Particle = go.GetComponent<UIParticle>(); retire.Replacement = new Vector3(7, 8, 9);
            yield return null; yield return null;
            Assert.That(go.GetComponent<SyncUIParticleScale>() == null, Is.True);
            Scale(retire.Particle, retire.Replacement);
        }
        [UnityTest] public IEnumerator AlreadyEnteredDeferredStartCannotWriteAfterItsComponentIsDestroyed()
        {
            // Invoke the unmodified production Start once to control the exact
            // await -> destruction boundary. The SDK, Yield and PlayerLoop are real.
            var go = Instance(CanvasRoot().transform, false); var helper = go.GetComponent<SyncUIParticleScale>();
            go.SetActive(true);
            typeof(SyncUIParticleScale).GetMethod("Start", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(helper, null);
            Assert.That(typeof(SyncUIParticleScale).GetField("isInitialized", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(helper), Is.False);
            var ui = go.GetComponent<UIParticle>(); Object.DestroyImmediate(helper); ui.scale3D = new Vector3(7, 8, 9);
            yield return null; yield return null;
            Scale(ui, new Vector3(7, 8, 9));
        }
        [UnityTest] public IEnumerator ActualSdkPlayPauseStopAndRestartProduceCanvasMeshes()
        {
            var go = Instance(CanvasRoot().transform); var ui = go.GetComponent<UIParticle>(); var ps = go.GetComponentInChildren<ParticleSystem>();
            var main = ps.main; main.loop = true; ui.RefreshParticles(); ui.Play();
            yield return Until(() => ps.particleCount > 0 && Vertices(ui) > 0, "Actual SDK generated particle Canvas mesh");
            ui.Pause(); float time = ps.time; yield return new WaitForSecondsRealtime(.12f); Assert.That(ps.time, Is.EqualTo(time).Within(.005));
            ui.Resume(); yield return Until(() => ps.time > time + .02f); ui.Stop(); ui.Clear();
            yield return null; Assert.That(ps.particleCount, Is.Zero); ui.Play(); yield return Until(() => ps.particleCount > 0 && Vertices(ui) > 0);
        }
        [UnityTest] public IEnumerator StencilMaskAndCanvasSortingAreAppliedToActualSdkRenderers()
        {
            var canvas = CanvasRoot(); canvas.sortingOrder = 37;
            var mask = New("Independent stencil mask", typeof(RectTransform), typeof(Image), typeof(Mask)); mask.transform.SetParent(canvas.transform, false);
            mask.GetComponent<RectTransform>().sizeDelta = new Vector2(40, 40); mask.GetComponent<Mask>().showMaskGraphic = false;
            var go = Instance(mask.transform); var ui = go.GetComponent<UIParticle>(); ui.Play();
            yield return Until(() => Vertices(ui) > 0); var generated = Generated(ui);
            Assert.That(generated.maskable, Is.True); Assert.That(generated.canvas.sortingOrder, Is.EqualTo(37));
            Assert.That(generated.materialForRendering.GetInt("_Stencil"), Is.GreaterThan(0), "Real stencil material, not mask flag only");
            int depth = generated.canvasRenderer.absoluteDepth; Assert.That(depth, Is.GreaterThanOrEqualTo(0));
            var sibling = Instance(mask.transform); sibling.GetComponent<UIParticle>().Play(); yield return Until(() => Vertices(sibling.GetComponent<UIParticle>()) > 0);
            Canvas.ForceUpdateCanvases(); Assert.That(Generated(sibling.GetComponent<UIParticle>()).canvasRenderer.absoluteDepth, Is.GreaterThan(depth));
        }
        [UnityTest] public IEnumerator TwentyEffectPoolReusesKeepOnePrefabLeaseAndCurrentScale()
        {
            var canvas = CanvasRoot(); _manager.SetPoolProfile(Key, 1, 4, 30); EffectHandle old = null; int completed = 0;
            for (int i = 0; i < 20; i++)
            {
                var play = _manager.PlayAsync(new EffectRequest(Key, loop: true, parent: canvas.transform, callBack: () => completed++)).AsTask(); yield return Done(play);
                var handle = play.Result; if (old) Assert.That(handle, Is.SameAs(old)); old = handle;
                Assert.That(handle.Renderer, Is.TypeOf<jjevol.Effect.Renderers.ParticleEffectRenderer>());
                ((RectTransform)handle.Renderer.Root).sizeDelta = new Vector2(200, 160); yield return null;
                Scale(handle.Renderer.Root.GetComponent<UIParticle>(), new Vector3(4, 6, 8));
                _manager.Despawn(handle); _manager.Despawn(handle); Assert.That(completed, Is.EqualTo(i + 1));
                Assert.That(handle.gameObject.activeSelf, Is.False); Assert.That(handle.GetComponentInChildren<ParticleSystem>(true).particleCount, Is.Zero);
            }
            Assert.That(_leases.Loads, Is.EqualTo(1)); Assert.That(_leases.Returns, Is.Zero);
            Object.Destroy(_manager.gameObject); yield return null; yield return Until(() => _leases.Returns == 1);
        }
        [UnityTest] public IEnumerator NonLoopCompletionReturnsIdlePrefabLease()
        {
            _manager.SetPoolProfile(Key, 0, 4, .1f); int completed = 0;
            var play = _manager.PlayAsync(new EffectRequest(Key, parent: CanvasRoot().transform, callBack: () => completed++)).AsTask(); yield return Done(play);
            yield return Until(() => completed == 1); yield return Until(() => _leases.Returns == 1);
            Assert.That(completed, Is.EqualTo(1));
        }
        [UnityTest] public IEnumerator SceneCanvasUnloadDestroysTheInstanceAndReturnsItsNativePrefabLease()
        {
            var scene = SceneManager.CreateScene("Independent Coffee scene"); _scenes.Add(scene);
            var canvas = CanvasRoot(); SceneManager.MoveGameObjectToScene(canvas.gameObject, scene);
            var play = _manager.PlayAsync(new EffectRequest(Key, loop: true, parent: canvas.transform)).AsTask(); yield return Done(play);
            yield return null; yield return SceneManager.UnloadSceneAsync(scene); yield return Until(() => _leases.Returns == 1);
            Assert.That(play.Result == null, Is.True); Assert.That(ActiveSdkParticles, Is.EqualTo(_activeBefore));
        }
        [UnityTest] public IEnumerator ManagerDisableAndDestroyRetireParticlesAndAllowReuse()
        {
            var canvas = CanvasRoot(); var play = _manager.PlayAsync(new EffectRequest(Key, loop: true, parent: canvas.transform)).AsTask(); yield return Done(play);
            _manager.enabled = false; Assert.That(play.Result.gameObject.activeSelf, Is.False); Assert.That(play.Result.GetComponentInChildren<ParticleSystem>(true).particleCount, Is.Zero);
            _manager.enabled = true; var next = _manager.PlayAsync(new EffectRequest(Key, loop: true, parent: canvas.transform)).AsTask(); yield return Done(next);
            Assert.That(next.Result, Is.SameAs(play.Result)); yield return null;
            Object.Destroy(_manager.gameObject); yield return null; yield return Until(() => _leases.Returns == 1); Assert.That(next.Result == null, Is.True);
        }
        [UnityTest] public IEnumerator ActualCameraPixelsShowTheSdkParticleAndStencilMaskClipping()
        {
            var canvas = CanvasRoot(); canvas.renderMode = RenderMode.ScreenSpaceCamera;
            var camera = New("Independent render Camera", typeof(Camera)).GetComponent<Camera>(); camera.enabled = false;
            camera.transform.position = new Vector3(0, 0, -10); camera.orthographic = true; camera.orthographicSize = 64;
            camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = Color.black;
            var rt = new RenderTexture(128, 128, 24); _objects.Add(rt); rt.Create(); camera.targetTexture = rt;
            canvas.worldCamera = camera; canvas.planeDistance = 5;
            var go = Instance(canvas.transform); var ui = go.GetComponent<UIParticle>(); ui.scale3D = Vector3.one; go.GetComponent<SyncUIParticleScale>().CaptureReference();
            var ps = go.GetComponentInChildren<ParticleSystem>(); var main = ps.main; main.loop = true; main.startSize = 40; main.startLifetime = 10;
            var emission = ps.emission; emission.rateOverTime = 0; ui.Play(); ps.Emit(1);
            yield return Until(() => Vertices(ui) > 0);
            int Read(string name)
            {
                Canvas.ForceUpdateCanvases(); camera.Render(); var old = RenderTexture.active; RenderTexture.active = rt;
                var texture = new Texture2D(128, 128, TextureFormat.RGB24, false);
                try
                {
                    texture.ReadPixels(new Rect(0, 0, 128, 128), 0, 0); texture.Apply(); var colors = texture.GetPixels32();
                    string folder = Path.GetFullPath(Path.Combine(Application.dataPath, "../Artifacts")); Directory.CreateDirectory(folder); File.WriteAllBytes(Path.Combine(folder, name + ".png"), texture.EncodeToPNG());
                    return colors.Count(c => c.r > 100 && c.g < 80 && c.b < 80);
                }
                finally { RenderTexture.active = old; Object.Destroy(texture); }
            }
            int full = Read("ParticleFull"); Assert.That(full, Is.GreaterThan(100), "Actual rendered red pixels");
            var mask = New("Render stencil mask", typeof(RectTransform), typeof(Image), typeof(Mask)); mask.transform.SetParent(canvas.transform, false);
            mask.GetComponent<RectTransform>().sizeDelta = new Vector2(12, 12); mask.GetComponent<Mask>().showMaskGraphic = false; go.transform.SetParent(mask.transform, false);
            yield return null; yield return null; int clipped = Read("ParticleMasked");
            Assert.That(clipped, Is.GreaterThan(0)); Assert.That(clipped, Is.LessThan(full / 2));
            TestContext.WriteLine("Native red pixels: full=" + full + ", clipped=" + clipped);
            camera.targetTexture = null;
        }
    }
}
//추가 종료
