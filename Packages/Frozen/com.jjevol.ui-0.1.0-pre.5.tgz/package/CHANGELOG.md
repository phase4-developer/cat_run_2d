# Changelog

## 0.1.0-pre.5 - 2026-11-20

- 깨짐: `UIRuntimeOptions`의 `Culture`, `Language`, `DisplayCulture`, `CurrentLanguage`, `NumberFormat`, `CurrentNumberFormat`, `FormatNumber`, `LocaleChanged`, `NotifyLocaleChanged`를 없앴다. 같은 이름으로 `com.jjevol.ui.contracts@0.1.0-pre.5`의 `UIDisplayOptions`에 있다(사용자 결정 2026-11-20 「ui.contracts 중립 설정」·「uGUI도 맞춤」). 게임은 `UIRuntimeOptions.X`를 `UIDisplayOptions.X`로 바꾼다. `UIRuntimeOptions`에는 uGUI 전용 `Localize`·`RegisterLoadingCounter`·`GetLocalizedString`만 남는다.
- `NumberAnimator`가 `UIDisplayOptions`를 읽는다. 표시는 그대로다.

## 0.1.0-pre.4 - 2026-11-19

- `UIRuntimeOptions.NumberFormat`(게임 전체 `NumberFormatSettings`, 없으면 N0), `CurrentNumberFormat`, `FormatNumber`를 더했다.
- `NumberAnimator`가 `com.jjevol.ui.contracts`의 `NumberFormat`을 쓴다. `PrintType.Number`는 게임 프로필을 따르고(기본 N0이라 표시는 그대로), `UseSymbolic`은 게임 프로필이 축약이면 그것을, 아니면 언어별 기본(한국어 만·억, 그 밖 K·M·B·T 소수 2자리 버림)을 쓴다. 라벨별 `SetNumberFormat`과 직렬화 필드 `_overrideNumberFormat`·`_numberFormat`을 더했다.
- 깨짐: 내부 `UINumberFormatting`을 지웠다. `UseSymbolic` 결과가 바뀐다. 예: 1,234,567은 `1,234K`에서 `1.23M`, 1,000은 `1,000`에서 `1K`.

## 0.1.0-pre.3 - 2026-11-11

- `IUILoadingProgressView` moved to `com.jjevol.ui.contracts` with its GUID. Namespace and name are unchanged. A game assembly definition that uses it needs a `JJEvol.UI.Contracts.Runtime` reference; Assembly-CSharp gets it automatically.

## 0.1.0-pre.2 - 2026-11-06

- A failed transition now fades out and releases input before rethrowing.
- A fader saved inactive finds its Image on first use, so its first fade or transition shows the cover. It no longer throws or skips the cover.
- Added `LoadingIndicator.Scope`, `IUILoadingProgressView` and `UILoadingBar`. A missing indicator warns once and a null Indicator is handled consistently.
- Reset static state when Domain Reload is disabled.

Unity tests for this candidate are NOT_RUN.
