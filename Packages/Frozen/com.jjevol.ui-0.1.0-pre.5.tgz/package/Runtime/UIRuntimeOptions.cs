using System;
using UnityEngine;
using UnityEngine.Events;
namespace jjevol
{
    // uGUI-only hooks. Culture, language, number profiles, the clock and the locale change notice live in
    // UIDisplayOptions (com.jjevol.ui.contracts), shared with the UI Toolkit packages.
    public static class UIRuntimeOptions
    {
        public static Func<string, string, string> Localize { get; set; }
        public static Action<IKeyReferenceCounter> RegisterLoadingCounter { get; set; }
        public static string GetLocalizedString(string collection, string key) => Localize?.Invoke(collection, key) ?? key;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            Localize = null; RegisterLoadingCounter = null;
        }
    }
    public interface IUITransition
    {
        bool IsTransitioning { get; }
        CanvasGroup TargetCanvasGroup { get; }
        UnityEvent ShowCompleted { get; }
        UnityEvent HideCompleted { get; }
        void OnWindowAdded();
        void OnWindowRemove();
        void ForceStopTransition();
    }
}
