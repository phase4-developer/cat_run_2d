# JJEvol UI Core — STEP 11 candidate

`com.jjevol.ui@0.1.0-pre.2`, Unity 6000.3.9f1. 기존 UIBase의 `ShowUI → Refresh → _DrawContents`, SetDirty의 다음 프레임 갱신, SetSubscribe의 중복 방지와 해제를 유지한다. 기본 화면 수명·레이아웃 helper·NumberAnimator·UIFader·LoadingIndicator를 제공한다.

필수 SDK는 uGUI 2.0.0(TMP 포함)과 UniTask 2.5.10이다. Addressables, Economy, Audio/Effect, Firebase, Platform, Runner, Localization SDK, DOTween을 강제하지 않는다. SDK 자산·폰트·제품 Prefab은 이 패키지에 포함하지 않는다. TMP를 쓰는 소비 프로젝트는 설치된 uGUI의 TMP Essential Resources와 사용할 폰트를 준비한다.

## 기존 사용법

```csharp
public class MyView : jjevol.UIBase
{
    public void ShowUI(MyData next) { data = next; base.ShowUI(); }
    protected override void _DrawContents() { /* Inspector로 연결한 컴포넌트에 표시 */ }
    protected override bool SetSubscribe(bool enabled)
    {
        if (!base.SetSubscribe(enabled)) return false;
        if (enabled) model.Changed += SetDirty;
        else model.Changed -= SetDirty;
        return true;
    }
    MyData data;
}
```

위 MyData/model은 게임 소유 예시 변수다. static RectTransform/Canvas 배치는 Prefab이 소유한다. UIBase가 크기·Anchor·Pivot·Scale을 변경하지 않는다. UIDynamicCanvasBinder/태그/follower는 원래의 명시적 동적 배치 경로를 제공하며, 모든 UI에 자동 적용하지 않는다.

NumberAnimator는 decimal 상태와 기존 필드를 보존해 long 수량을 좁히지 않는다. 완료 callback에서 새 AnimateTo를 시작해도 다음 callback을 지우지 않도록 수정했다. Symbolic + Number/Percentage는 기존의 literal `N0`/`P1` 출력 결함을 composite format으로 수정했다. UIFader는 이전 요청의 완료가 새 실행을 종료하지 못하도록 실행 버전을 확인한다. 실제 ShaderProgress material 조합 전체를 검증한 것은 아니다.

## 선택 연결

`UIRuntimeOptions.Localize`, `Culture`, `Language`는 게임의 Localization 연결 지점이다. Locale 변경 adapter는 `NotifyLocaleChanged()`를 호출한다. 별도 SDK의 이벤트를 자동 구독한다고 가정하지 않는다. `RegisterLoadingCounter`는 기존 LoadingIndicator의 Firebase 등록을 분리한 연결점이다. LoadingIndicator의 키별 참조·지연 표시와 UI 동작은 유지하며 Firebase를 포함하지 않는다.

`RegisterLoadingCounter`는 저장소 안에서 설정하는 곳이 없다. 게임이 설정하면 LoadingIndicator가 초기화될 때 자신을 `IKeyReferenceCounter`로 넘긴다. 외부 도구나 서비스 어댑터가 같은 로딩 카운터를 함께 쓰려면 여기서 받는다. 쓰지 않으면 비워 둔다.

Domain Reload를 끈 Play 진입에 대비해 `UIRuntimeOptions`, `LoadingIndicator`의 정적 상태는 `SubsystemRegistration`에서 비운다. 게임은 이 값들을 `BeforeSceneLoad` 이후나 부트스트랩에서 설정한다. `SubsystemRegistration` 콜백에서 설정하면 순서에 따라 지워질 수 있다.

## 전환 실패

`UIFader.PlayTransitionAsync`, `FadeInOut`의 midAction이 실패해도 화면을 덮은 채 끝나지 않는다. 페이드 아웃과 잠금 해제를 마친 뒤 예외를 호출자에게 전달한다. midAction이 던진 `OperationCanceledException`도 같이 전달한다. 삼키는 취소는 fader 자체 취소(새 전환 시작, 비활성화)뿐이다. endAction은 성공한 전환에서만 호출되고, endAction의 예외도 잠금 해제 뒤 전달한다. ShaderProgress 전환은 성공, midAction 실패, 비활성화, 새 전환으로 인한 취소 모두에서 `fadeImage`의 원래 material을 복원한다.

## 로딩

`LoadingIndicator`는 키별 참조 카운트로 입력을 즉시 막고 표시만 지연한다. `Show`와 `Hide`의 짝을 코드로 보장하려면 `using (LoadingIndicator.Scope(key))`를 쓴다. Dispose는 한 번만 적용되고 Show 시점의 인스턴스에만 반환된다. 인스턴스 없이 호출하면 경고를 한 번 남기고 무시한다. `Indicator`가 비어 있어도 카운트와 입력 차단 흐름은 동작한다.

`IUILoadingProgressView`는 진행률 0~1과 문구를 받는 표시 계약이고, `UILoadingBar`가 기본 구현이다. Image Fill 또는 Slider에 표시하고, 문구는 선택이다. 증가는 `fillSpeed`(초당, unscaled)로 부드럽게 올라가고 감소는 즉시 반영한다. 활성화될 때와 첫 `SetProgress`에서 표시값을 적용하므로 Prefab에 저장된 fillAmount는 보이지 않는다. 세 로딩 체계의 선택 기준과 세션 연결은 `com.jjevol.ui.addressables` README에 있다.

`IUITransition`은 팝업이 요구하는 전환 계약이다. DOTween 구현은 Core에 포함하지 않는다. 선택 Navigation 패키지의 `Integrations~`에 원본 UITransition의 기능과 GUID를 보존했으나 SDK 조합은 미검증이다.

`Singleton<T>`, `KeyReferenceCounter`, `IKeyReferenceCounter`는 이 Core가 소유한다. 기존 Resources 패키지의 PersistentSingleton/PlaySession을 복제하지 않는다. 향후 같은 helper를 다른 패키지에 다시 포함하면 안 된다.

## 검증 경계

Tests/Editor와 Tests/Runtime은 격리 asmdef로 구성한다. 실제 Canvas/TMP, long 표시, callback 재진입·fader 재사용을 검증한다. TMP 준비 helper는 승인된 `.local/ui-validation/CoreHost|FullHost`에만 설치된 SDK의 필수 자산 import를 허용한다. 다른 프로젝트에서 테스트하려면 TMP 자산을 먼저 준비해야 한다. 원본 게임 화면 미감·모든 Prefab·Player/실기기는 별도 검증 대상이다.

전체 결과: Framework의 `Docs/UIExtraction/STEP11_UIExtraction.md`. 로컬 후보이며 버전 발행·Snapshot 고정·기존 게임 적용은 하지 않았다.
