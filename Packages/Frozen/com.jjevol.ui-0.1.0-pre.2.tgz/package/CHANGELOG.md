# Changelog

## 0.1.0-pre.2 - 2026-11-06

- A failed transition now fades out and releases input before rethrowing.
- A fader saved inactive finds its Image on first use, so its first fade or transition shows the cover. It no longer throws or skips the cover.
- Added `LoadingIndicator.Scope`, `IUILoadingProgressView` and `UILoadingBar`. A missing indicator warns once and a null Indicator is handled consistently.
- Reset static state when Domain Reload is disabled.

Unity tests for this candidate are NOT_RUN.
