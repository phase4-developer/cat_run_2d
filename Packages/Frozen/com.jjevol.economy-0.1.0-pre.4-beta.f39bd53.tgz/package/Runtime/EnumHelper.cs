﻿using System.Collections;
using System.Collections.Generic;
using System;

static class EnumHelper
{
    static class Cache<T>
    {
        internal static readonly Dictionary<T, string> Values = new Dictionary<T, string>();
    }

    public static string FastToString<T>(this T @enum) where T : struct
    {
        if (!typeof(T).IsEnum)
            throw new ArgumentException(string.Format("Type {0} is not an enumeration.", typeof(T)));
        lock (Cache<T>.Values)
        {
            string result;
            if (!Cache<T>.Values.TryGetValue(@enum, out result))
            {
                result = @enum.ToString();
                Cache<T>.Values.Add(@enum, result);
            }
            return result;
        }
    }
}