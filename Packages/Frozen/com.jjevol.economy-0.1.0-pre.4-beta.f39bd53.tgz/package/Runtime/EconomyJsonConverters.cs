using System;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
namespace jjevol
{
    public class RHJsonDataConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return typeof(JsonDataBase).IsAssignableFrom(objectType);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.Null)
                return null;

            JObject jo = JObject.Load(reader);

            // Object construction only; field parsing belongs to the explicit model implementation.
            var instance = existingValue as JsonDataBase ?? (JsonDataBase)Activator.CreateInstance(objectType);
            instance.ImportJson(jo);

            return instance;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            var jo = ((JsonDataBase)value).ExportJson();
            jo.WriteTo(writer);
        }
    }

    public sealed class ConsumeTypeIdJsonConverter : JsonConverter<ConsumeTypeId>
    {
        public override ConsumeTypeId ReadJson(JsonReader reader, Type objectType, ConsumeTypeId existingValue, bool hasExistingValue, JsonSerializer serializer)
            => new ConsumeTypeId(ConsumeJson.IntToken(JToken.Load(reader), "consumeType"));
        public override void WriteJson(JsonWriter writer, ConsumeTypeId value, JsonSerializer serializer) => writer.WriteValue(value.Value);
    }

    public class DateTimeConverter : JsonConverter<DateTime>
    {
        private static readonly string[] SupportedFormats = new[]
        {
        "yyyyMMddHHmmss",         // 사용자 정의 형식
        "yyyy-MM-ddTHH:mm:ssZ",   // ISO 8601
        "yyyy-MM-dd HH:mm:ss",    // 표준 문자열
        "yyyy-MM-ddTHH:mm:ss",    // ISO 8601 (Z 미포함)
        "yyyy/MM/dd HH:mm:ss"     // 기타 서버 응답용
        };

        public override DateTime ReadJson(JsonReader reader, Type objectType, DateTime existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            switch (reader.TokenType)
            {
                case JsonToken.Date:
                    if (reader.Value is DateTime dt)
                        return EconomyUtc.ToUtc(dt);
                    if (reader.Value is DateTimeOffset offset)
                        return offset.UtcDateTime;
                    break;

                case JsonToken.String:
                    var str = reader.Value.ToString();
                    foreach (var format in SupportedFormats)
                    {
                        if (DateTime.TryParseExact(str, format, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var parsed))
                            return parsed;
                    }

                    // 시간대가 없는 서버/저장 문자열도 UTC로 해석한다.
                    if (EconomyUtc.TryParseUtc(str, out var fallback))
                        return fallback;

                    break;
            }

            return DateTime.MinValue; // 실패 시 안전한 기본값
        }

        public override void WriteJson(JsonWriter writer, DateTime value, JsonSerializer serializer)
        {
            // 기본은 yyyyMMddHHmmss 형식으로 출력
            writer.WriteValue(EconomyUtc.ToUtc(value).ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture));
        }
    }

}
