using System;
using System.Globalization;

namespace jjevol
{
    // File/GUID retained. The former global EconomyRuntimeOptions and storage factories were removed.
    // This marker preserves the data/list boundary without importing an OSA adapter.
    public interface IListData { }

    // Independent UTC conversion used by DateTimeConverter; no configuration or game-state lookup.
    internal static class EconomyUtc
    {
        public static DateTime ToUtc(DateTime value) => value.Kind == DateTimeKind.Unspecified ?
            DateTime.SpecifyKind(value, DateTimeKind.Utc) : value.ToUniversalTime();
        public static bool TryParseUtc(string value, out DateTime result)
        {
            const DateTimeStyles styles = DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal;
            return DateTime.TryParse(value, CultureInfo.InvariantCulture, styles, out result) ||
                DateTime.TryParseExact(value, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, styles, out result);
        }
    }
}
