using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace jjevol
{

    public sealed class LocalResourcePreparation
    {
        internal readonly RepositoryStorageAdapter Storage;
        internal readonly ResourceService Resources;
        internal readonly long Revision;
        internal readonly LocalSaveDocument Basis;
        internal readonly object Reservations;
        internal readonly ConsumeData[] Costs, Rewards;
        internal bool Committed;
        internal LocalResourcePreparation(RepositoryStorageAdapter storage, ResourceService resources, long revision, LocalSaveDocument basis, object reservations, ConsumeData[] costs, ConsumeData[] rewards)
        { Storage = storage; Resources = resources; Revision = revision; Basis = basis; Reservations = reservations; Costs = costs; Rewards = rewards; }
    }

    public static class LocalRewardService
    {

        public static LocalResourcePreparation PrepareMutation(RepositoryStorageAdapter storage, ResourceService resources, IEnumerable<ConsumeData> costs, IEnumerable<ConsumeData> rewards)
        {
            if (storage == null) throw new ArgumentNullException(nameof(storage));
            storage.EnsureLocalMutation(resources, resources?.Repository, resources?.Container.DataKey);
            DataRepository repository = storage.Repository;
            repository.BeginStorageChange(storage, false);
            try
            {
                ConsumeData[] capturedCosts = Capture(resources, costs), capturedRewards = Capture(resources, rewards);
                JObject candidate = CalculateContainer(resources, capturedCosts, capturedRewards);
                _ = repository.PrepareStored(candidate, true, new[] { resources.Container.DataKey });
                return new LocalResourcePreparation(storage, resources, repository.Revision, storage.Basis, resources.ReservationIdentity, capturedCosts, capturedRewards);
            }
            finally { repository.EndStorageChange(); }
        }

        public static void Commit(RepositoryStorageAdapter storage, ResourceService resources, LocalResourcePreparation preparation)
        {
            if (storage == null) throw new ArgumentNullException(nameof(storage));
            if (preparation == null) throw new ArgumentNullException(nameof(preparation));
            storage.EnsureLocalMutation(resources, resources?.Repository, resources?.Container.DataKey);
            DataRepository repository = storage.Repository;
            repository.BeginStorageChange(storage, false);
            try
            {
                if (preparation.Committed || !ReferenceEquals(storage, preparation.Storage) || !ReferenceEquals(resources, preparation.Resources) ||
                    preparation.Revision != repository.Revision || !ReferenceEquals(preparation.Basis, storage.Basis) || !ReferenceEquals(preparation.Reservations, resources.ReservationIdentity))
                    throw new LocalSaveConflictException();
                JObject candidate = CalculateContainer(resources, preparation.Costs, preparation.Rewards);
                storage.Persist(repository.PrepareStored(candidate, true, new[] { resources.Container.DataKey }));
                preparation.Committed = true;
            }
            finally { repository.EndStorageChange(); }
        }

        private static JObject CalculateContainer(ResourceService resources, IEnumerable<ConsumeData> costs, IEnumerable<ConsumeData> rewards)
        {
            Dictionary<int, long> required = Totals(resources, costs), granted = Totals(resources, rewards);
            JObject payload = resources.Container.ExportJson();
            var rows = (JArray)payload[resources.Container.DataKey];
            var byType = rows.Cast<JObject>().ToDictionary(row => row.Value<string>(WealthContainer.TypeKey), StringComparer.Ordinal);
            foreach (int id in required.Keys.Union(granted.Keys).OrderBy(id => id))
            {
                string key = resources.RequireWealthKey(id);
                required.TryGetValue(id, out long cost); granted.TryGetValue(id, out long reward);
                long raw = resources.GetRaw(id);
                long next = CalculateQuantity(id, raw, resources.Get(id), cost, reward);
                if (next == raw) continue;
                if (!byType.TryGetValue(key, out JObject row)) { row = new JObject { [WealthContainer.TypeKey] = key }; rows.Add(row); }
                row[WealthContainer.QuantityKey] = next;
            }
            return payload;
        }

        private static long CalculateQuantity(int id, long current, long available, long cost, long reward)
        {
            if (available < cost) throw new InsufficientResourceException(id, available, cost);
            return checked(current - cost + reward);
        }

        private static ConsumeData[] Capture(ResourceService resources, IEnumerable<ConsumeData> values)
        {
            if (values == null) throw new ArgumentNullException(nameof(values));
            var result = new List<ConsumeData>();
            foreach (ConsumeData value in values)
            {
                if (value == null) throw new ArgumentException("A local resource request contains a null entry.", nameof(values));
                _ = resources.GetRaw(value.TypeId, value.ItemId);
                if (value.IsRandomVal) throw new NotSupportedException("Resolve random quantities before preparing local resources.");
                long quantity = value.Quantity;
                if (quantity < 0) throw new ArgumentOutOfRangeException(nameof(values), "Resource quantities must be nonnegative.");
                resources.RequireWealthKey(value.ItemId);
                result.Add(new ConsumeData(value.TypeId, value.ItemId, quantity));
            }
            return result.ToArray();
        }

        private static Dictionary<int, long> Totals(ResourceService resources, IEnumerable<ConsumeData> values)
        {
            var totals = new Dictionary<int, long>();
            foreach (ConsumeData value in values)
            {
                resources.RequireWealthKey(value.ItemId);
                totals.TryGetValue(value.ItemId, out long previous);
                totals[value.ItemId] = checked(previous + value.Quantity);
            }
            return totals;
        }

    }
}
