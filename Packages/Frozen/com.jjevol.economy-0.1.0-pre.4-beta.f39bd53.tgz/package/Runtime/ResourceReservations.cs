using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace jjevol
{
    public enum ResourceRequestFailure { KnownNotApplied, Uncertain }

    /// <summary>Opaque handle for one transmitted batch in one service lifetime.</summary>
    public sealed class ResourceRequest
    {
        internal object Owner { get; }
        public string ProfileId { get; }
        /// <summary>Order of requests within one service lifetime. It restarts at 1 with each new service and app run, so never use it as a server idempotency key.</summary>
        public long Sequence { get; }
        internal ResourceRequest(object owner, string profileId, long sequence)
        { Owner = owner; ProfileId = profileId; Sequence = sequence; }
    }

    public sealed partial class ResourceService : IRepositoryOverlay
    {
        internal sealed class ReservationState
        {
            internal readonly Dictionary<int, long> Pending, InFlight;
            internal readonly ResourceRequest Request;
            internal readonly bool Uncertain;
            internal ReservationState(Dictionary<int, long> pending, Dictionary<int, long> inFlight, ResourceRequest request = null, bool uncertain = false)
            { Pending = pending; InFlight = inFlight; Request = request; Uncertain = uncertain; }
        }

        internal sealed class PreparedResources
        {
            internal readonly ReservationState State;
            internal readonly ResourceChange Notice;
            internal PreparedResources(ReservationState state, ResourceChange notice) { State = state; Notice = notice; }
        }

        private readonly object _requestOwner = new object();
        private Dictionary<int, string> _bindings;
        private ReservationState _reservations = EmptyReservations();
        private long _requestSequence, _resourceRevision;
        public DataRepository Repository { get; }
        public WealthContainer Container { get; }
        public ConsumeTypeId WealthTypeId { get; }
        public bool IsDisposed { get; private set; }
        public bool RequiresResynchronization { get { EnsureContainerAccess(); return _reservations.Uncertain; } }
        public ResourceRequest InFlightRequest { get { EnsureContainerAccess(); return _reservations.Request; } }
        public event Action<ResourceChange> Changed;

        /// <summary>Bind a game's wire kind to the repository's existing wealth container. Definitions are captured as metadata only.</summary>
        public ResourceService(DataRepository repository, WealthTable definitions, ConsumeTypeId wealthTypeId)
        {
            Repository = repository ?? throw new ArgumentNullException(nameof(repository));
            Definitions = definitions ?? throw new ArgumentNullException(nameof(definitions));
            Container = repository.Get<WealthContainer>(WealthContainer.PayloadKey);
            WealthTypeId = wealthTypeId;
            _bindings = definitions.Dict.ToDictionary(pair => pair.Key, pair => pair.Value.type);
            repository.AttachOverlay(this);
        }

        internal static ReservationState EmptyReservations() => new ReservationState(new Dictionary<int, long>(), new Dictionary<int, long>());
        internal object ReservationIdentity => _reservations;
        internal string RequireWealthKey(int itemId) => Binding(WealthTypeId, itemId);
        private void EnsureContainerAccess()
        {
            if (IsDisposed) throw new ObjectDisposedException(nameof(ResourceService));
            Repository.EnsureOverlayAccess(this);
        }

        private string Binding(ConsumeTypeId type, int item)
        {
            EnsureContainerAccess();
            if (type != WealthTypeId) throw new NotSupportedException("This resource kind is not connected: " + type);
            return _bindings.TryGetValue(item, out string key) ? key : throw new ArgumentException("Unknown wealth item ID: " + item, nameof(item));
        }

        public long GetRaw(int itemId) => GetRaw(WealthTypeId, itemId);
        public long GetRaw(ConsumeTypeId typeId, int itemId) => Container.Get(Binding(typeId, itemId));
        public long GetRaw(ConsumeData value) => value == null ? throw new ArgumentNullException(nameof(value)) : GetRaw(value.TypeId, value.ItemId);
        public long Get(ConsumeTypeId typeId, int itemId)
        {
            long raw = GetRaw(typeId, itemId);
            return Available(raw, _reservations, itemId);
        }

        private static long Reserved(ReservationState state, int id)
        { state.Pending.TryGetValue(id, out long pending); state.InFlight.TryGetValue(id, out long flight); return checked(pending + flight); }
        private static long Available(long raw, ReservationState state, int id) => Math.Max(0, checked(raw - Reserved(state, id)));

        private Dictionary<int, long> Costs(IEnumerable<ConsumeData> costs)
        {
            if (costs == null) throw new ArgumentNullException(nameof(costs));
            var result = new Dictionary<int, long>();
            foreach (ConsumeData cost in costs)
            {
                if (cost == null) throw new ArgumentException("A cost is null.", nameof(costs));
                Binding(cost.TypeId, cost.ItemId);
                if (cost.IsRandomVal) throw new NotSupportedException("Resolve range costs before reserving.");
                if (cost.Quantity < 0) throw new ArgumentOutOfRangeException(nameof(costs), "Costs must be nonnegative.");
                result.TryGetValue(cost.ItemId, out long previous);
                result[cost.ItemId] = checked(previous + cost.Quantity);
            }
            return result;
        }

        private bool CheckContainerSpend(IEnumerable<ConsumeData> costs)
        {
            EnsureContainerAccess();
            bool entered = Repository.BeginOverlayRead(this);
            try { foreach (var pair in Costs(costs)) if (Get(pair.Key) < pair.Value) return false; return true; }
            finally { if (entered) Repository.EndOverlayChange(); }
        }

        public void Reserve(IEnumerable<ConsumeData> costs)
        {
            EnsureContainerAccess();
            Repository.BeginOverlayChange(this);
            try
            {
                if (_reservations.Uncertain) throw new InvalidOperationException("Resynchronize before reserving more costs.");
                var pending = new Dictionary<int, long>(_reservations.Pending);
                foreach (var pair in Costs(costs))
                {
                    pending.TryGetValue(pair.Key, out long prior);
                    long amount = checked(prior + pair.Value);
                    _reservations.InFlight.TryGetValue(pair.Key, out long flight);
                    _ = checked(amount + flight);
                    long available = Get(pair.Key);
                    if (available < pair.Value) throw new InsufficientResourceException(pair.Key, available, pair.Value);
                    if (amount != 0) pending[pair.Key] = amount;
                }
                Repository.ApplyOverlay(this, new ReservationState(pending, _reservations.InFlight, _reservations.Request));
            }
            finally { Repository.EndOverlayChange(); }
        }

        public void CancelPending()
        {
            EnsureContainerAccess();
            Repository.BeginOverlayChange(this);
            try { Repository.ApplyOverlay(this, new ReservationState(new Dictionary<int, long>(), _reservations.InFlight, _reservations.Request, _reservations.Uncertain)); }
            finally { Repository.EndOverlayChange(); }
        }

        public ResourceRequest BeginRequest()
        {
            EnsureContainerAccess();
            Repository.BeginOverlayChange(this);
            try
            {
                if (_reservations.Uncertain || _reservations.Request != null) throw new InvalidOperationException("An unresolved request already exists.");
                if (_reservations.Pending.Count == 0) return null;
                long sequence = checked(_requestSequence + 1);
                var request = new ResourceRequest(_requestOwner, Repository.ProfileId, sequence);
                Repository.ApplyOverlay(this, new ReservationState(new Dictionary<int, long>(), _reservations.Pending, request));
                _requestSequence = sequence;
                return request;
            }
            finally { Repository.EndOverlayChange(); }
        }

        private void RequireRequest(ResourceRequest request)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (!ReferenceEquals(request.Owner, _requestOwner) || !ReferenceEquals(request, _reservations.Request))
                throw new InvalidOperationException("Stale, duplicate or foreign resource request.");
        }

        /// <summary>Use KnownNotApplied only when the transport/game can prove the server did not commit.</summary>
        public void FailRequest(ResourceRequest request, ResourceRequestFailure failure)
        {
            EnsureContainerAccess();
            Repository.BeginOverlayChange(this);
            try
            {
                RequireRequest(request);
                if (failure != ResourceRequestFailure.KnownNotApplied && failure != ResourceRequestFailure.Uncertain) throw new ArgumentOutOfRangeException(nameof(failure));
                if (_reservations.Uncertain && failure == ResourceRequestFailure.KnownNotApplied) throw new InvalidOperationException("An uncertain request requires authoritative reconciliation.");
                var next = failure == ResourceRequestFailure.Uncertain
                    ? new ReservationState(_reservations.Pending, _reservations.InFlight, request, true)
                    : new ReservationState(_reservations.Pending, new Dictionary<int, long>());
                Repository.ApplyOverlay(this, next);
            }
            finally { Repository.EndOverlayChange(); }
        }

        /// <summary>Apply an authoritative response and remove this request's hold before any observer can run. This is not a durable local commit.</summary>
        public void ApplyServerResponse(ResourceRequest request, JObject response, bool replace, params string[] targetKeys)
        {
            EnsureContainerAccess();
            Repository.BeginOverlayChange(this);
            try
            {
                RequireRequest(request);
                try
                {
                    RequireWealthResponse(response, targetKeys, replace ? null : _reservations.InFlight);
                    Repository.ChangeWithOverlay(this, new ReservationState(_reservations.Pending, new Dictionary<int, long>()), response, replace, targetKeys);
                }
                catch
                {
                    // Parsing/validation failed before commit. Keep all holds; transport success alone is insufficient.
                    _reservations = new ReservationState(_reservations.Pending, _reservations.InFlight, request, true);
                    throw;
                }
            }
            finally { Repository.EndOverlayChange(); }
        }

        /// <summary>After an uncertain outcome, apply a fresh full authoritative snapshot and discard all previews atomically.</summary>
        public void Resynchronize(JObject fullResponse, params string[] targetKeys)
        {
            EnsureContainerAccess();
            Repository.BeginOverlayChange(this);
            try
            {
                if (!_reservations.Uncertain) throw new InvalidOperationException("No uncertain request requires reconciliation.");
                RequireWealthResponse(fullResponse, targetKeys, null);
                Repository.ChangeWithOverlay(this, EmptyReservations(), fullResponse, true, targetKeys);
            }
            finally { Repository.EndOverlayChange(); }
        }

        private void RequireWealthResponse(JObject response, string[] targets, Dictionary<int, long> acknowledged)
        {
            if (response == null) throw new ArgumentNullException(nameof(response));
            if (targets == null || !targets.Contains(Container.DataKey)) throw new InvalidDataException("Explicitly target the wealth container in a resource response.");
            JArray rows = ContainerJson.RequireArray(response, Container.DataKey);
            if (acknowledged == null) return;
            var covered = new HashSet<string>(StringComparer.Ordinal);
            foreach (JToken token in rows)
                if (token is JObject row && row[WealthContainer.QuantityKey] != null)
                { ContainerJson.RequireInt64(row, WealthContainer.QuantityKey); covered.Add(ContainerJson.RequireKey(row, WealthContainer.TypeKey)); }
            foreach (int id in acknowledged.Keys)
                if (!covered.Contains(_bindings[id])) throw new InvalidDataException("A partial response omitted a reserved resource quantity.");
        }

        internal PreparedResources PrepareResources(IReadOnlyList<DataContainer.PreparedChange> plans, ReservationState next, long repositoryRevision)
        {
            next ??= _reservations;
            DataContainer.PreparedChange wealth = plans.FirstOrDefault(plan => ReferenceEquals(plan.Notice.Container, Container));
            var keys = new List<int>();
            bool rawChanged = false, availableChanged = false;
            foreach (var binding in _bindings.OrderBy(pair => pair.Key))
            {
                long before = Container.Get(binding.Value);
                long after = wealth == null ? before : Container.ReadPreparedQuantity(wealth, binding.Value);
                bool raw = before != after, available = Available(before, _reservations, binding.Key) != Available(after, next, binding.Key);
                if (raw || available) { keys.Add(binding.Key); rawChanged |= raw; availableChanged |= available; }
            }
            ResourceChange notice = keys.Count == 0 ? null : new ResourceChange(this, checked(_resourceRevision + 1), repositoryRevision, keys.ToArray(), rawChanged, availableChanged);
            return new PreparedResources(next, notice);
        }

        internal void ApplyResources(PreparedResources prepared)
        { _reservations = prepared.State; if (prepared.Notice != null) _resourceRevision = prepared.Notice.Revision; }
        internal void NotifyResources(ResourceChange change)
        {
            if (change == null) return;
            var subscribers = Changed;
            if (subscribers == null) return;
            foreach (Action<ResourceChange> subscriber in subscribers.GetInvocationList())
                try { subscriber(change); } catch (Exception exception) { Debug.LogException(exception); }
        }

        // Reservations are published by DataRepository in the same atomic step as container changes.
        bool IRepositoryOverlay.OverlayRequiresResynchronization => RequiresResynchronization;
        object IRepositoryOverlay.EmptyOverlayState() => EmptyReservations();
        object IRepositoryOverlay.PrepareOverlay(IReadOnlyList<DataContainer.PreparedChange> plans, object nextState, long repositoryRevision)
            => PrepareResources(plans, (ReservationState)nextState, repositoryRevision);
        void IRepositoryOverlay.ApplyOverlay(object prepared) => ApplyResources((PreparedResources)prepared);
        void IRepositoryOverlay.NotifyOverlay(object prepared) => NotifyResources(((PreparedResources)prepared).Notice);
        void IRepositoryOverlay.ReleaseOverlay() => ReleaseResources();

        internal void ReleaseResources()
        { _reservations = EmptyReservations(); Changed = null; IsDisposed = true; }
        public void Dispose()
        {
            if (IsDisposed) return;
            EnsureContainerAccess();
            Repository.DetachOverlay(this);
        }
    }
}
