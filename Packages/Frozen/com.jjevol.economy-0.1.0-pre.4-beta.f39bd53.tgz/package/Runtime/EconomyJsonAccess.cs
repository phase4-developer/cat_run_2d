using Newtonsoft.Json.Linq;
using System;
namespace jjevol
{
    internal static class EconomyJsonAccess
    {
        public static JToken Get(this JObject obj, string name) => obj.TryGetValue(name, out var token) && token.Type != JTokenType.Null ? token : null;
        public static int GetInt(this Newtonsoft.Json.Linq.JObject obj, string name) => obj.GetInt(name, 0);
        public static int GetInt(this Newtonsoft.Json.Linq.JObject obj, string name, int defaultValue)
        {
            if (!obj.TryGetValue(name, out var token) || token.Type == JTokenType.Null)
                return defaultValue;

            try
            {
                // Double은 int 범위를 정밀도 손실 없이 표현 가능하므로 double로 변환 후 비교
                double val = token.ToObject<double>();

                if (val >= int.MaxValue) return int.MaxValue;
                if (val <= int.MinValue) return int.MinValue;

                return (int)val;
            }
            catch
            {
                return defaultValue;
            }
        }
        public static long GetLong(this Newtonsoft.Json.Linq.JObject obj, string name) => obj.GetLong(name, 0);

        public static long GetLong(this Newtonsoft.Json.Linq.JObject obj, string name, long defaultValue)
        {
            if (!obj.TryGetValue(name, out var token) || token.Type == JTokenType.Null)
                return defaultValue;

            try
            {
                // 1. Decimal로 변환 시도 (Decimal 범위: ±7.9 x 10^28 > Long 범위: ±9 x 10^18)
                // Long보다 크고 정밀한 Decimal을 사용하여 값을 확인합니다.
                decimal val = token.ToObject<decimal>();

                if (val >= long.MaxValue) return long.MaxValue;
                if (val <= long.MinValue) return long.MinValue;

                return (long)val;
            }
            catch (OverflowException)
            {
                // 2. Decimal 범위조차 넘어서는 초거대 수(예: 10^100)일 경우
                // Double로 변환하여 부호(양수/음수)만 판별해 Max/Min 반환
                try
                {
                    double dVal = token.ToObject<double>();
                    return dVal > 0 ? long.MaxValue : long.MinValue;
                }
                catch
                {
                    return defaultValue;
                }
            }
            catch
            {
                return defaultValue;
            }
        }

    }
}
