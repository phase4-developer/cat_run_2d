using System;
using System.Collections.Generic;
using System.Linq;

namespace jjevol
{
    public readonly struct ConsumePresentation
    {
        public TableData Table { get; }
        public string Name { get; }
        public string Description { get; }
        public string Icon { get; }
        public string Atlas { get; }
        public int Grade { get; }
        public ConsumePresentation(TableData table = null, string icon = "", string atlas = "", string name = null, string description = null, int? grade = null)
        { Table = table; Name = name ?? table?.name ?? ""; Description = description ?? table?.description ?? ""; Icon = icon; Atlas = atlas; Grade = grade ?? table?.grade ?? 1; }
    }

    public interface IConsumePresentationProvider
    {
        /// <summary>Static metadata for the exact game type/item pair. False means unresolved, not an empty display string.
        /// Implementations must not create a ConsumeData or substitute another type/item on failure.</summary>
        bool TryResolve(ConsumeTypeId typeId, int itemId, out ConsumePresentation presentation);
        /// <summary>Data-dependent presentation; quantity/Source semantics remain game-owned.</summary>
        ConsumePresentation Resolve(ConsumeData data);
    }

    /// <summary>Explicit game boundaries; no registration, globals or built-in kind dispatch.</summary>
    public static class ConsumeDataGameExtensions
    {
        public static ConsumePresentation Present(this ConsumeData data, IConsumePresentationProvider provider)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            return provider.Resolve(data.Clone());
        }

        public static ConsumeData FromItem(TableData item, Func<TableData, ConsumeData> convert)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));
            if (convert == null) throw new ArgumentNullException(nameof(convert));
            return (convert(item) ?? throw new InvalidOperationException("The game returned no consume data.")).Clone();
        }

        public static List<ConsumeData> DropReward(this ConsumeData data, Func<ConsumeData, List<ConsumeData>> resolve)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (resolve == null) throw new ArgumentNullException(nameof(resolve));
            return Copy(resolve(data.Clone()));
        }

        public static List<ConsumeData> GetDropList(this ConsumeData data, Func<ConsumeData, ConsumeTypeId, List<ConsumeData>> resolve, ConsumeTypeId filter = default)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (resolve == null) throw new ArgumentNullException(nameof(resolve));
            return Copy(resolve(data.Clone(), filter));
        }

        private static List<ConsumeData> Copy(List<ConsumeData> values)
        {
            if (values == null || values.Any(value => value == null)) throw new InvalidOperationException("The game returned an invalid reward list.");
            return values.Select(value => value.Clone()).ToList();
        }
    }
}
