using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Newtonsoft.Json.Linq;

namespace jjevol
{
    internal static class ConsumeJson
    {
        internal static bool ReadLong(IEnumerable<JObject> scopes, string[] aliases, out long value)
        {
            bool present = false;
            value = 0;
            foreach (JObject scope in scopes)
                foreach (string name in aliases)
                {
                    if (scope.TryGetValue(name, out JToken token) && token.Type == JTokenType.Null) throw new InvalidDataException("Explicit null is not allowed: " + name);
                    if (ContainerJson.TryReadInt64(scope, name, out long parsed))
                    {
                        if (present && value != parsed) throw new InvalidDataException("Conflicting aliases for " + aliases[0]);
                        value = parsed; present = true;
                    }
                }
            return present;
        }

        internal static bool ReadInt(IEnumerable<JObject> scopes, string[] aliases, out int value)
        {
            bool present = ReadLong(scopes, aliases, out long number);
            if (number < int.MinValue || number > int.MaxValue) throw new InvalidDataException("ID exceeds the int range: " + aliases[0]);
            value = (int)number;
            return present;
        }

        internal static int IntToken(JToken token, string name)
        {
            ReadInt(new[] { new JObject { [name] = token } }, new[] { name }, out int value);
            return value;
        }

        internal static long TsvLong(string value) => long.Parse(value ?? throw new InvalidDataException("A TSV quantity is null."), NumberStyles.Integer, CultureInfo.InvariantCulture);
        internal static int TsvInt(string value) => int.Parse(value ?? throw new InvalidDataException("A TSV ID is null."), NumberStyles.Integer, CultureInfo.InvariantCulture);

        // Numeric wire IDs are common; names require an explicit game-owned parser.
        internal static ConsumeTypeId TsvType(string value, Func<string, ConsumeTypeId> parseType = null)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new FormatException("A TSV type ID is required.");
            string text = value.Trim();
            if (text[0] == '+' || text[0] == '-' || (text[0] >= '0' && text[0] <= '9')) return new ConsumeTypeId(TsvInt(text));
            if (parseType != null) return parseType(text);
            throw new FormatException("A named TSV type requires the game's explicit type parser: " + text);
        }
    }
}
