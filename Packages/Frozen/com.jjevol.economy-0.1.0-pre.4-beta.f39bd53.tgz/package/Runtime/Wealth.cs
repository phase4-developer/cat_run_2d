using Newtonsoft.Json.Linq;

namespace jjevol
{
    /// <summary>A read-only item handle. Values belong to its container, not to this view.</summary>
    public sealed class Wealth
    {
        private readonly WealthContainer _container;
        public string wealthType { get; }
        public long quantity => _container.ReadQuantity(this);
        internal Wealth(WealthContainer container, string type) { _container = container; wealthType = type; }
        public JObject ExportJson() => _container.ExportItem(this);
    }
}
