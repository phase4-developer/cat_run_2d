using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace jjevol
{
    /// <summary>Explicit model JSON contract. Constructors never dispatch to a virtual parser.</summary>
    [JsonConverter(typeof(RHJsonDataConverter))]
    public abstract class JsonDataBase : ListDataBase
    {
        protected JsonDataBase() { }
        public abstract bool ImportJson(JObject data);
        public abstract bool UpdateJson(JObject data);
        public abstract JObject ExportJson();
        public override string ToString() => ExportJson().ToString(Formatting.None);
        public virtual bool CompareModel(JsonDataBase other) => ReferenceEquals(this, other);
        public virtual void AssignFrom(JsonDataBase other)
        {
            if (other == null) throw new ArgumentNullException(nameof(other));
            ImportJson(other.ExportJson());
        }
    }
}
