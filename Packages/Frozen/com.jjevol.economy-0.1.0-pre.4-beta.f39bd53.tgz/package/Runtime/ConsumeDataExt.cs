using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace jjevol
{
    public static class ConsumeDataExt
    {
        public static ConsumeData FindConsume(this List<ConsumeData> list, ConsumeTypeId type)
            => (list ?? throw new ArgumentNullException(nameof(list))).Find(value => value != null && value.TypeId == type);
        public static bool ContainConsume(this List<ConsumeData> list, ConsumeTypeId type) => FindConsume(list, type) != null;

        public static bool TryParseUniqueID(string uniqueId, out ConsumeTypeId type, out int itemId)
        {
            type = default; itemId = 0;
            if (uniqueId == null) return false;
            int split = uniqueId.IndexOf('_');
            if (split <= 0 || split != uniqueId.LastIndexOf('_') || !int.TryParse(uniqueId.Substring(split + 1), NumberStyles.Integer, CultureInfo.InvariantCulture, out itemId)) return false;
            try { type = ConsumeJson.TsvType(uniqueId.Substring(0, split)); return true; }
            catch (Exception exception) when (exception is FormatException || exception is OverflowException) { type = default; itemId = 0; return false; }
        }

        public static void ImportDatas(this TSVRow row, bool IsReward, out List<ConsumeData> values)
            => ImportDatas(row, out values, IsReward ? "rewardType" : "priceType", IsReward ? "rewardId" : "priceId", IsReward ? "rewardValue" : "priceValue");

        public static void ImportDatas(this TSVRow row, out List<ConsumeData> values, string typeKey, string idKey, string valueKey, Func<string, ConsumeTypeId> parseType = null)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            var result = new List<ConsumeData>();
            bool hasType = row.Contains(typeKey), hasId = row.Contains(idKey), scalar = row.Contains(valueKey);
            bool hasMin = row.Contains(valueKey + "_min"), hasMax = row.Contains(valueKey + "_max");
            if (!hasType && !hasId && !scalar && !hasMin && !hasMax) { values = result; return; }
            if (!hasType || !hasId || (!scalar && (!hasMin || !hasMax))) throw new InvalidDataException("Incomplete TSV consume list.");
            string[] types = Parts(row.Get(typeKey)), ids = Parts(row.Get(idKey));
            string[] mins = Parts(row.Get(scalar ? valueKey : valueKey + "_min"));
            string[] maxs = scalar ? mins : Parts(row.Get(valueKey + "_max"));
            if (maxs.Length != mins.Length || types.Length > mins.Length || ids.Length > mins.Length) throw new InvalidDataException("Mismatched TSV consume list lengths.");
            if (scalar && (hasMin || hasMax)) throw new InvalidDataException("Use a scalar or a range in a TSV consume list.");
            for (int i = 0; i < mins.Length; i++)
                result.Add(new ConsumeData(ConsumeJson.TsvType(types[Math.Min(i, types.Length - 1)], parseType),
                    ConsumeJson.TsvInt(ids[Math.Min(i, ids.Length - 1)]), ConsumeJson.TsvLong(mins[i]), ConsumeJson.TsvLong(maxs[i])));
            values = result; // No partially parsed output is published.
        }

        public static void ImportDatas(TSVRow row, out List<ConsumeData> values, string keyName)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            if (row.Contains(keyName + "Type") || row.Contains(keyName + "Id") || row.Contains(keyName + "Value"))
            {
                if (row.Contains(keyName + "Type_1")) throw new InvalidDataException("Do not mix scalar and indexed TSV consume layouts.");
                ImportDatas(row, out values, keyName + "Type", keyName + "Id", keyName + "Value"); return;
            }
            var result = new List<ConsumeData>();
            int i = 1;
            for (; row.Contains(keyName + "Type_" + i); i++)
                result.Add(new ConsumeData(ConsumeJson.TsvType(row.Get(keyName + "Type_" + i)), ConsumeJson.TsvInt(row.Get(keyName + "Id_" + i)), ConsumeJson.TsvLong(row.Get(keyName + "Value_" + i))));
            if (row.Contains(keyName + "Id_" + i) || row.Contains(keyName + "Value_" + i)) throw new InvalidDataException("Incomplete indexed TSV consume entry.");
            values = result;
        }

        private static string[] Parts(string value)
        {
            if (value == null) throw new InvalidDataException("A TSV consume list is null.");
            string[] parts = value.Split(';');
            if (parts.Any(string.IsNullOrWhiteSpace)) throw new FormatException("A TSV consume list contains an empty entry.");
            return parts;
        }

        public static List<ConsumeData> MergeList(List<ConsumeData> list)
        {
            var copies = Copy(list);
            var result = new List<ConsumeData>();
            var groups = new Dictionary<(ConsumeTypeId, int, bool), ConsumeData>();
            foreach (ConsumeData data in copies)
            {
                data.prefix_Progress = 0;
                if (data.HasSource) { result.Add(data); continue; }
                var key = (data.TypeId, data.ItemId, data.IsRewardResult);
                if (groups.TryGetValue(key, out ConsumeData group)) group.AddValue(data);
                else { groups.Add(key, data); result.Add(data); }
            }
            return result;
        }

        public static List<ConsumeData> CalcProgress(List<ConsumeData> list)
        {
            List<ConsumeData> result = Copy(list);
            var totals = new Dictionary<(ConsumeTypeId, int), long>();
            for (int i = result.Count - 1; i >= 0; i--)
            {
                ConsumeData data = result[i];
                if (data.IsRandomVal) throw new InvalidOperationException("Resolve range quantities before calculating progress.");
                totals.TryGetValue(data.Key, out long later);
                data.prefix_Progress = later;
                totals[data.Key] = checked(later + data.Quantity);
            }
            return result;
        }

        public static List<ConsumeData> Filter(List<ConsumeData> list, List<ConsumeTypeId> excluded)
        {
            if (excluded == null) throw new ArgumentNullException(nameof(excluded));
            return Copy(list).Where(data => !excluded.Contains(data.TypeId)).ToList();
        }
        private static List<ConsumeData> Copy(List<ConsumeData> list)
        {
            if (list == null) throw new ArgumentNullException(nameof(list));
            if (list.Any(data => data == null)) throw new ArgumentException("A consume list contains a null entry.", nameof(list));
            return list.Select(data => data.Clone()).ToList();
        }
    }
}
