using System;

namespace jjevol
{
    /// <summary>Container-path invalidation only. UI re-queries the service; no independent UI balance state.</summary>
    public sealed class ResourceChange
    {
        public ResourceService Service { get; }
        public DataRepository Repository => Service.Repository;
        public string ProfileId => Repository.ProfileId;
        public ConsumeTypeId TypeId => Service.WealthTypeId;
        public long Revision { get; }
        public long RepositoryRevision { get; }
        public System.Collections.Generic.IReadOnlyList<int> ItemIds { get; }
        public bool RawChanged { get; }
        public bool AvailableChanged { get; }
        internal ResourceChange(ResourceService service, long revision, long repositoryRevision, int[] ids, bool raw, bool available)
        { Service = service; Revision = revision; RepositoryRevision = repositoryRevision; ItemIds = Array.AsReadOnly(ids); RawChanged = raw; AvailableChanged = available; }
    }

}
