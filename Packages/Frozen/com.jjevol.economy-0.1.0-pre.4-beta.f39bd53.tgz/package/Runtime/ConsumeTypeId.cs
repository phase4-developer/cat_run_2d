using System;
using System.Globalization;
using Newtonsoft.Json;

namespace jjevol
{
    /// <summary>A game's stable wire type ID. Has no built-in execution or game-kind policy.</summary>
    [JsonConverter(typeof(ConsumeTypeIdJsonConverter))]
    public readonly struct ConsumeTypeId : IEquatable<ConsumeTypeId>
    {
        public int Value { get; }
        public ConsumeTypeId(int value) { Value = value; }
        public bool Equals(ConsumeTypeId other) => Value == other.Value;
        public override bool Equals(object other) => other is ConsumeTypeId id && Equals(id);
        public override int GetHashCode() => Value;
        public override string ToString() => Value.ToString(CultureInfo.InvariantCulture);
        public static bool operator ==(ConsumeTypeId left, ConsumeTypeId right) => left.Equals(right);
        public static bool operator !=(ConsumeTypeId left, ConsumeTypeId right) => !left.Equals(right);
        public static explicit operator ConsumeTypeId(int value) => new ConsumeTypeId(value);
        public static explicit operator int(ConsumeTypeId value) => value.Value;
    }
}
