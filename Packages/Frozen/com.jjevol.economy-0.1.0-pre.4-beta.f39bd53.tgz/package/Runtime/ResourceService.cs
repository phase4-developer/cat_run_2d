using System;
using System.Collections.Generic;
namespace jjevol
{
    public sealed class InsufficientResourceException : InvalidOperationException
    {
        public int ResourceId { get; }
        public long Available { get; }
        public long Required { get; }
        public InsufficientResourceException(int resourceId, long available, long required) : base("Not enough local wealth: " + resourceId)
        { ResourceId = resourceId; Available = available; Required = required; }
    }

    public sealed partial class ResourceService : IDisposable
    {
        public WealthTable Definitions { get; }
        public long Get(int resourceId) => Get(WealthTypeId, resourceId);
        public long Get(ConsumeData data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            return Get(data.TypeId, data.ItemId);
        }
        // Advisory amount check. Durable Commit revalidates the current repository/document basis.
        public bool CheckSpend(IEnumerable<ConsumeData> costs) => CheckContainerSpend(costs);
        public bool CheckSpend(ConsumeData cost)
        {
            if (cost == null) throw new ArgumentNullException(nameof(cost));
            return CheckSpend(new[] { cost });
        }
    }
}
