using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace jjevol
{
    /// <summary>Pure consume/reward data. Signed quantities are data; services validate executable costs/rewards.</summary>
    public sealed class ConsumeData : JsonDataBase, IListData
    {
        private sealed class ValueState
        {
            internal readonly ConsumeTypeId Type;
            internal readonly int Id;
            internal readonly long Min, Max, Progress;
            internal readonly ValueState Source;
            internal readonly bool Reward;
            internal ValueState(ConsumeTypeId type, int id, long min, long max, ValueState source = null, bool reward = false, long progress = 0)
            {
                if (min > max) throw new ArgumentOutOfRangeException(nameof(min), "Minimum quantity exceeds maximum.");
                Type = type; Id = id; Min = min; Max = max; Source = source; Reward = reward; Progress = progress;
            }
        }

        private static readonly ValueState Empty = new ValueState(default, 0, 0, 0);
        private ValueState _value = Empty;
        public ConsumeTypeId TypeId => _value.Type;
        public int ItemId => _value.Id;
        public long Quantity => _value.Min;
        public long Min => _value.Min;
        public long Max => _value.Max;
        public (ConsumeTypeId TypeId, int ItemId) Key => (TypeId, ItemId);
        public string UniqueID => TypeId.ToString() + "_" + ItemId.ToString(CultureInfo.InvariantCulture);
        public bool IsRandomVal => Min != Max;
        public bool IsRewardResult => _value.Reward;
        public bool HasSource => _value.Source != null;
        public ConsumeData sourceData => _value.Source == null ? null : new ConsumeData(_value.Source);
        public ConsumeData prevRewardData => sourceData;

        // Scalar conveniences share the canonical value state and retain wire field terminology.
        public int consumeId { get => ItemId; set => _value = new ValueState(TypeId, value, Min, Max, _value.Source, IsRewardResult, prefix_Progress); }
        public long consumeVal => Quantity;
        public long consumeVal_min { get => Min; set => SetRange(value, Max); }
        public long consumeVal_max { get => Max; set => SetRange(Min, value); }
        public long prefix_Progress { get => _value.Progress; set => _value = new ValueState(TypeId, ItemId, Min, Max, _value.Source, IsRewardResult, value); }

        public ConsumeData() { }
        private ConsumeData(ValueState value) { _value = value; }
        public ConsumeData(JObject data) { _value = Parse(data, Empty, false, 0); }
        public ConsumeData(ConsumeTypeId typeId, int itemId, long quantity) { _value = new ValueState(typeId, itemId, quantity, quantity); }
        public ConsumeData(ConsumeTypeId typeId, int itemId, long min, long max) { _value = new ValueState(typeId, itemId, min, max); }

        public void SetData(ConsumeTypeId typeId, int itemId, long quantity) => _value = new ValueState(typeId, itemId, quantity, quantity);
        public void SetData(ConsumeData other)
        {
            if (other == null) throw new ArgumentNullException(nameof(other));
            _value = other._value; // Immutable value/source states can be shared; wrappers mutate by replacement only.
        }
        public void SetConsumeVal(long quantity) => _value = new ValueState(TypeId, ItemId, quantity, quantity, _value.Source, IsRewardResult, prefix_Progress);
        public void SetRange(long min, long max) => _value = new ValueState(TypeId, ItemId, min, max, _value.Source, IsRewardResult, prefix_Progress);

        public ConsumeData Clone(long fixValue = 1)
        {
            long a = checked(Min * fixValue), b = checked(Max * fixValue);
            return new ConsumeData(new ValueState(TypeId, ItemId, Math.Min(a, b), Math.Max(a, b), _value.Source, IsRewardResult, prefix_Progress));
        }

        public void SetRewardResult(ConsumeData sourceData = null)
        {
            ValueState source = sourceData?._value;
            int depth = 0;
            for (ValueState current = source; current != null; current = current.Source)
                if (++depth >= 64) throw new InvalidOperationException("Reward source nesting is too deep.");
            _value = new ValueState(TypeId, ItemId, Min, Max, source, true, prefix_Progress);
        }

        public void AddValue(ConsumeData other)
        {
            if (other == null) throw new ArgumentNullException(nameof(other));
            if (Key != other.Key) throw new ArgumentException("Only identical consume keys can be added.", nameof(other));
            long min = checked(Min + other.Min), max = checked(Max + other.Max);
            SetRange(min, max);
        }

        public override bool ImportJson(JObject data) { ValueState next = Parse(data, Empty, false, 0); _value = next; return true; }
        public override bool UpdateJson(JObject data) { ValueState next = Parse(data, _value, true, 0); _value = next; return true; }
        public override JObject ExportJson() => Write(_value);
        public override bool CompareModel(JsonDataBase other) => other is ConsumeData value && Key == value.Key;

        private static readonly string[] Types = { "consumeType", "rewardType", "priceType", "sellType" };
        private static readonly string[] Ids = { "consumeId", "rewardId", "priceId", "sellId" };
        private static readonly string[] Values = { "consumeVal", "consumeValue", "rewardValue", "priceValue", "sellValue" };
        private static readonly string[] Mins = { "consumeVal_min", "consumeValue_min", "rewardValue_min", "priceValue_min", "sellValue_min" };
        private static readonly string[] Maxs = { "consumeVal_max", "consumeValue_max", "rewardValue_max", "priceValue_max", "sellValue_max" };
        private static readonly string[] PreviousTypes = { "prevConsumeType", "prevRewardType" };
        private static readonly string[] PreviousIds = { "prevConsumeId", "prevRewardId" };
        private static readonly string[] PreviousValues = { "prevConsumeVal", "prevConsumeValue", "prevRewardValue" };

        private static ValueState Parse(JObject data, ValueState basis, bool patch, int depth)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (depth >= 64) throw new InvalidDataException("Reward source nesting is too deep.");
            var scopes = new List<JObject> { data };
            bool envelope = data.TryGetValue("grantedData", out JToken granted);
            if (envelope)
            {
                if (granted is not JObject body || body.ContainsKey("grantedData")) throw new InvalidDataException("grantedData must be a consume object.");
                scopes.Add(body);
            }
            bool hasType = ConsumeJson.ReadInt(scopes, Types, out int type);
            bool hasId = ConsumeJson.ReadInt(scopes, Ids, out int id);
            bool hasValue = ConsumeJson.ReadLong(scopes, Values, out long value);
            bool hasMin = ConsumeJson.ReadLong(scopes, Mins, out long min);
            bool hasMax = ConsumeJson.ReadLong(scopes, Maxs, out long max);
            if (!patch && (!hasType || !hasId || (!hasValue && (!hasMin || !hasMax))))
                throw new InvalidDataException("A full consume value requires type, item ID and quantity or a complete range.");
            if (hasValue)
            {
                if ((hasMin && min != value) || (hasMax && max != value)) throw new InvalidDataException("Scalar quantity conflicts with range aliases.");
                min = max = value;
            }
            else
            {
                if (!hasMin) min = basis.Min;
                if (!hasMax) max = basis.Max;
            }
            if (min > max) throw new InvalidDataException("Minimum quantity exceeds maximum.");

            ValueState source = patch ? basis.Source : null;
            bool sourceSeen = false;
            Action<ValueState> acceptSource = candidate =>
            {
                if (sourceSeen && !Same(source, candidate)) throw new InvalidDataException("Conflicting sourceData aliases.");
                source = candidate; sourceSeen = true;
            };
            foreach (JObject scope in scopes)
                foreach (string key in new[] { "sourceData", "prevRewardData" })
                    if (scope.TryGetValue(key, out JToken token))
                    {
                        if (token.Type == JTokenType.Null) acceptSource(null);
                        else if (token is JObject sourceJson) acceptSource(Parse(sourceJson, basis.Source ?? Empty, patch && basis.Source != null, depth + 1));
                        else throw new InvalidDataException(key + " must be an object or explicit null.");
                    }
            bool hasPreviousType = ConsumeJson.ReadInt(scopes, PreviousTypes, out int previousType);
            bool hasPreviousId = ConsumeJson.ReadInt(scopes, PreviousIds, out int previousId);
            bool hasPreviousValue = ConsumeJson.ReadLong(scopes, PreviousValues, out long previousValue);
            if (hasPreviousType || hasPreviousId || hasPreviousValue)
            {
                ValueState previous = patch ? basis.Source : null;
                if (previous == null && !(hasPreviousType && hasPreviousId && hasPreviousValue)) throw new InvalidDataException("Previous reward aliases require a complete consume value.");
                previous ??= Empty;
                acceptSource(new ValueState(hasPreviousType ? new ConsumeTypeId(previousType) : previous.Type,
                    hasPreviousId ? previousId : previous.Id, hasPreviousValue ? previousValue : previous.Min,
                    hasPreviousValue ? previousValue : previous.Max, previous.Source, previous.Reward));
            }
            return new ValueState(hasType ? new ConsumeTypeId(type) : basis.Type, hasId ? id : basis.Id, min, max,
                source, envelope || (patch && basis.Reward) || source != null, patch ? basis.Progress : 0);
        }

        private static bool Same(ValueState a, ValueState b)
            => ReferenceEquals(a, b) || (a != null && b != null && a.Type == b.Type && a.Id == b.Id && a.Min == b.Min && a.Max == b.Max && a.Reward == b.Reward && Same(a.Source, b.Source));

        private static JObject Write(ValueState value)
        {
            if (!value.Reward) return WriteCore(value, false);
            var json = new JObject { ["grantedData"] = WriteCore(value, true) };
            if (value.Source != null) json["sourceData"] = value.Source.Reward ? Write(value.Source) : WriteCore(value.Source, true);
            return json;
        }

        private static JObject WriteCore(ValueState value, bool reward)
        {
            var json = new JObject { ["consumeType"] = value.Type.Value, ["consumeId"] = value.Id };
            string key = reward ? "consumeValue" : "consumeVal";
            if (value.Min == value.Max) json[key] = value.Min;
            else { json[key + "_min"] = value.Min; json[key + "_max"] = value.Max; }
            return json;
        }

        public void SetData(TSVRow row, Func<string, ConsumeTypeId> parseType = null)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            var json = new JObject();
            foreach (string key in Types.Concat(PreviousTypes))
                if (row.Contains(key)) json[key] = ConsumeJson.TsvType(row.Get(key), parseType).Value;
            foreach (string key in Ids.Concat(PreviousIds))
                if (row.Contains(key)) json[key] = ConsumeJson.TsvInt(row.Get(key));
            foreach (string key in Values.Concat(Mins).Concat(Maxs).Concat(PreviousValues))
                if (row.Contains(key)) json[key] = ConsumeJson.TsvLong(row.Get(key));
            foreach (string key in new[] { "sourceData", "prevRewardData" })
                if (row.Contains(key)) json[key] = JToken.Parse(row.Get(key) ?? throw new InvalidDataException("A TSV source is null."));
            ImportJson(json);
        }
    }
}
