using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;

namespace jjevol
{
    public sealed class WealthContainer : DataContainer
    {
        public const string PayloadKey = "wealthInfos";
        public const string TypeKey = "wealthType";
        public const string QuantityKey = "quantity";
        private sealed class WealthState
        {
            internal readonly Dictionary<string, JObject> Rows;
            internal readonly IReadOnlyDictionary<string, Wealth> Items;
            internal readonly IReadOnlyDictionary<string, long> Balances;
            internal WealthState(Dictionary<string, JObject> rows, Dictionary<string, Wealth> items)
            {
                Rows = rows;
                Items = new ReadOnlyDictionary<string, Wealth>(items);
                Balances = new ReadOnlyDictionary<string, long>(rows.ToDictionary(pair => pair.Key, pair => pair.Value.Value<long>(QuantityKey), StringComparer.Ordinal));
            }
        }

        private WealthState Current => (WealthState)State;
        public IReadOnlyDictionary<string, long> Balances => Current.Balances;
        public IReadOnlyDictionary<string, Wealth> Items => Current.Items;

        public WealthContainer() : base(PayloadKey, EmptyState()) { }

        private static WealthState EmptyState() => new WealthState(new Dictionary<string, JObject>(StringComparer.Ordinal), new Dictionary<string, Wealth>(StringComparer.Ordinal));

        public long Get(string type)
        {
            if (string.IsNullOrWhiteSpace(type)) throw new ArgumentException("Wealth type is required.", nameof(type));
            return Current.Balances.TryGetValue(type, out long quantity) ? quantity : 0;
        }

        public Wealth GetItem(string type)
        {
            EnsureAccess();
            if (string.IsNullOrWhiteSpace(type)) throw new ArgumentException("Wealth type is required.", nameof(type));
            return Current.Items.TryGetValue(type, out Wealth item) ? item : null;
        }

        public bool TryGetItem(string type, out Wealth item) { item = GetItem(type); return item != null; }
        public bool AddOrReplace(JObject row)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            return UpdateJson(new JObject { [PayloadKey] = new JArray(row.DeepClone()) });
        }
        public bool Clear() => ImportJson(new JObject { [PayloadKey] = new JArray() });

        protected override StateChange ParseState(JObject data, bool replace)
        {
            WealthState current = Current;
            if (!replace && !data.ContainsKey(PayloadKey)) return new StateChange(current, Array.Empty<string>());
            JArray input = ContainerJson.RequireArray(data, PayloadKey);
            var rows = replace ? new Dictionary<string, JObject>(StringComparer.Ordinal) : new Dictionary<string, JObject>(current.Rows, StringComparer.Ordinal);
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (JToken token in input)
            {
                if (token is not JObject source) throw new InvalidDataException("A wealth row must be an object.");
                string key = ContainerJson.RequireKey(source, TypeKey);
                if (!seen.Add(key)) throw new InvalidDataException("Duplicate wealth key: " + key);
                current.Rows.TryGetValue(key, out JObject previous);
                rows[key] = ParseRow(source, previous, replace);
            }
            string[] changed = current.Rows.Keys.Union(rows.Keys, StringComparer.Ordinal)
                .Where(key => !current.Rows.TryGetValue(key, out JObject oldRow) || !rows.TryGetValue(key, out JObject newRow) || !JToken.DeepEquals(oldRow, newRow)).ToArray();
            if (changed.Length == 0) return new StateChange(current, changed);
            var items = new Dictionary<string, Wealth>(StringComparer.Ordinal);
            foreach (string key in rows.Keys)
                items.Add(key, current.Items.TryGetValue(key, out Wealth item) ? item : new Wealth(this, key));
            return new StateChange(new WealthState(rows, items), changed);
        }

        private static JObject ParseRow(JToken token, JObject previous, bool replace)
        {
            if (token is not JObject source) throw new InvalidDataException("A wealth row must be an object.");
            ContainerJson.RequireKey(source, TypeKey);
            bool hasQuantity = ContainerJson.TryReadInt64(source, QuantityKey, out long quantity);
            if (!hasQuantity && (replace || previous == null)) throw new InvalidDataException("A new or replacement wealth row requires quantity.");
            if (hasQuantity && quantity < 0) throw new InvalidDataException("Wealth quantity must be nonnegative.");
            var row = !replace && previous != null ? (JObject)previous.DeepClone() : new JObject();
            foreach (JProperty property in source.Properties()) row[property.Name] = property.Value.DeepClone();
            if (hasQuantity)
            {
                // JObject may treat equal BigInteger/long tokens as unchanged; replace the token explicitly.
                row.Remove(QuantityKey);
                row.Add(QuantityKey, new JValue(quantity));
            }
            return row;
        }

        protected override JObject WriteState(object state)
        {
            var array = new JArray();
            foreach (var pair in ((WealthState)state).Rows.OrderBy(pair => pair.Key, StringComparer.Ordinal)) array.Add(pair.Value.DeepClone());
            return new JObject { [PayloadKey] = array };
        }

        private JObject ReadItem(Wealth item)
        {
            EnsureAccess();
            WealthState state = Current;
            if (!state.Items.TryGetValue(item.wealthType, out Wealth current) || !ReferenceEquals(item, current))
                throw new InvalidOperationException("This item was removed or replaced. Query the container again.");
            return state.Rows[item.wealthType];
        }

        internal long ReadQuantity(Wealth item) => ReadItem(item).Value<long>(QuantityKey);
        internal long ReadPreparedQuantity(PreparedChange plan, string type)
            => ((WealthState)plan.State).Balances.TryGetValue(type, out long quantity) ? quantity : 0;
        internal JObject ExportItem(Wealth item) => (JObject)ReadItem(item).DeepClone();
    }
}
