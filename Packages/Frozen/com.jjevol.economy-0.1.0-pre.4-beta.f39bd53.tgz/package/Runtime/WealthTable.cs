using System;
using System.Collections.Generic;
using System.IO;

namespace jjevol
{
    public class WealthData : TableData
    {
        public string type { get; private set; }
        public bool active { get; private set; }
        public string icon { get; private set; }

        public WealthData() { }
        public WealthData(TSVRow row) : base(row) { }

        public override void Init(TSVRow row)
        {
            base.Init(row);
            type = row.GetString("type");
            active = row.GetInt("active", 0) != 0;
            icon = row.GetString("icon", string.Empty);
        }
    }

    public class WealthTable : KeyedTable<int, WealthData>
    {
        private readonly Dictionary<string, int> _typeMap = new Dictionary<string, int>(StringComparer.Ordinal);
        public WealthTable(string tableName = "01_wealth") : base(tableName) { }
        protected override WealthData ParseJson(TSVRow row) => new WealthData(row);
        protected override int GetKey(WealthData data) => data.id;

        protected override void _InsertData(int key, WealthData data)
        {
            if (key <= 0 || string.IsNullOrWhiteSpace(data.type) || data.type != data.type.Trim())
                throw new InvalidDataException("Wealth requires a positive ID and a nonempty type without surrounding whitespace.");
            if (_dict.ContainsKey(key) || _typeMap.ContainsKey(data.type)) throw new InvalidDataException("Duplicate wealth ID or type.");
            base._InsertData(key, data);
            _typeMap.Add(data.type, key);
        }

        protected override void InsertData(List<TSVRow> datas)
        {
            _typeMap.Clear();
            base.InsertData(datas);
        }

        protected override void _DataClear()
        {
            base._DataClear();
            _typeMap.Clear();
        }

        public int GetId(string type) => type != null && _typeMap.TryGetValue(type, out int id) ? id : 0;
        public WealthData Get(string type) => Get(GetId(type));
    }
}
