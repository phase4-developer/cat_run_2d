using JJEvol.Save.Testing;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace jjevol.Tests
{
    public sealed class EconomyRuntimeTests
    {
        private string _root;
        private Scene _scene;
        private ResourceService _resources;
        private DataRepository _data;
        private RepositoryStorageAdapter _storage;
        private readonly LocalSaveCodec _codec = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("test-v1", System.Text.Encoding.ASCII.GetBytes("0123456789abcdef0123456789abcdef")));
        private static readonly ConsumeTypeId Kind = new(812);

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolEconomyRuntimeTests", Guid.NewGuid().ToString("N")));
            var definitions = new WealthTable("31_fixture");
            definitions.LoadDatas(new FixtureSource());
            _resources = Open(definitions);
            _scene = SceneManager.CreateScene("EconomyFixture" + Guid.NewGuid().ToString("N"));
            yield return null;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        { PrefsFixture.Cleanup();
            if (_scene.IsValid() && _scene.isLoaded) yield return SceneManager.UnloadSceneAsync(_scene);
            _data?.Dispose();
            string allowed = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolEconomyRuntimeTests")) + Path.DirectorySeparatorChar;
            if (!Path.GetFullPath(_root).StartsWith(allowed, StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Unsafe synthetic economy cleanup");
            if (Directory.Exists(_root)) Directory.Delete(_root, true);
        }

        [UnityTest]
        public IEnumerator SceneSubscriberSeesCommittedStateAndCanUnsubscribeOnDisableAndUnload()
        {
            var go = new GameObject("Economy fixture listener");
            SceneManager.MoveGameObjectToScene(go, _scene);
            var observer = go.AddComponent<EconomyFixtureObserver>();
            observer.Resources = _resources;
            Grant(5);
            Assert.That(observer.Notifications, Is.EqualTo(1));
            Assert.That(observer.SeenQuantity, Is.EqualTo(5));
            Assert.That(observer.SeenRevision, Is.EqualTo(1));
            go.SetActive(false);
            Grant(3);
            Assert.That(observer.Notifications, Is.EqualTo(1));
            go.SetActive(true);
            yield return null;
            Grant(2);
            Assert.That(observer.Notifications, Is.EqualTo(2));
            Assert.That(observer.SeenQuantity, Is.EqualTo(10));
            int callsBeforeUnload = EconomyFixtureObserver.TotalNotifications;
            yield return SceneManager.UnloadSceneAsync(_scene);
            Grant(1);
            Assert.That(EconomyFixtureObserver.TotalNotifications, Is.EqualTo(callsBeforeUnload));
            var reopened = Open(_resources.Definitions);
            Assert.That(reopened.Get(31001001), Is.EqualTo(11));
        }

        [UnityTest]
        public IEnumerator PreparedRequestBecomesStaleAcrossFramesAndMustBeReprepared()
        {
            Grant(20);
            var cost = new ConsumeData(Kind, 31001001, 7);
            var old = Prepare(new[] { cost }, Array.Empty<ConsumeData>());
            yield return null;
            Grant(1);
            Assert.Throws<LocalSaveConflictException>(() => LocalRewardService.Commit(_storage, _resources, old));
            Assert.That(_resources.Get(31001001), Is.EqualTo(21));
            LocalRewardService.Commit(_storage, _resources, Prepare(new[] { cost }, Array.Empty<ConsumeData>()));
            Assert.That(_resources.Get(31001001), Is.EqualTo(14));
            Assert.That(_storage.SavedRevision, Is.EqualTo(3));
        }

        private ResourceService Open(WealthTable definitions)
        {
            _data?.Dispose(); _data = new DataRepository("device:economy-play"); _data.Register(new WealthContainer());
            _storage = RepositoryStorageAdapter.Open(_data, PrefsFixture.Create(_data.ProfileId, _root, _codec), "fixture:runtime:v1", RepositoryStorageMode.LocalAuthority,
                () => new JObject { ["wealthInfos"] = new JArray() });
            return new ResourceService(_data, definitions, Kind);
        }
        private LocalResourcePreparation Prepare(ConsumeData[] costs, ConsumeData[] rewards) => LocalRewardService.PrepareMutation(_storage, _resources, costs, rewards);
        private void Grant(long quantity) => LocalRewardService.Commit(_storage, _resources, Prepare(Array.Empty<ConsumeData>(),
            new[] { new ConsumeData(Kind, 31001001, quantity) }));

        private sealed class FixtureSource : ITableSource
        {
            public bool RequiresRemoteUpdate => false;
            public bool HasTable(string tableName) => tableName == "31_fixture";
            public List<TSVRow> Load(string tableName) => TSVRow.FromTsv("id\ttype\tactive\n31001001\tfixture-alpha\t1");
            public Task<List<TSVRow>> LoadAsync(string tableName) => Task.FromResult(Load(tableName));
        }
    }

    public sealed class EconomyFixtureObserver : MonoBehaviour
    {
        public static int TotalNotifications;
        private ResourceService _resources;
        public ResourceService Resources
        {
            get => _resources;
            set
            {
                if (_resources != null) _resources.Changed -= Observe;
                _resources = value;
                if (isActiveAndEnabled && _resources != null) _resources.Changed += Observe;
            }
        }
        public int Notifications;
        public long SeenQuantity;
        public long SeenRevision;
        private void OnEnable() { if (Resources != null) Resources.Changed += Observe; }
        private void OnDisable() { if (Resources != null) Resources.Changed -= Observe; }
        private void Observe(ResourceChange change)
        {
            if (Resources == null || !ReferenceEquals(change.Service, Resources)) return;
            Notifications++;
            TotalNotifications++;
            SeenQuantity = Resources.Get(change.ItemIds[0]);
            SeenRevision = Resources.Repository.Storage.SavedRevision;
            Assert.That(SeenRevision, Is.EqualTo(change.RepositoryRevision));
        }
    }
}
