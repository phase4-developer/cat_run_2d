using JJEvol.Save.Testing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using jjevol.Data;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Tests
{
    public sealed class EconomyAuthoringTests
    {
        private const int Alpha = 31001001;
        private const string Valid = "id\ttype\tactive\ticon\n31001001\tfixture-alpha\t1\tfixture-icon\n31001002\tfixture-beta\t1\tfixture-icon";
        private string _source;
        private string _output;
        private string _save;
        private DataRepository _data;
        private RepositoryStorageAdapter _storage;
        private readonly LocalSaveCodec _codec = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("test-v1", System.Text.Encoding.ASCII.GetBytes("0123456789abcdef0123456789abcdef")));
        private static readonly ConsumeTypeId Kind = new(812);

        [SetUp]
        public void SetUp()
        {
            _source = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolEconomyAuthoringTests", Guid.NewGuid().ToString("N")));
            _save = Path.Combine(_source, "Save");
            _output = Path.Combine(Application.dataPath, "EconomyStep10/Resources/EconomyStep10");
            Directory.CreateDirectory(_source);
            File.WriteAllText(Path.Combine(_source, "31_fixture.tsv"), Valid);
            File.WriteAllText(Path.Combine(_source, "32_costs.tsv"), "id\tpriceType\tpriceId\tpriceValue\n32001001\t812\t31001001\t7");
        }

        [TearDown]
        public void TearDown()
        { PrefsFixture.Cleanup();
            TableRepository.Clear();
            _data?.Dispose();
            GameTableSource.Configure(new PackagedTableSource());
            TableRuntimeOptions.StaticTablePath = null;
            var asset = Resources.Load<TextAsset>("EconomyStep10/31_fixture");
            if (asset) Resources.UnloadAsset(asset);
            string metadata = TableBuilder.GetManifestPath(_output);
            File.Delete(metadata);
            // tables.authoring 0.1.0-pre.6 keeps lock files under Library/JJEvol/TableAuthoring/Locks (TablePaths.Lock).
            string lockFile = Path.Combine(Path.GetFullPath(Path.Combine(Application.dataPath, "..")), "Library", "JJEvol", "TableAuthoring", "Locks", Path.GetFileName(metadata) + ".lock");
            if (File.Exists(lockFile)) File.Delete(lockFile); if (File.Exists(metadata + ".pending")) File.Delete(metadata + ".pending");
            AssetDatabase.DeleteAsset("Assets/EconomyStep10");
            string allowed = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolEconomyAuthoringTests")) + Path.DirectorySeparatorChar;
            if (!Path.GetFullPath(_source).StartsWith(allowed, StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Unsafe synthetic authoring cleanup");
            if (Directory.Exists(_source)) Directory.Delete(_source, true);
        }

        [Test]
        public async Task TsvAuthoringResourcesRepositoryAndDurableWealthTransactionWorkTogether()
        {
            var result = TableBuilder.Build(_source, _output, false, ValidateFixture);
            Assert.That(result.OutputFiles.Count, Is.EqualTo(2));
            GameTableSource.Configure(new PackagedTableSource(false));
            var table = new WealthTable("EconomyStep10/31_fixture");
            TableRepository.Clear();
            TableRepository.Register(table);
            await TableRepository.LoadAllAsync();
            Assert.That(table.Get(Alpha).table, Is.EqualTo(31));
            Assert.That(table.Get(Alpha).category, Is.EqualTo(1));
            Assert.That(table.Get(Alpha).index, Is.EqualTo(1));
            var costs = TSVRow.FromTsv(File.ReadAllText(Path.Combine(_output, "32_costs.txt")))[0];
            costs.ImportDatas(false, out var price);
            var repository = PrefsFixture.Create("device:economy-authoring", _save, _codec);
            var resources = Open(repository, table);
            LocalRewardService.Commit(_storage, resources, LocalRewardService.PrepareMutation(_storage, resources, Array.Empty<ConsumeData>(), new[] { new ConsumeData(Kind, Alpha, 50) }));
            LocalRewardService.Commit(_storage, resources, LocalRewardService.PrepareMutation(_storage, resources, price, Array.Empty<ConsumeData>()));
            Assert.That(resources.Get(Alpha), Is.EqualTo(43));
            var restored = Open(PrefsFixture.Create("device:economy-authoring", _save, _codec), table);
            Assert.That(restored.Get(Alpha), Is.EqualTo(43));
            Assert.That(_storage.SavedRevision, Is.EqualTo(2));

            string outputFile = Path.Combine(_output, "31_fixture.txt");
            string guid = AssetDatabase.AssetPathToGUID("Assets/EconomyStep10/Resources/EconomyStep10/31_fixture.txt");
            var cached = Resources.Load<TextAsset>("EconomyStep10/31_fixture");
            Resources.UnloadAsset(cached);
            File.WriteAllText(Path.Combine(_source, "31_fixture.tsv"), Valid.Replace("fixture-icon", "updated-icon"));
            TableBuilder.Build(_source, _output, false, ValidateFixture);
            Assert.That(File.ReadAllText(outputFile), Does.Contain("updated-icon"));
            Assert.That(AssetDatabase.AssetPathToGUID("Assets/EconomyStep10/Resources/EconomyStep10/31_fixture.txt"), Is.EqualTo(guid));
            table.LoadDatas();
            Assert.That(table.Get(Alpha).icon, Is.EqualTo("updated-icon"));
            Assert.That(restored.Get(Alpha), Is.EqualTo(43), "Static metadata regeneration must not reset saved balances.");
        }

        [TestCase("id\ttype\ninvalid\tfixture-alpha", false)]
        [TestCase("id\ttype\n31001001\t", false)]
        [TestCase("id\ttype\n31001001\ta\n31001001\tb", false)]
        [TestCase("id\ttype\n31001001\ta\n31001002\ta", false)]
        [TestCase("id\ttype\n31001001\ta", true)]
        public void GameOwnedIdRequiredDuplicateAndForeignKeyValidationPreservesPreviousOutput(string wealth, bool badFk)
        {
            TableBuilder.Build(_source, _output, false, ValidateFixture);
            byte[] previous = File.ReadAllBytes(Path.Combine(_output, "31_fixture.txt"));
            File.WriteAllText(Path.Combine(_source, "31_fixture.tsv"), wealth);
            if (badFk) File.WriteAllText(Path.Combine(_source, "32_costs.tsv"), "id\tpriceType\tpriceId\tpriceValue\n32001001\t812\t31999999\t7");
            Assert.Throws<InvalidDataException>(() => TableBuilder.Build(_source, _output, false, ValidateFixture));
            Assert.That(File.ReadAllBytes(Path.Combine(_output, "31_fixture.txt")), Is.EqualTo(previous));
        }

        // Fixture/game validation policy, intentionally outside Economy/Table runtime.
        private static void ValidateFixture(IReadOnlyList<TableBuildInput> tables)
        {
            var wealth = tables.Single(t => t.TableName == "31_fixture");
            var ids = new HashSet<int>();
            var types = new HashSet<string>(StringComparer.Ordinal);
            foreach (var row in wealth.Rows)
            {
                if (!int.TryParse(row.GetString("id"), out int id) || id / 1000000 != 31 || !ids.Add(id))
                    throw new InvalidDataException("Invalid/duplicate fixture wealth ID.");
                string type = row.GetString("type");
                if (string.IsNullOrWhiteSpace(type) || type != type.Trim() || !types.Add(type))
                    throw new InvalidDataException("Missing/duplicate fixture wealth type.");
            }
            foreach (var row in tables.Single(t => t.TableName == "32_costs").Rows)
            {
                row.ImportDatas(false, out var costs);
                foreach (var cost in costs)
                    if (cost.TypeId != Kind || !ids.Contains(cost.ItemId) || cost.Quantity < 0)
                        throw new InvalidDataException("Unknown fixture cost FK or invalid quantity.");
            }
        }
        private ResourceService Open(LocalSaveRepository files, WealthTable table)
        {
            _data?.Dispose(); _data = new DataRepository(files.ProfileId); _data.Register(new WealthContainer());
            _storage = RepositoryStorageAdapter.Open(_data, files, "fixture:authoring:v1", RepositoryStorageMode.LocalAuthority,
                () => new JObject { ["wealthInfos"] = new JArray() });
            return new ResourceService(_data, table, Kind);
        }
    }
}
