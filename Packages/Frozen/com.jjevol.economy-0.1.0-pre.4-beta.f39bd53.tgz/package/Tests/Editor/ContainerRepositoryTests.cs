using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tests
{
    public sealed class ContainerRepositoryTests
    {
        private DataRepository _repository;
        private WealthContainer _wealth;
        private TextContainer _text;
        private int _containerNotices;
        private int _repositoryNotices;

        [SetUp]
        public void SetUp()
        {
            _repository = new DataRepository("a1:" + Guid.NewGuid().ToString("N"));
            _wealth = new WealthContainer();
            _text = new TextContainer();
            _repository.Register(_wealth);
            _repository.Register(_text);
            _repository.ImportJson(JObject.Parse("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":10,\"opaque\":{\"x\":1}},{\"wealthType\":\"beta\",\"quantity\":20}],\"labels\":[{\"id\":\"one\",\"value\":\"old\"}]}"), "wealthInfos", "labels");
            _containerNotices = _repositoryNotices = 0;
            _wealth.Changed += _ => _containerNotices++;
            _repository.Changed += _ => _repositoryNotices++;
        }

        [TearDown]
        public void TearDown() => _repository.Dispose();

        private static JObject WealthJson(params JObject[] rows) => new JObject { [WealthContainer.PayloadKey] = new JArray(rows) };
        private static JObject Row(string key, long quantity) => new JObject { [WealthContainer.TypeKey] = key, [WealthContainer.QuantityKey] = quantity };

        [Test]
        public void ImportExportRoundTripKeepsContainerAndReplacesTheItemSet()
        {
            Wealth previous = _wealth.GetItem("alpha");
            JObject input = WealthJson(Row("gamma", 31));
            Assert.That(_wealth.ImportJson(input), Is.True);
            Assert.That(_repository.Get<WealthContainer>("wealthInfos"), Is.SameAs(_wealth));
            Assert.That(JToken.DeepEquals(input, _wealth.ExportJson()), Is.True);
            Assert.That(_wealth.GetItem("alpha"), Is.Null);
            Assert.That(_wealth.GetItem("gamma").quantity, Is.EqualTo(31));
            Assert.Throws<InvalidOperationException>(() => _ = previous.quantity);
            Assert.That(_containerNotices, Is.EqualTo(1));
            Assert.That(_repositoryNotices, Is.EqualTo(1));
        }

        [Test]
        public void PartialUpdatePreservesItemsFieldsAndExistingReferences()
        {
            Wealth alpha = _wealth.GetItem("alpha"), beta = _wealth.GetItem("beta");
            Assert.That(_wealth.UpdateJson(WealthJson(Row("alpha", 30))), Is.True);
            Assert.That(_wealth.GetItem("alpha"), Is.SameAs(alpha));
            Assert.That(_wealth.GetItem("beta"), Is.SameAs(beta));
            Assert.That(alpha.quantity, Is.EqualTo(30));
            Assert.That(beta.quantity, Is.EqualTo(20));
            Assert.That((int)alpha.ExportJson()["opaque"]["x"], Is.EqualTo(1));
            var patch = new JObject { ["wealthType"] = "alpha", ["another"] = true };
            _wealth.UpdateJson(WealthJson(patch));
            Assert.That(alpha.quantity, Is.EqualTo(30));
            Assert.That((bool)alpha.ExportJson()["another"], Is.True);
        }

        [Test]
        public void FullReplacementDropsMissingFieldsAndRowsButKeepsRetainedItemHandles()
        {
            Wealth alpha = _wealth.GetItem("alpha"), removed = _wealth.GetItem("beta");
            _wealth.ImportJson(WealthJson(Row("alpha", 91)));
            Assert.That(_wealth.GetItem("alpha"), Is.SameAs(alpha));
            Assert.That(alpha.quantity, Is.EqualTo(91));
            Assert.That(alpha.ExportJson()["opaque"], Is.Null);
            Assert.That(_wealth.GetItem("beta"), Is.Null);
            Assert.Throws<InvalidOperationException>(() => _ = removed.quantity);
            _wealth.AddOrReplace(Row("beta", 92));
            Assert.That(_wealth.GetItem("beta"), Is.Not.SameAs(removed));
            Assert.Throws<InvalidOperationException>(() => _ = removed.quantity);
        }

        [Test]
        public void BigIntegerTokensInsideLongRangeAreExactAndOutsideRangeAreRejected()
        {
            JObject row = Row("alpha", 0);
            row["quantity"] = new JValue(new System.Numerics.BigInteger(long.MaxValue));
            _wealth.UpdateJson(WealthJson(row));
            Assert.That(_wealth.Get("alpha"), Is.EqualTo(long.MaxValue));
            row["quantity"] = new JValue(new System.Numerics.BigInteger(long.MaxValue) + 1);
            Assert.Throws<InvalidDataException>(() => _wealth.UpdateJson(WealthJson(row)));
            Assert.That(_wealth.Get("alpha"), Is.EqualTo(long.MaxValue));
        }

        [Test]
        public void AddReplaceAndClearUseTheSameRepositoryBoundary()
        {
            _wealth.AddOrReplace(Row("gamma", 42));
            Wealth item = _wealth.GetItem("gamma");
            _wealth.AddOrReplace(Row("gamma", 50));
            Assert.That(_wealth.GetItem("gamma"), Is.SameAs(item));
            Assert.That(item.quantity, Is.EqualTo(50));
            long before = _repository.Revision;
            Assert.That(_wealth.Clear(), Is.True);
            Assert.That(_wealth.Items, Is.Empty);
            Assert.That(_repository.Revision, Is.EqualTo(before + 1));
            Assert.That(_wealth.Clear(), Is.False);
            Assert.That(_containerNotices, Is.EqualTo(3));
        }

        [Test]
        public void ReadsAndNoOpsDoNotCreateItemsAdvanceRevisionOrNotify()
        {
            long revision = _wealth.Revision, repositoryRevision = _repository.Revision;
            Assert.That(_wealth.Get("missing"), Is.Zero);
            Assert.That(_wealth.GetItem("missing"), Is.Null);
            Assert.That(_wealth.TryGetItem("missing", out Wealth missing), Is.False);
            Assert.That(missing, Is.Null);
            Assert.That(_wealth.Items.Count, Is.EqualTo(2));
            Assert.That(_wealth.UpdateJson(new JObject()), Is.False);
            Assert.That(_wealth.UpdateJson(WealthJson()), Is.False);
            Assert.That(_wealth.UpdateJson(WealthJson(new JObject { ["wealthType"] = "alpha" })), Is.False);
            Assert.That(_wealth.ImportJson(_wealth.ExportJson()), Is.False);
            Assert.That(_wealth.Revision, Is.EqualTo(revision));
            Assert.That(_repository.Revision, Is.EqualTo(repositoryRevision));
            Assert.That(_containerNotices + _repositoryNotices, Is.Zero);
        }

        [TestCase("{}")]
        [TestCase("{\"wealthInfos\":null}")]
        [TestCase("{\"wealthInfos\":{}}")]
        [TestCase("{\"wealthInfos\":1}")]
        [TestCase("{\"wealthInfos\":[null]}")]
        [TestCase("{\"wealthInfos\":[1]}")]
        [TestCase("{\"wealthInfos\":[{}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":null,\"quantity\":1}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":1,\"quantity\":1}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"\",\"quantity\":1}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"  \",\"quantity\":1}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\"}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":null}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":-1}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":1.5}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":\"2\"}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":true}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":9223372036854775808}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":-9223372036854775809}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":999999999999999999999999999999999999}]}")]
        public void InvalidImportsPreserveAllStateAndInput(string json)
        {
            JObject input = JObject.Parse(json), original = (JObject)input.DeepClone(), before = _repository.ExportJson();
            long revision = _wealth.Revision, repositoryRevision = _repository.Revision;
            Wealth alpha = _wealth.GetItem("alpha");
            Assert.Throws<InvalidDataException>(() => _wealth.ImportJson(input));
            Assert.That(JToken.DeepEquals(before, _repository.ExportJson()), Is.True);
            Assert.That(JToken.DeepEquals(original, input), Is.True);
            Assert.That(_wealth.GetItem("alpha"), Is.SameAs(alpha));
            Assert.That(_wealth.Revision, Is.EqualTo(revision));
            Assert.That(_repository.Revision, Is.EqualTo(repositoryRevision));
            Assert.That(_containerNotices + _repositoryNotices, Is.Zero);
        }

        [TestCase(true)]
        [TestCase(false)]
        public void InvalidMiddleRowOrDuplicateRejectsTheWholeChange(bool replace)
        {
            JObject before = _repository.ExportJson();
            foreach (JObject input in new[] { WealthJson(Row("alpha", 99), new JObject { ["wealthType"] = "new" }, Row("beta", 100)), WealthJson(Row("alpha", 99), Row("alpha", 100)) })
            {
                Assert.Throws<InvalidDataException>(() => { if (replace) _wealth.ImportJson(input); else _wealth.UpdateJson(input); });
                Assert.That(JToken.DeepEquals(before, _repository.ExportJson()), Is.True);
            }
            Assert.That(_containerNotices + _repositoryNotices, Is.Zero);
        }

        [Test]
        public void MissingAndNullAreDifferentInPartialUpdates()
        {
            _wealth.UpdateJson(WealthJson(new JObject { ["wealthType"] = "alpha", ["opaque"] = JValue.CreateNull() }));
            Assert.That(_wealth.Get("alpha"), Is.EqualTo(10));
            Assert.That(_wealth.GetItem("alpha").ExportJson()["opaque"].Type, Is.EqualTo(JTokenType.Null));
            long revision = _wealth.Revision;
            Assert.Throws<InvalidDataException>(() => _wealth.UpdateJson(WealthJson(new JObject { ["wealthType"] = "alpha", ["quantity"] = JValue.CreateNull() })));
            Assert.Throws<InvalidDataException>(() => _wealth.UpdateJson(WealthJson(new JObject { ["wealthType"] = "new" })));
            Assert.That(_wealth.Revision, Is.EqualTo(revision));
            _wealth.UpdateJson(WealthJson(Row("alpha", 0)));
            Assert.That(_wealth.GetItem("alpha"), Is.Not.Null);
            Assert.That(_wealth.Get("alpha"), Is.Zero);
        }

        [TestCase("null")]
        [TestCase("-1")]
        [TestCase("1.5")]
        [TestCase("\"2\"")]
        [TestCase("9223372036854775808")]
        public void InvalidPatchQuantitiesPreserveState(string quantity)
        {
            JObject before = _repository.ExportJson();
            long revision = _repository.Revision;
            JObject patch = JObject.Parse("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":" + quantity + "}]}");
            Assert.Throws<InvalidDataException>(() => _wealth.UpdateJson(patch));
            Assert.That(JToken.DeepEquals(before, _repository.ExportJson()), Is.True);
            Assert.That(_repository.Revision, Is.EqualTo(revision));
            Assert.That(_containerNotices + _repositoryNotices, Is.Zero);
        }

        [Test]
        public void NullInputsAndRowsFailWithoutChangingState()
        {
            JObject before = _repository.ExportJson();
            Assert.Throws<ArgumentNullException>(() => _wealth.ImportJson(null));
            Assert.Throws<ArgumentNullException>(() => _wealth.UpdateJson(null));
            Assert.Throws<ArgumentNullException>(() => _wealth.AddOrReplace(null));
            Assert.Throws<ArgumentNullException>(() => _repository.ImportJson(null, "wealthInfos"));
            Assert.That(JToken.DeepEquals(before, _repository.ExportJson()), Is.True);
            Assert.That(_containerNotices + _repositoryNotices, Is.Zero);
        }

        [TestCase(2147483648L)]
        [TestCase(9007199254740993L)]
        [TestCase(long.MaxValue)]
        public void LongIntegersRoundTripExactly(long quantity)
        {
            JObject input = JObject.Parse(WealthJson(Row("large", quantity)).ToString());
            _wealth.ImportJson(input);
            Assert.That(_wealth.GetItem("large").quantity, Is.EqualTo(quantity));
            Assert.That(_wealth.ExportJson()["wealthInfos"][0]["quantity"].Value<long>(), Is.EqualTo(quantity));
            using var restored = new WealthContainer();
            restored.ImportJson(_wealth.ExportJson());
            Assert.That(restored.Get("large"), Is.EqualTo(quantity));
        }

        [Test]
        public void CallersCannotChangeCollectionsItemValuesOrExportedJson()
        {
            Wealth alpha = _wealth.GetItem("alpha");
            Assert.Throws<NotSupportedException>(() => ((IDictionary<string, Wealth>)_wealth.Items).Clear());
            Assert.Throws<NotSupportedException>(() => ((IDictionary<string, long>)_wealth.Balances)["alpha"] = 999);
            Assert.Throws<NotSupportedException>(() => ((IDictionary<string, DataContainer>)_repository.Containers).Clear());
            Assert.That(typeof(Wealth).GetProperty("quantity").GetSetMethod(true), Is.Null);
            JObject exported = alpha.ExportJson();
            exported["quantity"] = 999;
            exported["opaque"]["x"] = 999;
            JObject combined = _repository.ExportJson();
            combined["wealthInfos"][0]["quantity"] = 888;
            Assert.That(alpha.quantity, Is.EqualTo(10));
            Assert.That((int)alpha.ExportJson()["opaque"]["x"], Is.EqualTo(1));
            Assert.That(_containerNotices + _repositoryNotices, Is.Zero);
        }

        [Test]
        public void SuccessfulParsingAlsoDetachesInputNestedFields()
        {
            JObject input = WealthJson(new JObject { ["wealthType"] = "alpha", ["quantity"] = 25, ["nested"] = new JArray(1, 2) });
            JObject original = (JObject)input.DeepClone();
            _wealth.UpdateJson(input);
            Assert.That(JToken.DeepEquals(input, original), Is.True);
            input["wealthInfos"][0]["nested"][0] = 999;
            Assert.That((int)_wealth.GetItem("alpha").ExportJson()["nested"][0], Is.EqualTo(1));
        }

        [TestCase(true)]
        [TestCase(false)]
        public void MultipleContainerValidationFailureCannotPartiallyApply(bool replace)
        {
            JObject before = _repository.ExportJson();
            long revision = _repository.Revision, wealthRevision = _wealth.Revision;
            JObject input = WealthJson(Row("alpha", 999));
            input["labels"] = new JArray(new JObject { ["id"] = "one", ["value"] = 123 });
            Assert.Throws<InvalidDataException>(() => { if (replace) _repository.ImportJson(input, "wealthInfos", "labels"); else _repository.UpdateJson(input, "wealthInfos", "labels"); });
            Assert.That(JToken.DeepEquals(_repository.ExportJson(), before), Is.True);
            Assert.That(_repository.Revision, Is.EqualTo(revision));
            Assert.That(_wealth.Revision, Is.EqualTo(wealthRevision));
            Assert.That(_containerNotices + _repositoryNotices, Is.Zero);
        }

        [Test]
        public void AllStateAndRevisionsArePublishedBeforeAnyNotification()
        {
            long revision = _repository.Revision;
            Wealth alpha = _wealth.GetItem("alpha");
            int observations = 0;
            Action observe = () =>
            {
                Assert.That(alpha.quantity, Is.EqualTo(77));
                Assert.That(_text.Get("one"), Is.EqualTo("new"));
                Assert.That(_repository.Revision, Is.EqualTo(revision + 1));
                observations++;
            };
            _wealth.Changed += change => { observe(); Assert.That(change.ChangedKeys, Is.EqualTo(new[] { "alpha" })); Assert.That(change.Revision, Is.EqualTo(_wealth.Revision)); };
            _text.Changed += _ => observe();
            _repository.Changed += change => { observe(); Assert.That(change.Containers.Count, Is.EqualTo(2)); };
            JObject data = WealthJson(Row("alpha", 77));
            data["labels"] = new JArray(new JObject { ["id"] = "one", ["value"] = "new" });
            _repository.UpdateJson(data, "wealthInfos", "labels");
            Assert.That(observations, Is.EqualTo(3));
        }

        [Test]
        public void DirectRegisteredCallsAndReentryUseTheRepositoryGate()
        {
            _wealth.Changed += _ =>
            {
                Assert.Throws<InvalidOperationException>(() => _text.UpdateJson(new JObject { ["labels"] = new JArray() }));
                Assert.Throws<InvalidOperationException>(() => _wealth.Clear());
                Assert.Throws<InvalidOperationException>(() => _repository.Register(new WealthContainer()));
                Assert.Throws<InvalidOperationException>(() => _repository.Dispose());
                Assert.Throws<InvalidOperationException>(() => _wealth.Dispose());
            };
            _wealth.AddOrReplace(Row("alpha", 51));
            _wealth.AddOrReplace(Row("alpha", 52));
            Assert.That(_repositoryNotices, Is.EqualTo(2));
            Assert.That(_wealth.Get("alpha"), Is.EqualTo(52));
        }

        [Test]
        public void OneSubscriberFailureDoesNotSkipOthersOrTurnCommitIntoFailure()
        {
            int healthy = 0;
            _wealth.Changed += _ => throw new InvalidOperationException("a1 notification failure");
            _wealth.Changed += _ => healthy++;
            _repository.Changed += _ => healthy++;
            LogAssert.Expect(LogType.Exception, new Regex("InvalidOperationException: a1 notification failure"));
            Assert.That(_wealth.AddOrReplace(Row("alpha", 60)), Is.True);
            Assert.That(healthy, Is.EqualTo(2));
            Assert.That(_wealth.Get("alpha"), Is.EqualTo(60));
        }

        [Test]
        public void ExplicitScopeControlsReplacementAndPatchRouting()
        {
            Assert.Throws<ArgumentException>(() => _repository.ImportJson(_repository.ExportJson()));
            Assert.Throws<ArgumentException>(() => _repository.UpdateJson(_repository.ExportJson(), "wealthInfos", "wealthInfos"));
            Assert.Throws<KeyNotFoundException>(() => _repository.UpdateJson(new JObject(), "unknown"));
            Assert.Throws<InvalidDataException>(() => _repository.ImportJson(WealthJson(Row("alpha", 99)), "wealthInfos", "labels"));
            Assert.That(_wealth.Get("alpha"), Is.EqualTo(10));
            Assert.That(_repository.UpdateJson(new JObject(), "wealthInfos", "labels"), Is.False);
            _repository.ImportJson(WealthJson(), "wealthInfos");
            Assert.That(_wealth.Items, Is.Empty);
            Assert.That(_text.Get("one"), Is.EqualTo("old"));
        }

        [Test]
        public void RegistrationOwnershipAndDisposalAreExplicit()
        {
            Assert.Throws<ArgumentException>(() => _repository.Register(new WealthContainer()));
            using var other = new DataRepository("a1:" + Guid.NewGuid().ToString("N"));
            Assert.Throws<InvalidOperationException>(() => other.Register(_wealth));
            Assert.Throws<InvalidOperationException>(() => new DataRepository(_repository.ProfileId));
            Wealth alpha = _wealth.GetItem("alpha");
            string profile = _repository.ProfileId;
            _repository.Dispose();
            Assert.That(_wealth.IsDisposed, Is.True);
            Assert.Throws<ObjectDisposedException>(() => _wealth.Get("alpha"));
            Assert.Throws<ObjectDisposedException>(() => _ = alpha.quantity);
            Assert.Throws<ObjectDisposedException>(() => _repository.ExportJson());
            using var replacement = new DataRepository(profile);
        }

        [Test]
        public void OtherThreadsCannotReadIntermediateStateOrMutate()
        {
            Wealth alpha = _wealth.GetItem("alpha");
            Task.Run(() =>
            {
                Assert.Throws<InvalidOperationException>(() => _ = alpha.quantity);
                Assert.Throws<InvalidOperationException>(() => _wealth.ExportJson());
                Assert.Throws<InvalidOperationException>(() => _wealth.UpdateJson(WealthJson(Row("alpha", 99))));
                Assert.Throws<InvalidOperationException>(() => _repository.ExportJson());
            }).GetAwaiter().GetResult();
            Assert.That(alpha.quantity, Is.EqualTo(10));
        }

        // A genuinely different model exercises the common two-phase boundary without Wealth-specific parsing.
        private sealed class TextContainer : DataContainer
        {
            public TextContainer() : base("labels", new Dictionary<string, string>(StringComparer.Ordinal)) { }
            public string Get(string key) => ((Dictionary<string, string>)State).TryGetValue(key, out string value) ? value : null;
            protected override StateChange ParseState(JObject data, bool replace)
            {
                var old = (Dictionary<string, string>)State;
                var next = replace ? new Dictionary<string, string>(StringComparer.Ordinal) : new Dictionary<string, string>(old, StringComparer.Ordinal);
                var seen = new HashSet<string>(StringComparer.Ordinal);
                foreach (JToken token in ContainerJson.RequireArray(data, DataKey))
                {
                    if (token is not JObject row) throw new InvalidDataException("Expected a label object.");
                    string key = ContainerJson.RequireKey(row, "id");
                    if (!seen.Add(key)) throw new InvalidDataException("Duplicate label.");
                    if (row["value"]?.Type != JTokenType.String) throw new InvalidDataException("Expected a label string.");
                    next[key] = row.Value<string>("value");
                }
                string[] keys = old.Keys.Union(next.Keys).Where(key => !old.TryGetValue(key, out string a) || !next.TryGetValue(key, out string b) || a != b).ToArray();
                return new StateChange(next, keys);
            }
            protected override JObject WriteState(object state) => new JObject { [DataKey] = new JArray(((Dictionary<string, string>)state).Select(pair => new JObject { ["id"] = pair.Key, ["value"] = pair.Value })) };
        }
    }
}
