using JJEvol.Save.Testing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tests
{
    public sealed class RepositoryStorageTests
    {
        private const string Schema = "synthetic:containers:v1";
        private string _root, _profile;
        private DataRepository _repository;
        private WealthContainer _wealth;
        private ResourceService _resources;
        private LocalSaveRepository _files;
        private RepositoryStorageAdapter _storage;
        private static readonly LocalSaveEncryption Encryption = new LocalSaveEncryption("test-v1", Encoding.ASCII.GetBytes("0123456789abcdef0123456789abcdef"));
        private static readonly LocalSaveCodec Codec = LocalSaveCodec.CreateEncrypted(Encryption);
        private readonly ConsumeTypeId _kind = new ConsumeTypeId(812);
        private int _notices;
        [SetUp]
        public void SetUp()
        {
            _root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolRepositoryStorageTests", Guid.NewGuid().ToString("N")));
            _profile = "step03:" + Guid.NewGuid().ToString("N");
            CreateRepository();
            _files = PrefsFixture.Create(_profile, _root, Codec);
        }
        private void CreateRepository()
        {
            _repository = new DataRepository(_profile); _wealth = new WealthContainer(); _repository.Register(_wealth);
            var table = new TestTable(); table.LoadDatas(); _resources = new ResourceService(_repository, table, _kind);
            _resources.Changed += _ => _notices++;
        }
        [TearDown]
        public void TearDown()
        { PrefsFixture.Cleanup();
            _repository.Dispose();
            string parent = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolRepositoryStorageTests")) + Path.DirectorySeparatorChar;
            if (!_root.StartsWith(parent, StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Unsafe synthetic storage cleanup.");
            if (Directory.Exists(_root)) Directory.Delete(_root, true);
        }
        private static JObject Data(long quantity) => new JObject { ["wealthInfos"] = new JArray(new JObject { ["wealthType"] = "alpha", ["quantity"] = quantity, ["opaque"] = new JObject { ["flag"] = true } }) };
        private ConsumeData Value(long quantity, int id = 11) => new ConsumeData(_kind, id, quantity);
        private void Open(RepositoryStorageMode mode = RepositoryStorageMode.LocalAuthority, Func<JObject> initial = null)
        { _storage = RepositoryStorageAdapter.Open(_repository, _files, Schema, mode, initial ?? (() => Data(1000))); _notices = 0; }
        private LocalResourcePreparation Prepare(long cost, long reward = 0)
            => LocalRewardService.PrepareMutation(_storage, _resources, new[] { Value(cost) }, new[] { Value(reward) });
        private void Commit(long cost, long reward = 0) => LocalRewardService.Commit(_storage, _resources, Prepare(cost, reward));
        private void Reopen()
        { _repository.Dispose(); CreateRepository(); Open(); }
        private long Persisted() => _files.Load().Document.Snapshot.Payload["wealthInfos"][0].Value<long>("quantity");
        [Test]
        public void NewProfileIsExplicitAndReloadsSameContainerWithoutSessionState()
        {
            int factories = 0; Open(initial: () => { factories++; return Data(1000); });
            Assert.That(factories, Is.EqualTo(1)); Assert.That(_storage.SavedRevision, Is.Zero);
            Assert.That(_storage.LastLoadStatus, Is.EqualTo(LocalSaveLoadStatus.Missing));
            Assert.That(_resources.Container, Is.SameAs(_repository.Get<WealthContainer>("wealthInfos")));
            _storage.Reload(); Assert.That(factories, Is.EqualTo(1)); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
            Reopen(); Assert.That(_resources.Get(11), Is.EqualTo(1000)); Assert.That(_storage.LastLoadStatus, Is.EqualTo(LocalSaveLoadStatus.Loaded));
        }
        [Test]
        public void MissingProfileNeverInfersEmptyOrWritesInvalidInitialData()
        {
            Assert.Throws<InvalidOperationException>(() => RepositoryStorageAdapter.Open(_repository, _files, Schema, RepositoryStorageMode.LocalAuthority));
            Assert.That(PlayerPrefs.HasKey(_files.Slot0Key), Is.False); Assert.That(_repository.Storage, Is.Null);
            Assert.Throws<InvalidDataException>(() => Open(initial: () => new JObject()));
            Assert.That(PlayerPrefs.HasKey(_files.Slot0Key), Is.False); Assert.That(_wealth.Items.Count, Is.Zero);
        }
        [Test]
        public void MultipleContainersAndUnrelatedPayloadRoundTripAtomically()
        {
            var note = new NoteContainer(); _repository.Register(note);
            Open(initial: () => { var data = Data(1000); data["notes"] = new JArray(new JObject { ["text"] = "old", ["extra"] = 7 }); data["foreign"] = new JObject { ["value"] = 91 }; return data; });
            var next = Data(850); next["notes"] = new JArray(new JObject { ["text"] = "new", ["extra"] = 9 });
            _storage.ApplyAndSave(next, true, "wealthInfos", "notes");
            Assert.That(note.Text, Is.EqualTo("new")); Assert.That(Persisted(), Is.EqualTo(850));
            _repository.Dispose(); CreateRepository(); var loaded = new NoteContainer(); _repository.Register(loaded); Open();
            Assert.That(loaded.Text, Is.EqualTo("new")); Assert.That((int)_files.Load().Document.Snapshot.Payload["foreign"]["value"], Is.EqualTo(91));
            Assert.That((int)loaded.ExportJson()["notes"][0]["extra"], Is.EqualTo(9));
        }
        [Test]
        public void InitialCandidatesAndExportAreValidatedBeforeAnyFileIsCreated()
        {
            var note = new NoteContainer { FailExport = true }; _repository.Register(note);
            Assert.Throws<InvalidOperationException>(() => Open(initial: () => { var data = Data(1); data["notes"] = new JArray(new JObject { ["text"] = "valid" }); return data; }));
            Assert.That(PlayerPrefs.HasKey(_files.Slot0Key), Is.False); Assert.That(_wealth.Items.Count, Is.Zero);
        }
        [Test]
        public void InvalidSecondContainerPreservesFileAndEveryLiveModel()
        {
            var note = new NoteContainer(); _repository.Register(note);
            Open(initial: () => { var data = Data(1000); data["notes"] = new JArray(new JObject { ["text"] = "old" }); return data; });
            byte[] original = PrefsFixture.Read(_files); long revision = _repository.Revision;
            var next = Data(800); next["notes"] = new JArray(new JObject { ["text"] = false });
            Assert.Throws<InvalidDataException>(() => _storage.ApplyAndSave(next, true, "wealthInfos", "notes"));
            Assert.That(PrefsFixture.Read(_files), Is.EqualTo(original)); Assert.That(note.Text, Is.EqualTo("old"));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_repository.Revision, Is.EqualTo(revision)); Assert.That(_notices, Is.Zero);
        }
        [TestCase(2147483648L)] [TestCase(9007199254740993L)] [TestCase(long.MaxValue)]
        public void ExactLongQuantitiesSurviveDurableRoundTrip(long quantity)
        { Open(); _storage.ApplyAndSave(Data(quantity), true, "wealthInfos"); Reopen(); Assert.That(_resources.GetRaw(11), Is.EqualTo(quantity)); }
        [Test]
        public void ExplicitEmptyContainerIsValidAndReservationsAreNeverSaved()
        {
            Open(); _resources.Reserve(new[] { Value(100) }); _resources.BeginRequest(); _resources.Reserve(new[] { Value(50) });
            _storage.Save(); Assert.That(Persisted(), Is.EqualTo(1000)); Assert.That(_resources.Get(11), Is.EqualTo(850));
            _storage.ApplyAndSave(new JObject { ["wealthInfos"] = new JArray() }, true, "wealthInfos");
            Reopen(); Assert.That(_wealth.Items.Count, Is.Zero); Assert.That(_resources.InFlightRequest, Is.Null); Assert.That(_resources.Get(11), Is.Zero);
        }
        [Test]
        public void DirectChangesAreDirtyUntilExplicitSaveAndDoNotEmitDuplicateCommitEvents()
        {
            Open(); _wealth.UpdateJson(Data(950)); Assert.That(_storage.IsDirty, Is.True); Assert.That(Persisted(), Is.EqualTo(1000));
            Assert.Throws<InvalidOperationException>(() => Prepare(1)); int notices = _notices;
            _storage.Save(); Assert.That(_storage.IsDirty, Is.False); Assert.That(Persisted(), Is.EqualTo(950)); Assert.That(_notices, Is.EqualTo(notices));
            _wealth.AddOrReplace(new JObject { ["wealthType"] = "beta", ["quantity"] = 17 }); Assert.That(_storage.IsDirty, Is.True);
            _storage.Save(); _wealth.Clear(); Assert.That(_storage.IsDirty, Is.True); _storage.Save(); Reopen(); Assert.That(_wealth.Items.Count, Is.Zero);
        }
        [Test]
        public void CostAndRewardCommitOnlyAfterConfirmedSaveAndReopenAt850()
        {
            Open(); var cost = Value(200); var reward = Value(50);
            var preparation = LocalRewardService.PrepareMutation(_storage, _resources, new[] { cost }, new[] { reward });
            cost.SetConsumeVal(999); reward.SetConsumeVal(999);
            int calls = 0; Action observe = () => { calls++; Assert.That(_resources.GetRaw(11), Is.EqualTo(850)); Assert.That(Persisted(), Is.EqualTo(850)); Assert.That(_storage.SavedRevision, Is.EqualTo(1)); Assert.That(_storage.IsDirty, Is.False); };
            _wealth.Changed += _ => observe(); _repository.Changed += _ => observe(); _resources.Changed += _ => observe();
            LocalRewardService.Commit(_storage, _resources, preparation);
            Assert.That(calls, Is.EqualTo(3)); Assert.That(_notices, Is.EqualTo(1));
            Assert.Throws<LocalSaveConflictException>(() => LocalRewardService.Commit(_storage, _resources, preparation));
            Reopen(); Assert.That(_resources.GetRaw(11), Is.EqualTo(850));
        }
        [Test]
        public void DuplicateCostsAndRewardsUseCheckedTotalsBeforeGranting()
        {
            Open(); var preparation = LocalRewardService.PrepareMutation(_storage, _resources, new[] { Value(100), Value(100) }, new[] { Value(20), Value(30) });
            LocalRewardService.Commit(_storage, _resources, preparation); Assert.That(_resources.GetRaw(11), Is.EqualTo(850));
            Assert.Throws<InsufficientResourceException>(() => Prepare(851, 1000)); Assert.That(Persisted(), Is.EqualTo(850));
        }
        [Test]
        public void ReservationsCannotBeSpentByAnotherLocalTransaction()
        {
            Open(); _resources.Reserve(new[] { Value(700) });
            Assert.Throws<InsufficientResourceException>(() => Prepare(301)); Commit(200, 50);
            Assert.That(_resources.GetRaw(11), Is.EqualTo(850)); Assert.That(_resources.Get(11), Is.EqualTo(150)); Assert.That(Persisted(), Is.EqualTo(850));
        }
        [TestCase(-1L)] [TestCase(long.MinValue)]
        public void NegativeCostsAndRewardsFailBeforeIO(long quantity)
        { Open(); byte[] before = PrefsFixture.Read(_files); Assert.Throws<ArgumentOutOfRangeException>(() => Prepare(quantity)); Assert.Throws<ArgumentOutOfRangeException>(() => Prepare(0, quantity)); Assert.That(PrefsFixture.Read(_files), Is.EqualTo(before)); }
        [Test]
        public void InvalidKindsRangesAndOverflowCannotPersist()
        {
            Open(); byte[] before = PrefsFixture.Read(_files);
            Assert.Throws<NotSupportedException>(() => LocalRewardService.PrepareMutation(_storage, _resources, new[] { new ConsumeData(new ConsumeTypeId(1), 11, 1) }, Array.Empty<ConsumeData>()));
            Assert.Throws<NotSupportedException>(() => LocalRewardService.PrepareMutation(_storage, _resources, new[] { new ConsumeData(_kind, 11, 1, 2) }, Array.Empty<ConsumeData>()));
            Assert.Throws<OverflowException>(() => LocalRewardService.PrepareMutation(_storage, _resources, new[] { Value(long.MaxValue), Value(1) }, Array.Empty<ConsumeData>()));
            Assert.Throws<OverflowException>(() => Prepare(0, long.MaxValue)); Assert.That(PrefsFixture.Read(_files), Is.EqualTo(before)); Assert.That(_notices, Is.Zero);
        }
        [Test]
        public void EmptyAndNetZeroTransactionsDoNotWriteAdvanceRevisionOrNotify()
        {
            Open(); byte[] before = PrefsFixture.Read(_files); long revision = _repository.Revision;
            Commit(0); Commit(200, 200); Assert.That(_storage.Save(), Is.False);
            Assert.That(PrefsFixture.Read(_files), Is.EqualTo(before)); Assert.That(_storage.SavedRevision, Is.Zero); Assert.That(_repository.Revision, Is.EqualTo(revision)); Assert.That(_notices, Is.Zero);
        }
        [Test]
        public void ReservationChangesInvalidatePreparationsEvenWithoutVisibleAmountChanges()
        {
            Open(); _resources.Reserve(new[] { Value(100) }); var preparation = Prepare(100); _resources.BeginRequest();
            Assert.Throws<LocalSaveConflictException>(() => LocalRewardService.Commit(_storage, _resources, preparation)); Assert.That(Persisted(), Is.EqualTo(1000));
        }

        [Test]
        public void ExactDocumentConflictDetectsDifferentDataAtSameRevision()
        {
            Open(); JObject changed = _files.Load().Document.Snapshot.Payload; changed["foreign"] = 91;
            PrefsFixture.Write(_files, Codec.Encode(new LocalSaveSnapshot(changed), _profile, 0, DateTime.UtcNow.AddSeconds(1)));
            Assert.Throws<LocalSaveConflictException>(() => Commit(1)); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Conflict)); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
            Assert.Throws<RepositoryRecoveryRequiredException>(() => _wealth.Clear()); _storage.Reload(); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Ready));
        }
        [Test]
        public void ExternalRevisionConflictNeverOverwritesTheOtherDocument()
        {
            Open(); var basis = _files.Load().Document; var changed = basis.Snapshot.Payload; changed["wealthInfos"][0]["quantity"] = 700;
            _files.Save(new LocalSaveSnapshot(changed), basis);
            Assert.Throws<LocalSaveConflictException>(() => Commit(100)); Assert.That(Persisted(), Is.EqualTo(700)); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
            _storage.Reload(); Assert.That(_resources.GetRaw(11), Is.EqualTo(700));
        }


        [Test]
        public void ConfirmedSaveAndInjectedMemoryFailureRequireRecoveryInsteadOfSaveFailure()
        {
            Open(); var preparation = Prepare(200, 50); long revision = _repository.Revision;
            typeof(RepositoryStorageAdapter).GetField("_failNextApplyForTesting", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(_storage, true);
            Assert.Throws<RepositoryRecoveryRequiredException>(() => LocalRewardService.Commit(_storage, _resources, preparation));
            Assert.That(Persisted(), Is.EqualTo(850)); Assert.That(_storage.SavedRevision, Is.EqualTo(1)); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_repository.Revision, Is.EqualTo(revision)); Assert.That(_notices, Is.Zero);
            Assert.Throws<RepositoryRecoveryRequiredException>(() => _wealth.UpdateJson(Data(1))); Assert.Throws<RepositoryRecoveryRequiredException>(() => Prepare(1));
            _storage.Reload(); Assert.That(_resources.GetRaw(11), Is.EqualTo(850));
            Assert.Throws<LocalSaveConflictException>(() => LocalRewardService.Commit(_storage, _resources, preparation));
        }

        [Test]
        public void ResourceDisposeInRecoveryKeepsRepositoryDisposableAndProfileReopenable()
        {
            Open();
            typeof(RepositoryStorageAdapter).GetField("_failNextApplyForTesting", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(_storage, true);
            Assert.Throws<RepositoryRecoveryRequiredException>(() => Commit(100));
            Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.RecoveryRequired));
            Assert.DoesNotThrow(() => _resources.Dispose()); Assert.That(_resources.IsDisposed, Is.True);
            Assert.DoesNotThrow(() => _repository.Dispose());
            CreateRepository(); Open(); Assert.That(_resources.GetRaw(11), Is.EqualTo(900));
        }
        [Test]
        public void ResourceDisposeAfterConflictDoesNotMaskTheOriginalFailure()
        {
            Open(); var basis = _files.Load().Document; var changed = basis.Snapshot.Payload; changed["wealthInfos"][0]["quantity"] = 700;
            _files.Save(new LocalSaveSnapshot(changed), basis);
            Assert.Throws<LocalSaveConflictException>(() => { using (_resources) Commit(100); });
            Assert.That(_resources.IsDisposed, Is.True); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Conflict));
            _repository.Dispose(); Assert.That(_repository.IsDisposed, Is.True);
            CreateRepository(); Open(); Assert.That(_resources.GetRaw(11), Is.EqualTo(700));
        }
        [Test]
        public void RecoveryMessagesSeparateReloadFromDisposeAndReopen()
        {
            Open(); var basis = _files.Load().Document; var changed = basis.Snapshot.Payload; changed["wealthInfos"][0]["quantity"] = 700;
            _files.Save(new LocalSaveSnapshot(changed), basis);
            Assert.Throws<LocalSaveConflictException>(() => Commit(100));
            var conflict = Assert.Throws<RepositoryRecoveryRequiredException>(() => _wealth.Clear());
            Assert.That(conflict.Message, Does.Contain("Reload")); Assert.That(conflict.Message, Does.Not.Contain("Dispose"));
            _storage.Reload(); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Ready));

            _repository.Dispose(); CreateRepository(); bool fail = true;
            _files = PrefsFixture.Create(_profile, _root, Codec, (key, value) => { if (fail) throw new IOException("synthetic PlayerPrefs failure"); PlayerPrefs.SetString(key, value); });
            Open();
            Assert.Throws<LocalSaveWriteException>(() => Commit(100)); fail = false;
            var uncertain = Assert.Throws<RepositoryRecoveryRequiredException>(() => _wealth.Clear());
            Assert.That(uncertain.Message, Does.Contain("Dispose")); Assert.That(uncertain.Message, Does.Not.StartWith("Reload"));
            var save = Assert.Throws<RepositoryRecoveryRequiredException>(() => _storage.Save()); Assert.That(save.Message, Does.Contain("Dispose"));
        }
        [Test]
        public void SessionResetReleasesProfileClaimsOfUndisposedRepositories()
        {
            string profile = "session:" + Guid.NewGuid().ToString("N"); var abandoned = new DataRepository(profile);
            Assert.Throws<InvalidOperationException>(() => new DataRepository(profile));
            var ownership = typeof(DataRepository).Assembly.GetType("jjevol.DataProfileOwnership");
            ownership.GetMethod("ResetSession", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, null);
            var next = new DataRepository(profile); next.Dispose(); abandoned.Dispose(); GC.KeepAlive(abandoned);
        }
        [Test]
        public void NotificationExceptionsDoNotReclassifyConfirmedDurableSuccess()
        {
            Open(); int last = 0;
            _resources.Changed += _ => throw new InvalidOperationException("storage observer failure"); _resources.Changed += _ => last++;
            LogAssert.Expect(LogType.Exception, new Regex("storage observer failure")); Commit(100);
            Assert.That(last, Is.EqualTo(1)); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Ready)); Assert.That(Persisted(), Is.EqualTo(900));
        }
        [TestCase("missing")] [TestCase("wrong")] [TestCase("null")]
        public void ExistingSchemaErrorsNeverInitializeOrOverwrite(string variant)
        {
            JObject payload = Data(1000); if (variant == "wrong") payload[RepositoryStorageAdapter.SchemaKey] = "other:v2"; if (variant == "null") payload[RepositoryStorageAdapter.SchemaKey] = JValue.CreateNull();
            _files.Save(new LocalSaveSnapshot(payload), 0, -1); byte[] before = PrefsFixture.Read(_files);
            Assert.Throws<InvalidDataException>(() => Open(initial: () => { Assert.Fail("Existing schema error must not initialize"); return Data(1); }));
            Assert.That(PrefsFixture.Read(_files), Is.EqualTo(before)); Assert.That(_wealth.Items.Count, Is.Zero);
        }
        [TestCase("corrupt")] [TestCase("future")] [TestCase("migration")]
        public void InvalidDocumentsArePreservedAndNeverAutomaticallyMigrated(string variant)
        {
            
            byte[] bytes = variant == "corrupt" ? Encoding.UTF8.GetBytes("synthetic corruption") : EnvelopeFixture(variant == "future" ? 99 : 0);
            PrefsFixture.Write(_files, bytes);
            Assert.Throws<InvalidDataException>(() => Open()); Assert.That(PrefsFixture.Read(_files), Is.EqualTo(bytes)); Assert.That(_wealth.Items.Count, Is.Zero);
        }
        [Test]
        public void ProfileMismatchAndCopiedForeignFileCannotBeUsed()
        {
            var other = PrefsFixture.Create("other:profile", _root, Codec);
            Assert.Throws<ArgumentException>(() => RepositoryStorageAdapter.Open(_repository, other, Schema, RepositoryStorageMode.LocalAuthority, () => Data(1)));
             PrefsFixture.Write(_files, Codec.Encode(new LocalSaveSnapshot(Data(1)), "other:profile", 0, DateTime.UtcNow));
            Assert.Throws<InvalidDataException>(() => Open()); Assert.That(_wealth.Items.Count, Is.Zero);
        }
        [Test]
        public void AdditionalEnvelopeAndUnrelatedPayloadFieldsArePreserved()
        {
            var payload = Data(1000); payload[RepositoryStorageAdapter.SchemaKey] = Schema; payload["foreign"] = new JObject { ["a"] = new JArray(1, 2) };
            JObject envelope = ParseEnvelope(Codec.Encode(new LocalSaveSnapshot(payload), _profile, 0, DateTime.UtcNow));
            envelope["foreignEnvelope"] = new JObject { ["b"] = 17 }; Resign(envelope);
             PrefsFixture.Write(_files, EncryptEnvelope(envelope));
            Open(); Commit(100);
            JObject saved = ParseEnvelope(PrefsFixture.Read(_files)); Assert.That((int)saved["foreignEnvelope"]["b"], Is.EqualTo(17)); Assert.That(JToken.DeepEquals(saved["payload"]["foreign"], payload["foreign"]), Is.True);
            Assert.That((bool)saved["payload"]["wealthInfos"][0]["opaque"]["flag"], Is.True);
        }


        [Test]
        public void ServerCacheFailureNeverRollsBackOrFailsAnAuthoritativeResponse()
        {
            bool fail = false; _files = PrefsFixture.Create(_profile, _root, Codec, (key, value) => { if (fail) throw new IOException("synthetic cache failure"); PlayerPrefs.SetString(key, value); });
            Open(RepositoryStorageMode.ServerCache); _resources.Reserve(new[] { Value(100) }); var request = _resources.BeginRequest();
            _resources.ApplyServerResponse(request, Data(900), false, "wealthInfos"); fail = true;
            Assert.Catch<IOException>(() => _storage.Save()); Assert.That(_resources.GetRaw(11), Is.EqualTo(900)); Assert.That(_storage.Mode, Is.EqualTo(RepositoryStorageMode.ServerCache));
            Assert.Throws<RepositoryRecoveryRequiredException>(() => Prepare(1)); _wealth.UpdateJson(Data(850)); Assert.That(_resources.GetRaw(11), Is.EqualTo(850));
            Assert.Throws<InvalidDataException>(() => _storage.RefreshCacheBasis()); Assert.That(_resources.GetRaw(11), Is.EqualTo(850)); Assert.That(_storage.IsDirty, Is.True);
        }
        [Test]
        public void RepositoryLifetimeInvalidatesOldPreparationsAndUiSubscriptions()
        {
            Open(); var old = _storage; var oldResources = _resources; var preparation = Prepare(100); int notices = 0; oldResources.Changed += _ => notices++;
            Reopen(); Commit(50); Assert.That(notices, Is.Zero);
            Assert.Throws<ObjectDisposedException>(() => old.Save()); Assert.Throws<LocalSaveConflictException>(() => LocalRewardService.Commit(_storage, _resources, preparation)); Assert.That(Persisted(), Is.EqualTo(950));
        }
        [Test]
        public void SchemaRegistrationAndCreatingThreadCannotBeBypassed()
        {
            Open(); using var note = new NoteContainer(); Assert.Throws<InvalidOperationException>(() => _repository.Register(note));
            Task.Run(() => { Assert.Throws<InvalidOperationException>(() => _storage.Save()); Assert.Throws<InvalidOperationException>(() => _storage.Reload()); }).GetAwaiter().GetResult();
        }
        [Test]
        public void MissingRequiredContainerAndLegacyNestedWealthAreNotGuessed()
        {
            JObject payload = new JObject { [RepositoryStorageAdapter.SchemaKey] = Schema, ["foreign"] = 7 };
            _files.Save(new LocalSaveSnapshot(payload), 0, -1); byte[] original = PrefsFixture.Read(_files);
            Assert.Throws<InvalidDataException>(() => Open()); Assert.That(PrefsFixture.Read(_files), Is.EqualTo(original));
            payload["wealthInfos"] = new JObject { ["alpha"] = new JObject { ["quantity"] = 1000 } };
            PrefsFixture.Write(_files, Codec.Encode(new LocalSaveSnapshot(payload), _profile, 1, DateTime.UtcNow));
            Assert.Throws<InvalidDataException>(() => Open()); Assert.That(_wealth.Items.Count, Is.Zero);
        }
        [Test]
        public void CorruptReloadBlocksLocalMutationsUntilExplicitRecovery()
        {
            Open(); PlayerPrefs.SetString(_files.Slot0Key, "synthetic reload corruption");
            Assert.Throws<InvalidDataException>(() => _storage.Reload()); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.RecoveryRequired));
            Assert.Throws<RepositoryRecoveryRequiredException>(() => _wealth.Clear()); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
        }
        [Test]
        public void RevisionOverflowFailsBeforeAnyFileOrMemoryChange()
        {
            var payload = Data(1000); payload[RepositoryStorageAdapter.SchemaKey] = Schema;
             byte[] bytes = Codec.Encode(new LocalSaveSnapshot(payload), _profile, long.MaxValue, DateTime.UtcNow); PrefsFixture.Write(_files, bytes);
            Open(); Assert.Throws<OverflowException>(() => Commit(100)); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Ready));
            Assert.That(PrefsFixture.Read(_files), Is.EqualTo(bytes)); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_notices, Is.Zero);
        }

        [Test]
        public void NoOpStillChecksExactDocumentBasis()
        {
            Open(); var payload = _files.Load().Document.Snapshot.Payload; payload["foreign"] = 1;
            PrefsFixture.Write(_files, Codec.Encode(new LocalSaveSnapshot(payload), _profile, 0, DateTime.UtcNow.AddSeconds(1)));
            Assert.Throws<LocalSaveConflictException>(() => Commit(0)); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Conflict)); Assert.That(_notices, Is.Zero);
        }
        [Test]
        public void ReloadClearsAllPreviewsBeforeFinalObserversAndInvalidatesTokens()
        {
            Open(); _resources.Reserve(new[] { Value(100) }); var request = _resources.BeginRequest(); _resources.Reserve(new[] { Value(50) });
            var basis = _files.Load().Document; var payload = basis.Snapshot.Payload; payload["wealthInfos"][0]["quantity"] = 700; _files.Save(new LocalSaveSnapshot(payload), basis);
            _wealth.Changed += _ => { Assert.That(_resources.Get(11), Is.EqualTo(700)); Assert.That(_resources.InFlightRequest, Is.Null); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Ready)); };
            _storage.Reload(); Assert.That(_resources.GetRaw(11), Is.EqualTo(700));
            Assert.Throws<InvalidOperationException>(() => _resources.ApplyServerResponse(request, Data(600), false, "wealthInfos"));
        }
        [Test]
        public void SeparateProfilesNeverShareFilesOrLatePreparedMutations()
        {
            Open(); var preparation = Prepare(100);
            string otherProfile = "step03:" + Guid.NewGuid().ToString("N");
            using var other = new DataRepository(otherProfile); var wealth = new WealthContainer(); other.Register(wealth); var table = new TestTable(); table.LoadDatas();
            using var resources = new ResourceService(other, table, _kind); var files = PrefsFixture.Create(otherProfile, _root, Codec);
            var storage = RepositoryStorageAdapter.Open(other, files, Schema, RepositoryStorageMode.LocalAuthority, () => Data(300));
            Assert.That(files.Slot0Key, Is.Not.EqualTo(_files.Slot0Key));
            Assert.Throws<LocalSaveConflictException>(() => LocalRewardService.Commit(storage, resources, preparation)); Assert.That(resources.GetRaw(11), Is.EqualTo(300)); Assert.That(Persisted(), Is.EqualTo(1000));
        }
        [Test]
        public void RealPlayerPrefsHundredUpdatesPreserveContainerIdentityAndReadOnlyPreviousRevision()
        {
            Open(); var container = _resources.Container;
            for (int i = 1; i <= 100; i++) { _storage.ApplyAndSave(Data(1000 + i), true, "wealthInfos"); Assert.That(_files.Load().Document.StateRevision, Is.EqualTo(i)); Assert.That(_wealth.Get("alpha"), Is.EqualTo(1000 + i)); Assert.That(_resources.Container, Is.SameAs(container)); }
            PlayerPrefs.SetString(_files.Slot0Key, "damaged-synthetic-slot");
            Assert.Throws<InvalidDataException>(() => _storage.Reload()); Assert.That(_wealth.Get("alpha"), Is.EqualTo(1100));
            var recovery = _files.LoadRecovery(); Assert.That(recovery.Status, Is.EqualTo(LocalSaveLoadStatus.RecoveredBackup)); Assert.That(recovery.Document.StateRevision, Is.EqualTo(99));
            Assert.That((long)recovery.Document.Snapshot.Payload["wealthInfos"][0]["quantity"], Is.EqualTo(1099));
            Assert.Throws<RepositoryRecoveryRequiredException>(() => _storage.Save()); Assert.That(PlayerPrefs.GetString(_files.Slot0Key), Is.EqualTo("damaged-synthetic-slot"));
        }
        private byte[] EnvelopeFixture(int version)
        {
            var payload = Data(1); payload[RepositoryStorageAdapter.SchemaKey] = Schema;
            JObject envelope = ParseEnvelope(Codec.Encode(new LocalSaveSnapshot(payload), _profile, 0, DateTime.UtcNow));
            envelope["saveVersion"] = version; Resign(envelope); return EncryptEnvelope(envelope);
        }
        private static void Resign(JObject envelope)
        { envelope.Remove("integrity"); envelope["integrity"] = (string)typeof(LocalSaveCodec).GetMethod("Hash", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { envelope }); }
        private byte[] EncryptEnvelope(JObject envelope) => Encryption.Encrypt(Encoding.UTF8.GetBytes(envelope.ToString(Formatting.None)), _profile);
        private JObject ParseEnvelope(byte[] bytes)
        { using var reader = new JsonTextReader(new StringReader(Encoding.UTF8.GetString(Encryption.Decrypt(bytes, _profile)))) { DateParseHandling = DateParseHandling.None }; return JObject.Load(reader); }
        private sealed class TestTable : WealthTable
        { public override void LoadDatas() { _DataClear(); InsertData(TSVRow.FromTsv("id\ttype\n11\talpha\n22\tbeta")); } }
        private sealed class NoteContainer : DataContainer
        {
            public bool FailExport;
            public NoteContainer() : base("notes", new JArray()) { }
            public string Text => ((JArray)State).First?.Value<string>("text");
            protected override StateChange ParseState(JObject data, bool replace)
            {
                JArray rows = ContainerJson.RequireArray(data, DataKey);
                foreach (JToken row in rows) if (row is not JObject || row["text"]?.Type != JTokenType.String) throw new InvalidDataException("Invalid synthetic note");
                return new StateChange(rows.DeepClone(), JToken.DeepEquals(rows, (JArray)State) ? Array.Empty<string>() : new[] { "all" });
            }
            protected override JObject WriteState(object state) => FailExport ? throw new InvalidOperationException("Synthetic export failure") : new JObject { [DataKey] = ((JArray)state).DeepClone() };
        }
    }
}
