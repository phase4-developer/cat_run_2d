using System;
using System.Collections.Generic;
using jjevol;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace jjevol.Tests
{
    public sealed class ConsumeCompatibilityTests
    {
        private enum GameKind { Coins = 812, Materials = 9001, Drop = 50 }
        [TestCase("consumeType", "consumeId", "consumeVal")]
        [TestCase("rewardType", "rewardId", "rewardValue")]
        [TestCase("priceType", "priceId", "priceValue")]
        [TestCase("sellType", "sellId", "sellValue")]
        [TestCase("consumeType", "consumeId", "consumeValue")]
        public void ExistingJsonAliasesPreserveLongValues(string type, string id, string value)
        {
            var data = new ConsumeData(new JObject { [type] = 1, [id] = 41, [value] = long.MaxValue });
            Assert.That(data.TypeId, Is.EqualTo(new ConsumeTypeId(1)));
            Assert.That(data.consumeId, Is.EqualTo(41));
            Assert.That(data.consumeVal, Is.EqualTo(long.MaxValue));
            Assert.That(data.UniqueID, Is.EqualTo("1_41"));
            Assert.That(ConsumeDataExt.TryParseUniqueID(data.UniqueID, out var parsedType, out var parsedId), Is.True);
            Assert.That(parsedType, Is.EqualTo(data.TypeId));
            Assert.That(parsedId, Is.EqualTo(data.ItemId));
            Assert.That((long)data.ExportJson()["consumeVal"], Is.EqualTo(long.MaxValue));
        }

        [Test]
        public void RewardEnvelopeSourceAndCloneArePreserved()
        {
            var source = new ConsumeData(new ConsumeTypeId((int)GameKind.Materials), 2, 3);
            var value = new ConsumeData(new ConsumeTypeId((int)GameKind.Coins), 41, 7);
            value.SetRewardResult(source);
            source.SetConsumeVal(999);
            var restored = new ConsumeData(value.ExportJson());
            var clone = restored.Clone(2);
            Assert.That(restored.consumeVal, Is.EqualTo(7));
            Assert.That(restored.prevRewardData.consumeVal, Is.EqualTo(3));
            Assert.That(clone.consumeVal, Is.EqualTo(14));
            Assert.That(clone.sourceData, Is.Not.SameAs(restored.sourceData));
            Assert.That((long)clone.ExportJson()["grantedData"]["consumeValue"], Is.EqualTo(14));
        }

        [Test]
        public void TsvListsReuseLastTypeAndIdAndRejectMalformedQuantities()
        {
            var row = TSVRow.FromTsv("rewardType\trewardId\trewardValue\n812\t41\t3;2147483648")[0];
            row.ImportDatas(true, out var values);
            Assert.That(values.Count, Is.EqualTo(2));
            Assert.That(values[1].consumeId, Is.EqualTo(41));
            Assert.That(values[1].consumeVal, Is.EqualTo(2147483648L));
            var merged = ConsumeDataExt.MergeList(values);
            Assert.That(merged[0].consumeVal, Is.EqualTo(2147483651L));
            values[0].SetConsumeVal(99);
            Assert.That(merged[0].consumeVal, Is.EqualTo(2147483651L));
            var invalid = TSVRow.FromTsv("rewardType\trewardId\trewardValue\n812\t41\tinvalid")[0];
            Assert.Throws<FormatException>(() => invalid.ImportDatas(true, out _));
        }

        [Test]
        public void ExactIntAndLongDataRemainIndependentWithoutGlobalStorageFactories()
        {
            var data = new ConsumeData(new ConsumeTypeId((int)GameKind.Coins), int.MaxValue, long.MaxValue);
            var copy = data.Clone();
            data.SetConsumeVal(long.MinValue);
            Assert.That(data.consumeVal, Is.EqualTo(long.MinValue));
            Assert.That(copy.consumeVal, Is.EqualTo(long.MaxValue));
            Assert.That(data.consumeId, Is.EqualTo(int.MaxValue));
            Assert.That(copy.consumeId, Is.EqualTo(int.MaxValue));
            data.consumeId = 7;
            Assert.That(copy.consumeId, Is.EqualTo(int.MaxValue));
        }

        [Test]
        public void GamePoliciesRemainCallableAndMissingRequiredProviderFailsExplicitly()
        {
            var data = new ConsumeData(new ConsumeTypeId((int)GameKind.Coins), 41, 1);
            Assert.That(data.Clone().consumeVal, Is.EqualTo(1));
            Assert.Throws<ArgumentNullException>(() => data.Present(null));
            var drop = new ConsumeData(new ConsumeTypeId((int)GameKind.Drop), 9, 1);
            Assert.Throws<ArgumentNullException>(() => drop.DropReward(null));
            var provider = new Provider();
            Assert.That(data.Present(provider).Table, Is.SameAs(provider.Row));
            Assert.That(data.Present(provider).Grade, Is.EqualTo(4));
            Assert.That(data.Present(provider).Icon, Is.EqualTo("fixture-icon"));
            Assert.That(ConsumeDataGameExtensions.FromItem(provider.Row, provider.FromItem).consumeVal, Is.EqualTo(12));
            Assert.That(drop.DropReward(provider.DropReward)[0].consumeVal, Is.EqualTo(12));
            Assert.That(drop.GetDropList(provider.GetDropList, new ConsumeTypeId(1))[0].consumeId, Is.EqualTo(41));
        }

        [Test]
        public void ExplicitModelsAndConverterMustOperateOnTheirOwnInstance()
        {
            var first = new ConsumeData(new ConsumeTypeId((int)GameKind.Coins), 1, 10);
            var second = new ConsumeData(new ConsumeTypeId((int)GameKind.Coins), 2, 20);
            second.UpdateJson(JObject.Parse("{\"consumeVal\":30}"));
            var restored = JsonConvert.DeserializeObject<List<ConsumeData>>(JsonConvert.SerializeObject(new[] { first, second }));
            Assert.That(first.consumeId, Is.EqualTo(1));
            Assert.That(first.consumeVal, Is.EqualTo(10));
            Assert.That(restored[0].consumeVal, Is.EqualTo(10));
            Assert.That(restored[1].consumeVal, Is.EqualTo(30));
            restored[0].SetConsumeVal(99);
            Assert.That(first.consumeVal, Is.EqualTo(10));
        }

        [Test]
        public void OriginalUtcDateConverterRetainsFormatAndInvalidDefault()
        {
            var settings = new JsonSerializerSettings { Converters = { new DateTimeConverter() }, DateParseHandling = DateParseHandling.None };
            var utc = new DateTime(2026, 1, 2, 3, 4, 5, DateTimeKind.Utc);
            Assert.That(JsonConvert.SerializeObject(utc, settings), Is.EqualTo("\"20260102030405\""));
            Assert.That(JsonConvert.DeserializeObject<DateTime>("\"2026-01-02T12:04:05+09:00\"", settings), Is.EqualTo(utc));
            Assert.That(JsonConvert.DeserializeObject<DateTime>("\"invalid\"", settings), Is.EqualTo(DateTime.MinValue));
        }

        private sealed class Provider : IConsumePresentationProvider
        {
            public readonly TableData Row = new WealthData(TSVRow.FromTsv("id\tgrade\ttype\n41\t4\tfixture")[0]);
            public bool TryResolve(ConsumeTypeId typeId, int itemId, out ConsumePresentation presentation)
            {
                bool found = typeId == new ConsumeTypeId((int)GameKind.Coins) && itemId == Row.id;
                presentation = found ? new ConsumePresentation(Row, "fixture-icon") : default; return found;
            }
            public ConsumePresentation Resolve(ConsumeData data) => new ConsumePresentation(Row, "fixture-icon");
            public ConsumeData FromItem(TableData item) => new ConsumeData(new ConsumeTypeId((int)GameKind.Coins), item.id, 12);
            public List<ConsumeData> DropReward(ConsumeData data) => new List<ConsumeData> { FromItem(Row) };
            public List<ConsumeData> GetDropList(ConsumeData data, ConsumeTypeId filter) => DropReward(data);
        }
    }
}
