using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tests
{
    public sealed class ResourceReservationTests
    {
        private DataRepository _repository;
        private WealthContainer _wealth;
        private TestTable _table;
        private ResourceService _resources;
        private readonly ConsumeTypeId _kind = new ConsumeTypeId(812);
        private int _notices;
        private ResourceChange _last;
        [SetUp]
        public void SetUp()
        {
            _repository = new DataRepository("b:" + Guid.NewGuid().ToString("N"));
            _wealth = new WealthContainer(); _repository.Register(_wealth);
            _wealth.ImportJson(Data(1000));
            _table = new TestTable(); _table.LoadDatas();
            _resources = new ResourceService(_repository, _table, _kind);
            _notices = 0; _last = null;
            _resources.Changed += change => { _notices++; _last = change; };
        }
        [TearDown] public void TearDown() => _repository.Dispose();
        private ConsumeData Cost(long quantity, int id = 11) => new ConsumeData(_kind, id, quantity);
        private void Reserve(long quantity) => _resources.Reserve(new[] { Cost(quantity) });
        private static JObject Data(long quantity) => JObject.Parse("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":" + quantity.ToString(System.Globalization.CultureInfo.InvariantCulture) + "}]}");
        private ResourceRequest Send(long quantity = 100) { Reserve(quantity); return _resources.BeginRequest(); }

        [Test]
        public void ReadsUseSameContainerAndDoNotCreateMissingBalances()
        {
            JObject before = _repository.ExportJson();
            Assert.That(_resources.Container, Is.SameAs(_wealth));
            Assert.That(_resources.Repository, Is.SameAs(_repository));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
            Assert.That(_resources.Get(_kind, 11), Is.EqualTo(1000));
            Assert.That(_resources.GetRaw(Cost(1)), Is.EqualTo(1000));
            Assert.That(_resources.Get(22), Is.Zero);
            Assert.That(JToken.DeepEquals(before, _repository.ExportJson()), Is.True);
            Assert.That(_wealth.GetItem("beta"), Is.Null);
        }
        [Test]
        public void PendingAddsDuplicateCostsWithoutChangingExportOrRaw()
        {
            JObject before = _wealth.ExportJson(); long revision = _repository.Revision;
            Reserve(100);
            _resources.Reserve(new[] { Cost(20), Cost(30) });
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
            Assert.That(_resources.Get(11), Is.EqualTo(850));
            Assert.That(_notices, Is.EqualTo(2));
            Assert.That(_last.RawChanged, Is.False); Assert.That(_last.AvailableChanged, Is.True);
            Assert.That(_repository.Revision, Is.EqualTo(revision));
            Assert.That(JToken.DeepEquals(before, _wealth.ExportJson()), Is.True);
        }
        [Test]
        public void CostChecksAggregateDuplicatesAndDoNotReserve()
        {
            Assert.That(_resources.CheckSpend(new[] { Cost(600), Cost(401) }), Is.False);
            Assert.That(_resources.CheckSpend(new[] { Cost(600), Cost(400) }), Is.True);
            Reserve(100);
            Assert.That(_resources.CheckSpend(Cost(901)), Is.False);
            Assert.That(_resources.CheckSpend(Cost(900)), Is.True);
            Assert.That(_notices, Is.EqualTo(1));
        }
        [Test]
        public void PendingMovesToFlightWithoutVisibleChangeAndNewPendingIsAllowed()
        {
            ResourceRequest request = Send();
            Assert.That(_resources.InFlightRequest, Is.SameAs(request));
            Assert.That(request.ProfileId, Is.EqualTo(_repository.ProfileId));
            Assert.That(_resources.Get(11), Is.EqualTo(900)); Assert.That(_notices, Is.EqualTo(1));
            Reserve(50); Assert.That(_resources.Get(11), Is.EqualTo(850));
            Assert.Throws<InvalidOperationException>(() => _resources.BeginRequest());
        }
        [TestCase(false)] [TestCase(true)]
        public void ServerAckAndReservationRemovalAreVisibleAtomicallyAtEveryNotification(bool replace)
        {
            ResourceRequest request = Send(); Reserve(50);
            int container = 0, repository = 0, resource = 0;
            Action check = () => { Assert.That(_resources.GetRaw(11), Is.EqualTo(900)); Assert.That(_resources.Get(11), Is.EqualTo(850)); Assert.That(_resources.InFlightRequest, Is.Null); };
            _wealth.Changed += _ => { container++; check(); };
            _repository.Changed += _ => { repository++; check(); };
            _resources.Changed += _ => { resource++; check(); };
            _resources.ApplyServerResponse(request, Data(900), replace, "wealthInfos");
            Assert.That(new[] { container, repository, resource }, Is.EqualTo(new[] { 1, 1, 1 }));
            Assert.That(_notices, Is.EqualTo(3)); Assert.That(_last.RawChanged, Is.True); Assert.That(_last.AvailableChanged, Is.False);
            Assert.That(_last.Repository, Is.SameAs(_repository)); Assert.That(_last.ProfileId, Is.EqualTo(_repository.ProfileId));
            Assert.That(_last.TypeId, Is.EqualTo(_kind)); Assert.That(_last.ItemIds, Is.EqualTo(new[] { 11 }));
            Assert.That(_last.RepositoryRevision, Is.EqualTo(_repository.Revision));
            Assert.Throws<InvalidOperationException>(() => _resources.ApplyServerResponse(request, Data(800), replace, "wealthInfos"));
            Assert.That(_resources.Get(11), Is.EqualTo(850));
        }
        [Test]
        public void NoOpRawResponseStillReleasesFlightAndNotifiesOnlyService()
        {
            var request = Send(); int raw = 0;
            _repository.Changed += _ => raw++;
            _wealth.Changed += _ => raw++;
            _resources.ApplyServerResponse(request, Data(1000), false, "wealthInfos");
            Assert.That(raw, Is.Zero); Assert.That(_resources.Get(11), Is.EqualTo(1000)); Assert.That(_notices, Is.EqualTo(2));
        }
        [Test]
        public void CancelPendingAndKnownNotAppliedReleaseOnlyTheirOwnHolds()
        {
            var request = Send(); Reserve(50);
            _resources.CancelPending(); Assert.That(_resources.Get(11), Is.EqualTo(900));
            Reserve(20); _resources.FailRequest(request, ResourceRequestFailure.KnownNotApplied);
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_resources.Get(11), Is.EqualTo(980));
            Assert.That(_resources.InFlightRequest, Is.Null);
            Assert.Throws<InvalidOperationException>(() => _resources.FailRequest(request, ResourceRequestFailure.KnownNotApplied));
        }
        [Test]
        public void UncertainOutcomeRetainsHoldsAndRequiresAuthoritativeReconciliation()
        {
            var request = Send(); Reserve(50); int notices = _notices;
            _resources.FailRequest(request, ResourceRequestFailure.Uncertain);
            Assert.That(_resources.RequiresResynchronization, Is.True); Assert.That(_resources.Get(11), Is.EqualTo(850)); Assert.That(_notices, Is.EqualTo(notices));
            Assert.Throws<InvalidOperationException>(() => Reserve(1));
            Assert.Throws<InvalidOperationException>(() => _resources.BeginRequest());
            Assert.Throws<InvalidOperationException>(() => _resources.FailRequest(request, ResourceRequestFailure.KnownNotApplied));
            _resources.Resynchronize(Data(900), "wealthInfos");
            Assert.That(_resources.Get(11), Is.EqualTo(900)); Assert.That(_resources.RequiresResynchronization, Is.False);
            Assert.Throws<InvalidOperationException>(() => _resources.ApplyServerResponse(request, Data(800), false, "wealthInfos"));
        }
        [Test]
        public void TrustedLateAckCanResolveAnUncertainRequestWithoutDroppingNewPending()
        {
            var request = Send(); Reserve(50); _resources.FailRequest(request, ResourceRequestFailure.Uncertain);
            _resources.ApplyServerResponse(request, Data(900), false, "wealthInfos");
            Assert.That(_resources.RequiresResynchronization, Is.False); Assert.That(_resources.Get(11), Is.EqualTo(850));
        }
        [TestCase("{}")]
        [TestCase("{\"wealthInfos\":null}")]
        [TestCase("{\"wealthInfos\":[]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\"}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":-1}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":\"900\"}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":9223372036854775808}]}")]
        [TestCase("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"quantity\":900},{\"wealthType\":\"alpha\",\"quantity\":900}]}")]
        public void InvalidAckPreservesRawAndBothHoldsAndMarksUncertainty(string text)
        {
            var request = Send(); Reserve(50); long revision = _repository.Revision; int notices = _notices;
            JObject input = JObject.Parse(text), before = (JObject)input.DeepClone();
            Assert.Throws<InvalidDataException>(() => _resources.ApplyServerResponse(request, input, false, "wealthInfos"));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_resources.Get(11), Is.EqualTo(850));
            Assert.That(_resources.InFlightRequest, Is.SameAs(request)); Assert.That(_resources.RequiresResynchronization, Is.True);
            Assert.That(_repository.Revision, Is.EqualTo(revision)); Assert.That(_notices, Is.EqualTo(notices)); Assert.That(JToken.DeepEquals(input, before), Is.True);
        }
        [Test]
        public void InvalidOtherContainerPreventsBothWealthCommitAndHoldRelease()
        {
            var other = new OtherContainer(); _repository.Register(other);
            var request = Send(); JObject response = Data(900); response["other"] = 1;
            Assert.Throws<InvalidDataException>(() => _resources.ApplyServerResponse(request, response, true, "wealthInfos", "other"));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_resources.Get(11), Is.EqualTo(900)); Assert.That(other.Amount, Is.Zero);
            response["other"] = new JArray(2);
            _resources.ApplyServerResponse(request, response, true, "wealthInfos", "other");
            Assert.That(other.Amount, Is.EqualTo(2)); Assert.That(_resources.Get(11), Is.EqualTo(900));
        }
        [Test]
        public void ExplicitResponseScopeAndOperationAreRequired()
        {
            var request = Send();
            Assert.Throws<InvalidDataException>(() => _resources.ApplyServerResponse(request, Data(900), false));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
            Assert.Throws<InvalidDataException>(() => _resources.Resynchronize(new JObject(), "wealthInfos"));
            Assert.That(_resources.RequiresResynchronization, Is.True);
        }
        [Test]
        public void FullResponseMayAuthoritativelyRemoveAnAbsentWealthRow()
        {
            var request = Send();
            _resources.ApplyServerResponse(request, new JObject { ["wealthInfos"] = new JArray() }, true, "wealthInfos");
            Assert.That(_resources.GetRaw(11), Is.Zero); Assert.That(_resources.Get(11), Is.Zero);
        }
        [Test]
        public void UnsupportedKindAndUnregisteredItemAreDistinctFailures()
        {
            Assert.Throws<NotSupportedException>(() => _resources.GetRaw(new ConsumeTypeId(1), 11));
            Assert.Throws<ArgumentException>(() => _resources.GetRaw(_kind, 999));
            Assert.Throws<NotSupportedException>(() => _resources.Reserve(new[] { new ConsumeData(new ConsumeTypeId(1), 11, 1) }));
            Assert.Throws<ArgumentException>(() => _resources.CheckSpend(Cost(1, 999)));
            Assert.That(_notices, Is.Zero);
        }
        [TestCase(-1L)] [TestCase(long.MinValue)]
        public void NegativeCostsCannotReserveOrPassChecks(long quantity)
        { Assert.Throws<ArgumentOutOfRangeException>(() => Reserve(quantity)); Assert.Throws<ArgumentOutOfRangeException>(() => _resources.CheckSpend(Cost(quantity))); Assert.That(_notices, Is.Zero); }
        [Test]
        public void InvalidCostsAndInsufficiencyCannotPartiallyReserve()
        {
            Assert.Throws<ArgumentNullException>(() => _resources.Reserve(null));
            Assert.Throws<ArgumentException>(() => _resources.Reserve(new ConsumeData[] { Cost(1), null }));
            Assert.Throws<NotSupportedException>(() => _resources.Reserve(new[] { new ConsumeData(_kind, 11, 1, 2) }));
            Assert.Throws<InsufficientResourceException>(() => _resources.Reserve(new[] { Cost(100), Cost(1, 22) }));
            Assert.That(_resources.Get(11), Is.EqualTo(1000)); Assert.That(_notices, Is.Zero);
        }
        [Test]
        public void CheckedOverflowAcrossPendingAndFlightDoesNotChangeState()
        {
            _wealth.UpdateJson(Data(long.MaxValue));
            Reserve(long.MaxValue); var request = _resources.BeginRequest(); int notices = _notices;
            Assert.Throws<OverflowException>(() => Reserve(1));
            Assert.Throws<OverflowException>(() => _resources.CheckSpend(new[] { Cost(long.MaxValue), Cost(1) }));
            Assert.That(_resources.Get(11), Is.Zero); Assert.That(_resources.InFlightRequest, Is.SameAs(request)); Assert.That(_notices, Is.EqualTo(notices));
        }
        [Test]
        public void CheckedPendingOverflowAndAmountsAboveIntRemainExact()
        {
            _wealth.UpdateJson(Data(long.MaxValue)); Reserve(long.MaxValue);
            Assert.Throws<OverflowException>(() => Reserve(1));
            _resources.CancelPending(); Reserve(2147483648L);
            Assert.That(_resources.Get(11), Is.EqualTo(long.MaxValue - 2147483648L));
        }
        [Test]
        public void UnrelatedConfirmedUpdatesNotifyFinalRawAndAvailableWithoutMutatingHolds()
        {
            Reserve(100); _wealth.UpdateJson(Data(1100));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1100)); Assert.That(_resources.Get(11), Is.EqualTo(1000));
            Assert.That(_last.RawChanged && _last.AvailableChanged, Is.True);
            _wealth.UpdateJson(Data(50)); Assert.That(_resources.Get(11), Is.Zero);
            _resources.CancelPending(); Assert.That(_resources.Get(11), Is.EqualTo(50));
        }
        [Test]
        public void NoVisibleChangesEmitNoInvalidation()
        {
            Reserve(0); _resources.CancelPending(); _resources.BeginRequest();
            _repository.UpdateJson(Data(1000), "wealthInfos");
            _wealth.UpdateJson(JObject.Parse("{\"wealthInfos\":[{\"wealthType\":\"alpha\",\"metadata\":7}]}"));
            Assert.That(_notices, Is.Zero);
        }
        [Test]
        public void AllNotificationBoundariesRejectReentrantMutationsButPermitReads()
        {
            Action assert = () =>
            {
                _ = _resources.Get(11); _ = _resources.GetRaw(11);
                Assert.That(_resources.CheckSpend(Cost(1)), Is.True);
                Assert.Throws<InvalidOperationException>(() => Reserve(1));
                Assert.Throws<InvalidOperationException>(() => _resources.CancelPending());
                Assert.Throws<InvalidOperationException>(() => _resources.Dispose());
                Assert.Throws<InvalidOperationException>(() => _repository.UpdateJson(Data(1001), "wealthInfos"));
                Assert.Throws<InvalidOperationException>(() => _repository.Dispose());
            };
            int calls = 0;
            _wealth.Changed += _ => { calls++; assert(); };
            _repository.Changed += _ => { calls++; assert(); };
            _resources.Changed += _ => { calls++; assert(); };
            _wealth.UpdateJson(Data(1001)); Assert.That(calls, Is.EqualTo(3));
            Reserve(1); Assert.That(calls, Is.EqualTo(4));
        }
        [Test]
        public void SubscriberExceptionCannotTurnAckIntoFailureOrSkipLaterSubscribers()
        {
            var request = Send(); int calls = 0;
            _wealth.Changed += _ => throw new InvalidOperationException("container-observer");
            _repository.Changed += _ => throw new InvalidOperationException("repository-observer");
            _resources.Changed += _ => throw new InvalidOperationException("resource-observer");
            _resources.Changed += _ => calls++;
            LogAssert.Expect(LogType.Exception, new Regex("container-observer"));
            LogAssert.Expect(LogType.Exception, new Regex("repository-observer"));
            LogAssert.Expect(LogType.Exception, new Regex("resource-observer"));
            Assert.DoesNotThrow(() => _resources.ApplyServerResponse(request, Data(900), false, "wealthInfos"));
            Assert.That(calls, Is.EqualTo(1)); Assert.That(_resources.RequiresResynchronization, Is.False); Assert.That(_resources.InFlightRequest, Is.Null);
        }
        [Test]
        public void UnsubscribedUiReceivesNoFurtherSignals()
        {
            int calls = 0; Action<ResourceChange> listener = _ => calls++;
            _resources.Changed += listener; Reserve(1); _resources.Changed -= listener; _resources.CancelPending();
            Assert.That(calls, Is.EqualTo(1));
        }
        [Test]
        public void ProfileReplacementInvalidatesOldCallbacksEvenWhenProfileIdIsReused()
        {
            string profile = _repository.ProfileId; var request = Send(); var old = _resources;
            _repository.Dispose();
            using var next = new DataRepository(profile); var wealth = new WealthContainer(); next.Register(wealth); wealth.ImportJson(Data(700));
            using var resources = new ResourceService(next, _table, _kind);
            Assert.Throws<ObjectDisposedException>(() => old.ApplyServerResponse(request, Data(600), false, "wealthInfos"));
            Assert.Throws<InvalidOperationException>(() => resources.ApplyServerResponse(request, Data(600), false, "wealthInfos"));
            Assert.That(resources.Get(11), Is.EqualTo(700)); Assert.That(resources.RequiresResynchronization, Is.False);
        }
        [Test]
        public void FailedWealthReloadRestoresRowsAndTypeLookup()
        {
            var rows = new RowSource { Rows = TSVRow.FromTsv("id\ttype\n11\talpha\n22\tbeta") };
            var table = new WealthTable(); table.LoadDatas(rows); Assert.That(table.GetId("beta"), Is.EqualTo(22));
            rows.Rows = TSVRow.FromTsv("id\ttype\n33\tgamma\n33\tdelta");
            Assert.Throws<InvalidDataException>(() => table.LoadDatas(rows));
            Assert.That(table.Dict.Keys, Is.EquivalentTo(new[] { 11, 22 }));
            Assert.That(table.GetId("alpha"), Is.EqualTo(11)); Assert.That(table.GetId("gamma"), Is.Zero);
        }
        [Test]
        public void RequestSequenceRestartsWithEachServiceAndIsNotDurable()
        {
            var first = Send(); Assert.That(first.Sequence, Is.EqualTo(1));
            _resources.FailRequest(first, ResourceRequestFailure.KnownNotApplied); _resources.Dispose();
            using var next = new ResourceService(_repository, _table, _kind);
            next.Reserve(new[] { Cost(100) });
            Assert.That(next.BeginRequest().Sequence, Is.EqualTo(first.Sequence), "A durable idempotency key needs a game-owned persisted ID.");
        }
        [Test]
        public void ForeignProfileAndOldRequestCannotReconcileNewFlight()
        {
            var old = Send(); _resources.FailRequest(old, ResourceRequestFailure.KnownNotApplied); var current = Send(50);
            Assert.That(current.Sequence, Is.GreaterThan(old.Sequence));
            Assert.Throws<InvalidOperationException>(() => _resources.ApplyServerResponse(old, Data(850), false, "wealthInfos"));
            Assert.That(_resources.InFlightRequest, Is.SameAs(current)); Assert.That(_resources.RequiresResynchronization, Is.False);
            using var other = new DataRepository("b:" + Guid.NewGuid().ToString("N")); var wealth = new WealthContainer(); other.Register(wealth); wealth.ImportJson(Data(20));
            using var service = new ResourceService(other, _table, _kind);
            Assert.Throws<InvalidOperationException>(() => service.FailRequest(current, ResourceRequestFailure.Uncertain)); Assert.That(service.Get(11), Is.EqualTo(20));
        }
        [Test]
        public void OneOverlayOwnerAndRepositoryOwnedLifetimeAreEnforced()
        {
            Assert.Throws<InvalidOperationException>(() => new ResourceService(_repository, _table, _kind));
            _resources.Dispose(); Assert.That(_resources.IsDisposed, Is.True);
            Assert.Throws<ObjectDisposedException>(() => _resources.Get(11));
            using var replacement = new ResourceService(_repository, _table, _kind);
            Assert.That(replacement.Get(11), Is.EqualTo(1000));
        }
        [Test]
        public void TableMetadataIsBoundAtInitializationAndReloadCannotRetargetHolds()
        {
            Reserve(100); _table.Rows = TSVRow.FromTsv("id\ttype\n11\tgamma"); _table.LoadDatas();
            Assert.That(_resources.Get(11), Is.EqualTo(900)); Assert.That(_resources.Get(22), Is.Zero);
        }
        [Test]
        public void WorkerQueriesAndMutationsAreRejected()
        {
            Task.Run(() => { Assert.Throws<InvalidOperationException>(() => _resources.Get(11)); Assert.Throws<InvalidOperationException>(() => Reserve(1)); }).GetAwaiter().GetResult();
        }
        [TestCase(-1)] [TestCase(0)] [TestCase(1)] [TestCase(9001)]
        public void ExplicitGameKindUsesTheConfiguredStableWireId(int kind)
        {
            _resources.Dispose(); using var service = new ResourceService(_repository, _table, new ConsumeTypeId(kind));
            service.Reserve(new[] { new ConsumeData(new ConsumeTypeId(kind), 11, 10) });
            Assert.That(service.GetRaw(11), Is.EqualTo(1000)); Assert.That(service.Get(11), Is.EqualTo(990));
        }
        [Test]
        public void InputDtosAndSuccessfulResponseAreDetached()
        {
            var cost = Cost(100); _resources.Reserve(new[] { cost }); cost.SetConsumeVal(500);
            var request = _resources.BeginRequest(); var response = Data(900); var before = response.DeepClone();
            _resources.ApplyServerResponse(request, response, false, "wealthInfos");
            Assert.That(JToken.DeepEquals(response, before), Is.True);
            response["wealthInfos"][0]["quantity"] = 0;
            Assert.That(_resources.GetRaw(11), Is.EqualTo(900)); Assert.That(cost.Quantity, Is.EqualTo(500));
        }
        [Test]
        public void CostEnumerationCannotMutateTheRepositoryOrReserveRecursively()
        {
            _resources.Reserve(Enumerate()); Assert.That(_resources.Get(11), Is.EqualTo(990));
            IEnumerable<ConsumeData> Enumerate()
            {
                Assert.Throws<InvalidOperationException>(() => _repository.UpdateJson(Data(10), "wealthInfos"));
                Assert.Throws<InvalidOperationException>(() => Reserve(1));
                Assert.That(_resources.CheckSpend(Cost(10)), Is.True);
                yield return Cost(10);
            }
        }
        [Test]
        public void NestedCostReadDoesNotReleaseTheOuterPublicationGate()
        {
            _resources.Changed += _ =>
            {
                Assert.Throws<NotSupportedException>(() => _resources.CheckSpend(new ConsumeData(new ConsumeTypeId(9001), 1, 1)));
                Assert.Throws<InvalidOperationException>(() => _wealth.UpdateJson(Data(1)));
            };
            Reserve(1); Assert.That(_resources.Get(11), Is.EqualTo(999));
        }
        [Test]
        public void APartialResponseMustCoverEveryHeldItem()
        {
            JObject initial = Data(1000); ((JArray)initial["wealthInfos"]).Add(new JObject { ["wealthType"] = "beta", ["quantity"] = 500 }); _wealth.UpdateJson(initial);
            _resources.Reserve(new[] { Cost(100), Cost(50, 22) }); var request = _resources.BeginRequest();
            Assert.Throws<InvalidDataException>(() => _resources.ApplyServerResponse(request, Data(900), false, "wealthInfos"));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_resources.Get(22), Is.EqualTo(450));
        }
        [Test]
        public void ResyncCallbacksObserveAllPreviewsClearedAndNoUncertainty()
        {
            var request = Send(); Reserve(50); _resources.FailRequest(request, ResourceRequestFailure.Uncertain);
            _wealth.Changed += _ => { Assert.That(_resources.RequiresResynchronization, Is.False); Assert.That(_resources.InFlightRequest, Is.Null); Assert.That(_resources.Get(11), Is.EqualTo(925)); };
            _resources.Resynchronize(Data(925), "wealthInfos");
        }
        private sealed class RowSource : ITableSource
        {
            public List<TSVRow> Rows;
            public bool RequiresRemoteUpdate => false;
            public bool HasTable(string name) => true;
            public List<TSVRow> Load(string name) => Rows;
            public Task<List<TSVRow>> LoadAsync(string name) => Task.FromResult(Rows);
        }
        private sealed class TestTable : WealthTable
        {
            public List<TSVRow> Rows = TSVRow.FromTsv("id\ttype\n11\talpha\n22\tbeta");
            public override void LoadDatas() { _DataClear(); InsertData(Rows); }
        }
        private sealed class OtherContainer : DataContainer
        {
            public OtherContainer() : base("other", 0L) { }
            public long Amount => (long)State;
            protected override StateChange ParseState(JObject data, bool replace)
            {
                var rows = ContainerJson.RequireArray(data, DataKey);
                long value = rows.Count == 1 && rows[0].Type == JTokenType.Integer ? (long)rows[0] : throw new InvalidDataException("Invalid other model.");
                return new StateChange(value, Amount == value ? Array.Empty<string>() : new[] { "one" });
            }
            protected override JObject WriteState(object state) => new JObject { [DataKey] = new JArray((long)state) };
        }
    }
}
