using System;
using NUnit.Framework;

namespace jjevol.Tests
{
    public sealed class ConsumePresentationTests
    {
        private sealed class Provider : IConsumePresentationProvider
        {
            public int IdCalls, DataCalls;
            public ConsumeData Seen;
            public bool TryResolve(ConsumeTypeId type, int itemId, out ConsumePresentation presentation)
            {
                IdCalls++;
                bool found = (type.Value == -18 || type.Value == 812) && itemId == 41;
                presentation = found ? new ConsumePresentation(name: type.Value == 812 ? "Wealth" : "Item", description: "description", icon: "icon", atlas: "atlas", grade: 4) : default;
                return found;
            }
            public ConsumePresentation Resolve(ConsumeData data)
            {
                DataCalls++; Seen = data;
                TryResolve(data.TypeId, data.ItemId, out var common);
                var result = new ConsumePresentation(icon: common.Icon, atlas: common.Atlas, grade: common.Grade,
                    name: common.Name, description: data.Quantity + ":" + data.sourceData?.ItemId);
                data.SetConsumeVal(99); data.consumeId = 99; data.sourceData?.SetConsumeVal(99);
                return result;
            }
        }
        [Test] public void SameItemIdKeepsBothTypeIdsAndMetadataDistinct()
        {
            IConsumePresentationProvider provider = new Provider();
            Assert.That(provider.TryResolve(new(812), 41, out var wealth), Is.True);
            Assert.That(provider.TryResolve(new(-18), 41, out var item), Is.True);
            Assert.That(wealth.Name, Is.EqualTo("Wealth")); Assert.That(item.Name, Is.EqualTo("Item"));
            Assert.That(item.Description, Is.EqualTo("description")); Assert.That(item.Icon, Is.EqualTo("icon"));
            Assert.That(item.Atlas, Is.EqualTo("atlas")); Assert.That(item.Grade, Is.EqualTo(4));
        }
        [TestCase(int.MinValue, 41)][TestCase(int.MaxValue, 41)][TestCase(812, 42)][TestCase(-18, 0)]
        public void UnresolvedIdsDoNotUseAnotherTypeOrItem(int type, int id)
        { Assert.That(new Provider().TryResolve(new(type), id, out var result), Is.False); Assert.That(result.Table, Is.Null); Assert.That(result.Icon, Is.Null); }
        [Test] public void PresentPreservesQuantitySourcePolicyAndCloneIsolation()
        {
            var source = new ConsumeData(new(-18), 17, 8);
            var data = new ConsumeData(new(812), 41, 5); data.SetRewardResult(source);
            var provider = new Provider(); var result = data.Present(provider);
            Assert.That(provider.Seen, Is.Not.SameAs(data)); Assert.That(provider.DataCalls, Is.EqualTo(1));
            Assert.That(result.Description, Is.EqualTo("5:17")); Assert.That(data.Quantity, Is.EqualTo(5));
            Assert.That(data.ItemId, Is.EqualTo(41)); Assert.That(data.sourceData.Quantity, Is.EqualTo(8));
            Assert.That(provider.TryResolve(data.TypeId, data.ItemId, out var common), Is.True);
            Assert.That(result.Name, Is.EqualTo(common.Name)); Assert.That(result.Icon, Is.EqualTo(common.Icon));
            Assert.That(result.Atlas, Is.EqualTo(common.Atlas)); Assert.That(result.Grade, Is.EqualTo(common.Grade));
        }
        [Test] public void IdLookupDoesNotDispatchResolveOrAllocateConsumeWrappers()
        {
            IConsumePresentationProvider provider = new Provider(); var kind = new ConsumeTypeId(812);
            for (int i = 0; i < 256; i++) provider.TryResolve(kind, 41, out _);
            long before = GC.GetAllocatedBytesForCurrentThread();
            for (int i = 0; i < 4096; i++) provider.TryResolve(kind, 41, out _);
            long allocated = GC.GetAllocatedBytesForCurrentThread() - before;
            Assert.That(allocated, Is.Zero); Assert.That(((Provider)provider).DataCalls, Is.Zero);
        }
    }
}
