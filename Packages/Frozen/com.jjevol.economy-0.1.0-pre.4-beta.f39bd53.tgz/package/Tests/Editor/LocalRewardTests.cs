using JJEvol.Save.Testing;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tests
{
    public sealed class LocalRewardTests
    {
        private const string Profile = "device:resource-tests";
        private const string Schema = "fixture:resource-tests:v1";
        private const int Alpha = 11, Beta = 22;
        private static readonly ConsumeTypeId Kind = new(812);
        private string _root;
        private LocalSaveRepository _repository;
        private readonly LocalSaveCodec _codec = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("test-v1", System.Text.Encoding.ASCII.GetBytes("0123456789abcdef0123456789abcdef")));
        private TestWealthTable _table;
        private ResourceService _resources;
        private RepositoryStorageAdapter _storage => _resources.Repository.Storage;
        private readonly List<DataRepository> _owners = new();
        private readonly List<Listener> _listeners = new();

        [SetUp]
        public void SetUp()
        {
            _root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolEconomyTests", Guid.NewGuid().ToString("N")));
            _repository = PrefsFixture.Create(Profile, _root, _codec); _table = new TestWealthTable(); _table.LoadDatas();
            _resources = OpenProfile(Profile, Initial(100, 20), _repository);
        }

        [TearDown]
        public void TearDown()
        { PrefsFixture.Cleanup();
            foreach (Listener listener in _listeners) listener.Resources.Changed -= listener.Observe; _listeners.Clear();
            foreach (DataRepository owner in _owners) owner.Dispose(); _owners.Clear();
            string parent = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolEconomyTests")) + Path.DirectorySeparatorChar;
            if (!Path.GetFullPath(_root).StartsWith(parent, StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Unexpected economy test directory.");
            if (Directory.Exists(_root)) Directory.Delete(_root, true);
        }

        [Test]
        public void WealthDefinitionsUseExistingTsvMetadataAndClearTypeAliasesOnReload()
        {
            Assert.That(_table.TableName, Is.EqualTo("01_wealth"));
            Assert.That(_table.RowType, Is.EqualTo(typeof(WealthData)));
            WealthData alpha = _table.Get(Alpha);
            Assert.That(alpha.type, Is.EqualTo("alpha"));
            Assert.That(alpha.active, Is.True);
            Assert.That(alpha.icon, Is.EqualTo("test_icon"));
            Assert.That(alpha.sort, Is.EqualTo(3));
            Assert.That(alpha.name, Is.EqualTo("test_name"));
            Assert.That(_table.Get("alpha"), Is.SameAs(alpha));
            _table.Rows = Rows("id\ttype\tactive\n33\tgamma\t0");
            _table.LoadDatas();
            Assert.That(_table.Get("alpha"), Is.Null);
            Assert.That(_table.GetId("alpha"), Is.Zero);
            Assert.That(_table.Get(Alpha), Is.Null);
            Assert.That(_table.Get("gamma").active, Is.False);
        }

        [TestCase("id\ttype\n1\ta\n1\tb")]
        [TestCase("id\ttype\n1\ta\n2\ta")]
        [TestCase("id\ttype\n0\ta")]
        [TestCase("id\ttype\n1\t ")]
        [TestCase("id\ttype\n1\t a")]
        public void InvalidOrAmbiguousWealthDefinitionsFail(string tsv)
        {
            _table.Rows = Rows(tsv);
            Assert.Throws<InvalidDataException>(() => _table.LoadDatas());
        }

        [Test]
        public async Task WealthTableCanUseExistingTableRepositoryWithoutNewRegistrationContracts()
        {
            var field = typeof(jjevol.Data.TableRepository).GetField("_allTables", BindingFlags.Static | BindingFlags.NonPublic);
            var registered = (List<TableBase>)field.GetValue(null);
            TableBase[] previous = registered.ToArray();
            bool loaded = jjevol.Data.TableRepository.loaded;
            try
            {
                jjevol.Data.TableRepository.Clear();
                jjevol.Data.TableRepository.Register(_table);
                await jjevol.Data.TableRepository.LoadAllAsync();
                Assert.That(jjevol.Data.TableRepository.loaded, Is.True);
                Assert.That(_table.Get(Alpha).type, Is.EqualTo("alpha"));
                int loads = _table.Loads;
                jjevol.Data.TableRepository.LoadAll();
                Assert.That(_table.Loads, Is.EqualTo(loads));
            }
            finally
            {
                registered.Clear();
                registered.AddRange(previous);
                typeof(jjevol.Data.TableRepository).GetField("<loaded>k__BackingField", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, loaded);
            }
        }

        [Test]
        public void TwoCurrenciesUseLongBalancesAndDoNotNeedAGameProvider()
        {
            Assert.That(_resources.Get(Alpha), Is.EqualTo(100));
            Assert.That(_resources.Get(Kind, Beta), Is.EqualTo(20));
            Assert.That(_resources.Get(Value(Alpha, 1)), Is.EqualTo(100));
            var preparation = PrepareRewards(_resources, new[] { Value(Alpha, (long)int.MaxValue + 1), Value(Beta, 3) });
            Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Commit(_resources, preparation);
            Assert.That(_resources.Get(Alpha), Is.EqualTo((long)int.MaxValue + 101)); Assert.That(_resources.Get(Beta), Is.EqualTo(23));
            Commit(_resources, PrepareCosts(_resources, new[] { Value(Alpha, 7), Value(Beta, 2) }));
            Assert.That(_resources.Get(Alpha), Is.EqualTo((long)int.MaxValue + 94)); Assert.That(_resources.Get(Beta), Is.EqualTo(21));
        }

        [Test]
        public void CostsAndRewardsForBothCurrenciesCommitOnceAndPublishTheWholeCommittedState()
        {
            Listener listener = Listen(change =>
            {
                Assert.That(change.Service, Is.SameAs(_resources)); Assert.That(change.ProfileId, Is.EqualTo(Profile));
                Assert.That(change.TypeId, Is.EqualTo(Kind)); Assert.That(change.RepositoryRevision, Is.EqualTo(_resources.Repository.Revision));
                Assert.That(_resources.Get(Alpha), Is.EqualTo(80)); Assert.That(_resources.Get(Beta), Is.EqualTo(24));
                Assert.That(_storage.SavedRevision, Is.EqualTo(1)); Assert.That(_repository.Load().Document.StateRevision, Is.EqualTo(1));
            });
            var preparation = PrepareMutation(_resources, new[] { Value(Alpha, 10), Value(Alpha, 20), Value(Beta, 5) }, new[] { Value(Alpha, 10), Value(Beta, 2), Value(Beta, 7) });
            Assert.That(listener.Events, Is.Empty); Assert.That(_storage.SavedRevision, Is.Zero);
            Commit(_resources, preparation);
            Assert.That(listener.Events.Count, Is.EqualTo(1)); Assert.That(listener.Events[0].ItemIds, Is.EqualTo(new[] { Alpha, Beta }));
            var saved = (JArray)_repository.Load().Document.Snapshot.Payload[WealthContainer.PayloadKey];
            Assert.That(saved.Select(row => row.Value<long>(WealthContainer.QuantityKey)), Is.EqualTo(new long[] { 80, 24 }));
        }

        [Test]
        public void InsufficientCombinedCostRejectsAllChangesAndCannotBeFundedBySameTransactionRewards()
        {
            Listener listener = Listen();
            Assert.That(_resources.CheckSpend(new[] { Value(Alpha, 60), Value(Alpha, 50) }), Is.False);
            Assert.Throws<InsufficientResourceException>(() => PrepareMutation(_resources, new[] { Value(Alpha, 101), Value(Beta, 1) }, new[] { Value(Alpha, 500), Value(Beta, 3) }));
            Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Assert.That(_resources.Get(Beta), Is.EqualTo(20));
            Assert.That(_storage.SavedRevision, Is.Zero); Assert.That(listener.Events, Is.Empty);
            Assert.That(_resources.CheckSpend(Value(Alpha, 100)), Is.True);
            Commit(_resources, PrepareCosts(_resources, new[] { Value(Alpha, 100) })); Assert.That(_resources.Get(Alpha), Is.Zero);
        }

        [TestCase(true)] [TestCase(false)]
        public void DuplicateQuantityOverflowIsRejectedBeforeAnyMutation(bool rewards)
        {
            Listener listener = Listen(); var values = new[] { Value(Alpha, long.MaxValue), Value(Alpha, 1) };
            Assert.Throws<OverflowException>(() => { if (rewards) PrepareRewards(_resources, values); else PrepareCosts(_resources, values); });
            Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Assert.That(_storage.SavedRevision, Is.Zero); Assert.That(listener.Events, Is.Empty);
        }

        [Test]
        public void BalanceOverflowIsRejectedButCostThenRewardCanSafelyReachLongMaxValue()
        {
            var resources = OpenProfile("device:large", Initial(long.MaxValue, 0));
            Assert.Throws<OverflowException>(() => PrepareRewards(resources, new[] { Value(Alpha, 1) }));
            Commit(resources, PrepareMutation(resources, new[] { Value(Alpha, 10) }, new[] { Value(Alpha, 10), Value(Beta, long.MaxValue) }));
            Assert.That(resources.Get(Alpha), Is.EqualTo(long.MaxValue)); Assert.That(resources.Get(Beta), Is.EqualTo(long.MaxValue));
        }

        [TestCase(-1L)] [TestCase(long.MinValue)]
        public void NegativeCostsAndRewardsAreRejected(long quantity)
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => PrepareRewards(_resources, new[] { Value(Alpha, quantity) }));
            Assert.Throws<ArgumentOutOfRangeException>(() => PrepareCosts(_resources, new[] { Value(Alpha, quantity) }));
            Assert.Throws<ArgumentOutOfRangeException>(() => _resources.CheckSpend(Value(Alpha, quantity))); Assert.That(_storage.SavedRevision, Is.Zero);
        }

        [TestCase(0)] [TestCase(5)] [TestCase(-1)] [TestCase(3)] [TestCase(50)] [TestCase(8)] [TestCase(101)] [TestCase(100)] [TestCase(9999)]
        public void UnsupportedTypesFailExplicitlyEvenWithZeroQuantity(int type)
        {
            var value = new ConsumeData(new ConsumeTypeId(type), Alpha, 0);
            Assert.Throws<NotSupportedException>(() => _resources.Get(value)); Assert.Throws<NotSupportedException>(() => _resources.CheckSpend(value));
            Assert.Throws<NotSupportedException>(() => PrepareRewards(_resources, new[] { value }));
        }

        [Test]
        public void UnknownIdsRandomQuantitiesAndNullEntriesAreNotSilentlyIgnored()
        {
            Assert.Throws<ArgumentException>(() => _resources.Get(9999)); Assert.Throws<ArgumentException>(() => _resources.CheckSpend(Value(9999, 0)));
            Assert.Throws<ArgumentException>(() => PrepareRewards(_resources, new[] { Value(9999, 1) }));
            Assert.Throws<NotSupportedException>(() => PrepareRewards(_resources, new[] { new ConsumeData(Kind, Alpha, 1, 3) }));
            Assert.Throws<ArgumentException>(() => PrepareCosts(_resources, new ConsumeData[] { null })); Assert.Throws<ArgumentNullException>(() => PrepareRewards(_resources, null));
        }

        [Test]
        public void ExplicitEmptyWealthAndAbsentDefinedRowsHaveZeroBalances()
        {
            var resources = OpenProfile("device:empty", new JObject { [WealthContainer.PayloadKey] = new JArray(), ["other"] = 42 });
            Assert.That(resources.Get(Alpha), Is.Zero); Assert.That(resources.Get(Beta), Is.Zero);
            Commit(resources, PrepareRewards(resources, new[] { Value(Beta, 2) }));
            Assert.That(resources.Get(Alpha), Is.Zero); Assert.That(resources.Get(Beta), Is.EqualTo(2));
            Assert.That((int)PrefsFixture.Create(resources.Repository.ProfileId, _root, _codec).Load().Document.Snapshot.Payload["other"], Is.EqualTo(42));
        }

        [TestCase("null")] [TestCase("{}")] [TestCase("[null]")]
        [TestCase("[{\"wealthType\":\"alpha\",\"quantity\":-1}]")]
        [TestCase("[{\"wealthType\":\"alpha\",\"quantity\":1.5}]")]
        [TestCase("[{\"wealthType\":\"alpha\",\"quantity\":\"2\"}]")]
        [TestCase("[{\"wealthType\":\"alpha\"}]")]
        [TestCase("[{\"wealthType\":\"alpha\",\"quantity\":1},{\"wealthType\":\"alpha\",\"quantity\":2}]")]
        [TestCase("[{\"wealthType\":\"alpha\",\"quantity\":9999999999999999999999999999}]")]
        public void InvalidStoredBalancesAreRejectedWithoutResettingOrSaving(string json)
        {
            JObject payload = _repository.Load().Document.Snapshot.Payload; payload[WealthContainer.PayloadKey] = JToken.Parse(json);
            PersistExternal(payload); byte[] bytes = PrefsFixture.Read(_repository); Listener listener = Listen();
            Assert.Throws<InvalidDataException>(() => _storage.Reload());
            Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.RecoveryRequired));
            Assert.Throws<RepositoryRecoveryRequiredException>(() => PrepareRewards(_resources, new[] { Value(Alpha, 1) }));
            Assert.That(listener.Events, Is.Empty); Assert.That(PrefsFixture.Read(_repository), Is.EqualTo(bytes));
        }

        [Test]
        public void PreparationInputsAndExportedValuesAreDetachedAndOtherPayloadDataIsPreserved()
        {
            JObject payload = _repository.Load().Document.Snapshot.Payload; payload["unrelated"] = new JObject { ["nested"] = new JArray(1, 2), ["revision"] = 77 };
            var rows = (JArray)payload[WealthContainer.PayloadKey]; rows[0]["futureField"] = new JObject { ["value"] = true };
            rows.Add(new JObject { [WealthContainer.TypeKey] = "unregistered", [WealthContainer.QuantityKey] = long.MaxValue, ["opaque"] = 9 });
            PersistExternal(payload); _storage.Reload();
            var reward = Value(Alpha, 5); var list = new List<ConsumeData> { reward }; var preparation = PrepareRewards(_resources, list);
            reward.SetConsumeVal(500); list.Clear(); _resources.Repository.ExportJson()["unrelated"] = null;
            Commit(_resources, preparation); JObject saved = _repository.Load().Document.Snapshot.Payload;
            Assert.That(_resources.Get(Alpha), Is.EqualTo(105)); Assert.That(JToken.DeepEquals(saved["unrelated"], payload["unrelated"]), Is.True);
            Assert.That(JToken.DeepEquals(saved[WealthContainer.PayloadKey][0]["futureField"], rows[0]["futureField"]), Is.True);
            Assert.That(JToken.DeepEquals(saved[WealthContainer.PayloadKey][2], rows[2]), Is.True);
            Assert.Throws<NotSupportedException>(() => ((IDictionary<string, long>)_resources.Container.Balances)["alpha"] = 0);
        }

        [Test]
        public void PlayerPrefsFailureLeavesBalancesUnchangedAndRequiresReopenBeforeNewPreparation()
        {
            bool fail = true; var repository = Inject((key, bytes) => { if (fail) throw new IOException("synthetic PlayerPrefs failure"); Write(key, bytes); });
            _resources = Reopen(_resources, repository); var preparation = PrepareMutation(_resources, new[] { Value(Alpha, 10) }, new[] { Value(Beta, 2) });
            Listener listener = Listen(); byte[] original = PrefsFixture.Read(repository);
            Assert.Throws<LocalSaveWriteException>(() => Commit(_resources, preparation)); Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Assert.That(_resources.Get(Beta), Is.EqualTo(20));
            Assert.That(_storage.SavedRevision, Is.Zero); Assert.That(listener.Events, Is.Empty); Assert.That(PrefsFixture.Read(repository), Is.EqualTo(original));
            Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.RecoveryRequired)); Assert.Throws<RepositoryRecoveryRequiredException>(() => Commit(_resources, preparation));
            fail = false; _resources = Reopen(_resources); Assert.Throws<LocalSaveConflictException>(() => Commit(_resources, preparation));
            Commit(_resources, PrepareMutation(_resources, new[] { Value(Alpha, 10) }, new[] { Value(Beta, 2) }));
            Assert.That(_resources.Get(Alpha), Is.EqualTo(90)); Assert.That(_resources.Get(Beta), Is.EqualTo(22));
        }

        [Test]
        public void SamePreparedRequestCannotBeAppliedTwiceOrToAnotherRepository()
        {
            var preparation = PrepareRewards(_resources, new[] { Value(Alpha, 7) }); var other = OpenProfile("device:other", Initial(100, 20));
            Assert.Throws<LocalSaveConflictException>(() => Commit(other, preparation)); Listener listener = Listen(); Commit(_resources, preparation);
            Assert.Throws<LocalSaveConflictException>(() => Commit(_resources, preparation)); Assert.That(_resources.Get(Alpha), Is.EqualTo(107)); Assert.That(listener.Events.Count, Is.EqualTo(1));
        }

        [Test]
        public void ExternalRevisionConflictRequiresReloadAndRecalculatedCosts()
        {
            var previous = PrepareCosts(_resources, new[] { Value(Alpha, 50) }); JObject changed = _repository.Load().Document.Snapshot.Payload;
            changed[WealthContainer.PayloadKey][0][WealthContainer.QuantityKey] = 20; PersistExternal(changed); Listener listener = Listen();
            Assert.Throws<LocalSaveConflictException>(() => Commit(_resources, previous)); Assert.That(_resources.Get(Alpha), Is.EqualTo(100));
            Assert.That(_storage.SavedRevision, Is.Zero); Assert.That(listener.Events, Is.Empty); _storage.Reload();
            Assert.That(_resources.Get(Alpha), Is.EqualTo(20)); Assert.Throws<LocalSaveConflictException>(() => Commit(_resources, previous));
            Assert.That(_resources.CheckSpend(Value(Alpha, 50)), Is.False); Assert.Throws<InsufficientResourceException>(() => PrepareCosts(_resources, new[] { Value(Alpha, 50) }));
            Commit(_resources, PrepareCosts(_resources, new[] { Value(Alpha, 10) })); Assert.That(_resources.Get(Alpha), Is.EqualTo(10));
        }

        [Test]
        public void UnrelatedDocumentMutationInvalidatesAnOldPreparationWithoutDroppingThatData()
        {
            var preparation = PrepareRewards(_resources, new[] { Value(Alpha, 7) }); JObject payload = _repository.Load().Document.Snapshot.Payload;
            payload["otherState"] = 5; PersistExternal(payload); _storage.Reload();
            Assert.Throws<LocalSaveConflictException>(() => Commit(_resources, preparation));
            Assert.That((int)_repository.Load().Document.Snapshot.Payload["otherState"], Is.EqualTo(5)); Assert.That(_resources.Get(Alpha), Is.EqualTo(100));
        }

        [Test]
        public void DefinitionsRemainCapturedUntilTheGameExplicitlyRebindsTheService()
        {
            var preparation = PrepareRewards(_resources, new[] { Value(Alpha, 7) });
            _table.Get(Alpha).Init(new TSVRow(new Dictionary<string, string> { ["id"] = Alpha.ToString(), ["type"] = "changed" }));
            Commit(_resources, preparation); Assert.That(_resources.Get(Alpha), Is.EqualTo(107));
            var repository = _resources.Repository; _resources.Dispose(); _resources = new ResourceService(repository, _table, Kind);
            Assert.That(_resources.Get(Alpha), Is.Zero); Assert.That(repository.Get<WealthContainer>(WealthContainer.PayloadKey).Get("alpha"), Is.EqualTo(107));
        }

        [Test]
        public void ReentryIsBlockedDuringPersistenceAndPublication()
        {
            LocalResourcePreparation preparation = null;
            var repository = Inject((path, bytes) =>
            {
                Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Assert.That(_resources.Get(Beta), Is.EqualTo(20)); Assert.That(_storage.SavedRevision, Is.Zero);
                Assert.Throws<InvalidOperationException>(() => Commit(_resources, preparation)); Write(path, bytes);
            });
            _resources = Reopen(_resources, repository); preparation = PrepareMutation(_resources, new[] { Value(Alpha, 10) }, new[] { Value(Beta, 2) });
            Listener listener = Listen(change =>
            {
                Assert.That(_resources.Get(Alpha), Is.EqualTo(90)); Assert.That(_resources.Get(Beta), Is.EqualTo(22));
                Assert.Throws<InvalidOperationException>(() => Commit(_resources, preparation));
                Assert.Throws<InvalidOperationException>(() => PrepareRewards(_resources, new[] { Value(Alpha, 999) }));
            });
            Commit(_resources, preparation); Assert.That(listener.Events.Count, Is.EqualTo(1)); Assert.That(_storage.SavedRevision, Is.EqualTo(1));
        }

        [Test]
        public void LocalPublicationKeeps101AndItsRevisionWhenObserversAttempt777()
        {
            var repository = _resources.Repository;
            long expectedRevision = checked(repository.Revision + 1), expectedSavedRevision = checked(_storage.SavedRevision + 1);
            int observations = 0;
            void Observe(long revision)
            {
                observations++;
                Assert.That(revision, Is.EqualTo(expectedRevision)); Assert.That(repository.Revision, Is.EqualTo(expectedRevision));
                Assert.That(_resources.GetRaw(Alpha), Is.EqualTo(101)); Assert.That(_resources.Get(Alpha), Is.EqualTo(101));
                Assert.That(_storage.SavedRevision, Is.EqualTo(expectedSavedRevision));
                Assert.Throws<InvalidOperationException>(() => _resources.Container.UpdateJson(Initial(777, 20)));
                Assert.Throws<InvalidOperationException>(() => _storage.ApplyAndSave(Initial(777, 20), true, WealthContainer.PayloadKey));
                Assert.Throws<InvalidOperationException>(() => PrepareRewards(_resources, new[] { Value(Alpha, 676) }));
                var saved = _repository.Load().Document;
                Assert.That(saved.StateRevision, Is.EqualTo(expectedSavedRevision));
                var alpha = ((JArray)saved.Snapshot.Payload[WealthContainer.PayloadKey]).OfType<JObject>().Single(row => row.Value<string>(WealthContainer.TypeKey) == "alpha");
                Assert.That(alpha.Value<long>(WealthContainer.QuantityKey), Is.EqualTo(101));
            }
            Action<RepositoryChange> repositoryObserver = change => Observe(change.Revision);
            repository.Changed += repositoryObserver;
            try
            {
                Listen(change => Observe(change.RepositoryRevision));
                Commit(_resources, PrepareRewards(_resources, new[] { Value(Alpha, 1) }));
                Assert.That(observations, Is.EqualTo(2));
                Assert.That(repository.Revision, Is.EqualTo(expectedRevision)); Assert.That(_resources.GetRaw(Alpha), Is.EqualTo(101));
                _resources = Reopen(_resources); Assert.That(_resources.GetRaw(Alpha), Is.EqualTo(101));
                Assert.That(_storage.SavedRevision, Is.EqualTo(expectedSavedRevision));
            }
            finally { repository.Changed -= repositoryObserver; }
        }

        [Test]
        public void NotificationFailureCannotReportAnAlreadyCommittedMutationAsASaveFailure()
        {
            Listen(change => { throw new InvalidOperationException("test notification failure"); }); Listener healthy = Listen();
            LogAssert.Expect(LogType.Exception, new Regex("InvalidOperationException: test notification failure"));
            var preparation = PrepareRewards(_resources, new[] { Value(Alpha, 1), Value(Beta, 1) }); Assert.DoesNotThrow(() => Commit(_resources, preparation));
            Assert.That(_resources.Get(Alpha), Is.EqualTo(101)); Assert.That(_resources.Get(Beta), Is.EqualTo(21)); Assert.That(_storage.SavedRevision, Is.EqualTo(1));
            Assert.That(healthy.Events.Single().ItemIds, Is.EqualTo(new[] { Alpha, Beta })); Assert.Throws<LocalSaveConflictException>(() => Commit(_resources, preparation));
        }

        [Test]
        public void RepeatedBalanceReadsDoNotAllocateAndRefreshAfterContainerChanges()
        {
            for (int i = 0; i < 32; i++) _resources.Get(Alpha); long before = GC.GetAllocatedBytesForCurrentThread(); long total = 0;
            for (int i = 0; i < 1000; i++) total += _resources.Get(Alpha);
            long allocated = GC.GetAllocatedBytesForCurrentThread() - before;
            Assert.That(total, Is.EqualTo(100000)); Assert.That(allocated, Is.Zero, "Reads query the existing Container without building Snapshot projections.");
            Commit(_resources, PrepareCosts(_resources, new[] { Value(Alpha, 7) })); Assert.That(_resources.Get(Alpha), Is.EqualTo(93));
            _resources.Container.UpdateJson(new JObject { [WealthContainer.PayloadKey] = new JArray(new JObject { [WealthContainer.TypeKey] = "alpha", [WealthContainer.QuantityKey] = 41 }) });
            Assert.That(_resources.Get(Alpha), Is.EqualTo(41)); _storage.Save();
            _resources = Reopen(_resources); Assert.That(_resources.Get(Alpha), Is.EqualTo(41));
        }

        [Test]
        public void EmptyAndNetZeroMutationsDoNotWriteAdvanceRevisionOrEmitBalanceEvents()
        {
            Listener listener = Listen(); byte[] before = PrefsFixture.Read(_repository);
            Commit(_resources, PrepareMutation(_resources, Array.Empty<ConsumeData>(), Array.Empty<ConsumeData>()));
            Commit(_resources, PrepareMutation(_resources, new[] { Value(Alpha, 1) }, new[] { Value(Alpha, 1), Value(Beta, 0) }));
            Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Assert.That(_resources.Get(Beta), Is.EqualTo(20));
            Assert.That(_storage.SavedRevision, Is.Zero); Assert.That(listener.Events, Is.Empty); Assert.That(PrefsFixture.Read(_repository), Is.EqualTo(before));
        }

        [Test]
        public void RestartRestoresBothCurrenciesAndProfilesRemainSeparated()
        {
            Commit(_resources, PrepareMutation(_resources, new[] { Value(Alpha, 30) }, new[] { Value(Beta, 7) })); _resources = Reopen(_resources);
            Assert.That(_resources.Get(Alpha), Is.EqualTo(70)); Assert.That(_resources.Get(Beta), Is.EqualTo(27));
            var other = OpenProfile("device:other", Initial(2, 3)); Assert.That(other.Get(Alpha), Is.EqualTo(2)); Assert.That(other.Get(Beta), Is.EqualTo(3));
            Assert.That(_resources.Get(Alpha), Is.EqualTo(70));
        }

        [Test]
        public void FreshRequestsRepeatRewardsAndDoNotClaimBusinessIdempotency()
        {
            Listener listener = Listen();
            for (int i = 0; i < 20; i++)
            {
                var preparation = PrepareMutation(_resources, new[] { Value(Alpha, 2) }, new[] { Value(Alpha, 3), Value(Beta, 1) }); Commit(_resources, preparation);
                Assert.Throws<LocalSaveConflictException>(() => Commit(_resources, preparation));
            }
            Assert.That(_resources.Get(Alpha), Is.EqualTo(120)); Assert.That(_resources.Get(Beta), Is.EqualTo(40)); Assert.That(_storage.SavedRevision, Is.EqualTo(20));
            Assert.That(listener.Events.Count, Is.EqualTo(20)); Assert.That(listener.Events.All(e => e.ItemIds.SequenceEqual(new[] { Alpha, Beta })), Is.True);
            _resources = Reopen(_resources); Assert.That(_resources.Get(Alpha), Is.EqualTo(120));
        }

        [Test]
        public void ThrowingRequestEnumerationCannotPartiallySpendOrGrant()
        {
            Listener listener = Listen(); byte[] original = PrefsFixture.Read(_repository);
            Assert.Throws<InvalidOperationException>(() => PrepareMutation(_resources, new[] { Value(Alpha, 10) }, FailingRewards()));
            Assert.That(_resources.Get(Alpha), Is.EqualTo(100)); Assert.That(_resources.Get(Beta), Is.EqualTo(20)); Assert.That(_storage.SavedRevision, Is.Zero);
            Assert.That(listener.Events, Is.Empty); Assert.That(PrefsFixture.Read(_repository), Is.EqualTo(original));
        }

        [Test]
        public void DamagedPlayerPrefsBlocksNormalReopenAndOnlyAllowsExplicitReadOnlySalvage()
        {
            Commit(_resources, PrepareRewards(_resources, new[] { Value(Alpha, 10) })); Commit(_resources, PrepareRewards(_resources, new[] { Value(Alpha, 20) }));
            PlayerPrefs.SetString(_repository.Slot0Key, "damaged-synthetic-slot");
            Assert.That(_repository.Load().Status, Is.EqualTo(LocalSaveLoadStatus.Corrupt));
            var recovery = _repository.LoadRecovery(); Assert.That(recovery.Status, Is.EqualTo(LocalSaveLoadStatus.RecoveredBackup)); Assert.That(recovery.Document.StateRevision, Is.EqualTo(1));
            Assert.Throws<InvalidDataException>(() => _storage.Reload()); Assert.That(_resources.Get(Alpha), Is.EqualTo(130));
            Assert.Throws<RepositoryRecoveryRequiredException>(() => PrepareCosts(_resources, new[] { Value(Alpha, 5) })); Assert.That(PlayerPrefs.GetString(_repository.Slot0Key), Is.EqualTo("damaged-synthetic-slot"));
        }


        private static IEnumerable<ConsumeData> FailingRewards()
        { yield return Value(Beta, 7); throw new InvalidOperationException("fixture request enumeration failure"); }
        private static LocalResourcePreparation PrepareMutation(ResourceService resources, IEnumerable<ConsumeData> costs, IEnumerable<ConsumeData> rewards)
            => LocalRewardService.PrepareMutation(resources.Repository.Storage, resources, costs, rewards);
        private static LocalResourcePreparation PrepareCosts(ResourceService resources, IEnumerable<ConsumeData> costs)
            => PrepareMutation(resources, costs, Array.Empty<ConsumeData>());
        private static LocalResourcePreparation PrepareRewards(ResourceService resources, IEnumerable<ConsumeData> rewards)
            => PrepareMutation(resources, Array.Empty<ConsumeData>(), rewards);
        private static void Commit(ResourceService resources, LocalResourcePreparation preparation)
            => LocalRewardService.Commit(resources.Repository.Storage, resources, preparation);
        private void PersistExternal(JObject payload) => _repository.Save(new LocalSaveSnapshot(payload), _repository.Load().Document);
        private ResourceService OpenProfile(string profile, JObject initial = null, LocalSaveRepository files = null)
        {
            var owner = new DataRepository(profile); _owners.Add(owner); owner.Register(new WealthContainer());
            RepositoryStorageAdapter.Open(owner, files ?? PrefsFixture.Create(profile, _root, _codec), Schema, RepositoryStorageMode.LocalAuthority, initial == null ? null : () => initial);
            return new ResourceService(owner, _table, Kind);
        }
        private ResourceService Reopen(ResourceService previous, LocalSaveRepository files = null)
        { string profile = previous.Repository.ProfileId; previous.Repository.Dispose(); return OpenProfile(profile, files: files); }
        private static ConsumeData Value(int id, long quantity) => new ConsumeData(Kind, id, quantity);
        private static List<TSVRow> Rows(string tsv) => TSVRow.FromTsv(tsv);
        private static JObject Initial(long alpha, long beta) => new JObject
        {
            [WealthContainer.PayloadKey] = new JArray(
                new JObject { [WealthContainer.TypeKey] = "alpha", [WealthContainer.QuantityKey] = alpha },
                new JObject { [WealthContainer.TypeKey] = "beta", [WealthContainer.QuantityKey] = beta })
        };
        private Listener Listen(Action<ResourceChange> callback = null)
        {
            var listener = new Listener(_resources, callback); _listeners.Add(listener); _resources.Changed += listener.Observe; return listener;
        }
        private LocalSaveRepository Inject(Action<string, byte[]> write)
            => PrefsFixture.Create(Profile, _root, _codec, (key, value) => write(key, Convert.FromBase64String(value)));
        private static void Write(string key, byte[] bytes) => PlayerPrefs.SetString(key, Convert.ToBase64String(bytes));
        private sealed class TestWealthTable : WealthTable
        {
            public List<TSVRow> Rows = LocalRewardTests.Rows("id\ttype\tactive\ticon\tsort\tnameKey\n11\talpha\t1\ttest_icon\t3\ttest_name\n22\tbeta\t1\ttest_icon\t4\ttest_other_name");
            public int Loads;
            public override void LoadDatas() { Loads++; _DataClear(); InsertData(Rows); }
            public override Task LoadDatasAsync() { LoadDatas(); return Task.CompletedTask; }
        }
        private sealed class Listener
        {
            public readonly ResourceService Resources;
            private readonly Action<ResourceChange> _callback;
            public readonly List<ResourceChange> Events = new();
            public Listener(ResourceService resources, Action<ResourceChange> callback) { Resources = resources; _callback = callback; }
            public void Observe(ResourceChange change) { Events.Add(change); _callback?.Invoke(change); }
        }
    }
}
