using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace jjevol.Tests
{
    public sealed class ConsumeParsingTests
    {
        private enum GameKind { None = 0, Junk = -1, Coins = 812, Materials = 9001 }
        private static ConsumeData Value(long amount = 5) => new ConsumeData(new ConsumeTypeId((int)GameKind.Coins), 41, amount);
        private static JObject Json(long amount = 5) => Value(amount).ExportJson();

        [TestCase(-1)]
        [TestCase(0)]
        [TestCase(812)]
        [TestCase(9001)]
        [TestCase(int.MaxValue)]
        [TestCase(int.MinValue)]
        public void GameAndUnknownNumericIdsRoundTripWithoutCoreRegistration(int type)
        {
            var id = new ConsumeTypeId(type);
            var data = new ConsumeData(id, 41, 2147483648L);
            var restored = JsonConvert.DeserializeObject<ConsumeData>(JsonConvert.SerializeObject(data));
            Assert.That(restored.TypeId, Is.EqualTo(id));
            Assert.That(restored.ItemId, Is.EqualTo(41));
            Assert.That(restored.Quantity, Is.EqualTo(2147483648L));
            Assert.That(restored.TypeId.Value, Is.EqualTo(type));
            Assert.That(JsonConvert.DeserializeObject<ConsumeTypeId>(JsonConvert.SerializeObject(id)), Is.EqualTo(id));
            Assert.That(JsonConvert.SerializeObject(id), Is.EqualTo(type.ToString(System.Globalization.CultureInfo.InvariantCulture)));
            Assert.That(new HashSet<ConsumeTypeId> { id, new ConsumeTypeId(type) }.Count, Is.EqualTo(1));
        }

        [TestCase("consumeType", "consumeId", "consumeVal")]
        [TestCase("consumeType", "consumeId", "consumeValue")]
        [TestCase("rewardType", "rewardId", "rewardValue")]
        [TestCase("priceType", "priceId", "priceValue")]
        [TestCase("sellType", "sellId", "sellValue")]
        public void AllScalarAliasesWorkForJsonAndRawTsv(string type, string id, string quantity)
        {
            var json = new JObject { [type] = -1, [id] = 41, [quantity] = long.MaxValue };
            Assert.That(new ConsumeData(json).Quantity, Is.EqualTo(long.MaxValue));
            var data = new ConsumeData();
            data.SetData(new TSVRow(new Dictionary<string, string> { [type] = "-1", [id] = "41", [quantity] = long.MaxValue.ToString() }));
            Assert.That(data.TypeId.Value, Is.EqualTo(-1));
            Assert.That(data.Quantity, Is.EqualTo(long.MaxValue));
        }

        [TestCase("consumeType", "consumeId", "consumeVal")]
        [TestCase("consumeType", "consumeId", "consumeValue")]
        [TestCase("rewardType", "rewardId", "rewardValue")]
        [TestCase("priceType", "priceId", "priceValue")]
        [TestCase("sellType", "sellId", "sellValue")]
        public void RangeAliasesAndTsvRoundTripWithoutLosingMaximum(string type, string id, string quantity)
        {
            var json = new JObject { [type] = 812, [id] = 1, [quantity + "_min"] = -7, [quantity + "_max"] = long.MaxValue };
            var data = new ConsumeData(json);
            var restored = new ConsumeData(data.ExportJson());
            Assert.That(restored.Min, Is.EqualTo(-7));
            Assert.That(restored.Max, Is.EqualTo(long.MaxValue));
            data.SetData(new TSVRow(new Dictionary<string, string> { [type] = "812", [id] = "1", [quantity + "_min"] = "-7", [quantity + "_max"] = long.MaxValue.ToString() }));
            Assert.That(data.Max, Is.EqualTo(long.MaxValue));
        }

        [TestCase("{}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41}")]
        [TestCase("{\"consumeType\":null,\"consumeId\":41,\"consumeVal\":5}")]
        [TestCase("{\"consumeType\":\"812\",\"consumeId\":41,\"consumeVal\":5}")]
        [TestCase("{\"consumeType\":2147483648,\"consumeId\":41,\"consumeVal\":5}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":2147483648,\"consumeVal\":5}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":1.5,\"consumeVal\":5}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":null}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":\"5\"}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":1.5}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":true}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":9223372036854775808}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":-9223372036854775809}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal_min\":5}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal_min\":7,\"consumeVal_max\":6}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":5,\"sourceData\":1}")]
        [TestCase("{\"consumeType\":812,\"consumeId\":41,\"consumeVal\":5,\"sourceData\":{}}")]
        [TestCase("{\"grantedData\":null}")]
        public void InvalidFullImportsPreserveEveryExistingValueAndInput(string text)
        {
            var data = Value(); data.SetRewardResult(new ConsumeData(new ConsumeTypeId((int)GameKind.Materials), 9, 2)); data.prefix_Progress = 17;
            JObject before = data.ExportJson(), input = JObject.Parse(text), copy = (JObject)input.DeepClone();
            Assert.Throws<InvalidDataException>(() => data.ImportJson(input));
            Assert.That(JToken.DeepEquals(data.ExportJson(), before), Is.True);
            Assert.That(data.prefix_Progress, Is.EqualTo(17));
            Assert.That(JToken.DeepEquals(input, copy), Is.True);
        }

        [TestCase("{\"consumeVal\":null}")]
        [TestCase("{\"consumeId\":null}")]
        [TestCase("{\"consumeVal\":\"1\"}")]
        [TestCase("{\"consumeVal\":1.5}")]
        [TestCase("{\"consumeVal\":9223372036854775808}")]
        [TestCase("{\"consumeType\":812,\"rewardType\":9001}")]
        [TestCase("{\"consumeId\":41,\"sellId\":42}")]
        [TestCase("{\"consumeVal\":5,\"consumeValue\":6}")]
        [TestCase("{\"consumeVal\":5,\"consumeVal_min\":4}")]
        [TestCase("{\"consumeVal_min\":6,\"consumeVal_max\":5}")]
        [TestCase("{\"grantedData\":false}")]
        public void InvalidPatchesAndAliasConflictsAreAtomic(string text)
        {
            var data = Value(); data.SetRewardResult(new ConsumeData(new ConsumeTypeId((int)GameKind.Materials), 2, 3));
            JObject before = data.ExportJson();
            Assert.Throws<InvalidDataException>(() => data.UpdateJson(JObject.Parse(text)));
            Assert.That(JToken.DeepEquals(before, data.ExportJson()), Is.True);
        }

        [Test]
        public void IdenticalAliasesAreAcceptedAndEnvelopeConflictsAreRejected()
        {
            JObject json = Json(); json["rewardType"] = 812; json["priceValue"] = 5; json["consumeVal_min"] = 5; json["consumeVal_max"] = 5;
            Assert.That(new ConsumeData(json).Quantity, Is.EqualTo(5));
            var envelope = new JObject { ["grantedData"] = Json(), ["consumeVal"] = 6 };
            Assert.Throws<InvalidDataException>(() => new ConsumeData(envelope));
        }

        [Test]
        public void ImportReplacesAndPatchPreservesMissingSourceAndRangeFields()
        {
            var data = new ConsumeData(new ConsumeTypeId(812), 41, 2, 8);
            data.SetRewardResult(new ConsumeData(new ConsumeTypeId((int)GameKind.Materials), 9, 3)); data.prefix_Progress = 7;
            data.UpdateJson(JObject.Parse("{\"consumeVal_max\":10}"));
            Assert.That(data.Min, Is.EqualTo(2)); Assert.That(data.Max, Is.EqualTo(10));
            Assert.That(data.sourceData.Quantity, Is.EqualTo(3)); Assert.That(data.prefix_Progress, Is.EqualTo(7));
            data.UpdateJson(JObject.Parse("{\"grantedData\":{\"consumeValue\":5}}"));
            Assert.That(data.Min, Is.EqualTo(5)); Assert.That(data.Max, Is.EqualTo(5));
            Assert.That(data.sourceData.Quantity, Is.EqualTo(3));
            data.UpdateJson(JObject.Parse("{\"sourceData\":{\"consumeVal\":9}}"));
            Assert.That(data.sourceData.ItemId, Is.EqualTo(9)); Assert.That(data.sourceData.Quantity, Is.EqualTo(9));
            data.UpdateJson(JObject.Parse("{\"sourceData\":null}")); Assert.That(data.sourceData, Is.Null);
            data.ImportJson(Json(12)); Assert.That(data.IsRewardResult, Is.False); Assert.That(data.sourceData, Is.Null); Assert.That(data.prefix_Progress, Is.Zero);
        }

        [TestCase("prevConsumeType", "prevConsumeId", "prevConsumeVal")]
        [TestCase("prevRewardType", "prevRewardId", "prevRewardValue")]
        public void PreviousRewardScalarAliasesPreserveIdsAndLongs(string type, string id, string quantity)
        {
            JObject json = Json(); json[type] = -1; json[id] = 9; json[quantity] = long.MaxValue;
            var data = new ConsumeData(json);
            var restored = new ConsumeData(data.ExportJson());
            Assert.That(restored.prevRewardData.TypeId.Value, Is.EqualTo(-1));
            Assert.That(restored.prevRewardData.Quantity, Is.EqualTo(long.MaxValue));
        }

        [Test]
        public void SourceAliasesNestedEnvelopesAndRangesRoundTripDetached()
        {
            var source = new ConsumeData(new ConsumeTypeId(-1), 3, 2, long.MaxValue);
            source.SetRewardResult(new ConsumeData(new ConsumeTypeId(9001), 4, 7));
            var data = Value(); data.SetRewardResult(source);
            var restored = JsonConvert.DeserializeObject<ConsumeData>(JsonConvert.SerializeObject(data));
            Assert.That(restored.sourceData.Max, Is.EqualTo(long.MaxValue));
            Assert.That(restored.sourceData.sourceData.TypeId.Value, Is.EqualTo(9001));
            restored.sourceData.SetConsumeVal(99); source.SetConsumeVal(77);
            Assert.That(restored.sourceData.Min, Is.EqualTo(2)); Assert.That(data.sourceData.Min, Is.EqualTo(2));
            JObject json = Json(); json["sourceData"] = source.ExportJson(); json["prevRewardData"] = source.ExportJson();
            Assert.DoesNotThrow(() => new ConsumeData(json));
            json["prevRewardData"] = new ConsumeData(new ConsumeTypeId((int)GameKind.Materials), 8, 1).ExportJson();
            Assert.Throws<InvalidDataException>(() => data.UpdateJson(json));
            data.SetRewardResult(); Assert.That(data.sourceData, Is.Null);
        }

        [TestCase(long.MinValue)]
        [TestCase(2147483648L)]
        [TestCase(9007199254740993L)]
        [TestCase(long.MaxValue)]
        public void SignedLongValuesRemainExactAndExecutionPolicyIsSeparate(long amount)
        {
            var data = new ConsumeData(Json(amount));
            Assert.That(new ConsumeData(data.ExportJson()).Quantity, Is.EqualTo(amount));
            Assert.That(data.Clone().Quantity, Is.EqualTo(amount));
        }

        [Test]
        public void CloneScalesRangesAndOverflowCannotMutateInputs()
        {
            var data = new ConsumeData(new ConsumeTypeId(812), 41, -3, 7);
            var negative = data.Clone(-2);
            Assert.That(negative.Min, Is.EqualTo(-14)); Assert.That(negative.Max, Is.EqualTo(6));
            Assert.That(data.Min, Is.EqualTo(-3)); Assert.That(data.Max, Is.EqualTo(7));
            Assert.Throws<OverflowException>(() => Value(long.MinValue).Clone(-1));
            Assert.Throws<OverflowException>(() => Value(long.MaxValue).Clone(2));
            var range = new ConsumeData(new ConsumeTypeId(812), 41, 0, long.MaxValue);
            Assert.Throws<OverflowException>(() => range.AddValue(Value(1)));
            Assert.That(range.Min, Is.Zero); Assert.That(range.Max, Is.EqualTo(long.MaxValue));
            Assert.Throws<ArgumentOutOfRangeException>(() => range.SetRange(9, 8));
            Assert.That(range.Min, Is.Zero);
        }

        [Test]
        public void MergeUsesValueKeysPreservesSourceEntriesAndNeverAliasesInputs()
        {
            var source = Value(); source.SetRewardResult(new ConsumeData(new ConsumeTypeId((int)GameKind.Materials), 1, 3));
            var list = new List<ConsumeData> { Value(2), Value(3), new ConsumeData(new ConsumeTypeId(0), 41, 4), new ConsumeData(new ConsumeTypeId(-1), 41, 5), source, source };
            List<ConsumeData> merged = ConsumeDataExt.MergeList(list);
            Assert.That(merged.Count, Is.EqualTo(5)); Assert.That(merged[0].Quantity, Is.EqualTo(5));
            Assert.That(merged[1].TypeId.Value, Is.Zero); Assert.That(merged[2].TypeId.Value, Is.EqualTo(-1));
            merged[3].SetConsumeVal(99); Assert.That(source.Quantity, Is.EqualTo(5));
            Assert.Throws<OverflowException>(() => ConsumeDataExt.MergeList(new List<ConsumeData> { Value(long.MaxValue), Value(1) }));
            Assert.That(list[0].Quantity, Is.EqualTo(2));
            Assert.Throws<ArgumentException>(() => list[0].AddValue(new ConsumeData(new ConsumeTypeId(1), 41, 2)));
        }

        [Test]
        public void CalcProgressReturnsDetachedRepeatableSuffixQuantities()
        {
            var input = new List<ConsumeData> { Value(2), new ConsumeData(new ConsumeTypeId(9), 41, 20), Value(3), Value(4) };
            var result = ConsumeDataExt.CalcProgress(input);
            Assert.That(result.Select(data => data.prefix_Progress), Is.EqualTo(new long[] { 7, 0, 4, 0 }));
            Assert.That(input.Select(data => data.prefix_Progress), Is.All.Zero);
            Assert.That(ConsumeDataExt.CalcProgress(result).Select(data => data.prefix_Progress), Is.EqualTo(new long[] { 7, 0, 4, 0 }));
            Assert.Throws<OverflowException>(() => ConsumeDataExt.CalcProgress(new List<ConsumeData> { Value(long.MaxValue), Value(1) }));
            Assert.Throws<InvalidOperationException>(() => ConsumeDataExt.CalcProgress(new List<ConsumeData> { new ConsumeData(new ConsumeTypeId(1), 1, 1, 2) }));
        }

        [TestCase("812_41", 812, 41)]
        [TestCase("-1_0", -1, 0)]
        [TestCase("0_-9", 0, -9)]
        public void NumericUniqueIdsRoundTripStableGameTypes(string text, int type, int item)
        {
            Assert.That(ConsumeDataExt.TryParseUniqueID(text, out var parsed, out int parsedItem), Is.True);
            Assert.That(parsed.Value, Is.EqualTo(type)); Assert.That(parsedItem, Is.EqualTo(item));
            var data = new ConsumeData(parsed, parsedItem, 1);
            Assert.That(ConsumeDataExt.TryParseUniqueID(data.UniqueID, out var roundTrip, out int id), Is.True);
            Assert.That(roundTrip.Value, Is.EqualTo(type)); Assert.That(id, Is.EqualTo(item));
        }

        [TestCase("bad")]
        [TestCase("Wealth_41")]
        [TestCase("812_1_extra")]
        [TestCase("2147483648_1")]
        [TestCase("812_2147483648")]
        public void InvalidUniqueIdsFailExplicitly(string text)
        { Assert.That(ConsumeDataExt.TryParseUniqueID(text, out _, out _), Is.False); }

        [Test]
        public void TsvListsReuseTailEntriesAndAllowGameOwnedNamesAndRanges()
        {
            var row = new TSVRow(new Dictionary<string, string> { ["rewardType"] = "Coins;Materials", ["rewardId"] = "41", ["rewardValue_min"] = "1;2;3", ["rewardValue_max"] = "2;4;6" });
            row.ImportDatas(out var values, "rewardType", "rewardId", "rewardValue", name => new ConsumeTypeId(name == "Coins" ? (int)GameKind.Coins : (int)GameKind.Materials));
            Assert.That(values.Select(data => data.TypeId.Value), Is.EqualTo(new[] { 812, 9001, 9001 }));
            Assert.That(values[2].ItemId, Is.EqualTo(41)); Assert.That(values[2].Max, Is.EqualTo(6));
            var indexed = new TSVRow(new Dictionary<string, string> { ["priceType_1"] = "-1", ["priceId_1"] = "1", ["priceValue_1"] = long.MaxValue.ToString(), ["priceType_2"] = "0", ["priceId_2"] = "2", ["priceValue_2"] = "7" });
            ConsumeDataExt.ImportDatas(indexed, out values, "price");
            Assert.That(values[0].Quantity, Is.EqualTo(long.MaxValue)); Assert.That(values[1].TypeId.Value, Is.Zero);
            ConsumeDataExt.ImportDatas(new TSVRow(new Dictionary<string, string> { ["priceType"] = "1", ["priceId"] = "41", ["priceValue"] = long.MaxValue.ToString() }), out values, "price");
            Assert.That(values[0].Quantity, Is.EqualTo(long.MaxValue));
        }

        [TestCase("Wealth")]
        [TestCase("Coins")]
        [TestCase("RandomBox")]
        public void NamedTypesRequireTheGameParserAndDoNotUseAFrameworkLexicon(string name)
        {
            var row = new TSVRow(new Dictionary<string, string> { ["consumeType"] = name, ["consumeId"] = "41", ["consumeVal"] = "7" });
            var data = Value(); JObject before = data.ExportJson();
            Assert.Throws<FormatException>(() => data.SetData(row)); Assert.That(JToken.DeepEquals(before, data.ExportJson()), Is.True);
            data.SetData(row, text => text == name ? new ConsumeTypeId((int)GameKind.Coins) : throw new FormatException("Unknown game name"));
            Assert.That(data.TypeId.Value, Is.EqualTo(812)); Assert.That(data.Quantity, Is.EqualTo(7));
        }

        [TestCase("bad")]
        [TestCase("1.5")]
        [TestCase("")]
        public void InvalidTsvDataNeverDefaultsOrPartiallyUpdates(string amount)
        {
            var data = Value(); JObject before = data.ExportJson();
            Assert.Throws<FormatException>(() => data.SetData(new TSVRow(new Dictionary<string, string> { ["consumeType"] = "812", ["consumeId"] = "41", ["consumeVal"] = amount })));
            Assert.That(JToken.DeepEquals(before, data.ExportJson()), Is.True);
        }

        [Test]
        public void TsvOverflowAndIncompleteListsCannotPublishPartialOutputs()
        {
            var data = Value();
            Assert.Throws<OverflowException>(() => data.SetData(new TSVRow(new Dictionary<string, string> { ["consumeType"] = "812", ["consumeId"] = "41", ["consumeVal"] = "9223372036854775808" })));
            var row = new TSVRow(new Dictionary<string, string> { ["rewardType"] = "812", ["rewardId"] = "41", ["rewardValue"] = "3;bad" });
            var values = new List<ConsumeData> { data }; var original = values;
            Assert.Throws<FormatException>(() => row.ImportDatas(true, out values));
            Assert.That(values, Is.SameAs(original)); Assert.That(data.Quantity, Is.EqualTo(5));
            Assert.Throws<InvalidDataException>(() => new TSVRow(new Dictionary<string, string> { ["rewardId"] = "41" }).ImportDatas(true, out _));
        }

        [Test]
        public void PureDataAndExplicitProvidersRemainIndependentAcrossGames()
        {
            var data = Value();
            var first = new Presentation("game A");
            var second = new Presentation("game B");
            Assert.That(data.Present(first).Name, Is.EqualTo("game A"));
            Assert.That(data.Present(second).Name, Is.EqualTo("game B"));
            Assert.That(data.Quantity, Is.EqualTo(5));
            List<ConsumeData> rewards = data.DropReward(request => { request.SetConsumeVal(99); return new List<ConsumeData> { request }; });
            rewards[0].SetConsumeVal(77); Assert.That(data.Quantity, Is.EqualTo(5));
            Assert.Throws<ArgumentNullException>(() => data.Present(null));
            Assert.That(new ConsumeData(data.ExportJson()).TypeId, Is.EqualTo(data.TypeId));
        }

        [Test]
        public void ExplicitConverterUsesInitializedModelsAndPreservesExistingStateOnFailure()
        {
            var model = JsonConvert.DeserializeObject<ProbeModel>("{\"amount\":2147483648}");
            Assert.That(model.Amount, Is.EqualTo(2147483648L));
            Assert.That(JsonConvert.SerializeObject(model), Is.EqualTo("{\"amount\":2147483648}"));
            using var reader = new JsonTextReader(new StringReader("{\"amount\":null}")); reader.Read();
            Assert.Throws<InvalidDataException>(() => new RHJsonDataConverter().ReadJson(reader, typeof(ProbeModel), model, JsonSerializer.CreateDefault()));
            Assert.That(model.Amount, Is.EqualTo(2147483648L));
            var other = Value(); var copy = new ConsumeData(); copy.AssignFrom(other); copy.SetConsumeVal(99);
            Assert.That(other.Quantity, Is.EqualTo(5)); Assert.That(copy.CompareModel(other), Is.True);
        }

        [Test]
        public void JsonInputAndSourceTreesAreDetachedAndNullRootIsRejected()
        {
            JObject input = Json(); input["sourceData"] = new ConsumeData(new ConsumeTypeId((int)GameKind.Materials), 9, 7).ExportJson();
            JObject copy = (JObject)input.DeepClone(); var data = new ConsumeData(input);
            Assert.That(JToken.DeepEquals(copy, input), Is.True);
            input["sourceData"]["consumeVal"] = 999;
            Assert.That(data.sourceData.Quantity, Is.EqualTo(7));
            Assert.Throws<ArgumentNullException>(() => data.ImportJson(null));
            Assert.Throws<ArgumentNullException>(() => data.UpdateJson(null));
            Assert.That(data.Quantity, Is.EqualTo(5));
        }

        private sealed class Presentation : IConsumePresentationProvider
        {
            private readonly string _name;
            public Presentation(string name) { _name = name; }
            public bool TryResolve(ConsumeTypeId typeId, int itemId, out ConsumePresentation presentation) { presentation = default; return false; }
            public ConsumePresentation Resolve(ConsumeData data) { data.SetConsumeVal(100); return new ConsumePresentation(name: _name); }
        }

        public sealed class ProbeModel : JsonDataBase
        {
            private readonly bool _ready;
            public long Amount { get; private set; }
            public ProbeModel() { _ready = true; }
            public override bool ImportJson(JObject data)
            {
                if (!_ready) throw new InvalidOperationException("Virtual parse ran before model initialization.");
                long next = ContainerJson.RequireInt64(data, "amount"); Amount = next; return true;
            }
            public override bool UpdateJson(JObject data) { if (data.ContainsKey("amount")) return ImportJson(data); return true; }
            public override JObject ExportJson() => new JObject { ["amount"] = Amount };
        }
    }
}
