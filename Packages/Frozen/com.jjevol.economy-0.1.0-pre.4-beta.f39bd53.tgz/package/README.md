# JJEvol Economy — Container / ConsumeData local candidate

`com.jjevol.economy@0.1.0-pre.4`은 Container 단일 정본과 게임별 ConsumeTypeId를 사용하는 UPM 개발 원본이다. Unity 6000.3.9f1 기준이다. 고정 후보의 버전·SHA는 Framework 저장소의 `Docs/PackageInstallation.md`와 각 Snapshot manifest, 검증 범위는 `Docs/Guide/Verification.md`를 따른다. 이 폴더는 변경 가능한 소스이므로 버전 문자열만으로 고정 tarball과 같다고 판단하지 않는다.

필수: `com.jjevol.data@0.1.0-pre.1`, `com.jjevol.save@0.1.0-pre.3`, `com.jjevol.tables@0.1.0-pre.2`, Unity Newtonsoft JSON 3.2.2. 제작 도구 `com.jjevol.tables.authoring`은 Editor 선택 설치다. Audio, Effect, Addressables, Platform, Runner, UI, Localization SDK, Firebase, MoreMountains, CodeStage, SGuard, Spine을 요구하지 않는다.

`DataRepository`, `DataContainer`, `RepositoryStorageAdapter`, `ContainerJson`은 0.1.0-pre.4부터 `com.jjevol.data`에 있다. 클래스 이름과 namespace(`jjevol`)는 같다. 재화는 저장소의 부록이다. `ResourceService`는 저장소의 내부 연결 지점으로 예약 상태를 Container 변경과 같은 단계에 반영한다.

실제 데이터의 정본은 `DataRepository`가 관리하는 `WealthContainer()`다. UI·Runtime/Authoring·Validation Economy 소비자는 이 경로를 사용한다. Session 기반 Economy API·Snapshot projection·static 이벤트·고정 ConsumeType enum은 STEP 04-C에서 제거했다. 범용 LocalSaveSession은 Save 패키지의 독립 소비자를 위해 유지한다. 현행 저장 매체는 AES PlayerPrefs이며, 과거 파일 교체 실패 기록은 역사적 증거로 보존한다.

## Container 조회와 예약

게임은 서버와 같은 숫자의 enum을 정의한다. WealthTable의 ID→wealthType 메타데이터를 로드한 뒤 아래처럼 명시적으로 연결한다. 연결한 메타데이터는 서비스 수명 동안 고정되며, 실제 수량은 같은 Container에서 매번 읽는다.

```csharp
using var repository = new DataRepository(profileId);
var wealth = new WealthContainer();
repository.Register(wealth);
repository.ImportJson(confirmedResponse, "wealthInfos"); // 확정 응답. 로컬 durable 저장은 별도다.
using var resources = new ResourceService(repository, loadedWealthTable,
    new ConsumeTypeId((int)GameConsumeKind.Coins));

long raw = resources.GetRaw(itemId);
resources.Reserve(new[] { new ConsumeData(resources.WealthTypeId, itemId, 100L) });
long available = resources.Get(itemId); // raw - pending - inFlight, 최저 0
ResourceRequest request = resources.BeginRequest(); // 표시 수량 변화 없음
// 게임이 전송하고, 이 요청에 대한 권위 있는 서버 응답을 받은 뒤:
resources.ApplyServerResponse(request, response, replace: false, "wealthInfos");
```

Reserve와 CheckSpend는 중복 key 비용을 checked long으로 합산한다. 미지원 종류는 NotSupportedException, 미등록 항목은 ArgumentException이며, 정의된 항목의 Container 행이 없으면 0을 읽고 생성하지 않는다. 범위/음수/overflow 비용은 거부한다. 전송 중에도 새 pending을 예약할 수 있고 CancelPending은 미전송분만 해제한다.

요청은 동시에 하나다. BeginRequest가 빈 pending에 null을 반환하면 보낼 요청이 없다. `ResourceRequest.Sequence`는 서비스 수명 안의 순서일 뿐이고 새 서비스나 앱 재시작에서 1로 돌아간다. 서버 멱등 키로 쓰면 다른 요청이 충돌하므로 금지한다. 멱등 키가 필요하면 게임이 저장소에 영속하는 ID를 만들어 전송한다. FailRequest의 KnownNotApplied는 서버 미처리가 입증된 경우에만 사용한다. 타임아웃·연결 종료 등 확정이 불명확한 실패는 Uncertain으로 보고한다. 이때 hold를 유지하고 추가 예약/전송을 막는다. Resynchronize는 새 전체 서버 snapshot을 원자 적용하며 모든 preview를 버린다. 검증 실패한 응답도 hold를 보존하고 RequiresResynchronization을 설정한다. 중복/이전/다른 서비스의 토큰은 거부한다. 서버 revision이나 응답 권위·프로필의 transport 검증은 게임 Adapter의 책임이다.

부분 응답으로 요청을 확정할 때는 해당 요청의 모든 재화에 명시 quantity가 있어야 한다. 전체 응답은 행 제거까지 확정한다. transport 성공 플래그만으로 hold를 해제하는 API는 없다. 일반 Repository 갱신은 요청 완료를 뜻하지 않으며, 관련 응답은 반드시 ApplyServerResponse로 적용한다.

신규 UI는 `resources.Changed` 인스턴스 이벤트 하나를 구독하고 `GetRaw/Get/CheckSpend`를 다시 조회한다. payload는 Repository/프로필/변경 ID와 revision·변경 종류를 식별하며 별도 UI 잔액을 제공하지 않는다. Container/Repository 이벤트는 하위 모델 관찰용이다. 같은 UI가 세 이벤트를 모두 구독하지 않는다. 신규 경로는 구형 static ChangeResource를 발행하지 않는다. 표시 수량이나 raw가 변하지 않는 전송 이동·반복 입력·상태 플래그만의 변경은 수량 알림을 내지 않는다. 요청 busy/uncertain UI는 게임의 transport 완료 흐름에서 상태를 확인한다.

Container·예약 상태 교체를 완료한 뒤 Container → Repository → ResourceService 순서로 알린다. 알림 안에서 조회는 가능하고 같은 Repository 변경은 거부한다. 구독자 예외는 격리한다. 계정 전환은 기존 Repository를 Dispose하고 새 Repository/서비스를 만든다. Domain Reload를 끈 Editor에서는 Play 시작 시 프로필 점유 기록을 지운다. 이전 Play의 미해제 Repository가 같은 프로필을 막지 않는다. UI 수명 종료는 인스턴스 구독만 해제하며 사용자 데이터나 예약을 폐기하지 않는다.

LocalRewardService는 아래 Storage Adapter API로 PlayerPrefs 저장 확인 거래를 처리한다. 서버 반영은 아래 「Container 조회와 예약」과 Framework `Docs/Guide/Features/SaveEconomy.md`를 따른다.

## Container 통합 저장과 로컬 확정

모든 Container를 먼저 등록한 뒤 같은 profile의 AES PlayerPrefs 저장소와 명시적인 게임 스키마를 연결한다. profile에는 게임·환경·사용자 구분을 넣고, PlayerPrefs namespace와 암호화 key는 게임이 명시 제공한다. 신규 프로필에만 초기 factory가 실행된다. 기존 문서의 필수 Container/스키마가 누락되면 빈 데이터로 초기화하지 않는다.

```csharp
using var repository = new DataRepository(profileId);
repository.Register(new WealthContainer());
// 다른 등록 Container도 같은 문서에 함께 저장/로드된다.
var storage = RepositoryStorageAdapter.Open(repository,
    new LocalSaveRepository(profileId, encryptedCodec, "mygame.progress.v2"),
    "game:local:v1", RepositoryStorageMode.LocalAuthority,
    () => initialContainerJson);
using var resources = new ResourceService(repository, loadedWealthTable, gameWealthTypeId);

var preparation = LocalRewardService.PrepareMutation(storage, resources, costs, rewards);
LocalRewardService.Commit(storage, resources, preparation);
// PlayerPrefs.SetString/Save 및 캐시 readback 확인 후 같은 Container가 바뀌고 인스턴스 이벤트를 발행한다.
```

저장 payload의 `_containerSchema`는 전달한 versioned schema ID다. 로컬 저장으로 등록한 Container(`Register(container)` 기본값)가 필수이며 알 수 없는 다른 payload는 마지막 문서에서 보존한다. exact-document Save API를 사용해 envelope의 추가 필드도 보존한다. Steam nested wealth/PlayerPrefs/스키마 없는 기존 Session 문서는 자동 추측 이전하지 않는다. Save envelope 버전·무결성·프로필·백업·revision 충돌 검사는 기존 LocalSave가 담당한다.

Adapter는 비공개 LocalSaveDocument basis만 보관하고 Session을 만들거나 UI/ResourceService에 노출하지 않는다. pending/inFlight는 영속 저장하지 않는다. 로컬 비용은 예약을 제외한 Get으로 먼저 검사하며, 보상으로 비용 부족을 충당하지 않는다. 같은 preparation은 성공 후 다시 사용할 수 없다. 빈 거래·순변화 0은 exact basis만 확인하고 PlayerPrefs/저장 revision/이벤트를 바꾸지 않는다.

`storage.ApplyAndSave(json, replace, targetKeys)`는 모든 후보와 통합 Export를 저장 전에 검증한 뒤 저장·반영한다. 일반 Container Import/Update/AddOrReplace/Clear는 메모리 변경이며 `storage.IsDirty=true`다. 명시 `storage.Save()`로 저장할 수 있다. 이때 기존 메모리 변경 이벤트를 중복 발행하지 않는다. dirty 상태에서는 새 로컬 보상/비용 거래를 막아 무심코 영속 완료로 취급하지 않는다.

저장 실패는 메모리·revision·예약을 보존하고 오류를 전달한다. 문서 basis 충돌은 Status=Conflict, PlayerPrefs 쓰기 확인 실패 또는 저장 성공 후 메모리 반영 실패는 RecoveryRequired다. PlayerPrefs.Save는 void이며 캐시 readback은 디스크 내구성 보증이 아니다. 쓰기 실패 인스턴스는 새로 열어 게임 receipt와 저장 결과를 확인해야 한다. 로컬 모드에서는 추가 변경을 차단한다. `storage.Reload()`는 모든 Container를 검증해 한 번에 적용하고 모든 preview/token을 무효화한다. 보상을 무조건 재시도하지 않는다. Repository의 Dispose가 Adapter 수명도 끝낸다.

복구 경로는 원인에 따라 다르다. 문서 충돌과 메모리 반영 실패는 `storage.Reload()`로 복구한다. 쓰기 결과가 불확실한 경우(`LocalSaveWriteException`)는 LocalSaveRepository가 이후 쓰기를 계속 거절하므로, Repository를 Dispose하고 새 LocalSaveRepository로 다시 연다. 예외 문구도 "Dispose 후 재오픈"으로 구분한다. 복구 상태에서도 `ResourceService.Dispose()`와 `DataRepository.Dispose()`는 예외를 던지지 않으므로 `using` 블록의 원래 저장 예외가 가려지지 않는다. 변경이 진행 중인 알림 콜백 안에서의 Dispose는 기존처럼 거절한다.

`RepositoryStorageMode.ServerCache`는 명시적인 선택 캐시다. 서버 반영은 별도이고 캐시 저장 실패로 서버 상태를 롤백하거나 로컬 권위 모드로 전환하지 않는다. 캐시 충돌 뒤에는 `RefreshCacheBasis()`로 저장 기준만 갱신하며 서버 모델을 유지한다. 이 모드에 로컬 보상 Commit을 호출할 수 없다.

현재 Economy는 Save의 공개 exact-document Save/Matches API가 필요하다. Save 0.1.0-pre.3 / Economy 0.1.0-pre.3의 호환되는 고정 후보를 함께 선택하고 이전 파일 백엔드 Save tgz와 혼합하지 않는다. 파일 백엔드는 은퇴했다. 현행 AES PlayerPrefs 검증 범위는 Framework `Docs/Guide/Verification.md`를 따른다. 메모리 정본은 Container이고 저장 시점은 게임이 정한다. 저장 확인 실패는 RecoveryRequired이며, 결과 재확인 없이 보상을 재시도하지 않는다.

## 공개 API 변경과 호환 경계

현행 개발 소스는 과거 `0.1.0-pre.1` Snapshot과 API가 다르다. 사용자는 STEP 04-C에서 신규 게임용 구형 Economy 호환 제거를 승인했다. 아래 제거 목록은 그 이행 경계이며, 이후 저장계열 후보는 Framework `Docs/PackageInstallation.md`에 있다. 설치할 때는 선택 후보 manifest의 정확한 Save/Economy/UI Economy 버전·SHA 조합을 확인한다. 현재 개발 소스나 문서 갱신이 소비 게임의 자동 갱신을 뜻하지 않는다.

- `ResourceService`는 DataRepository/WealthTable/ConsumeTypeId 생성자만 사용한다. Session 속성·생성자 및 enum Get overload가 없다.
- `WealthContainer`는 매개변수 없는 실제 모델 생성자만 사용한다. LocalSaveSnapshot projection/CWT 캐시를 제거했다.
- 거래는 `PrepareMutation(storage, resources, costs, rewards)`와 `Commit(storage, resources, preparation)`이다. 단독 비용·보상은 반대쪽에 `Array.Empty<ConsumeData>()`를 전달한다. LocalRewardPreparation/Session overload/composedSnapshot은 없다. 여러 Container 통합 저장은 Storage.ApplyAndSave의 명시 범위를 사용한다.
- 알림은 `resources.Changed`의 ResourceChange batch다. 변경된 ItemIds와 서비스/Repository/profile을 확인하고 GetRaw/Get을 재조회한다. ChangeResource/static 이벤트는 없다.
- 게임 enum의 안정적인 숫자를 `new ConsumeTypeId((int)GameKind.Coins)`로 연결한다. ConsumeData는 TypeId/ItemId/Quantity 및 typed 생성자/SetData를 사용한다. 고정 ConsumeType·consumeType enum alias·구형 int/bool Important 생성자는 제거했다.
- JSON의 consumeType/consumeId/consumeVal 등 서버 필드 alias와 long 파싱은 유지한다. TSV 이름은 SetData(row, gameParser) 또는 명시 열 ImportDatas의 gameParser로 해석한다. 기본 파서는 숫자 ID만 받으며 UniqueID는 숫자 `type_item`이다.

정적 정의의 id는 조회, type은 저장 잔액 식별에 사용한다. type 변경은 게임의 migration 대상이며 서비스 수명 중 metadata binding은 고정된다. 게임이 명시적으로 새 서비스를 연결할 때 새 binding을 읽는다. active는 metadata이며 자동 거래 금지 정책이 아니다. 다른 profile의 실제 상태는 공유하지 않는다.

Prepare는 입력을 분리·검증하고 Commit은 실제 Repository/예약/document basis를 재검사한다. 성공한 preparation은 재사용할 수 없다. 새 preparation으로 같은 보상을 요청하면 다시 지급하므로 사업상 수령 ID 중복 방지는 게임 책임이다. 모든 수량은 long이며 같은 거래의 보상으로 비용 부족을 충당하지 않는다. 스레드/재진입/저장 실패 규칙은 위 Container 계약을 따른다. 제거된 API와 버전 경계는 아래 「공개 API 변경과 호환 경계」와 CHANGELOG를 따른다.

## 의존성 분리와 호환성

- ResourceService/LocalRewardService/WealthContainer는 Container 경로 하나만 사용한다. Save Adapter의 exact document basis는 충돌/저장 검증 자료이며 UI 조회 상태가 아니다.
- ConsumeData는 단일 `ConsumeTypeId`, int ItemId, signed long 수량/범위, JSON/TSV, Clone/Merge/Progress와 sourceData를 제공한다. 게임은 자기 enum의 서버 숫자를 명시적으로 `new ConsumeTypeId((int)GameKind.Coins)`로 전달한다.
- `EconomyRuntimeOptions`와 전역 Provider/값 factory를 제거했다. 순수 데이터는 설정 없이 동작한다. 표시·테이블은 `data.Present(gamePresentationProvider)`, Item 변환은 `ConsumeDataGameExtensions.FromItem(item, gameConvert)`, Drop 조회는 `data.DropReward(gameResolve)` / `data.GetDropList(gameList, filter)`로 명시 전달한다. DTO는 광고·상품·드롭 종류를 직접 실행하지 않는다.
- 기본 DTO에 보안 backend나 전역 값 factory를 붙이지 않는다. 실제 보호 저장/검증은 게임의 실제 상태 소유 계층에서 별도로 제공해야 한다. 기존 factory에는 실제 Vendor 구현/검증이 없었으며 동등한 메모리 보호를 제공한다고 주장하지 않는다.
- JsonDataBase는 명시 Import/Update/Export 계약이다. 자동 Reflection/컬렉션 mapper와 생성자의 가상 Import 호출은 제거했다. RHJsonDataConverter는 모델의 명시 codec을 호출하고 DateTimeConverter/UTC 의미는 유지한다.
- GUID를 보존했어도 assembly가 Assembly-CSharp에서 `JJEvol.Economy.Runtime`으로 바뀐다. 게임 asmdef, reflection/assembly-qualified 이름 및 SerializeReference 이력은 소비자 통합 시 검토한다. 원본 Host와 중복 설치하지 않는다.

`UniqueID`는 안정적인 숫자 `typeId_itemId`를 생성하고 역변환도 이 형태를 읽는다. 게임별 이름 해석은 명시적인 TSV callback에 한정한다. Clone/합산/곱셈/Progress는 checked long이며 실패 시 입력을 바꾸지 않는다. Merge/CalcProgress/Filter는 분리된 결과를 반환한다. None/음수/미지 ID의 데이터 표현과 실제 실행 가능 여부는 별개다.

Import는 type/item/수량 또는 완전한 범위를 요구하고 source metadata를 교체한다. Update는 미전달 필드를 유지한다. null 숫자·잘못된 타입·overflow·서로 다른 alias 값은 오류이며 기존 DTO 상태를 유지한다. 범위는 min/max 모두 Export하고 보상은 grantedData/sourceData envelope를 유지한다. 버전별 변경은 CHANGELOG를 참고한다.

## 제작과 검증

TSV → Resources 변환은 STEP 8의 `TableBuilder.Build`를 사용한다. ID 형식·필수값·FK는 게임의 `ValidateTables`/validate callback 책임이다. WealthTable은 양수 ID·공백 없는 type·중복 ID/type을 추가 검사하지만 테이블 번호나 모든 FK를 검사하지 않는다. 게임 Validator는 파서의 기본값으로 잘못된 ID가 유효한 숫자처럼 보이기 전에 원시 입력을 검사해야 한다.

기본 테스트는 `Tests/Editor`, `Tests/Runtime`과 각각의 격리 asmdef에 있다. Authoring 연계 테스트는 자동 컴파일되지 않는 `Tests/Authoring~`에 두었으며, Authoring을 설치한 격리 Host의 Assets로만 복사해서 실행한다. Runtime에 Editor 의존성을 강제하지 않는다. 실행 결과는 Framework `Docs/Guide/Verification.md`, 원본 경로와 해시는 `Docs/EconomyExtraction/TransferManifest.json`을 따른다.

별도 범위: 실제 서버 transport, 상품/장비/광고/IAP/퀘스트 정책, 실제 Vendor 보호, Player·실기기·실제 게임 콘텐츠 통합. UIBase/ResourceLabel/PriceLabel 연결은 `com.jjevol.ui.economy`가 제공한다. 새 경제 규칙이나 원격 트랜잭션을 제공하지 않는다.

## ID 기반 표시 조회 (STEP 05-E)

`IConsumePresentationProvider`는 두 종류의 조회를 명시적으로 구분한다.

```csharp
if (provider.TryResolve(GameConsumeType.Item.ToConsumeTypeId(), itemId, out var metadata))
{
    // metadata.Name / Description / Icon / Atlas / Grade; no temporary ConsumeData.
}
var contextual = consumeData.Present(provider); // still clones and calls Resolve(ConsumeData)
```

`TryResolve(ConsumeTypeId, int, out ConsumePresentation)`는 정확한 type/item 쌍의 정적 표시 metadata다. 성공한 빈 문자열은 true이고, 미정의 종류/항목·미로드/누락 테이블·게임 규칙상 잘못된 metadata는 false/default로 반환한다. 다른 종류/항목으로 치환하거나 실패를 빈 표시와 혼동하지 않는다. 게임 Provider가 기존 WealthTable과 게임 소유 ItemTable 등을 명시적으로 연결한다. 공통 ItemTable/게임 enum/전역 Registry를 제공하지 않는다.

기존 `Resolve(ConsumeData)`와 `Present`의 수량·Source 의존 처리는 그대로다. Present를 ID 조회로 우회하지 않는다. 두 경로의 공통 metadata는 게임이 재사용할 수 있다. `ConsumePresentation.Table`은 기존 게임 소유 참조이며, 표시 결과의 이름/설명은 조회 시점 값이다. Locale 변경 후 다시 조회한다. 표시 정보가 있다는 사실은 ResourceService의 수량 관리·지급·소비 지원을 의미하지 않는다.

**소스 호환 경계:** STEP 05-E에서 `IConsumePresentationProvider`에 추상 메서드를 추가했으므로 이전 Provider 구현자는 TryResolve를 명시적으로 구현해야 한다. 기존 Present 호출 문법은 동일하다. Framework Provider 테스트 구현은 이 계약으로 이행됐다. 과거 Snapshot의 Provider와 현행 패키지를 혼합할 때는 선택 후보의 정확한 버전·SHA 및 Provider 소스 호환성을 확인한다. 가상의 DTO를 만들어 Resolve에 전달하는 호환 fallback은 없다.

Sprite 로드/lease 해제는 기존 AddressableImage/리소스 로더의 책임이다. Provider는 key만 반환한다. 생성 enum→ID, 실제 암호화 테이블과 Wealth/Item·Locale·Atlas 연결 예제는 `com.jjevol.ui.economy/Tests/Integration~`의 격리 게임 fixture를 참고한다.
