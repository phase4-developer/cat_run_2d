//추가
using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using PlatformLibrary.UnityRuntime;
using UnityEditor;
using UnityEngine;
namespace PlatformLibrary.Step25.Tests.Editor
{
    public class ContractTests
    {
        [Test]public void OriginalTypesPublicApiGuidsAndAssemblyRemain()
        {
            Assert.AreEqual("PlatformLibrary.UnityRuntime",typeof(UnityHapticsProvider).Assembly.GetName().Name);
            Assert.AreEqual("PlatformLibrary.UnityRuntime",typeof(UnityDeepLinkProvider).Namespace);
            Assert.NotNull(typeof(UnityHapticsProvider).GetMethod("TryPulse",new[]{typeof(float),typeof(float),typeof(float)}));
            Assert.AreEqual(typeof(bool),typeof(UnityHapticsProvider).GetProperty("IsSupported").PropertyType);
            Assert.NotNull(typeof(UnityDeepLinkProvider).GetEvent("LinkActivated"));Assert.NotNull(typeof(UnityDeepLinkProvider).GetMethod("Dispose"));
            foreach(var pair in new[]{("cf8206c2fdd107f48971715f6c9dfea7","UnityHapticsProvider.cs"),("e81af4ceb8755f6478f239a6057832ab","UnityDeepLinkProvider.cs")})
                StringAssert.EndsWith("com.jjevol.platform.unity/Runtime/"+pair.Item2,AssetDatabase.GUIDToAssetPath(pair.Item1));
            foreach(var type in new[]{typeof(UnityHapticsProvider),typeof(UnityDeepLinkProvider)})
                Assert.IsFalse(type.GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).Any(f=>Attribute.IsDefined(f,typeof(SerializeField))),"Original plain providers have no Unity serialized fields");
        }
        [Test]public void CoreRemainsEngineNeutralAndProviderHasOnlyExpectedAssemblyDependencies()
        {
            Assert.AreEqual("PlatformLibrary.Core",typeof(IPlatformHapticsProvider).Assembly.GetName().Name);
            Assert.IsFalse(typeof(IPlatformHapticsProvider).Assembly.GetReferencedAssemblies().Any(a=>a.Name.StartsWith("UnityEngine")||a.Name=="PlatformLibrary.UnityRuntime"));
            var references=typeof(UnityHapticsProvider).Assembly.GetReferencedAssemblies().Select(a=>a.Name).ToArray();
            CollectionAssert.Contains(references,"PlatformLibrary.Core");
            foreach(string denied in new[]{"Firebase","Google","Purchasing","Steam","JJEvol.Localization","JJEvol.Audio","JJEvol.Effects"})Assert.IsFalse(references.Any(a=>a.Contains(denied)));
        }
    }
}
//추가 종료
