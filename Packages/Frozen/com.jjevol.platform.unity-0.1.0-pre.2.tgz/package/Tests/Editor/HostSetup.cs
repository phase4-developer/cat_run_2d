//추가
using System;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
namespace PlatformLibrary.Step25.Tests.Editor
{
    public static class HostSetup
    {
        public static void PrepareAndExit()
        {
            try
            {
                if(!Path.GetFullPath(Application.dataPath).Replace('\\','/').Contains("/.local/step25/UnityProviderHost/"))throw new InvalidOperationException("Only new Provider Host settings");
                var settings=Resources.FindObjectsOfTypeAll<PlayerSettings>();if(settings.Length!=1)throw new InvalidOperationException("Expected actual PlayerSettings");
                var serialized=new SerializedObject(settings[0]);var input=serialized.FindProperty("activeInputHandler");
                if(input==null)throw new InvalidOperationException("Actual activeInputHandler setting unavailable");
                input.intValue=1;serialized.ApplyModifiedPropertiesWithoutUndo();AssetDatabase.SaveAssets();EditorApplication.Exit(0);
            }
            catch(Exception ex){Debug.LogException(ex);EditorApplication.Exit(1);}
        }
    }
}
//추가 종료
