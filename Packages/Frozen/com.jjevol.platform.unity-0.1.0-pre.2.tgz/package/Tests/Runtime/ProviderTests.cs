//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using NUnit.Framework;
using PlatformLibrary.UnityRuntime;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.InputSystem.Utilities;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace PlatformLibrary.Step25.Tests
{
    public class HapticsTests
    {
        private UnityHapticsProvider _provider;
        private readonly List<Gamepad> _pads=new List<Gamepad>();
        private readonly List<(Gamepad pad,float low,float high)> _commands=new List<(Gamepad,float,float)>();
        private Action _onCommand;
        private unsafe long? Command(InputDevice device,InputDeviceCommand* command)
        {
            if(!_pads.Contains(device as Gamepad)||command->type!=new FourCC('R','M','B','L'))return null;
            // Decode the actual Input System 1.18.0 RMBL payload; no internal Vendor command type is copied.
            byte* payload=(byte*)command+sizeof(InputDeviceCommand);
            _commands.Add(((Gamepad)device,*(float*)payload,*(float*)(payload+4)));
            var callback=_onCommand;_onCommand=null;callback?.Invoke();
            return InputDeviceCommand.GenericSuccess;
        }
        [SetUp]public unsafe void Setup()
        {
            Assert.AreEqual(0,Gamepad.all.Count,"Physical gamepads must not participate in this isolated command test");
            InputSystem.onDeviceCommand+=Command;_provider=new UnityHapticsProvider();
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {
            ((object)_provider as IDisposable)?.Dispose();
            yield return new WaitForSecondsRealtime(.4f);
            foreach(var pad in _pads)if(pad.added)InputSystem.RemoveDevice(pad);_pads.Clear();
            InputSystem.RemoveLayout("Step25ThrowingGamepad");
            Unsubscribe();_commands.Clear();_onCommand=null;
        }
        private unsafe void Unsubscribe()=>InputSystem.onDeviceCommand-=Command;
        private Gamepad Pad(){var pad=InputSystem.AddDevice<Gamepad>();_pads.Add(pad);pad.MakeCurrent();return pad;}
        [UnityTest]public IEnumerator ActualGamepadStartAndDelayedStop()
        {
            Assert.IsFalse(_provider.IsSupported);Assert.IsFalse(_provider.TryPulse(.2f,.3f,.02f));
            var pad=Pad();Assert.IsTrue(_provider.IsSupported);Assert.IsTrue(_provider.TryPulse(.2f,.3f,.04f));
            Assert.AreSame(pad,_commands.Last().pad);Assert.AreEqual(.2f,_commands.Last().low);Assert.AreEqual(.3f,_commands.Last().high);
            yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(0f,_commands.Last().low);Assert.AreEqual(0f,_commands.Last().high);
        }
        [UnityTest]public IEnumerator OlderStopMustNotCutOffNewerLongPulse()
        {
            Pad();Assert.IsTrue(_provider.TryPulse(.2f,.3f,.06f));yield return new WaitForSecondsRealtime(.02f);
            Assert.IsTrue(_provider.TryPulse(.8f,.9f,.3f));yield return new WaitForSecondsRealtime(.12f);
            Assert.AreEqual(.8f,_commands.Last().low,.0001f,"Old delayed stop must not stop the new pulse");Assert.AreEqual(.9f,_commands.Last().high,.0001f);
            yield return new WaitForSecondsRealtime(.25f);Assert.AreEqual(0f,_commands.Last().low);
        }
        [UnityTest]public IEnumerator ChangedCurrentGamepadDoesNotReceiveAnotherDevicesStop()
        {
            var first=Pad();_provider.TryPulse(.4f,.5f,.05f);var second=Pad();
            yield return new WaitForSecondsRealtime(.12f);
            Assert.AreSame(first,_commands.Last().pad);Assert.IsFalse(_commands.Any(c=>c.pad==second));
        }
        [UnityTest]public IEnumerator RemovedDeviceMustNotReceiveDelayedCommand()
        {
            var pad=Pad();_provider.TryPulse(.4f,.5f,.05f);InputSystem.RemoveDevice(pad);int before=_commands.Count;
            yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(before,_commands.Count,"Removed device must not receive a stale stop command");
        }
        [UnityTest]public IEnumerator NativeStrengthClampingAndZeroDurationRemainSupported()
        {
            Pad();Assert.IsTrue(_provider.TryPulse(-2f,2f,.04f));Assert.AreEqual(0f,_commands.Last().low);Assert.AreEqual(1f,_commands.Last().high);
            yield return new WaitForSecondsRealtime(.1f);Assert.IsTrue(_provider.TryPulse(.2f,.3f,0));yield return null;Assert.AreEqual(0f,_commands.Last().low);
        }
        [UnityTest]public IEnumerator NegativeDurationMustFailBeforeIssuingRumble()
        {
            Pad();bool accepted=_provider.TryPulse(.2f,.3f,-.01f);
            if(accepted){LogAssert.Expect(LogType.Exception,new Regex("ArgumentOutOfRangeException"));yield return null;}
            Assert.IsFalse(accepted,"Invalid duration must not start a pulse that has no valid delayed stop");Assert.AreEqual(0,_commands.Count);
        }
        [UnityTest]public IEnumerator NanStrengthMustNotReachRumbleCommandPayload()
        {
            Pad();Assert.IsFalse(_provider.TryPulse(float.NaN,.3f,.02f),"NaN strength must not be sent to a device");
            Assert.AreEqual(0,_commands.Count);yield return null;
        }
        [UnityTest]public IEnumerator DisposeStopsOnlyOwnedDeviceAndRejectsFutureCalls()
        {
            var first=Pad();_provider.TryPulse(.4f,.5f,.08f);Pad();_provider.Dispose();_provider.Dispose();
            Assert.AreSame(first,_commands.Last().pad);Assert.AreEqual(0,_commands.Last().low);int count=_commands.Count;
            Assert.IsFalse(_provider.TryPulse(.9f,.9f,.01f));yield return new WaitForSecondsRealtime(.15f);Assert.AreEqual(count,_commands.Count);
        }
        [UnityTest]public IEnumerator SwitchingPulseDeviceStopsPreviousOwnedMotorImmediately()
        {
            var first=Pad();_provider.TryPulse(.4f,.5f,.06f);var second=Pad();_provider.TryPulse(.8f,.9f,.25f);
            Assert.IsTrue(_commands.Any(c=>c.pad==first&&c.low==0));Assert.AreSame(second,_commands.Last().pad);
            yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(.8f,_commands.Last().low);yield return new WaitForSecondsRealtime(.2f);Assert.AreEqual(0,_commands.Last().low);
        }
        [UnityTest]public IEnumerator ReentrantDeviceCommandCannotRestoreAnOlderStop()
        {
            Pad();_onCommand=()=>Assert.IsTrue(_provider.TryPulse(.8f,.9f,.25f));_provider.TryPulse(.2f,.3f,.04f);
            yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(.8f,_commands.Last().low);
            yield return new WaitForSecondsRealtime(.2f);Assert.AreEqual(0,_commands.Last().low);
        }
        [UnityTest]public IEnumerator ReentrantDisposeLeavesNoDelayedCommands()
        {
            Pad();_onCommand=()=>_provider.Dispose();_provider.TryPulse(.2f,.3f,.04f);Assert.AreEqual(0,_commands.Last().low);int count=_commands.Count;
            yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(count,_commands.Count);
        }
        [UnityTest]public IEnumerator InvalidInputDoesNotInterruptAnAcceptedPulse()
        {
            Pad();_provider.TryPulse(.4f,.5f,.2f);int count=_commands.Count;
            foreach(float duration in new[]{-1f,float.NaN,float.PositiveInfinity,float.NegativeInfinity,float.MaxValue,2147484f})
                Assert.IsFalse(_provider.TryPulse(.8f,.9f,duration));
            Assert.IsFalse(_provider.TryPulse(.8f,float.NaN,.02f));Assert.AreEqual(count,_commands.Count);
            yield return new WaitForSecondsRealtime(.25f);Assert.AreEqual(0,_commands.Last().low);
        }
        [UnityTest]public IEnumerator TwentyOverlappingPulsesHaveOnlyOneFinalStop()
        {
            Pad();for(int i=0;i<20;i++)Assert.IsTrue(_provider.TryPulse(.1f+i*.01f,.5f,.04f));
            Assert.AreEqual(20,_commands.Count);yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(21,_commands.Count);Assert.AreEqual(0,_commands.Last().low);
        }
        [UnityTest]public IEnumerator ResolverDoesNotOwnConcreteHapticsDisposal()
        {
            Pad();var resolver=new PlatformServiceResolver();resolver.RegisterHaptics(_provider);_provider.TryPulse(.4f,.5f,.08f);resolver.Dispose();
            Assert.AreEqual(.4f,_commands.Last().low,"Existing Core Dispose does not dispose its Haptics interface");
            _provider.Dispose();Assert.AreEqual(0,_commands.Last().low);int count=_commands.Count;yield return new WaitForSecondsRealtime(.15f);Assert.AreEqual(count,_commands.Count);
        }
        [UnityTest]public IEnumerator DisabledDeviceCancelsItsPendingStop()
        {
            var pad=Pad();_provider.TryPulse(.4f,.5f,.05f);InputSystem.DisableDevice(pad);int count=_commands.Count;
            yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(count,_commands.Count);InputSystem.EnableDevice(pad);
        }
        [UnityTest]public IEnumerator SceneOwnerStopsActiveMotorBeforeUnloadCompletes()
        {
            Pad();var scene=SceneManager.CreateScene("Step25-haptic-owner");var root=new GameObject("Fixture Haptics Owner");SceneManager.MoveGameObjectToScene(root,scene);
            root.AddComponent<ProviderOwner>().Haptics=_provider;_provider.TryPulse(.4f,.5f,.25f);
            yield return SceneManager.UnloadSceneAsync(scene);Assert.AreEqual(0,_commands.Last().low);int count=_commands.Count;
            yield return new WaitForSecondsRealtime(.3f);Assert.AreEqual(count,_commands.Count);Assert.IsFalse(_provider.TryPulse(.2f,.3f,.02f));
        }
        [UnityTest]public IEnumerator ReentrantReplacementWhileStoppingPreviousPadKeepsNewestRequest()
        {
            Pad();_provider.TryPulse(.3f,.4f,.04f);var second=Pad();_onCommand=()=>Assert.IsTrue(_provider.TryPulse(.7f,.8f,.25f));
            Assert.IsFalse(_provider.TryPulse(.1f,.2f,.05f),"Superseded reentrant request must not replace the newer owner");
            yield return new WaitForSecondsRealtime(.12f);Assert.AreSame(second,_commands.Last().pad);Assert.AreEqual(.7f,_commands.Last().low);
            yield return new WaitForSecondsRealtime(.2f);Assert.AreEqual(0,_commands.Last().low);
        }
        [UnityTest]public IEnumerator DeviceCommandExceptionCleansOwnershipAndAllowsRetry()
        {
            InputSystem.RegisterLayout<ThrowingGamepad>("Step25ThrowingGamepad");var bad=InputSystem.AddDevice<ThrowingGamepad>();_pads.Add(bad);bad.MakeCurrent();
            Assert.Throws<InvalidOperationException>(()=>_provider.TryPulse(.2f,.3f,.04f));
            Assert.IsNull(typeof(UnityHapticsProvider).GetField("_pendingStop",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(_provider));
            var good=Pad();Assert.IsTrue(_provider.TryPulse(.7f,.8f,.08f));yield return new WaitForSecondsRealtime(.15f);
            Assert.AreSame(good,_commands.Last().pad);Assert.AreEqual(0,_commands.Last().low);
        }
        [UnityTest]public IEnumerator InfiniteStrengthKeepsOriginalSdkClamping()
        {
            Pad();Assert.IsTrue(_provider.TryPulse(float.NegativeInfinity,float.PositiveInfinity,.04f));Assert.AreEqual(0,_commands.Last().low);Assert.AreEqual(1,_commands.Last().high);
            yield return new WaitForSecondsRealtime(.12f);Assert.AreEqual(0,_commands.Last().high);
        }
    }
    public class DeepLinkTests
    {
        private readonly List<UnityDeepLinkProvider> _providers=new List<UnityDeepLinkProvider>();
        private static Action<string> Snapshot()
        {
            var field=typeof(Application).GetField("deepLinkActivated",BindingFlags.NonPublic|BindingFlags.Static);
            Assert.NotNull(field,"Actual Unity 6000.3.9f1 Application event backing field must be inspected");
            return field.GetValue(null) as Action<string>;
        }
        private UnityDeepLinkProvider Provider(){var value=new UnityDeepLinkProvider();_providers.Add(value);return value;}
        [TearDown]public void Cleanup(){foreach(var value in _providers)value.Dispose();_providers.Clear();}
        [Test]public void InitialUrlMatchesActualApplicationAndInputPolicyIsUnchanged()
        {
            var provider=Provider();Assert.IsTrue(provider.IsSupported);Assert.AreEqual(Application.absoluteURL??string.Empty,provider.CurrentUrl);
            var values=new List<string>();provider.LinkActivated+=values.Add;
            Snapshot()?.Invoke("jjevol-fixture://open/item");Snapshot()?.Invoke("not a validated URL");Snapshot()?.Invoke(null);Snapshot()?.Invoke("");
            CollectionAssert.AreEqual(new[]{"jjevol-fixture://open/item","not a validated URL","",""},values);Assert.AreEqual("",provider.CurrentUrl);
        }
        [Test]public void RepeatedEventsAndDisposeAndRecreationUseSingleSubscription()
        {
            var provider=Provider();int count=0;provider.LinkActivated+=url=>count++;
            Snapshot()?.Invoke("fixture://same");Snapshot()?.Invoke("fixture://same");Assert.AreEqual(2,count);
            provider.Dispose();provider.Dispose();Snapshot()?.Invoke("fixture://after-dispose");Assert.AreEqual(2,count);
            var next=Provider();int current=0;next.LinkActivated+=url=>current++;Snapshot()?.Invoke("fixture://new");Assert.AreEqual(2,count);Assert.AreEqual(1,current);
        }
        [Test]public void CapturedBeforeDisposeCallbackMustNotPublishAfterDispose()
        {
            var provider=Provider();int count=0;provider.LinkActivated+=url=>count++;
            var queued=Snapshot();string original=provider.CurrentUrl;provider.Dispose();queued?.Invoke("fixture://late");
            Assert.AreEqual(0,count,"A callback captured before Dispose must not escape its lifetime");Assert.AreEqual(original,provider.CurrentUrl);
        }
        [Test]public void ResolverUsesExistingRegistrationDuplicateAndDisposeContract()
        {
            var resolver=new PlatformServiceResolver();Assert.IsFalse(resolver.DeepLinks.IsSupported);Assert.IsFalse(resolver.Haptics.IsSupported);
            var links=Provider();var haptics=new UnityHapticsProvider();resolver.RegisterDeepLinks(links);resolver.RegisterHaptics(haptics);
            Assert.AreSame(links,resolver.DeepLinks);Assert.AreSame(haptics,resolver.Haptics);
            Assert.Throws<InvalidOperationException>(()=>resolver.RegisterDeepLinks(links));Assert.Throws<InvalidOperationException>(()=>resolver.RegisterHaptics(haptics));
            resolver.Dispose();int count=0;links.LinkActivated+=url=>count++;Snapshot()?.Invoke("fixture://resolver-ended");Assert.AreEqual(0,count);
            Assert.IsFalse(resolver.DeepLinks.IsSupported);Assert.IsFalse(resolver.Haptics.IsSupported);
            ((object)haptics as IDisposable)?.Dispose();
        }
        [UnityTest]public IEnumerator SceneUnloadUsesGameOwnedDisposalAndBlocksCapturedCallbacks()
        {
            var scene=SceneManager.CreateScene("Step25-owned-lifetime");var root=new GameObject("Fixture Provider Owner");SceneManager.MoveGameObjectToScene(root,scene);
            var owner=root.AddComponent<ProviderOwner>();owner.Links=Provider();owner.Haptics=new UnityHapticsProvider();int count=0;owner.Links.LinkActivated+=url=>count++;
            var captured=Snapshot();Snapshot()?.Invoke("fixture://scene-alive");Assert.AreEqual(1,count);
            var links=owner.Links;yield return SceneManager.UnloadSceneAsync(scene);captured?.Invoke("fixture://scene-gone");Assert.AreEqual(1,count);Assert.AreEqual("fixture://scene-alive",links.CurrentUrl);
            var next=Provider();int nextCount=0;next.LinkActivated+=url=>nextCount++;Snapshot()?.Invoke("fixture://next-scene");Assert.AreEqual(1,count);Assert.AreEqual(1,nextCount);
        }
    }
    public sealed class ProviderOwner : MonoBehaviour
    {
        public UnityDeepLinkProvider Links;
        public UnityHapticsProvider Haptics;
        private void OnDestroy(){Haptics?.Dispose();Links?.Dispose();}
    }
    public sealed class ThrowingGamepad : Gamepad
    {
        public override void SetMotorSpeeds(float lowFrequency,float highFrequency)=>throw new InvalidOperationException("STEP25 injected device failure");
    }
}
//추가 종료
