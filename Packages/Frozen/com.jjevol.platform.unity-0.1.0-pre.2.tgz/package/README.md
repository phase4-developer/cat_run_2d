# Unity Haptics / Deep Link Providers

선택 개발 후보 `com.jjevol.platform.unity@0.1.0-pre.2`. Unity 6000.3.9f1, Input System 1.18.0 및 `com.jjevol.platform.core@0.1.0-pre.2`를 사용한다. Production assembly는 원본 `PlatformLibrary.UnityRuntime`이다. SDK 구현을 포함하지 않는다.

## 설치와 등록

기존 고정 Platform Core를 먼저 설치하고 이 패키지를 로컬 UPM으로 추가한다. 기본 registry에 JJEvol 패키지가 공개되어 있다고 가정하지 않는다. 검증 manifest/lock과 보고서는 `Docs/PlatformUnityExtraction`에 있다. 소비 프로젝트에서 Input System을 활성화하고 Editor를 재시작한다. 검증 Host는 Active Input Handling = Input System Package (New)를 사용했다.

```csharp
using PlatformLibrary;
using PlatformLibrary.UnityRuntime;

var services = new PlatformServiceResolver();
var haptics = new UnityHapticsProvider();
var links = new UnityDeepLinkProvider();
services.RegisterHaptics(haptics);
services.RegisterDeepLinks(links);
links.LinkActivated += url => { /* 게임의 URL 처리 */ };
services.Haptics.TryPulse(0.2f, 0.4f, 0.1f);
// links.CurrentUrl에는 생성 시 Application.absoluteURL이 들어 있다.

// 게임 Composition Root의 Scene/앱 수명 종료 시:
haptics.Dispose(); // 기존 Resolver는 Haptics를 Dispose하지 않는다.
services.Dispose(); // DeepLinks.Dispose 호출 및 등록 해제.
```

자동 Singleton/등록/Scene hook은 없다. Scene을 넘어 유지할지는 게임이 결정한다. 각각 하나만 등록해도 된다. 다만 Deep Link만 사용해도 이 패키지의 Input System 의존성은 설치된다. 두 작은 원본 Provider의 같은 assembly를 보존하기 위해 한 패키지로 묶었다.

Resolver는 중복 등록을 거절하며 replace/unregister API가 없다. 등록에 실패한 새 Deep Link Provider는 호출자가 Dispose해야 한다. 생성자가 즉시 Application 이벤트를 구독하기 때문이다. 모든 호출과 Dispose는 Unity main thread에서 수행한다. 같은 Gamepad를 여러 Provider/다른 rumble 작성자가 동시에 제어하는 소유권 중재는 제공하지 않는다.

## 유지한 의미와 수명 보완

- `TryPulse(float lowFrequency, float highFrequency, float seconds)`와 `IsSupported`를 유지한다. Gamepad 강도 범위 보정은 실제 Input System의 Clamp01에 맡긴다. 0초를 지원하고 정상 지속시간의 float 밀리초→int 절삭을 유지한다. 지원 장치 유무/모바일 조건인 IsSupported는 Dispose 이후에도 capability 의미다. Dispose된 Provider의 TryPulse는 false다.
- 재현된 음수 지속시간/NaN 강도 문제를 보완했다. 음수·NaN·무한·int 밀리초 범위 초과 지속시간, NaN 강도는 명령 전에 false를 반환한다. 기존 SDK가 처리하던 유한 범위 밖 강도와 ±Infinity 강도는 그대로 SDK에 전달해 clamp된다. 거절한 입력은 기존 pulse를 취소하지 않는다.
- 최신 pulse만 지연 정지를 소유한다. 다른 Gamepad로 새 pulse를 시작하면 이전 소유 장치는 즉시 0으로 정지한다. 제거/연결 해제/비활성화는 이전 지연 작업을 취소한다. `IDisposable`을 concrete Provider에 추가했으며 종료 시 활성 장치 정지·취소·임시 이벤트 해제를 수행한다. Core interface/Resolver는 변경하지 않았다.
- 실제 SDK 시작 호출 예외는 정리 후 원래처럼 호출자에게 전달한다. 지연 정지의 예상 취소만 정상 처리하고 다른 예외는 Unity에 기록한다. 활성 pulse 동안만 `Application.quitting`과 장치 변경을 구독한다.
- 모바일의 기존 `Handheld.Vibrate()` 한 번 호출도 보존했다. 이 API는 요청 강도/초를 반영하거나 이미 시작한 진동을 취소하는 API가 아니다. 이번 Editor 시험은 Android/iOS 분기를 실행하지 않았다.
- Deep Link의 최초 URL, null→빈 문자열, 잘못된 형식/중복 URL의 그대로 전달을 유지한다. Dispose는 멱등이며 구독/소비자 참조를 해제한다. Dispose 전에 캡처된 이전 Unity 이벤트 delegate가 호출돼도 URL/알림을 변경하지 않는다. URL 보안 검증·라우팅은 게임 소유다.

## 검증 범위

실제 Unity/Input System의 합성 Gamepad와 RMBL 명령 경로, 실제 Application 이벤트 delegate chain, Scene unload와 게임 소유 Dispose를 검증했다. 물리 모터, OS가 앱을 실행하는 Deep Link, cold-start/background resume, Android/iOS 및 Player 빌드는 NOT_RUN이다. 전체 플랫폼 검증 완료나 고정 배포본으로 간주하지 않는다.
