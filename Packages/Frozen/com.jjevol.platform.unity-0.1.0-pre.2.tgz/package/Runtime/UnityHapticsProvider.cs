//추가
using System;
using System.Threading;
//추가 종료
using System.Threading.Tasks;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace PlatformLibrary.UnityRuntime
{
    //수정
    public sealed class UnityHapticsProvider : IPlatformHapticsProvider, IDisposable
    //수정 종료
    {
        //추가
        private bool _disposed;
#if ENABLE_INPUT_SYSTEM
        private CancellationTokenSource _pendingStop;
        private Gamepad _activeGamepad;
        private long _requestVersion;
#endif
        //추가 종료
        public bool IsSupported
        {
            get
            {
#if UNITY_ANDROID || UNITY_IOS
                return true;
#elif ENABLE_INPUT_SYSTEM
                return Gamepad.current != null;
#else
                return false;
#endif
            }
        }

        public bool TryPulse(float lowFrequency, float highFrequency, float seconds)
        {
            //추가
            float milliseconds = seconds * 1000f;
            if (_disposed || float.IsNaN(lowFrequency) || float.IsNaN(highFrequency) ||
                float.IsNaN(seconds) || seconds < 0f || float.IsInfinity(seconds) || (double)milliseconds >= 2147483648d)
                return false;
            //추가 종료
            bool supported = false;
#if ENABLE_INPUT_SYSTEM
            var gamepad = Gamepad.current;
            if (gamepad != null)
            {
                //수정
                long requestVersion = ++_requestVersion;
                CancelPendingStop(_activeGamepad != gamepad);
                if (_disposed || requestVersion != _requestVersion) return false;
                var pending = new CancellationTokenSource();
                _pendingStop = pending;
                _activeGamepad = gamepad;
                InputSystem.onDeviceChange += OnDeviceChange;
                Application.quitting += Dispose;
                try
                {
                    gamepad.SetMotorSpeeds(lowFrequency, highFrequency);
                }
                catch
                {
                    if (ReferenceEquals(_pendingStop, pending)) CancelPendingStop(false);
                    pending.Dispose();
                    throw;
                }
                if (ReferenceEquals(_pendingStop, pending))
                    _ = StopAfterDelay(gamepad, (int)milliseconds, pending);
                else
                    pending.Dispose(); // A device command can reenter TryPulse or Dispose.
                supported = true;
                //수정 종료
            }
#endif
#if UNITY_ANDROID || UNITY_IOS
            Handheld.Vibrate();
            supported = true;
#endif
            return supported;
        }

#if ENABLE_INPUT_SYSTEM
        //수정
        private async Task StopAfterDelay(Gamepad gamepad, int milliseconds, CancellationTokenSource pending)
        {
            try
            {
                await Task.Delay(milliseconds, pending.Token);
                if (!ReferenceEquals(_pendingStop, pending) || _disposed) return;
                ClearPendingStop();
                if (gamepad.added) gamepad.SetMotorSpeeds(0f, 0f);
            }
            catch (OperationCanceledException) when (pending.IsCancellationRequested) { }
            catch (Exception exception) { Debug.LogException(exception); }
            finally { pending.Dispose(); }
        }
        //수정 종료
        //추가
        private void ClearPendingStop()
        {
            _pendingStop = null;
            _activeGamepad = null;
            InputSystem.onDeviceChange -= OnDeviceChange;
            Application.quitting -= Dispose;
        }

        private void CancelPendingStop(bool stopMotor)
        {
            var pending = _pendingStop;
            var gamepad = _activeGamepad;
            ClearPendingStop();
            pending?.Cancel();
            if (stopMotor && gamepad != null && gamepad.added) gamepad.SetMotorSpeeds(0f, 0f);
        }

        private void OnDeviceChange(InputDevice device, InputDeviceChange change)
        {
            if (device == _activeGamepad && (change == InputDeviceChange.Removed ||
                change == InputDeviceChange.Disconnected || change == InputDeviceChange.Disabled))
                CancelPendingStop(false);
        }
        //추가 종료
#endif
        //추가
        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
#if ENABLE_INPUT_SYSTEM
            CancelPendingStop(true);
#endif
        }
        //추가 종료
    }
}
