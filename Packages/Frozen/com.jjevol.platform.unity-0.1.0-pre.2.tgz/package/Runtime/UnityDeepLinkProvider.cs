using System;
using UnityEngine;

namespace PlatformLibrary.UnityRuntime
{
    public sealed class UnityDeepLinkProvider : IPlatformDeepLinkProvider
    {
        //추가
        private bool _disposed;
        //추가 종료
        public bool IsSupported => true;
        public string CurrentUrl { get; private set; }
        public event Action<string> LinkActivated;
        public UnityDeepLinkProvider()
        {
            CurrentUrl = Application.absoluteURL ?? string.Empty;
            Application.deepLinkActivated += OnLinkActivated;
        }
        //수정
        private void OnLinkActivated(string url)
        {
            if (_disposed) return;
            CurrentUrl = url ?? string.Empty;
            LinkActivated?.Invoke(CurrentUrl);
        }
        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            Application.deepLinkActivated -= OnLinkActivated;
            LinkActivated = null;
        }
        //수정 종료
    }
}
