using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("JJEvol.Quest.Tests.Editor")]
