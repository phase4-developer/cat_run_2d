using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using PlatformLibrary.Network;
using jjevol;

namespace jjevol.Quest.Network
{
    /// <summary>
    /// Local-route side of the quest requests. <see cref="QuestLocalService"/> routes requests here; a game with its own
    /// <see cref="INetworkLocalService"/> can call <see cref="TryHandle"/>.
    /// Request parameters: record <c>{ ev: [{t, c, v}] }</c>; claim <c>{ id, premium? }</c> | <c>{ group }</c> | <c>{ tab }</c> | <c>{ complete }</c>.
    /// The response carries the state key, paid rewards (through <see cref="IQuestGrantWriter"/>) and <c>rewards</c> for the popup;
    /// the request's DataKeys must list the state key and the paid keys so they are applied together.
    /// Failures throw <see cref="NetworkRejection"/> with a <see cref="QuestCodes"/> string.
    /// </summary>
    public sealed class QuestLocalHandler
    {
        public const string RewardsKey = "rewards";
        private readonly QuestRules _rules;
        private readonly Func<QuestState> _state;
        private readonly IQuestGrantWriter _grants;
        private readonly Func<long> _now;
        private readonly Func<string, bool> _isOpen;

        public QuestLocalHandler(QuestRules rules, QuestStateContainer state, IQuestGrantWriter grants, Func<long> nowUtcMs, Func<string, bool> isOpen = null)
            : this(rules, () => (state ?? throw new ArgumentNullException(nameof(state))).Current, grants, nowUtcMs, isOpen, state?.DataKey ?? QuestStateJson.DefaultKey) { }

        public QuestLocalHandler(QuestRules rules, Func<QuestState> state, IQuestGrantWriter grants, Func<long> nowUtcMs, Func<string, bool> isOpen = null, string stateKey = QuestStateJson.DefaultKey)
        {
            _rules = rules ?? throw new ArgumentNullException(nameof(rules));
            _state = state ?? throw new ArgumentNullException(nameof(state));
            _grants = grants;
            _now = nowUtcMs ?? throw new ArgumentNullException(nameof(nowUtcMs));
            _isOpen = isOpen;
            StateKey = string.IsNullOrWhiteSpace(stateKey) ? throw new ArgumentException("State key is required.", nameof(stateKey)) : stateKey;
        }

        /// <summary>Repository key of the quest state in responses.</summary>
        public string StateKey { get; }

        /// <summary>Handles <see cref="QuestCall.RecordName"/> and <see cref="QuestCall.ClaimName"/>. False for any other name.</summary>
        public bool TryHandle(string requestName, IReadOnlyDictionary<string, object> parameters, out JObject response)
        {
            switch (requestName)
            {
                case QuestCall.RecordName: response = HandleRecord(parameters); return true;
                case QuestCall.ClaimName: response = HandleClaim(parameters); return true;
                default: response = null; return false;
            }
        }

        /// <summary>Client-reported progress. Server-only clear types and point counters are rejected.</summary>
        public JObject HandleRecord(IReadOnlyDictionary<string, object> parameters)
        {
            QuestEvent[] events;
            try { events = ParseEvents(parameters); }
            catch (InvalidDataException e) { throw new NetworkRejection(QuestCodes.BadEvent, e.Message); }
            var response = new JObject();
            string code = Write(response, (s, now) => _rules.Record(s, events, now, QuestSource.Client, _isOpen), fromResponse: false);
            if (code != null) throw new NetworkRejection(code);
            return response;
        }

        public JObject HandleClaim(IReadOnlyDictionary<string, object> parameters)
        {
            QuestClaimTarget target;
            try { target = QuestClaimTarget.From(parameters); }
            catch (InvalidDataException e) { throw new NetworkRejection(QuestCodes.BadRequest, e.Message); }
            var response = new JObject();
            string code = Write(response, (s, now) => _rules.Claim(s, target, now, _isOpen), fromResponse: false);
            if (code != null) throw new NetworkRejection(code);
            return response;
        }

        /// <summary>
        /// Adds progress to a response another local handler built (a run end, a purchase), so progress and result are applied together.
        /// Continues from the quest state already in the response, if any. Returns null, or the rejection code with the response unchanged.
        /// </summary>
        public string AppendProgress(JObject response, IReadOnlyList<QuestEvent> events, QuestSource source = QuestSource.Server)
        {
            if (response == null) throw new ArgumentNullException(nameof(response));
            return Write(response, (s, now) => _rules.Record(s, events, now, source, _isOpen), fromResponse: true);
        }

        /// <summary>
        /// Adds the quest part of rewards paid elsewhere (point consume types, premium activation) to that response.
        /// Returns null, or the rejection code with the response unchanged.
        /// </summary>
        public string AppendRewards(JObject response, IReadOnlyList<ConsumeData> rewards)
        {
            if (response == null) throw new ArgumentNullException(nameof(response));
            return Write(response, (s, now) => _rules.ApplyRewards(s, rewards, now, _isOpen), fromResponse: true);
        }

        private string Write(JObject response, Func<QuestState, long, QuestResult> run, bool fromResponse)
        {
            QuestState state = _state();
            if (fromResponse && response[StateKey] is JObject carried)
            {
                try { state = QuestStateJson.Read(carried); }
                catch (InvalidDataException e) { throw new InvalidOperationException("The response carries a bad quest state: " + e.Message, e); }
            }
            QuestResult result;
            try { result = run(state, _now()); }
            catch (OverflowException) { return QuestCodes.UnsupportedReward; }
            if (!result.Ok) return result.Code;
            if (result.Grants.Count > 0 && _grants == null) return QuestCodes.UnsupportedReward;

            // Write into a copy so a writer that cannot pay (wrong kind, unknown id, balance overflow) leaves the response as it was.
            var copy = (JObject)response.DeepClone();
            copy[StateKey] = QuestStateJson.Write(result.State);
            try { _grants?.Write(copy, result.Grants); }
            catch (Exception e) when (e is InvalidOperationException || e is OverflowException || e is ArgumentException) { return QuestCodes.UnsupportedReward; }
            if (result.Rewards.Count > 0)
            {
                var rewards = copy[RewardsKey] as JArray ?? new JArray();
                foreach (ConsumeData r in result.Rewards) rewards.Add(r.ExportJson());
                copy[RewardsKey] = rewards;
            }
            foreach (JProperty p in copy.Properties().ToArray()) response[p.Name] = p.Value;
            return null;
        }

        /// <summary>Reads <c>ev</c>: an array of <c>{t, c?, v}</c> integers.</summary>
        public static QuestEvent[] ParseEvents(IReadOnlyDictionary<string, object> parameters)
        {
            if (parameters == null || !parameters.TryGetValue("ev", out object raw) || raw == null) throw new InvalidDataException("ev is required.");
            JToken token = raw as JToken ?? JToken.FromObject(raw);
            if (!(token is JArray array) || array.Count == 0) throw new InvalidDataException("ev must be a nonempty array.");
            var events = new List<QuestEvent>();
            foreach (JToken item in array)
            {
                if (!(item is JObject o)) throw new InvalidDataException("ev items must be objects.");
                events.Add(new QuestEvent(Int(o["t"], "t"), Long(o["v"], "v"), o["c"] == null || o["c"].Type == JTokenType.Null ? 0 : Int(o["c"], "c")));
            }
            return events.ToArray();
        }

        /// <summary>The <c>ev</c> parameter value for a request.</summary>
        public static JArray WriteEvents(IEnumerable<QuestEvent> events)
            => new JArray((events ?? throw new ArgumentNullException(nameof(events))).Select(e => new JObject { ["t"] = e.Type, ["c"] = e.Condition, ["v"] = e.Amount }));

        private static int Int(JToken token, string name)
        {
            long v = Long(token, name);
            if (v < int.MinValue || v > int.MaxValue) throw new InvalidDataException(name + " is out of range.");
            return (int)v;
        }

        private static long Long(JToken token, string name)
        {
            if (token == null || token.Type != JTokenType.Integer) throw new InvalidDataException(name + " must be an integer.");
            try { return token.Value<long>(); }
            catch (OverflowException) { throw new InvalidDataException(name + " is out of range."); }
        }
    }

    /// <summary>
    /// <see cref="INetworkLocalService"/> that handles the quest requests and, for the game's other requests, adds the progress they make
    /// to their responses. Wrap the game's own service:
    /// <c>NetworkManager.SetLocalService(new QuestLocalService(handler, gameService).Progress("run.end", (call, data) => events));</c>
    /// A request with progress must list the quest state key (and the paid keys of autoClaim rewards) in its DataKeys.
    /// </summary>
    public sealed class QuestLocalService : INetworkLocalService
    {
        private readonly QuestLocalHandler _handler;
        private readonly INetworkLocalService _inner;
        private readonly Dictionary<string, List<Func<NetworkCall, JObject, IEnumerable<QuestEvent>>>> _progress =
            new Dictionary<string, List<Func<NetworkCall, JObject, IEnumerable<QuestEvent>>>>(StringComparer.Ordinal);
        private readonly Dictionary<string, List<Func<NetworkCall, JObject, IEnumerable<ConsumeData>>>> _rewards =
            new Dictionary<string, List<Func<NetworkCall, JObject, IEnumerable<ConsumeData>>>>(StringComparer.Ordinal);

        public QuestLocalService(QuestLocalHandler handler, INetworkLocalService inner = null)
        {
            _handler = handler ?? throw new ArgumentNullException(nameof(handler));
            _inner = inner;
        }

        /// <summary>After <paramref name="requestName"/> succeeds, records the events it made (from its parameters or its response) into the same response.</summary>
        public QuestLocalService Progress(string requestName, Func<NetworkCall, JObject, IEnumerable<QuestEvent>> events)
        {
            Add(_progress, requestName, events);
            return this;
        }

        /// <summary>After <paramref name="requestName"/> succeeds, applies the point and premium rewards it paid (a pass purchase, pass experience).</summary>
        public QuestLocalService Rewards(string requestName, Func<NetworkCall, JObject, IEnumerable<ConsumeData>> rewards)
        {
            Add(_rewards, requestName, rewards);
            return this;
        }

        private static void Add<T>(Dictionary<string, List<T>> map, string name, T value)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Request name is required.", nameof(name));
            if (value == null) throw new ArgumentNullException(nameof(value));
            if (name == QuestCall.RecordName || name == QuestCall.ClaimName) throw new ArgumentException("Quest requests carry their own progress.", nameof(name));
            if (!map.TryGetValue(name, out List<T> list)) map.Add(name, list = new List<T>());
            list.Add(value);
        }

        public bool CanHandle(NetworkRequest request)
            => request != null && (request.Name == QuestCall.RecordName || request.Name == QuestCall.ClaimName || (_inner?.CanHandle(request) ?? false));

        public async System.Threading.Tasks.Task<JObject> HandleAsync(NetworkCall call, System.Threading.CancellationToken cancellationToken)
        {
            if (call == null) throw new ArgumentNullException(nameof(call));
            if (_handler.TryHandle(call.Request.Name, call.Parameters, out JObject quest)) return quest;
            if (_inner == null) throw new InvalidOperationException("No local service handles " + call.Request.Name);
            JObject data = await _inner.HandleAsync(call, cancellationToken) ?? new JObject();
            bool hasProgress = _progress.TryGetValue(call.Request.Name, out var progress), hasRewards = _rewards.TryGetValue(call.Request.Name, out var rewards);
            if (!hasProgress && !hasRewards) return data;
            if (!call.Request.DataKeys.Contains(_handler.StateKey))
                throw new InvalidOperationException(call.Request.Name + " adds quest progress but its DataKeys do not list " + _handler.StateKey + "; the progress would be lost.");
            if (hasRewards)
                foreach (var f in rewards)
                {
                    ConsumeData[] list = f(call, data)?.ToArray() ?? Array.Empty<ConsumeData>();
                    if (list.Length == 0) continue;
                    string code = _handler.AppendRewards(data, list);
                    if (code != null) throw new InvalidOperationException("Quest rewards of " + call.Request.Name + " were rejected: " + code);
                }
            if (hasProgress)
                foreach (var f in progress)
                {
                    QuestEvent[] events = f(call, data)?.ToArray() ?? Array.Empty<QuestEvent>();
                    if (events.Length == 0) continue;
                    string code = _handler.AppendProgress(data, events);
                    if (code != null) throw new InvalidOperationException("Quest progress of " + call.Request.Name + " was rejected: " + code);
                }
            return data;
        }
    }
}
