using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using PlatformLibrary.Network;
using jjevol;

namespace jjevol.Quest.Network
{
    /// <summary>
    /// One quest request as the game's request factory receives it. The factory makes the game's <see cref="NetworkRequest"/> subclass
    /// (its common parent) with this name, these parameters and these DataKeys.
    /// </summary>
    public sealed class QuestCall
    {
        public const string RecordName = "quest.record";
        public const string ClaimName = "quest.claim";

        internal QuestCall(string name, IReadOnlyDictionary<string, object> parameters, string[] dataKeys)
        { Name = name; Parameters = parameters; DataKeys = dataKeys; }

        public string Name { get; }
        public IReadOnlyDictionary<string, object> Parameters { get; }
        /// <summary>The quest state key and the paid keys. The request must list them so the response is applied together.</summary>
        public string[] DataKeys { get; }
    }

    /// <summary>Result of a client call.</summary>
    public sealed class QuestOutcome
    {
        internal QuestOutcome(string code, IReadOnlyList<ConsumeData> rewards, bool sent, NetworkResult? network)
        { Code = code; Rewards = rewards ?? Array.Empty<ConsumeData>(); Sent = sent; Network = network; }
        public bool Ok => Code == null;
        /// <summary>A <see cref="QuestCodes"/> value, the server's error code, or null.</summary>
        public string Code { get; }
        /// <summary>Rewards for the popup (the response <c>rewards</c>).</summary>
        public IReadOnlyList<ConsumeData> Rewards { get; }
        /// <summary>False when the local rules refused before sending (nothing went over the network).</summary>
        public bool Sent { get; }
        public NetworkResult? Network { get; }
    }

    /// <summary>
    /// The screen's entry point: the board (rebuilt when the state changes or a period ends), claim and record calls that check with
    /// the local rules first, and one request at a time. The response is applied by the game's network data binding; the board follows
    /// the container change.
    /// </summary>
    public sealed class QuestClient : IDisposable
    {
        private readonly QuestRules _rules;
        private readonly QuestStateContainer _state;
        private readonly Func<QuestCall, NetworkRequest> _createRequest;
        private readonly Func<long> _now;
        private readonly Func<string, bool> _isOpen;
        private readonly string[] _dataKeys;
        private readonly Func<NetworkRequest, CancellationToken, Task<NetworkResult>> _send;
        private QuestBoard _board;
        private bool _busy, _disposed;

        /// <param name="grantKeys">Repository keys the claim rewards change (for example "wealthInfos").</param>
        public QuestClient(QuestRules rules, QuestStateContainer state, Func<QuestCall, NetworkRequest> createRequest, Func<long> nowUtcMs,
            Func<string, bool> isOpen = null, params string[] grantKeys)
            : this(rules, state, createRequest, nowUtcMs, isOpen, grantKeys, null) { }

        internal QuestClient(QuestRules rules, QuestStateContainer state, Func<QuestCall, NetworkRequest> createRequest, Func<long> nowUtcMs,
            Func<string, bool> isOpen, string[] grantKeys, Func<NetworkRequest, CancellationToken, Task<NetworkResult>> send)
        {
            _rules = rules ?? throw new ArgumentNullException(nameof(rules));
            _state = state ?? throw new ArgumentNullException(nameof(state));
            _createRequest = createRequest ?? throw new ArgumentNullException(nameof(createRequest));
            _now = nowUtcMs ?? throw new ArgumentNullException(nameof(nowUtcMs));
            _isOpen = isOpen;
            _dataKeys = new[] { state.DataKey }.Concat(grantKeys ?? Array.Empty<string>()).Where(k => !string.IsNullOrWhiteSpace(k)).Distinct().ToArray();
            _send = send ?? ((request, token) => NetworkManager.PostAsync(request, token));
            _state.Changed += OnStateChanged;
        }

        /// <summary>Raised with the new board when the state changes or <see cref="Refresh"/> is called.</summary>
        public event Action<QuestBoard> BoardChanged;

        /// <summary>A claim or record request is running.</summary>
        public bool IsBusy => _busy;

        /// <summary>The current board. Rebuilt when the state changed or a period boundary passed.</summary>
        public QuestBoard Board
        {
            get
            {
                if (_board == null || _now() >= _board.NextResetMs) _board = _rules.Board(_state.Current, _now(), _isOpen);
                return _board;
            }
        }

        /// <summary>Rebuilds the board and raises <see cref="BoardChanged"/>. Call it when an open key changes or at <see cref="QuestBoard.NextResetMs"/>.</summary>
        public void Refresh()
        {
            _board = null;
            BoardChanged?.Invoke(Board);
        }

        private void OnStateChanged(ContainerChange change) { if (!_disposed) Refresh(); }

        /// <summary>
        /// Claims a target. The local rules check it first; a refusal returns its code without sending. While another call runs this
        /// returns <see cref="QuestCodes.Busy"/>.
        /// </summary>
        public Task<QuestOutcome> ClaimAsync(QuestClaimTarget target, CancellationToken cancellationToken = default)
        {
            QuestClaimResult preview = _rules.Claim(_state.Current, target, _now(), _isOpen);
            return Send(preview.Ok ? null : preview.Code, QuestCall.ClaimName, target.ToParameters(), cancellationToken);
        }

        /// <summary>Sends client progress (clear types the game registered with <see cref="QuestSource.Client"/>).</summary>
        public Task<QuestOutcome> RecordAsync(IReadOnlyList<QuestEvent> events, CancellationToken cancellationToken = default)
        {
            QuestRecordResult preview = _rules.Record(_state.Current, events, _now(), QuestSource.Client, _isOpen);
            var parameters = new Dictionary<string, object>(StringComparer.Ordinal);
            if (preview.Ok) parameters["ev"] = QuestLocalHandler.WriteEvents(events);
            return Send(preview.Ok ? null : preview.Code, QuestCall.RecordName, parameters, cancellationToken);
        }

        private async Task<QuestOutcome> Send(string refused, string name, Dictionary<string, object> parameters, CancellationToken cancellationToken)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(QuestClient));
            if (_busy) return new QuestOutcome(QuestCodes.Busy, null, false, null);
            if (refused != null) return new QuestOutcome(refused, null, false, null);
            NetworkRequest request = _createRequest(new QuestCall(name, parameters, _dataKeys));
            if (request == null) throw new InvalidOperationException("The request factory returned null for " + name);
            if (request.Name != name) throw new InvalidOperationException("The request factory must keep the name " + name + ", not " + request.Name);
            string missing = _dataKeys.FirstOrDefault(k => !request.DataKeys.Contains(k));
            if (missing != null) throw new InvalidOperationException("The request for " + name + " must list " + missing + " in DataKeys.");
            _busy = true;
            try
            {
                NetworkResult result = await _send(request, cancellationToken);
                if (!result.Success) return new QuestOutcome(string.IsNullOrEmpty(result.ServerErrorCode) ? QuestCodes.Network : result.ServerErrorCode, null, true, result);
                return new QuestOutcome(null, ReadRewards(result.Data), true, result);
            }
            finally { _busy = false; }
        }

        private static IReadOnlyList<ConsumeData> ReadRewards(JObject data)
        {
            if (!(data?[QuestLocalHandler.RewardsKey] is JArray array)) return Array.Empty<ConsumeData>();
            return array.OfType<JObject>().Select(o => new ConsumeData(o)).ToArray();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _state.Changed -= OnStateChanged;
        }
    }
}
