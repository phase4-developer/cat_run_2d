# JJEvol Quest

`com.jjevol.quest@0.1.0-pre.2`는 일일·주간·월간·주기(시즌·이벤트) 퀘스트, 포인트 보상 트랙, 업적 단계, 패스, 시작 퀘스트, 조건 퀘스트, 무작위로 고르는 퀘스트를 하나의 규칙으로 다루는 패키지다. 진행 기록, 기간과 그룹 회차, 보상 받기, 목록 화면 데이터와 표 검사가 모두 같은 카탈로그를 읽는다. 규칙의 정본은 저장소의 `Docs/FrameworkImprovement/Quest/Rules.md`, 구조를 정한 까닭은 같은 폴더의 `Pre2Design.md`다. pre.1과 호환되지 않는다(열거 번호, 저장 문서, 공개 API).

필수: `com.jjevol.economy@0.1.0-pre.4`, `com.jjevol.tables@0.1.0-pre.3`, `com.jjevol.data@0.1.0-pre.1`, `com.jjevol.platform.network@0.1.0-pre.2`, `com.jjevol.tables.authoring@0.1.0-pre.11`(Editor 검사), Unity Newtonsoft JSON 3.2.2. economy의 전이 의존성 `com.jjevol.save`도 manifest에 함께 적는다.

## 어셈블리

| 어셈블리 | 내용 |
|---|---|
| `JJEvol.Quest.Runtime` | 표 행, 카탈로그·검사, 기간 키, 상태와 JSON, 규칙(`QuestRules`), 화면 데이터(`QuestBoard`), `QuestStateContainer`, `WealthQuestGrantWriter` |
| `JJEvol.Quest.Network` | 화면 진입점 `QuestClient`, 로컬 경로 `QuestLocalService`(로컬 서비스 장식)와 `QuestLocalHandler` |
| `JJEvol.Quest.Editor` | 표 스키마 `QuestTableAuthoring.Schemas`와 빌드 검사 `Check`/`Validate` |

## 표

| 표 | 행 | 주요 열 |
|---|---|---|
| `440_questGroup` | 그룹 | `tab`, `periodType`(0 없음·2 일·4 주·8 월·16 주기), `cycleKey`, `groupType`(1 목록·2 단계·3 트랙), `progressScope`(1 평생·2 회차·3 기간), `premium`, `requireGroupId`, `selectionCount`, `autoClaim`, `completeReward*`, `openKey` |
| `441_quest` | 퀘스트 | `questGroupId`, `clearType`, `clearCondition`, `clearValue`, `clearValueStep`(반복), `step`, `reward*` |
| `442_passQuest` | 패스 단계 | 위 + `premiumReward*`, `step` 필수 |
| `443_achievement` | 업적 단계 | 위, `step` 필수 |

코드 값은 위 enum이 정본이다. 다른 표 이름·열 이름·번호를 쓰는 운영 중 게임은 `QuestTableLayout`(그룹 표, 행 표 목록, 그룹 키 열, 그룹 열, 단계 열, 값 변환)으로 바꿔 읽는다. 사람용 `name` 열은 tables.authoring이 공통으로 받으므로 스키마에 없다.

## 시작

```csharp
// clearType은 게임이 등록한다. 숫자와 뜻은 게임 것이다.
var kinds = new QuestKindRegistry()
    .Add(1, QuestAggregate.Add, usesCondition: false)                       // 판 수
    .Add(2, QuestAggregate.Max, usesCondition: false)                       // 최고 점수
    .Add(3, QuestAggregate.Add, usesCondition: true)                        // 아이템 강화(조건 = 아이템 종류)
    .Add(9, QuestAggregate.Add, usesCondition: false, QuestSource.Server)   // 결제처럼 클라이언트가 보고하면 안 되는 것
    .AddPoint(20, new ConsumeTypeId(300));                                  // 일일 포인트: clearType 20 = consume 300
var rewards = new QuestRewardPolicy(wealthType);                             // 바로 지급할 수 있는 소모 종류. 유료 활성은 500
var period = new QuestPeriodSettings(resetHourUtc: 15)                       // 한국 0시 초기화
    .AddCycle("season", seasons.IdAt, seasons.EndsAt);                       // 주기 그룹(periodType 16)

QuestCatalog catalog = QuestCatalog.Build(tableSource, kinds, rewards, period, out var issues);
if (issues.Any(i => i.Severity == QuestIssueSeverity.Error)) throw new InvalidDataException(string.Join("\n", issues));
var rules = new QuestRules(catalog, kinds, rewards, period);
```

## 연결(로컬 경로)

```csharp
repository.Register(quests = new QuestStateContainer());          // 키 "questState"
var handler = new QuestLocalHandler(rules, quests, new WealthQuestGrantWriter(resources), clock.UtcNowMs, unlocks.IsOpen);
NetworkManager.SetLocalService(new QuestLocalService(handler, gameLocalService)
    .Progress("run.end", (call, response) => RunEvents(call))      // 판 종료 응답에 진행을 함께 싣는다
    .Rewards("pass.buy", (call, response) => PaidItems(response))); // 퀘스트 밖에서 준 포인트·유료 활성
```

`quest.record`·`quest.claim`은 `QuestLocalService`가 처리하고, 나머지 요청은 게임 서비스가 처리한 뒤 진행·보상을 같은 응답에 붙인다. 진행을 붙이는 요청은 DataKeys에 `questState`(자동 수령이 있으면 지급 키도)를 적어야 하고, 없으면 예외로 알린다. 응답에 이미 퀘스트 상태가 있으면 그 위에 이어 쓰고, 재화 행이 있으면 그 잔액 위에 더한다.

## 화면

```csharp
// 게임의 요청 부모 클래스로 퀘스트 요청을 만든다. 이름·파라미터·DataKeys를 그대로 쓴다.
var client = new QuestClient(rules, quests, call => new GameQuestRequest(call), clock.UtcNowMs, unlocks.IsOpen, "wealthInfos");
client.BoardChanged += Draw;                                   // 상태가 바뀌거나 Refresh 할 때
Draw(client.Board);                                             // 다음 초기화 시각이 지나면 스스로 다시 만든다

QuestOutcome got = await client.ClaimAsync(QuestClaimTarget.Tab(1));
if (got.Ok) popup.Show(got.Rewards);
else if (got.Sent) ShowError(got.Code);                         // 보내기 전 거절(got.Sent == false)은 요청 없이 코드만
```

| 할 일 | API |
|---|---|
| 보상 받기 | `ClaimAsync(QuestClaimTarget.Quest(id[, premium]) / Group(key) / Tab(tab) / Completion(key))`. 로컬 규칙으로 먼저 확인하고, 요청 중에는 `quest.busy` |
| 클라이언트 진행 | `RecordAsync(events)`. 서버 전용·포인트 종류는 보내기 전에 거절 |
| 보드 | `Board.Items(tab)`(탭의 열린 그룹 칸을 정렬해 한 줄로), `Board.Group(key)`(상태·끝남·완료 보상·유료), 칸 `State`/`Current`/`Start`/`Target`/`Progress01`/`Remaining`, `NextResetMs` |
| 빨간 점 | 칸·그룹의 `HasRedDot`, `Board.HasRedDot(tab)`, `Board.HasRedDotAny` |

빨간 점은 이 패키지가 계산만 하고 뱃지 패키지에 의존하지 않는다.

## 규칙 직접 쓰기

`QuestRules`는 순수 함수다. 서버 시험 표, 서버 응답 미리보기, 게임이 직접 만든 처리기에서 쓴다.

| 할 일 | API |
|---|---|
| 진행 기록 | `Record(state, events, now, source, isOpen)`. 이벤트 하나라도 틀리면 전부 거절, 상태는 그대로. 자동 수령 그룹은 같은 결과에 수령·지급이 들어 있다 |
| 보상 받기 | `Claim(state, target, now, isOpen)`. `Grants`는 지급할 보상(합산), `Rewards`는 팝업용(포인트 포함) |
| 밖에서 받은 보상 | `ApplyRewards(state, rewards, now, isOpen)`. 포인트 consume과 500(유료 활성)만 반영 |
| 유료 활성 | `ActivatePremium(state, groupKey, now, isOpen)`. 그룹이 열리기 전이어도 회차를 만들어 기록 |
| 굴리기·보드 | `Roll`, `Status`, `IsFinished`, `Board` |

다른 응답 처리기 안에서는 `handler.AppendProgress(response, events)`·`handler.AppendRewards(response, rewards)`를 쓴다. 결과는 null(성공) 또는 거절 코드다.

## 표 검사

```csharp
TableAuthoringOptions.Schemas = existing.Concat(QuestTableAuthoring.Schemas(layout)).ToArray();
TableAuthoringOptions.ValidateTables = inputs => QuestTableAuthoring.Validate(inputs, kinds, rewards, period, layout);
```

`Check`는 모든 문제를 `QuestCatalogIssue`(코드·행 ID·설명)로 돌려준다. 오류가 있으면 게임을 시작하지 않는다.

## 게임이 맡을 일

- clearType 번호와 뜻, 진행을 붙일 요청(`Progress`)과 클라이언트 진행 지점(`RecordAsync`).
- 서버가 있는 게임은 같은 규칙을 서버에 둔다. 이 패키지의 `QuestRules`는 로컬 권한 게임, 받기 전 확인, 서버 시험 기대값에 쓴다.
- 지급할 수 없는 보상 종류(상자, 캐릭터 등)는 `IQuestRewardPolicy`와 `IQuestGrantWriter`를 게임이 구현해 넓힌다.
- 잠금(`openKey` → `isOpen`) 판단, 주기 번호와 끝나는 시각(`AddCycle`), 무작위 선택 씨앗(`QuestState.WithSeed`, 프로필 만들 때).
