using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using jjevol.Quest;

namespace jjevol.Quest.Editor
{
    /// <summary>
    /// Table schemas and the build-time check for the quest tables. A game adds <see cref="Schemas"/> to
    /// <c>TableAuthoringOptions.Schemas</c> and calls <see cref="Validate"/> from its <c>TableAuthoringOptions.ValidateTables</c> callback.
    /// The human <c>name</c> column is accepted by tables.authoring itself (pre.11) and is not declared here.
    /// </summary>
    public static class QuestTableAuthoring
    {
        public static IReadOnlyList<TableSchema> Schemas(QuestTableLayout layout = null)
        {
            layout ??= QuestTableLayout.Default;
            TableColumnRule Req(string name, TableColumnKind kind = TableColumnKind.Int32) => new TableColumnRule(name, kind, required: true);
            TableColumnRule Opt(string name, TableColumnKind kind = TableColumnKind.Int32) => new TableColumnRule(name, kind, required: false);
            TableColumnRule[] Text(params string[] names) => names.Select(n => new TableColumnRule(n, TableColumnKind.Text, required: false)).ToArray();

            TableColumnRule[] RowColumns(bool repeat, bool premium, bool stepRequired)
            {
                var columns = new List<TableColumnRule>
                {
                    new TableColumnRule("id", TableColumnKind.Int32, required: true, unique: true),
                    Req(layout.GroupColumn), Req("clearType"), Req("clearValue", TableColumnKind.Int64),
                    Opt("clearCondition"), stepRequired ? Req(layout.StepColumn) : Opt(layout.StepColumn), Opt("sort"), Opt("active"),
                };
                if (repeat) columns.Add(Opt("clearValueStep", TableColumnKind.Int64));
                columns.AddRange(Text("rewardType", "rewardId", "rewardValue", "nameKey", "descriptionKey"));
                if (premium) columns.AddRange(Text("premiumRewardType", "premiumRewardId", "premiumRewardValue"));
                return columns.ToArray();
            }

            var groupColumns = new List<TableColumnRule>
            {
                new TableColumnRule("id", TableColumnKind.Int32, required: true, unique: true),
                Req("tab"), Req("periodType"), Req("groupType"), Req("progressScope"), Opt("sort"), Opt("active"),
                Opt("premium"), Opt("requireGroupId"), Opt("selectionCount"), Opt("autoClaim"),
            };
            if (layout.GroupKeyColumn != "id") groupColumns.Add(new TableColumnRule(layout.GroupKeyColumn, TableColumnKind.Int32, required: true, unique: true));
            groupColumns.AddRange(Text("openKey", "cycleKey", "nameKey", "descriptionKey", "completeRewardType", "completeRewardId", "completeRewardValue"));

            var schemas = new List<TableSchema> { new TableSchema(layout.GroupTable, groupColumns.ToArray()) };
            foreach (QuestRowSource source in layout.RowTables)
                schemas.Add(new TableSchema(source.Table, RowColumns(repeat: source.Kind == QuestRowKind.Quest, premium: source.Kind == QuestRowKind.Pass,
                    stepRequired: source.Kind != QuestRowKind.Quest)));
            return schemas;
        }

        /// <summary>
        /// Builds the catalog from the tables in a build and returns its issues. Tables that are not in the build are read as empty;
        /// a build without the group table is not checked (empty result).
        /// </summary>
        public static IReadOnlyList<QuestCatalogIssue> Check(IReadOnlyList<TableBuildInput> inputs, QuestKindRegistry kinds, IQuestRewardPolicy rewards,
            QuestPeriodSettings period = null, QuestTableLayout layout = null)
        {
            if (inputs == null) throw new ArgumentNullException(nameof(inputs));
            return Check(name => inputs.FirstOrDefault(i => string.Equals(i.TableName, name, StringComparison.OrdinalIgnoreCase))?.Rows, kinds, rewards, period, layout);
        }

        /// <summary>Same check from rows by table name (null = table not present).</summary>
        public static IReadOnlyList<QuestCatalogIssue> Check(Func<string, IReadOnlyList<TSVRow>> rowsOf, QuestKindRegistry kinds, IQuestRewardPolicy rewards,
            QuestPeriodSettings period = null, QuestTableLayout layout = null)
        {
            if (rowsOf == null) throw new ArgumentNullException(nameof(rowsOf));
            layout ??= QuestTableLayout.Default;
            IReadOnlyList<TSVRow> groupRows = rowsOf(layout.GroupTable);
            if (groupRows == null) return Array.Empty<QuestCatalogIssue>();
            var groups = groupRows.Select(r => new QuestGroupRow(r, layout)).ToArray();
            var rows = new List<QuestRow>();
            foreach (QuestRowSource source in layout.RowTables)
            {
                IReadOnlyList<TSVRow> input = rowsOf(source.Table);
                if (input != null) rows.AddRange(input.Select(r => new QuestRow(r, source.Kind, layout)));
            }
            QuestCatalog.Build(groups, rows, kinds, rewards, period, out IReadOnlyList<QuestCatalogIssue> issues);
            return issues;
        }

        /// <summary><see cref="Check"/> that throws on any error, for <c>TableAuthoringOptions.ValidateTables</c>.</summary>
        public static void Validate(IReadOnlyList<TableBuildInput> inputs, QuestKindRegistry kinds, IQuestRewardPolicy rewards,
            QuestPeriodSettings period = null, QuestTableLayout layout = null)
        {
            QuestCatalogIssue[] errors = Check(inputs, kinds, rewards, period, layout).Where(i => i.Severity == QuestIssueSeverity.Error).ToArray();
            if (errors.Length > 0) throw new InvalidDataException("Quest tables have " + errors.Length + " error(s):\n" + string.Join("\n", errors.Select(e => e.ToString())));
        }
    }
}
