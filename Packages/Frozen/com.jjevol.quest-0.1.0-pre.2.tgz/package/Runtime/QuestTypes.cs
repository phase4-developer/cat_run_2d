using System;
using System.Collections.Generic;
using jjevol;

namespace jjevol.Quest
{
    /// <summary>Period of a quest group. Table codes of the JJEvol quest rules (the values case A already used).</summary>
    public enum QuestPeriod { None = 0, Daily = 2, Weekly = 4, Monthly = 8, Cycle = 16 }

    /// <summary>1 List: every row on its own. 2 Steps: only the current row shows, in order. 3 Track: every row, cumulative thresholds of one counter.</summary>
    public enum QuestGroupType { List = 1, Steps = 2, Track = 3 }

    /// <summary>
    /// Which counter a group reads. 1 Lifetime: the account counter. 2 Run: the group's own counter, counted while its current run is open.
    /// 3 Period: the shared counter of the group's period.
    /// </summary>
    public enum QuestScope { Lifetime = 1, Run = 2, Period = 3 }

    /// <summary>How a recorded amount changes a counter.</summary>
    public enum QuestAggregate { Add = 1, Max = 2, Set = 3 }

    /// <summary>Who may record a clear type. A request from the client cannot record a server-only type.</summary>
    [Flags] public enum QuestSource { Client = 1, Server = 2, Any = Client | Server }

    public enum QuestItemState { InProgress = 0, Claimable = 1, Done = 2 }

    /// <summary>Why a group is or is not open.</summary>
    public enum QuestGroupStatus
    {
        Open = 0,
        /// <summary>The game's open key is closed.</summary>
        Locked = 1,
        /// <summary>The required group's current run is not finished.</summary>
        Waiting = 2,
        /// <summary>A cycle group whose cycle is not running.</summary>
        NoCycle = 3,
    }

    /// <summary>Which table a row came from. It only decides which columns the row takes.</summary>
    public enum QuestRowKind { Quest = 1, Pass = 2, Achievement = 3 }

    /// <summary>One progress report: add, raise or set the counter of a clear type (and its condition).</summary>
    public readonly struct QuestEvent
    {
        public QuestEvent(int type, long amount, int condition = 0) { Type = type; Amount = amount; Condition = condition; }
        public int Type { get; }
        public long Amount { get; }
        public int Condition { get; }
        public override string ToString() => Condition == 0 ? $"{Type}+{Amount}" : $"{Type}:{Condition}+{Amount}";
    }

    /// <summary>Rejection codes. Strings, never numbers.</summary>
    public static class QuestCodes
    {
        public const string NotDone = "quest.notDone";
        public const string AlreadyClaimed = "quest.alreadyClaimed";
        public const string NotCurrentStep = "quest.notCurrentStep";
        public const string Locked = "quest.locked";
        public const string PremiumRequired = "quest.premiumRequired";
        public const string UnsupportedReward = "quest.unsupportedReward";
        public const string Unknown = "quest.unknown";
        public const string BadEvent = "quest.badEvent";
        public const string BadRequest = "quest.badRequest";
        /// <summary>A claim was refused before sending because another request of the same client is running.</summary>
        public const string Busy = "quest.busy";
        /// <summary>The request failed in the network layer (no connection, timeout, maintenance).</summary>
        public const string Network = "quest.network";
    }

    /// <summary>The game's clear types. Only this registry and the game's enum know the numbers.</summary>
    public sealed class QuestKindRegistry
    {
        public sealed class Kind
        {
            internal Kind(int type, QuestAggregate aggregate, bool usesCondition, QuestSource source, ConsumeTypeId? point)
            { Type = type; Aggregate = aggregate; UsesCondition = usesCondition; Source = source; PointConsume = point; }
            public int Type { get; }
            public QuestAggregate Aggregate { get; }
            public bool UsesCondition { get; }
            public QuestSource Source { get; }
            /// <summary>Point counters grow only when a reward of <see cref="PointConsume"/> is claimed or applied, never by a record call.</summary>
            public bool IsPoint => PointConsume.HasValue;
            public ConsumeTypeId? PointConsume { get; }
        }

        private readonly Dictionary<int, Kind> _kinds = new Dictionary<int, Kind>();
        private readonly Dictionary<int, Kind> _points = new Dictionary<int, Kind>();

        public QuestKindRegistry Add(int clearType, QuestAggregate aggregate, bool usesCondition, QuestSource source = QuestSource.Any)
        {
            if (clearType <= 0) throw new ArgumentOutOfRangeException(nameof(clearType), "Clear types start at 1.");
            if (!Enum.IsDefined(typeof(QuestAggregate), aggregate)) throw new ArgumentOutOfRangeException(nameof(aggregate));
            if ((source & QuestSource.Any) == 0 || (source & ~QuestSource.Any) != 0) throw new ArgumentOutOfRangeException(nameof(source));
            Put(new Kind(clearType, aggregate, usesCondition, source, null));
            return this;
        }

        /// <summary>A point counter: rewards of <paramref name="pointConsume"/> add to counter <paramref name="clearType"/>.</summary>
        public QuestKindRegistry AddPoint(int clearType, ConsumeTypeId pointConsume)
        {
            if (clearType <= 0) throw new ArgumentOutOfRangeException(nameof(clearType), "Clear types start at 1.");
            if (pointConsume.Value <= 0) throw new ArgumentOutOfRangeException(nameof(pointConsume));
            if (_points.ContainsKey(pointConsume.Value)) throw new ArgumentException("Point consume type registered twice: " + pointConsume.Value);
            var kind = new Kind(clearType, QuestAggregate.Add, false, 0, pointConsume);
            Put(kind);
            _points.Add(pointConsume.Value, kind);
            return this;
        }

        private void Put(Kind kind)
        {
            if (_kinds.ContainsKey(kind.Type)) throw new ArgumentException("Clear type registered twice: " + kind.Type);
            _kinds.Add(kind.Type, kind);
        }

        public bool TryGet(int clearType, out Kind kind) => _kinds.TryGetValue(clearType, out kind);
        /// <summary>The point counter a consume type adds to, or false when the type is not a registered point.</summary>
        public bool TryGetPoint(ConsumeTypeId consume, out Kind kind) => _points.TryGetValue(consume.Value, out kind);
        public IEnumerable<Kind> All => _kinds.Values;
    }

    /// <summary>A named cycle (season, event round): the running cycle id at a time and when it ends.</summary>
    public sealed class QuestCycle
    {
        internal QuestCycle(string key, Func<long, int> idOf, Func<long, long> endsAt) { Key = key; IdOf = idOf; EndsAt = endsAt; }
        public string Key { get; }
        /// <summary>Cycle id at a time (UTC ms). 0 or less means none is running.</summary>
        public Func<long, int> IdOf { get; }
        /// <summary>End of the cycle running at a time (UTC ms), for the screen countdown. Optional.</summary>
        public Func<long, long> EndsAt { get; }
    }

    /// <summary>Reset hour, week start and cycles of the period keys.</summary>
    public sealed class QuestPeriodSettings
    {
        public const string DefaultCycle = "season";
        private readonly Dictionary<string, QuestCycle> _cycles = new Dictionary<string, QuestCycle>(StringComparer.Ordinal);

        /// <param name="resetHourUtc">Hour (UTC, 0-23) a day starts.</param>
        /// <param name="weekStart">First day of a week.</param>
        public QuestPeriodSettings(int resetHourUtc = 0, DayOfWeek weekStart = DayOfWeek.Monday)
        {
            if (resetHourUtc < 0 || resetHourUtc > 23) throw new ArgumentOutOfRangeException(nameof(resetHourUtc));
            if (!Enum.IsDefined(typeof(DayOfWeek), weekStart)) throw new ArgumentOutOfRangeException(nameof(weekStart));
            ResetHourUtc = resetHourUtc; WeekStart = weekStart;
        }

        /// <summary>
        /// Adds a cycle groups name in <c>cycleKey</c>. Returns this. <paramref name="idOf"/> gives the cycle id at a time (0 or less: no cycle
        /// is running). <paramref name="endsAt"/> gives the next time the id changes: the end of the running cycle, or the start of the next
        /// one during a gap. Without it the board cannot see the boundary and the game calls <c>QuestClient.Refresh</c> itself.
        /// </summary>
        public QuestPeriodSettings AddCycle(string key, Func<long, int> idOf, Func<long, long> endsAt = null)
        {
            if (!ValidCycleKey(key)) throw new ArgumentException("Cycle keys are letters, digits and '_'.", nameof(key));
            if (_cycles.ContainsKey(key)) throw new ArgumentException("Cycle added twice: " + key, nameof(key));
            _cycles.Add(key, new QuestCycle(key, idOf ?? throw new ArgumentNullException(nameof(idOf)), endsAt));
            return this;
        }

        /// <summary>Table setting questWeekStart (1 Monday … 7 Sunday) as a <see cref="DayOfWeek"/>.</summary>
        public static DayOfWeek WeekStartFromTable(int isoDay)
        {
            if (isoDay < 1 || isoDay > 7) throw new ArgumentOutOfRangeException(nameof(isoDay), "questWeekStart is 1 (Monday) to 7 (Sunday).");
            return (DayOfWeek)(isoDay % 7);
        }

        internal static bool ValidCycleKey(string key)
        {
            if (string.IsNullOrEmpty(key) || key.Length > 32) return false;
            foreach (char c in key) if (!(c == '_' || (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) return false;
            return true;
        }

        public int ResetHourUtc { get; }
        public DayOfWeek WeekStart { get; }
        public IEnumerable<QuestCycle> Cycles => _cycles.Values;
        public QuestCycle Cycle(string key) => key != null && _cycles.TryGetValue(key, out QuestCycle c) ? c : null;
        public static QuestPeriodSettings Default { get; } = new QuestPeriodSettings();
    }

    /// <summary>What a claim may pay out. Point consume types are known from <see cref="QuestKindRegistry.AddPoint"/>.</summary>
    public interface IQuestRewardPolicy
    {
        /// <summary>Premium activation: the reward's item id is the group key of a premium group.</summary>
        bool IsPremium(ConsumeTypeId type);
        /// <summary>Paid through <see cref="IQuestGrantWriter"/>.</summary>
        bool CanGrant(ConsumeTypeId type);
    }

    /// <summary>Premium activation is consume 500 (JJEvol table spec 5.2) unless set. Everything else must be listed to be paid.</summary>
    public sealed class QuestRewardPolicy : IQuestRewardPolicy
    {
        public const int DefaultPremiumType = 500;
        private readonly HashSet<int> _grantable;
        private readonly int _premium;

        public QuestRewardPolicy(params ConsumeTypeId[] grantable) : this(DefaultPremiumType, grantable) { }

        public QuestRewardPolicy(int premiumType, params ConsumeTypeId[] grantable)
        {
            if (grantable == null) throw new ArgumentNullException(nameof(grantable));
            if (premiumType <= 0) throw new ArgumentOutOfRangeException(nameof(premiumType));
            _premium = premiumType;
            _grantable = new HashSet<int>();
            foreach (ConsumeTypeId type in grantable)
            {
                if (type.Value == premiumType) throw new ArgumentException("Premium activation is not paid out: " + type.Value);
                _grantable.Add(type.Value);
            }
        }

        public bool IsPremium(ConsumeTypeId type) => type.Value == _premium;
        public bool CanGrant(ConsumeTypeId type) => _grantable.Contains(type.Value);
    }

    /// <summary>Writes paid rewards into a response so they are applied and saved together with the quest state.</summary>
    public interface IQuestGrantWriter
    {
        /// <summary>
        /// Adds <paramref name="grants"/> to <paramref name="response"/>. When the response already carries rows this writer owns
        /// (another reward of the same request), add on top of them. Throw <see cref="InvalidOperationException"/> for a reward it cannot pay.
        /// </summary>
        void Write(Newtonsoft.Json.Linq.JObject response, IReadOnlyList<ConsumeData> grants);
    }
}
