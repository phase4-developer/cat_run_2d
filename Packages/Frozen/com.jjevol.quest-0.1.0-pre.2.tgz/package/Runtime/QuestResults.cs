using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Newtonsoft.Json.Linq;
using jjevol;

namespace jjevol.Quest
{
    public enum QuestClaimScope { Quest, Group, Tab, Completion }

    /// <summary>What to claim: one row (free or premium side), every claimable reward of a group or tab, or a group's completion reward.</summary>
    public readonly struct QuestClaimTarget
    {
        private QuestClaimTarget(QuestClaimScope scope, int id, bool premium) { Scope = scope; Id = id; Premium = premium; }
        public QuestClaimScope Scope { get; }
        /// <summary>Row id, group key or tab, by <see cref="Scope"/>.</summary>
        public int Id { get; }
        /// <summary>Only for <see cref="QuestClaimScope.Quest"/> on a premium group's row: the premium reward.</summary>
        public bool Premium { get; }

        public static QuestClaimTarget Quest(int questId, bool premium = false) => new QuestClaimTarget(QuestClaimScope.Quest, questId, premium);
        /// <summary>Every claimable row (both sides when premium is active) and the completion reward of a group.</summary>
        public static QuestClaimTarget Group(int groupKey) => new QuestClaimTarget(QuestClaimScope.Group, groupKey, false);
        public static QuestClaimTarget Tab(int tab) => new QuestClaimTarget(QuestClaimScope.Tab, tab, false);
        public static QuestClaimTarget Completion(int groupKey) => new QuestClaimTarget(QuestClaimScope.Completion, groupKey, false);

        /// <summary>Request parameters: exactly one of <c>id</c> (with optional <c>premium</c>), <c>group</c>, <c>tab</c>, <c>complete</c>.</summary>
        public Dictionary<string, object> ToParameters()
        {
            var p = new Dictionary<string, object>(StringComparer.Ordinal);
            switch (Scope)
            {
                case QuestClaimScope.Quest: p["id"] = Id; if (Premium) p["premium"] = true; break;
                case QuestClaimScope.Group: p["group"] = Id; break;
                case QuestClaimScope.Tab: p["tab"] = Id; break;
                default: p["complete"] = Id; break;
            }
            return p;
        }

        public static QuestClaimTarget From(IReadOnlyDictionary<string, object> parameters)
        {
            if (parameters == null) throw new InvalidDataException("Claim parameters are required.");
            bool hasId = parameters.TryGetValue("id", out object id), hasGroup = parameters.TryGetValue("group", out object group), hasTab = parameters.TryGetValue("tab", out object tab),
                hasComplete = parameters.TryGetValue("complete", out object complete);
            if ((hasId ? 1 : 0) + (hasGroup ? 1 : 0) + (hasTab ? 1 : 0) + (hasComplete ? 1 : 0) != 1) throw new InvalidDataException("Claim needs exactly one of id, group, tab, complete.");
            bool premium = parameters.TryGetValue("premium", out object p) && ToBool(p);
            if (premium && !hasId) throw new InvalidDataException("premium goes with id only.");
            if (hasId) return Quest(ToInt(id, "id"), premium);
            if (hasComplete) return Completion(ToInt(complete, "complete"));
            return hasGroup ? Group(ToInt(group, "group")) : Tab(ToInt(tab, "tab"));
        }

        private static int ToInt(object value, string name)
        {
            JToken token = value as JToken ?? (value == null ? null : JToken.FromObject(value));
            if (token == null || token.Type != JTokenType.Integer) throw new InvalidDataException(name + " must be an integer.");
            long v = token.Value<long>();
            if (v < int.MinValue || v > int.MaxValue) throw new InvalidDataException(name + " is out of range.");
            return (int)v;
        }

        private static bool ToBool(object value)
        {
            JToken token = value as JToken ?? (value == null ? null : JToken.FromObject(value));
            if (token == null || token.Type == JTokenType.Null) return false;
            if (token.Type != JTokenType.Boolean) throw new InvalidDataException("premium must be true or false.");
            return token.Value<bool>();
        }

        public override string ToString() => Scope + " " + Id.ToString(CultureInfo.InvariantCulture) + (Premium ? " premium" : "");
    }

    /// <summary>One claimed reward: a row side, or a group's completion reward (<see cref="QuestId"/> 0).</summary>
    public readonly struct QuestClaimed
    {
        public QuestClaimed(int groupKey, int questId, bool premium) { GroupKey = groupKey; QuestId = questId; Premium = premium; }
        public int GroupKey { get; }
        public int QuestId { get; }
        public bool Premium { get; }
        public bool IsCompletion => QuestId == 0;
    }

    /// <summary>Result of a write. A rejected write leaves <see cref="State"/> as the input.</summary>
    public abstract class QuestResult
    {
        internal QuestResult(QuestState state, string code, IReadOnlyList<QuestClaimed> claimed, IReadOnlyList<ConsumeData> grants, IReadOnlyList<ConsumeData> rewards)
        {
            State = state; Code = code;
            Claimed = claimed ?? Array.Empty<QuestClaimed>(); Grants = grants ?? Array.Empty<ConsumeData>(); Rewards = rewards ?? Array.Empty<ConsumeData>();
        }
        public bool Ok => Code == null;
        public string Code { get; }
        public QuestState State { get; }
        /// <summary>Claimed rewards (by claim, or automatically by an autoClaim group).</summary>
        public IReadOnlyList<QuestClaimed> Claimed { get; }
        /// <summary>Rewards to pay through <see cref="IQuestGrantWriter"/>: points and premium activations removed, same type/id summed.</summary>
        public IReadOnlyList<ConsumeData> Grants { get; }
        /// <summary>Every reward of what was claimed (points and premium included), for the reward popup.</summary>
        public IReadOnlyList<ConsumeData> Rewards { get; }
    }

    public sealed class QuestRecordResult : QuestResult
    {
        internal QuestRecordResult(QuestState state, string code, IReadOnlyList<QuestClaimed> claimed = null, IReadOnlyList<ConsumeData> grants = null, IReadOnlyList<ConsumeData> rewards = null)
            : base(state, code, claimed, grants, rewards) { }
    }

    public sealed class QuestClaimResult : QuestResult
    {
        internal QuestClaimResult(QuestState state, string code, IReadOnlyList<QuestClaimed> claimed = null, IReadOnlyList<ConsumeData> grants = null, IReadOnlyList<ConsumeData> rewards = null)
            : base(state, code, claimed, grants, rewards) { }
    }
}
