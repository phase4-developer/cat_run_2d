using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace jjevol.Quest
{
    /// <summary>
    /// State document:
    /// <c>{ seed, cnt: { slot: { period, v:{key:long} } }, groups: { "groupKey": { period, since, v, got, n, pick, premium, paid, fin } } }</c>.
    /// Reading is strict: a wrong shape throws and nothing is applied.
    /// </summary>
    public static class QuestStateJson
    {
        public const string DefaultKey = "questState";
        public const string SeedKey = "seed", CountersKey = "cnt", GroupsKey = "groups";

        public static JObject Write(QuestState state)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            var counters = new JObject();
            foreach (KeyValuePair<string, QuestCounterSlot> pair in state.Counters.OrderBy(p => p.Key, StringComparer.Ordinal))
                counters[pair.Key] = WriteSlot(pair.Value);
            var groups = new JObject();
            foreach (KeyValuePair<int, QuestGroupRun> pair in state.Groups.OrderBy(p => p.Key))
                groups[pair.Key.ToString(CultureInfo.InvariantCulture)] = WriteRun(pair.Value);
            return new JObject { [SeedKey] = state.Seed, [CountersKey] = counters, [GroupsKey] = groups };
        }

        public static JObject WriteSlot(QuestCounterSlot slot) => new JObject { ["period"] = slot.Period, ["v"] = Values(slot.Values) };

        public static JObject WriteRun(QuestGroupRun run)
        {
            var n = new JObject();
            foreach (KeyValuePair<int, int> r in run.Repeats.OrderBy(p => p.Key)) n[r.Key.ToString(CultureInfo.InvariantCulture)] = r.Value;
            return new JObject
            {
                ["period"] = run.Period,
                ["since"] = run.Since,
                ["v"] = Values(run.Values),
                ["got"] = new JArray(run.Claimed),
                ["n"] = n,
                ["pick"] = new JArray(run.Picks),
                ["premium"] = run.Premium,
                ["paid"] = new JArray(run.Paid),
                ["fin"] = run.CompletionClaimed,
            };
        }

        private static JObject Values(IReadOnlyDictionary<string, long> values)
        {
            var o = new JObject();
            foreach (KeyValuePair<string, long> c in values.OrderBy(p => p.Key, StringComparer.Ordinal)) o[c.Key] = c.Value;
            return o;
        }

        /// <summary>Whole state from its document. Unknown keys are an error; missing parts are empty.</summary>
        public static QuestState Read(JObject document)
        {
            if (document == null) throw new InvalidDataException("Quest state must be an object.");
            foreach (JProperty p in document.Properties())
                if (p.Name != SeedKey && p.Name != CountersKey && p.Name != GroupsKey) throw new InvalidDataException("Unknown quest state key: " + p.Name);
            return new QuestState(Int(document[SeedKey], SeedKey), ReadCounters(document[CountersKey]), ReadGroups(document[GroupsKey]));
        }

        /// <summary>The response shape: <c>{ key: document }</c>.</summary>
        public static JObject Response(QuestState state, string key = DefaultKey) => new JObject { [key] = Write(state) };

        internal static IEnumerable<KeyValuePair<string, QuestCounterSlot>> ReadCounters(JToken token)
        {
            var result = new List<KeyValuePair<string, QuestCounterSlot>>();
            if (token == null || token.Type == JTokenType.Null) return result;
            if (!(token is JObject o)) throw new InvalidDataException("cnt must be an object.");
            foreach (JProperty p in o.Properties())
            {
                if (!QuestPeriods.TryParseSlot(p.Name, out _, out _)) throw new InvalidDataException("Unknown counter slot: " + p.Name);
                string name = "cnt." + p.Name;
                if (!(p.Value is JObject slot)) throw new InvalidDataException(name + " must be an object.");
                Only(slot, name, "period", "v");
                int period = Required(slot["period"], name + ".period");
                if (p.Name == QuestPeriods.Lifetime ? period != 0 : period < 0) throw new InvalidDataException(name + ".period is out of range: " + period);
                result.Add(new KeyValuePair<string, QuestCounterSlot>(p.Name, new QuestCounterSlot(period, ReadValues(slot["v"], name + ".v"))));
            }
            return result;
        }

        internal static IEnumerable<KeyValuePair<int, QuestGroupRun>> ReadGroups(JToken token)
        {
            var result = new List<KeyValuePair<int, QuestGroupRun>>();
            if (token == null || token.Type == JTokenType.Null) return result;
            if (!(token is JObject o)) throw new InvalidDataException("groups must be an object.");
            foreach (JProperty p in o.Properties())
                result.Add(new KeyValuePair<int, QuestGroupRun>(Id(p.Name, "groups"), ReadRun(p.Value, "groups." + p.Name)));
            return result;
        }

        internal static QuestGroupRun ReadRun(JToken token, string name)
        {
            if (!(token is JObject o)) throw new InvalidDataException(name + " must be an object.");
            Only(o, name, "period", "since", "v", "got", "n", "pick", "premium", "paid", "fin");
            var repeats = new Dictionary<int, int>();
            if (o["n"] != null && o["n"].Type != JTokenType.Null)
            {
                if (!(o["n"] is JObject n)) throw new InvalidDataException(name + ".n must be an object.");
                foreach (JProperty r in n.Properties())
                {
                    int count = Required(r.Value, name + ".n." + r.Name);
                    if (count < 0) throw new InvalidDataException(name + ".n is negative: " + r.Name);
                    repeats.Add(Id(r.Name, name + ".n"), count);
                }
            }
            long since = Long(o["since"], name + ".since");
            if (since < 0) throw new InvalidDataException(name + ".since is negative.");
            return new QuestGroupRun(Required(o["period"], name + ".period"), since, ReadValues(o["v"], name + ".v"), Ids(o["got"], name + ".got"), repeats,
                Ids(o["pick"], name + ".pick"), Bool(o["premium"], name + ".premium"), Ids(o["paid"], name + ".paid"), Bool(o["fin"], name + ".fin"));
        }

        private static Dictionary<string, long> ReadValues(JToken token, string name)
        {
            var values = new Dictionary<string, long>(StringComparer.Ordinal);
            if (token == null || token.Type == JTokenType.Null) return values;
            if (!(token is JObject o)) throw new InvalidDataException(name + " must be an object.");
            foreach (JProperty c in o.Properties())
            {
                if (!ValidCounterKey(c.Name)) throw new InvalidDataException(name + " has a bad key: " + c.Name);
                long v = Long(c.Value, name + "." + c.Name);
                if (v < 0) throw new InvalidDataException(name + " is negative: " + c.Name);
                values.Add(c.Name, v);
            }
            return values;
        }

        private static void Only(JObject o, string name, params string[] keys)
        {
            foreach (JProperty p in o.Properties())
                if (Array.IndexOf(keys, p.Name) < 0) throw new InvalidDataException(name + " has an unknown key: " + p.Name);
        }

        /// <summary>Only keys the rules write: "{type}" or "{type}:{condition}", positive numbers without leading zeros.</summary>
        private static bool ValidCounterKey(string key)
        {
            string[] parts = key.Split(':');
            if (parts.Length > 2) return false;
            if (!int.TryParse(parts[0], NumberStyles.None, CultureInfo.InvariantCulture, out int type) || type <= 0) return false;
            int condition = 0;
            if (parts.Length == 2 && (!int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out condition) || condition <= 0)) return false;
            return QuestCounters.Key(type, condition) == key;
        }

        private static int Id(string text, string name)
        {
            if (!int.TryParse(text, NumberStyles.None, CultureInfo.InvariantCulture, out int id) || id.ToString(CultureInfo.InvariantCulture) != text)
                throw new InvalidDataException(name + " has a bad id: " + text);
            return id;
        }

        private static int Required(JToken token, string name)
        {
            if (token == null || token.Type == JTokenType.Null) throw new InvalidDataException(name + " is required.");
            return Int(token, name);
        }

        private static int[] Ids(JToken token, string name)
        {
            if (token == null || token.Type == JTokenType.Null) return Array.Empty<int>();
            if (!(token is JArray array)) throw new InvalidDataException(name + " must be an array.");
            int[] ids = array.Select(t => Int(t, name)).ToArray();
            if (ids.Distinct().Count() != ids.Length) throw new InvalidDataException(name + " repeats an id.");
            return ids;
        }

        private static bool Bool(JToken token, string name)
        {
            if (token == null || token.Type == JTokenType.Null) return false;
            if (token.Type != JTokenType.Boolean) throw new InvalidDataException(name + " must be true or false.");
            return token.Value<bool>();
        }

        private static int Int(JToken token, string name)
        {
            if (token == null || token.Type == JTokenType.Null) return 0;
            if (token.Type != JTokenType.Integer) throw new InvalidDataException(name + " must be an integer.");
            long v = token.Value<long>();
            if (v < int.MinValue || v > int.MaxValue) throw new InvalidDataException(name + " is out of range.");
            return (int)v;
        }

        private static long Long(JToken token, string name)
        {
            if (token == null || token.Type != JTokenType.Integer) throw new InvalidDataException(name + " must be an integer.");
            try { return token.Value<long>(); }
            catch (OverflowException) { throw new InvalidDataException(name + " is out of range."); }
        }
    }
}
