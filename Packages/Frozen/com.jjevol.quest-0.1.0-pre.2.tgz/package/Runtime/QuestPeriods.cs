using System;
using System.Globalization;

namespace jjevol.Quest
{
    /// <summary>Period keys and boundaries. All times are UTC milliseconds; a day starts at the reset hour.</summary>
    public static class QuestPeriods
    {
        public const string Lifetime = "lifetime", Daily = "daily", Weekly = "weekly", Monthly = "monthly", CyclePrefix = "cycle.";
        private const long HourMs = 3_600_000L;

        /// <summary>Shared counter slot name in the state document: lifetime, daily, weekly, monthly or cycle.{key}.</summary>
        public static string SlotName(QuestPeriod period, string cycleKey = null) => period switch
        {
            QuestPeriod.None => Lifetime,
            QuestPeriod.Daily => Daily,
            QuestPeriod.Weekly => Weekly,
            QuestPeriod.Monthly => Monthly,
            QuestPeriod.Cycle => QuestPeriodSettings.ValidCycleKey(cycleKey) ? CyclePrefix + cycleKey : throw new ArgumentException("A cycle slot needs a cycle key.", nameof(cycleKey)),
            _ => throw new ArgumentOutOfRangeException(nameof(period)),
        };

        /// <summary>Parses a slot name back to its period and cycle key.</summary>
        public static bool TryParseSlot(string name, out QuestPeriod period, out string cycleKey)
        {
            cycleKey = "";
            switch (name)
            {
                case Lifetime: period = QuestPeriod.None; return true;
                case Daily: period = QuestPeriod.Daily; return true;
                case Weekly: period = QuestPeriod.Weekly; return true;
                case Monthly: period = QuestPeriod.Monthly; return true;
            }
            period = QuestPeriod.None;
            if (name == null || !name.StartsWith(CyclePrefix, StringComparison.Ordinal)) return false;
            string key = name.Substring(CyclePrefix.Length);
            if (!QuestPeriodSettings.ValidCycleKey(key)) return false;
            period = QuestPeriod.Cycle; cycleKey = key;
            return true;
        }

        /// <summary>
        /// Lifetime 0, day yyyyMMdd, week = its first day yyyyMMdd, month yyyyMM, cycle = running cycle id (0 when none or not configured).
        /// </summary>
        public static int Key(QuestPeriod period, string cycleKey, long nowUtcMs, QuestPeriodSettings settings)
        {
            settings ??= QuestPeriodSettings.Default;
            if (period == QuestPeriod.None) return 0;
            if (period == QuestPeriod.Cycle) return Math.Max(0, settings.Cycle(cycleKey)?.IdOf(nowUtcMs) ?? 0);
            DateTime day = GameDay(nowUtcMs, settings);
            switch (period)
            {
                case QuestPeriod.Daily: return DateKey(day);
                case QuestPeriod.Weekly: return DateKey(WeekStart(day, settings.WeekStart));
                case QuestPeriod.Monthly: return day.Year * 100 + day.Month;
                default: throw new ArgumentOutOfRangeException(nameof(period));
            }
        }

        /// <summary>Next boundary after <paramref name="nowUtcMs"/>, or <see cref="long.MaxValue"/> when the period never resets or its end is unknown.</summary>
        public static long NextReset(QuestPeriod period, string cycleKey, long nowUtcMs, QuestPeriodSettings settings)
        {
            settings ??= QuestPeriodSettings.Default;
            if (period == QuestPeriod.None) return long.MaxValue;
            if (period == QuestPeriod.Cycle)
            {
                long end = settings.Cycle(cycleKey)?.EndsAt?.Invoke(nowUtcMs) ?? long.MaxValue;
                return end > nowUtcMs ? end : long.MaxValue;
            }
            DateTime day = GameDay(nowUtcMs, settings);
            DateTime next;
            switch (period)
            {
                case QuestPeriod.Daily: next = day.AddDays(1); break;
                case QuestPeriod.Weekly: next = WeekStart(day, settings.WeekStart).AddDays(7); break;
                case QuestPeriod.Monthly: next = new DateTime(day.Year, day.Month, 1, 0, 0, 0, DateTimeKind.Utc).AddMonths(1); break;
                default: throw new ArgumentOutOfRangeException(nameof(period));
            }
            return ToMs(next) + settings.ResetHourUtc * HourMs;
        }

        private static DateTime GameDay(long nowUtcMs, QuestPeriodSettings settings)
        {
            DateTime shifted = DateTimeOffset.FromUnixTimeMilliseconds(nowUtcMs - settings.ResetHourUtc * HourMs).UtcDateTime;
            return new DateTime(shifted.Year, shifted.Month, shifted.Day, 0, 0, 0, DateTimeKind.Utc);
        }

        private static DateTime WeekStart(DateTime day, DayOfWeek start) => day.AddDays(-(((int)day.DayOfWeek - (int)start + 7) % 7));
        private static int DateKey(DateTime d) => d.Year * 10000 + d.Month * 100 + d.Day;
        private static long ToMs(DateTime utc) => new DateTimeOffset(utc, TimeSpan.Zero).ToUnixTimeMilliseconds();

        /// <summary>For logs: "20261110 (daily)".</summary>
        public static string Describe(string slot, int key) => key.ToString(CultureInfo.InvariantCulture) + " (" + slot + ")";
    }
}
