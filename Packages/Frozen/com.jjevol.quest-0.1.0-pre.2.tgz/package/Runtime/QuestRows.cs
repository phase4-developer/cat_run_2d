using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using jjevol;

namespace jjevol.Quest
{
    /// <summary>One row table: its name and which columns its rows take.</summary>
    public sealed class QuestRowSource
    {
        public QuestRowSource(string table, QuestRowKind kind)
        {
            Table = string.IsNullOrWhiteSpace(table) ? throw new ArgumentException("Table name is required.", nameof(table)) : table;
            if (!Enum.IsDefined(typeof(QuestRowKind), kind)) throw new ArgumentOutOfRangeException(nameof(kind));
            Kind = kind;
        }
        public string Table { get; }
        public QuestRowKind Kind { get; }
    }

    /// <summary>
    /// Table names, key columns and value conversions. The defaults are the JJEvol quest rules.
    /// A running game whose tables keep other names or codes passes its own layout (table spec 2, "전환 표 선언").
    /// </summary>
    public sealed class QuestTableLayout
    {
        public string GroupTable { get; set; } = "440_questGroup";
        /// <summary>Row tables, read in this order. Ids must not repeat across them.</summary>
        public IReadOnlyList<QuestRowSource> RowTables { get; set; } = new[]
        {
            new QuestRowSource("441_quest", QuestRowKind.Quest),
            new QuestRowSource("442_passQuest", QuestRowKind.Pass),
            new QuestRowSource("443_achievement", QuestRowKind.Achievement),
        };
        /// <summary>Group table column that is the group key (default the row id).</summary>
        public string GroupKeyColumn { get; set; } = "id";
        /// <summary>Row table column that holds the group key.</summary>
        public string GroupColumn { get; set; } = "questGroupId";
        /// <summary>Row table column that holds the step number.</summary>
        public string StepColumn { get; set; } = "step";
        /// <summary>Converts a stored periodType code to <see cref="QuestPeriod"/> values.</summary>
        public Func<int, int> Period { get; set; } = v => v;
        public Func<int, int> GroupType { get; set; } = v => v;
        public Func<int, int> Scope { get; set; } = v => v;
        public static QuestTableLayout Default => new QuestTableLayout();
    }

    /// <summary>One row of the group table.</summary>
    public sealed class QuestGroupRow : TableData
    {
        public QuestGroupRow(TSVRow row) : this(row, QuestTableLayout.Default) { }
        public QuestGroupRow(TSVRow row, QuestTableLayout layout) : base(row)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            layout ??= QuestTableLayout.Default;
            Key = layout.GroupKeyColumn == "id" ? id : row.GetInt(layout.GroupKeyColumn);
            Tab = row.GetInt("tab");
            Period = (QuestPeriod)layout.Period(row.GetInt("periodType"));
            GroupType = (QuestGroupType)layout.GroupType(row.GetInt("groupType"));
            Scope = (QuestScope)layout.Scope(row.GetInt("progressScope"));
            Active = QuestTsv.ReadActive(row);
            OpenKey = row.Get("openKey")?.Trim() ?? "";
            CycleKey = Period == QuestPeriod.Cycle ? (string.IsNullOrWhiteSpace(row.Get("cycleKey")) ? QuestPeriodSettings.DefaultCycle : row.Get("cycleKey").Trim()) : "";
            Premium = row.GetInt("premium") != 0;
            RequireGroup = row.GetInt("requireGroupId");
            SelectionCount = row.GetInt("selectionCount");
            AutoClaim = row.GetInt("autoClaim") != 0;
            CompleteRewards = QuestTsv.ReadConsume(row, "completeReward");
            HasOwnNameKey = !string.IsNullOrEmpty(row.Get("nameKey"));
        }

        /// <summary>For tests and code-built catalogs. The key is the id.</summary>
        public QuestGroupRow(int id, int tab, QuestPeriod period, QuestGroupType groupType, QuestScope scope, int sort = 0, bool active = true,
            string openKey = "", string cycleKey = null, bool premium = false, int requireGroup = 0, int selectionCount = 0, bool autoClaim = false,
            IReadOnlyList<ConsumeData> completeRewards = null)
        {
            this.id = id; this.sort = sort == 0 ? id : sort; Key = id;
            Tab = tab; Period = period; GroupType = groupType; Scope = scope; Active = active; OpenKey = openKey ?? "";
            CycleKey = period == QuestPeriod.Cycle ? cycleKey ?? QuestPeriodSettings.DefaultCycle : "";
            Premium = premium; RequireGroup = requireGroup; SelectionCount = selectionCount; AutoClaim = autoClaim;
            CompleteRewards = completeRewards ?? Array.Empty<ConsumeData>();
        }

        /// <summary>The group key rows point at (the id unless the layout names another column).</summary>
        public int Key { get; }
        /// <summary>Screen grouping only; the rules never read it.</summary>
        public int Tab { get; }
        public QuestPeriod Period { get; }
        public QuestGroupType GroupType { get; }
        public QuestScope Scope { get; }
        public bool Active { get; }
        public string OpenKey { get; }
        /// <summary>Cycle name of a cycle group, empty otherwise.</summary>
        public string CycleKey { get; }
        /// <summary>Rows may carry a premium side, opened by a premium activation.</summary>
        public bool Premium { get; }
        /// <summary>Key of the group whose current run must be finished first; 0 for none.</summary>
        public int RequireGroup { get; }
        /// <summary>Rows picked per run; 0 for every row.</summary>
        public int SelectionCount { get; }
        /// <summary>Rows are claimed in the write that completes them.</summary>
        public bool AutoClaim { get; }
        /// <summary>Paid once the run is finished (every picked one-shot row claimed).</summary>
        public IReadOnlyList<ConsumeData> CompleteRewards { get; }
        /// <summary>True when the TSV cell nameKey had a value (TableData fills an empty one with the id).</summary>
        public bool HasOwnNameKey { get; }
        public bool HasCompletion => CompleteRewards.Count > 0;
        /// <summary>Counter slot name of a lifetime- or period-scope group (null for run scope, and for a period or cycle key the catalog reports).</summary>
        public string SharedSlot
        {
            get
            {
                if (Scope == QuestScope.Lifetime) return QuestPeriods.Lifetime;
                if (Scope != QuestScope.Period || Period == QuestPeriod.None || !Enum.IsDefined(typeof(QuestPeriod), Period)) return null;
                if (Period == QuestPeriod.Cycle && !QuestPeriodSettings.ValidCycleKey(CycleKey)) return null;
                return QuestPeriods.SlotName(Period, CycleKey);
            }
        }
    }

    /// <summary>One row of a quest, pass or achievement table.</summary>
    public sealed class QuestRow : TableData
    {
        public QuestRow(TSVRow row, QuestRowKind kind) : this(row, kind, QuestTableLayout.Default) { }
        public QuestRow(TSVRow row, QuestRowKind kind, QuestTableLayout layout) : base(row)
        {
            if (row == null) throw new ArgumentNullException(nameof(row));
            layout ??= QuestTableLayout.Default;
            Kind = kind;
            Group = row.GetInt(layout.GroupColumn);
            ClearType = row.GetInt("clearType");
            ClearCondition = row.GetInt("clearCondition");
            ClearValue = row.GetLong("clearValue");
            ClearValueStep = kind == QuestRowKind.Quest ? row.GetLong("clearValueStep") : 0;
            Step = row.GetInt(layout.StepColumn);
            Active = QuestTsv.ReadActive(row);
            HasOwnNameKey = !string.IsNullOrEmpty(row.Get("nameKey"));
            Rewards = QuestTsv.ReadConsume(row, "reward");
            PremiumRewards = kind == QuestRowKind.Pass ? QuestTsv.ReadConsume(row, "premiumReward") : Array.Empty<ConsumeData>();
        }

        /// <summary>For tests and code-built catalogs.</summary>
        public QuestRow(int id, QuestRowKind kind, int group, int clearType, long clearValue, int clearCondition = 0, long clearValueStep = 0,
            int step = 0, int sort = 0, bool active = true, IReadOnlyList<ConsumeData> rewards = null, IReadOnlyList<ConsumeData> premiumRewards = null)
        {
            this.id = id; this.sort = sort == 0 ? id : sort;
            Kind = kind; Group = group; ClearType = clearType; ClearValue = clearValue; ClearCondition = clearCondition;
            ClearValueStep = clearValueStep; Step = step; Active = active;
            Rewards = rewards ?? Array.Empty<ConsumeData>();
            PremiumRewards = premiumRewards ?? Array.Empty<ConsumeData>();
        }

        public QuestRowKind Kind { get; }
        /// <summary>Group key.</summary>
        public int Group { get; }
        public int ClearType { get; }
        public int ClearCondition { get; }
        public long ClearValue { get; }
        public long ClearValueStep { get; }
        public int Step { get; }
        public bool Active { get; }
        public bool HasOwnNameKey { get; }
        public IReadOnlyList<ConsumeData> Rewards { get; }
        public IReadOnlyList<ConsumeData> PremiumRewards { get; }
        public bool Repeats => ClearValueStep > 0;

        /// <summary>Target after <paramref name="claimed"/> claims: clearValue + clearValueStep × claimed.</summary>
        public long TargetAfter(int claimed) => ClearValueStep > 0 ? checked(ClearValue + ClearValueStep * claimed) : ClearValue;
        /// <summary>Counter key: "{clearType}" or "{clearType}:{clearCondition}".</summary>
        public string CounterKey => QuestCounters.Key(ClearType, ClearCondition);
    }

    public sealed class QuestGroupTable : IndexedTable<QuestGroupRow>
    {
        private readonly QuestTableLayout _layout;
        public QuestGroupTable(QuestTableLayout layout = null) : base((layout ?? QuestTableLayout.Default).GroupTable) { _layout = layout ?? QuestTableLayout.Default; }
        protected override QuestGroupRow ParseJson(TSVRow data) => new QuestGroupRow(data, _layout);
    }

    /// <summary>Every row table of the layout in one table (ids never repeat across them).</summary>
    public sealed class QuestRowTable : IndexedTable<QuestRow>
    {
        private readonly QuestTableLayout _layout;
        private readonly QuestRowKind _firstKind;

        public QuestRowTable(QuestTableLayout layout = null) : base(First(layout).Table)
        {
            _layout = layout ?? QuestTableLayout.Default;
            _firstKind = First(_layout).Kind;
            foreach (QuestRowSource source in _layout.RowTables.Skip(1))
            {
                QuestRowKind kind = source.Kind;
                AddSource(source.Table, row => new QuestRow(row, kind, _layout));
            }
        }

        private static QuestRowSource First(QuestTableLayout layout)
            => (layout ?? QuestTableLayout.Default).RowTables?.FirstOrDefault() ?? throw new ArgumentException("The layout has no row table.", nameof(layout));

        protected override QuestRow ParseJson(TSVRow data) => new QuestRow(data, _firstKind, _layout);
    }

    internal static class QuestTsv
    {
        /// <summary>0/1 by GetInt; an empty cell is 0. Only a missing column means active (table spec 4).</summary>
        internal static bool ReadActive(TSVRow row) => !row.Contains("active") || row.GetInt("active") != 0;

        /// <summary>
        /// Reads {p}Type/{p}Id/{p}Value (";" lists) or {p}Type_1… numbered cells. All three cells empty means none
        /// (table spec 5); numbered cells stop at the first empty number.
        /// </summary>
        internal static IReadOnlyList<ConsumeData> ReadConsume(TSVRow row, string prefix)
        {
            if (row.Contains(prefix + "Type"))
            {
                if (Blank(row, prefix, "")) return Array.Empty<ConsumeData>();
                row.ImportDatas(out List<ConsumeData> list, prefix + "Type", prefix + "Id", prefix + "Value");
                return list;
            }
            var result = new List<ConsumeData>();
            for (int i = 1; row.Contains(prefix + "Type_" + i) && !Blank(row, prefix, "_" + i); i++)
                result.Add(new ConsumeData(new ConsumeTypeId(Int(row, prefix + "Type_" + i)), Int(row, prefix + "Id_" + i), Long(row, prefix + "Value_" + i)));
            return result;
        }

        private static bool Blank(TSVRow row, string p, string s)
            => string.IsNullOrWhiteSpace(row.Get(p + "Type" + s)) && string.IsNullOrWhiteSpace(row.Get(p + "Id" + s)) && string.IsNullOrWhiteSpace(row.Get(p + "Value" + s));

        private static int Int(TSVRow row, string column)
        {
            string text = row.Get(column)?.Trim();
            if (string.IsNullOrEmpty(text)) return 0;
            if (!int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value)) throw new InvalidDataException($"Not a number in {column}: {text}");
            return value;
        }

        private static long Long(TSVRow row, string column)
        {
            string text = row.Get(column)?.Trim();
            if (string.IsNullOrEmpty(text)) return 0;
            if (!long.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out long value)) throw new InvalidDataException($"Not a number in {column}: {text}");
            return value;
        }
    }
}
