using System;
using System.Collections.Generic;
using System.Linq;
using jjevol;

namespace jjevol.Quest
{
    /// <summary>
    /// What a quest screen draws. Computed from catalog + state + time; never changes the state.
    /// <see cref="HasRedDot"/> on board, group and item is the name a badge (red dot) adapter reads.
    /// </summary>
    public sealed class QuestBoard
    {
        internal QuestBoard(IReadOnlyList<QuestBoardGroup> groups, long nextResetMs)
        {
            Groups = groups; NextResetMs = nextResetMs;
            _dotTabs = new HashSet<int>(groups.Where(g => g.HasRedDot).Select(g => g.Tab));
            _byKey = groups.ToDictionary(g => g.Key);
        }

        private readonly HashSet<int> _dotTabs;
        private readonly Dictionary<int, QuestBoardGroup> _byKey;
        /// <summary>Active groups, sort → id.</summary>
        public IReadOnlyList<QuestBoardGroup> Groups { get; }
        /// <summary>Earliest period boundary of any group; build the board again once time passes it.</summary>
        public long NextResetMs { get; }
        /// <summary>Some open group of the tab has a claimable reward.</summary>
        public bool HasRedDot(int tab) => _dotTabs.Contains(tab);
        /// <summary>Some open group has a claimable reward (the lobby button).</summary>
        public bool HasRedDotAny => _dotTabs.Count > 0;
        public IEnumerable<QuestBoardGroup> InTab(int tab) => Groups.Where(g => g.Tab == tab);
        public QuestBoardGroup Group(int groupKey) => _byKey.TryGetValue(groupKey, out QuestBoardGroup g) ? g : null;
        /// <summary>The first open, unfinished group of a tab in sort order (a chain of starter groups shows one at a time), or null.</summary>
        public QuestBoardGroup Current(int tab) => InTab(tab).FirstOrDefault(g => g.Status == QuestGroupStatus.Open && !g.Finished);

        /// <summary>Items of the open groups of a tab in one list: claimable → in progress → done, then group sort, row sort, id.</summary>
        public IReadOnlyList<QuestBoardItem> Items(int tab)
        {
            var order = Groups.Select((g, i) => (g, i)).ToDictionary(p => p.g.Key, p => p.i);
            return InTab(tab).Where(g => g.Status == QuestGroupStatus.Open).SelectMany(g => g.Items)
                .OrderBy(it => Rank(it.State)).ThenBy(it => order[it.GroupKey]).ThenBy(it => it.Row.sort).ThenBy(it => it.Id).ToArray();
        }

        internal static int Rank(QuestItemState state) => state == QuestItemState.Claimable ? 0 : state == QuestItemState.InProgress ? 1 : 2;
    }

    public sealed class QuestBoardGroup
    {
        internal QuestBoardGroup(QuestGroupRow row, QuestGroupStatus status, QuestGroupRun run, bool finished, int claimedRows, int totalRows,
            QuestItemState? completion, long nextResetMs, IReadOnlyList<QuestBoardItem> items)
        {
            Row = row; Status = status; Run = run; Finished = finished; ClaimedRows = claimedRows; TotalRows = totalRows;
            CompletionState = completion; NextResetMs = nextResetMs; Items = items;
            HasRedDot = status == QuestGroupStatus.Open && (items.Any(i => i.HasRedDot) || completion == QuestItemState.Claimable);
        }

        public QuestGroupRow Row { get; }
        public int Key => Row.Key;
        public int Tab => Row.Tab;
        public QuestGroupType GroupType => Row.GroupType;
        public QuestGroupStatus Status { get; }
        public bool IsOpen => Status == QuestGroupStatus.Open;
        /// <summary>The current run, or null when the group has not opened in this period.</summary>
        public QuestGroupRun Run { get; }
        /// <summary>Every one-shot row claimed and the completion reward (if any) claimed. A finished starter group can be hidden.</summary>
        public bool Finished { get; }
        /// <summary>One-shot rows claimed / shown (repeating rows are not counted). For an "n / N" bar.</summary>
        public int ClaimedRows { get; }
        public int TotalRows { get; }
        /// <summary>State of the completion reward, or null when the group has none.</summary>
        public QuestItemState? CompletionState { get; }
        public IReadOnlyList<ConsumeData> CompletionRewards => Row.CompleteRewards;
        /// <summary>Next reset of this group's period, or long.MaxValue.</summary>
        public long NextResetMs { get; }
        public bool HasPremium => Row.Premium;
        /// <summary>Premium groups: the premium side is active.</summary>
        public bool PremiumActive => Run != null && Run.Premium;
        /// <summary>
        /// List: claimable → in progress → done, then sort → id. Steps: the current step only (the last one when all are done).
        /// Track: every row in step order. Only the picked rows of a selecting group.
        /// </summary>
        public IReadOnlyList<QuestBoardItem> Items { get; }
        public bool HasRedDot { get; }
    }

    public sealed class QuestBoardItem
    {
        internal QuestBoardItem(QuestGroupRow group, QuestRow row, QuestItemState state, long current, long start, long target, int claimedCount,
            QuestItemState premiumState, bool locked)
        {
            GroupKey = group.Key; Row = row; State = state; Current = current; Start = start; Target = target; ClaimedCount = claimedCount; PremiumState = premiumState;
            HasRedDot = !locked && (state == QuestItemState.Claimable || premiumState == QuestItemState.Claimable);
        }

        public int GroupKey { get; }
        public QuestRow Row { get; }
        public int Id => Row.id;
        public int ClearType => Row.ClearType;
        /// <summary>Condition of the clear type (item kind, stage), for the description text.</summary>
        public int Condition => Row.ClearCondition;
        public QuestItemState State { get; }
        /// <summary>Counter value now (not capped).</summary>
        public long Current { get; }
        /// <summary>Bar start: the previous step's target for steps and tracks, the previous target of a repeating row, 0 otherwise.</summary>
        public long Start { get; }
        public long Target { get; }
        /// <summary>Claims so far of a repeating row.</summary>
        public int ClaimedCount { get; }
        /// <summary>Bar fill 0..1 between <see cref="Start"/> and <see cref="Target"/>.</summary>
        public float Progress01 => Target <= Start ? (Current >= Target ? 1f : 0f) : (float)Math.Max(0d, Math.Min(1d, (double)(Current - Start) / (Target - Start)));
        /// <summary>Amount still needed, 0 when reached.</summary>
        public long Remaining => Math.Max(0, Target - Current);
        public bool CanClaim => HasRedDot;
        public IReadOnlyList<ConsumeData> Rewards => Row.Rewards;
        public IReadOnlyList<ConsumeData> PremiumRewards => Row.PremiumRewards;
        /// <summary>Premium side of a premium group's row. <see cref="QuestItemState.InProgress"/> also covers "premium not bought".</summary>
        public QuestItemState PremiumState { get; }
        public bool HasRedDot { get; }
    }
}
