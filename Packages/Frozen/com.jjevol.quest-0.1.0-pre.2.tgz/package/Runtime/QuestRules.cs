using System;
using System.Collections.Generic;
using System.Linq;
using jjevol;

namespace jjevol.Quest
{
    /// <summary>
    /// The quest rules as pure functions: state, events, time and the game's open check in; a new state (and payouts) out.
    /// Every write rolls before and after (the second roll opens groups whose required group just finished).
    /// The same rules serve the local route and are the reference for a server.
    /// </summary>
    public sealed class QuestRules
    {
        /// <summary>Upper bound of claims one request makes (repeating rows can be claimed many times).</summary>
        public const int MaxClaimsPerRequest = 1000;

        private readonly QuestKindRegistry _kinds;
        private readonly IQuestRewardPolicy _rewards;

        public QuestRules(QuestCatalog catalog, QuestKindRegistry kinds, IQuestRewardPolicy rewards, QuestPeriodSettings period = null)
        {
            Catalog = catalog ?? throw new ArgumentNullException(nameof(catalog));
            _kinds = kinds ?? throw new ArgumentNullException(nameof(kinds));
            _rewards = rewards ?? throw new ArgumentNullException(nameof(rewards));
            Period = period ?? QuestPeriodSettings.Default;
        }

        public QuestCatalog Catalog { get; }
        public QuestPeriodSettings Period { get; }

        // ---------------------------------------------------------------- runs

        /// <summary>Why the group is (not) open now. Read on a rolled state.</summary>
        public QuestGroupStatus Status(QuestState state, QuestGroupRow group, long nowUtcMs, Func<string, bool> isOpen = null)
        {
            if (group == null) throw new ArgumentNullException(nameof(group));
            state ??= QuestState.Empty;
            if (!string.IsNullOrEmpty(group.OpenKey) && isOpen != null && !isOpen(group.OpenKey)) return QuestGroupStatus.Locked;
            if (group.Period == QuestPeriod.Cycle && PeriodKey(group, nowUtcMs) == 0) return QuestGroupStatus.NoCycle;
            if (group.RequireGroup != 0)
            {
                QuestGroupRow required = Catalog.Group(group.RequireGroup);
                if (required == null || !IsFinished(required, state.Run(required.Key))) return QuestGroupStatus.Waiting;
            }
            return QuestGroupStatus.Open;
        }

        /// <summary>Every picked one-shot row claimed (free side) and, when the group has one, the completion reward claimed.</summary>
        public bool IsFinished(QuestGroupRow group, QuestGroupRun run)
            => run != null && AllRowsClaimed(group, run) && (!group.HasCompletion || run.CompletionClaimed);

        private bool AllRowsClaimed(QuestGroupRow group, QuestGroupRun run)
            => Catalog.Rows(group.Key).Where(r => !r.Repeats && run.IsPicked(r.id)).All(r => run.IsClaimed(r.id));

        private int PeriodKey(QuestGroupRow g, long now) => QuestPeriods.Key(g.Period, g.CycleKey, now, Period);

        /// <summary>
        /// Brings the state to <paramref name="nowUtcMs"/>: empties shared slots of a past period, drops runs of a past period and starts a run
        /// for every open group that has none. Groups are visited in requirement order. Runs of groups the catalog does not have are kept.
        /// </summary>
        public QuestState Roll(QuestState state, long nowUtcMs, Func<string, bool> isOpen = null)
        {
            QuestState next = state ?? QuestState.Empty;
            foreach (string slot in Catalog.SharedSlots)
            {
                QuestPeriods.TryParseSlot(slot, out QuestPeriod p, out string cycle);
                int key = QuestPeriods.Key(p, cycle, nowUtcMs, Period);
                if (!next.Counters.TryGetValue(slot, out QuestCounterSlot s) || s.Period != key) next = next.With(slot, QuestCounterSlot.Empty(key));
            }
            foreach (QuestGroupRow g in Catalog.RollOrder)
            {
                int key = PeriodKey(g, nowUtcMs);
                QuestGroupRun run = next.Run(g.Key);
                if (run != null && run.Period != key) { next = next.With(g.Key, null); run = null; }
                if (run == null && Status(next, g, nowUtcMs, isOpen) == QuestGroupStatus.Open) next = next.With(g.Key, NewRun(g, key, nowUtcMs, next.Seed));
            }
            return next;
        }

        private QuestGroupRun NewRun(QuestGroupRow g, int key, long now, int seed)
            => new QuestGroupRun(key, now, picks: Pick(g, key, seed));

        /// <summary>The run of a group, started now when it has none for this period (premium bought before the group opened).</summary>
        private QuestGroupRun EnsureRun(QuestState state, QuestGroupRow g, long now)
        {
            int key = PeriodKey(g, now);
            QuestGroupRun run = state.Run(g.Key);
            return run != null && run.Period == key ? run : NewRun(g, key, now, state.Seed);
        }

        /// <summary>Same seed, group and period always pick the same rows, on a server and on the local route.</summary>
        private int[] Pick(QuestGroupRow g, int periodKey, int seed)
        {
            if (g.SelectionCount <= 0) return Array.Empty<int>();
            int[] ids = Catalog.Rows(g.Key).Select(r => r.id).ToArray();
            if (g.SelectionCount >= ids.Length) return Array.Empty<int>();
            ulong x = Mix(Mix(Mix(0x9E3779B97F4A7C15UL ^ (uint)seed) ^ (uint)g.Key) ^ (uint)periodKey);
            for (int i = ids.Length - 1; i > 0; i--)
            {
                x = Mix(x);
                int j = (int)(x % (ulong)(i + 1));
                (ids[i], ids[j]) = (ids[j], ids[i]);
            }
            return ids.Take(g.SelectionCount).ToArray();
        }

        private static ulong Mix(ulong z)
        {
            z += 0x9E3779B97F4A7C15UL;
            z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
            z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
            return z ^ (z >> 31);
        }

        // ---------------------------------------------------------------- counting

        /// <summary>
        /// Records progress. Add needs a positive amount; Max and Set take 0 or more. A point counter, an unknown type,
        /// a type the <paramref name="source"/> may not record or a condition the type does not take rejects the whole call.
        /// Rows of open autoClaim groups that the events complete are claimed in the same result.
        /// </summary>
        public QuestRecordResult Record(QuestState state, IReadOnlyList<QuestEvent> events, long nowUtcMs, QuestSource source, Func<string, bool> isOpen = null)
        {
            state ??= QuestState.Empty;
            if (events == null) return new QuestRecordResult(state, QuestCodes.BadEvent);
            foreach (QuestEvent e in events)
            {
                if (!_kinds.TryGet(e.Type, out QuestKindRegistry.Kind kind) || kind.IsPoint || (kind.Source & source) == 0) return new QuestRecordResult(state, QuestCodes.BadEvent);
                if (e.Condition < 0 || (e.Condition != 0 && !kind.UsesCondition)) return new QuestRecordResult(state, QuestCodes.BadEvent);
                if (kind.Aggregate == QuestAggregate.Add ? e.Amount <= 0 : e.Amount < 0) return new QuestRecordResult(state, QuestCodes.BadEvent);
            }
            QuestState next = Roll(state, nowUtcMs, isOpen);
            foreach (QuestEvent e in events)
            {
                _kinds.TryGet(e.Type, out QuestKindRegistry.Kind kind);
                next = Count(next, kind, e.Condition, e.Amount, nowUtcMs, isOpen);
            }
            var w = new Writes();
            string code = AutoClaim(ref next, nowUtcMs, isOpen, w);
            if (code != null) return new QuestRecordResult(state, code);
            return new QuestRecordResult(Roll(next, nowUtcMs, isOpen), null, w.Claimed.ToArray(), Sum(w.Paid), w.Shown.ToArray());
        }

        /// <summary>
        /// Applies the quest part of rewards paid elsewhere (a purchase, a gacha): point consume types raise their counters and a premium
        /// activation opens its group's premium side. Other types are ignored (their own system pays them). AutoClaim rows follow.
        /// </summary>
        public QuestRecordResult ApplyRewards(QuestState state, IReadOnlyList<ConsumeData> rewards, long nowUtcMs, Func<string, bool> isOpen = null)
        {
            state ??= QuestState.Empty;
            if (rewards == null) return new QuestRecordResult(state, QuestCodes.BadEvent);
            QuestState next = Roll(state, nowUtcMs, isOpen);
            var w = new Writes();
            foreach (ConsumeData r in rewards)
            {
                if (r.Quantity < 0) return new QuestRecordResult(state, QuestCodes.BadEvent);
                if (_kinds.TryGetPoint(r.TypeId, out _) || _rewards.IsPremium(r.TypeId))
                {
                    string code = PayOne(ref next, r, nowUtcMs, isOpen, w);
                    if (code != null) return new QuestRecordResult(state, code);
                }
            }
            string auto = AutoClaim(ref next, nowUtcMs, isOpen, w);
            if (auto != null) return new QuestRecordResult(state, auto);
            return new QuestRecordResult(Roll(next, nowUtcMs, isOpen), null, w.Claimed.ToArray(), Sum(w.Paid), w.Shown.ToArray());
        }

        /// <summary>Adds an amount to every counter that reads the kind: the lifetime, shared slots a group reads, and runs of open run-scope groups.</summary>
        private QuestState Count(QuestState next, QuestKindRegistry.Kind kind, int condition, long amount, long now, Func<string, bool> isOpen)
        {
            string[] keys = condition == 0 ? new[] { QuestCounters.Key(kind.Type, 0) } : new[] { QuestCounters.Key(kind.Type, 0), QuestCounters.Key(kind.Type, condition) };
            foreach (string slotName in Catalog.SharedSlots)
            {
                QuestCounterSlot slot = next.Slot(slotName);
                bool lifetime = slotName == QuestPeriods.Lifetime;
                foreach (string key in keys)
                    // The lifetime keeps every registered counter so rows added later see past progress; period slots keep only what a group reads.
                    if (lifetime || Catalog.SharedReads(slotName, key)) slot = slot.With(key, QuestCounters.Apply(kind.Aggregate, slot.Counter(key), amount));
                next = next.With(slotName, slot);
            }
            foreach (QuestGroupRow g in Catalog.Groups)
            {
                if (g.Scope != QuestScope.Run) continue;
                QuestGroupRun run = next.Run(g.Key);
                if (run == null || Status(next, g, now, isOpen) != QuestGroupStatus.Open) continue;
                QuestGroupRun changed = run;
                foreach (string key in keys)
                    if (Catalog.RunReads(g.Key, key)) changed = changed.WithCounter(key, QuestCounters.Apply(kind.Aggregate, changed.Counter(key), amount));
                if (!ReferenceEquals(changed, run)) next = next.With(g.Key, changed);
            }
            return next;
        }

        private long CounterOf(QuestState state, QuestGroupRow g, QuestGroupRun run, QuestRow row)
            => g.Scope == QuestScope.Run ? run?.Counter(row.CounterKey) ?? 0 : state.Slot(g.SharedSlot).Counter(row.CounterKey);

        // ---------------------------------------------------------------- claiming

        private sealed class Writes
        {
            public readonly List<QuestClaimed> Claimed = new List<QuestClaimed>();
            public readonly List<ConsumeData> Paid = new List<ConsumeData>();
            public readonly List<ConsumeData> Shown = new List<ConsumeData>();
        }

        /// <summary>
        /// Claims one row, a completion reward, or everything claimable (free and, when bought, premium; completion last) of a group or tab.
        /// A tab claim repeats until nothing more opens: points paid by one claim can open a track step, and a finished group can open the next.
        /// </summary>
        public QuestClaimResult Claim(QuestState state, QuestClaimTarget target, long nowUtcMs, Func<string, bool> isOpen = null)
        {
            state ??= QuestState.Empty;
            QuestState next = Roll(state, nowUtcMs, isOpen);
            var w = new Writes();

            if (target.Scope == QuestClaimScope.Quest || target.Scope == QuestClaimScope.Completion)
            {
                QuestRow row = target.Scope == QuestClaimScope.Quest ? Catalog.Row(target.Id) : null;
                if (target.Scope == QuestClaimScope.Quest && row == null) return Fail(state, QuestCodes.Unknown);
                QuestGroupRow g = Catalog.Group(row?.Group ?? target.Id);
                if (g == null || (target.Scope == QuestClaimScope.Completion && !g.HasCompletion)) return Fail(state, QuestCodes.Unknown);
                if (Status(next, g, nowUtcMs, isOpen) != QuestGroupStatus.Open) return Fail(state, QuestCodes.Locked);
                string code = row != null ? TryClaim(ref next, g, row, target.Premium, nowUtcMs, isOpen, w) : TryCompletion(ref next, g, nowUtcMs, isOpen, w);
                if (code != null) return Fail(state, code);
                return Finish(state, next, nowUtcMs, isOpen, w);
            }

            QuestGroupRow[] Targets(QuestState s) => (target.Scope == QuestClaimScope.Group ? Catalog.Groups.Where(g => g.Key == target.Id) : Catalog.Groups.Where(g => g.Tab == target.Id))
                .Where(g => Status(s, g, nowUtcMs, isOpen) == QuestGroupStatus.Open).ToArray();
            bool any = target.Scope == QuestClaimScope.Group ? Catalog.Group(target.Id) != null : Catalog.Groups.Any(g => g.Tab == target.Id);
            if (!any) return Fail(state, QuestCodes.Unknown);
            if (Targets(next).Length == 0) return Fail(state, QuestCodes.Locked);

            for (bool progressed = true; progressed && w.Claimed.Count < MaxClaimsPerRequest;)
            {
                progressed = false;
                foreach (QuestGroupRow g in Targets(next))
                {
                    string code = ClaimAll(ref next, g, nowUtcMs, isOpen, w, MaxClaimsPerRequest, ref progressed);
                    if (code != null) return Fail(state, code);
                }
                next = Roll(next, nowUtcMs, isOpen);
            }
            return w.Claimed.Count == 0 ? Fail(state, QuestCodes.NotDone) : Finish(state, next, nowUtcMs, isOpen, w);
        }

        /// <summary>
        /// Claims everything claimable of one group while fewer than <paramref name="cap"/> claims are written.
        /// Only <see cref="QuestCodes.UnsupportedReward"/> is returned; other refusals just stop.
        /// </summary>
        private string ClaimAll(ref QuestState next, QuestGroupRow g, long now, Func<string, bool> isOpen, Writes w, int cap, ref bool progressed)
        {
            foreach (QuestRow row in Catalog.Rows(g.Key))
                foreach (bool premium in g.Premium ? new[] { false, true } : new[] { false })
                    while (w.Claimed.Count < cap)
                    {
                        QuestState attempt = next;
                        string code = TryClaim(ref attempt, g, row, premium, now, isOpen, w);
                        if (code == QuestCodes.UnsupportedReward) return code;
                        if (code != null) break;
                        next = attempt; progressed = true;
                        if (!row.Repeats) break;
                    }
            if (g.HasCompletion && w.Claimed.Count < cap)
            {
                QuestState attempt = next;
                string code = TryCompletion(ref attempt, g, now, isOpen, w);
                if (code == QuestCodes.UnsupportedReward) return code;
                if (code == null) { next = attempt; progressed = true; }
            }
            return null;
        }

        /// <summary>
        /// Claims what open autoClaim groups completed, until nothing more opens. Not capped: autoClaim groups have one-shot rows only,
        /// and a request that reached <see cref="MaxClaimsPerRequest"/> still pays what it completed.
        /// </summary>
        private string AutoClaim(ref QuestState next, long now, Func<string, bool> isOpen, Writes w)
        {
            if (!Catalog.Groups.Any(g => g.AutoClaim)) return null;
            for (bool progressed = true; progressed;)
            {
                progressed = false;
                next = Roll(next, now, isOpen);
                foreach (QuestGroupRow g in Catalog.Groups)
                {
                    if (!g.AutoClaim || Status(next, g, now, isOpen) != QuestGroupStatus.Open) continue;
                    string code = ClaimAll(ref next, g, now, isOpen, w, int.MaxValue, ref progressed);
                    if (code != null) return code;
                }
            }
            return null;
        }

        private QuestClaimResult Finish(QuestState input, QuestState next, long now, Func<string, bool> isOpen, Writes w)
        {
            string code = AutoClaim(ref next, now, isOpen, w);
            if (code != null) return Fail(input, code);
            return new QuestClaimResult(Roll(next, now, isOpen), null, w.Claimed.ToArray(), Sum(w.Paid), w.Shown.ToArray());
        }

        private string TryClaim(ref QuestState state, QuestGroupRow g, QuestRow row, bool premium, long now, Func<string, bool> isOpen, Writes w)
        {
            QuestGroupRun run = state.Run(g.Key);
            if (run == null) return QuestCodes.Locked;
            if (!run.IsPicked(row.id)) return QuestCodes.Unknown;
            long counter = CounterOf(state, g, run, row);
            IReadOnlyList<ConsumeData> rewards;

            if (premium)
            {
                if (!g.Premium || row.PremiumRewards.Count == 0) return QuestCodes.BadRequest;
                if (run.PaidClaimed(row.id)) return QuestCodes.AlreadyClaimed;
                if (!run.Premium) return QuestCodes.PremiumRequired;
                if (counter < row.ClearValue) return QuestCodes.NotDone;
                run = run.WithPaid(row.id); rewards = row.PremiumRewards;
            }
            else if (g.GroupType == QuestGroupType.Steps)
            {
                if (run.IsClaimed(row.id)) return QuestCodes.AlreadyClaimed;
                QuestRow current = Catalog.Rows(g.Key).FirstOrDefault(r => !run.IsClaimed(r.id));
                if (current == null || current.id != row.id) return QuestCodes.NotCurrentStep;
                if (counter < row.ClearValue) return QuestCodes.NotDone;
                run = run.WithClaim(row.id); rewards = row.Rewards;
            }
            else if (row.Repeats)
            {
                if (counter < row.TargetAfter(run.RepeatCount(row.id))) return QuestCodes.NotDone;
                run = run.WithRepeat(row.id); rewards = row.Rewards;
            }
            else
            {
                if (run.IsClaimed(row.id)) return QuestCodes.AlreadyClaimed;
                if (counter < row.ClearValue) return QuestCodes.NotDone;
                run = run.WithClaim(row.id); rewards = row.Rewards;
            }

            QuestState next = state.With(g.Key, run);
            string code = Pay(ref next, rewards, now, isOpen, w);
            if (code != null) return code;
            w.Claimed.Add(new QuestClaimed(g.Key, row.id, premium));
            state = next;
            return null;
        }

        private string TryCompletion(ref QuestState state, QuestGroupRow g, long now, Func<string, bool> isOpen, Writes w)
        {
            QuestGroupRun run = state.Run(g.Key);
            if (run == null) return QuestCodes.Locked;
            if (!g.HasCompletion) return QuestCodes.Unknown;
            if (run.CompletionClaimed) return QuestCodes.AlreadyClaimed;
            if (!AllRowsClaimed(g, run)) return QuestCodes.NotDone;
            QuestState next = state.With(g.Key, run.WithCompletion());
            string code = Pay(ref next, g.CompleteRewards, now, isOpen, w);
            if (code != null) return code;
            w.Claimed.Add(new QuestClaimed(g.Key, 0, false));
            state = next;
            return null;
        }

        private string Pay(ref QuestState state, IReadOnlyList<ConsumeData> rewards, long now, Func<string, bool> isOpen, Writes w)
        {
            QuestState next = state;
            int paidBefore = w.Paid.Count;
            foreach (ConsumeData reward in rewards)
            {
                string code = PayOne(ref next, reward, now, isOpen, w);
                if (code != null) { w.Paid.RemoveRange(paidBefore, w.Paid.Count - paidBefore); return code; }
            }
            w.Shown.AddRange(rewards.Select(r => new ConsumeData(r.TypeId, r.ItemId, r.Quantity)));
            state = next;
            return null;
        }

        private string PayOne(ref QuestState state, ConsumeData reward, long now, Func<string, bool> isOpen, Writes w)
        {
            if (_kinds.TryGetPoint(reward.TypeId, out QuestKindRegistry.Kind point))
            {
                if (reward.Quantity > 0) state = Count(state, point, 0, reward.Quantity, now, isOpen);
                return null;
            }
            if (_rewards.IsPremium(reward.TypeId))
            {
                QuestGroupRow pg = Catalog.Group(reward.ItemId);
                if (pg == null || !pg.Premium) return QuestCodes.UnsupportedReward;
                if (NoCycle(pg, now)) return QuestCodes.Locked;
                state = state.With(pg.Key, EnsureRun(state, pg, now).WithPremium());
                return null;
            }
            if (!_rewards.CanGrant(reward.TypeId)) return QuestCodes.UnsupportedReward;
            w.Paid.Add(reward);
            return null;
        }

        /// <summary>
        /// Turns on the premium side of a group for its current period (a purchase handler calls this; a claimed or applied reward of the premium
        /// consume type does the same). Returns null when <paramref name="groupKey"/> is not an active premium group, or when it is a cycle
        /// group and no cycle is running (the purchase would be lost when the next cycle starts; the shop must not sell it then).
        /// </summary>
        public QuestState ActivatePremium(QuestState state, int groupKey, long nowUtcMs, Func<string, bool> isOpen = null)
        {
            QuestGroupRow g = Catalog.Group(groupKey);
            if (g == null || !g.Premium || NoCycle(g, nowUtcMs)) return null;
            QuestState next = Roll(state ?? QuestState.Empty, nowUtcMs, isOpen);
            next = next.With(g.Key, EnsureRun(next, g, nowUtcMs).WithPremium());
            return Roll(next, nowUtcMs, isOpen);
        }

        private bool NoCycle(QuestGroupRow g, long now) => g.Period == QuestPeriod.Cycle && PeriodKey(g, now) == 0;

        private static QuestClaimResult Fail(QuestState state, string code) => new QuestClaimResult(state, code);

        private static ConsumeData[] Sum(IEnumerable<ConsumeData> values)
            => values.GroupBy(v => (v.TypeId.Value, v.ItemId)).OrderBy(g => g.Key.Item1).ThenBy(g => g.Key.Item2)
                .Select(g => new ConsumeData(new ConsumeTypeId(g.Key.Item1), g.Key.Item2, g.Aggregate(0L, (s, v) => checked(s + v.Quantity)))).ToArray();

        // ---------------------------------------------------------------- screen

        /// <summary>The screen model. Rolls in memory only; the state is not changed.</summary>
        public QuestBoard Board(QuestState state, long nowUtcMs, Func<string, bool> isOpen = null)
        {
            QuestState s = Roll(state ?? QuestState.Empty, nowUtcMs, isOpen);
            var groups = new List<QuestBoardGroup>();
            long boardReset = long.MaxValue;
            foreach (QuestGroupRow g in Catalog.Groups)
            {
                QuestGroupStatus status = Status(s, g, nowUtcMs, isOpen);
                bool locked = status != QuestGroupStatus.Open;
                QuestGroupRun run = s.Run(g.Key);
                IReadOnlyList<QuestRow> rows = Catalog.Rows(g.Key).Where(r => run?.IsPicked(r.id) ?? g.SelectionCount <= 0).ToArray();
                long Counter(QuestRow r) => CounterOf(s, g, run, r);
                bool Claimed(QuestRow r) => run != null && run.IsClaimed(r.id);
                QuestItemState Plain(QuestRow r, bool claimed) => claimed ? QuestItemState.Done : Counter(r) >= r.ClearValue ? QuestItemState.Claimable : QuestItemState.InProgress;
                var items = new List<QuestBoardItem>();

                if (g.GroupType == QuestGroupType.Steps)
                {
                    int i = 0;
                    while (i < rows.Count && Claimed(rows[i])) i++;
                    if (rows.Count > 0)
                    {
                        int at = Math.Min(i, rows.Count - 1);
                        QuestRow r = rows[at];
                        items.Add(new QuestBoardItem(g, r, Plain(r, i >= rows.Count), Counter(r), at == 0 ? 0 : rows[at - 1].ClearValue, r.ClearValue, 0, QuestItemState.Done, locked));
                    }
                }
                else if (g.GroupType == QuestGroupType.Track)
                {
                    for (int i = 0; i < rows.Count; i++)
                    {
                        QuestRow r = rows[i];
                        QuestItemState premium = !g.Premium || r.PremiumRewards.Count == 0 || (run != null && run.PaidClaimed(r.id)) ? QuestItemState.Done
                            : run != null && run.Premium && Counter(r) >= r.ClearValue ? QuestItemState.Claimable : QuestItemState.InProgress;
                        items.Add(new QuestBoardItem(g, r, Plain(r, Claimed(r)), Counter(r), i == 0 ? 0 : rows[i - 1].ClearValue, r.ClearValue, 0, premium, locked));
                    }
                }
                else
                {
                    foreach (QuestRow r in rows)
                    {
                        long current = Counter(r);
                        if (r.Repeats)
                        {
                            int n = run?.RepeatCount(r.id) ?? 0;
                            long target = r.TargetAfter(n);
                            items.Add(new QuestBoardItem(g, r, current >= target ? QuestItemState.Claimable : QuestItemState.InProgress, current, n == 0 ? 0 : r.TargetAfter(n - 1), target, n, QuestItemState.Done, locked));
                        }
                        else items.Add(new QuestBoardItem(g, r, Plain(r, Claimed(r)), current, 0, r.ClearValue, 0, QuestItemState.Done, locked));
                    }
                    items = items.OrderBy(it => QuestBoard.Rank(it.State)).ThenBy(it => it.Row.sort).ThenBy(it => it.Id).ToList();
                }

                QuestRow[] oneShot = rows.Where(r => !r.Repeats).ToArray();
                int claimedRows = oneShot.Count(Claimed);
                QuestItemState? completion = !g.HasCompletion ? (QuestItemState?)null
                    : run != null && run.CompletionClaimed ? QuestItemState.Done
                    : run != null && claimedRows == oneShot.Length ? QuestItemState.Claimable : QuestItemState.InProgress;
                long reset = QuestPeriods.NextReset(g.Period, g.CycleKey, nowUtcMs, Period);
                boardReset = Math.Min(boardReset, reset);
                groups.Add(new QuestBoardGroup(g, status, run, IsFinished(g, run), claimedRows, oneShot.Length, completion, reset, items));
            }
            return new QuestBoard(groups, boardReset);
        }
    }
}
