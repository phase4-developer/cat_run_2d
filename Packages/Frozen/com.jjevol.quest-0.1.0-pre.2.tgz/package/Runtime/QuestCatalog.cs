using System;
using System.Collections.Generic;
using System.Linq;
using jjevol;

namespace jjevol.Quest
{
    public enum QuestIssueSeverity { Warning, Error }

    /// <summary>A table problem. <see cref="RowId"/> is the group key or row id (0 when not about one row).</summary>
    public sealed class QuestCatalogIssue
    {
        public QuestCatalogIssue(QuestIssueSeverity severity, string code, int rowId, string message)
        { Severity = severity; Code = code; RowId = rowId; Message = message; }
        public QuestIssueSeverity Severity { get; }
        public string Code { get; }
        public int RowId { get; }
        public string Message { get; }
        public override string ToString() => $"{Severity} {Code} {(RowId == 0 ? "" : RowId + ": ")}{Message}";
    }

    /// <summary>Groups and rows indexed once, with the table checks of the quest rules.</summary>
    public sealed class QuestCatalog
    {
        private readonly Dictionary<int, QuestGroupRow> _groups;
        private readonly Dictionary<int, QuestRow[]> _rowsByGroup;
        private readonly Dictionary<int, QuestRow> _rows;
        private readonly HashSet<(string, string)> _sharedReads;
        private readonly Dictionary<int, HashSet<string>> _runReads;

        private QuestCatalog(Dictionary<int, QuestGroupRow> groups, Dictionary<int, QuestRow[]> rowsByGroup, Dictionary<int, QuestRow> rows, QuestGroupRow[] rollOrder)
        {
            _groups = groups; _rowsByGroup = rowsByGroup; _rows = rows; RollOrder = rollOrder;
            Groups = groups.Values.OrderBy(g => g.sort).ThenBy(g => g.id).ToArray();
            _sharedReads = new HashSet<(string, string)>();
            _runReads = new Dictionary<int, HashSet<string>>();
            foreach (QuestGroupRow g in Groups)
            {
                IEnumerable<string> keys = Rows(g.Key).Select(r => r.CounterKey);
                if (g.Scope == QuestScope.Run) _runReads[g.Key] = new HashSet<string>(keys, StringComparer.Ordinal);
                else foreach (string k in keys) _sharedReads.Add((g.SharedSlot, k));
            }
            SharedSlots = new[] { QuestPeriods.Lifetime }.Concat(Groups.Where(g => g.Scope == QuestScope.Period).Select(g => g.SharedSlot).Where(s => s != null)).Distinct().ToArray();
        }

        /// <summary>Active groups, sort → id.</summary>
        public IReadOnlyList<QuestGroupRow> Groups { get; }
        /// <summary>Active groups with every required group before the group that needs it.</summary>
        public IReadOnlyList<QuestGroupRow> RollOrder { get; }
        /// <summary>Shared counter slots in use: the lifetime and the period slots of period-scope groups.</summary>
        public IReadOnlyList<string> SharedSlots { get; }

        public QuestGroupRow Group(int groupKey) => _groups.TryGetValue(groupKey, out QuestGroupRow g) ? g : null;
        /// <summary>Active rows of a group: step → sort → id.</summary>
        public IReadOnlyList<QuestRow> Rows(int groupKey) => _rowsByGroup.TryGetValue(groupKey, out QuestRow[] rows) ? rows : Array.Empty<QuestRow>();
        public QuestRow Row(int questId) => _rows.TryGetValue(questId, out QuestRow row) ? row : null;

        /// <summary>Some period-scope group reads this counter in this shared slot.</summary>
        internal bool SharedReads(string slot, string key) => _sharedReads.Contains((slot, key));
        /// <summary>The run-scope group reads this counter.</summary>
        internal bool RunReads(int groupKey, string key) => _runReads.TryGetValue(groupKey, out HashSet<string> keys) && keys.Contains(key);

        /// <summary>
        /// Indexes the active rows and reports every table problem. The catalog is built even with errors so an Editor
        /// check can list them all; the game must not start with an <see cref="QuestIssueSeverity.Error"/>.
        /// </summary>
        public static QuestCatalog Build(IEnumerable<QuestGroupRow> groups, IEnumerable<QuestRow> rows, QuestKindRegistry kinds,
            IQuestRewardPolicy rewards, QuestPeriodSettings period, out IReadOnlyList<QuestCatalogIssue> issues)
        {
            if (groups == null) throw new ArgumentNullException(nameof(groups));
            if (rows == null) throw new ArgumentNullException(nameof(rows));
            if (kinds == null) throw new ArgumentNullException(nameof(kinds));
            if (rewards == null) throw new ArgumentNullException(nameof(rewards));
            period ??= QuestPeriodSettings.Default;
            var list = new List<QuestCatalogIssue>();
            void Error(string code, int id, string message) => list.Add(new QuestCatalogIssue(QuestIssueSeverity.Error, code, id, message));
            void Warn(string code, int id, string message) => list.Add(new QuestCatalogIssue(QuestIssueSeverity.Warning, code, id, message));

            var allGroups = new Dictionary<int, QuestGroupRow>();
            var ids = new HashSet<int>();
            foreach (QuestGroupRow g in groups)
            {
                if (g == null) continue;
                if (!ids.Add(g.id)) { Error("DuplicateId", g.id, "group id repeats"); continue; }
                if (g.Key <= 0) { Error("BadGroupKey", g.id, "group key must be positive"); continue; }
                if (!allGroups.TryAdd(g.Key, g)) { Error("DuplicateKey", g.Key, "group key repeats"); continue; }
                if (!g.Active) continue;
                if (!Enum.IsDefined(typeof(QuestPeriod), g.Period)) Error("BadPeriod", g.Key, "periodType " + (int)g.Period);
                if (!Enum.IsDefined(typeof(QuestGroupType), g.GroupType)) Error("BadGroupType", g.Key, "groupType " + (int)g.GroupType);
                if (!Enum.IsDefined(typeof(QuestScope), g.Scope)) Error("BadScope", g.Key, "progressScope " + (int)g.Scope);
                if (g.Period == QuestPeriod.None && g.Scope == QuestScope.Period) Error("ScopeWithoutPeriod", g.Key, "progressScope 3 needs a periodType; use 1 (lifetime) or 2 (run)");
                if (g.Period == QuestPeriod.Cycle)
                {
                    if (!QuestPeriodSettings.ValidCycleKey(g.CycleKey)) Error("BadCycleKey", g.Key, "cycleKey is letters, digits and '_'");
                    else if (period.Cycle(g.CycleKey) == null) Error("NoCycleSource", g.Key, "cycle '" + g.CycleKey + "' is not added to QuestPeriodSettings");
                }
                if (g.Premium && g.GroupType != QuestGroupType.Track) Error("PremiumNotTrack", g.Key, "a premium group is groupType 3 (track)");
                if (g.SelectionCount < 0) Error("BadSelection", g.Key, "selectionCount < 0");
                if (g.SelectionCount > 0 && g.GroupType != QuestGroupType.List) Error("SelectionNotList", g.Key, "selectionCount needs a list group");
                if (g.AutoClaim && g.Premium) Error("AutoClaimPremium", g.Key, "autoClaim cannot pay a premium side");
                if (g.HasCompletion && g.Premium) Error("CompletionOnPremium", g.Key, "a premium group has no completion reward");
                if (g.RequireGroup == g.Key) Error("RequireSelf", g.Key, "requireGroupId points at itself");
            }

            Dictionary<int, QuestGroupRow> activeGroups = allGroups.Values.Where(g => g.Active).ToDictionary(g => g.Key);
            foreach (QuestGroupRow g in activeGroups.Values)
                if (g.RequireGroup != 0 && g.RequireGroup != g.Key && !activeGroups.ContainsKey(g.RequireGroup))
                    Error("MissingRequire", g.Key, "requireGroupId " + g.RequireGroup + " is not an active group");

            var allRows = new Dictionary<int, QuestRow>();
            var byGroup = new Dictionary<int, List<QuestRow>>();
            var paidPoints = new HashSet<int>();   // point consume types some reward pays

            void CheckRewards(int id, IEnumerable<ConsumeData> list2)
            {
                foreach (ConsumeData reward in list2)
                {
                    if (reward.Quantity <= 0 || reward.Min != reward.Max) Error("BadReward", id, "reward quantity must be a fixed positive number");
                    else if (kinds.TryGetPoint(reward.TypeId, out _)) paidPoints.Add(reward.TypeId.Value);
                    else if (rewards.IsPremium(reward.TypeId))
                    {
                        if (!activeGroups.TryGetValue(reward.ItemId, out QuestGroupRow pg) || !pg.Premium) Error("UnknownPremium", id, "premium reward id " + reward.ItemId + " is not a premium group");
                    }
                    else if (!rewards.CanGrant(reward.TypeId)) Error("UnsupportedReward", id, "consume type " + reward.TypeId.Value + " cannot be paid by this game");
                }
            }

            foreach (QuestRow r in rows)
            {
                if (r == null) continue;
                if (!allRows.TryAdd(r.id, r)) { Error("DuplicateId", r.id, "row id repeats across quest tables"); continue; }
                if (!allGroups.TryGetValue(r.Group, out QuestGroupRow g)) { Error("MissingGroup", r.id, "group " + r.Group + " is not in the group table"); continue; }
                if (!r.Active) continue;
                if (!g.Active) { Error("InactiveGroup", r.id, "active row in inactive group " + g.Key); continue; }
                if (!kinds.TryGet(r.ClearType, out QuestKindRegistry.Kind kind)) Error("UnknownClearType", r.id, "clearType " + r.ClearType + " is not registered");
                else if (r.ClearCondition != 0 && !kind.UsesCondition) Error("ConditionNotUsed", r.id, "clearType " + r.ClearType + " takes no condition");
                if (r.ClearCondition < 0) Error("BadCondition", r.id, "clearCondition < 0");
                if (r.ClearValue <= 0) Error("BadClearValue", r.id, "clearValue <= 0");
                if (r.ClearValueStep < 0) Error("BadStep", r.id, "clearValueStep < 0");
                if (r.Repeats && (g.GroupType != QuestGroupType.List || g.Period == QuestPeriod.None || g.AutoClaim || g.Premium || g.SelectionCount > 0))
                    Error("RepeatNotAllowed", r.id, "clearValueStep needs a list group with a period, without autoClaim or selectionCount");
                if (r.PremiumRewards.Count > 0 && !g.Premium) Error("PremiumOutsideGroup", r.id, "premium rewards need a premium group");
                CheckRewards(r.id, r.Rewards.Concat(r.PremiumRewards));
                if (!byGroup.TryGetValue(g.Key, out List<QuestRow> bucket)) byGroup.Add(g.Key, bucket = new List<QuestRow>());
                bucket.Add(r);
            }

            var ordered = new Dictionary<int, QuestRow[]>();
            foreach (QuestGroupRow g in activeGroups.Values)
            {
                CheckRewards(g.Key, g.CompleteRewards);
                QuestRow[] sorted = byGroup.TryGetValue(g.Key, out List<QuestRow> b) ? b.OrderBy(r => r.Step).ThenBy(r => r.sort).ThenBy(r => r.id).ToArray() : Array.Empty<QuestRow>();
                ordered.Add(g.Key, sorted);
                if (g.SelectionCount > 0 && g.SelectionCount >= sorted.Length) Error("SelectionTooLarge", g.Key, "selectionCount must be less than the row count");
                if (g.HasCompletion && sorted.All(r => r.Repeats)) Error("CompletionNeverDone", g.Key, "a completion reward needs a one-shot row");
                else if (sorted.All(r => r.Repeats) && activeGroups.Values.Any(o => o.RequireGroup == g.Key && o.Key != g.Key))
                    Error("RequireNeverDone", g.Key, "a required group needs a one-shot row, or it counts as finished at once");
                if (g.GroupType == QuestGroupType.List) continue;
                if (sorted.Any(r => r.Step <= 0)) Error("MissingStep", g.Key, "steps and tracks need step 1, 2, …");
                if (sorted.Select(r => r.Step).Distinct().Count() != sorted.Length) Error("RepeatedStep", g.Key, "step repeats in the group");
                if (sorted.Select(r => r.CounterKey).Distinct().Count() > 1) Error("MixedCounter", g.Key, "rows of one steps or track group share clearType and clearCondition");
                for (int i = 1; i < sorted.Length; i++)
                    if (sorted[i].ClearValue <= sorted[i - 1].ClearValue) Error("NotIncreasing", sorted[i].id, "clearValue must grow with step (cumulative thresholds)");
            }

            foreach (QuestKindRegistry.Kind k in kinds.All.Where(k => k.IsPoint))
                if (!paidPoints.Contains(k.PointConsume.Value.Value) && ordered.Values.SelectMany(x => x).Any(r => r.ClearType == k.Type))
                    Warn("PointNeverPaid", 0, "no reward pays point consume " + k.PointConsume.Value.Value + " (counter " + k.Type + "); only ApplyRewards can raise it");

            // Requirement order; a loop is an error and its groups are left out of the order (they never open).
            var order = new List<QuestGroupRow>();
            var state = new Dictionary<int, int>();   // 1 visiting, 2 done
            bool Visit(QuestGroupRow g)
            {
                if (state.TryGetValue(g.Key, out int s)) return s == 2;
                state[g.Key] = 1;
                bool ok = g.RequireGroup == 0 || g.RequireGroup == g.Key || !activeGroups.TryGetValue(g.RequireGroup, out QuestGroupRow req) || Visit(req);
                if (!ok && state[g.Key] == 1) Error("RequireLoop", g.Key, "requireGroupId forms a loop");
                state[g.Key] = ok ? 2 : 3;
                if (ok) order.Add(g);
                return ok;
            }
            foreach (QuestGroupRow g in activeGroups.Values.OrderBy(g => g.sort).ThenBy(g => g.id)) Visit(g);

            issues = list;
            return new QuestCatalog(activeGroups, ordered, allRows.Values.Where(r => r.Active && activeGroups.ContainsKey(r.Group)).ToDictionary(r => r.id), order.ToArray());
        }

        /// <summary>
        /// Reads the tables of the layout from a table source (a table the source does not have is empty) and builds.
        /// <c>IndexedTable.LoadDatas(ITableSource)</c> reads only the first table of <see cref="QuestRowTable"/>; use this instead.
        /// </summary>
        public static QuestCatalog Build(ITableSource source, QuestKindRegistry kinds, IQuestRewardPolicy rewards, QuestPeriodSettings period,
            out IReadOnlyList<QuestCatalogIssue> issues, QuestTableLayout layout = null)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            layout ??= QuestTableLayout.Default;
            IEnumerable<TSVRow> Rows(string table) => source.HasTable(table) ? source.Load(table) ?? new List<TSVRow>() : new List<TSVRow>();
            var groups = Rows(layout.GroupTable).Select(r => new QuestGroupRow(r, layout)).ToArray();
            var rows = layout.RowTables.SelectMany(t => Rows(t.Table).Select(r => new QuestRow(r, t.Kind, layout))).ToArray();
            return Build(groups, rows, kinds, rewards, period, out issues);
        }

        /// <summary>Builds from loaded tables.</summary>
        public static QuestCatalog Build(QuestGroupTable groups, QuestRowTable rows, QuestKindRegistry kinds, IQuestRewardPolicy rewards,
            QuestPeriodSettings period, out IReadOnlyList<QuestCatalogIssue> issues)
            => Build(groups?.Datas ?? throw new ArgumentNullException(nameof(groups)), rows?.Datas ?? throw new ArgumentNullException(nameof(rows)), kinds, rewards, period, out issues);
    }
}
