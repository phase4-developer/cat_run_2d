using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;
using jjevol;

namespace jjevol.Quest
{
    /// <summary>
    /// Holds <see cref="QuestState"/> in a <see cref="DataRepository"/> under one key (default "questState").
    /// A response always carries the whole document (the rules roll and drop runs, which a partial merge could not remove), so both
    /// merge and replace take the whole document. Changed keys: "seed", "cnt.{slot}", "group.{key}" (also for removed ones). Register with saveLocal true for a local-authority game,
    /// false (or a ServerCache storage) when the server owns the state.
    /// </summary>
    public sealed class QuestStateContainer : DataContainer
    {
        public QuestStateContainer(string key = QuestStateJson.DefaultKey) : base(key, QuestState.Empty) { }

        public QuestState Current => (QuestState)State;

        protected override StateChange ParseState(JObject data, bool replace)
        {
            QuestState current = Current;
            JToken token = data[DataKey];
            if (token == null)
            {
                if (replace) throw new InvalidDataException("Quest state is missing: " + DataKey);
                return new StateChange(current, Array.Empty<string>());
            }
            if (!(token is JObject document)) throw new InvalidDataException("Quest state must be an object: " + DataKey);
            QuestState incoming = QuestStateJson.Read(document);
            return new StateChange(incoming, ChangedKeys(current, incoming));
        }

        protected override JObject WriteState(object state) => new JObject { [DataKey] = QuestStateJson.Write((QuestState)state) };

        private static string[] ChangedKeys(QuestState a, QuestState b)
        {
            var keys = new List<string>();
            if (a.Seed != b.Seed) keys.Add(QuestStateJson.SeedKey);
            foreach (string slot in a.Counters.Keys.Union(b.Counters.Keys).OrderBy(k => k, StringComparer.Ordinal))
            {
                a.Counters.TryGetValue(slot, out QuestCounterSlot x); b.Counters.TryGetValue(slot, out QuestCounterSlot y);
                if (x == null || y == null || !JToken.DeepEquals(QuestStateJson.WriteSlot(x), QuestStateJson.WriteSlot(y))) keys.Add("cnt." + slot);
            }
            foreach (int group in a.Groups.Keys.Union(b.Groups.Keys).OrderBy(k => k))
            {
                a.Groups.TryGetValue(group, out QuestGroupRun x); b.Groups.TryGetValue(group, out QuestGroupRun y);
                if (x == null || y == null || !JToken.DeepEquals(QuestStateJson.WriteRun(x), QuestStateJson.WriteRun(y))) keys.Add("group." + group);
            }
            return keys.ToArray();
        }
    }

    /// <summary>
    /// Pays wealth rewards on the local route: writes <c>wealthInfos</c> rows (balance + reward) into the response, so the quest state
    /// and the balances are applied and saved together. The base is the row the response already carries (another reward of the same
    /// request), otherwise the raw balance (not the reservation-reduced one).
    /// </summary>
    public sealed class WealthQuestGrantWriter : IQuestGrantWriter
    {
        private readonly ResourceService _resources;
        public WealthQuestGrantWriter(ResourceService resources) => _resources = resources ?? throw new ArgumentNullException(nameof(resources));

        public void Write(JObject response, IReadOnlyList<ConsumeData> grants)
        {
            if (response == null) throw new ArgumentNullException(nameof(response));
            if (grants == null || grants.Count == 0) return;
            if (response[WealthContainer.PayloadKey] != null && !(response[WealthContainer.PayloadKey] is JArray))
                throw new InvalidOperationException(WealthContainer.PayloadKey + " in the response is not an array.");
            var rows = (JArray)response[WealthContainer.PayloadKey] ?? new JArray();
            foreach (IGrouping<int, ConsumeData> g in grants.GroupBy(v => v.ItemId).OrderBy(g => g.Key))
            {
                if (g.Any(v => !v.TypeId.Equals(_resources.WealthTypeId))) throw new InvalidOperationException("Only wealth rewards are written by WealthQuestGrantWriter.");
                WealthData definition = _resources.Definitions.Get(g.Key);
                if (definition == null || string.IsNullOrEmpty(definition.type)) throw new InvalidOperationException("Unknown wealth id: " + g.Key);
                JObject existing = rows.OfType<JObject>().FirstOrDefault(r => (string)r[WealthContainer.TypeKey] == definition.type);
                long baseValue = existing != null ? existing[WealthContainer.QuantityKey]?.Value<long>() ?? 0 : _resources.GetRaw(g.Key);
                long next = checked(baseValue + g.Sum(v => v.Quantity));
                if (existing != null) existing[WealthContainer.QuantityKey] = next;
                else rows.Add(new JObject { [WealthContainer.TypeKey] = definition.type, [WealthContainer.QuantityKey] = next });
            }
            response[WealthContainer.PayloadKey] = rows;
        }
    }
}
