using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;

namespace jjevol.Quest
{
    internal static class QuestCounters
    {
        internal static Dictionary<TKey, TValue> Copy<TKey, TValue>(IEnumerable<KeyValuePair<TKey, TValue>> source, IEqualityComparer<TKey> comparer = null)
        {
            var copy = new Dictionary<TKey, TValue>(comparer ?? EqualityComparer<TKey>.Default);
            if (source != null) foreach (KeyValuePair<TKey, TValue> pair in source) copy.Add(pair.Key, pair.Value);
            return copy;
        }

        internal static string Key(int clearType, int condition)
            => condition == 0 ? clearType.ToString(CultureInfo.InvariantCulture) : clearType.ToString(CultureInfo.InvariantCulture) + ":" + condition.ToString(CultureInfo.InvariantCulture);

        internal static long Apply(QuestAggregate aggregate, long current, long amount)
        {
            switch (aggregate)
            {
                case QuestAggregate.Add: return current > long.MaxValue - amount ? long.MaxValue : current + amount;
                case QuestAggregate.Max: return Math.Max(current, amount);
                default: return amount;
            }
        }

        internal static int[] Sorted(IEnumerable<int> ids) => new SortedSet<int>(ids ?? Array.Empty<int>()).ToArray();
    }

    /// <summary>Shared counters of one period (or the lifetime). Immutable.</summary>
    public sealed class QuestCounterSlot
    {
        public static QuestCounterSlot Empty(int period) => new QuestCounterSlot(period, null);

        public QuestCounterSlot(int period, IEnumerable<KeyValuePair<string, long>> values)
        {
            Period = period;
            Values = new ReadOnlyDictionary<string, long>(QuestCounters.Copy(values, StringComparer.Ordinal));
        }

        /// <summary>Period key the counters belong to (0 for the lifetime).</summary>
        public int Period { get; }
        public IReadOnlyDictionary<string, long> Values { get; }
        public long Counter(string key) => Values.TryGetValue(key, out long v) ? v : 0;

        internal QuestCounterSlot With(string key, long value)
        {
            var v = QuestCounters.Copy(Values, StringComparer.Ordinal); v[key] = value;
            return new QuestCounterSlot(Period, v);
        }
    }

    /// <summary>
    /// The current run of one group: when it started, its own counters (run scope), claims, picked rows and premium side. Immutable.
    /// A new period starts a new run.
    /// </summary>
    public sealed class QuestGroupRun
    {
        public QuestGroupRun(int period, long since, IEnumerable<KeyValuePair<string, long>> values = null, IEnumerable<int> claimed = null,
            IEnumerable<KeyValuePair<int, int>> repeats = null, IEnumerable<int> picks = null, bool premium = false, IEnumerable<int> paid = null,
            bool completionClaimed = false)
        {
            Period = period; Since = since; Premium = premium; CompletionClaimed = completionClaimed;
            Values = new ReadOnlyDictionary<string, long>(QuestCounters.Copy(values, StringComparer.Ordinal));
            Claimed = QuestCounters.Sorted(claimed);
            Repeats = new ReadOnlyDictionary<int, int>(QuestCounters.Copy(repeats));
            Picks = QuestCounters.Sorted(picks);
            Paid = QuestCounters.Sorted(paid);
            _claimed = new HashSet<int>(Claimed); _paid = new HashSet<int>(Paid); _picks = new HashSet<int>(Picks);
        }

        private readonly HashSet<int> _claimed, _paid, _picks;
        /// <summary>Period key of the run (0 for a group without a period).</summary>
        public int Period { get; }
        /// <summary>UTC ms the run started.</summary>
        public long Since { get; }
        /// <summary>Run-scope counters.</summary>
        public IReadOnlyDictionary<string, long> Values { get; }
        /// <summary>One-shot rows claimed (free side), sorted.</summary>
        public IReadOnlyList<int> Claimed { get; }
        /// <summary>Claims of repeating rows (clearValueStep &gt; 0).</summary>
        public IReadOnlyDictionary<int, int> Repeats { get; }
        /// <summary>Picked rows when the group selects some; empty means every row.</summary>
        public IReadOnlyList<int> Picks { get; }
        public bool Premium { get; }
        /// <summary>Premium side claimed, sorted.</summary>
        public IReadOnlyList<int> Paid { get; }
        /// <summary>The group's completion reward was claimed.</summary>
        public bool CompletionClaimed { get; }

        public long Counter(string key) => Values.TryGetValue(key, out long v) ? v : 0;
        public bool IsClaimed(int id) => _claimed.Contains(id);
        public bool PaidClaimed(int id) => _paid.Contains(id);
        public int RepeatCount(int id) => Repeats.TryGetValue(id, out int n) ? n : 0;
        public bool IsPicked(int id) => Picks.Count == 0 || _picks.Contains(id);

        private QuestGroupRun Copy(IEnumerable<KeyValuePair<string, long>> values = null, IEnumerable<int> claimed = null, IEnumerable<KeyValuePair<int, int>> repeats = null,
            bool? premium = null, IEnumerable<int> paid = null, bool? completion = null)
            => new QuestGroupRun(Period, Since, values ?? Values, claimed ?? Claimed, repeats ?? Repeats, Picks, premium ?? Premium, paid ?? Paid, completion ?? CompletionClaimed);

        internal QuestGroupRun WithCounter(string key, long value) { var v = QuestCounters.Copy(Values, StringComparer.Ordinal); v[key] = value; return Copy(values: v); }
        internal QuestGroupRun WithClaim(int id) => Copy(claimed: Claimed.Concat(new[] { id }));
        internal QuestGroupRun WithRepeat(int id) { var r = QuestCounters.Copy(Repeats); r[id] = checked(RepeatCount(id) + 1); return Copy(repeats: r); }
        internal QuestGroupRun WithPremium() => Copy(premium: true);
        internal QuestGroupRun WithPaid(int id) => Copy(paid: Paid.Concat(new[] { id }));
        internal QuestGroupRun WithCompletion() => Copy(completion: true);
    }

    /// <summary>All quest progress of a profile. Immutable; rules return new states.</summary>
    public sealed class QuestState
    {
        public static QuestState Empty { get; } = new QuestState(0, null, null);

        public QuestState(int seed, IEnumerable<KeyValuePair<string, QuestCounterSlot>> counters, IEnumerable<KeyValuePair<int, QuestGroupRun>> groups)
        {
            Seed = seed;
            Counters = new ReadOnlyDictionary<string, QuestCounterSlot>(QuestCounters.Copy(counters, StringComparer.Ordinal));
            Groups = new ReadOnlyDictionary<int, QuestGroupRun>(QuestCounters.Copy(groups));
        }

        /// <summary>Seed of the per-run row selection. Set once when the profile is made (<see cref="WithSeed"/>).</summary>
        public int Seed { get; }
        /// <summary>Shared counter slots by name (lifetime, daily, weekly, monthly, cycle.{key}).</summary>
        public IReadOnlyDictionary<string, QuestCounterSlot> Counters { get; }
        /// <summary>Current run of each group that has one, by group key.</summary>
        public IReadOnlyDictionary<int, QuestGroupRun> Groups { get; }

        /// <summary>The stored slot, or an empty one with period key 0. Rules roll before reading.</summary>
        public QuestCounterSlot Slot(string name) => name != null && Counters.TryGetValue(name, out QuestCounterSlot s) ? s : QuestCounterSlot.Empty(0);
        /// <summary>The group's current run, or null when it has none (never opened, or its period passed while closed).</summary>
        public QuestGroupRun Run(int groupKey) => Groups.TryGetValue(groupKey, out QuestGroupRun r) ? r : null;

        public QuestState WithSeed(int seed) => new QuestState(seed, Counters, Groups);

        internal QuestState With(string slot, QuestCounterSlot value)
        {
            var c = QuestCounters.Copy(Counters, StringComparer.Ordinal); c[slot] = value;
            return new QuestState(Seed, c, Groups);
        }

        internal QuestState With(int groupKey, QuestGroupRun run)
        {
            var g = QuestCounters.Copy(Groups);
            if (run == null) g.Remove(groupKey); else g[groupKey] = run;
            return new QuestState(Seed, Counters, g);
        }
    }
}
