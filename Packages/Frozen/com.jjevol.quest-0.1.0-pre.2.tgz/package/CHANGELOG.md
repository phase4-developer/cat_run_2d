# Changelog

## 0.1.0-pre.2 - 2026-11-10

Breaking: enum codes, the state document and the public API changed. No game used pre.1.

- Enum codes follow the existing games: `QuestPeriod` 0/2/4/8/16 (16 = named cycle), `QuestScope` 1 lifetime / 2 run / 3 period, `QuestGroupType` 1 list / 2 steps / 3 track.
- Group runs (`QuestGroupRun`): each group has a current run with its own counters, claims, repeats, picks, premium and completion. A run starts when the group opens (active, `openKey`, `requireGroupId` finished, cycle running) and again each period. Every write rolls before and after.
- New group columns: `premium` (track only; replaces the tab-100 pass rule), `requireGroupId` (starter chains), `selectionCount` (seeded picks per run), `autoClaim`, `cycleKey`, `completeRewardType/Id/Value`.
- `QuestKindRegistry.AddPoint(clearType, pointConsume)`: point clear types and consume types are numbered separately. Points count into every counter that reads them.
- `QuestPeriodSettings.AddCycle(key, idOf, endsAt)` replaces the single season source.
- `QuestTableLayout` adds `GroupKeyColumn`, `StepColumn` and `RowTables` (any number of row tables).
- State JSON `{seed, cnt:{slot:{period,v}}, groups:{key:{period,since,v,got,n,pick,premium,paid,fin}}}`. The container takes the whole document on merge too, so runs the rules dropped do not come back; change keys are `seed`, `cnt.{slot}`, `group.{key}`, removed ones included.
- `QuestRules.ApplyRewards` applies points and premium paid elsewhere; `Claim` takes `QuestClaimTarget.Completion`; group and tab claims continue into newly opened groups.
- `QuestBoard`: group status, finished, completion, premium; item `Progress01`, `Remaining`, `Condition`; `Items(tab)`.
- `QuestClient` (Network): cached board with `BoardChanged`, `ClaimAsync`/`RecordAsync` checked with the local rules first, one call at a time (`quest.busy`).
- `QuestLocalService`: an `INetworkLocalService` decorator that handles the quest requests and appends progress (`Progress`) and paid points or premium (`Rewards`) to the game's other responses. `AppendProgress`/`AppendRewards` continue from the state already in the response and return a code.
- `WealthQuestGrantWriter` adds onto wealth rows already in the response.
- New catalog issue codes for the new columns (`RequireNeverDone`, repeats not allowed in selection groups); `PointNeverPaid` is a warning. A bad period or cycle key is reported instead of throwing.
- Premium of a cycle group is refused while no cycle runs; `ActivatePremium` rolls after writing; autoClaim still pays when a claim reached the 1000 cap; claiming a row id that is not a row is `quest.unknown`.
- `QuestStateJson` rejects a nonzero lifetime period, a negative period and null repeat counts.

## 0.1.0-pre.1 - 2026-11-10

- New package. Daily, weekly, monthly and season quests, point tracks, achievement steps and passes share one catalog and one set of rules.
- Tables `440_questGroup`, `441_quest`, `442_passQuest`, `443_achievement`; enum codes are canonical and `QuestTableLayout` converts other names and codes.
- `QuestCatalog.Build` reports every table problem as a `QuestCatalogIssue` with a stable code. `QuestTableAuthoring.Schemas`/`Check`/`Validate` hook the check into tables.authoring builds.
- `QuestRules.Record`/`Claim`/`ActivatePremium`/`Board` work on an immutable `QuestState`; every write rolls the periods first and a rejected call leaves the state unchanged. Claim-all repeats until nothing more opens (point tracks), capped at 1000 claims.
- `QuestBoard` exposes red dots as `HasRedDot` on items, groups, tabs and the whole board, with no dependency on a badge package.
- `QuestStateJson` reads strictly; `QuestStateContainer` merges the slots present and replaces the whole document on import.
- `QuestLocalHandler` handles record and claim requests on the local route and appends progress to other responses; `WealthQuestGrantWriter` pays wealth rewards from the raw balance.
- `QuestPeriodSettings.WeekStartFromTable` converts the table setting questWeekStart (1 Monday … 7 Sunday). Pass groups get the same one-counter, growing-threshold checks as tracks and steps.
- `QuestStateJson` requires `period` and accepts only counter keys the rules write. `QuestLocalHandler.HandleClaim` turns grant-writer failures and reward-total overflow into `quest.unsupportedReward`.
