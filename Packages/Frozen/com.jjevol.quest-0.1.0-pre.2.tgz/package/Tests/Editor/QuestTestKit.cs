using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using jjevol;

namespace jjevol.Quest.Tests
{
    /// <summary>Neutral example tables. Ids and values are made up for the tests.</summary>
    internal static class QuestTestKit
    {
        internal const int Run = 1, Best = 2, Upgrade = 3, Level = 4, ServerOnly = 5, DayPoint = 20;
        internal const string Lifetime = QuestPeriods.Lifetime, Daily = QuestPeriods.Daily, Monthly = QuestPeriods.Monthly;
        internal static readonly ConsumeTypeId WealthKind = new ConsumeTypeId(1);
        /// <summary>Daily point consume type; its counter is clear type <see cref="DayPoint"/> (the numbers differ on purpose).</summary>
        internal static readonly ConsumeTypeId Point = new ConsumeTypeId(300);
        internal static readonly ConsumeTypeId Premium = new ConsumeTypeId(QuestRewardPolicy.DefaultPremiumType);
        internal const int Coins = 1001001, Gems = 1001002;

        internal const int DailyGroup = 440001001, TrackGroup = 440001002, MonthlyGroup = 440003001, AchieveGroup = 440004001, PassGroup = 440100001, LockedGroup = 440001009;
        internal const int DailyRun = 441001001, DailyUpgrade = 441001002, Track1 = 441002001, Track2 = 441002002, MonthlyRepeat = 441003001,
            Achieve1 = 443004001, Achieve2 = 443004002, Pass1 = 442100001, Pass2 = 442100002, LockedRow = 441009001;
        internal const int PassTab = 100;

        /// <summary>2026-11-10 12:00 UTC.</summary>
        internal static readonly long Now = At(2026, 11, 10, 12);

        internal static long At(int y, int m, int d, int h = 0, int min = 0) => new DateTimeOffset(y, m, d, h, min, 0, TimeSpan.Zero).ToUnixTimeMilliseconds();

        internal static QuestKindRegistry Kinds() => new QuestKindRegistry()
            .Add(Run, QuestAggregate.Add, usesCondition: false)
            .Add(Best, QuestAggregate.Max, usesCondition: false)
            .Add(Upgrade, QuestAggregate.Add, usesCondition: true)
            .Add(Level, QuestAggregate.Set, usesCondition: false)
            .Add(ServerOnly, QuestAggregate.Add, usesCondition: false, QuestSource.Server)
            .AddPoint(DayPoint, Point);

        internal static QuestRewardPolicy Policy() => new QuestRewardPolicy(WealthKind);

        internal static ConsumeData C(int item, long n) => new ConsumeData(WealthKind, item, n);
        internal static ConsumeData P(long n) => new ConsumeData(Point, 0, n);

        internal static List<QuestGroupRow> Groups() => new List<QuestGroupRow>
        {
            new QuestGroupRow(DailyGroup, 1, QuestPeriod.Daily, QuestGroupType.List, QuestScope.Period, sort: 1),
            new QuestGroupRow(TrackGroup, 1, QuestPeriod.Daily, QuestGroupType.Track, QuestScope.Period, sort: 2),
            new QuestGroupRow(MonthlyGroup, 3, QuestPeriod.Monthly, QuestGroupType.List, QuestScope.Period),
            new QuestGroupRow(AchieveGroup, 4, QuestPeriod.None, QuestGroupType.Steps, QuestScope.Lifetime),
            new QuestGroupRow(PassGroup, PassTab, QuestPeriod.None, QuestGroupType.Track, QuestScope.Lifetime, premium: true),
            new QuestGroupRow(LockedGroup, 1, QuestPeriod.Daily, QuestGroupType.List, QuestScope.Period, sort: 3, openKey: "shop"),
        };

        internal static List<QuestRow> Rows() => new List<QuestRow>
        {
            new QuestRow(DailyRun, QuestRowKind.Quest, DailyGroup, Run, 3, rewards: new[] { C(Coins, 100), P(20) }),
            new QuestRow(DailyUpgrade, QuestRowKind.Quest, DailyGroup, Upgrade, 2, clearCondition: 7, rewards: new[] { P(20) }),
            new QuestRow(Track1, QuestRowKind.Quest, TrackGroup, DayPoint, 20, step: 1, rewards: new[] { C(Gems, 5) }),
            new QuestRow(Track2, QuestRowKind.Quest, TrackGroup, DayPoint, 40, step: 2, rewards: new[] { C(Gems, 10) }),
            new QuestRow(MonthlyRepeat, QuestRowKind.Quest, MonthlyGroup, Run, 10, clearValueStep: 5, rewards: new[] { C(Coins, 50) }),
            new QuestRow(Achieve1, QuestRowKind.Achievement, AchieveGroup, Best, 100, step: 1, rewards: new[] { C(Gems, 1) }),
            new QuestRow(Achieve2, QuestRowKind.Achievement, AchieveGroup, Best, 200, step: 2, rewards: new[] { C(Gems, 2) }),
            new QuestRow(Pass1, QuestRowKind.Pass, PassGroup, Level, 1, step: 1, rewards: new[] { C(Coins, 10) }, premiumRewards: new[] { C(Gems, 1) }),
            new QuestRow(Pass2, QuestRowKind.Pass, PassGroup, Level, 2, step: 2, rewards: new[] { C(Coins, 20) }, premiumRewards: new[] { C(Gems, 2) }),
            new QuestRow(LockedRow, QuestRowKind.Quest, LockedGroup, Run, 1, rewards: new[] { C(Coins, 1) }),
        };

        internal static QuestCatalog Catalog(List<QuestGroupRow> groups = null, List<QuestRow> rows = null, QuestPeriodSettings period = null)
        {
            QuestCatalog catalog = QuestCatalog.Build(groups ?? Groups(), rows ?? Rows(), Kinds(), Policy(), period, out IReadOnlyList<QuestCatalogIssue> issues);
            Assert.That(issues.Where(i => i.Severity == QuestIssueSeverity.Error), Is.Empty, string.Join("\n", issues));
            return catalog;
        }

        internal static QuestRules Rules(QuestPeriodSettings period = null) => new QuestRules(Catalog(period: period), Kinds(), Policy(), period);
        internal static QuestRules Rules(List<QuestGroupRow> groups, List<QuestRow> rows, QuestPeriodSettings period = null)
            => new QuestRules(Catalog(groups, rows, period), Kinds(), Policy(), period);

        internal static IReadOnlyList<QuestCatalogIssue> Issues(List<QuestGroupRow> groups, List<QuestRow> rows, QuestPeriodSettings period = null)
        {
            QuestCatalog.Build(groups, rows, Kinds(), Policy(), period, out IReadOnlyList<QuestCatalogIssue> issues);
            return issues;
        }

        internal static string[] Codes(IReadOnlyList<QuestCatalogIssue> issues) => issues.Where(i => i.Severity == QuestIssueSeverity.Error).Select(i => i.Code).ToArray();

        internal static QuestState Record(QuestRules rules, QuestState state, long now, params QuestEvent[] events) => Record(rules, state, now, null, events);

        internal static QuestState Record(QuestRules rules, QuestState state, long now, Func<string, bool> isOpen, params QuestEvent[] events)
        {
            QuestRecordResult result = rules.Record(state, events, now, QuestSource.Server, isOpen);
            Assert.That(result.Ok, Is.True, result.Code);
            return result.State;
        }

        internal static QuestState Claim(QuestRules rules, QuestState state, QuestClaimTarget target, long now, Func<string, bool> isOpen = null)
        {
            QuestClaimResult result = rules.Claim(state, target, now, isOpen);
            Assert.That(result.Ok, Is.True, result.Code);
            return result.State;
        }

        internal static TSVRow Row(string tsvHeader, string tsvLine) => TSVRow.FromTsv(tsvHeader + "\n" + tsvLine).Single();
    }
}
