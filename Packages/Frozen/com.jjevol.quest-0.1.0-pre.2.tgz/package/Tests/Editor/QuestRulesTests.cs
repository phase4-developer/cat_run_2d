using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using jjevol;
using static jjevol.Quest.Tests.QuestTestKit;

namespace jjevol.Quest.Tests
{
    public sealed class QuestRulesTests
    {
        private QuestRules _rules;

        [SetUp] public void SetUp() => _rules = Rules();

        [Test]
        public void RecordAppliesAddMaxAndSet()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 2), new QuestEvent(Run, 1), new QuestEvent(Best, 150), new QuestEvent(Best, 90), new QuestEvent(Level, 5), new QuestEvent(Level, 2));
            Assert.That(s.Slot(Daily).Counter("1"), Is.EqualTo(3));
            Assert.That(s.Slot(Monthly).Counter("1"), Is.EqualTo(3));
            Assert.That(s.Slot(Lifetime).Counter("1"), Is.EqualTo(3), "lifetime keeps every registered counter");
            Assert.That(s.Slot(Lifetime).Counter("2"), Is.EqualTo(150));
            Assert.That(s.Slot(Lifetime).Counter("4"), Is.EqualTo(2));
            Assert.That(s.Slot(Daily).Values.ContainsKey("2"), Is.False, "period slots keep only counters a group reads");
        }

        [Test]
        public void ConditionRecordsBothKeys()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Upgrade, 1, 7), new QuestEvent(Upgrade, 1, 8));
            Assert.That(s.Slot(Daily).Counter("3:7"), Is.EqualTo(1));
            Assert.That(s.Slot(Lifetime).Counter("3"), Is.EqualTo(2));
            Assert.That(s.Slot(Lifetime).Counter("3:8"), Is.EqualTo(1));
        }

        [TestCase(Run, 0L, 0, TestName = "RejectZeroAdd")]
        [TestCase(Run, -1L, 0, TestName = "RejectNegativeAdd")]
        [TestCase(Run, 1L, 3, TestName = "RejectUnusedCondition")]
        [TestCase(Upgrade, 1L, -1, TestName = "RejectNegativeCondition")]
        [TestCase(99, 1L, 0, TestName = "RejectUnknownType")]
        [TestCase(DayPoint, 5L, 0, TestName = "RejectPointCounter")]
        [TestCase(Level, -1L, 0, TestName = "RejectNegativeSet")]
        public void RecordRejectsWholeCall(int type, long amount, int condition)
        {
            QuestState before = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 1));
            QuestRecordResult r = _rules.Record(before, new[] { new QuestEvent(Run, 1), new QuestEvent(type, amount, condition) }, Now, QuestSource.Server);
            Assert.That(r.Ok, Is.False);
            Assert.That(r.Code, Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(r.State, Is.SameAs(before));
            Assert.That(r.State.Slot(Daily).Counter("1"), Is.EqualTo(1));
        }

        [Test]
        public void ClientCannotRecordServerOnlyType()
        {
            Assert.That(_rules.Record(QuestState.Empty, new[] { new QuestEvent(ServerOnly, 1) }, Now, QuestSource.Client).Code, Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(_rules.Record(QuestState.Empty, new[] { new QuestEvent(ServerOnly, 1) }, Now, QuestSource.Server).Ok, Is.True);
        }

        [Test]
        public void RecordSaturatesAtMax()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, long.MaxValue - 1), new QuestEvent(Run, 5));
            Assert.That(s.Slot(Daily).Counter("1"), Is.EqualTo(long.MaxValue));
        }

        [Test]
        public void RollEmptiesOnlyChangedPeriods()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 3));
            s = Claim(_rules, s, QuestClaimTarget.Quest(DailyRun), Now);
            QuestState next = _rules.Roll(s, At(2026, 11, 11, 0));
            Assert.That(next.Slot(Daily).Period, Is.EqualTo(20261111));
            Assert.That(next.Slot(Daily).Counter("1"), Is.EqualTo(0));
            Assert.That(next.Run(DailyGroup).IsClaimed(DailyRun), Is.False, "a new day is a new run");
            Assert.That(next.Run(DailyGroup).Since, Is.EqualTo(At(2026, 11, 11, 0)));
            Assert.That(next.Slot(Monthly).Counter("1"), Is.EqualTo(3));
            Assert.That(next.Slot(Lifetime).Counter("1"), Is.EqualTo(3));
            Assert.That(_rules.Roll(s, At(2026, 11, 10, 23, 59)), Is.SameAs(s), "same period: nothing to roll");
        }

        [Test]
        public void WritesRollBeforeRecording()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 3));
            s = Record(_rules, s, At(2026, 11, 11, 1), new QuestEvent(Run, 1));
            Assert.That(s.Slot(Daily).Counter("1"), Is.EqualTo(1));
            Assert.That(s.Slot(Monthly).Counter("1"), Is.EqualTo(4));
        }

        [Test]
        public void ClaimOnceAndPayOut()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 2));
            Assert.That(_rules.Claim(s, QuestClaimTarget.Quest(DailyRun), Now).Code, Is.EqualTo(QuestCodes.NotDone));
            s = Record(_rules, s, Now, new QuestEvent(Run, 1));
            QuestClaimResult r = _rules.Claim(s, QuestClaimTarget.Quest(DailyRun), Now);
            Assert.That(r.Ok, Is.True);
            Assert.That(r.Grants.Select(g => (g.ItemId, g.Quantity)), Is.EqualTo(new[] { (Coins, 100L) }), "points are not paid out");
            Assert.That(r.Rewards.Count, Is.EqualTo(2), "the popup shows points too");
            Assert.That(r.State.Slot(Daily).Counter("20"), Is.EqualTo(20), "consume 300 raises clear type 20");
            Assert.That(r.Claimed.Single().GroupKey, Is.EqualTo(DailyGroup));
            Assert.That(_rules.Claim(r.State, QuestClaimTarget.Quest(DailyRun), Now).Code, Is.EqualTo(QuestCodes.AlreadyClaimed));
            Assert.That(_rules.Claim(r.State, QuestClaimTarget.Quest(DailyRun), At(2026, 11, 11)).Code, Is.EqualTo(QuestCodes.NotDone), "next day starts over");
        }

        [Test]
        public void PointsGoWhereTheyAreRead()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 3));
            s = Claim(_rules, s, QuestClaimTarget.Quest(DailyRun), Now);
            Assert.That(s.Slot(Daily).Counter("20"), Is.EqualTo(20));
            Assert.That(s.Slot(Lifetime).Counter("20"), Is.EqualTo(20), "the lifetime keeps every counter");
            Assert.That(s.Slot(Monthly).Values.ContainsKey("20"), Is.False, "no monthly group reads daily points");
        }

        [Test]
        public void RepeatTargetGrowsAndCounterStays()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 16));
            s = Claim(_rules, s, QuestClaimTarget.Quest(MonthlyRepeat), Now);   // target 10
            s = Claim(_rules, s, QuestClaimTarget.Quest(MonthlyRepeat), Now);   // target 15
            Assert.That(_rules.Claim(s, QuestClaimTarget.Quest(MonthlyRepeat), Now).Code, Is.EqualTo(QuestCodes.NotDone));   // target 20
            Assert.That(s.Run(MonthlyGroup).RepeatCount(MonthlyRepeat), Is.EqualTo(2));
            Assert.That(s.Slot(Monthly).Counter("1"), Is.EqualTo(16));
            QuestBoardItem item = _rules.Board(s, Now).Group(MonthlyGroup).Items.Single();
            Assert.That((item.Start, item.Target, item.ClaimedCount, item.State), Is.EqualTo((15L, 20L, 2, QuestItemState.InProgress)));
            Assert.That(item.Progress01, Is.EqualTo(0.2f).Within(1e-6));
            Assert.That(_rules.Roll(s, At(2026, 12, 1)).Run(MonthlyGroup).RepeatCount(MonthlyRepeat), Is.EqualTo(0));
        }

        [Test]
        public void StepsGoInOrder()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Best, 250));
            Assert.That(_rules.Claim(s, QuestClaimTarget.Quest(Achieve2), Now).Code, Is.EqualTo(QuestCodes.NotCurrentStep));
            s = Claim(_rules, s, QuestClaimTarget.Quest(Achieve1), Now);
            Assert.That(_rules.Claim(s, QuestClaimTarget.Quest(Achieve1), Now).Code, Is.EqualTo(QuestCodes.AlreadyClaimed));
            QuestBoardItem current = _rules.Board(s, Now).Group(AchieveGroup).Items.Single();
            Assert.That((current.Id, current.Start, current.Target, current.State), Is.EqualTo((Achieve2, 100L, 200L, QuestItemState.Claimable)));
            s = Claim(_rules, s, QuestClaimTarget.Quest(Achieve2), Now);
            QuestBoardGroup done = _rules.Board(s, At(2027, 3, 1)).Group(AchieveGroup);
            Assert.That((done.Items.Single().Id, done.Items.Single().State, done.Finished), Is.EqualTo((Achieve2, QuestItemState.Done, true)), "lifetime steps never reset");
        }

        [Test]
        public void PointsOpenTrackStepsAndClaimAllChains()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 3), new QuestEvent(Upgrade, 2, 7));
            System.Func<string, bool> isOpen = key => key != "shop";
            QuestClaimResult r = _rules.Claim(s, QuestClaimTarget.Tab(1), Now, isOpen);
            Assert.That(r.Ok, Is.True, r.Code);
            Assert.That(r.Claimed.Select(c => c.QuestId), Is.EquivalentTo(new[] { DailyRun, DailyUpgrade, Track1, Track2 }));
            Assert.That(r.Grants.Select(g => (g.ItemId, g.Quantity)), Is.EqualTo(new[] { (Coins, 100L), (Gems, 15L) }), "same rewards are summed");
            Assert.That(r.State.Slot(Daily).Counter("20"), Is.EqualTo(40));
            Assert.That(r.Claimed.Any(c => c.QuestId == LockedRow), Is.False);
            Assert.That(_rules.Claim(r.State, QuestClaimTarget.Tab(1), Now, isOpen).Code, Is.EqualTo(QuestCodes.NotDone));
            Assert.That(_rules.Claim(s, QuestClaimTarget.Tab(1), Now).Claimed.Any(c => c.QuestId == LockedRow), Is.True, "no isOpen: every group is open");
        }

        [Test]
        public void LockedGroupCannotBeClaimedOrDotted()
        {
            System.Func<string, bool> closed = key => key != "shop";
            QuestState s = Record(_rules, QuestState.Empty, Now, closed, new QuestEvent(Run, 1));
            Assert.That(s.Run(LockedGroup), Is.Null, "a locked group has no run");
            Assert.That(_rules.Claim(s, QuestClaimTarget.Quest(LockedRow), Now, closed).Code, Is.EqualTo(QuestCodes.Locked));
            QuestBoardGroup g = _rules.Board(s, Now, closed).Group(LockedGroup);
            Assert.That((g.Status, g.HasRedDot, g.Items.Single().State, g.Items.Single().HasRedDot), Is.EqualTo((QuestGroupStatus.Locked, false, QuestItemState.Claimable, false)),
                "a period-scope group shows shared progress while locked");
            Assert.That(_rules.Claim(s, QuestClaimTarget.Quest(LockedRow), Now, key => true).Ok, Is.True);
        }

        [Test]
        public void PremiumSideOfATrack()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Level, 2));
            s = Claim(_rules, s, QuestClaimTarget.Quest(Pass1), Now);
            Assert.That(_rules.Claim(s, QuestClaimTarget.Quest(Pass1, premium: true), Now).Code, Is.EqualTo(QuestCodes.PremiumRequired));
            Assert.That(_rules.Board(s, Now).Group(PassGroup).Items[0].PremiumState, Is.EqualTo(QuestItemState.InProgress));
            s = _rules.ActivatePremium(s, PassGroup, Now);
            Assert.That(s.Run(PassGroup).Premium, Is.True);
            QuestClaimResult r = _rules.Claim(s, QuestClaimTarget.Group(PassGroup), Now);
            Assert.That(r.Claimed.Select(c => (c.QuestId, c.Premium)), Is.EquivalentTo(new[] { (Pass1, true), (Pass2, false), (Pass2, true) }), "premium bought later still pays past steps");
            Assert.That(r.State.Run(PassGroup).Paid, Is.EqualTo(new[] { Pass1, Pass2 }));
            Assert.That(_rules.Claim(r.State, QuestClaimTarget.Quest(Pass2, premium: true), Now).Code, Is.EqualTo(QuestCodes.AlreadyClaimed));
            Assert.That(_rules.Claim(r.State, QuestClaimTarget.Quest(DailyRun, premium: true), Now).Code, Is.EqualTo(QuestCodes.BadRequest));
            Assert.That(_rules.ActivatePremium(s, DailyGroup, Now), Is.Null);
        }

        [Test]
        public void PremiumRewardActivatesItsGroup()
        {
            List<QuestRow> rows = Rows();
            rows[0] = new QuestRow(DailyRun, QuestRowKind.Quest, DailyGroup, Run, 3, rewards: new[] { new ConsumeData(Premium, PassGroup, 1) });
            QuestRules rules = Rules(Groups(), rows);
            QuestState s = Record(rules, QuestState.Empty, Now, new QuestEvent(Run, 3));
            QuestClaimResult r = rules.Claim(s, QuestClaimTarget.Quest(DailyRun), Now);
            Assert.That(r.Ok && r.Grants.Count == 0 && r.State.Run(PassGroup).Premium, Is.True);
        }

        [Test]
        public void UnsupportedRewardFailsWholeClaim()
        {
            List<QuestRow> rows = Rows();
            rows[0] = new QuestRow(DailyRun, QuestRowKind.Quest, DailyGroup, Run, 3, rewards: new[] { C(Coins, 1), new ConsumeData(new ConsumeTypeId(5), 103001001, 1) });
            QuestCatalog.Build(Groups(), rows, Kinds(), Policy(), null, out IReadOnlyList<QuestCatalogIssue> issues);
            Assert.That(Codes(issues), Does.Contain("UnsupportedReward"));
            QuestCatalog catalog = QuestCatalog.Build(Groups(), rows, Kinds(), Policy(), null, out _);
            var rules = new QuestRules(catalog, Kinds(), Policy());
            QuestState s = Record(rules, QuestState.Empty, Now, new QuestEvent(Run, 3), new QuestEvent(Upgrade, 2, 7));
            Assert.That(rules.Claim(s, QuestClaimTarget.Quest(DailyRun), Now).Code, Is.EqualTo(QuestCodes.UnsupportedReward));
            QuestClaimResult all = rules.Claim(s, QuestClaimTarget.Tab(1), Now);
            Assert.That((all.Ok, all.Code, all.State), Is.EqualTo((false, QuestCodes.UnsupportedReward, s)));
        }

        [Test]
        public void UnknownTargetsAreRejected()
        {
            Assert.That(_rules.Claim(QuestState.Empty, QuestClaimTarget.Quest(123), Now).Code, Is.EqualTo(QuestCodes.Unknown));
            Assert.That(_rules.Claim(QuestState.Empty, QuestClaimTarget.Group(123), Now).Code, Is.EqualTo(QuestCodes.Unknown));
            Assert.That(_rules.Claim(QuestState.Empty, QuestClaimTarget.Tab(55), Now).Code, Is.EqualTo(QuestCodes.Unknown));
            Assert.That(_rules.Claim(QuestState.Empty, QuestClaimTarget.Completion(DailyGroup), Now).Code, Is.EqualTo(QuestCodes.Unknown), "no completion reward");
            Assert.That(_rules.Claim(QuestState.Empty, QuestClaimTarget.Quest(AchieveGroup), Now).Code, Is.EqualTo(QuestCodes.Unknown), "a group key is not a row id");
        }

        [Test]
        public void BoardSortsAndDots()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Upgrade, 2, 7));
            QuestBoard board = _rules.Board(s, Now);
            Assert.That(board.Groups.Select(g => g.Key).Take(3), Is.EqualTo(new[] { DailyGroup, TrackGroup, LockedGroup }));
            Assert.That(board.Group(DailyGroup).Items.Select(i => i.Id), Is.EqualTo(new[] { DailyUpgrade, DailyRun }), "claimable first");
            Assert.That(board.HasRedDot(1) && board.HasRedDotAny && !board.HasRedDot(4), Is.True);
            Assert.That(board.NextResetMs, Is.EqualTo(At(2026, 11, 11)));
            Assert.That(board.Group(TrackGroup).Items.Select(i => (i.Start, i.Target)), Is.EqualTo(new[] { (0L, 20L), (20L, 40L) }));
            QuestBoardItem upgrade = board.Group(DailyGroup).Items[0];
            Assert.That((upgrade.Condition, upgrade.Remaining, upgrade.Progress01, upgrade.CanClaim), Is.EqualTo((7, 0L, 1f, true)));
            QuestBoardItem run = board.Group(DailyGroup).Items[1];
            Assert.That((run.Remaining, run.Progress01), Is.EqualTo((3L, 0f)));
            s = Claim(_rules, s, QuestClaimTarget.Quest(DailyUpgrade), Now);
            board = _rules.Board(s, Now, key => key != "shop");
            Assert.That(board.Group(DailyGroup).Items.Select(i => i.State), Is.EqualTo(new[] { QuestItemState.InProgress, QuestItemState.Done }));
            Assert.That(board.Group(TrackGroup).Items[0].HasRedDot, Is.True, "20 points open the first track step");
            Assert.That(board.Items(1).Select(i => i.Id).First(), Is.EqualTo(Track1), "tab list: claimable first across groups");
            Assert.That(board.Items(1).Any(i => i.Id == LockedRow), Is.False, "the tab list shows open groups only");
        }

        [Test]
        public void BoardDoesNotChangeState()
        {
            QuestState s = Record(_rules, QuestState.Empty, Now, new QuestEvent(Run, 3));
            string before = QuestStateJson.Write(s).ToString();
            QuestBoard board = _rules.Board(s, At(2026, 11, 12));
            Assert.That(board.Group(DailyGroup).Items.All(i => i.Current == 0), Is.True, "the board shows the rolled day");
            Assert.That(QuestStateJson.Write(s).ToString(), Is.EqualTo(before));
        }
    }
}
