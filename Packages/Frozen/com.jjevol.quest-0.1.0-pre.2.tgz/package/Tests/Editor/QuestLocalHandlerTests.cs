using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using PlatformLibrary.Network;
using jjevol.Quest.Network;
using static jjevol.Quest.Tests.QuestTestKit;

namespace jjevol.Quest.Tests
{
    public sealed class QuestLocalHandlerTests
    {
        private DataRepository _repository;
        private QuestStateContainer _quests;
        private ResourceService _resources;
        private long _now;
        private QuestLocalHandler _handler;

        private sealed class FixtureWealthTable : WealthTable
        {
            public override void LoadDatas() { _DataClear(); InsertData(TSVRow.FromTsv("id\ttype\tactive\n1001001\tcoins\t1\n1001002\tgems\t1")); }
            public override Task LoadDatasAsync() { LoadDatas(); return Task.CompletedTask; }
        }

        [SetUp]
        public void SetUp()
        {
            _repository = new DataRepository("quest-handler:" + Guid.NewGuid().ToString("N"));
            _repository.Register(new WealthContainer());
            _repository.Register(_quests = new QuestStateContainer());
            _repository.ImportJson(new JObject
            {
                [WealthContainer.PayloadKey] = new JArray(
                    new JObject { [WealthContainer.TypeKey] = "coins", [WealthContainer.QuantityKey] = 5 },
                    new JObject { [WealthContainer.TypeKey] = "gems", [WealthContainer.QuantityKey] = 0 }),
            }, WealthContainer.PayloadKey);
            var table = new FixtureWealthTable();
            table.LoadDatas();
            _resources = new ResourceService(_repository, table, WealthKind);
            _now = Now;
            _handler = new QuestLocalHandler(Rules(), _quests, new WealthQuestGrantWriter(_resources), () => _now, key => key != "shop");
        }

        [TearDown]
        public void TearDown()
        {
            _resources?.Dispose();
            _repository?.Dispose();
        }

        private static Dictionary<string, object> Params(params (string, object)[] values) => values.ToDictionary(v => v.Item1, v => v.Item2);
        private void Apply(JObject response, params string[] keys) => _repository.UpdateJson(response, keys);

        [Test]
        public void RecordFromClientParameters()
        {
            var ev = new List<Dictionary<string, object>> { new Dictionary<string, object> { ["t"] = Run, ["v"] = 2 }, new Dictionary<string, object> { ["t"] = Upgrade, ["c"] = 7, ["v"] = 1 } };
            JObject response = _handler.HandleRecord(Params(("ev", ev)));
            Apply(response, QuestStateJson.DefaultKey);
            Assert.That(_quests.Current.Slot(Daily).Counter("1"), Is.EqualTo(2));
            Assert.That(_quests.Current.Slot(Daily).Counter("3:7"), Is.EqualTo(1));
        }

        [Test]
        public void RecordRejections()
        {
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleRecord(Params())).Code, Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleRecord(Params(("ev", new JArray())))).Code, Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleRecord(Params(("ev", JArray.Parse("[{\"t\":1,\"v\":\"2\"}]"))))).Code, Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleRecord(Params(("ev", QuestLocalHandler.WriteEvents(new[] { new QuestEvent(ServerOnly, 1) }))))).Code, Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleRecord(Params(("ev", QuestLocalHandler.WriteEvents(new[] { new QuestEvent(DayPoint, 1) }))))).Code, Is.EqualTo(QuestCodes.BadEvent));
        }

        [Test]
        public void ClaimPaysWealthAndState()
        {
            Apply(_handler.HandleRecord(Params(("ev", QuestLocalHandler.WriteEvents(new[] { new QuestEvent(Run, 3) })))), QuestStateJson.DefaultKey);
            JObject response = _handler.HandleClaim(Params(("id", DailyRun)));
            Assert.That(response[QuestLocalHandler.RewardsKey].Count(), Is.EqualTo(2));
            Apply(response, QuestStateJson.DefaultKey, WealthContainer.PayloadKey);
            Assert.That(_resources.GetRaw(Coins), Is.EqualTo(105));
            Assert.That(_resources.GetRaw(Gems), Is.EqualTo(0));
            Assert.That(_quests.Current.Run(DailyGroup).IsClaimed(DailyRun), Is.True);
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("id", DailyRun)))).Code, Is.EqualTo(QuestCodes.AlreadyClaimed));
        }

        [Test]
        public void ClaimRejections()
        {
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("id", 1), ("group", 2)))).Code, Is.EqualTo(QuestCodes.BadRequest));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("tab", 1), ("premium", true)))).Code, Is.EqualTo(QuestCodes.BadRequest));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("id", "x")))).Code, Is.EqualTo(QuestCodes.BadRequest));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("id", DailyRun)))).Code, Is.EqualTo(QuestCodes.NotDone));
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("id", 5)))).Code, Is.EqualTo(QuestCodes.Unknown));
            Apply(_handler.HandleRecord(Params(("ev", QuestLocalHandler.WriteEvents(new[] { new QuestEvent(Run, 1) })))), QuestStateJson.DefaultKey);
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("id", LockedRow)))).Code, Is.EqualTo(QuestCodes.Locked));
            var noWriter = new QuestLocalHandler(Rules(), _quests, null, () => _now);
            Apply(_handler.HandleRecord(Params(("ev", QuestLocalHandler.WriteEvents(new[] { new QuestEvent(Run, 2) })))), QuestStateJson.DefaultKey);
            Assert.That(Assert.Throws<NetworkRejection>(() => noWriter.HandleClaim(Params(("id", DailyRun)))).Code, Is.EqualTo(QuestCodes.UnsupportedReward));
        }

        [Test]
        public void AppendProgressJoinsAnotherResponse()
        {
            var response = new JObject { ["other"] = 1 };
            Assert.That(_handler.AppendProgress(response, new[] { new QuestEvent(Run, 2) }), Is.Null);
            Assert.That(_handler.AppendProgress(response, new[] { new QuestEvent(Run, 1) }), Is.Null, "the second append continues from the state in the response");
            Assert.That(response["other"].Value<int>(), Is.EqualTo(1));
            Apply(response, QuestStateJson.DefaultKey);
            Assert.That(_quests.Current.Slot(Daily).Counter("1"), Is.EqualTo(3));
            var rejected = new JObject();
            Assert.That(_handler.AppendProgress(rejected, new[] { new QuestEvent(ServerOnly, 4) }, QuestSource.Client), Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(rejected.Count, Is.Zero);
            Assert.Throws<InvalidOperationException>(() => _handler.AppendProgress(new JObject { [QuestStateJson.DefaultKey] = new JObject { ["groups"] = 1 } }, new[] { new QuestEvent(Run, 1) }), "a bad carried state is a bug");
        }

        [Test]
        public void AppendRewardsCountsPointsAndPremium()
        {
            var response = new JObject();
            Assert.That(_handler.AppendRewards(response, new[] { P(30), new ConsumeData(Premium, PassGroup, 1) }), Is.Null);
            Apply(response, QuestStateJson.DefaultKey);
            Assert.That(_quests.Current.Slot(Daily).Counter(DayPoint.ToString()), Is.EqualTo(30));
            Assert.That(_quests.Current.Run(PassGroup).Premium, Is.True);
            Assert.That(response[QuestLocalHandler.RewardsKey], Is.Null, "paid elsewhere: no popup rows");
        }

        [Test]
        public void TimeComesFromTheClock()
        {
            Apply(_handler.HandleRecord(Params(("ev", QuestLocalHandler.WriteEvents(new[] { new QuestEvent(Run, 3) })))), QuestStateJson.DefaultKey);
            _now = At(2026, 11, 11, 1);
            Assert.That(Assert.Throws<NetworkRejection>(() => _handler.HandleClaim(Params(("id", DailyRun)))).Code, Is.EqualTo(QuestCodes.NotDone));
        }

        [Test]
        public void EventsRoundTrip()
        {
            QuestEvent[] events = { new QuestEvent(Run, 2), new QuestEvent(Upgrade, 1, 7) };
            QuestEvent[] back = QuestLocalHandler.ParseEvents(Params(("ev", QuestLocalHandler.WriteEvents(events))));
            Assert.That(back.Select(e => (e.Type, e.Condition, e.Amount)), Is.EqualTo(events.Select(e => (e.Type, e.Condition, e.Amount))));
        }

        private sealed class FailingWriter : IQuestGrantWriter
        {
            public void Write(JObject response, IReadOnlyList<ConsumeData> grants) => throw new InvalidOperationException("cannot pay");
        }

        [Test]
        public void WriterFailureIsARejection()
        {
            Apply(_handler.HandleRecord(Params(("ev", QuestLocalHandler.WriteEvents(new[] { new QuestEvent(Run, 3) })))), QuestStateJson.DefaultKey);
            var handler = new QuestLocalHandler(Rules(), _quests, new FailingWriter(), () => _now);
            Assert.That(Assert.Throws<NetworkRejection>(() => handler.HandleClaim(Params(("id", DailyRun)))).Code, Is.EqualTo(QuestCodes.UnsupportedReward));
            Assert.That(_quests.Current.Run(DailyGroup)?.IsClaimed(DailyRun) ?? false, Is.False);
        }

        [Test]
        public void GrantWriterAddsOntoRowsInTheResponse()
        {
            var writer = new WealthQuestGrantWriter(_resources);
            var response = new JObject { [WealthContainer.PayloadKey] = new JArray(new JObject { [WealthContainer.TypeKey] = "coins", [WealthContainer.QuantityKey] = 50 }) };
            writer.Write(response, new[] { C(Coins, 10), C(Gems, 2) });
            var rows = (JArray)response[WealthContainer.PayloadKey];
            Assert.That(rows.Select(r => ((string)r[WealthContainer.TypeKey], r[WealthContainer.QuantityKey].Value<long>())), Is.EquivalentTo(new[] { ("coins", 60L), ("gems", 2L) }), "the row another handler wrote is the base");
            Assert.Throws<InvalidOperationException>(() => writer.Write(new JObject { [WealthContainer.PayloadKey] = 1 }, new[] { C(Coins, 1) }));
        }

        [Test]
        public void GrantWriterRejectsOtherKinds()
        {
            var writer = new WealthQuestGrantWriter(_resources);
            Assert.Throws<InvalidOperationException>(() => writer.Write(new JObject(), new[] { new ConsumeData(new ConsumeTypeId(9), Coins, 1) }));
            Assert.Throws<InvalidOperationException>(() => writer.Write(new JObject(), new[] { C(999, 1) }));
            var empty = new JObject();
            writer.Write(empty, Array.Empty<ConsumeData>());
            Assert.That(empty.Count, Is.Zero);
        }
    }
}
