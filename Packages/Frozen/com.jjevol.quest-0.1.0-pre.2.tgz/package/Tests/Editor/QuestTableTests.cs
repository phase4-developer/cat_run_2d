using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using jjevol.Quest.Editor;
using static jjevol.Quest.Tests.QuestTestKit;

namespace jjevol.Quest.Tests
{
    public sealed class QuestTableTests
    {
        private const string GroupTsv =
            "id\tname\ttab\tperiodType\tgroupType\tprogressScope\tsort\tactive\topenKey\tnameKey\tpremium\trequireGroupId\tselectionCount\tautoClaim\tcycleKey\tcompleteRewardType\tcompleteRewardId\tcompleteRewardValue\n" +
            "440001001\t일일\t1\t2\t1\t3\t1\t1\t\t\t\t\t\t\t\t\t\t\n" +
            "440004001\t업적\t4\t0\t2\t1\t\t1\t\tquest_group_achieve\t\t\t\t\t\t1\t1001002\t5\n" +
            "440100001\t패스\t100\t0\t3\t1\t\t1\t\t\t1\t\t\t\t\t\t\t\n";

        private const string QuestTsv =
            "id\tname\tquestGroupId\tclearType\tclearCondition\tclearValue\tclearValueStep\tstep\tsort\tactive\trewardType\trewardId\trewardValue\n" +
            "441001001\t달리기\t440001001\t1\t\t3\t\t\t\t1\t1;300\t1001001;0\t100;20\n" +
            "441001002\t꺼짐\t440001001\t1\t\t5\t\t\t\t\t\t\t\n";

        private const string PassTsv =
            "id\tquestGroupId\tclearType\tclearValue\tstep\tactive\trewardType_1\trewardId_1\trewardValue_1\trewardType_2\trewardId_2\trewardValue_2\trewardType_3\trewardId_3\trewardValue_3\tpremiumRewardType\tpremiumRewardId\tpremiumRewardValue\n" +
            "442100001\t440100001\t4\t1\t1\t1\t1\t1001001\t10\t\t\t\t1\t1001002\t3\t1\t1001002\t1\n";

        private const string AchieveTsv =
            "id\tquestGroupId\tclearType\tclearValue\tstep\tactive\trewardType\trewardId\trewardValue\n" +
            "443004001\t440004001\t2\t100\t1\t1\t1\t1001002\t1\n" +
            "443004002\t440004001\t2\t200\t2\t1\t1\t1001002\t2\n";

        private static readonly Dictionary<string, string> Tables = new Dictionary<string, string>
        {
            ["440_questGroup"] = GroupTsv, ["441_quest"] = QuestTsv, ["442_passQuest"] = PassTsv, ["443_achievement"] = AchieveTsv,
        };

        private sealed class FixtureSource : ITableSource
        {
            private readonly Dictionary<string, string> _tables;
            public FixtureSource(Dictionary<string, string> tables) => _tables = tables;
            public bool RequiresRemoteUpdate => false;
            public bool HasTable(string tableName) => _tables.ContainsKey(tableName);
            public List<TSVRow> Load(string tableName) => TSVRow.FromTsv(_tables[tableName]);
            public Task<List<TSVRow>> LoadAsync(string tableName) => Task.FromResult(Load(tableName));
        }

        private static IReadOnlyList<TSVRow> RowsOf(string table) => Tables.TryGetValue(table, out string tsv) ? TSVRow.FromTsv(tsv) : null;

        [Test]
        public void GroupRowReadsColumns()
        {
            List<TSVRow> rows = TSVRow.FromTsv(GroupTsv);
            var daily = new QuestGroupRow(rows[0]);
            Assert.That((daily.Key, daily.Tab, daily.Period, daily.GroupType, daily.Scope, daily.Active, daily.HasOwnNameKey), Is.EqualTo((DailyGroup, 1, QuestPeriod.Daily, QuestGroupType.List, QuestScope.Period, true, false)));
            Assert.That((daily.SharedSlot, daily.Premium, daily.RequireGroup, daily.SelectionCount, daily.AutoClaim, daily.HasCompletion), Is.EqualTo(("daily", false, 0, 0, false, false)));
            var achieve = new QuestGroupRow(rows[1]);
            Assert.That((achieve.SharedSlot, achieve.HasOwnNameKey), Is.EqualTo(("lifetime", true)));
            Assert.That(achieve.CompleteRewards.Select(r => (r.ItemId, r.Quantity)), Is.EqualTo(new[] { (Gems, 5L) }));
            var pass = new QuestGroupRow(rows[2]);
            Assert.That((pass.Premium, pass.GroupType), Is.EqualTo((true, QuestGroupType.Track)));
            var cycle = new QuestGroupRow(Row("id\ttab\tperiodType\tgroupType\tprogressScope\tcycleKey\trequireGroupId\tselectionCount\tautoClaim", "7\t1\t16\t1\t3\t\t3\t2\t1"));
            Assert.That((cycle.CycleKey, cycle.SharedSlot, cycle.RequireGroup, cycle.SelectionCount, cycle.AutoClaim), Is.EqualTo(("season", "cycle.season", 3, 2, true)), "an empty cycleKey is season");
            Assert.That(new QuestGroupRow(Row("id\ttab\tperiodType\tgroupType\tprogressScope", "8\t1\t2\t1\t2")).SharedSlot, Is.Null, "run scope reads no shared slot");
        }

        [Test]
        public void RowReadsScalarListsAndBlankActive()
        {
            List<TSVRow> rows = TSVRow.FromTsv(QuestTsv);
            var run = new QuestRow(rows[0], QuestRowKind.Quest);
            Assert.That((run.Group, run.ClearType, run.ClearValue, run.Active), Is.EqualTo((DailyGroup, Run, 3L, true)));
            Assert.That(run.Rewards.Select(r => (r.TypeId.Value, r.ItemId, r.Quantity)), Is.EqualTo(new[] { (1, Coins, 100L), (Point.Value, 0, 20L) }));
            var off = new QuestRow(rows[1], QuestRowKind.Quest);
            Assert.That(off.Active, Is.False, "an empty active cell is 0");
            Assert.That(off.Rewards, Is.Empty);
            Assert.That(new QuestRow(Row("id\tquestGroupId\tclearType\tclearValue", "1\t2\t3\t4"), QuestRowKind.Quest).Active, Is.True, "no active column means active");
        }

        [Test]
        public void NumberedRewardsStopAtFirstBlank()
        {
            var pass = new QuestRow(TSVRow.FromTsv(PassTsv)[0], QuestRowKind.Pass);
            Assert.That(pass.Rewards.Select(r => (r.ItemId, r.Quantity)), Is.EqualTo(new[] { (Coins, 10L) }));
            Assert.That(pass.PremiumRewards.Select(r => (r.ItemId, r.Quantity)), Is.EqualTo(new[] { (Gems, 1L) }));
            Assert.That(new QuestRow(TSVRow.FromTsv(PassTsv)[0], QuestRowKind.Quest).PremiumRewards, Is.Empty, "premium is read from the pass table only");
        }

        [Test]
        public void LayoutConvertsCodesAndColumns()
        {
            var layout = new QuestTableLayout { GroupKeyColumn = "group", GroupColumn = "questGroup", StepColumn = "progress", Period = v => v == 3 ? (int)QuestPeriod.Monthly : v };
            var group = new QuestGroupRow(Row("id\tgroup\ttab\tperiodType\tgroupType\tprogressScope", "5\t70\t1\t3\t1\t3"), layout);
            Assert.That((group.id, group.Key, group.Period), Is.EqualTo((5, 70, QuestPeriod.Monthly)));
            var row = new QuestRow(Row("id\tquestGroup\tclearType\tclearValue\tprogress", "6\t70\t1\t2\t4"), QuestRowKind.Achievement, layout);
            Assert.That((row.Group, row.Step), Is.EqualTo((70, 4)));
        }

        [Test]
        public void LayoutTakesAnyRowTables()
        {
            var layout = new QuestTableLayout
            {
                RowTables = new[] { new QuestRowSource("412_start", QuestRowKind.Quest), new QuestRowSource("441_quest", QuestRowKind.Quest), new QuestRowSource("442_passQuest", QuestRowKind.Pass) },
            };
            var tables = new Dictionary<string, string>(Tables)
            {
                ["412_start"] = "id\tquestGroupId\tclearType\tclearValue\tactive\n441001009\t440001001\t1\t9\t1\n",
            };
            QuestCatalog catalog = QuestCatalog.Build(new FixtureSource(tables), Kinds(), Policy(), null, out IReadOnlyList<QuestCatalogIssue> issues, layout);
            Assert.That(Codes(issues), Is.EqualTo(new[] { "CompletionNeverDone" }), "the achievement group keeps its completion reward without its table");
            Assert.That(catalog.Row(441001009), Is.Not.Null);
            Assert.That(catalog.Row(443004001), Is.Null, "the achievement table is not in this layout");
            Assert.That(QuestTableAuthoring.Schemas(layout).Select(x => x.TableName), Is.EqualTo(new[] { "440_questGroup", "412_start", "441_quest", "442_passQuest" }));
        }

        [Test]
        public void BuildFromSourceReadsAllFourTables()
        {
            QuestCatalog catalog = QuestCatalog.Build(new FixtureSource(Tables), Kinds(), Policy(), null, out IReadOnlyList<QuestCatalogIssue> issues);
            Assert.That(Codes(issues), Is.Empty, string.Join("\n", issues));
            Assert.That(catalog.Row(442100001)?.Kind, Is.EqualTo(QuestRowKind.Pass));
            Assert.That(catalog.Rows(AchieveGroup).Select(r => r.id), Is.EqualTo(new[] { 443004001, 443004002 }));
            Assert.That(catalog.Row(441001002), Is.Null, "inactive rows are left out");
            Assert.That(catalog.SharedSlots, Is.EquivalentTo(new[] { "lifetime", "daily" }));
            Assert.That(catalog.Group(AchieveGroup).HasCompletion, Is.True);
            var partial = new Dictionary<string, string> { ["440_questGroup"] = GroupTsv };
            QuestCatalog.Build(new FixtureSource(partial), Kinds(), Policy(), null, out issues);
            Assert.That(Codes(issues), Is.EqualTo(new[] { "CompletionNeverDone" }), "missing row tables are empty; the achievement group then has a completion reward and no row");
        }

        [Test]
        public void SchemasCoverTheFourTables()
        {
            IReadOnlyList<TableSchema> schemas = QuestTableAuthoring.Schemas();
            Assert.That(schemas.Select(s => s.TableName), Is.EqualTo(new[] { "440_questGroup", "441_quest", "442_passQuest", "443_achievement" }));
            TableColumnRule Col(int table, string name) => schemas[table].Columns.SingleOrDefault(c => c.Name == name);
            Assert.That(Col(1, "questGroupId").Required && Col(1, "clearValue").Kind == TableColumnKind.Int64, Is.True);
            Assert.That(Col(1, "step").Required, Is.False);
            Assert.That(Col(2, "step").Required && Col(3, "step").Required, Is.True);
            Assert.That(Col(1, "clearValueStep"), Is.Not.Null);
            Assert.That(Col(2, "clearValueStep"), Is.Null);
            Assert.That(Col(2, "premiumRewardType"), Is.Not.Null);
            Assert.That(Col(1, "premiumRewardType"), Is.Null);
            Assert.That(schemas.SelectMany(s => s.Columns).Any(c => c.Name == "name"), Is.False, "name is a common column of tables.authoring");
            Assert.That(QuestTableAuthoring.Schemas(new QuestTableLayout { GroupColumn = "g" })[1].Columns.Any(c => c.Name == "g"), Is.True);
            Assert.That(new[] { "premium", "requireGroupId", "selectionCount", "autoClaim", "cycleKey", "completeRewardType" }.All(n => Col(0, n) != null), Is.True);
            Assert.That(QuestTableAuthoring.Schemas(new QuestTableLayout { GroupKeyColumn = "group" })[0].Columns.Single(c => c.Name == "group").Required, Is.True);
        }

        [Test]
        public void CheckReadsRowsByTableName()
        {
            Assert.That(QuestTableAuthoring.Check(RowsOf, Kinds(), Policy()).Where(i => i.Severity == QuestIssueSeverity.Error), Is.Empty);
            Assert.That(QuestTableAuthoring.Check(_ => null, Kinds(), Policy()), Is.Empty, "no group table: nothing to check");
            var broken = new Dictionary<string, string>(Tables) { ["441_quest"] = QuestTsv.Replace("440001001\t1\t\t3", "440009999\t1\t\t3") };
            IReadOnlyList<QuestCatalogIssue> issues = QuestTableAuthoring.Check(t => broken.TryGetValue(t, out string tsv) ? TSVRow.FromTsv(tsv) : null, Kinds(), Policy());
            Assert.That(Codes(issues), Is.EqualTo(new[] { "MissingGroup" }));
            Assert.That(issues[0].RowId, Is.EqualTo(441001001));
        }

        private static List<QuestGroupRow> G(params QuestGroupRow[] extra) => Groups().Concat(extra).ToList();
        private static List<QuestRow> R(params QuestRow[] extra) => Rows().Concat(extra).ToList();
        private static QuestRow Q(int id, int group, int type = Run, long value = 1, int condition = 0, long repeat = 0, int step = 0, QuestRowKind kind = QuestRowKind.Quest, jjevol.ConsumeData reward = null, jjevol.ConsumeData premium = null)
            => new QuestRow(id, kind, group, type, value, condition, repeat, step, rewards: reward == null ? null : new[] { reward }, premiumRewards: premium == null ? null : new[] { premium });

        private static QuestGroupRow GR(int key, QuestPeriod period = QuestPeriod.Daily, QuestGroupType type = QuestGroupType.List, QuestScope scope = QuestScope.Period,
            bool active = true, string cycle = null, bool premium = false, int require = 0, int select = 0, bool auto = false, jjevol.ConsumeData complete = null)
            => new QuestGroupRow(key, 1, period, type, scope, active: active, cycleKey: cycle, premium: premium, requireGroup: require, selectionCount: select, autoClaim: auto,
                completeRewards: complete == null ? null : new[] { complete });

        private static IEnumerable<TestCaseData> IssueCases()
        {
            yield return new TestCaseData(G(GR(DailyGroup)), R(), "DuplicateId").SetName("IssueDuplicateId");
            yield return new TestCaseData(G(), R(Q(DailyRun, DailyGroup)), "DuplicateId").SetName("IssueDuplicateId2");
            yield return new TestCaseData(G(GR(1, period: (QuestPeriod)1)), R(), "BadPeriod").SetName("IssueBadPeriod");
            yield return new TestCaseData(G(GR(1, type: (QuestGroupType)9)), R(), "BadGroupType").SetName("IssueBadGroupType");
            yield return new TestCaseData(G(GR(1, scope: (QuestScope)0)), R(), "BadScope").SetName("IssueBadScope");
            yield return new TestCaseData(G(GR(1, period: QuestPeriod.None)), R(), "ScopeWithoutPeriod").SetName("IssueScopeWithoutPeriod");
            yield return new TestCaseData(G(GR(1, period: QuestPeriod.Cycle)), R(), "NoCycleSource").SetName("IssueNoCycleSource");
            yield return new TestCaseData(G(GR(1, period: QuestPeriod.Cycle, cycle: "a-b")), R(), "BadCycleKey").SetName("IssueBadCycleKey");
            yield return new TestCaseData(G(GR(1, premium: true)), R(), "PremiumNotTrack").SetName("IssuePremiumNotTrack");
            yield return new TestCaseData(G(GR(1, select: -1)), R(), "BadSelection").SetName("IssueBadSelection");
            yield return new TestCaseData(G(GR(1, type: QuestGroupType.Track, select: 1)), R(), "SelectionNotList").SetName("IssueSelectionNotList");
            yield return new TestCaseData(G(GR(1, select: 1)), R(Q(2, 1)), "SelectionTooLarge").SetName("IssueSelectionTooLarge");
            yield return new TestCaseData(G(GR(1, type: QuestGroupType.Track, premium: true, auto: true)), R(), "AutoClaimPremium").SetName("IssueAutoClaimPremium");
            yield return new TestCaseData(G(GR(1, type: QuestGroupType.Track, premium: true, complete: C(Coins, 1))), R(), "CompletionOnPremium").SetName("IssueCompletionOnPremium");
            yield return new TestCaseData(G(GR(1, complete: C(Coins, 1))), R(Q(2, 1, repeat: 1)), "CompletionNeverDone").SetName("IssueCompletionNeverDone");
            yield return new TestCaseData(G(GR(1, complete: C(Coins, 0))), R(Q(2, 1)), "BadReward").SetName("IssueBadCompletionReward");
            yield return new TestCaseData(G(GR(1, require: 1)), R(), "RequireSelf").SetName("IssueRequireSelf");
            yield return new TestCaseData(G(GR(1, require: 77)), R(), "MissingRequire").SetName("IssueMissingRequire");
            yield return new TestCaseData(G(), R(Q(1, 5)), "MissingGroup").SetName("IssueMissingGroup");
            yield return new TestCaseData(G(GR(1, active: false)), R(Q(2, 1)), "InactiveGroup").SetName("IssueInactiveGroup");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, type: 77)), "UnknownClearType").SetName("IssueUnknownClearType");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, condition: 3)), "ConditionNotUsed").SetName("IssueConditionNotUsed");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, type: Upgrade, condition: -1)), "BadCondition").SetName("IssueBadCondition");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, value: 0)), "BadClearValue").SetName("IssueBadClearValue");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, repeat: -1)), "BadStep").SetName("IssueBadStep");
            yield return new TestCaseData(G(), R(Q(1, AchieveGroup, kind: QuestRowKind.Achievement, step: 3, type: Best, value: 300, repeat: 5)), "RepeatNotAllowed").SetName("IssueRepeatNotAllowed");
            yield return new TestCaseData(G(GR(1, period: QuestPeriod.None, scope: QuestScope.Lifetime)), R(Q(2, 1, repeat: 2)), "RepeatNotAllowed").SetName("IssueRepeatWithoutPeriod");
            yield return new TestCaseData(G(GR(1, auto: true)), R(Q(2, 1, repeat: 2)), "RepeatNotAllowed").SetName("IssueRepeatAutoClaim");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, premium: C(Coins, 1))), "PremiumOutsideGroup").SetName("IssuePremiumOutsideGroup");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, reward: C(Coins, 0))), "BadReward").SetName("IssueBadReward");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, reward: new jjevol.ConsumeData(Premium, DailyGroup, 1))), "UnknownPremium").SetName("IssueUnknownPremium");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, reward: new jjevol.ConsumeData(new jjevol.ConsumeTypeId(5), 1, 1))), "UnsupportedReward").SetName("IssueUnsupportedReward");
            yield return new TestCaseData(G(), R(Q(1, DailyGroup, reward: new jjevol.ConsumeData(new jjevol.ConsumeTypeId(301), 0, 5))), "UnsupportedReward").SetName("IssueUnregisteredPoint");
            yield return new TestCaseData(G(), R(Q(1, AchieveGroup, kind: QuestRowKind.Achievement, type: Best, value: 300)), "MissingStep").SetName("IssueMissingStep");
            yield return new TestCaseData(G(), R(Q(1, AchieveGroup, kind: QuestRowKind.Achievement, type: Best, value: 300, step: 2)), "RepeatedStep").SetName("IssueRepeatedStep");
            yield return new TestCaseData(G(), R(Q(1, AchieveGroup, kind: QuestRowKind.Achievement, type: Run, value: 300, step: 3)), "MixedCounter").SetName("IssueMixedCounter");
            yield return new TestCaseData(G(), R(Q(1, AchieveGroup, kind: QuestRowKind.Achievement, type: Best, value: 150, step: 3)), "NotIncreasing").SetName("IssueNotIncreasing");
            yield return new TestCaseData(G(), R(Q(1, PassGroup, kind: QuestRowKind.Pass, type: Level, value: 1, step: 3)), "NotIncreasing").SetName("IssueNotIncreasingPass");
            yield return new TestCaseData(G(), R(Q(1, PassGroup, kind: QuestRowKind.Pass, type: Run, value: 5, step: 3)), "MixedCounter").SetName("IssueMixedCounterPass");
            yield return new TestCaseData(G(GR(0)), R(), "BadGroupKey").SetName("IssueBadGroupKey");
            yield return new TestCaseData(G(GR(1, select: 1)), R(Q(2, 1), Q(3, 1, repeat: 1)), "RepeatNotAllowed").SetName("IssueRepeatInSelection");
            yield return new TestCaseData(G(GR(1), GR(4, require: 1)), R(Q(2, 1, repeat: 1)), "RequireNeverDone").SetName("IssueRequireNeverDone");
        }

        [Test]
        public void DuplicateKeyFromAnotherColumn()
        {
            var layout = new QuestTableLayout { GroupKeyColumn = "group" };
            var groups = new List<QuestGroupRow>
            {
                new QuestGroupRow(Row("id\tgroup\ttab\tperiodType\tgroupType\tprogressScope", "1\t9\t1\t2\t1\t3"), layout),
                new QuestGroupRow(Row("id\tgroup\ttab\tperiodType\tgroupType\tprogressScope", "2\t9\t1\t2\t1\t3"), layout),
            };
            Assert.That(Codes(Issues(groups, new List<QuestRow>())), Is.EqualTo(new[] { "DuplicateKey" }));
        }

        [Test]
        public void PointNeverPaidIsAWarning()
        {
            List<QuestRow> rows = Rows().Where(r => r.id != DailyRun && r.id != DailyUpgrade).ToList();
            IReadOnlyList<QuestCatalogIssue> issues = Issues(Groups(), rows);
            Assert.That(issues.Single().Code, Is.EqualTo("PointNeverPaid"));
            Assert.That(issues.Single().Severity, Is.EqualTo(QuestIssueSeverity.Warning), "ApplyRewards can still raise it");
        }

        [TestCaseSource(nameof(IssueCases))]
        public void CatalogReportsIssue(List<QuestGroupRow> groups, List<QuestRow> rows, string code)
        {
            Assert.That(Codes(Issues(groups, rows)), Does.Contain(code));
        }

        [Test]
        public void ExampleTablesHaveNoIssues()
        {
            Assert.That(Issues(Groups(), Rows()), Is.Empty);
        }
    }
}
