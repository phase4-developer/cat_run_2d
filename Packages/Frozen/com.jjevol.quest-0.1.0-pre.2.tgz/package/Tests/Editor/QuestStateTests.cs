using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using static jjevol.Quest.Tests.QuestTestKit;

namespace jjevol.Quest.Tests
{
    public sealed class QuestStateTests
    {
        private readonly List<DataRepository> _repositories = new List<DataRepository>();

        [TearDown]
        public void TearDown()
        {
            foreach (DataRepository r in _repositories) r.Dispose();
            _repositories.Clear();
        }

        private static QuestState Sample()
        {
            QuestRules rules = Rules();
            QuestState s = Record(rules, QuestState.Empty.WithSeed(5), Now, new QuestEvent(Run, 16), new QuestEvent(Upgrade, 2, 7), new QuestEvent(Level, 1));
            s = Claim(rules, s, QuestClaimTarget.Quest(DailyRun), Now);
            s = Claim(rules, s, QuestClaimTarget.Quest(MonthlyRepeat), Now);
            s = Claim(rules, s, QuestClaimTarget.Quest(Pass1), Now);
            return rules.ActivatePremium(s, PassGroup, Now);
        }

        [Test]
        public void JsonRoundTrips()
        {
            QuestState s = Sample();
            JObject doc = QuestStateJson.Write(s);
            Assert.That(doc["seed"].Value<int>(), Is.EqualTo(5));
            Assert.That(doc["cnt"]["daily"]["period"].Value<int>(), Is.EqualTo(20261110));
            Assert.That(doc["cnt"]["lifetime"]["v"]["1"].Value<long>(), Is.EqualTo(16));
            JToken daily = doc["groups"][DailyGroup.ToString()];
            Assert.That((daily["period"].Value<int>(), daily["since"].Value<long>()), Is.EqualTo((20261110, Now)));
            Assert.That(daily["got"].ToObject<int[]>(), Is.EqualTo(new[] { DailyRun }));
            Assert.That(doc["groups"][MonthlyGroup.ToString()]["n"][MonthlyRepeat.ToString()].Value<int>(), Is.EqualTo(1));
            JToken pass = doc["groups"][PassGroup.ToString()];
            Assert.That((pass["premium"].Value<bool>(), pass["got"].ToObject<int[]>()[0], pass["fin"].Value<bool>()), Is.EqualTo((true, Pass1, false)));
            QuestState back = QuestStateJson.Read(doc);
            Assert.That(JToken.DeepEquals(QuestStateJson.Write(back), doc), Is.True);
            Assert.That(QuestStateJson.Response(s, "q")["q"], Is.Not.Null);
        }

        [TestCase("{\"hourly\":{}}", TestName = "ReadRejectsUnknownKey")]
        [TestCase("{\"cnt\":[]}", TestName = "ReadRejectsCountersArray")]
        [TestCase("{\"cnt\":{\"hourly\":{\"period\":1}}}", TestName = "ReadRejectsUnknownSlot")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":\"x\"}}}", TestName = "ReadRejectsTextPeriod")]
        [TestCase("{\"cnt\":{\"daily\":{\"v\":{}}}}", TestName = "ReadRejectsMissingPeriod")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":1,\"x\":1}}}", TestName = "ReadRejectsUnknownSlotKey")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":1,\"v\":{\"a\":1}}}}", TestName = "ReadRejectsTextCounterKey")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":1,\"v\":{\"1:2:3\":1}}}}", TestName = "ReadRejectsThreePartKey")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":1,\"v\":{\"1\":-1}}}}", TestName = "ReadRejectsNegativeCounter")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":1,\"v\":{\"1\":1.5}}}}", TestName = "ReadRejectsFractionCounter")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":1,\"v\":{\"1:0\":1}}}}", TestName = "ReadRejectsZeroConditionKey")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":1,\"v\":{\"01\":1}}}}", TestName = "ReadRejectsLeadingZeroKey")]
        [TestCase("{\"cnt\":{\"cycle.a b\":{\"period\":1}}}", TestName = "ReadRejectsBadCycleSlot")]
        [TestCase("{\"groups\":[]}", TestName = "ReadRejectsGroupsArray")]
        [TestCase("{\"groups\":{\"g\":{\"period\":1,\"since\":0}}}", TestName = "ReadRejectsTextGroupKey")]
        [TestCase("{\"groups\":{\"05\":{\"period\":1,\"since\":0}}}", TestName = "ReadRejectsLeadingZeroGroupKey")]
        [TestCase("{\"groups\":{\"5\":{\"since\":0}}}", TestName = "ReadRejectsMissingRunPeriod")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1}}}", TestName = "ReadRejectsMissingSince")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":-1}}}", TestName = "ReadRejectsNegativeSince")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"got\":[1,1]}}}", TestName = "ReadRejectsRepeatedClaim")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"got\":{}}}}", TestName = "ReadRejectsClaimObject")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"n\":{\"x\":1}}}}", TestName = "ReadRejectsTextRepeatId")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"n\":{\"5\":-1}}}}", TestName = "ReadRejectsNegativeRepeat")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"premium\":1}}}", TestName = "ReadRejectsNumberPremium")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"paid\":[\"a\"]}}}", TestName = "ReadRejectsTextPaidId")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"fin\":\"yes\"}}}", TestName = "ReadRejectsTextFin")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"other\":1}}}", TestName = "ReadRejectsUnknownRunKey")]
        [TestCase("{\"seed\":\"x\"}", TestName = "ReadRejectsTextSeed")]
        [TestCase("{\"cnt\":{\"lifetime\":{\"period\":5}}}", TestName = "ReadRejectsLifetimePeriod")]
        [TestCase("{\"cnt\":{\"daily\":{\"period\":-1}}}", TestName = "ReadRejectsNegativePeriod")]
        [TestCase("{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"n\":{\"5\":null}}}}", TestName = "ReadRejectsNullRepeat")]
        public void ReadIsStrict(string json)
        {
            Assert.Throws<InvalidDataException>(() => QuestStateJson.Read(JObject.Parse(json)));
        }

        [Test]
        public void ContainerUpdateTakesTheWholeDocument()
        {
            var container = new QuestStateContainer();
            JObject full = new JObject { [QuestStateJson.DefaultKey] = QuestStateJson.Write(Sample()) };
            Assert.That(container.ImportJson(full), Is.True);
            Assert.That(container.Current.Run(MonthlyGroup).RepeatCount(MonthlyRepeat), Is.EqualTo(1));

            var changes = new List<IReadOnlyList<string>>();
            container.Changed += c => changes.Add(c.ChangedKeys);
            JObject next = JObject.Parse("{\"questState\":{\"seed\":5,\"cnt\":{\"daily\":{\"period\":20261111}},\"groups\":{\"" + DailyGroup + "\":{\"period\":20261111,\"since\":1}}}}");
            Assert.That(container.UpdateJson(next), Is.True);
            Assert.That(changes[0], Does.Contain("cnt.daily").And.Contain("cnt.lifetime").And.Contain("group." + MonthlyGroup).And.Not.Contain("seed"));
            Assert.That(container.Current.Run(DailyGroup).Claimed, Is.Empty);
            Assert.That(container.Current.Run(MonthlyGroup), Is.Null, "a run the rules dropped is gone, so an old claim cannot come back");
            Assert.That(container.Current.Seed, Is.EqualTo(5));
            Assert.That(container.UpdateJson(next), Is.False, "same data: no change");
            Assert.That(container.UpdateJson(new JObject { ["other"] = 1 }), Is.False);
        }

        [Test]
        public void ContainerReplaceAndFailures()
        {
            var container = new QuestStateContainer();
            container.ImportJson(new JObject { [QuestStateJson.DefaultKey] = QuestStateJson.Write(Sample()) });
            QuestState before = container.Current;
            Assert.Throws<InvalidDataException>(() => container.UpdateJson(JObject.Parse("{\"questState\":{\"groups\":{\"5\":{\"period\":1,\"since\":0,\"got\":[1,1]}}}}")));
            Assert.Throws<InvalidDataException>(() => container.ImportJson(new JObject()));
            Assert.Throws<InvalidDataException>(() => container.UpdateJson(JObject.Parse("{\"questState\":5}")));
            Assert.That(container.Current, Is.SameAs(before));
            Assert.That(container.ImportJson(JObject.Parse("{\"questState\":{}}")), Is.True);
            Assert.That(container.Current.Counters, Is.Empty);
            Assert.That(container.Current.Groups, Is.Empty);
        }

        [Test]
        public void ContainerWorksInRepository()
        {
            var repository = new DataRepository("quest:" + Guid.NewGuid().ToString("N"));
            _repositories.Add(repository);
            var container = new QuestStateContainer("quests");
            repository.Register(container);
            JObject doc = new JObject { ["quests"] = QuestStateJson.Write(Sample()) };
            Assert.That(repository.ImportJson(doc, "quests"), Is.True);
            Assert.That(JToken.DeepEquals(container.ExportJson(), doc), Is.True);
            Assert.That(repository.Get<QuestStateContainer>("quests").Current.Slot(Lifetime).Counter("1"), Is.EqualTo(16));
        }
    }
}
