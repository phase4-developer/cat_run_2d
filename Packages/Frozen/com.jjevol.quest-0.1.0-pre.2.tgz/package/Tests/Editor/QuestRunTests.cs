using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using jjevol;
using static jjevol.Quest.Tests.QuestTestKit;

namespace jjevol.Quest.Tests
{
    /// <summary>Group runs: run scope, requirements, completion rewards, selection, autoClaim, cycles and rewards paid elsewhere.</summary>
    public sealed class QuestRunTests
    {
        private const int Start1 = 440005001, Start2 = 440005002, PickGroup = 440001003, AutoGroup = 440006001, SeasonGroup = 440007001, RunDaily = 440001004;
        private const int S1a = 441005001, S1b = 441005002, S2a = 441005101, Auto1 = 441006001, Auto2 = 441006002, Season1 = 441007001, RunRow = 441001401;
        private const int StartTab = 5;

        private static QuestGroupRow Group(int key, int tab, QuestPeriod period, QuestGroupType type, QuestScope scope, int require = 0, int select = 0,
            bool auto = false, ConsumeData complete = null, string cycle = null, string openKey = "")
            => new QuestGroupRow(key, tab, period, type, scope, openKey: openKey, cycleKey: cycle, requireGroup: require, selectionCount: select, autoClaim: auto,
                completeRewards: complete == null ? null : new[] { complete });

        private static QuestRow Row(int id, int group, int type, long value, ConsumeData reward = null, int step = 0)
            => new QuestRow(id, QuestRowKind.Quest, group, type, value, step: step, rewards: reward == null ? null : new[] { reward });

        // ------------------------------------------------------------ run scope

        [Test]
        public void RunScopeCountsFromWhenTheGroupOpened()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(RunDaily, 1, QuestPeriod.Daily, QuestGroupType.List, QuestScope.Run, openKey: "arena"));
            List<QuestRow> rows = Rows();
            rows.Add(Row(RunRow, RunDaily, Run, 2, C(Coins, 1)));
            QuestRules rules = Rules(groups, rows);
            bool arena = false;
            Func<string, bool> isOpen = key => key != "arena" || arena;

            QuestState s = Record(rules, QuestState.Empty, Now, isOpen, new QuestEvent(Run, 5));
            Assert.That(s.Run(RunDaily), Is.Null);
            Assert.That(s.Slot(Daily).Counter("1"), Is.EqualTo(5), "the shared daily counter counts from the day start");
            arena = true;
            s = Record(rules, s, Now + 1000, isOpen, new QuestEvent(Run, 1));
            Assert.That((s.Run(RunDaily).Since, s.Run(RunDaily).Counter("1")), Is.EqualTo((Now + 1000, 1L)), "the run opened before the event and counts it");
            Assert.That(rules.Claim(s, QuestClaimTarget.Quest(RunRow), Now + 1000, isOpen).Code, Is.EqualTo(QuestCodes.NotDone));
            arena = false;
            s = Record(rules, s, Now + 2000, isOpen, new QuestEvent(Run, 9));
            Assert.That(s.Run(RunDaily).Counter("1"), Is.EqualTo(1), "a locked run keeps its counters but stops counting");
            arena = true;
            s = Record(rules, s, Now + 3000, isOpen, new QuestEvent(Run, 1));
            Assert.That(rules.Claim(s, QuestClaimTarget.Quest(RunRow), Now + 3000, isOpen).Ok, Is.True);
            QuestState tomorrow = rules.Roll(s, At(2026, 11, 11, 1), isOpen);
            Assert.That((tomorrow.Run(RunDaily).Since, tomorrow.Run(RunDaily).Counter("1")), Is.EqualTo((At(2026, 11, 11, 1), 0L)), "each day is a new run");
        }

        [Test]
        public void MaxAndSetWorkInARun()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(RunDaily, 1, QuestPeriod.None, QuestGroupType.List, QuestScope.Run));
            List<QuestRow> rows = Rows();
            rows.Add(Row(RunRow, RunDaily, Best, 50, C(Coins, 1)));
            QuestRules rules = Rules(groups, rows);
            QuestState s = Record(rules, QuestState.Empty, Now, new QuestEvent(Best, 40), new QuestEvent(Best, 30));
            Assert.That(s.Run(RunDaily).Counter("2"), Is.EqualTo(40), "the best since the run began, not the lifetime best minus a base");
            s = Record(rules, s, Now, new QuestEvent(Best, 55));
            Assert.That(rules.Claim(s, QuestClaimTarget.Quest(RunRow), Now).Ok, Is.True);
        }

        // ------------------------------------------------------------ starter chain

        private static QuestRules StarterRules()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(Start1, StartTab, QuestPeriod.None, QuestGroupType.List, QuestScope.Run, complete: C(Gems, 30)));
            groups.Add(Group(Start2, StartTab, QuestPeriod.None, QuestGroupType.List, QuestScope.Run, require: Start1));
            List<QuestRow> rows = Rows();
            rows.Add(Row(S1a, Start1, Run, 1, C(Coins, 5)));
            rows.Add(Row(S1b, Start1, Upgrade, 1, C(Coins, 5)));
            rows.Add(Row(S2a, Start2, Run, 3, C(Coins, 7)));
            return Rules(groups, rows);
        }

        [Test]
        public void StarterChainOpensTheNextGroupWhenFinished()
        {
            QuestRules rules = StarterRules();
            QuestState s = Record(rules, QuestState.Empty, Now, new QuestEvent(Run, 2));
            QuestBoard board = rules.Board(s, Now);
            Assert.That(board.Group(Start2).Status, Is.EqualTo(QuestGroupStatus.Waiting));
            Assert.That(board.Current(StartTab).Key, Is.EqualTo(Start1));
            Assert.That((board.Group(Start1).ClaimedRows, board.Group(Start1).TotalRows, board.Group(Start1).CompletionState), Is.EqualTo((0, 2, (QuestItemState?)QuestItemState.InProgress)));

            s = Claim(rules, s, QuestClaimTarget.Quest(S1a), Now);
            Assert.That(rules.Claim(s, QuestClaimTarget.Completion(Start1), Now).Code, Is.EqualTo(QuestCodes.NotDone));
            s = Record(rules, s, Now, new QuestEvent(Upgrade, 1, 4));
            QuestClaimResult r = rules.Claim(s, QuestClaimTarget.Tab(StartTab), Now);
            Assert.That(r.Claimed.Select(c => (c.GroupKey, c.QuestId)), Is.EqualTo(new[] { (Start1, S1b), (Start1, 0) }), "the completion reward comes last in a tab claim");
            Assert.That(r.Grants.Select(g => (g.ItemId, g.Quantity)), Is.EqualTo(new[] { (Coins, 5L), (Gems, 30L) }));
            Assert.That(r.State.Run(Start2), Is.Not.Null, "the next group opens in the same result");
            Assert.That(r.State.Run(Start2).Counter("1"), Is.EqualTo(0), "it counts from now");
            board = rules.Board(r.State, Now);
            Assert.That((board.Group(Start1).Finished, board.Current(StartTab).Key), Is.EqualTo((true, Start2)));
            Assert.That(rules.Claim(r.State, QuestClaimTarget.Completion(Start1), Now).Code, Is.EqualTo(QuestCodes.AlreadyClaimed));
        }

        [Test]
        public void RequirementLoopIsAnError()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(Start1, StartTab, QuestPeriod.None, QuestGroupType.List, QuestScope.Run, require: Start2));
            groups.Add(Group(Start2, StartTab, QuestPeriod.None, QuestGroupType.List, QuestScope.Run, require: Start1));
            Assert.That(Codes(Issues(groups, Rows())), Does.Contain("RequireLoop"));
        }

        // ------------------------------------------------------------ selection

        private static QuestRules PickRules()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(PickGroup, 1, QuestPeriod.Daily, QuestGroupType.List, QuestScope.Period, select: 2));
            List<QuestRow> rows = Rows();
            for (int i = 0; i < 6; i++) rows.Add(Row(441001301 + i, PickGroup, Run, 1 + i, C(Coins, 1)));
            return Rules(groups, rows);
        }

        [Test]
        public void SelectionIsStoredAndRepeatable()
        {
            QuestRules rules = PickRules();
            QuestState a = rules.Roll(QuestState.Empty.WithSeed(11), Now);
            QuestState b = rules.Roll(QuestState.Empty.WithSeed(11), Now + 5000);
            Assert.That(a.Run(PickGroup).Picks.Count, Is.EqualTo(2));
            Assert.That(b.Run(PickGroup).Picks, Is.EqualTo(a.Run(PickGroup).Picks), "same seed, group and day: same rows on server and local route");
            Assert.That(rules.Board(a, Now).Group(PickGroup).Items.Select(i => i.Id), Is.EquivalentTo(a.Run(PickGroup).Picks));
            var days = Enumerable.Range(0, 10).Select(d => string.Join(",", rules.Roll(a, At(2026, 11, 11 + d, 1)).Run(PickGroup).Picks)).Distinct().Count();
            Assert.That(days, Is.GreaterThan(1), "other days pick other rows");
            int notPicked = Enumerable.Range(441001301, 6).First(id => !a.Run(PickGroup).IsPicked(id));
            QuestState full = Record(rules, a, Now, new QuestEvent(Run, 10));
            Assert.That(rules.Claim(full, QuestClaimTarget.Quest(notPicked), Now).Code, Is.EqualTo(QuestCodes.Unknown));
            Assert.That(rules.Claim(full, QuestClaimTarget.Group(PickGroup), Now).Claimed.Count, Is.EqualTo(2));
        }

        // ------------------------------------------------------------ autoClaim

        private static QuestRules AutoRules()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(AutoGroup, 900, QuestPeriod.None, QuestGroupType.List, QuestScope.Lifetime, auto: true));
            List<QuestRow> rows = Rows();
            rows.Add(Row(Auto1, AutoGroup, Run, 4, C(Gems, 1)));
            rows.Add(Row(Auto2, AutoGroup, Best, 100, P(20)));
            return Rules(groups, rows);
        }

        [Test]
        public void AutoClaimPaysInTheWriteThatCompletes()
        {
            QuestRules rules = AutoRules();
            QuestRecordResult r = rules.Record(QuestState.Empty, new[] { new QuestEvent(Run, 3) }, Now, QuestSource.Server);
            Assert.That(r.Claimed, Is.Empty);
            r = rules.Record(r.State, new[] { new QuestEvent(Run, 1), new QuestEvent(Best, 120) }, Now, QuestSource.Server);
            Assert.That(r.Claimed.Select(c => c.QuestId), Is.EquivalentTo(new[] { Auto1, Auto2 }));
            Assert.That(r.Grants.Select(g => (g.ItemId, g.Quantity)), Is.EqualTo(new[] { (Gems, 1L) }));
            Assert.That(r.State.Slot(Daily).Counter("20"), Is.EqualTo(20), "autoClaim points still raise their counters");
            Assert.That(rules.Board(r.State, Now).Group(AutoGroup).Items.All(i => i.State == QuestItemState.Done), Is.True);
            Assert.That(rules.Record(r.State, new[] { new QuestEvent(Run, 1) }, Now, QuestSource.Server).Claimed, Is.Empty, "claimed once");
        }

        [Test]
        public void AutoClaimFollowsPointsOfAClaim()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(AutoGroup, 900, QuestPeriod.Daily, QuestGroupType.List, QuestScope.Period, auto: true));
            List<QuestRow> rows = Rows();
            rows.Add(Row(Auto1, AutoGroup, DayPoint, 20, C(Gems, 9)));
            QuestRules rules = Rules(groups, rows);
            QuestState s = Record(rules, QuestState.Empty, Now, new QuestEvent(Run, 3));
            QuestClaimResult r = rules.Claim(s, QuestClaimTarget.Quest(DailyRun), Now);
            Assert.That(r.Claimed.Select(c => c.QuestId), Is.EqualTo(new[] { DailyRun, Auto1 }));
            Assert.That(r.Grants.Select(g => (g.ItemId, g.Quantity)), Is.EqualTo(new[] { (Coins, 100L), (Gems, 9L) }));
        }

        // ------------------------------------------------------------ cycles

        [Test]
        public void CycleGroupsFollowTheirCycle()
        {
            var period = new QuestPeriodSettings().AddCycle("event", t => t < At(2026, 11, 20) ? 3 : t < At(2026, 12, 1) ? 0 : 4, t => At(2026, 11, 20));
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(SeasonGroup, 7, QuestPeriod.Cycle, QuestGroupType.List, QuestScope.Period, cycle: "event"));
            List<QuestRow> rows = Rows();
            rows.Add(Row(Season1, SeasonGroup, Run, 5, C(Coins, 1)));
            QuestRules rules = Rules(groups, rows, period);
            QuestState s = Record(rules, QuestState.Empty, Now, new QuestEvent(Run, 5));
            Assert.That(s.Slot("cycle.event").Period, Is.EqualTo(3));
            s = Claim(rules, s, QuestClaimTarget.Quest(Season1), Now);
            QuestState gap = rules.Roll(s, At(2026, 11, 25));
            Assert.That((gap.Run(SeasonGroup), rules.Board(gap, At(2026, 11, 25)).Group(SeasonGroup).Status), Is.EqualTo(((QuestGroupRun)null, QuestGroupStatus.NoCycle)));
            Assert.That(rules.Claim(gap, QuestClaimTarget.Quest(Season1), At(2026, 11, 25)).Code, Is.EqualTo(QuestCodes.Locked));
            QuestState next = rules.Roll(s, At(2026, 12, 2));
            Assert.That((next.Run(SeasonGroup).Period, next.Run(SeasonGroup).IsClaimed(Season1), next.Slot("cycle.event").Counter("1")), Is.EqualTo((4, false, 0L)));
            Assert.That(rules.Board(s, Now).Group(SeasonGroup).NextResetMs, Is.EqualTo(At(2026, 11, 20)));
        }

        [Test]
        public void PremiumNeedsARunningCycle()
        {
            const int SeasonPass = 440107001, SeasonPass1 = 442107001;
            var period = new QuestPeriodSettings().AddCycle("event", t => t < At(2026, 11, 20) ? 3 : t < At(2026, 12, 1) ? 0 : 4, t => t < At(2026, 11, 20) ? At(2026, 11, 20) : At(2026, 12, 1));
            List<QuestGroupRow> groups = Groups();
            groups.Add(new QuestGroupRow(SeasonPass, PassTab, QuestPeriod.Cycle, QuestGroupType.Track, QuestScope.Period, cycleKey: "event", premium: true));
            List<QuestRow> rows = Rows();
            rows.Add(new QuestRow(SeasonPass1, QuestRowKind.Pass, SeasonPass, Level, 1, step: 1, rewards: new[] { C(Coins, 1) }, premiumRewards: new[] { C(Gems, 1) }));
            QuestRules rules = Rules(groups, rows, period);
            long gap = At(2026, 11, 25);
            Assert.That(rules.ActivatePremium(QuestState.Empty, SeasonPass, gap), Is.Null, "a purchase in a gap would be dropped when the next cycle starts");
            Assert.That(rules.ApplyRewards(QuestState.Empty, new[] { new ConsumeData(Premium, SeasonPass, 1) }, gap).Code, Is.EqualTo(QuestCodes.Locked));
            Assert.That(rules.Board(QuestState.Empty, gap).Group(SeasonPass).NextResetMs, Is.EqualTo(At(2026, 12, 1)), "endsAt in a gap is the next start");
            QuestState bought = rules.ActivatePremium(QuestState.Empty, SeasonPass, Now);
            Assert.That(bought.Run(SeasonPass).Premium, Is.True);
        }

        [Test]
        public void CycleWithoutSourceIsAnError()
        {
            List<QuestGroupRow> groups = Groups();
            groups.Add(Group(SeasonGroup, 7, QuestPeriod.Cycle, QuestGroupType.List, QuestScope.Period, cycle: "event"));
            Assert.That(Codes(Issues(groups, Rows())), Does.Contain("NoCycleSource"));
        }

        // ------------------------------------------------------------ rewards paid elsewhere

        [Test]
        public void ApplyRewardsRaisesPointsAndPremium()
        {
            QuestRules rules = Rules();
            QuestRecordResult r = rules.ApplyRewards(QuestState.Empty, new[] { P(25), new ConsumeData(Premium, PassGroup, 1), C(Coins, 999) }, Now);
            Assert.That(r.Ok, Is.True, r.Code);
            Assert.That(r.State.Slot(Daily).Counter("20"), Is.EqualTo(25));
            Assert.That(r.State.Run(PassGroup).Premium, Is.True);
            Assert.That(r.Grants, Is.Empty, "coins are paid by whoever paid them");
            Assert.That(rules.Board(r.State, Now).Group(TrackGroup).Items[0].State, Is.EqualTo(QuestItemState.Claimable));
            Assert.That(rules.ApplyRewards(QuestState.Empty, new[] { new ConsumeData(Premium, DailyGroup, 1) }, Now).Code, Is.EqualTo(QuestCodes.UnsupportedReward));
        }

        [Test]
        public void PremiumBoughtBeforeTheGroupOpens()
        {
            List<QuestGroupRow> groups = Groups();
            groups[4] = new QuestGroupRow(PassGroup, PassTab, QuestPeriod.None, QuestGroupType.Track, QuestScope.Lifetime, premium: true, openKey: "pass");
            QuestRules rules = Rules(groups, Rows());
            QuestState s = rules.ActivatePremium(QuestState.Empty, PassGroup, Now, key => key != "pass");
            Assert.That(s.Run(PassGroup).Premium, Is.True, "the purchase is kept in a run started now");
            s = Record(rules, s, Now, new QuestEvent(Level, 1));
            Assert.That(rules.Claim(s, QuestClaimTarget.Quest(Pass1, premium: true), Now).Ok, Is.True);
        }
    }
}
