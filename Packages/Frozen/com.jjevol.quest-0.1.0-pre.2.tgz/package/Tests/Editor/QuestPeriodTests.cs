using System;
using NUnit.Framework;
using static jjevol.Quest.Tests.QuestTestKit;

namespace jjevol.Quest.Tests
{
    public sealed class QuestPeriodTests
    {
        [Test]
        public void KeysUseUtcDayWeekAndMonth()
        {
            var s = QuestPeriodSettings.Default;
            long t = At(2026, 11, 10, 12);   // Tuesday
            Assert.That(QuestPeriods.Key(QuestPeriod.None, null, t, s), Is.EqualTo(0));
            Assert.That(QuestPeriods.Key(QuestPeriod.Daily, null, t, s), Is.EqualTo(20261110));
            Assert.That(QuestPeriods.Key(QuestPeriod.Weekly, null, t, s), Is.EqualTo(20261109));
            Assert.That(QuestPeriods.Key(QuestPeriod.Monthly, null, t, s), Is.EqualTo(202611));
            Assert.That(QuestPeriods.Key(QuestPeriod.Weekly, null, t, new QuestPeriodSettings(weekStart: DayOfWeek.Sunday)), Is.EqualTo(20261108));
        }

        [Test]
        public void ResetHourShiftsTheDay()
        {
            var s = new QuestPeriodSettings(resetHourUtc: 15);
            Assert.That(QuestPeriods.Key(QuestPeriod.Daily, null, At(2026, 11, 10, 14, 59), s), Is.EqualTo(20261109));
            Assert.That(QuestPeriods.Key(QuestPeriod.Daily, null, At(2026, 11, 10, 15), s), Is.EqualTo(20261110));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Daily, null, At(2026, 11, 10, 14, 59), s), Is.EqualTo(At(2026, 11, 10, 15)));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Daily, null, At(2026, 11, 10, 15), s), Is.EqualTo(At(2026, 11, 11, 15)));
            Assert.That(QuestPeriods.Key(QuestPeriod.Monthly, null, At(2026, 12, 1, 14), s), Is.EqualTo(202611));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Monthly, null, At(2026, 12, 1, 14), s), Is.EqualTo(At(2026, 12, 1, 15)));
        }

        [Test]
        public void BoundariesAcrossMonthYearAndLeapDay()
        {
            var s = QuestPeriodSettings.Default;
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Daily, null, At(2028, 2, 28, 23, 59), s), Is.EqualTo(At(2028, 2, 29)));
            Assert.That(QuestPeriods.Key(QuestPeriod.Daily, null, At(2028, 2, 29, 0), s), Is.EqualTo(20280229));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Monthly, null, At(2026, 12, 31, 23), s), Is.EqualTo(At(2027, 1, 1)));
            Assert.That(QuestPeriods.Key(QuestPeriod.Weekly, null, At(2027, 1, 1), s), Is.EqualTo(20261228));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Weekly, null, At(2026, 11, 15, 23, 59), s), Is.EqualTo(At(2026, 11, 16)));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.None, null, At(2026, 11, 15), s), Is.EqualTo(long.MaxValue));
        }

        [Test]
        public void CyclesComeFromSettings()
        {
            var s = new QuestPeriodSettings().AddCycle("season", t => t < At(2026, 12, 1) ? 7 : 8, t => t < At(2026, 12, 1) ? At(2026, 12, 1) : long.MaxValue)
                .AddCycle("event", t => 2);
            Assert.That(QuestPeriods.Key(QuestPeriod.Cycle, "season", At(2026, 11, 30), s), Is.EqualTo(7));
            Assert.That(QuestPeriods.Key(QuestPeriod.Cycle, "season", At(2026, 12, 1), s), Is.EqualTo(8));
            Assert.That(QuestPeriods.Key(QuestPeriod.Cycle, "event", Now, s), Is.EqualTo(2));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Cycle, "season", At(2026, 11, 30), s), Is.EqualTo(At(2026, 12, 1)));
            Assert.That(QuestPeriods.NextReset(QuestPeriod.Cycle, "event", Now, s), Is.EqualTo(long.MaxValue), "no end given");
            Assert.That(QuestPeriods.Key(QuestPeriod.Cycle, "season", Now, QuestPeriodSettings.Default), Is.EqualTo(0));
            Assert.Throws<ArgumentException>(() => s.AddCycle("event", t => 1));
            Assert.Throws<ArgumentException>(() => s.AddCycle("bad key", t => 1));
        }

        [Test]
        public void SlotNamesRoundTrip()
        {
            foreach (var (p, c, name) in new[] { (QuestPeriod.None, "", "lifetime"), (QuestPeriod.Daily, "", "daily"), (QuestPeriod.Weekly, "", "weekly"), (QuestPeriod.Monthly, "", "monthly"), (QuestPeriod.Cycle, "season", "cycle.season") })
            {
                Assert.That(QuestPeriods.SlotName(p, c), Is.EqualTo(name));
                Assert.That(QuestPeriods.TryParseSlot(name, out QuestPeriod back, out string cycle) && back == p && cycle == c, Is.True, name);
            }
            Assert.That(QuestPeriods.TryParseSlot("cycle.", out _, out _), Is.False);
            Assert.That(QuestPeriods.TryParseSlot("hourly", out _, out _), Is.False);
        }

        [Test]
        public void PeriodCodesAreTheTableCodes()
        {
            Assert.That(new[] { (int)QuestPeriod.None, (int)QuestPeriod.Daily, (int)QuestPeriod.Weekly, (int)QuestPeriod.Monthly, (int)QuestPeriod.Cycle }, Is.EqualTo(new[] { 0, 2, 4, 8, 16 }));
            Assert.That(new[] { (int)QuestScope.Lifetime, (int)QuestScope.Run, (int)QuestScope.Period }, Is.EqualTo(new[] { 1, 2, 3 }));
            Assert.That(new[] { (int)QuestGroupType.List, (int)QuestGroupType.Steps, (int)QuestGroupType.Track }, Is.EqualTo(new[] { 1, 2, 3 }));
        }

        [Test]
        public void WeekStartFromTableUsesMondayOne()
        {
            Assert.That(QuestPeriodSettings.WeekStartFromTable(1), Is.EqualTo(DayOfWeek.Monday));
            Assert.That(QuestPeriodSettings.WeekStartFromTable(6), Is.EqualTo(DayOfWeek.Saturday));
            Assert.That(QuestPeriodSettings.WeekStartFromTable(7), Is.EqualTo(DayOfWeek.Sunday));
            Assert.Throws<ArgumentOutOfRangeException>(() => QuestPeriodSettings.WeekStartFromTable(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => QuestPeriodSettings.WeekStartFromTable(8));
        }

        [Test]
        public void SettingsRejectBadHour()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new QuestPeriodSettings(resetHourUtc: 24));
            Assert.Throws<ArgumentOutOfRangeException>(() => new QuestPeriodSettings(resetHourUtc: -1));
        }
    }
}
