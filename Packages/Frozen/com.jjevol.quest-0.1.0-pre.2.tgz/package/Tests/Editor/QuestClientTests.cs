using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using PlatformLibrary.Network;
using jjevol.Quest.Network;
using static jjevol.Quest.Tests.QuestTestKit;

namespace jjevol.Quest.Tests
{
    public sealed class QuestClientTests
    {
        private sealed class GameRequest : NetworkRequest
        {
            private readonly string _name;
            public GameRequest(string name, IEnumerable<KeyValuePair<string, object>> parameters, string[] dataKeys)
            {
                _name = name;
                foreach (var p in parameters) Add(p.Key, p.Value);
                DataKeys = dataKeys;
            }
            public override string Name => _name;
        }

        private QuestStateContainer _quests;
        private QuestClient _client;
        private readonly List<NetworkRequest> _sent = new List<NetworkRequest>();
        private Func<NetworkRequest, Task<NetworkResult>> _reply;
        private Func<QuestCall, NetworkRequest> _factory;
        private long _now;
        private SynchronizationContext _context;

        [SetUp]
        public void SetUp()
        {
            // The editor's context would post the continuation to a main thread that the test blocks on; run it inline instead.
            _context = SynchronizationContext.Current;
            SynchronizationContext.SetSynchronizationContext(null);
            _quests = new QuestStateContainer();
            _quests.ImportJson(new JObject { [QuestStateJson.DefaultKey] = new JObject() });
            _now = Now;
            _sent.Clear();
            _reply = _ => Task.FromResult(NetworkResult.Succeeded(new JObject()));
            _factory = call => new GameRequest(call.Name, call.Parameters, call.DataKeys);
            _client = new QuestClient(Rules(), _quests, call => _factory(call), () => _now, key => key != "shop", new[] { "wealthInfos" },
                (request, token) => { _sent.Add(request); return _reply(request); });
        }

        [TearDown]
        public void TearDown()
        {
            _client?.Dispose();
            SynchronizationContext.SetSynchronizationContext(_context);
        }

        private void SetState(QuestState state) => _quests.ImportJson(new JObject { [QuestStateJson.DefaultKey] = QuestStateJson.Write(state) });

        [Test]
        public void LocalRefusalIsNotSent()
        {
            QuestOutcome outcome = _client.ClaimAsync(QuestClaimTarget.Quest(DailyRun)).Result;
            Assert.That((outcome.Ok, outcome.Code, outcome.Sent), Is.EqualTo((false, QuestCodes.NotDone, false)));
            Assert.That(_client.RecordAsync(new[] { new QuestEvent(ServerOnly, 1) }).Result.Code, Is.EqualTo(QuestCodes.BadEvent));
            Assert.That(_sent, Is.Empty);
        }

        [Test]
        public void ClaimSendsTheTargetAndReadsRewards()
        {
            SetState(Record(Rules(), QuestState.Empty, Now, new QuestEvent(Run, 3)));
            _reply = _ => Task.FromResult(NetworkResult.Succeeded(new JObject { [QuestLocalHandler.RewardsKey] = new JArray(C(Coins, 100).ExportJson(), P(20).ExportJson()) }));
            QuestOutcome outcome = _client.ClaimAsync(QuestClaimTarget.Quest(DailyRun)).Result;
            Assert.That((outcome.Ok, outcome.Sent), Is.EqualTo((true, true)));
            Assert.That(outcome.Rewards.Select(r => (r.ItemId, r.Quantity)), Is.EqualTo(new[] { (Coins, 100L), (0, 20L) }));
            NetworkRequest sent = _sent.Single();
            Assert.That((sent.Name, Convert.ToInt32(sent.Params["id"])), Is.EqualTo((QuestCall.ClaimName, DailyRun)));
            Assert.That(sent.DataKeys, Is.EqualTo(new[] { QuestStateJson.DefaultKey, "wealthInfos" }));
        }

        [Test]
        public void RecordSendsEvents()
        {
            Assert.That(_client.RecordAsync(new[] { new QuestEvent(Run, 2) }).Result.Ok, Is.True);
            QuestEvent[] events = QuestLocalHandler.ParseEvents(_sent.Single().Params);
            Assert.That(events.Select(e => (e.Type, e.Amount)), Is.EqualTo(new[] { (Run, 2L) }));
            Assert.That(_sent[0].Name, Is.EqualTo(QuestCall.RecordName));
        }

        [Test]
        public void OneCallAtATime()
        {
            var pending = new TaskCompletionSource<NetworkResult>();
            _reply = _ => pending.Task;
            Task<QuestOutcome> first = _client.RecordAsync(new[] { new QuestEvent(Run, 1) });
            Assert.That(_client.IsBusy, Is.True);
            QuestOutcome second = _client.RecordAsync(new[] { new QuestEvent(Run, 1) }).Result;
            Assert.That((second.Code, second.Sent), Is.EqualTo((QuestCodes.Busy, false)));
            pending.SetResult(NetworkResult.Succeeded(new JObject()));
            Assert.That(first.Result.Ok, Is.True);
            Assert.That(_client.IsBusy, Is.False);
            Assert.That(_sent.Count, Is.EqualTo(1));
        }

        [Test]
        public void FailuresCarryTheServerCode()
        {
            _reply = _ => Task.FromResult(NetworkResult.Failed(NetworkFailure.Rejected, QuestCodes.AlreadyClaimed));
            QuestOutcome rejected = _client.RecordAsync(new[] { new QuestEvent(Run, 1) }).Result;
            Assert.That((rejected.Code, rejected.Sent, rejected.Network?.Failure), Is.EqualTo((QuestCodes.AlreadyClaimed, true, (NetworkFailure?)NetworkFailure.Rejected)));
            _reply = _ => Task.FromResult(NetworkResult.Failed(NetworkFailure.NoConnection));
            Assert.That(_client.RecordAsync(new[] { new QuestEvent(Run, 1) }).Result.Code, Is.EqualTo(QuestCodes.Network));
            Assert.That(_client.IsBusy, Is.False);
        }

        [Test]
        public void FactoryMustKeepNameAndDataKeys()
        {
            _factory = call => new GameRequest(call.Name, call.Parameters, new[] { QuestStateJson.DefaultKey });
            Assert.Throws<InvalidOperationException>(() => _client.RecordAsync(new[] { new QuestEvent(Run, 1) }).GetAwaiter().GetResult(), "the paid keys are missing");
            _factory = call => new GameRequest("other", call.Parameters, call.DataKeys);
            Assert.Throws<InvalidOperationException>(() => _client.RecordAsync(new[] { new QuestEvent(Run, 1) }).GetAwaiter().GetResult());
            _factory = _ => null;
            Assert.Throws<InvalidOperationException>(() => _client.RecordAsync(new[] { new QuestEvent(Run, 1) }).GetAwaiter().GetResult());
            Assert.That(_sent, Is.Empty);
            Assert.That(_client.IsBusy, Is.False);
        }

        [Test]
        public void BoardFollowsTheStateAndTheClock()
        {
            var boards = new List<QuestBoard>();
            _client.BoardChanged += boards.Add;
            QuestBoard first = _client.Board;
            Assert.That(_client.Board, Is.SameAs(first), "cached until something changes");
            Assert.That(first.HasRedDot(1), Is.False);

            SetState(Record(Rules(), QuestState.Empty, Now, new QuestEvent(Run, 3)));
            Assert.That(boards.Count, Is.EqualTo(1));
            Assert.That(boards[0].HasRedDot(1), Is.True);
            Assert.That(_client.Board, Is.SameAs(boards[0]));

            _now = boards[0].NextResetMs;
            Assert.That(_client.Board, Is.Not.SameAs(boards[0]), "a period boundary rebuilds the board");
            Assert.That(_client.Board.HasRedDot(1), Is.False, "the daily run reset");

            _client.Refresh();
            Assert.That(boards.Count, Is.EqualTo(2));
            _client.Dispose();
            SetState(QuestState.Empty);
            Assert.That(boards.Count, Is.EqualTo(2), "disposed clients stop following");
            Assert.Throws<ObjectDisposedException>(() => _client.RecordAsync(new[] { new QuestEvent(Run, 1) }).GetAwaiter().GetResult());
        }
    }
}
