using System;
using System.Collections;
using System.Reflection;
using Firebase.Functions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network.Firebase
{
    /// <summary>The game error found in a Functions exception.</summary>
    public readonly struct FirebaseFunctionError
    {
        public FunctionsErrorCode FunctionsCode { get; }
        /// <summary>Game error string from details, the message, or a compatibility phrase.</summary>
        public string ErrorCode { get; }
        public string Message { get; }
        public JObject Details { get; }
        /// <summary>True when <see cref="ErrorCode"/> came from the details object rather than message heuristics.</summary>
        public bool FromDetails { get; }
        public bool UsedCompatibilityPhrase { get; }

        public FirebaseFunctionError(FunctionsErrorCode functionsCode, string errorCode, string message, JObject details, bool fromDetails, bool usedCompatibilityPhrase)
        {
            FunctionsCode = functionsCode;
            ErrorCode = errorCode ?? string.Empty;
            Message = message ?? string.Empty;
            Details = details;
            FromDetails = fromDetails;
            UsedCompatibilityPhrase = usedCompatibilityPhrase;
        }

        public JObject CreateResponse(NetworkResponseFormat format)
        {
            var response = new JObject
            {
                [format.MessageKey ?? "message"] = Message,
                [format.ErrorCodeKey ?? "errorCode"] = ErrorCode
            };
            if (Details != null) response["details"] = Details.DeepClone();
            return response;
        }
    }

    /// <summary>
    /// Finds the server's game error in a Functions exception. Order kept from the original parser:
    /// exception details, Exception.Data, the message as JSON, known codes inside the message,
    /// then compatibility phrases for SDKs that hide custom details.
    /// </summary>
    public static class FirebaseFunctionsErrorParser
    {
        public static FirebaseFunctionError Parse(FunctionsException exception, NetworkResponseFormat format, FirebaseNetworkSettings settings = null)
        {
            if (exception == null) throw new ArgumentNullException(nameof(exception));
            return Parse(exception.ErrorCode, exception.Message, exception, format, settings);
        }

        /// <summary>Parses from parts. <paramref name="source"/> supplies optional Details and Data.</summary>
        public static FirebaseFunctionError Parse(FunctionsErrorCode code, string exceptionMessage, Exception source, NetworkResponseFormat format, FirebaseNetworkSettings settings = null)
        {
            format ??= new NetworkResponseFormat();
            settings ??= new FirebaseNetworkSettings();
            JObject details = TryGetDetails(source) ?? TryGetExceptionData(source) ?? TryParseObject(exceptionMessage);
            string errorCode = FindString(details, format.ErrorCodeKey);
            bool fromDetails = !string.IsNullOrEmpty(errorCode);
            string message = FindString(details, format.MessageKey);
            if (string.IsNullOrEmpty(message)) message = exceptionMessage ?? string.Empty;

            if (string.IsNullOrEmpty(errorCode))
            {
                if (Contains(message, format.SessionInvalidCode)) errorCode = format.SessionInvalidCode;
                else if (Contains(message, format.MaintenanceCode)) errorCode = format.MaintenanceCode;
            }

            bool compatibility = false;
            if (string.IsNullOrEmpty(errorCode))
            {
                if (code == FunctionsErrorCode.PermissionDenied && Contains(message, settings.SessionInvalidPhrase)) errorCode = format.SessionInvalidCode;
                else if (code == FunctionsErrorCode.Unavailable && Contains(message, settings.MaintenancePhrase)) errorCode = format.MaintenanceCode;
                compatibility = !string.IsNullOrEmpty(errorCode);
            }

            if (string.IsNullOrEmpty(errorCode)) errorCode = string.IsNullOrEmpty(exceptionMessage) ? code.ToString() : exceptionMessage;
            return new FirebaseFunctionError(code, errorCode, message, details, fromDetails, compatibility);
        }

        /// <summary>Maps a parsed error to a failure. Game errors stay Rejected with their string.</summary>
        public static NetworkResult ToResult(FirebaseFunctionError error, NetworkResponseFormat format)
        {
            format ??= new NetworkResponseFormat();
            NetworkFailure classified = format.Classify(error.ErrorCode);
            NetworkFailure failure;
            if (classified == NetworkFailure.SessionInvalid || classified == NetworkFailure.Maintenance) failure = classified;
            else if (error.FromDetails) failure = NetworkFailure.Rejected;
            else failure = MapCode(error.FunctionsCode);
            return NetworkResult.Failed(failure, error.ErrorCode, error.Message, error.CreateResponse(format), (int)error.FunctionsCode,
                "Functions " + error.FunctionsCode + (error.UsedCompatibilityPhrase ? " (compatibility phrase)" : string.Empty));
        }

        public static NetworkFailure MapCode(FunctionsErrorCode code)
        {
            switch (code)
            {
                case FunctionsErrorCode.Unavailable: return NetworkFailure.NoConnection;
                case FunctionsErrorCode.DeadlineExceeded: return NetworkFailure.Timeout;
                case FunctionsErrorCode.Unauthenticated: return NetworkFailure.Unauthorized;
                case FunctionsErrorCode.Internal: return NetworkFailure.ServerError;
                case FunctionsErrorCode.InvalidArgument:
                case FunctionsErrorCode.NotFound:
                case FunctionsErrorCode.AlreadyExists:
                case FunctionsErrorCode.PermissionDenied:
                case FunctionsErrorCode.ResourceExhausted:
                case FunctionsErrorCode.FailedPrecondition:
                case FunctionsErrorCode.Aborted:
                case FunctionsErrorCode.OutOfRange:
                    return NetworkFailure.Rejected;
                default: return NetworkFailure.ProviderError;
            }
        }

        private static JObject TryGetDetails(Exception exception)
        {
            if (exception == null) return null;
            try
            {
                PropertyInfo property = exception.GetType().GetProperty("Details", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                return ToObject(property?.GetValue(exception));
            }
            catch (Exception) { return null; }
        }

        private static JObject TryGetExceptionData(Exception exception)
        {
            try
            {
                if (exception?.Data == null || exception.Data.Count == 0) return null;
                var data = new JObject();
                foreach (DictionaryEntry entry in exception.Data)
                {
                    string key = entry.Key?.ToString();
                    if (string.IsNullOrEmpty(key)) continue;
                    data[key] = entry.Value == null ? JValue.CreateNull() : JToken.FromObject(entry.Value);
                }
                return data.Count > 0 ? data : null;
            }
            catch (Exception) { return null; }
        }

        private static JObject TryParseObject(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return null;
            try { return JToken.Parse(text) as JObject; }
            catch (Exception) { return null; }
        }

        private static JObject ToObject(object value)
        {
            if (value == null) return null;
            if (value is JObject objectValue) return objectValue;
            if (value is string text) return TryParseObject(text);
            JToken token = JToken.Parse(JsonConvert.SerializeObject(value));
            return token as JObject ?? new JObject { ["value"] = token };
        }

        private static bool Contains(string source, string value)
            => !string.IsNullOrEmpty(source) && !string.IsNullOrEmpty(value) && source.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0;

        private static string FindString(JToken token, string name)
        {
            if (token == null || string.IsNullOrEmpty(name)) return string.Empty;
            if (token is JObject objectToken)
            {
                foreach (JProperty property in objectToken.Properties())
                    if (string.Equals(property.Name, name, StringComparison.OrdinalIgnoreCase) && property.Value.Type != JTokenType.Object && property.Value.Type != JTokenType.Array)
                        return property.Value.Type == JTokenType.Null ? string.Empty : property.Value.ToString();
                foreach (JProperty property in objectToken.Properties())
                {
                    string nested = FindString(property.Value, name);
                    if (!string.IsNullOrEmpty(nested)) return nested;
                }
            }
            else if (token is JArray array)
            {
                foreach (JToken child in array)
                {
                    string nested = FindString(child, name);
                    if (!string.IsNullOrEmpty(nested)) return nested;
                }
            }
            return string.Empty;
        }
    }
}
