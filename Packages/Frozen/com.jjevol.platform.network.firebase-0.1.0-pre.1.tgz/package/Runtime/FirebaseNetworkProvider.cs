using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Firebase;
using Firebase.Functions;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network.Firebase
{
    /// <summary>Optional settings for <see cref="FirebaseNetworkProvider"/>.</summary>
    public sealed class FirebaseNetworkSettings
    {
        /// <summary>Parameter for the session ID of RequiresSession requests. Null uses <see cref="NetworkResponseFormat.SessionParameter"/>.</summary>
        public string SessionParameter { get; set; }
        /// <summary>Server default message for an invalid session when the SDK hides details (PermissionDenied).</summary>
        public string SessionInvalidPhrase { get; set; } = "Session is invalid";
        /// <summary>Server default message for maintenance when the SDK hides details (Unavailable).</summary>
        public string MaintenancePhrase { get; set; } = "Service is under maintenance";
    }

    /// <summary>
    /// Calls Firebase Functions callables by request name. The Firebase app and region are resolved per environment
    /// key on every attempt, so a runtime switch between live and stage apps needs no new provider. Sign-in is the
    /// SDK's: the callable carries the signed-in user of the same app. The Firebase SDK is installed by the project.
    /// </summary>
    public sealed class FirebaseNetworkProvider : INetworkProvider
    {
        private readonly Func<string, (FirebaseApp App, string Region)> _target;
        private readonly FirebaseNetworkSettings _settings;
        internal Func<NetworkCall, FirebaseApp, string, Task<object>> InvokeOverride;

        /// <summary>One app per environment key (null when not ready) and an optional fixed region.</summary>
        public FirebaseNetworkProvider(Func<string, FirebaseApp> appByEnvironment, string region = null, FirebaseNetworkSettings settings = null)
            : this(WithRegion(appByEnvironment, region), settings) { }

        /// <summary>App and region per environment key.</summary>
        public FirebaseNetworkProvider(Func<string, (FirebaseApp App, string Region)> targetByEnvironment, FirebaseNetworkSettings settings = null)
        {
            _target = targetByEnvironment ?? throw new ArgumentNullException(nameof(targetByEnvironment));
            _settings = settings ?? new FirebaseNetworkSettings();
        }

        private static Func<string, (FirebaseApp, string)> WithRegion(Func<string, FirebaseApp> app, string region)
        {
            if (app == null) throw new ArgumentNullException(nameof(app));
            return environment => (app(environment), region);
        }

        public bool IsReady(string environmentKey) => Resolve(environmentKey).App != null;

        public async Task<NetworkResult> SendAsync(NetworkCall call, CancellationToken cancellationToken)
        {
            (FirebaseApp app, string region) = Resolve(call.EnvironmentKey);
            if (app == null) return NetworkResult.Failed(NetworkFailure.NotInitialized, detail: "No Firebase app for environment " + call.EnvironmentKey + ".");

            Dictionary<string, object> data = BuildData(call);
            object responseData;
            try
            {
                responseData = InvokeOverride != null ? await InvokeOverride(call, app, region) : await InvokeAsync(app, region, call.Request.Name, data);
            }
            catch (Exception exception)
            {
                return MapException(exception, call.Format);
            }
            return Interpret(responseData, call.Format);
        }

        internal Dictionary<string, object> BuildData(NetworkCall call)
        {
            var data = new Dictionary<string, object>(call.Parameters, StringComparer.Ordinal);
            if (call.Request.RequiresSession && !string.IsNullOrEmpty(call.SessionId))
                data[_settings.SessionParameter ?? call.Format.SessionParameter] = call.SessionId;
            return data;
        }

        private static async Task<object> InvokeAsync(FirebaseApp app, string region, string name, Dictionary<string, object> data)
        {
            FirebaseFunctions functions = string.IsNullOrEmpty(region) ? FirebaseFunctions.GetInstance(app) : FirebaseFunctions.GetInstance(app, region);
            HttpsCallableResult result = await functions.GetHttpsCallable(name).CallAsync(data);
            return result?.Data;
        }

        internal NetworkResult MapException(Exception exception, NetworkResponseFormat format)
        {
            FunctionsException functions = FindFunctionsException(exception);
            if (functions != null)
                return FirebaseFunctionsErrorParser.ToResult(FirebaseFunctionsErrorParser.Parse(functions, format, _settings), format);
            return NetworkResult.Failed(NetworkFailure.ProviderError, detail: exception.GetType().Name + ": " + exception.Message);
        }

        internal static NetworkResult Interpret(object data, NetworkResponseFormat format)
        {
            JObject response;
            try
            {
                if (data == null) response = new JObject();
                else
                {
                    JToken token = data as JToken ?? JToken.FromObject(data);
                    response = token as JObject ?? new JObject { [format.DataKey ?? "data"] = token };
                }
            }
            catch (Exception exception)
            {
                return NetworkResult.Failed(NetworkFailure.InvalidResponse, detail: "Cannot convert the callable result: " + exception.Message);
            }
            return format.Interpret(response);
        }

        private static FunctionsException FindFunctionsException(Exception exception)
        {
            for (Exception current = exception; current != null; current = current.InnerException)
            {
                if (current is FunctionsException functions) return functions;
                if (current is AggregateException aggregate)
                    foreach (Exception inner in aggregate.InnerExceptions)
                    {
                        FunctionsException found = FindFunctionsException(inner);
                        if (found != null) return found;
                    }
            }
            return null;
        }

        private (FirebaseApp App, string Region) Resolve(string environmentKey)
        {
            try { return _target(environmentKey ?? string.Empty); }
            catch (Exception) { return (null, null); }
        }
    }
}
