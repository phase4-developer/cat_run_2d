using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Network.Firebase.Tests.Editor")]
