using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using Firebase;
using Firebase.Functions;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace PlatformLibrary.Network.Firebase.Tests
{
    public sealed class FirebaseNetworkProviderTests
    {
        private readonly NetworkResponseFormat _format = new NetworkResponseFormat();

        private sealed class GameRequest : NetworkRequest
        {
            private readonly bool _session;
            public GameRequest(bool session) { _session = session; Add("mailId", "m1"); }
            public override string Name => "claimMailCallable";
            public override bool RequiresSession => _session;
        }

        private static FunctionsException CreateException(FunctionsErrorCode code, string message)
        {
            // The SDK keeps its constructors internal; tests build one by reflection.
            ConstructorInfo constructor = typeof(FunctionsException).GetConstructor(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public,
                null, new[] { typeof(FunctionsErrorCode), typeof(string) }, null);
            if (constructor == null) Assert.Ignore("This Firebase SDK version has no (code, message) FunctionsException constructor.");
            return (FunctionsException)constructor.Invoke(new object[] { code, message });
        }

        private NetworkResult Parse(FunctionsErrorCode code, string message, Exception source = null)
            => FirebaseFunctionsErrorParser.ToResult(FirebaseFunctionsErrorParser.Parse(code, message, source, _format), _format);

        [Test]
        public void DetailsCarryTheGameError()
        {
            var source = new Exception("failed");
            source.Data["errorCode"] = "NOT_ENOUGH_GOLD";
            source.Data["message"] = "gold";
            NetworkResult result = Parse(FunctionsErrorCode.FailedPrecondition, "failed", source);
            Assert.AreEqual(NetworkFailure.Rejected, result.Failure);
            Assert.AreEqual("NOT_ENOUGH_GOLD", result.ServerErrorCode);
            Assert.AreEqual("gold", result.Message);
            Assert.AreEqual((int)FunctionsErrorCode.FailedPrecondition, result.ProviderCode);
        }

        [Test]
        public void MessageJsonAndKnownCodes()
        {
            Assert.AreEqual(NetworkFailure.SessionInvalid, Parse(FunctionsErrorCode.Unknown, "{\"errorCode\":\"SESSION_INVALID\"}").Failure);
            Assert.AreEqual(NetworkFailure.Maintenance, Parse(FunctionsErrorCode.Unknown, "Error: MAINTENANCE_MODE now").Failure);
        }

        [Test]
        public void CompatibilityPhrasesWhenDetailsAreHidden()
        {
            var parsed = FirebaseFunctionsErrorParser.Parse(FunctionsErrorCode.PermissionDenied, "Session is invalid", null, _format);
            Assert.IsTrue(parsed.UsedCompatibilityPhrase);
            Assert.AreEqual(NetworkFailure.SessionInvalid, FirebaseFunctionsErrorParser.ToResult(parsed, _format).Failure);
            Assert.AreEqual(NetworkFailure.Maintenance, Parse(FunctionsErrorCode.Unavailable, "Service is under maintenance").Failure);

            var custom = new FirebaseNetworkSettings { MaintenancePhrase = "closed for repair" };
            var parsedCustom = FirebaseFunctionsErrorParser.Parse(FunctionsErrorCode.Unavailable, "closed for repair", null, _format, custom);
            Assert.AreEqual(_format.MaintenanceCode, parsedCustom.ErrorCode);
        }

        [Test]
        public void FunctionsCodesMapToFailures()
        {
            Assert.AreEqual(NetworkFailure.NoConnection, Parse(FunctionsErrorCode.Unavailable, "unavailable").Failure);
            Assert.AreEqual(NetworkFailure.Timeout, Parse(FunctionsErrorCode.DeadlineExceeded, "deadline").Failure);
            Assert.AreEqual(NetworkFailure.Unauthorized, Parse(FunctionsErrorCode.Unauthenticated, "who").Failure);
            Assert.AreEqual(NetworkFailure.ServerError, Parse(FunctionsErrorCode.Internal, "INTERNAL").Failure);
            NetworkResult rejected = Parse(FunctionsErrorCode.FailedPrecondition, "NO_MAIL");
            Assert.AreEqual(NetworkFailure.Rejected, rejected.Failure);
            Assert.AreEqual("NO_MAIL", rejected.ServerErrorCode);
            Assert.AreEqual(NetworkFailure.ProviderError, Parse(FunctionsErrorCode.Unimplemented, "nope").Failure);
        }

        [Test]
        public void ExceptionsFromTheCallMap()
        {
            var provider = new FirebaseNetworkProvider(_ => (FirebaseApp)null);
            FunctionsException functions = CreateException(FunctionsErrorCode.Unauthenticated, "token");
            Assert.AreEqual(NetworkFailure.Unauthorized, provider.MapException(new AggregateException(functions), _format).Failure);
            Assert.AreEqual(NetworkFailure.ProviderError, provider.MapException(new InvalidOperationException("x"), _format).Failure);
        }

        [Test]
        public void CallableDataIsInterpreted()
        {
            var data = new Dictionary<string, object> { ["data"] = new Dictionary<string, object> { ["gold"] = 3L }, ["timeStamp"] = 5L };
            NetworkResult ok = FirebaseNetworkProvider.Interpret(data, _format);
            Assert.IsTrue(ok.Success);
            Assert.AreEqual(3, ok.Data["gold"].Value<int>());

            NetworkResult rejected = FirebaseNetworkProvider.Interpret(new Dictionary<string, object> { ["errorCode"] = "NO_MAIL", ["message"] = "none" }, _format);
            Assert.AreEqual(NetworkFailure.Rejected, rejected.Failure);
            Assert.IsTrue(FirebaseNetworkProvider.Interpret(null, _format).Success);
            Assert.AreEqual(NetworkFailure.InvalidResponse, FirebaseNetworkProvider.Interpret(new List<object> { 1 }, _format).Failure);
        }

        [Test]
        public void SessionGoesIntoTheCallableData()
        {
            var provider = new FirebaseNetworkProvider(_ => (FirebaseApp)null, settings: new FirebaseNetworkSettings());
            var call = new NetworkCall(new GameRequest(true), new Dictionary<string, object> { ["mailId"] = "m1" }, "live", "s1", 1, NetworkRoute.Server, _format);
            Dictionary<string, object> sent = provider.BuildData(call);
            Assert.AreEqual("s1", sent["sessionId"]);
            Assert.AreEqual("m1", sent["mailId"]);
            Assert.IsFalse(provider.BuildData(new NetworkCall(new GameRequest(false), new Dictionary<string, object>(), "live", "s1", 1, NetworkRoute.Server, _format)).ContainsKey("sessionId"));
        }

        [Test]
        public void MissingAppIsNotReady()
        {
            var provider = new FirebaseNetworkProvider(env => env == "live" ? throw new InvalidOperationException("not created") : (FirebaseApp)null);
            Assert.IsFalse(provider.IsReady("live"));
            Assert.IsFalse(provider.IsReady("stage"));
            Task<NetworkResult> task = provider.SendAsync(new NetworkCall(new GameRequest(false), new Dictionary<string, object>(), "stage", null, 1, NetworkRoute.Server, _format), CancellationToken.None);
            Assert.AreEqual(NetworkFailure.NotInitialized, task.Result.Failure);
        }
    }
}
