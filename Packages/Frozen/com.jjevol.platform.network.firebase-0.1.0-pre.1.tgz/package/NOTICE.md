# Provenance and distribution boundary

User-authored code, written as a redesign of the Firebase path of the user's original network library (`jjevol_library_mobile` `FirebasePostManager`, `FirebaseAPI`, `ServerBackendProvider`, `FirebaseFunctionsErrorParser`, read only). The error parsing order is kept from the user's original parser.

The Firebase Unity SDK (Google, Apache License 2.0) is not bundled. The consuming project installs it. No Firebase configuration files, app IDs, keys, server addresses, company content or paid Vendor source is bundled.

This is an unfrozen local validation candidate. Publishing and installing into existing games remain separate review steps.
