# JJEvol Platform Network Firebase

`com.jjevol.platform.network.firebase@0.1.0-pre.1`은 `com.jjevol.platform.network`의 Firebase Functions 서버 공급자다. 요청 `Name`을 callable 이름으로 부른다. Firebase 앱과 지역은 매 시도마다 현재 환경 키로 고르므로 실행 중에 live와 stage를 바꿀 수 있다. Unity 6000.3.9f1 기준이다.

## 설치 조건

- 필수: `com.jjevol.platform.network@0.1.0-pre.1`, Unity Newtonsoft JSON 3.2.2.
- **Firebase Functions SDK는 프로젝트가 설치한다.** 이 패키지는 SDK를 포함하지 않는다. asmdef는 SDK의 `Firebase.Functions` 어셈블리(SDK 12 이후 소스 asmdef) 또는 `Firebase.Functions.dll`(이전 SDK)과 `Firebase.App.dll`, `Firebase.Platform.dll`을 이름으로 참조한다.
- SDK가 없는 프로젝트에 이 패키지를 설치하면 컴파일되지 않는다. Firebase를 쓰지 않으면 설치하지 않는다.
- Firebase 앱 생성, 환경별 설정 파일, 지역, App Check는 프로젝트가 한다.

## 연결

```csharp
// 게임 서버: 환경마다 다른 Firebase 앱
NetworkManager.SetServerProvider(new FirebaseNetworkProvider(env => GameFirebase.GetApp(env), region: GameFirebase.Region));
// 버전 확인: 환경과 무관한 제어 앱
NetworkManager.SetServerProvider("control", new FirebaseNetworkProvider(env => GameFirebase.ControlApp));
// 환경마다 지역도 다를 때
new FirebaseNetworkProvider(env => (GameFirebase.GetApp(env), GameFirebase.GetRegion(env)));
```

- 앱 함수가 `null`을 돌려주거나 예외를 던지면 `IsReady`가 거짓이고 요청은 `NotInitialized`.
- 인증은 SDK가 같은 Firebase 앱의 로그인 사용자를 붙인다. 로그인은 그 환경의 앱으로 해야 한다.
- `RequiresSession` 요청은 세션 ID를 callable 데이터 `sessionId`(`NetworkResponseFormat.SessionParameter`, `FirebaseNetworkSettings.SessionParameter`로 변경)에 넣는다.

## 응답과 오류

성공한 callable 결과는 JSON 객체로 바꿔 `NetworkResponseFormat`으로 해석한다(기본: `errorCode`, `message`, `data`, `timeStamp`). 응답 안의 `errorCode`는 `Rejected`, `SESSION_INVALID`, `MAINTENANCE_MODE`는 세션 무효와 점검이다.

`FunctionsException`은 원본 파서의 순서로 게임 오류를 찾는다: 예외의 Details → `Exception.Data` → 메시지 JSON → 메시지 안의 세션 무효·점검 코드 → 호환 문구(`PermissionDenied` + `SessionInvalidPhrase`, `Unavailable` + `MaintenancePhrase`, `FirebaseNetworkSettings`에서 바꿈).

| Functions 오류 | 결과 |
|---|---|
| Details에 게임 오류 문자열 | `Rejected` (세션 무효·점검 문자열이면 그것) |
| `Unavailable` | `NoConnection` |
| `DeadlineExceeded` | `Timeout` |
| `Unauthenticated` | `Unauthorized` |
| `Internal` | `ServerError` |
| `InvalidArgument`, `NotFound`, `AlreadyExists`, `PermissionDenied`, `ResourceExhausted`, `FailedPrecondition`, `Aborted`, `OutOfRange` | `Rejected`, 메시지를 오류 문자열로 |
| 그 밖 | `ProviderError` |

Functions 오류 코드는 `result.ProviderCode`에 남는다. 게임은 이 숫자로 분기하지 않는다. callable은 취소 토큰을 받지 않으므로 시간 제한·취소 뒤 늦게 온 응답은 `NetworkManager`가 버린다.

## 시험

`Tests/Editor`(`PlatformLibrary.Network.Firebase.Tests.Editor`)에 오류 해석, 오류 코드 변환, 응답 해석, 세션 데이터, 앱 미준비 시험 8개가 있다. 시험 어셈블리도 Firebase SDK가 있어야 컴파일된다. Unity EditMode 시험 8개는 `Hosts/NetworkFirebaseSdkValidationHost`(Firebase Functions 13.17.0, 잡 `network-firebase-sdk-2`, 후보 `abd61a5`)에서 모두 통과했다. Unity 밖 .NET 실행기에서 해석 시험 5개는 통과했고, `FirebaseApp` 형식을 불러야 하는 3개는 SDK 어셈블리가 로드되지 않아 실행하지 못했다.
