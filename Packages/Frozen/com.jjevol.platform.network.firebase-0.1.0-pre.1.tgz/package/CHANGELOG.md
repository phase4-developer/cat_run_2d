# Changelog

## 0.1.0-pre.1 - 2026-11-08

- First candidate. `FirebaseNetworkProvider`, `FirebaseNetworkSettings`, `FirebaseFunctionsErrorParser`, `FirebaseFunctionError`.

The 8 Unity EditMode tests passed on Hosts/NetworkFirebaseSdkValidationHost with Firebase Functions 13.17.0 (job network-firebase-sdk-2, candidate abd61a5). In an offline .NET runner compiled against a game's Firebase SDK, the 5 parser and response tests passed; the 3 tests that load the `FirebaseApp` type could not run outside Unity.
