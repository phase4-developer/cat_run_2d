# Changelog

## 0.1.0-pre.3 - 2026-11-11

- Test assemblies reference `JJEvol.UI.Contracts.Runtime`, because `IScreenData` and `IPopupData` moved to `com.jjevol.ui.contracts`. UI Core dependency raised to 0.1.0-pre.3, which brings that package. No runtime source change.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.2 - 2026-11-06

- Updated internal dependency versions. No source change.

Unity tests for this candidate are NOT_RUN.
