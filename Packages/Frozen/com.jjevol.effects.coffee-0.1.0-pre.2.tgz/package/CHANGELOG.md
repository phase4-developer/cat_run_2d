# Changelog

## 0.1.0-pre.2 - 2026-11-11

- Tests only. The coexistence test fixture (`Tests/Coexist~`) references `JJEvol.UI.Contracts.Runtime`, where `UIAddress` now lives.

## 0.1.0-pre.1

- Extract original SyncUIParticleScale with unchanged public API, serialized fields and Script GUID.
- Keep Coffee dependency optional, with no Effects Core reverse dependency.
- Guard the existing deferred Start continuation after component destruction; retain original scale formula and encoding.
- Add isolated real-SDK contract, runtime, rendering and selected coexistence validation. No SDK or game content is bundled.
