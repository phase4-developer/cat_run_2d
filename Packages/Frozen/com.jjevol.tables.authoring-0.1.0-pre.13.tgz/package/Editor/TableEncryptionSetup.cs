using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// Applies the encryption chosen in Table Builder project settings, so a game needs no code to encrypt tables.
    /// "on" registers the built-in <see cref="TableEncryption"/> codec and writes the key into Resources;
    /// "off" writes plaintext; "" leaves <see cref="TableAuthoringOptions"/> to game code as before.
    /// </summary>
    [InitializeOnLoad]
    internal static class TableEncryptionSetup
    {
        internal const string CodecPrefix = "jjevol-aes:v1:";
        private static Func<byte[], byte[]> s_encrypt, s_decrypt;
        private static string s_keyText;

        // Runs after every [InitializeOnLoad] so the saved setting wins over a game registration made at load.
        // TableBuilder.Build and the window's review apply it again, which covers batch -executeMethod runs.
        static TableEncryptionSetup() => EditorApplication.delayCall += () =>
        {
            try { Apply(TableAuthoringProjectSettings.Read()); }
            catch (Exception e) { Debug.LogWarning("[Table Builder] Table encryption setting could not be applied: " + e.Message); }
        };

        internal static byte[] ParseKey(string text)
        {
            byte[] key;
            try { key = Convert.FromBase64String(text ?? ""); }
            catch (FormatException) { throw new ArgumentException("Table encryption key must be Base64 of 32 bytes. Settings were not saved."); }
            if (key.Length != TableEncryption.KeyLength) throw new ArgumentException("Table encryption key must be Base64 of 32 bytes. Settings were not saved.");
            return key;
        }

        internal static string KeyId(string text) { try { return TableEncryption.KeyId(ParseKey(text)); } catch (ArgumentException) { return ""; } }

        internal static void Apply(TableAuthoringProjectSettings settings)
        {
            if (settings.encryption == TableAuthoringProjectSettings.EncryptionOn)
            {
                byte[] key = ParseKey(settings.encryptionKey);
                if (s_keyText != settings.encryptionKey)
                {
                    // Fresh delegates only when the key changes: a prepared plan compares the registered delegates by identity.
                    s_encrypt = plain => TableEncryption.Encrypt(key, plain);
                    s_decrypt = data => TableEncryption.Decrypt(key, data);
                    s_keyText = settings.encryptionKey;
                }
                TableAuthoringOptions.UseEncryption = true;
                TableAuthoringOptions.EncryptBytes = s_encrypt;
                TableRuntimeOptions.DecryptBytes = s_decrypt;
                TableAuthoringOptions.CodecProfileVersion = CodecPrefix + TableEncryption.KeyId(key);
                return;
            }
            ReleaseBuiltIn();
            if (settings.encryption == TableAuthoringProjectSettings.EncryptionOff) TableAuthoringOptions.UseEncryption = false;
        }

        private static void ReleaseBuiltIn()
        {
            if (s_encrypt != null && TableAuthoringOptions.EncryptBytes == s_encrypt) TableAuthoringOptions.EncryptBytes = null;
            if (s_decrypt != null && TableRuntimeOptions.DecryptBytes == s_decrypt) TableRuntimeOptions.DecryptBytes = null;
            if ((TableAuthoringOptions.CodecProfileVersion ?? "").StartsWith(CodecPrefix, StringComparison.Ordinal)) TableAuthoringOptions.CodecProfileVersion = "";
        }

        /// <summary>The key file the Runtime loads: <c>JJEvolTableKey.bytes</c> in the Resources root that holds the table output.</summary>
        internal static string KeyPath(string outputDirectory)
        {
            string full = TablePaths.Output(outputDirectory);
            string[] parts = full.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            int resources = Array.LastIndexOf(parts, "Resources");
            return string.Join(Path.DirectorySeparatorChar.ToString(), parts.Take(resources + 1)) + Path.DirectorySeparatorChar + TableEncryption.KeyResourceName + ".bytes";
        }

        /// <summary>Writes the key file when encryption is on and removes it when off. Game-code mode leaves it alone. Returns true when a file changed.</summary>
        internal static bool SyncKeyFile(TableAuthoringProjectSettings settings, string outputDirectory)
        {
            if (settings.encryption == "") return false;
            string path = KeyPath(outputDirectory); TablePaths.NoReparse(path);
            string asset = TablePaths.Relative(path);
            if (settings.encryption == TableAuthoringProjectSettings.EncryptionOn)
            {
                byte[] key = ParseKey(settings.encryptionKey);
                if (File.Exists(path) && File.ReadAllBytes(path).SequenceEqual(key)) return false;
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.WriteAllBytes(path, key); TableEncryption.ForgetLoadedKey();
                AssetDatabase.ImportAsset(asset, ImportAssetOptions.ForceSynchronousImport);
                return true;
            }
            if (!File.Exists(path)) return false;
            TableEncryption.ForgetLoadedKey();
            if (!AssetDatabase.DeleteAsset(asset)) { File.Delete(path); if (File.Exists(path + ".meta")) File.Delete(path + ".meta"); }
            return true;
        }
    }
}
