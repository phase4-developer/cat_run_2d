using System;
using System.IO;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;

namespace jjevol.Tables.Authoring.Tests
{
    /// <summary>Encryption chosen in Table Builder project settings, with no game code registering a codec.</summary>
    public sealed class TableEncryptionSetupTests
    {
        private const BindingFlags Hidden = BindingFlags.NonPublic | BindingFlags.Static;
        private string _root, _output;
        private bool _useEncryption; private Func<byte[], byte[]> _encrypt, _decrypt; private string _codec;

        private static Type Internal(string name) => typeof(TableAuthoringOptions).Assembly.GetType("jjevol." + name, true);
        private static object Settings(string encryption, string key)
        {
            object settings = Activator.CreateInstance(Internal("TableAuthoringProjectSettings"), true);
            settings.GetType().GetField("encryption").SetValue(settings, encryption);
            settings.GetType().GetField("encryptionKey").SetValue(settings, key);
            return settings;
        }
        private static void Apply(object settings) => Internal("TableEncryptionSetup").GetMethod("Apply", Hidden).Invoke(null, new[] { settings });
        private bool Sync(object settings) => (bool)Internal("TableEncryptionSetup").GetMethod("SyncKeyFile", Hidden).Invoke(null, new[] { settings, _output });
        private string KeyFile => _root + "/Resources/" + TableEncryption.KeyResourceName + ".bytes";

        [SetUp] public void Setup()
        {
            _root = "Assets/JJEvolStepTableEncryption_" + Guid.NewGuid().ToString("N"); _output = _root + "/Resources/Tables";
            _useEncryption = TableAuthoringOptions.UseEncryption; _encrypt = TableAuthoringOptions.EncryptBytes;
            _decrypt = TableRuntimeOptions.DecryptBytes; _codec = TableAuthoringOptions.CodecProfileVersion;
            TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null; TableAuthoringOptions.CodecProfileVersion = "";
        }
        [TearDown] public void Cleanup()
        {
            Apply(Settings("off", ""));
            TableAuthoringOptions.UseEncryption = _useEncryption; TableAuthoringOptions.EncryptBytes = _encrypt;
            TableRuntimeOptions.DecryptBytes = _decrypt; TableAuthoringOptions.CodecProfileVersion = _codec;
            PipelineValidation.ForgetFixtureMetadata(_root); AssetDatabase.Refresh(); if (AssetDatabase.IsValidFolder(_root)) AssetDatabase.DeleteAsset(_root);
            TableEncryption.ForgetLoadedKey();
        }

        [Test]
        public void OnBuildsEncryptedTablesThatLoadWithoutAnyGameCode()
        {
            byte[] key = TableEncryption.NewKey(); object settings = Settings("on", Convert.ToBase64String(key));
            Apply(settings);
            Assert.That(TableAuthoringOptions.UseEncryption, Is.True);
            Assert.That(TableAuthoringOptions.CodecProfileVersion, Is.EqualTo("jjevol-aes:v1:" + TableEncryption.KeyId(key)));
            Assert.That(Sync(settings), Is.True); Assert.That(File.ReadAllBytes(KeyFile), Is.EqualTo(key)); Assert.That(Sync(settings), Is.False);

            var input = TableInput.FromText("a", "key\tlabel\nx\ty");
            var result = TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(new[] { input }, _output, TableAuthoringOptions.UseEncryption))).Apply();
            Assert.That(result.State, Is.Not.EqualTo(TableBuildState.RecoveryRequired));
            string text = File.ReadAllText(_output + "/a.txt");
            Assert.That(TableEncryption.IsEncryptedText(text), Is.True);
            Assert.That(System.Text.Encoding.UTF8.GetString(TableEncryption.Decrypt(key, Convert.FromBase64String(text.Trim('﻿')))), Is.EqualTo("key\tlabel\nx\ty"));

            // A game that never registered a decoder and still passes useEncrypt:false reads the table.
            AssetDatabase.Refresh(); TableRuntimeOptions.DecryptBytes = null;
            TableEncryption.ForgetLoadedKey();
            var rows = TableUtil.LoadLocalTable("Tables/a", useEncrypt: false);
            Assert.That(rows.Count, Is.EqualTo(1)); Assert.That(rows[0].Get("label"), Is.EqualTo("y"));
        }

        [Test]
        public void SameKeyKeepsTheRegisteredCodecAndANewKeyReplacesIt()
        {
            string key = Convert.ToBase64String(TableEncryption.NewKey());
            Apply(Settings("on", key)); var first = TableAuthoringOptions.EncryptBytes; var decoder = TableRuntimeOptions.DecryptBytes;
            Apply(Settings("on", key));
            Assert.That(TableAuthoringOptions.EncryptBytes, Is.SameAs(first)); Assert.That(TableRuntimeOptions.DecryptBytes, Is.SameAs(decoder));
            Apply(Settings("on", Convert.ToBase64String(TableEncryption.NewKey())));
            Assert.That(TableAuthoringOptions.EncryptBytes, Is.Not.SameAs(first));
        }

        [Test]
        public void OffWritesPlaintextAndRemovesTheKeyFile()
        {
            string key = Convert.ToBase64String(TableEncryption.NewKey());
            Apply(Settings("on", key)); Sync(Settings("on", key)); Assert.That(File.Exists(KeyFile), Is.True);
            object off = Settings("off", key); Apply(off);
            Assert.That(TableAuthoringOptions.UseEncryption, Is.False); Assert.That(TableAuthoringOptions.EncryptBytes, Is.Null);
            Assert.That(TableRuntimeOptions.DecryptBytes, Is.Null); Assert.That(TableAuthoringOptions.CodecProfileVersion, Is.Empty);
            Assert.That(Sync(off), Is.True); Assert.That(File.Exists(KeyFile), Is.False);
        }

        [Test]
        public void GameCodeModeLeavesTheGameRegistrationAlone()
        {
            Func<byte[], byte[]> game = b => b;
            TableAuthoringOptions.UseEncryption = true; TableAuthoringOptions.EncryptBytes = game; TableAuthoringOptions.CodecProfileVersion = "game:v1";
            object settings = Settings("", ""); Apply(settings);
            Assert.That(TableAuthoringOptions.EncryptBytes, Is.SameAs(game)); Assert.That(TableAuthoringOptions.UseEncryption, Is.True);
            Assert.That(TableAuthoringOptions.CodecProfileVersion, Is.EqualTo("game:v1")); Assert.That(Sync(settings), Is.False);
        }

        [Test]
        public void ABadKeyIsRejected()
        {
            var error = Assert.Throws<TargetInvocationException>(() => Apply(Settings("on", "not-base64")));
            Assert.That(error.InnerException, Is.TypeOf<ArgumentException>());
        }
    }
}
