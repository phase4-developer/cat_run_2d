namespace PlatformLibrary.Analytics
{
    /// <summary>One analytics SDK behind <see cref="AnalyticsManager"/>.</summary>
    public interface IAnalyticsProvider
    {
        /// <summary>False while the provider cannot send. The manager skips it.</summary>
        bool IsEnabled { get; }

        /// <summary>Sends one event in the SDK's format. The manager catches exceptions.</summary>
        void Log(AnalyticsEvent analyticsEvent);

        /// <summary>
        /// Turns SDK collection on or off. <see cref="AnalyticsManager.AddProvider"/> calls this once with the
        /// current state, so a provider can start its SDK here and never starts it while collection is off.
        /// </summary>
        void SetCollectionEnabled(bool enabled);
    }
}
