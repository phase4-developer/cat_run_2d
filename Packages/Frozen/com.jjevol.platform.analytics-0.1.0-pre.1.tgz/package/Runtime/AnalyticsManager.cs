using System;
using System.Collections.Generic;
using UnityEngine;

namespace PlatformLibrary.Analytics
{
    /// <summary>
    /// The only analytics type the game calls. The project adds providers in its start code.
    /// With no provider every call does nothing.
    /// </summary>
    public static class AnalyticsManager
    {
        private const string AdRevenueEventName = "ad_revenue_paid";
        private const string DefaultAdPlatform = "unknown";
        private const string DefaultCurrency = "USD";

        private sealed class Registration
        {
            public readonly IAnalyticsProvider Provider;
            public readonly Func<AnalyticsEvent, bool> Filter;

            public Registration(IAnalyticsProvider provider, Func<AnalyticsEvent, bool> filter)
            {
                Provider = provider;
                Filter = filter;
            }
        }

        private static readonly List<Registration> registrations = new List<Registration>();
        private static bool collectionEnabled = true;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetForPlay()
        {
            registrations.Clear();
            collectionEnabled = true;
        }

        /// <summary>
        /// Adds a provider. <paramref name="filter"/> decides which events it receives; null means all of them.
        /// Adding the same instance twice keeps the first registration.
        /// </summary>
        public static void AddProvider(IAnalyticsProvider provider, Func<AnalyticsEvent, bool> filter = null)
        {
            if (provider == null)
                return;

            for (int i = 0; i < registrations.Count; i++)
            {
                if (ReferenceEquals(registrations[i].Provider, provider))
                    return;
            }

            registrations.Add(new Registration(provider, filter));
            ApplyCollectionEnabled(provider);
        }

        /// <summary>Removes every provider. The collection state stays, so a consent choice survives.</summary>
        public static void Clear()
        {
            registrations.Clear();
        }

        /// <summary>Turns collection on or off for current and later providers.</summary>
        public static void SetCollectionEnabled(bool enabled)
        {
            collectionEnabled = enabled;

            for (int i = 0; i < registrations.Count; i++)
                ApplyCollectionEnabled(registrations[i].Provider);
        }

        public static void Log(string name, params (string Key, object Value)[] parameters)
        {
            Log(name, AnalyticsStandardEvent.None, parameters);
        }

        public static void Log(string name, AnalyticsStandardEvent standardEvent, params (string Key, object Value)[] parameters)
        {
            if (!CanLog(name))
                return;

            Log(new AnalyticsEvent(name, standardEvent, ToDictionary(parameters)));
        }

        public static void Log(AnalyticsEvent analyticsEvent)
        {
            if (analyticsEvent == null || !CanLog(analyticsEvent.Name))
                return;

            for (int i = 0; i < registrations.Count; i++)
            {
                Registration registration = registrations[i];

                try
                {
                    if (!registration.Provider.IsEnabled)
                        continue;

                    if (registration.Filter != null && !registration.Filter(analyticsEvent))
                        continue;

                    registration.Provider.Log(analyticsEvent);
                }
                catch (Exception e)
                {
                    Debug.LogWarning($"[AnalyticsManager] {registration.Provider.GetType().Name} failed. Event:{analyticsEvent.Name}, Error:{e.Message}");
                }
            }
        }

        /// <summary>
        /// Logs a <see cref="AnalyticsStandardEvent.Purchase"/> with the transaction_id, value and currency parameters.
        /// A negative revenue becomes 0 and an empty currency becomes USD. Product details go in <paramref name="parameters"/>.
        /// This is analytics data, never a reason to grant anything.
        /// </summary>
        public static void LogPurchase(
            string name,
            string transactionId,
            double revenue,
            string currencyCode,
            params (string Key, object Value)[] parameters)
        {
            if (!CanLog(name))
                return;

            Dictionary<string, object> values = ToDictionary(parameters);
            values["transaction_id"] = transactionId ?? string.Empty;
            values["value"] = Math.Max(revenue, 0d);
            values["currency"] = string.IsNullOrEmpty(currencyCode) ? DefaultCurrency : currencyCode;

            Log(new AnalyticsEvent(name, AnalyticsStandardEvent.Purchase, values));
        }

        /// <summary>
        /// Logs an <see cref="AnalyticsStandardEvent.AdRevenue"/> event named ad_revenue_paid. A negative revenue becomes 0,
        /// an empty platform becomes unknown, an empty source becomes the platform and an empty currency becomes USD.
        /// </summary>
        public static void LogAdRevenue(
            string adPlatform,
            string adSource,
            string adUnitId,
            string adFormat,
            double revenue,
            string currencyCode,
            string placement = "",
            string countryCode = "")
        {
            if (!CanLog(AdRevenueEventName))
                return;

            string platform = string.IsNullOrEmpty(adPlatform) ? DefaultAdPlatform : adPlatform;

            Log(new AnalyticsEvent(
                AdRevenueEventName,
                AnalyticsStandardEvent.AdRevenue,
                new Dictionary<string, object>
                {
                    { "ad_format", adFormat ?? string.Empty },
                    { "value", Math.Max(revenue, 0d) },
                    { "currency", string.IsNullOrEmpty(currencyCode) ? DefaultCurrency : currencyCode },
                    { "ad_platform", platform },
                    { "ad_source", string.IsNullOrEmpty(adSource) ? platform : adSource },
                    { "ad_unit_name", adUnitId ?? string.Empty },
                    { "placement", placement ?? string.Empty },
                    { "ad_country_code", countryCode ?? string.Empty },
                }));
        }

        private static bool CanLog(string name)
        {
            return collectionEnabled && registrations.Count > 0 && !string.IsNullOrEmpty(name);
        }

        private static void ApplyCollectionEnabled(IAnalyticsProvider provider)
        {
            try
            {
                provider.SetCollectionEnabled(collectionEnabled);
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[AnalyticsManager] {provider.GetType().Name} failed to set collection. Error:{e.Message}");
            }
        }

        private static Dictionary<string, object> ToDictionary((string Key, object Value)[] parameters)
        {
            Dictionary<string, object> result = new Dictionary<string, object>();

            if (parameters == null)
                return result;

            for (int i = 0; i < parameters.Length; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Key))
                    result[parameters[i].Key] = parameters[i].Value;
            }

            return result;
        }
    }
}
