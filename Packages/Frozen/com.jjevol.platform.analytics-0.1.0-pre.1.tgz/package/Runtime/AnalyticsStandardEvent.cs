namespace PlatformLibrary.Analytics
{
    /// <summary>
    /// A concept the analytics SDKs share. Providers turn it into their own standard event.
    /// Game concepts stay out of this list: a stage clear is logged as <see cref="LevelAchieved"/>.
    /// </summary>
    public enum AnalyticsStandardEvent
    {
        None = 0,
        TutorialComplete,
        LevelAchieved,
        AchievementUnlocked,
        VirtualCurrencySpent,
        Purchase,
        AdReward,
        AdRevenue,
    }
}
