using System.Collections.Generic;

namespace PlatformLibrary.Analytics
{
    /// <summary>One event as providers and filters see it. It keeps its own copy of the parameters.</summary>
    public sealed class AnalyticsEvent
    {
        public string Name { get; }
        public AnalyticsStandardEvent StandardEvent { get; }
        public IReadOnlyDictionary<string, object> Parameters { get; }

        public AnalyticsEvent(
            string name,
            AnalyticsStandardEvent standardEvent = AnalyticsStandardEvent.None,
            IReadOnlyDictionary<string, object> parameters = null)
        {
            Name = name;
            StandardEvent = standardEvent;

            Dictionary<string, object> copy = new Dictionary<string, object>();

            if (parameters != null)
            {
                foreach (KeyValuePair<string, object> pair in parameters)
                {
                    if (!string.IsNullOrEmpty(pair.Key))
                        copy[pair.Key] = pair.Value;
                }
            }

            Parameters = copy;
        }
    }
}
