using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Analytics.Tests
{
    public sealed class AnalyticsManagerTests
    {
        private sealed class RecordingProvider : IAnalyticsProvider
        {
            public readonly List<AnalyticsEvent> Events = new List<AnalyticsEvent>();
            public readonly List<bool> CollectionCalls = new List<bool>();
            public bool IsEnabled { get; set; } = true;
            public Exception LogFailure { get; set; }
            public Exception CollectionFailure { get; set; }

            public void Log(AnalyticsEvent analyticsEvent)
            {
                if (LogFailure != null)
                    throw LogFailure;

                Events.Add(analyticsEvent);
            }

            public void SetCollectionEnabled(bool enabled)
            {
                CollectionCalls.Add(enabled);

                if (CollectionFailure != null)
                    throw CollectionFailure;
            }
        }

        [SetUp]
        [TearDown]
        public void ResetManager()
        {
            AnalyticsManager.Clear();
            AnalyticsManager.SetCollectionEnabled(true);
        }

        [Test]
        public void PlayStartWithoutDomainReloadDropsOldProvidersAndTurnsCollectionOn()
        {
            RecordingProvider old = new RecordingProvider();
            AnalyticsManager.AddProvider(old);
            AnalyticsManager.SetCollectionEnabled(false);

            MethodInfo playStartReset = typeof(AnalyticsManager)
                .GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
                .FirstOrDefault(method =>
                    method.GetCustomAttribute<RuntimeInitializeOnLoadMethodAttribute>()?.loadType == RuntimeInitializeLoadType.SubsystemRegistration);
            Assert.That(playStartReset, Is.Not.Null);
            playStartReset.Invoke(null, null);

            RecordingProvider next = new RecordingProvider();
            AnalyticsManager.AddProvider(next);
            AnalyticsManager.Log("second_play");

            Assert.That(old.Events, Is.Empty);
            Assert.That(next.Events.Select(item => item.Name), Is.EqualTo(new[] { "second_play" }));
            Assert.That(next.CollectionCalls, Is.EqualTo(new[] { true }));
        }

        [Test]
        public void WithoutProviderEveryCallDoesNothing()
        {
            AnalyticsManager.Log("plain");
            AnalyticsManager.Log("stage_clear", AnalyticsStandardEvent.LevelAchieved, ("stage", 10));
            AnalyticsManager.Log(new AnalyticsEvent("object"));
            AnalyticsManager.LogPurchase("buy", "order", 1d, "USD");
            AnalyticsManager.LogAdRevenue("platform", "source", "unit", "rewarded", 0.1d, "USD");
            AnalyticsManager.SetCollectionEnabled(false);
            AnalyticsManager.SetCollectionEnabled(true);
            AnalyticsManager.Clear();

            LogAssert.NoUnexpectedReceived();
        }

        [Test]
        public void LogReachesEveryProviderWithNameStandardEventAndParameters()
        {
            RecordingProvider first = new RecordingProvider();
            RecordingProvider second = new RecordingProvider();
            AnalyticsManager.AddProvider(first);
            AnalyticsManager.AddProvider(second);

            AnalyticsManager.Log("stage_clear", AnalyticsStandardEvent.LevelAchieved, ("stage", 10), ("hard", true));

            foreach (RecordingProvider provider in new[] { first, second })
            {
                Assert.That(provider.Events, Has.Count.EqualTo(1));
                AnalyticsEvent logged = provider.Events[0];
                Assert.That(logged.Name, Is.EqualTo("stage_clear"));
                Assert.That(logged.StandardEvent, Is.EqualTo(AnalyticsStandardEvent.LevelAchieved));
                Assert.That(logged.Parameters["stage"], Is.EqualTo(10));
                Assert.That(logged.Parameters["hard"], Is.EqualTo(true));
            }
        }

        [Test]
        public void LogWithoutStandardEventUsesNone()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);

            AnalyticsManager.Log("use_ticket", ("season_id", 3));
            AnalyticsManager.Log("plain");

            Assert.That(provider.Events[0].StandardEvent, Is.EqualTo(AnalyticsStandardEvent.None));
            Assert.That(provider.Events[0].Parameters["season_id"], Is.EqualTo(3));
            Assert.That(provider.Events[1].Parameters.Count, Is.EqualTo(0));
        }

        [Test]
        public void FilterChoosesEventsPerProvider()
        {
            RecordingProvider everything = new RecordingProvider();
            RecordingProvider noPurchases = new RecordingProvider();
            RecordingProvider onlyNamed = new RecordingProvider();
            AnalyticsManager.AddProvider(everything);
            AnalyticsManager.AddProvider(noPurchases, e => e.StandardEvent != AnalyticsStandardEvent.Purchase);
            AnalyticsManager.AddProvider(onlyNamed, e => e.Name.StartsWith("mode_", StringComparison.Ordinal));

            AnalyticsManager.Log("mode_start");
            AnalyticsManager.LogPurchase("buy", "order", 1d, "USD");
            AnalyticsManager.Log("other");

            Assert.That(Names(everything), Is.EqualTo(new[] { "mode_start", "buy", "other" }));
            Assert.That(Names(noPurchases), Is.EqualTo(new[] { "mode_start", "other" }));
            Assert.That(Names(onlyNamed), Is.EqualTo(new[] { "mode_start" }));
        }

        [Test]
        public void FilterSeesParameters()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider, e => e.Parameters.ContainsKey("send"));

            AnalyticsManager.Log("skip");
            AnalyticsManager.Log("keep", ("send", 1));

            Assert.That(Names(provider), Is.EqualTo(new[] { "keep" }));
        }

        [Test]
        public void NullProviderIsIgnoredAndSameInstanceIsAddedOnce()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(null);
            AnalyticsManager.AddProvider(provider);
            AnalyticsManager.AddProvider(provider, e => false);

            AnalyticsManager.Log("once");

            Assert.That(Names(provider), Is.EqualTo(new[] { "once" }));
            Assert.That(provider.CollectionCalls, Is.EqualTo(new[] { true }));
        }

        [Test]
        public void DisabledProviderIsSkipped()
        {
            RecordingProvider disabled = new RecordingProvider { IsEnabled = false };
            RecordingProvider enabled = new RecordingProvider();
            AnalyticsManager.AddProvider(disabled);
            AnalyticsManager.AddProvider(enabled);

            AnalyticsManager.Log("event");

            Assert.That(disabled.Events, Is.Empty);
            Assert.That(enabled.Events, Has.Count.EqualTo(1));
        }

        [Test]
        public void FailingProviderDoesNotStopTheOthers()
        {
            RecordingProvider failing = new RecordingProvider { LogFailure = new InvalidOperationException("boom") };
            RecordingProvider healthy = new RecordingProvider();
            AnalyticsManager.AddProvider(failing);
            AnalyticsManager.AddProvider(healthy);

            LogAssert.Expect(LogType.Warning, "[AnalyticsManager] RecordingProvider failed. Event:event, Error:boom");
            AnalyticsManager.Log("event");

            Assert.That(healthy.Events, Has.Count.EqualTo(1));
        }

        [Test]
        public void FailingFilterDoesNotStopTheOthers()
        {
            RecordingProvider filtered = new RecordingProvider();
            RecordingProvider healthy = new RecordingProvider();
            AnalyticsManager.AddProvider(filtered, e => throw new InvalidOperationException("filter"));
            AnalyticsManager.AddProvider(healthy);

            LogAssert.Expect(LogType.Warning, "[AnalyticsManager] RecordingProvider failed. Event:event, Error:filter");
            AnalyticsManager.Log("event");

            Assert.That(filtered.Events, Is.Empty);
            Assert.That(healthy.Events, Has.Count.EqualTo(1));
        }

        [Test]
        public void FailingCollectionCallDoesNotReachTheGame()
        {
            RecordingProvider failing = new RecordingProvider { CollectionFailure = new InvalidOperationException("sdk") };

            LogAssert.Expect(LogType.Warning, "[AnalyticsManager] RecordingProvider failed to set collection. Error:sdk");
            AnalyticsManager.AddProvider(failing);

            LogAssert.Expect(LogType.Warning, "[AnalyticsManager] RecordingProvider failed to set collection. Error:sdk");
            AnalyticsManager.SetCollectionEnabled(false);

            Assert.That(failing.CollectionCalls, Is.EqualTo(new[] { true, false }));
        }

        [Test]
        public void CollectionOffStopsEveryProviderAndOnResumes()
        {
            RecordingProvider first = new RecordingProvider();
            RecordingProvider second = new RecordingProvider();
            AnalyticsManager.AddProvider(first);
            AnalyticsManager.AddProvider(second);

            AnalyticsManager.SetCollectionEnabled(false);
            AnalyticsManager.Log("off");
            AnalyticsManager.LogPurchase("off", "order", 1d, "USD");
            AnalyticsManager.LogAdRevenue("platform", "source", "unit", "rewarded", 0.1d, "USD");
            AnalyticsManager.SetCollectionEnabled(true);
            AnalyticsManager.Log("on");

            Assert.That(Names(first), Is.EqualTo(new[] { "on" }));
            Assert.That(Names(second), Is.EqualTo(new[] { "on" }));
            Assert.That(first.CollectionCalls, Is.EqualTo(new[] { true, false, true }));
            Assert.That(second.CollectionCalls, Is.EqualTo(new[] { true, false, true }));
        }

        [Test]
        public void ProviderAddedWhileCollectionIsOffStartsOff()
        {
            AnalyticsManager.SetCollectionEnabled(false);
            RecordingProvider provider = new RecordingProvider();

            AnalyticsManager.AddProvider(provider);

            Assert.That(provider.CollectionCalls, Is.EqualTo(new[] { false }));
        }

        [Test]
        public void ClearRemovesProvidersAndKeepsCollectionState()
        {
            RecordingProvider removed = new RecordingProvider();
            AnalyticsManager.AddProvider(removed);
            AnalyticsManager.SetCollectionEnabled(false);

            AnalyticsManager.Clear();
            RecordingProvider added = new RecordingProvider();
            AnalyticsManager.AddProvider(added);
            AnalyticsManager.SetCollectionEnabled(true);
            AnalyticsManager.Log("event");

            Assert.That(removed.Events, Is.Empty);
            Assert.That(added.CollectionCalls, Is.EqualTo(new[] { false, true }));
            Assert.That(added.Events, Has.Count.EqualTo(1));
        }

        [Test]
        public void EmptyNameAndNullEventAreIgnored()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);

            AnalyticsManager.Log(string.Empty);
            AnalyticsManager.Log((string)null);
            AnalyticsManager.Log((AnalyticsEvent)null);
            AnalyticsManager.Log(new AnalyticsEvent(string.Empty));
            AnalyticsManager.LogPurchase(string.Empty, "order", 1d, "USD");

            Assert.That(provider.Events, Is.Empty);
        }

        [Test]
        public void LogAcceptsAPreparedEvent()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);
            Dictionary<string, object> parameters = new Dictionary<string, object> { { "level", 5 } };

            AnalyticsManager.Log(new AnalyticsEvent("lv_5", AnalyticsStandardEvent.LevelAchieved, parameters));

            Assert.That(provider.Events[0].StandardEvent, Is.EqualTo(AnalyticsStandardEvent.LevelAchieved));
            Assert.That(provider.Events[0].Parameters["level"], Is.EqualTo(5));
        }

        [Test]
        public void EventKeepsItsOwnParametersAndDropsEmptyKeys()
        {
            Dictionary<string, object> parameters = new Dictionary<string, object> { { "kept", 1 }, { string.Empty, 2 } };

            AnalyticsEvent analyticsEvent = new AnalyticsEvent("event", parameters: parameters);
            parameters["kept"] = 3;

            Assert.That(analyticsEvent.Parameters["kept"], Is.EqualTo(1));
            Assert.That(analyticsEvent.Parameters.Count, Is.EqualTo(1));
        }

        [Test]
        public void TupleParametersDropEmptyKeysAndLastValueWins()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);

            AnalyticsManager.Log("event", (null, 1), ("key", 1), ("key", 2));

            Assert.That(provider.Events[0].Parameters.Count, Is.EqualTo(1));
            Assert.That(provider.Events[0].Parameters["key"], Is.EqualTo(2));
        }

        [Test]
        public void LogPurchaseFillsPurchaseParameters()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);

            AnalyticsManager.LogPurchase("buy_product_7", "order-1", 4.99d, "KRW", ("product_id", 7), ("quantity", 1));

            AnalyticsEvent logged = provider.Events[0];
            Assert.That(logged.Name, Is.EqualTo("buy_product_7"));
            Assert.That(logged.StandardEvent, Is.EqualTo(AnalyticsStandardEvent.Purchase));
            Assert.That(logged.Parameters["transaction_id"], Is.EqualTo("order-1"));
            Assert.That(logged.Parameters["value"], Is.EqualTo(4.99d));
            Assert.That(logged.Parameters["currency"], Is.EqualTo("KRW"));
            Assert.That(logged.Parameters["product_id"], Is.EqualTo(7));
            Assert.That(logged.Parameters["quantity"], Is.EqualTo(1));
        }

        [Test]
        public void LogPurchaseNormalizesInvalidValues()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);

            AnalyticsManager.LogPurchase("buy", null, -1d, null, ("value", 99d));

            AnalyticsEvent logged = provider.Events[0];
            Assert.That(logged.Parameters["transaction_id"], Is.EqualTo(string.Empty));
            Assert.That(logged.Parameters["value"], Is.EqualTo(0d));
            Assert.That(logged.Parameters["currency"], Is.EqualTo("USD"));
        }

        [Test]
        public void LogAdRevenueFillsAdRevenueParameters()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);

            AnalyticsManager.LogAdRevenue("admob", "network", "unit", "rewarded", 0.25d, "EUR", "revive", "KR");

            AnalyticsEvent logged = provider.Events[0];
            Assert.That(logged.Name, Is.EqualTo("ad_revenue_paid"));
            Assert.That(logged.StandardEvent, Is.EqualTo(AnalyticsStandardEvent.AdRevenue));
            Assert.That(logged.Parameters["ad_platform"], Is.EqualTo("admob"));
            Assert.That(logged.Parameters["ad_source"], Is.EqualTo("network"));
            Assert.That(logged.Parameters["ad_unit_name"], Is.EqualTo("unit"));
            Assert.That(logged.Parameters["ad_format"], Is.EqualTo("rewarded"));
            Assert.That(logged.Parameters["value"], Is.EqualTo(0.25d));
            Assert.That(logged.Parameters["currency"], Is.EqualTo("EUR"));
            Assert.That(logged.Parameters["placement"], Is.EqualTo("revive"));
            Assert.That(logged.Parameters["ad_country_code"], Is.EqualTo("KR"));
        }

        [Test]
        public void LogAdRevenueNormalizesInvalidValues()
        {
            RecordingProvider provider = new RecordingProvider();
            AnalyticsManager.AddProvider(provider);

            AnalyticsManager.LogAdRevenue(null, null, null, null, -0.5d, null, null, null);

            AnalyticsEvent logged = provider.Events[0];
            Assert.That(logged.Parameters["ad_platform"], Is.EqualTo("unknown"));
            Assert.That(logged.Parameters["ad_source"], Is.EqualTo("unknown"));
            Assert.That(logged.Parameters["ad_unit_name"], Is.EqualTo(string.Empty));
            Assert.That(logged.Parameters["ad_format"], Is.EqualTo(string.Empty));
            Assert.That(logged.Parameters["value"], Is.EqualTo(0d));
            Assert.That(logged.Parameters["currency"], Is.EqualTo("USD"));
            Assert.That(logged.Parameters["placement"], Is.EqualTo(string.Empty));
            Assert.That(logged.Parameters["ad_country_code"], Is.EqualTo(string.Empty));
        }

        private static string[] Names(RecordingProvider provider)
        {
            return provider.Events.ConvertAll(e => e.Name).ToArray();
        }
    }
}
