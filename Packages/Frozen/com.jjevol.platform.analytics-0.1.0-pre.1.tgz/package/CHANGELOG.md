# Changelog

## 0.1.0-pre.1 - 2026-11-08

Initial package, redesigned from the mobile library's `Assets/Common/Analytics` by the user's decision in `Docs/PlatformAdsAnalytics/Design.md`. Original class names and GUIDs are not kept, so moving an existing game needs code changes.

| Original | Here |
| --- | --- |
| `AnalyticsEventRouter` | `AnalyticsManager` |
| `IAnalyticsEventSink` | `IAnalyticsProvider`, with `Log` and `SetCollectionEnabled` |
| `AnalyticsEventKind` | `AnalyticsStandardEvent`, without game concepts. Quest and character milestones become `AchievementUnlocked`, and virtual currency purchases become `VirtualCurrencySpent`. |
| `AnalyticsEventTarget` | The `filter` of `AddProvider` |
| `AnalyticsEventType` | Removed. Nothing read it. |
| `GameAnalytics.LogPurchase`, `LogAdRevenuePaid` | `LogPurchase`, `LogAdRevenue`, with the same value clean-up |

`GameAnalytics` game event functions stay in the project. Added: a failing provider or filter no longer stops the others, collection can be turned off across all providers, and each Play resets the manager also with Domain Reload turned off.

Unity Host results are in `Docs/PlatformAdsAnalytics/AnalyticsReport.md`.
