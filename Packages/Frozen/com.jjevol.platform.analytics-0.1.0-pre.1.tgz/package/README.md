# JJEvol Platform Analytics

Local validation candidate 0.1.0-pre.1. The game calls `AnalyticsManager`. It never touches an SDK and never knows which providers exist.

The code is user-authored, confirmed by the user on 2026-11-08. No SDK, key, App ID, company content or product value is included.

This package does nothing by itself. The project installs provider packages and adds them in its start code. With no provider, every call does nothing and logs nothing, so a game can ship without analytics.

| Package | Install |
| --- | --- |
| `com.jjevol.platform.analytics.firebase` | `FirebaseAnalyticsProvider` |
| `com.jjevol.platform.analytics.appsflyer` | `AppsFlyerAnalyticsProvider` |

Everything is in the `PlatformLibrary.Analytics` namespace. Each provider has its own: `PlatformLibrary.Analytics.Firebase` and `PlatformLibrary.Analytics.AppsFlyer`. The original `Assets/Common/Analytics` declares `jjevol.AnalyticsEvent`, so a file that imports both namespaces has to pick one.

## Start code

The project decides everything here. This package has no default provider, no selection define and no store branch.

```csharp
AnalyticsManager.Clear();
AnalyticsManager.AddProvider(new FirebaseAnalyticsProvider());
AnalyticsManager.AddProvider(new AppsFlyerAnalyticsProvider(appsFlyerSettings));
```

`AddProvider` ignores null and an instance that is already added. `Clear` removes the providers and keeps the collection state, so a player's consent choice survives. Each Play starts with no providers and collection on, also with Domain Reload turned off, so the start code does not need `Clear` and sets a saved consent choice again.

## Game code

```csharp
AnalyticsManager.Log("use_ticket", ("season_id", 3));
AnalyticsManager.Log("stage_clear", AnalyticsStandardEvent.LevelAchieved, ("stage", 10));
AnalyticsManager.Log(new AnalyticsEvent("lv_5", AnalyticsStandardEvent.LevelAchieved, parametersDictionary));

AnalyticsManager.LogPurchase("buy_product_7", orderId, 4.99, "USD", ("product_id", 7), ("quantity", 1));
AnalyticsManager.LogAdRevenue("admob", "network", adUnitId, "rewarded", 0.01, "USD", "revive", "KR");

AnalyticsManager.SetCollectionEnabled(false);
```

The event name is yours. `AnalyticsStandardEvent` says what the event means, and each provider turns that into its own standard event. Game concepts do not belong in that enum: keep game event functions such as `LogStageClear` in the project, and have them call `AnalyticsManager`.

| `AnalyticsStandardEvent` | Meaning |
| --- | --- |
| `None` | A plain event. This is the default. |
| `TutorialComplete` | A tutorial finished |
| `LevelAchieved` | A level was finished or gained |
| `AchievementUnlocked` | An achievement or milestone was reached |
| `VirtualCurrencySpent` | In-game currency was spent |
| `Purchase` | A real-money purchase. Use `LogPurchase`. |
| `AdReward` | A rewarded ad finished |
| `AdRevenue` | An ad paid. Use `LogAdRevenue`. |

`LogPurchase` and `LogAdRevenue` turn a negative revenue into 0 and an empty currency into USD. `LogAdRevenue` also turns an empty platform into `unknown`, an empty source into the platform, and names the event `ad_revenue_paid`. Your parameters cannot replace the purchase's `transaction_id`, `value` and `currency`.

Purchases and ad revenue here are analytics data, never a reason to grant anything. See the trust boundary in the `com.jjevol.platform.core` README.

## Choosing where events go

`filter` decides what a provider receives. It runs once per provider per event, sees the name, standard event and parameters, and null means everything.

```csharp
// Android builds where Firebase collects store purchases by itself.
AnalyticsManager.AddProvider(new FirebaseAnalyticsProvider(), e => e.StandardEvent != AnalyticsStandardEvent.Purchase);

// Events that one provider should not see.
AnalyticsManager.AddProvider(new AppsFlyerAnalyticsProvider(settings), e => !e.Name.StartsWith("debug_"));
```

## Collection

`SetCollectionEnabled` reaches every provider, including ones added later, and `AddProvider` passes the current state to the new provider. It starts as on. Call it with false before `AddProvider` when consent comes first: a provider that starts its SDK there then does not start it.

## Failures

Nothing here throws into the game. An exception from a provider or a filter logs one warning naming the provider and event, and the other providers still run. An empty name or a null event does nothing.

## Writing a provider

Implement `IAnalyticsProvider`. `Log` sends one event in the SDK's format, `IsEnabled` false makes the manager skip it, and `SetCollectionEnabled` is called once by `AddProvider`. Keep event routing out of a provider: that belongs in `filter`.

No license grant for third-party dependencies is made here. Enable this package in the validation Host manifest testables list to run its Editor tests. Installation in a consumer project is a separate task.
