using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using jjevol.Effect.Behaviours;

namespace jjevol.Effect
{
    /// <summary>
    /// 이펙트 비행 하나의 자리와 알림. 연출 값(시간·곡선·크기)은 프리팹의 <see cref="EffectFlightProfile"/>이 정본이고,
    /// 프리팹에 없을 때만 <see cref="legs"/>를 쓴다(둘 다 없으면 0.5초 직선).
    /// </summary>
    public sealed class EffectFlightRoute
    {
        /// <summary>출발 자리. 비우면 요청(<see cref="EffectRequest.localPosition"/>)이 놓은 자리에서 떠난다.</summary>
        public EffectPoint from;

        /// <summary>마지막 구간 앞 구간들의 도착 자리(퍼질 자리 등). 구간보다 적으면 남은 구간은 앞 자리에 머문다.</summary>
        public EffectPoint[] via = Array.Empty<EffectPoint>();

        /// <summary>마지막 도착 자리.</summary>
        public EffectPoint to;

        /// <summary>프리팹에 <see cref="EffectFlightProfile"/>이 없을 때 쓰는 구간. 프리팹 값이 있으면 무시한다.</summary>
        public IReadOnlyList<EffectFlightLeg> legs;

        /// <summary>true(기본)면 도착하는 순간 요청을 <see cref="EffectEndReason.Completed"/>로 끝내고 풀로 돌린다.</summary>
        public bool endOnArrive = true;

        /// <summary>도착 순간 한 번(이펙트가 놓인 곳의 월드 자리). 요청이 끝나기 전에 부른다. 도착 전에 끝나면 부르지 않는다.</summary>
        public Action<Vector3> onArrived;

        /// <summary>
        /// 요청이 어떤 이유로든 끝날 때 정확히 한 번(도착했으면 true). 재생을 시작하지 못한 경우(Play가 null)에도 false로 부른다.
        /// 게이지 같은 값이 멈춰 있지 않게 하려면 여기서 셈한다.
        /// </summary>
        public Action<bool> onEnded;

        public EffectFlightRoute() { }

        public EffectFlightRoute(EffectPoint from, EffectPoint to, Action<Vector3> onArrived = null, Action<bool> onEnded = null)
        {
            this.from = from;
            this.to = to;
            this.onArrived = onArrived;
            this.onEnded = onEnded;
        }
    }

    /// <summary>
    /// 이펙트를 내보내 어디로 날려 보내고, 도착하면 알리고 사라지게 한다(2026-11-20 사용자 원문
    /// 「이펙트는 연출용도로 나오는거 거기서 추가적으로 어디로 이동해서 없어질때 이벤트 받아서 처리하는정도」).
    /// 도착 이벤트를 받아 UI 갱신·실제 값 증가를 하는 것은 게임이다.
    /// </summary>
    public static class EffectFlight
    {
        /// <summary>
        /// 이펙트 하나를 재생하고 <paramref name="route"/>대로 날린다. 재생하지 못하면 null을 돌려주고 <see cref="EffectFlightRoute.onEnded"/>(false)를 부른다.
        /// 비루프 이펙트는 Renderer가 먼저 끝나면 도착 전에 끝난다(onEnded(false)). 날아가는 이펙트는 보통 <c>loop: true</c>로 요청한다.
        /// </summary>
        public static EffectHandle PlayFlight(this IEffectPlayer player, EffectRequest request, EffectFlightRoute route)
            => Launch(player, request, route, null);

        /// <summary>
        /// 같은 이펙트를 <paramref name="count"/>개 <paramref name="interval"/>초 간격으로 날린다(요청의 unscaledTime을 따른다).
        /// 끝나면(모두 도착했거나 끝났으면) 도착한 개수를 돌려준다. 취소되면 아직 내보내지 않은 것은 내보내지 않고 도착하지 않은 것으로 센다.
        /// </summary>
        /// <param name="routeFor">i번째 비행의 자리. 매번 새 경로를 돌려준다(연속 발사마다 퍼질 자리를 바꾸는 등).</param>
        public static async UniTask<int> PlayFlightBurst(this IEffectPlayer player, EffectRequest request, int count, float interval,
            Func<int, EffectFlightRoute> routeFor, CancellationToken token = default)
        {
            if (player == null) throw new ArgumentNullException(nameof(player));
            if (routeFor == null) throw new ArgumentNullException(nameof(routeFor));
            if (count <= 0) return 0;

            int ended = 0, arrived = 0;
            var all = new UniTaskCompletionSource();
            void OnOneEnded(bool ok)
            {
                ended++;
                if (ok) arrived++;
                if (ended == count) all.TrySetResult();
            }

            for (int i = 0; i < count; i++)
            {
                if (token.IsCancellationRequested)
                {
                    for (int skipped = i; skipped < count; skipped++) OnOneEnded(false);
                    break;
                }

                Launch(player, request, routeFor(i) ?? throw new InvalidOperationException("routeFor returned null."), OnOneEnded);

                if (i < count - 1 && interval > 0f)
                    await UniTask.Delay(TimeSpan.FromSeconds(interval), ignoreTimeScale: request.unscaledTime, cancellationToken: token).SuppressCancellationThrow();
            }

            await all.Task;
            return arrived;
        }

        static EffectHandle Launch(IEffectPlayer player, EffectRequest request, EffectFlightRoute route, Action<bool> extraEnded)
        {
            if (player == null) throw new ArgumentNullException(nameof(player));
            if (route == null) throw new ArgumentNullException(nameof(route));

            var state = new EffectFlightState(route, extraEnded);
            var userEnded = request.onEnded;
            request.onEnded = reason =>
            {
                try { userEnded?.Invoke(reason); }
                finally { state.End(); }
            };

            var handle = player.Play(request);
            // 재생을 거부했거나 같은 호출 안에서 이미 끝났으면(Handle은 풀로 돌아갔다) 붙이지 않는다.
            if (handle == null || state.Ended)
            {
                state.End();
                return null;
            }

            handle.AddBehaviour<EffectFlightBehaviour>().Configure(route, state);
            return handle;
        }
    }

    /// <summary>비행 하나의 도착·종료 알림을 한 번씩만 보낸다.</summary>
    internal sealed class EffectFlightState
    {
        readonly EffectFlightRoute _route;
        readonly Action<bool> _extraEnded;

        public bool Arrived { get; private set; }
        public bool Ended { get; private set; }

        public EffectFlightState(EffectFlightRoute route, Action<bool> extraEnded)
        {
            _route = route;
            _extraEnded = extraEnded;
        }

        public void Arrive(Vector3 position)
        {
            if (Arrived || Ended) return;
            Arrived = true;
            try { _route.onArrived?.Invoke(position); }
            catch (Exception exception) { Debug.LogException(exception); }
        }

        public void End()
        {
            if (Ended) return;
            Ended = true;
            try { _route.onEnded?.Invoke(Arrived); }
            catch (Exception exception) { Debug.LogException(exception); }
            finally { _extraEnded?.Invoke(Arrived); }
        }
    }
}
