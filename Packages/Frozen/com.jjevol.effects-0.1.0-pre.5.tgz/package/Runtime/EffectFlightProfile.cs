using System;
using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>비행 구간 종류.</summary>
    public enum EffectFlightLegKind
    {
        /// <summary>앞 자리에서 이 구간의 도착 자리(경유 또는 마지막 도착)로 이동한다.</summary>
        Move = 0,

        /// <summary>
        /// 출발 자리에서 튀어 올랐다가 몇 번 통통 튀며 옆에 내려앉는다(코인이 튕겨 나오듯). 도착 자리를 쓰지 않고,
        /// 내려앉은 자리가 다음 구간의 출발 자리다. UI 판 아래에서는 판 단위(px), 월드에서는 월드 단위다.
        /// </summary>
        Bounce = 1,
    }

    /// <summary>
    /// 비행 구간 하나의 연출 값. 이동 시간·곡선·휘는 정도·끝 크기·끝난 뒤 멈춤, 튕김 구간이면 튕김 힘·횟수.
    /// </summary>
    [Serializable]
    public sealed class EffectFlightLeg
    {
        [Tooltip("Move: 앞 자리에서 이 구간의 도착 자리로 이동한다. Bounce: 출발 자리에서 튕겨 나와 몇 번 튀며 내려앉는다(도착 자리를 쓰지 않는다).")]
        public EffectFlightLegKind kind = EffectFlightLegKind.Move;

        [Tooltip("이 구간 초(Bounce면 모든 튐을 합친 시간). 0이면 바로 끝난다.")]
        [Min(0f)] public float duration = 0.5f;

        [Tooltip("시간 0~1 → 진행 0~1. 비우면 일정한 속도다. Bounce에서는 크기 변화에만 쓴다.")]
        public AnimationCurve ease;

        [Tooltip("Move: 곡선이 옆으로 휘는 정도(구간 길이에 대한 비율). 0이면 직선, 음수면 반대쪽.")]
        public float arc;

        [Tooltip("Move: 켜면 휘는 방향을 이펙트마다 무작위로 고른다(연속 발사가 겹치지 않게).")]
        public bool randomArcSide;

        [Tooltip("구간 끝 크기 배율(요청 크기에 곱한다).")]
        public float scale = 1f;

        [Tooltip("구간이 끝난 뒤 멈추는 초. 마지막 구간에서는 쓰지 않는다(도착이 먼저다).")]
        [Min(0f)] public float holdAfter;

        [Tooltip("Bounce: 첫 튐의 가로 거리(x)와 높이(y). UI 판 아래에서는 판 단위(px), 월드에서는 월드 단위. x 음수면 왼쪽.")]
        public Vector2 bounceForce = new Vector2(80f, 120f);

        [Tooltip("Bounce: 튀는 횟수(1 이상).")]
        [Min(1)] public int bounceCount = 2;

        [Tooltip("Bounce: 다음 튐의 거리·높이 배율(0~1). 0.5면 튈 때마다 반으로 준다.")]
        [Range(0f, 1f)] public float bounceDamping = 0.5f;

        [Tooltip("Bounce: 켜면 가로 방향(왼쪽·오른쪽)을 이펙트마다 무작위로 고른다.")]
        public bool randomBounceSide = true;

        [Tooltip("Bounce: 힘 무작위 폭(0~1). 0.3이면 가로·세로 힘에 각각 0.7~1.3배를 곱한다(여러 개가 겹치지 않게).")]
        [Range(0f, 1f)] public float bounceJitter = 0.3f;

        public EffectFlightLeg() { }

        public EffectFlightLeg(float duration, AnimationCurve ease = null, float arc = 0f, float scale = 1f, float holdAfter = 0f)
        {
            this.duration = Mathf.Max(0f, duration);
            this.ease = ease;
            this.arc = arc;
            this.scale = scale;
            this.holdAfter = Mathf.Max(0f, holdAfter);
        }

        /// <summary>튕김 구간을 만든다. 코드에서 만들 때는 무작위를 끈 값이 기본이다(결과가 정해지게).</summary>
        public static EffectFlightLeg Bounce(float duration, Vector2 force, int count = 2, float damping = 0.5f,
            bool randomSide = false, float jitter = 0f, float scale = 1f, float holdAfter = 0f)
            => new EffectFlightLeg(duration, scale: scale, holdAfter: holdAfter)
            {
                kind = EffectFlightLegKind.Bounce,
                bounceForce = force,
                bounceCount = Mathf.Max(1, count),
                bounceDamping = Mathf.Clamp01(damping),
                randomBounceSide = randomSide,
                bounceJitter = Mathf.Clamp01(jitter),
            };
    }

    /// <summary>
    /// 이펙트 프리팹에 붙이는 비행 연출 값(정본). 자리(출발·경유·도착)는 코드가
    /// <see cref="EffectFlightRoute"/>로 넘기고, 시간·곡선·크기·튕김은 디자이너가 여기서 고친다.
    /// 구간 i의 도착 자리는 마지막 구간이면 <see cref="EffectFlightRoute.to"/>, 아니면 <see cref="EffectFlightRoute.via"/>[i]다(없으면 그 자리에 머문다).
    /// 튕김(<see cref="EffectFlightLegKind.Bounce"/>) 구간은 도착 자리를 쓰지 않고 내려앉은 자리에서 다음 구간을 시작한다.
    /// 예: [Bounce(멈춤 0.2초), Move] = 튕겨 나옴 → 멈춤 → 대상(to)으로 비행 → 도착 이벤트.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class EffectFlightProfile : MonoBehaviour
    {
        [Tooltip("출발 때 크기 배율(요청 크기에 곱한다).")]
        public float startScale = 1f;

        [Tooltip("구간 목록. 비우면 0.5초 직선 한 구간이다. 예: Bounce(멈춤 0.2) → Move = 튕겨 나와 멈췄다가 대상으로 날아간다.")]
        public List<EffectFlightLeg> legs = new() { new EffectFlightLeg() };

        [Tooltip("UI 판 아래에서 날 때 이펙트 레이어를 그 판의 레이어로 맞춘다(UI 카메라가 그리게). 끝나면 되돌린다.")]
        public bool matchUILayer = true;
    }
}
