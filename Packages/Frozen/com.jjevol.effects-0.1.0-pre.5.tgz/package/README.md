# JJEvol Effects

Overall transfer status: PARTIAL. STEP 6 basic Core validation passed in Unity 6000.3.9f1 Editor: 31 standalone tests, including independent AnimatorController, movement/UI behaviours, pause and scene lifetime. The later lifecycle and module restructure, EffectsLifecycleTests, EffectsEndReasonTests and EffectsModuleTests were compiled statically and have NOT been run in Unity. Optional Vendor/UI integrations, original game content and Player/device validation remain incomplete. Beta frozen archives exist (latest `Snapshots/20261112-uitoolkit-beta`; see Docs/Guide/Delivery.md).

Install this package and explicitly select UniTask in the consuming project manifest:

~~~json
"com.cysharp.unitask": "https://github.com/Cysharp/UniTask.git?path=src/UniTask/Assets/Plugins/UniTask#2e993ff18f28c931602a07292df0b0804eebef99"
~~~

The package declares UniTask 2.5.11; the Host pins its actual Git source. SDK sources are not bundled. Unity baseline is 6000.3.9f1.

Namespace remains jjevol.Effect. Play(string,Vector3,Transform), Play(EffectRequest), UniTask<EffectHandle> PlayAsync, UniTask PreloadAsync, PlayRouletteEffect, Despawn and profile configuration retain call shapes. Position is local, as in the original implementation.

~~~csharp
var effects = EffectManager.Instance;
// Optional: before any loads, when com.jjevol.effects.addressables is installed:
effects.SetPrefabProvider(new AddressablesEffectPrefabProvider());
await effects.PreloadAsync("MyEffect");
var handle = await effects.PlayAsync(new EffectRequest("MyEffect", loop: true, parent: effectRoot));
effects.Despawn(handle);
~~~

Without explicit provider configuration, Core uses Resources.Load<GameObject>(key). This changes the original implicit Common AddressablesManager initialization; Addressables-only keys require the optional provider above. No game Host is migrated automatically.

Core no longer depends on PersistentSingleton, Coffee, Spine or DOTween types. A small owned singleton retains Instance/HasInstance/IsDestroyed/applicationIsQuitting and scene persistence. Configure a provider before loading. Prefab loads are shared per key; one prefab lease remains while any active/idle instance exists. Idle cull or manager destruction destroys instances before deferred lease return. Preload pins until pool cull or manager destruction. Disable despawns owned active instances; individual Despawn invalidates late binding. Public async APIs retain their original absence of a caller CancellationToken parameter. Underlying loads are not claimed to be forcibly aborted.

Completion callbacks and idle cull use request identities. Manager tracks handles even when parented outside its hierarchy. maxPool remains the original declared field; the original pool did not enforce a capacity cap, and this candidate does not invent one.

Integrations~ contains unchanged user-authored DOTween/Spine/Toast/icon/Coffee-scale sources with original script metas. Unity excludes this folder. These are NOT installable/validated adapters: the Vendor assemblies, renderer registration and/or Common AddressableImage/AddressableTexture connection are still required. No Vendor binary/source or product effect prefab is included.

## Lifecycle

EffectHandle holds one lifetime state: Idle (pooled) -> Loading -> Playing -> Idle. Stop moves a live request to Finished, where it waits for Despawn. Pause and the inactive-hierarchy wait are separate flags. Play and PlayAsync run the same pipeline (prefab, bind, play); Play is a thin caller that logs what PlayAsync would throw.

Every end passes one exit with one EffectEndReason. EffectRequest.onEnded runs exactly once and receives that reason; callBack runs exactly once unless the handle itself was destroyed:

| End | Reason | callBack | OnComplete | onEnded | Notes |
|---|---|---|---|---|---|
| Natural completion | Completed | once | once | once | |
| Non-loop under a deactivated parent, parent destroyed, or the handle passed to Object.Destroy | Interrupted | once | no | once | Runs in EffectManager.LateUpdate, never inside the disable callback |
| Despawn, manager disable | Despawned | once | no | once | Duplicate Despawn is ignored |
| Manager destroy | Despawned | once | no | once | Unity calls OnDisable first, which despawns active and loading handles |
| Prefab not found | Failed | once | no | once | Play returns the recovered handle, PlayAsync returns null, Core logs a warning |
| Provider exception, missing adapter, renderer or behaviour exception | Failed | once | no | once | Play logs the exception, PlayAsync faults |
| Behaviour exception during playback (Tick, IsFinished, End) | Failed | once | no | once | Logged. A Tick that already ended its own request leaves the next request alone |
| Canceled load | Failed | once | no | once | Play stays silent, PlayAsync is canceled |
| Loop or stopped handle passed to Object.Destroy, or any handle passed to DestroyImmediate | Destroyed | no | no | once | callBack keeps its original behaviour |

A loop or stopped handle has no Interrupted path. If it dies with its parent, it ends as Destroyed. A live non-loop handle reaches the deferred settle before Object.Destroy finishes, measured in PlayMode.

callBack, OnComplete and onEnded run in that order, before the handle returns to the pool, so OnComplete never receives a handle that already runs a newer request. A Play inside a notification takes another handle. An exception from any of them is logged instead of reaching the caller or the next one, so one callback cannot stop other handles from ending. An OnComplete subscription lasts for one request: every new request clears it, including one added after the handle already ended.

Inactive parents: a non-loop effect ends as Interrupted when its parent is deactivated, even if the parent comes back in the same frame, because the renderer's waiter stopped with it. A loop stays Playing until its owner calls Despawn; when the hierarchy is active again the renderer restarts, finished built-in behaviours begin again and a pause is reapplied. Renderers whose own OnDisable clears data lose it: re-apply Toast data after reactivation. A Play under an inactive parent follows the same rule and does not start the renderer, and a first bind there still registers the prefab's built-in behaviours. Despawn from a parent's OnDisable is safe; the pool reparent waits for LateUpdate, including a panel disabled by another handle's callback.

Stop halts playback without returning the handle. The owner must still call Despawn, and Stop alone does not call back. A stopped handle is not ended by a parent deactivation.

## Structure

EffectManager is a thin MonoBehaviour and the only effect manager. It holds the serialized fields and pool profiles, receives Unity callbacks, forwards the public API and drives its spawners. The built-in GameObject spawner composes the modules below; a spawner for another render kind (VisualElement, `com.jjevol.effects.uitoolkit`) is added with `AddSpawner` and receives the same calls: Update and LateUpdate every frame, DespawnAll when the manager is disabled, Resume when it is enabled and Shutdown when it is destroyed. `IEffectInstance` is what every playing effect offers; `EffectHandle` implements it and `Play` still returns `EffectHandle`. It implements IEffectPlayer, so code that only plays effects can depend on that interface. Modules are internal and receive their collaborators by constructor; the package has no dependency injection container.

| Module | Responsibility |
|---|---|
| EffectHandle | One lifetime state and the single exit. Knows its owner only through IEffectHandleHost, set once by Initialize |
| EffectPool | One per effect type: idle and active handles, idle cull, pool return and final prefab release. Hosts the handles it creates |
| EffectPlaybackPipeline | The flow shared by Play and PlayAsync: prefab, bind, start |
| EffectInstanceBinder | Instantiate, renderer selection, built-in behaviour collection, parenting into the handle |
| EffectSettleQueue | Handles waiting to leave a disable callback. Drained once per LateUpdate |
| EffectPrefabCache | Prefab state per key, see below |

## Prefab state

EffectPrefabCache keeps one record per key: Loading, Ready or Failed. Concurrent requests share one load. A null result or exception marks the record Failed and the next request loads again, including a Ready record whose prefab was destroyed. SetPrefabProvider also rejects a load still in progress; a key that only failed does not block it.

## Renderer selection and state

Selection order on the prefab root: an existing IEffectRenderer, Animator, registered adapter factories, then rejection of an unregistered Vendor root component. After that, a ParticleSystem anywhere under the root selects ParticleEffectRenderer, a root SpriteRenderer selects SpriteEffectRenderer, and otherwise the Sprite fallback is added with a warning. ParticleEffectRenderer drives the root system, or every active child system when the root only groups them, and waits for the longest one.

Prefab impact: a prefab with child-only particles used to fall through to the Sprite renderer and return at once; it now plays and waits. This includes a root SpriteRenderer with child particles, and a root with no renderer whose only particle child is inactive stays on the particle path and completes immediately. Sibling child systems are now started, stopped and given the request's loop and sorting. A ParticleEffectRenderer with no system completes at once instead of holding its handle.

F5 compatibility impact: on a prefab with a root SpriteRenderer and child particles, the request's Sorting now reaches only the particles (and a root SortingGroup, if any). The root sprite keeps its prefab sorting, where the Sprite path used to apply the request to it. Such a prefab needs a SortingGroup on its root, or matching authored sorting, to keep the sprite and particles together.

A prefab instance that destroys itself is not reused: a pooled handle whose Unity renderer is gone binds a new instance on its next request.

IEffectRendererStateRestore is optional. CaptureState runs once after binding, RestoreState after every request. EffectSortingSnapshot stores Renderer, SortingGroup and Canvas sorting for implementers; Animator, Particle, Sprite, DOTween and Spine renderers use it, so an empty request layer means the prefab value, not the previous request. Renderers without the interface still receive SetPaused(false) before StopAndClear when a paused request ends.

FollowTargetBehaviour waits while Target is unset, so a code-added module works when Target is assigned after AddBehaviour, even in a later frame. It ends when an assigned Target is lost. A Target and Offset stored on the prefab survive pool reuse; ones set from code do not.

## Optional renderers and limits

EffectRendererAdapters.Factories is an explicit optional renderer selection hook, after an existing IEffectRenderer/Animator and before basic Particle/Sprite fallback. Recognized Vendor root components without an adapter fail explicitly. Missing scripts or unsupported child-only Vendor compositions require asset validation; they are not verified by Core tests.

Pause suspends renderer completion time and behaviour ticks, including requests paused before binding. Both Play entry points reject disabled managers. Disabling the manager retains idle cache; re-enabling starts fresh idle intervals. Scene-destroyed handles retire their pool ownership before the final prefab lease is returned. Preload without instances has no idle expiration and remains until manager destruction or later final pool cull.

Basic Animator State/Trigger, movement/UI behaviours and Pause/Resume were exercised with independent assets. Full animation/curve combinations, original content compatibility, visual quality and legacy prefab migration remain NOT_VERIFIED. Existing no-op interface members such as Sprite skin are original behavior, not substitutes for missing Vendor functionality.

Original script GUIDs are preserved. Do not install alongside legacy classes/GUIDs. Validation scope is in the Framework Docs/Guide/Verification.md; original extraction provenance is in Docs/EffectExtraction/SourceInventory.json.

## Flight and arrival event

An effect is presentation: it plays, optionally flies somewhere, and tells the game when it arrives. Updating the HUD or adding the real value (coins, gauge) on that event is the game's job (central request `9ee9a8f1901c`, FW-FX-ARRIVE).

~~~csharp
var route = new EffectFlightRoute(
    from: EffectPoint.Follow(enemy.transform),          // where it leaves
    to: EffectPoint.Anchor(coinIcon),                    // HUD element on any Canvas
    onArrived: position => hud.PunchCoinIcon(),          // once, on arrival, before the request ends
    onEnded: arrived => wallet.Add(1));                  // exactly once for every end, arrived or cut short
effects.PlayFlight(new EffectRequest("CoinFly", loop: true, parent: uiEffectRoot), route);
~~~

- **Request a loop effect.** A non-loop renderer that finishes first ends the request before arrival (`onEnded(false)`). Flight ends the loop itself on arrival (`endOnArrive`, default true, ends as `Completed`).
- **Points** (`EffectPoint`) are read every frame, so moving targets and cameras are followed. A point that disappears keeps its last position.
  - `World(position)` fixed world point; `Follow(transform, offset)` moving world target.
  - `Anchor(rectTransform, offset)` centre of a uGUI element on any Canvas; `Screen(px)` fixed screen point; `FromScreen(source)` asks the game every frame.
  - The effect space is chosen by the request parent: a RectTransform under a Canvas makes a UI flight, anything else a world flight. World points are projected into UI flights and screen/UI points are unprojected into world flights with the world camera (`Camera.main` unless given).
  - Leaving `from` empty starts where the request placed the effect.
- **Timing lives on the prefab.** Add `EffectFlightProfile` to the effect prefab and edit it in the Inspector: `startScale`, `legs` and `matchUILayer` (under a UI plane the effect takes the plane's layer during the flight and gets its layers back at the end). `EffectFlightRoute.legs` is used only when the prefab has no profile; without both, one 0.5 s straight leg is used.
- **Legs.** Leg *i* ends at `route.via[i]`, the last leg at `route.to`. Each leg has `duration`, `ease`, `scale` (end scale) and `holdAfter` (pause after the leg, ignored on the last leg).
  - `Move` legs fly to their point; `arc` bends the path sideways (fraction of the leg length) and `randomArcSide` picks the bend side per effect.
  - `Bounce` legs ("coin pops out") ignore their point: the effect hops up from where the leg starts and bounces a few times before landing beside it. `bounceForce` is the first hop (x = sideways distance, y = height), `bounceCount` the number of hops, `bounceDamping` the factor for each next hop (time scales by its square root), `randomBounceSide` flips left/right per effect and `bounceJitter` varies the force. Units are plane units (px) under a UI plane and world units in the world (up = world up, sideways = camera right). The start and the landing are fixed to the effect parent, so a bounce does not follow the object it left. The landing is where the next leg starts; a final bounce arrives where it lands.
  - Prefab-only "pop out, pause, fly to target, arrival event": `legs = [Bounce (holdAfter 0.2), Move]` with `route.from` and `route.to`. Code can build the same with `EffectFlightLeg.Bounce(...)`.
- **Events.** `onArrived(position)` runs once on arrival, before the request ends. `onEnded(arrived)` then runs exactly once for every end: after arrival with `true`, on Despawn, interruption or a rejected `Play` (which returns null) with `false`. Count values in `onEnded` so a gauge never stalls when an effect is cut short. Exceptions in either are logged.
- **Bursts.** `PlayFlightBurst(request, count, interval, i => route, token)` launches `count` flights `interval` seconds apart (scaled or unscaled like the request), asks for a fresh route per index (spread points, random offsets) and returns how many arrived. Cancelling stops further launches; those count as not arrived.

Not covered: UI Toolkit flights (`com.jjevol.effects.uitoolkit`) and scaling a world effect to match a UI target. The older `MoveToTargetBehaviour`, `MoveCurveBehaviour`, `JumpPopBehaviour` and `UIJumpPopBehaviour` are unchanged.

## Menus

Framework menus are grouped by feature: Editor tools under `JJEvol/<feature>/`, asset menus under `Assets/Create/JJEvol/<feature>/`, and UI objects under `GameObject/UI/JJEvol/`.

- `Assets/Create/JJEvol/Effects/Pool Profiles` — `PoolProfileAsset`
