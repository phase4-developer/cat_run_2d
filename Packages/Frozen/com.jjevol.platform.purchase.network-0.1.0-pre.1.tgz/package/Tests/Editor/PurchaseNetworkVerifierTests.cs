using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using PlatformLibrary.Network;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Purchase.Network.Tests
{
    /// <summary>A verification request as a project would write it: one API, the receipt fields as parameters.</summary>
    internal sealed class VerifyRequest : NetworkRequest
    {
        private readonly bool _requiresSession;

        public VerifyRequest(PurchaseOrder order, bool requiresSession = false)
        {
            _requiresSession = requiresSession;
            Add("productId", order.ProductId);
            Add("transactionId", order.TransactionId);
            Add("verificationData", order.VerificationData);
            DataKeys = new[] { "wallet" };
            UseDefaultFailureHandling = false;
        }

        public override string Name => "verifyPurchase";
        public override bool RequiresSession => _requiresSession;
    }

    /// <summary>A server that answers every request with the scripted result.</summary>
    internal sealed class ScriptedServer : INetworkProvider
    {
        public NetworkResult Next = NetworkResult.Succeeded(new JObject());
        public readonly List<NetworkCall> Calls = new List<NetworkCall>();

        public bool IsReady(string environmentKey) => true;

        public Task<NetworkResult> SendAsync(NetworkCall call, CancellationToken cancellationToken)
        {
            Calls.Add(call);
            return Task.FromResult(Next);
        }
    }

    public sealed class PurchaseNetworkVerifierTests
    {
        private SynchronizationContext _context;
        private ScriptedServer _server;
        private PurchaseNetworkVerifier _verifier;
        private PurchaseOrder _order;

        private static readonly PurchaseServerErrors Errors = new PurchaseServerErrors()
            .AlreadyGranted("ReceiptAlreadyProcessed", "ReceiptAlreadyUsed", "DuplicatePurchaseRequest")
            .Rejected("InvalidReceipt");

        [SetUp]
        public void SetUp()
        {
            // Completed tasks continue inline, so each verification answers before Verify returns.
            _context = SynchronizationContext.Current;
            SynchronizationContext.SetSynchronizationContext(null);
            NetworkManager.ClearAll();
            _server = new ScriptedServer();
            NetworkManager.SetServerProvider(_server);
            _verifier = new PurchaseNetworkVerifier(order => new VerifyRequest(order), Errors);
            var product = new PurchaseProduct(new PurchaseProductDefinition("gems_100", "store.gems_100", PurchaseProductType.Consumable), true, "1,200 KRW", 1200m, "KRW", "Gems");
            _order = new PurchaseOrder("order-1", product, PurchaseOrderState.Pending, "transaction-1", "receipt", "token-1");
        }

        [TearDown]
        public void TearDown()
        {
            NetworkManager.ClearAll();
            SynchronizationContext.SetSynchronizationContext(_context);
        }

        private List<PurchaseVerification> Verify(PurchaseNetworkVerifier verifier = null)
        {
            var answers = new List<PurchaseVerification>();
            (verifier ?? _verifier).Verify(_order, answers.Add);
            return answers;
        }

        private PurchaseVerification VerifyOnce(PurchaseNetworkVerifier verifier = null)
        {
            List<PurchaseVerification> answers = Verify(verifier);
            Assert.AreEqual(1, answers.Count, "The verifier answers exactly once.");
            return answers[0];
        }

        [Test]
        public void SuccessIsGrantedWithTheAppliedData()
        {
            JObject data = JObject.Parse("{\"wallet\":{\"gems\":100},\"rewards\":[{\"id\":\"gems\",\"count\":100}]}");
            _server.Next = NetworkResult.Succeeded(data);
            var order = new List<string>();
            NetworkManager.SetResponseApplier((request, result) => order.Add("apply"));

            var answers = new List<PurchaseVerification>();
            _verifier.Verify(_order, verification =>
            {
                order.Add("verified");
                answers.Add(verification);
            });

            Assert.AreEqual(1, answers.Count);
            Assert.AreEqual(PurchaseVerdict.Granted, answers[0].Verdict);
            Assert.AreEqual(100, ((JObject)answers[0].Grant)["rewards"][0]["count"].Value<int>(), "The grant is the success data.");
            CollectionAssert.AreEqual(new[] { "apply", "verified" }, order, "The repository is updated before the verdict.");
        }

        [Test]
        public void TheRequestCarriesTheOrdersReceipt()
        {
            Verify();

            Assert.AreEqual(1, _server.Calls.Count);
            NetworkCall call = _server.Calls[0];
            Assert.AreEqual("verifyPurchase", call.Request.Name);
            Assert.AreEqual("transaction-1", call.Parameters["transactionId"]);
            Assert.AreEqual("token-1", call.Parameters["verificationData"]);
            Assert.AreEqual("gems_100", call.Parameters["productId"]);
        }

        [Test]
        public void EveryAlreadyGrantedCodeClosesTheOrderAsGranted()
        {
            foreach (string code in new[] { "ReceiptAlreadyProcessed", "ReceiptAlreadyUsed", "DuplicatePurchaseRequest" })
            {
                _server.Next = NetworkResult.Failed(NetworkFailure.Rejected, code, "already", new JObject { ["code"] = code });
                PurchaseVerification verification = VerifyOnce();

                Assert.AreEqual(PurchaseVerdict.AlreadyGranted, verification.Verdict, code);
                Assert.AreEqual(code, verification.ServerErrorCode);
                Assert.IsNull(verification.Grant, "Nothing new is granted, and an error response is never passed as a reward.");
            }
        }

        [Test]
        public void ARejectedCodeClosesTheOrderWithoutAGrant()
        {
            _server.Next = NetworkResult.Failed(NetworkFailure.Rejected, "InvalidReceipt", "bad receipt");
            PurchaseVerification verification = VerifyOnce();

            Assert.AreEqual(PurchaseVerdict.Rejected, verification.Verdict);
            Assert.AreEqual("InvalidReceipt", verification.ServerErrorCode);
            Assert.IsNull(verification.Grant);
            StringAssert.Contains("bad receipt", verification.Detail);
        }

        [Test]
        public void AnUnlistedServerCodeKeepsTheOrderPending()
        {
            _server.Next = NetworkResult.Failed(NetworkFailure.Rejected, "ServerBusy");
            PurchaseVerification verification = VerifyOnce();

            Assert.AreEqual(PurchaseVerdict.Unavailable, verification.Verdict);
            Assert.AreEqual("ServerBusy", verification.ServerErrorCode, "The server's code is kept for logs.");
        }

        [Test]
        public void TransportFailuresKeepTheOrderPending()
        {
            var failures = new[]
            {
                NetworkFailure.NoConnection, NetworkFailure.Timeout, NetworkFailure.ServerError, NetworkFailure.InvalidResponse,
                NetworkFailure.Unauthorized, NetworkFailure.Maintenance, NetworkFailure.ProviderError
            };
            foreach (NetworkFailure failure in failures)
            {
                NetworkManager.ClearAll();
                NetworkManager.SetServerProvider(_server);
                _server.Next = NetworkResult.Failed(failure, detail: "scripted " + failure);
                PurchaseVerification verification = VerifyOnce();

                Assert.AreEqual(PurchaseVerdict.Unavailable, verification.Verdict, failure.ToString());
                StringAssert.Contains(failure.ToString(), verification.Detail, "The detail names the network failure.");
            }
        }

        [Test]
        public void AListedCodeIsJudgedWhateverFailureCarriedIt()
        {
            // A server that sends its code only as an error message reaches the client as a server error with that string.
            _server.Next = NetworkResult.Failed(NetworkFailure.ServerError, "InvalidReceipt", "InvalidReceipt");
            PurchaseVerification rejected = VerifyOnce();
            Assert.AreEqual(PurchaseVerdict.Rejected, rejected.Verdict);
            StringAssert.Contains("ServerError", rejected.Detail, "The detail keeps the network failure kind.");

            _server.Next = NetworkResult.Failed(NetworkFailure.ProviderError, "ReceiptAlreadyUsed");
            PurchaseVerification granted = VerifyOnce();
            Assert.AreEqual(PurchaseVerdict.AlreadyGranted, granted.Verdict);
            Assert.IsNull(granted.Grant);

            _server.Next = NetworkResult.Failed(NetworkFailure.ServerError, "internal");
            Assert.AreEqual(PurchaseVerdict.Unavailable, VerifyOnce().Verdict, "An unlisted string keeps the order pending.");
        }

        [Test]
        public void AFailedApplyKeepsTheOrderPending()
        {
            _server.Next = NetworkResult.Succeeded(JObject.Parse("{\"wallet\":{\"gems\":100}}"));
            NetworkManager.SetResponseApplier((request, result) => throw new InvalidOperationException("bad wallet"));
            LogAssert.Expect(LogType.Exception, new Regex("bad wallet"));

            PurchaseVerification verification = VerifyOnce();

            Assert.AreEqual(PurchaseVerdict.Unavailable, verification.Verdict, "The server may have granted; the next recovery closes it as already granted.");
            StringAssert.Contains("ApplyFailed", verification.Detail);
            StringAssert.Contains("bad wallet", verification.Detail);
        }

        [Test]
        public void NoSessionKeepsTheOrderPendingWithoutSending()
        {
            var verifier = new PurchaseNetworkVerifier(order => new VerifyRequest(order, requiresSession: true), Errors);
            PurchaseVerification verification = VerifyOnce(verifier);

            Assert.AreEqual(PurchaseVerdict.Unavailable, verification.Verdict);
            StringAssert.Contains("SessionNotReady", verification.Detail);
            Assert.AreEqual(0, _server.Calls.Count);
        }

        [Test]
        public void NoServerProviderKeepsTheOrderPending()
        {
            NetworkManager.ClearAll();
            PurchaseVerification verification = VerifyOnce();

            Assert.AreEqual(PurchaseVerdict.Unavailable, verification.Verdict);
            StringAssert.Contains("Unsupported", verification.Detail);
        }

        [Test]
        public void ACancelledRequestKeepsTheOrderPending()
        {
            var pending = new TaskCompletionSource<NetworkResult>();
            var waiting = new WaitingServer(pending.Task);
            NetworkManager.SetServerProvider(waiting);

            var answers = new List<PurchaseVerification>();
            _verifier.Verify(_order, answers.Add);
            Assert.AreEqual(0, answers.Count, "Still waiting for the server.");

            NetworkManager.CancelAll();
            // With no synchronization context the cancellation completes inline; the wait only guards a slower scheduler.
            Assert.IsTrue(SpinWait.SpinUntil(() => answers.Count > 0, 5000), "The cancelled request answers.");
            pending.SetResult(NetworkResult.Succeeded(new JObject()));
            Thread.Sleep(50);

            Assert.AreEqual(1, answers.Count, "A late server answer does not answer again.");
            Assert.AreEqual(PurchaseVerdict.Unavailable, answers[0].Verdict);
            StringAssert.Contains("Cancelled", answers[0].Detail);
        }

        [Test]
        public void AFailingRequestFactoryKeepsTheOrderPendingWithoutSending()
        {
            var throwing = new PurchaseNetworkVerifier(order => throw new FormatException("no receipt"), Errors);
            PurchaseVerification verification = VerifyOnce(throwing);
            Assert.AreEqual(PurchaseVerdict.Unavailable, verification.Verdict);
            StringAssert.Contains("REQUEST_NOT_CREATED", verification.Detail);
            StringAssert.Contains("no receipt", verification.Detail);

            var empty = new PurchaseNetworkVerifier(order => null, Errors);
            Assert.AreEqual(PurchaseVerdict.Unavailable, VerifyOnce(empty).Verdict);
            Assert.AreEqual(0, _server.Calls.Count);
        }

        [Test]
        public void AReusedRequestKeepsTheOrderPending()
        {
            NetworkRequest shared = null;
            var reusing = new PurchaseNetworkVerifier(order => shared ?? (shared = new VerifyRequest(order)), Errors);
            Assert.AreEqual(PurchaseVerdict.Granted, VerifyOnce(reusing).Verdict);

            PurchaseVerification second = VerifyOnce(reusing);
            Assert.AreEqual(PurchaseVerdict.Unavailable, second.Verdict, "A request instance is sent once; the second order is not lost.");
            StringAssert.Contains("REQUEST_NOT_SENT", second.Detail);
        }

        [Test]
        public void ConstructorAndVerifyRequireTheirArguments()
        {
            Assert.Throws<ArgumentNullException>(() => new PurchaseNetworkVerifier(null, Errors));
            Assert.Throws<ArgumentNullException>(() => new PurchaseNetworkVerifier(order => new VerifyRequest(order), null));
            Assert.Throws<ArgumentNullException>(() => _verifier.Verify(_order, null));
        }

        [Test]
        public void ACodeCannotBeInBothLists()
        {
            Assert.Throws<ArgumentException>(() => new PurchaseServerErrors().AlreadyGranted("Same").Rejected("Same"));
            Assert.Throws<ArgumentException>(() => new PurchaseServerErrors().Rejected("Same").AlreadyGranted("Same"));
            Assert.Throws<ArgumentException>(() => new PurchaseServerErrors().Rejected("Same").AlreadyGranted("SAME"), "Lists ignore case, so these are the same string.");
        }

        [Test]
        public void BlankCodesAndNullListsAreIgnored()
        {
            var errors = new PurchaseServerErrors().AlreadyGranted(null).AlreadyGranted("", " ").Rejected((string[])null);
            var verifier = new PurchaseNetworkVerifier(order => new VerifyRequest(order), errors);

            _server.Next = NetworkResult.Failed(NetworkFailure.Rejected, "AnyCode");
            Assert.AreEqual(PurchaseVerdict.Unavailable, VerifyOnce(verifier).Verdict);
        }

        [Test]
        public void CodesIgnoreCase()
        {
            _server.Next = NetworkResult.Failed(NetworkFailure.Rejected, "invalidreceipt");
            Assert.AreEqual(PurchaseVerdict.Rejected, VerifyOnce().Verdict);

            _server.Next = NetworkResult.Failed(NetworkFailure.Rejected, "RECEIPTALREADYUSED");
            Assert.AreEqual(PurchaseVerdict.AlreadyGranted, VerifyOnce().Verdict);
        }
    }

    internal sealed class WaitingServer : INetworkProvider
    {
        private readonly Task<NetworkResult> _answer;
        public WaitingServer(Task<NetworkResult> answer) { _answer = answer; }
        public bool IsReady(string environmentKey) => true;
        public Task<NetworkResult> SendAsync(NetworkCall call, CancellationToken cancellationToken) => _answer;
    }
}
