# JJEvol Platform Purchase Network

Connects `com.jjevol.platform.purchase` to `com.jjevol.platform.network`. `PurchaseNetworkVerifier` is an `IPurchaseVerifier` that sends the project's verification request through `NetworkManager` and turns the result into a purchase verdict. The purchase and network packages do not reference each other; this package is the only link, in the same way as `com.jjevol.platform.network.data`.

Status: local validation candidate. Android and iOS Player and a real server are NOT_RUN.

## Install

| Package | Why |
|---|---|
| `com.jjevol.platform.purchase` | The purchase manager and the verifier contract |
| `com.jjevol.platform.network` | The network manager and a provider such as `com.jjevol.platform.network.http` |
| `com.jjevol.platform.purchase.network` | This package |

Install `com.jjevol.platform.network.data` as well when the server's purchase response should go into the data repository.

## Use

The request class and the server's error strings belong to the project, because every server names them differently.

```csharp
using System;
using PlatformLibrary.Network;
using PlatformLibrary.Purchase;
using PlatformLibrary.Purchase.Network;

// One request class per server API, as for any other request.
public sealed class VerifyPurchaseRequest : GameRequest
{
    public VerifyPurchaseRequest(PurchaseOrder order)
    {
        Add("productId", order.ProductId);
        Add("transactionId", order.TransactionId);
        Add("receipt", order.VerificationData);
        DataKeys = new[] { "userWallet" };   // Keys the server's reward changes
        Timeout = TimeSpan.FromSeconds(70);  // Shorter than PurchaseManager.VerificationTimeoutSeconds (90 by default)
        UseDefaultFailureHandling = false;   // The purchase result reports the failure; see below
    }

    public override string Name => "verifyPurchase";
    public override bool RequiresSession => true;
}

// Start-up code
var errors = new PurchaseServerErrors()
    .AlreadyGranted("ReceiptAlreadyProcessed", "ReceiptAlreadyUsed", "DuplicatePurchaseRequest")
    .Rejected("InvalidReceipt");

PurchaseManager.SetVerifier(new PurchaseNetworkVerifier(order => new VerifyPurchaseRequest(order), errors));
```

`GameRequest` stands for the project's own `NetworkRequest` parent with its common parameters. The error strings above are examples; use the ones your server sends.

## How results become verdicts

| `NetworkResult` | Verdict | Purchase manager |
|---|---|---|
| Success | `Granted`. `Grant` is `NetworkResult.Data`, already applied to the repository | Closes the order, success |
| A failure with a code in the `AlreadyGranted` list | `AlreadyGranted`. Nothing new is granted, so `Grant` is `NetworkResult.Data`, which is `null` for a failure | Closes the order, success |
| A failure with a code in the `Rejected` list | `Rejected` | Closes the order, `VerificationRejected` |
| A failure whose code is in neither list | `Unavailable` | Keeps the order pending, `VerificationUnavailable` |
| `ApplyFailed` | `Unavailable`. The server may have granted; the next recovery should get an already-granted code | Keeps the order pending |
| Any other failure without a listed code (`NoConnection`, `Timeout`, `ServerError`, `InvalidResponse`, `Unauthorized`, `SessionNotReady`, `SessionInvalid`, `Maintenance`, `Cancelled`, `Unsupported`, `NotInitialized`, `ProviderError`) | `Unavailable` | Keeps the order pending |

A listed code is judged whatever failure kind carried it. A server may send its code as a game error or only as an error message; the Firebase provider then reports a server error with that message as the code, and the order still closes. Codes are matched ignoring case. A code cannot be in both lists.

`ServerErrorCode` on the verdict is the network result's code. `Detail` holds the network failure name, its message and its detail, for logs.

If the request factory throws or returns `null`, or `NetworkManager.Post` refuses the request (for example the same instance sent twice), the verdict is `Unavailable` and nothing is sent. Return a new request for every call.

## Settings to decide in the project

- Automatic retry (`NetworkRequest.Retry`) stays off unless the server deduplicates by transaction ID.
- Keep the request's `Timeout` shorter than `PurchaseManager.VerificationTimeoutSeconds` (90 by default; the project can change it). A late answer is ignored by the manager; the order stays pending and closes as already granted on the next recovery.
- A failure reaches the game through the purchase result, so the example turns the network's default failure handling off. If it stays on, its popup can appear as well, and while it waits for the player the request's `Timeout` does not run: the purchase manager may end the verification as `VerificationUnavailable` at its limit, and a retry the player picks afterwards can still grant on the server. The order then closes as already granted on the next recovery.
- Games that show rewards from `PurchaseBatchResult.Granted` should skip a `null` `Grant`: an already-granted order is in that list with nothing new to show.
- A request with `Route = NetworkRoute.Local` is judged by the project's local service. For development without a server, that or `UnverifiedPurchaseVerifier` works.
- Call `PurchaseManager.RecoverPendingPurchases` after `NetworkManager.SetSession` when the request needs a session. Before that it ends as `SessionNotReady`, which keeps the order pending.

## Trust boundary

The server decides whether an order is paid and what it grants. This package only carries the request and reads the answer; it does not check receipts itself.
