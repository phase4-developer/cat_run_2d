using System;
using System.Threading;
using PlatformLibrary.Network;

namespace PlatformLibrary.Purchase.Network
{
    /// <summary>
    /// Verifies orders with the project's server through <see cref="NetworkManager"/>. The project builds the request,
    /// with its own name, parameters and receipt fields, and lists the server's error strings.
    /// <para>
    /// A success becomes <see cref="PurchaseVerdict.Granted"/> with <see cref="NetworkResult.Data"/> as the grant. The
    /// network's response applier has already put that data into the repository before this answer, so purchase rewards
    /// reach the repository the same way as every other server response.
    /// </para>
    /// <para>
    /// Anything the server did not finish is <see cref="PurchaseVerdict.Unavailable"/>, so the order stays pending at the
    /// store and the next recovery tries it again. That includes <see cref="NetworkFailure.ApplyFailed"/>: the server may
    /// have granted, and on the next try it should answer with an already-granted error.
    /// </para>
    /// </summary>
    public sealed class PurchaseNetworkVerifier : IPurchaseVerifier
    {
        private readonly Func<PurchaseOrder, NetworkRequest> _createRequest;
        private readonly PurchaseServerErrors _errors;

        /// <param name="createRequest">Builds a new request for one order. Called once per verification.</param>
        /// <param name="errors">The server's error strings that close an order.</param>
        public PurchaseNetworkVerifier(Func<PurchaseOrder, NetworkRequest> createRequest, PurchaseServerErrors errors)
        {
            _createRequest = createRequest ?? throw new ArgumentNullException(nameof(createRequest));
            _errors = errors ?? throw new ArgumentNullException(nameof(errors));
        }

        public void Verify(PurchaseOrder order, Action<PurchaseVerification> completed)
        {
            if (completed == null) throw new ArgumentNullException(nameof(completed));

            int answered = 0;
            void Answer(PurchaseVerification verification)
            {
                if (Interlocked.Exchange(ref answered, 1) == 0) completed(verification);
            }

            NetworkRequest request;
            try
            {
                request = _createRequest(order);
            }
            catch (Exception exception)
            {
                Answer(PurchaseVerification.Unavailable(detail: "REQUEST_NOT_CREATED " + exception.GetType().Name + ": " + exception.Message));
                return;
            }

            if (request == null)
            {
                Answer(PurchaseVerification.Unavailable(detail: "REQUEST_NOT_CREATED"));
                return;
            }

            try
            {
                NetworkManager.Post(request, result => Answer(Judge(result)));
            }
            catch (Exception exception)
            {
                // For example a request instance that was already sent. Nothing reached the server.
                Answer(PurchaseVerification.Unavailable(detail: "REQUEST_NOT_SENT " + exception.GetType().Name + ": " + exception.Message));
            }
        }

        /// <summary>Turns one network result into a verdict. See the table in this package's README.</summary>
        private PurchaseVerification Judge(NetworkResult result)
        {
            if (result.Success) return PurchaseVerification.Granted(result.Data, result.ServerErrorCode, result.Detail);

            string detail = Describe(result);

            // A listed string is the server's answer about the order, whatever failure kind carried it. A server may send it
            // as a game error or only as an error message, which the network reports as a server error; both close the order.
            // Nothing new is granted, so the grant is the result's Data, which a failed result leaves empty.
            if (_errors.IsAlreadyGranted(result.ServerErrorCode)) return PurchaseVerification.AlreadyGranted(result.Data, result.ServerErrorCode, detail);
            if (_errors.IsRejected(result.ServerErrorCode)) return PurchaseVerification.Rejected(result.ServerErrorCode, detail);

            return PurchaseVerification.Unavailable(result.ServerErrorCode, detail);
        }

        private static string Describe(NetworkResult result)
        {
            string detail = result.Failure.ToString();
            if (!string.IsNullOrEmpty(result.Message)) detail += " " + result.Message;
            if (!string.IsNullOrEmpty(result.Detail)) detail += " " + result.Detail;
            return detail;
        }
    }
}
