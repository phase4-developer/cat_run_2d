using System;
using System.Collections.Generic;

namespace PlatformLibrary.Purchase.Network
{
    /// <summary>
    /// Which error strings from the server close an order. The strings are the server's own, so the project lists them.
    /// They are matched ignoring case, whatever failure kind carried them. A failed request with a string in neither list
    /// leaves the order pending, so it is tried again later.
    /// </summary>
    public sealed class PurchaseServerErrors
    {
        private readonly HashSet<string> _alreadyGranted = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _rejected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>The server had already recorded the order, for example a receipt used before. The order is closed as a success.</summary>
        public PurchaseServerErrors AlreadyGranted(params string[] serverErrorCodes)
        {
            Add(_alreadyGranted, _rejected, serverErrorCodes, nameof(Rejected));
            return this;
        }

        /// <summary>The server refused the receipt. The order is closed and nothing is granted.</summary>
        public PurchaseServerErrors Rejected(params string[] serverErrorCodes)
        {
            Add(_rejected, _alreadyGranted, serverErrorCodes, nameof(AlreadyGranted));
            return this;
        }

        internal bool IsAlreadyGranted(string serverErrorCode) => !string.IsNullOrEmpty(serverErrorCode) && _alreadyGranted.Contains(serverErrorCode);

        internal bool IsRejected(string serverErrorCode) => !string.IsNullOrEmpty(serverErrorCode) && _rejected.Contains(serverErrorCode);

        // One string cannot both close the order as granted and refuse it, so a code in both lists is a setup mistake.
        private static void Add(HashSet<string> target, HashSet<string> other, string[] codes, string otherList)
        {
            if (codes == null) return;
            foreach (string code in codes)
            {
                if (string.IsNullOrWhiteSpace(code)) continue;
                if (other.Contains(code)) throw new ArgumentException("\"" + code + "\" is already in the " + otherList + " list.", nameof(codes));
                target.Add(code);
            }
        }
    }
}
