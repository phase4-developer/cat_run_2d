# Changelog

## 0.1.0-pre.1 - 2026-11-08

- A code in either list is judged whatever failure kind carried it, and codes are matched ignoring case. A server that sends its code only as an error message reaches the client as a server error with that string, and the original game closed those orders too.

- First candidate. `PurchaseNetworkVerifier` sends the project's verification request through `NetworkManager.Post` and turns the `NetworkResult` into a `PurchaseVerification`. `PurchaseServerErrors` lists the server's error strings that close an order as already granted or rejected.
- Success is `Granted` with `NetworkResult.Data`, after the network's response applier ran. A failure with a code in the already-granted list is `AlreadyGranted` with `NetworkResult.Data`, which is `null` for a failure, as designed: nothing new is granted. Every other result, `ApplyFailed` included, is `Unavailable` and keeps the order pending.
- A request factory that throws or returns `null`, and a request `NetworkManager.Post` refuses, answer `Unavailable` without sending. The verifier answers once.
