using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>Scenes listed in Build Settings, addressed by name or path.</summary>
    public sealed class BuildSceneSource : ISceneSource
    {
        public const string SourceId = "build";

        public string Id => SourceId;

        public UniTask<bool> ContainsAsync(string key, CancellationToken cancellationToken)
            => UniTask.FromResult(Application.CanStreamedLevelBeLoaded(key));

        public ISceneLoadOperation BeginLoad(string key, LoadSceneMode mode) => new Operation(key, mode);

        sealed class Operation : ISceneLoadOperation
        {
            // AsyncOperation.progress stops here while allowSceneActivation is false.
            const float ReadyProgress = 0.9f;

            readonly string _sceneName;
            readonly AsyncOperation _load;
            Scene _scene;

            public Operation(string key, LoadSceneMode mode)
            {
                _sceneName = SceneNameOf(key);
                _load = SceneManager.LoadSceneAsync(key, mode);
                if (_load == null) throw new InvalidOperationException($"Build scene '{key}' could not start loading.");

                _load.allowSceneActivation = false;

                // A Single load replaces the current scene the moment it activates, so it has no way back.
                CanAbandon = mode == LoadSceneMode.Additive;
            }

            public bool CanAbandon { get; }

            public async UniTask WaitUntilReadyAsync(IProgress<float> progress, CancellationToken cancellationToken)
            {
                while (_load.progress < ReadyProgress)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    progress?.Report(_load.progress / ReadyProgress);
                    await UniTask.Yield();
                }

                progress?.Report(1f);
            }

            public async UniTask<Scene> ActivateAsync()
            {
                void Capture(Scene scene, LoadSceneMode mode)
                {
                    if (!_scene.IsValid() && scene.name == _sceneName) _scene = scene;
                }

                SceneManager.sceneLoaded += Capture;
                try
                {
                    _load.allowSceneActivation = true;
                    while (!_load.isDone) await UniTask.Yield();
                }
                finally
                {
                    SceneManager.sceneLoaded -= Capture;
                }

                if (!_scene.IsValid()) throw new InvalidOperationException($"Build scene '{_sceneName}' did not load.");
                return _scene;
            }

            // Unity cannot cancel a started load, so the scene has to activate before it can go.
            public async UniTask AbandonAsync()
            {
                await ActivateAsync();
                await UnloadAsync();
            }

            public async UniTask UnloadAsync()
            {
                // The game may already have closed it directly.
                if (!_scene.IsValid() || !_scene.isLoaded) return;

                var unload = SceneManager.UnloadSceneAsync(_scene);
                if (unload == null) throw new InvalidOperationException($"Build scene '{_sceneName}' could not be unloaded.");
                await unload.ToUniTask();
            }

            static string SceneNameOf(string key)
            {
                string name = key.Substring(key.LastIndexOf('/') + 1);
                return name.EndsWith(".unity", StringComparison.OrdinalIgnoreCase) ? name.Substring(0, name.Length - ".unity".Length) : name;
            }
        }
    }
}
