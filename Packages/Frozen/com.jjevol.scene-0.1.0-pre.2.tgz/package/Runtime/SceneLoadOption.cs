using System;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    public enum SceneLoadType
    {
        LoadingScene,
        FadeOnly,
        None
    }

    public class SceneLoadOption
    {
        public SceneLoadType loadType = SceneLoadType.LoadingScene;

        /// <summary>Loading view key. Null uses the presenter's default and empty shows no view.</summary>
        public string loadingScreen;

        public Color fadeColor = Color.black;
        public float fadeInDuration = 0.2f;
        public float fadeOutDuration = 0.2f;

        public Func<UniTask> postInitializeTask;

        /// <summary>Scene shown while the target loads, so the previous scene is released first. Null skips it.</summary>
        public string intermediateScene;

        /// <summary>Forces a source such as <see cref="BuildSceneSource.SourceId"/>. Null searches every source.</summary>
        public string sourceId;

        /// <summary>Shortest time the transition stays covered, in unscaled seconds. Ignored without a presenter.</summary>
        public float minimumLoadingSeconds;

        public bool unloadUnusedAssets = true;

        public static SceneLoadOption Loading(string loadingScreen = null, Func<UniTask> postInitializeTask = null)
        {
            return new SceneLoadOption
            {
                loadType = SceneLoadType.LoadingScene,
                loadingScreen = loadingScreen,
                minimumLoadingSeconds = 0.3f,
                postInitializeTask = postInitializeTask
            };
        }

        public static SceneLoadOption WhiteFade(float fadeInDuration = 0f, float fadeOutDuration = 0.35f, Func<UniTask> postInitializeTask = null)
        {
            return new SceneLoadOption
            {
                loadType = SceneLoadType.FadeOnly,
                loadingScreen = string.Empty,
                fadeColor = Color.white,
                fadeInDuration = fadeInDuration,
                fadeOutDuration = fadeOutDuration,
                postInitializeTask = postInitializeTask
            };
        }

        public static SceneLoadOption Direct(Func<UniTask> postInitializeTask = null)
        {
            return new SceneLoadOption
            {
                loadType = SceneLoadType.None,
                loadingScreen = string.Empty,
                fadeInDuration = 0f,
                fadeOutDuration = 0f,
                postInitializeTask = postInitializeTask
            };
        }

        internal SceneLoadOption Copy() => (SceneLoadOption)MemberwiseClone();
    }
}
