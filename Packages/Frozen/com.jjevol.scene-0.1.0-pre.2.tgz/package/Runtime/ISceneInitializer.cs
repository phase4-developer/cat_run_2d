using Cysharp.Threading.Tasks;

namespace jjevol
{
    /// <summary>
    /// Runs after its scene activates, lowest Priority first. Any component on an active object in the scene is found,
    /// so nothing needs registering.
    /// </summary>
    public interface ISceneInitializer
    {
        int Priority { get; }
        UniTask InitializeAsync(SceneLoadContext context);
    }
}
