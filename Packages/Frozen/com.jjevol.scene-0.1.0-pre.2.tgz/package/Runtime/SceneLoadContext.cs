using System.Threading;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>What an initializer knows about the request that opened its scene.</summary>
    public sealed class SceneLoadContext
    {
        internal SceneLoadContext(string key, object data, Scene scene, CancellationToken cancellationToken)
        {
            Key = key;
            Data = data;
            Scene = scene;
            CancellationToken = cancellationToken;
        }

        public string Key { get; }
        public object Data { get; }
        public Scene Scene { get; }
        public CancellationToken CancellationToken { get; }

        public bool TryGetData<T>(out T value)
        {
            if (Data is T typed)
            {
                value = typed;
                return true;
            }

            value = default;
            return false;
        }
    }
}
