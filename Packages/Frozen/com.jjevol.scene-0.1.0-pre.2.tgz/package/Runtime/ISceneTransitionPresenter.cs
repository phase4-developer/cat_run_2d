using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>
    /// What the player sees during a transition. A failure here is logged and the scene still loads, except
    /// <see cref="PrepareSceneAsync"/> for the requested scene, whose failure fails the request.
    /// </summary>
    public interface ISceneTransitionPresenter
    {
        /// <summary>Hides the current scene and readies the loading view.</summary>
        UniTask CoverAsync(SceneLoadOption option, CancellationToken cancellationToken);

        /// <summary>Lets the loading view be seen.</summary>
        UniTask ShowLoadingAsync(SceneLoadOption option, CancellationToken cancellationToken);

        void SetProgress(float progress);

        /// <summary>Connects shared systems to a new scene before its initializers run. Also runs for an intermediate scene.</summary>
        UniTask PrepareSceneAsync(Scene scene, CancellationToken cancellationToken);

        /// <summary>Hides and removes the loading view. Also runs after a failure.</summary>
        UniTask HideLoadingAsync(SceneLoadOption option);

        /// <summary>Shows the final scene. Also runs after a failure.</summary>
        UniTask RevealAsync(SceneLoadOption option);
    }

    /// <summary>A presenter that does nothing, so a game overrides only the steps it needs.</summary>
    public abstract class SceneTransitionPresenter : ISceneTransitionPresenter
    {
        public virtual UniTask CoverAsync(SceneLoadOption option, CancellationToken cancellationToken) => UniTask.CompletedTask;
        public virtual UniTask ShowLoadingAsync(SceneLoadOption option, CancellationToken cancellationToken) => UniTask.CompletedTask;
        public virtual void SetProgress(float progress) { }
        public virtual UniTask PrepareSceneAsync(Scene scene, CancellationToken cancellationToken) => UniTask.CompletedTask;
        public virtual UniTask HideLoadingAsync(SceneLoadOption option) => UniTask.CompletedTask;
        public virtual UniTask RevealAsync(SceneLoadOption option) => UniTask.CompletedTask;
    }

    internal sealed class NoSceneTransitionPresenter : SceneTransitionPresenter
    {
        public static readonly NoSceneTransitionPresenter Instance = new NoSceneTransitionPresenter();
    }
}
