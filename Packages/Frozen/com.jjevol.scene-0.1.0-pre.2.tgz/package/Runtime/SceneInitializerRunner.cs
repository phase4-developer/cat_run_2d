using System;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using UnityEngine.SceneManagement;

namespace jjevol
{
    internal static class SceneInitializerRunner
    {
        public static List<ISceneInitializer> Find(Scene scene)
        {
            var found = new List<ISceneInitializer>();
            if (!scene.IsValid() || !scene.isLoaded) return found;

            foreach (var root in scene.GetRootGameObjects())
            {
                // GetComponentsInChildren skips inactive children but still returns the object it was called on.
                if (root.activeSelf) found.AddRange(root.GetComponentsInChildren<ISceneInitializer>(false));
            }

            return found.OrderBy(initializer => initializer.Priority).ToList();
        }

        public static async UniTask RunAsync(SceneLoadContext context, Action<float> progress)
        {
            var initializers = Find(context.Scene);

            for (int i = 0; i < initializers.Count; i++)
            {
                context.CancellationToken.ThrowIfCancellationRequested();

                // An earlier initializer may have destroyed this one.
                if (initializers[i] is UnityEngine.Object component && component == null) continue;

                await initializers[i].InitializeAsync(context);
                progress?.Invoke((float)(i + 1) / initializers.Count);
            }
        }
    }
}
