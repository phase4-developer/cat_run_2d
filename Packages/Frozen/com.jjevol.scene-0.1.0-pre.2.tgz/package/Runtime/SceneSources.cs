using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// The sources a scene key is looked up in, highest priority first. Build Settings scenes are always available.
    /// </summary>
    public static class SceneSources
    {
        public const int DefaultPriority = 100;

        const int BuildPriority = 0;

        static readonly List<KeyValuePair<int, ISceneSource>> Registered = new List<KeyValuePair<int, ISceneSource>>();

        static SceneSources() => Reset();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void Reset()
        {
            Registered.Clear();
            Add(new BuildSceneSource(), BuildPriority);
        }

        /// <summary>
        /// Adds a source, replacing any source with the same Id. Automatic registration belongs at
        /// RuntimeInitializeLoadType.BeforeSceneLoad, because the list resets at SubsystemRegistration.
        /// </summary>
        public static void Register(ISceneSource source, int priority = DefaultPriority)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (string.IsNullOrWhiteSpace(source.Id)) throw new ArgumentException("A source id is required.", nameof(source));

            Registered.RemoveAll(entry => entry.Value.Id == source.Id);
            Add(source, priority);
        }

        public static void Unregister(ISceneSource source) => Registered.RemoveAll(entry => ReferenceEquals(entry.Value, source));

        static void Add(ISceneSource source, int priority)
        {
            // Earlier registrations stay ahead of later ones with the same priority.
            int index = Registered.FindIndex(entry => entry.Key < priority);
            Registered.Insert(index < 0 ? Registered.Count : index, new KeyValuePair<int, ISceneSource>(priority, source));
        }

        internal static async UniTask<ISceneSource> ResolveAsync(string key, string sourceId, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("A scene key is required.", nameof(key));

            var candidates = Registered.Select(entry => entry.Value)
                .Where(source => string.IsNullOrEmpty(sourceId) || source.Id == sourceId)
                .ToList();

            foreach (var source in candidates)
            {
                cancellationToken.ThrowIfCancellationRequested();

                try
                {
                    if (await source.ContainsAsync(key, cancellationToken)) return source;
                }
                catch (Exception exception) when (!(exception is OperationCanceledException))
                {
                    // A source that cannot answer must not hide a scene another source holds.
                    Debug.LogWarning($"[CustomSceneManager] Source '{source.Id}' could not look up '{key}': {exception.Message}");
                }
            }

            string searched = candidates.Count == 0 ? $"no source named '{sourceId}'" : string.Join(", ", candidates.Select(source => source.Id));
            throw new InvalidOperationException($"Scene '{key}' was not found. Searched: {searched}. Add it to Build Settings, or install com.jjevol.scene.addressables for an Addressable scene.");
        }
    }
}
