using System;
using UnityEngine.SceneManagement;

namespace jjevol
{
    public enum SceneLoadStatus
    {
        Succeeded,
        Failed,

        /// <summary>Another scene operation was running, so this request did nothing.</summary>
        Rejected,
        Canceled
    }

    /// <summary>The last step a request reached.</summary>
    public enum SceneLoadStage
    {
        Validate,
        Cover,
        Load,
        Activate,
        Prepare,
        Initialize,
        Complete
    }

    public sealed class SceneLoadResult
    {
        internal SceneLoadResult(string key, SceneLoadStatus status, SceneLoadStage stage, Scene scene, bool sceneChanged, Exception exception)
        {
            Key = key;
            Status = status;
            Stage = stage;
            Scene = scene;
            SceneChanged = sceneChanged;
            Exception = exception;
        }

        public string Key { get; }
        public SceneLoadStatus Status { get; }
        public SceneLoadStage Stage { get; }

        /// <summary>The requested scene. Invalid when it never became active.</summary>
        public Scene Scene { get; }

        /// <summary>False means the scene that was active before the request is still loaded.</summary>
        public bool SceneChanged { get; }

        public Exception Exception { get; }
        public bool IsSuccess => Status == SceneLoadStatus.Succeeded;
    }
}
