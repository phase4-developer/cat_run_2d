using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>A place scenes are loaded from. Register one with <see cref="SceneSources.Register"/>.</summary>
    public interface ISceneSource
    {
        string Id { get; }

        /// <summary>Answered before the screen changes, so a wrong key fails with the current scene intact.</summary>
        UniTask<bool> ContainsAsync(string key, CancellationToken cancellationToken);

        ISceneLoadOperation BeginLoad(string key, LoadSceneMode mode);
    }

    /// <summary>One scene load, held back from activation until the transition asks for it.</summary>
    public interface ISceneLoadOperation
    {
        /// <summary>False when the load cannot be stopped without replacing the current scene.</summary>
        bool CanAbandon { get; }

        /// <summary>Completes when the scene is ready to activate. Reports progress from 0 to 1.</summary>
        UniTask WaitUntilReadyAsync(IProgress<float> progress, CancellationToken cancellationToken);

        UniTask<Scene> ActivateAsync();

        /// <summary>Drops a load that will not be used. Called only when <see cref="CanAbandon"/> is true.</summary>
        UniTask AbandonAsync();

        UniTask UnloadAsync();
    }
}
