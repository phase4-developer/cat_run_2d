using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    public abstract class SceneInitializerBase : MonoBehaviour, ISceneInitializer
    {
        public virtual int Priority => 0;

        /// <summary>The request being served. Set before <see cref="OnInitializeAsync"/> runs and meaningful only until it ends.</summary>
        protected SceneLoadContext Context { get; private set; }

        protected virtual void Awake() { }

        protected virtual void OnDestroy() { }

        public abstract UniTask OnInitializeAsync();

        UniTask ISceneInitializer.InitializeAsync(SceneLoadContext context)
        {
            Context = context;
            return OnInitializeAsync();
        }
    }
}
