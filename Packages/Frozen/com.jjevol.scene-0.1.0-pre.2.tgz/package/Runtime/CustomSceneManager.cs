using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>
    /// Entry point for scene changes. Created on first use, and every request returns a result rather than throwing.
    /// </summary>
    public class CustomSceneManager : MonoBehaviour
    {
        static CustomSceneManager _instance;
        static bool _quitting;

        readonly Dictionary<string, AdditiveScene> _additiveScenes = new Dictionary<string, AdditiveScene>();
        CancellationTokenSource _outsideRequests;
        SceneLoadOption _defaultOption = SceneLoadOption.Loading();
        Scene _currentScene;
        bool _isLoading;

        public static Action<float> OnProgressChanged;
        public static Action OnLoadStart;
        public static Action OnLoadEnd;

        /// <summary>Shows transitions. Null runs them without any visuals.</summary>
        public static ISceneTransitionPresenter Presenter { get; set; }

        public static CustomSceneManager Instance
        {
            get
            {
                if (_quitting || !Application.isPlaying) return null;

                if (_instance == null) _instance = FindAnyObjectByType<CustomSceneManager>();
                if (_instance == null) _instance = new GameObject(nameof(CustomSceneManager)).AddComponent<CustomSceneManager>();

                return _instance;
            }
        }

        public static bool HasInstance => !_quitting && _instance != null;

        public bool IsLoading => _isLoading;

        /// <summary>The key of the last scene this manager opened.</summary>
        public string CurrentSceneKey { get; private set; }

        /// <summary>Used when a request passes no option.</summary>
        public SceneLoadOption DefaultOption
        {
            get => _defaultOption;
            set => _defaultOption = value ?? SceneLoadOption.Loading();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetSession()
        {
            _instance = null;
            _quitting = false;
            OnProgressChanged = null;
            OnLoadStart = null;
            OnLoadEnd = null;
            Presenter = null;

            Application.quitting -= MarkQuitting;
            Application.quitting += MarkQuitting;
            SceneManager.sceneLoaded -= HandleSceneLoaded;
            SceneManager.sceneLoaded += HandleSceneLoaded;
        }

        static void MarkQuitting() => _quitting = true;

        // Covers the first scene and a scene opened directly in the Editor, which never pass through a request.
        static void HandleSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (_quitting || (HasInstance && _instance._isLoading)) return;
            if (SceneInitializerRunner.Find(scene).Count > 0) Instance.InitializeOutsideRequestAsync(scene).Forget();
        }

        protected virtual void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }

            _instance = this;

            // DontDestroyOnLoad applies only to root objects.
            if (transform.parent != null) transform.SetParent(null);
            DontDestroyOnLoad(gameObject);
        }

        protected virtual void OnDestroy()
        {
            CancelOutsideRequests();
            if (_instance == this) _instance = null;
        }

        /// <summary>OnLoadStart and OnLoadEnd fire only for a scene that exists, so a wrong key leaves listeners alone.</summary>
        public async UniTask<SceneLoadResult> LoadSceneAsync(string sceneName, SceneLoadOption option = null, object data = null, CancellationToken cancellationToken = default)
        {
            if (_isLoading) return Reject(sceneName);

            _isLoading = true;
            var presenter = Presenter ?? NoSceneTransitionPresenter.Instance;
            var snapshot = (option ?? _defaultOption).Copy();
            bool started = false;
            SceneLoadResult result;

            void Start()
            {
                started = true;
                CancelOutsideRequests();
                Notify(OnLoadStart);
                Report(presenter, 0f);
            }

            using (var lifetime = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, this.GetCancellationTokenOnDestroy()))
            {
                try
                {
                    result = await new SceneTransitionPipeline(sceneName, snapshot, data, presenter, value => Report(presenter, value), Start, lifetime.Token).RunAsync();
                    Remember(result);
                }
                finally
                {
                    _isLoading = false;
                }
            }

            if (started) Notify(OnLoadEnd);
            return result;
        }

        /// <summary>Reloads the active scene and runs its initializers again.</summary>
        public UniTask<SceneLoadResult> ReloadActiveSceneAsync(SceneLoadOption option = null, object data = null, CancellationToken cancellationToken = default)
        {
            var active = SceneManager.GetActiveScene();
            string key = active == _currentScene && !string.IsNullOrEmpty(CurrentSceneKey) ? CurrentSceneKey : active.name;
            return LoadSceneAsync(key, option, data, cancellationToken);
        }

        [Obsolete("Pass a SceneLoadOption. An empty loadingScreen is SceneLoadOption.loadingScreen = string.Empty.")]
        public UniTask<SceneLoadResult> LoadSceneAsync(string sceneName, string loadingScreen, Func<UniTask> postInitializeTask = null)
        {
            var option = _defaultOption.Copy();
            option.loadingScreen = loadingScreen;
            option.postInitializeTask = postInitializeTask;
            return LoadSceneAsync(sceneName, option);
        }

        [Obsolete("Pass a SceneLoadOption with postInitializeTask.")]
        public UniTask<SceneLoadResult> LoadSceneAsync(string sceneName, Func<UniTask> postInitializeTask)
        {
            var option = _defaultOption.Copy();
            option.postInitializeTask = postInitializeTask;
            return LoadSceneAsync(sceneName, option);
        }

        /// <summary>Adds a scene on top of the current one. It leaves with the next full scene change or UnloadAdditiveAsync.</summary>
        public async UniTask<SceneLoadResult> LoadAdditiveAsync(string sceneName, object data = null, CancellationToken cancellationToken = default)
        {
            if (_isLoading) return Reject(sceneName);

            if (!string.IsNullOrEmpty(sceneName) && _additiveScenes.TryGetValue(sceneName, out var existing))
            {
                if (existing.Scene.isLoaded) return Reject(sceneName);

                // The game closed it directly, so the name is free again.
                _additiveScenes.Remove(sceneName);
            }

            _isLoading = true;

            using (var lifetime = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, this.GetCancellationTokenOnDestroy()))
            {
                try
                {
                    var pipeline = new SceneTransitionPipeline(sceneName, new SceneLoadOption(), data, NoSceneTransitionPresenter.Instance, _ => { }, null, lifetime.Token);
                    var result = await pipeline.RunAdditiveAsync();
                    if (result.IsSuccess) _additiveScenes[sceneName] = new AdditiveScene(pipeline.Operation, result.Scene);
                    return result;
                }
                finally
                {
                    _isLoading = false;
                }
            }
        }

        public async UniTask<SceneLoadResult> UnloadAdditiveAsync(string sceneName)
        {
            if (_isLoading) return Reject(sceneName);

            if (string.IsNullOrEmpty(sceneName) || !_additiveScenes.TryGetValue(sceneName, out var additive))
            {
                var missing = new InvalidOperationException($"Additive scene '{sceneName}' is not loaded.");
                Debug.LogError($"[CustomSceneManager] Unload Failed: {missing.Message}");
                return new SceneLoadResult(sceneName, SceneLoadStatus.Failed, SceneLoadStage.Validate, default, false, missing);
            }

            _isLoading = true;

            try
            {
                await additive.Operation.UnloadAsync();
                _additiveScenes.Remove(sceneName);
                return new SceneLoadResult(sceneName, SceneLoadStatus.Succeeded, SceneLoadStage.Complete, default, false, null);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[CustomSceneManager] Unload Failed: {exception.Message}");
                return new SceneLoadResult(sceneName, SceneLoadStatus.Failed, SceneLoadStage.Load, default, false, exception);
            }
            finally
            {
                _isLoading = false;
            }
        }

        async UniTaskVoid InitializeOutsideRequestAsync(Scene scene)
        {
            _outsideRequests ??= new CancellationTokenSource();

            using (var lifetime = CancellationTokenSource.CreateLinkedTokenSource(_outsideRequests.Token, this.GetCancellationTokenOnDestroy()))
            {
                var token = lifetime.Token;

                try
                {
                    // Lets the rest of the scene finish its own sceneLoaded and Awake work first.
                    await UniTask.Yield(token);
                    await (Presenter ?? NoSceneTransitionPresenter.Instance).PrepareSceneAsync(scene, token);
                    await SceneInitializerRunner.RunAsync(new SceneLoadContext(scene.name, null, scene, token), null);
                }
                catch (OperationCanceledException)
                {
                }
                catch (Exception exception)
                {
                    Debug.LogError($"[CustomSceneManager] Initialize Failed: {exception.Message}");
                }
            }
        }

        // A transition takes the scene these are working on away from them.
        void CancelOutsideRequests()
        {
            _outsideRequests?.Cancel();
            _outsideRequests?.Dispose();
            _outsideRequests = null;
        }

        void Remember(SceneLoadResult result)
        {
            if (result.SceneChanged) _additiveScenes.Clear();
            if (!result.Scene.IsValid()) return;

            CurrentSceneKey = result.Key;
            _currentScene = result.Scene;
        }

        static SceneLoadResult Reject(string sceneName)
        {
            Debug.LogWarning($"[CustomSceneManager] Ignored '{sceneName}': a scene operation is running or the scene is already loaded.");
            return new SceneLoadResult(sceneName, SceneLoadStatus.Rejected, SceneLoadStage.Validate, default, false, null);
        }

        static void Report(ISceneTransitionPresenter presenter, float progress)
        {
            try
            {
                OnProgressChanged?.Invoke(progress);
                presenter.SetProgress(progress);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
            }
        }

        static void Notify(Action listeners)
        {
            try
            {
                listeners?.Invoke();
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
            }
        }

        readonly struct AdditiveScene
        {
            public AdditiveScene(ISceneLoadOperation operation, Scene scene)
            {
                Operation = operation;
                Scene = scene;
            }

            public ISceneLoadOperation Operation { get; }
            public Scene Scene { get; }
        }
    }
}
