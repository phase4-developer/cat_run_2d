using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>One run of the transition order. It never throws: every outcome becomes a SceneLoadResult.</summary>
    internal sealed class SceneTransitionPipeline
    {
        const float LoadStartProgress = 0.1f;
        const float LoadEndProgress = 0.7f;

        readonly string _key;
        readonly SceneLoadOption _option;
        readonly object _data;
        readonly ISceneTransitionPresenter _presenter;
        readonly Action<float> _report;
        readonly Action _started;
        readonly CancellationToken _token;

        SceneLoadStage _stage = SceneLoadStage.Validate;
        ISceneLoadOperation _intermediate;
        Scene _scene;
        bool _covered;
        bool _sceneChanged;

        /// <param name="started">Runs once the scene is known to exist, so a wrong key disturbs nothing.</param>
        public SceneTransitionPipeline(string key, SceneLoadOption option, object data, ISceneTransitionPresenter presenter, Action<float> report, Action started, CancellationToken token)
        {
            _key = key;
            _option = option;
            _data = data;
            _presenter = presenter;
            _report = report;
            _started = started;
            _token = token;
        }

        /// <summary>The loaded scene's operation, kept by the caller so an additive scene can be unloaded later.</summary>
        public ISceneLoadOperation Operation { get; private set; }

        public async UniTask<SceneLoadResult> RunAsync()
        {
            float startedAt = Time.realtimeSinceStartup;

            try
            {
                _token.ThrowIfCancellationRequested();
                var source = await SceneSources.ResolveAsync(_key, _option.sourceId, _token);
                var intermediateSource = string.IsNullOrEmpty(_option.intermediateScene) ? null : await SceneSources.ResolveAsync(_option.intermediateScene, null, _token);

                _started?.Invoke();

                _stage = SceneLoadStage.Cover;
                _covered = true;
                await PresentAsync("Cover", () => _presenter.CoverAsync(_option, _token));

                _stage = SceneLoadStage.Load;
                if (intermediateSource != null) await OpenIntermediateAsync(intermediateSource);
                await PresentAsync("Show loading", () => _presenter.ShowLoadingAsync(_option, _token));

                await UniTask.NextFrame(_token);
                await ReleaseMemoryAsync();

                Operation = source.BeginLoad(_key, intermediateSource != null ? LoadSceneMode.Additive : LoadSceneMode.Single);
                await WaitUntilReadyAsync(Operation, LoadProgress());

                _stage = SceneLoadStage.Activate;
                _sceneChanged = true;
                _scene = await Operation.ActivateAsync();
                MakeActive(_scene);
                _report(LoadEndProgress);

                _stage = SceneLoadStage.Prepare;
                _token.ThrowIfCancellationRequested();
                await _presenter.PrepareSceneAsync(_scene, _token);

                _stage = SceneLoadStage.Initialize;
                await InitializeAsync();
                _token.ThrowIfCancellationRequested();
                if (_option.postInitializeTask != null) await _option.postInitializeTask.Invoke();

                _report(1f);
                await HoldMinimumTimeAsync(startedAt);

                _stage = SceneLoadStage.Complete;
                await CloseAsync();
                return Result(SceneLoadStatus.Succeeded, null);
            }
            catch (OperationCanceledException exception)
            {
                await CloseAsync();
                return Result(SceneLoadStatus.Canceled, exception);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[CustomSceneManager] Load Failed: {exception.Message}");
                await CloseAsync();
                return Result(SceneLoadStatus.Failed, exception);
            }
        }

        public async UniTask<SceneLoadResult> RunAdditiveAsync()
        {
            ISceneLoadOperation operation = null;

            try
            {
                _token.ThrowIfCancellationRequested();
                var source = await SceneSources.ResolveAsync(_key, _option.sourceId, _token);

                _stage = SceneLoadStage.Load;
                operation = source.BeginLoad(_key, LoadSceneMode.Additive);
                await WaitUntilReadyAsync(operation, LoadProgress());

                _stage = SceneLoadStage.Activate;
                _scene = await operation.ActivateAsync();

                _stage = SceneLoadStage.Initialize;
                await InitializeAsync();

                _stage = SceneLoadStage.Complete;
                Operation = operation;
                return Result(SceneLoadStatus.Succeeded, null);
            }
            catch (OperationCanceledException exception)
            {
                await UnloadFailedAdditiveAsync(operation);
                return Result(SceneLoadStatus.Canceled, exception);
            }
            catch (Exception exception)
            {
                Debug.LogError($"[CustomSceneManager] Load Failed: {exception.Message}");
                await UnloadFailedAdditiveAsync(operation);
                return Result(SceneLoadStatus.Failed, exception);
            }
        }

        async UniTask OpenIntermediateAsync(ISceneSource source)
        {
            _intermediate = source.BeginLoad(_option.intermediateScene, LoadSceneMode.Single);

            // Not reported: progress must only rise, and the target's load owns this range.
            await WaitUntilReadyAsync(_intermediate, null);

            _sceneChanged = true;
            var scene = await _intermediate.ActivateAsync();
            MakeActive(scene);

            // Shared systems may have left with the previous scene, and the loading view stands on them.
            await PresentAsync("Prepare intermediate scene", () => _presenter.PrepareSceneAsync(scene, _token));
        }

        IProgress<float> LoadProgress() => Progress.Create<float>(value => _report(Mathf.Lerp(LoadStartProgress, LoadEndProgress, value)));

        async UniTask WaitUntilReadyAsync(ISceneLoadOperation operation, IProgress<float> progress)
        {
            try
            {
                await operation.WaitUntilReadyAsync(progress, operation.CanAbandon ? _token : CancellationToken.None);
                if (operation.CanAbandon) _token.ThrowIfCancellationRequested();
            }
            catch (OperationCanceledException)
            {
                if (operation.CanAbandon) await CleanupAsync("Abandon", operation.AbandonAsync);
                throw;
            }
        }

        UniTask InitializeAsync()
        {
            var context = new SceneLoadContext(_key, _data, _scene, _token);
            return SceneInitializerRunner.RunAsync(context, value => _report(Mathf.Lerp(LoadEndProgress, 1f, value)));
        }

        async UniTask ReleaseMemoryAsync()
        {
            if (!_option.unloadUnusedAssets) return;

            await Resources.UnloadUnusedAssets().ToUniTask(cancellationToken: _token);
            GC.Collect();
        }

        async UniTask HoldMinimumTimeAsync(float startedAt)
        {
            if (_presenter is NoSceneTransitionPresenter) return;

            float remaining = _option.minimumLoadingSeconds - (Time.realtimeSinceStartup - startedAt);
            if (remaining > 0f) await UniTask.Delay(TimeSpan.FromSeconds(remaining), DelayType.UnscaledDeltaTime, cancellationToken: _token);
        }

        async UniTask CloseAsync()
        {
            if (!_covered) return;

            await CleanupAsync("Hide loading", () => _presenter.HideLoadingAsync(_option));

            // Without the target, the intermediate scene is all that is left to stand on, so it stays.
            if (_intermediate != null && _scene.IsValid()) await CleanupAsync("Unload intermediate scene", _intermediate.UnloadAsync);

            await CleanupAsync("Reveal", () => _presenter.RevealAsync(_option));
        }

        async UniTask UnloadFailedAdditiveAsync(ISceneLoadOperation operation)
        {
            if (operation != null && _scene.IsValid()) await CleanupAsync("Unload failed scene", operation.UnloadAsync);
        }

        static async UniTask PresentAsync(string step, Func<UniTask> action)
        {
            try
            {
                await action();
            }
            catch (Exception exception) when (!(exception is OperationCanceledException))
            {
                Debug.LogWarning($"[CustomSceneManager] {step} failed: {exception.Message}");
            }
        }

        static async UniTask CleanupAsync(string step, Func<UniTask> action)
        {
            try
            {
                await action();
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"[CustomSceneManager] {step} failed: {exception.Message}");
            }
        }

        static void MakeActive(Scene scene)
        {
            if (scene.IsValid() && scene.isLoaded) SceneManager.SetActiveScene(scene);
        }

        SceneLoadResult Result(SceneLoadStatus status, Exception exception) => new SceneLoadResult(_key, status, _stage, _scene, _sceneChanged, exception);
    }
}
