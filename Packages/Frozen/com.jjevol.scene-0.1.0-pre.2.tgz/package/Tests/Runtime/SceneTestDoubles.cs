using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using jjevol;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace JJEvolSceneTests
{
    /// <summary>A source whose scenes are created in memory, so the flow can be tested without scene assets.</summary>
    internal sealed class FakeSceneSource : ISceneSource
    {
        readonly HashSet<string> _keys;

        public FakeSceneSource(string id, params string[] keys)
        {
            Id = id;
            _keys = new HashSet<string>(keys);
        }

        public string Id { get; }
        public List<Scene> Created { get; } = new List<Scene>();
        public List<FakeSceneOperation> Operations { get; } = new List<FakeSceneOperation>();

        /// <summary>Holds every load at WaitUntilReadyAsync until set.</summary>
        public UniTaskCompletionSource Gate { get; set; }
        public Exception LoadFailure { get; set; }
        public bool CanAbandon { get; set; } = true;
        public Action<Scene, string> Populate { get; set; }

        public UniTask<bool> ContainsAsync(string key, CancellationToken cancellationToken) => UniTask.FromResult(_keys.Contains(key));

        public ISceneLoadOperation BeginLoad(string key, LoadSceneMode mode)
        {
            var operation = new FakeSceneOperation(this, key, mode);
            Operations.Add(operation);
            return operation;
        }
    }

    internal sealed class FakeSceneOperation : ISceneLoadOperation
    {
        readonly FakeSceneSource _source;
        readonly string _key;
        Scene _scene;

        public FakeSceneOperation(FakeSceneSource source, string key, LoadSceneMode mode)
        {
            _source = source;
            _key = key;
            Mode = mode;
        }

        public LoadSceneMode Mode { get; }
        public bool Abandoned { get; private set; }
        public bool Unloaded { get; private set; }
        public bool CanAbandon => _source.CanAbandon;

        public async UniTask WaitUntilReadyAsync(IProgress<float> progress, CancellationToken cancellationToken)
        {
            progress?.Report(0.5f);
            if (_source.Gate != null) await _source.Gate.Task.AttachExternalCancellation(cancellationToken);
            await UniTask.Yield();
            if (_source.LoadFailure != null) throw _source.LoadFailure;
            progress?.Report(1f);
        }

        public UniTask<Scene> ActivateAsync()
        {
            _scene = SceneManager.CreateScene(_key + "-" + Guid.NewGuid().ToString("N"));
            _source.Created.Add(_scene);
            _source.Populate?.Invoke(_scene, _key);
            return UniTask.FromResult(_scene);
        }

        public UniTask AbandonAsync()
        {
            Abandoned = true;
            return UniTask.CompletedTask;
        }

        public async UniTask UnloadAsync()
        {
            Unloaded = true;
            await SceneManager.UnloadSceneAsync(_scene).ToUniTask();
        }
    }

    internal sealed class RecordingPresenter : SceneTransitionPresenter
    {
        public List<string> Log { get; set; } = new List<string>();
        public List<float> Progress { get; } = new List<float>();
        public Action OnPrepare { get; set; }
        public Exception CoverFailure { get; set; }
        public Exception PrepareFailure { get; set; }
        public SceneLoadOption LastOption { get; private set; }

        public override UniTask CoverAsync(SceneLoadOption option, CancellationToken cancellationToken)
        {
            LastOption = option;
            Log.Add("cover");
            return CoverFailure != null ? UniTask.FromException(CoverFailure) : UniTask.CompletedTask;
        }

        public override UniTask ShowLoadingAsync(SceneLoadOption option, CancellationToken cancellationToken)
        {
            Log.Add("show");
            return UniTask.CompletedTask;
        }

        public override void SetProgress(float progress) => Progress.Add(progress);

        public override UniTask PrepareSceneAsync(Scene scene, CancellationToken cancellationToken)
        {
            Log.Add("prepare");
            OnPrepare?.Invoke();
            return PrepareFailure != null ? UniTask.FromException(PrepareFailure) : UniTask.CompletedTask;
        }

        public override UniTask HideLoadingAsync(SceneLoadOption option)
        {
            Log.Add("hide");
            return UniTask.CompletedTask;
        }

        public override UniTask RevealAsync(SceneLoadOption option)
        {
            Log.Add("reveal");
            return UniTask.CompletedTask;
        }
    }

    internal sealed class RecordingInitializer : SceneInitializerBase
    {
        public int Order { get; set; }
        public Action<SceneLoadContext> Run { get; set; }

        public override int Priority => Order;

        public override UniTask OnInitializeAsync()
        {
            Run?.Invoke(Context);
            return UniTask.CompletedTask;
        }

        public static RecordingInitializer Add(Scene scene, int order, Action<SceneLoadContext> run)
        {
            var host = new GameObject("initializer-" + order);
            SceneManager.MoveGameObjectToScene(host, scene);
            var initializer = host.AddComponent<RecordingInitializer>();
            initializer.Order = order;
            initializer.Run = run;
            return initializer;
        }
    }
}
