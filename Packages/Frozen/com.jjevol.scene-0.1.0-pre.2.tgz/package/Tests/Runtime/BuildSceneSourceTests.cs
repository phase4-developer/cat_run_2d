#if UNITY_EDITOR
using System.Collections;
using System.Linq;
using System.Threading;
using Cysharp.Threading.Tasks;
using jjevol;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace JJEvolSceneTests
{
    /// <summary>Adds a real scene asset to Build Settings for the duration of the run.</summary>
    public sealed class BuildSceneFixture : IPrebuildSetup, IPostBuildCleanup
    {
        internal const string SceneName = "JJEvolSceneBuildFixture";
        const string Folder = "Assets/JJEvolSceneTests";
        const string ScenePath = Folder + "/" + SceneName + ".unity";

        public void Setup()
        {
            if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets", "JJEvolSceneTests");

            // Unity refuses to add a scene next to an untitled one.
            var prior = SceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(prior.path)) EditorSceneManager.SaveScene(prior, Folder + "/Anchor.unity");

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            var host = new GameObject("build-fixture-initializer", typeof(BuildFixtureInitializer));
            SceneManager.MoveGameObjectToScene(host, scene);
            EditorSceneManager.SaveScene(scene, ScenePath);
            if (prior.IsValid()) SceneManager.SetActiveScene(prior);
            EditorSceneManager.CloseScene(scene, true);

            EditorBuildSettings.scenes = EditorBuildSettings.scenes.Append(new EditorBuildSettingsScene(ScenePath, true)).ToArray();
        }

        public void Cleanup()
        {
            EditorBuildSettings.scenes = EditorBuildSettings.scenes.Where(scene => scene.path != ScenePath).ToArray();
            AssetDatabase.DeleteAsset(Folder);
        }
    }

    [PrebuildSetup(typeof(BuildSceneFixture))]
    [PostBuildCleanup(typeof(BuildSceneFixture))]
    public sealed class BuildSceneSourceTests
    {
        static SceneLoadOption Direct => new SceneLoadOption { loadType = SceneLoadType.None, unloadUnusedAssets = false };

        [SetUp]
        public void SetUp() => BuildFixtureInitializer.Runs = 0;

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            var fixture = SceneManager.GetSceneByName(BuildSceneFixture.SceneName);
            if (fixture.IsValid() && fixture.isLoaded)
            {
                // A Single load leaves the fixture as the only scene, and the last scene cannot be unloaded.
                if (SceneManager.sceneCount == 1) SceneManager.SetActiveScene(SceneManager.CreateScene("anchor-" + System.Guid.NewGuid().ToString("N")));
                yield return SceneManager.UnloadSceneAsync(fixture);
            }

            if (CustomSceneManager.HasInstance) Object.Destroy(CustomSceneManager.Instance.gameObject);
            yield return null;
        }

        [UnityTest]
        public IEnumerator ContainsOnlyScenesInBuildSettings() => UniTask.ToCoroutine(async () =>
        {
            var source = new BuildSceneSource();

            Assert.That(await source.ContainsAsync(BuildSceneFixture.SceneName, default), Is.True);
            Assert.That(await source.ContainsAsync("NotInBuildSettings", default), Is.False);
        });

        [UnityTest]
        public IEnumerator BuildSceneLoadsByNameThroughTheSameCall() => UniTask.ToCoroutine(async () =>
        {
            var result = await CustomSceneManager.Instance.LoadSceneAsync(BuildSceneFixture.SceneName, Direct);

            Assert.That(result.IsSuccess, Is.True);
            Assert.That(SceneManager.GetActiveScene().name, Is.EqualTo(BuildSceneFixture.SceneName));
            Assert.That(BuildFixtureInitializer.Runs, Is.EqualTo(1));
        });

        [UnityTest]
        public IEnumerator BuildSceneLoadsAdditivelyAndUnloads() => UniTask.ToCoroutine(async () =>
        {
            var manager = CustomSceneManager.Instance;

            var loaded = await manager.LoadAdditiveAsync(BuildSceneFixture.SceneName);
            bool wasLoaded = SceneManager.GetSceneByName(BuildSceneFixture.SceneName).isLoaded;
            var unloaded = await manager.UnloadAdditiveAsync(BuildSceneFixture.SceneName);

            Assert.That(loaded.IsSuccess, Is.True);
            Assert.That(wasLoaded, Is.True);
            Assert.That(unloaded.IsSuccess, Is.True);
            Assert.That(SceneManager.GetSceneByName(BuildSceneFixture.SceneName).isLoaded, Is.False);
            Assert.That(BuildFixtureInitializer.Runs, Is.EqualTo(1));
        });

        [UnityTest]
        public IEnumerator CancelingAnAdditiveBuildLoadRemovesTheScene() => UniTask.ToCoroutine(async () =>
        {
            using var cancellation = new CancellationTokenSource();
            var pending = CustomSceneManager.Instance.LoadAdditiveAsync(BuildSceneFixture.SceneName, null, cancellation.Token);
            cancellation.Cancel();

            var result = await pending;

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Canceled));
            Assert.That(SceneManager.GetSceneByName(BuildSceneFixture.SceneName).isLoaded, Is.False);
            Assert.That(BuildFixtureInitializer.Runs, Is.Zero);
            Assert.That(CustomSceneManager.Instance.IsLoading, Is.False);
        });

        [UnityTest]
        public IEnumerator AdditiveSceneClosedByTheGameCanLoadAgain() => UniTask.ToCoroutine(async () =>
        {
            var manager = CustomSceneManager.Instance;
            await manager.LoadAdditiveAsync(BuildSceneFixture.SceneName);
            await SceneManager.UnloadSceneAsync(BuildSceneFixture.SceneName).ToUniTask();

            var again = await manager.LoadAdditiveAsync(BuildSceneFixture.SceneName);
            var unloaded = await manager.UnloadAdditiveAsync(BuildSceneFixture.SceneName);

            Assert.That(again.IsSuccess, Is.True);
            Assert.That(unloaded.IsSuccess, Is.True);
        });

        [UnityTest]
        public IEnumerator SceneOpenedWithoutARequestStillInitializes() => UniTask.ToCoroutine(async () =>
        {
            await SceneManager.LoadSceneAsync(BuildSceneFixture.SceneName, LoadSceneMode.Additive).ToUniTask();

            for (int frame = 0; frame < 3; frame++) await UniTask.NextFrame();

            Assert.That(BuildFixtureInitializer.Runs, Is.EqualTo(1));
        });

        [UnityTest]
        public IEnumerator SceneOpenedByARequestInitializesOnce() => UniTask.ToCoroutine(async () =>
        {
            await CustomSceneManager.Instance.LoadAdditiveAsync(BuildSceneFixture.SceneName);

            for (int frame = 0; frame < 3; frame++) await UniTask.NextFrame();

            Assert.That(BuildFixtureInitializer.Runs, Is.EqualTo(1));
        });
    }
}
#endif
