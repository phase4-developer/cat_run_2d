using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using Cysharp.Threading.Tasks;
using jjevol;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace JJEvolSceneTests
{
    public sealed class CustomSceneManagerTests
    {
        const string Target = "Target";
        const string Holding = "Holding";

        static readonly Regex LoadFailed = new Regex(@"^\[CustomSceneManager\] Load Failed:");

        Scene _origin;
        FakeSceneSource _source;
        RecordingPresenter _presenter;
        ISceneTransitionPresenter _installedPresenter;

        static SceneLoadOption Plain => new SceneLoadOption { loadType = SceneLoadType.None, unloadUnusedAssets = false };

        [SetUp]
        public void SetUp()
        {
            _origin = SceneManager.GetActiveScene();
            _source = new FakeSceneSource("fake", Target, Holding);
            _presenter = new RecordingPresenter();
            SceneSources.Register(_source);
            _installedPresenter = CustomSceneManager.Presenter;
            CustomSceneManager.Presenter = _presenter;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            Time.timeScale = 1f;
            CustomSceneManager.Presenter = _installedPresenter;
            CustomSceneManager.OnLoadStart = null;
            CustomSceneManager.OnLoadEnd = null;
            CustomSceneManager.OnProgressChanged = null;
            SceneSources.Unregister(_source);

            if (_origin.IsValid() && _origin.isLoaded) SceneManager.SetActiveScene(_origin);
            foreach (var scene in _source.Created)
                if (scene.IsValid() && scene.isLoaded) yield return SceneManager.UnloadSceneAsync(scene);

            if (CustomSceneManager.HasInstance) UnityEngine.Object.Destroy(CustomSceneManager.Instance.gameObject);
            yield return null;
        }

        [UnityTest]
        public IEnumerator SuccessRunsEveryStepInOrder() => UniTask.ToCoroutine(async () =>
        {
            _source.Populate = (scene, key) =>
            {
                RecordingInitializer.Add(scene, 2, _ => _presenter.Log.Add("init2"));
                RecordingInitializer.Add(scene, 1, _ => _presenter.Log.Add("init1"));
            };
            var option = Plain;
            option.postInitializeTask = () => { _presenter.Log.Add("post"); return UniTask.CompletedTask; };

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, option);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Succeeded));
            Assert.That(result.Stage, Is.EqualTo(SceneLoadStage.Complete));
            Assert.That(_presenter.Log, Is.EqualTo(new[] { "cover", "show", "prepare", "init1", "init2", "post", "hide", "reveal" }));
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(result.Scene));
            Assert.That(_source.Operations[0].Mode, Is.EqualTo(LoadSceneMode.Single));
            Assert.That(CustomSceneManager.Instance.CurrentSceneKey, Is.EqualTo(Target));
            Assert.That(CustomSceneManager.Instance.IsLoading, Is.False);
            Assert.That(_presenter.Progress[_presenter.Progress.Count - 1], Is.EqualTo(1f));
        });

        [UnityTest]
        public IEnumerator LoadEventsFireOncePerRequestAndEndAfterTheLockIsReleased() => UniTask.ToCoroutine(async () =>
        {
            int started = 0, ended = 0;
            bool loadingAtEnd = true;
            CustomSceneManager.OnLoadStart = () => started++;
            CustomSceneManager.OnLoadEnd = () => { ended++; loadingAtEnd = CustomSceneManager.Instance.IsLoading; };

            await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);

            Assert.That(started, Is.EqualTo(1));
            Assert.That(ended, Is.EqualTo(1));
            Assert.That(loadingAtEnd, Is.False);
        });

        [UnityTest]
        public IEnumerator UnknownSceneFailsBeforeTheScreenChanges() => UniTask.ToCoroutine(async () =>
        {
            LogAssert.Expect(LogType.Error, LoadFailed);

            var result = await CustomSceneManager.Instance.LoadSceneAsync("Missing", Plain);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(result.Stage, Is.EqualTo(SceneLoadStage.Validate));
            Assert.That(result.SceneChanged, Is.False);
            Assert.That(result.Exception.Message, Does.Contain("Missing").And.Contain("fake").And.Contain(BuildSceneSource.SourceId));
            Assert.That(_presenter.Log, Is.Empty);
            Assert.That(_source.Operations, Is.Empty);
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(_origin));
        });

        [UnityTest]
        public IEnumerator UnknownSceneDoesNotDisturbLoadListeners() => UniTask.ToCoroutine(async () =>
        {
            int events = 0;
            CustomSceneManager.OnLoadStart = () => events++;
            CustomSceneManager.OnLoadEnd = () => events++;
            CustomSceneManager.OnProgressChanged = _ => events++;
            LogAssert.Expect(LogType.Error, LoadFailed);

            await CustomSceneManager.Instance.LoadSceneAsync("Missing", Plain);

            Assert.That(events, Is.Zero);
        });

        [UnityTest]
        public IEnumerator ProgressOnlyRisesWithAnIntermediateScene() => UniTask.ToCoroutine(async () =>
        {
            var option = Plain;
            option.intermediateScene = Holding;

            await CustomSceneManager.Instance.LoadSceneAsync(Target, option);

            Assert.That(_presenter.Progress, Is.Ordered);
            Assert.That(_presenter.Progress[_presenter.Progress.Count - 1], Is.EqualTo(1f));
        });

        [UnityTest]
        public IEnumerator ProgressReachesTheEndBeforeTheMinimumHold() => UniTask.ToCoroutine(async () =>
        {
            float fullAt = 0f, endedAt = 0f;
            var option = Plain;
            option.minimumLoadingSeconds = 0.3f;
            CustomSceneManager.OnProgressChanged = value => { if (value >= 1f) fullAt = Time.realtimeSinceStartup; };
            CustomSceneManager.OnLoadEnd = () => endedAt = Time.realtimeSinceStartup;

            await CustomSceneManager.Instance.LoadSceneAsync(Target, option);

            Assert.That(fullAt, Is.GreaterThan(0f));
            Assert.That(endedAt - fullAt, Is.GreaterThan(0.05f));
        });

        [UnityTest]
        public IEnumerator DestroyingTheManagerEndsTheTransition() => UniTask.ToCoroutine(async () =>
        {
            _source.Gate = new UniTaskCompletionSource();
            var manager = CustomSceneManager.Instance;
            var pending = manager.LoadSceneAsync(Target, Plain);

            while (_source.Operations.Count == 0) await UniTask.Yield();
            UnityEngine.Object.Destroy(manager.gameObject);
            var result = await pending;

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Canceled));
            Assert.That(_presenter.Log, Does.Contain("reveal"));
        });

        [UnityTest]
        public IEnumerator SecondRequestIsRejectedWhileOneIsRunning() => UniTask.ToCoroutine(async () =>
        {
            _source.Gate = new UniTaskCompletionSource();
            var first = CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);

            LogAssert.Expect(LogType.Warning, new Regex("Ignored"));
            var second = await CustomSceneManager.Instance.LoadSceneAsync(Holding, Plain);
            _source.Gate.TrySetResult();
            var result = await first;

            Assert.That(second.Status, Is.EqualTo(SceneLoadStatus.Rejected));
            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Succeeded));
            Assert.That(_source.Operations.Count, Is.EqualTo(1));
        });

        [UnityTest]
        public IEnumerator LoadFailureCleansUpAndKeepsThePreviousScene() => UniTask.ToCoroutine(async () =>
        {
            _source.LoadFailure = new InvalidOperationException("broken bundle");
            LogAssert.Expect(LogType.Error, LoadFailed);

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(result.Stage, Is.EqualTo(SceneLoadStage.Load));
            Assert.That(result.SceneChanged, Is.False);
            Assert.That(result.Scene.IsValid(), Is.False);
            Assert.That(_presenter.Log, Is.EqualTo(new[] { "cover", "show", "hide", "reveal" }));
            Assert.That(CustomSceneManager.Instance.IsLoading, Is.False);
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(_origin));
        });

        [UnityTest]
        public IEnumerator InitializerFailureReportsTheStageAndAllowsTheNextRequest() => UniTask.ToCoroutine(async () =>
        {
            bool fail = true;
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 0, _ =>
            {
                if (fail) throw new InvalidOperationException("no data");
            });
            LogAssert.Expect(LogType.Error, LoadFailed);

            var failed = await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);
            fail = false;
            var retried = await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);

            Assert.That(failed.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(failed.Stage, Is.EqualTo(SceneLoadStage.Initialize));
            Assert.That(failed.SceneChanged, Is.True);
            Assert.That(retried.IsSuccess, Is.True);
        });

        [UnityTest]
        public IEnumerator PresenterCoverFailureDoesNotStopTheLoad() => UniTask.ToCoroutine(async () =>
        {
            _presenter.CoverFailure = new InvalidOperationException("no fader");
            LogAssert.Expect(LogType.Warning, new Regex("Cover failed"));

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);

            Assert.That(result.IsSuccess, Is.True);
        });

        [UnityTest]
        public IEnumerator PrepareFailureFailsTheRequest() => UniTask.ToCoroutine(async () =>
        {
            _presenter.PrepareFailure = new InvalidOperationException("no UI");
            LogAssert.Expect(LogType.Error, LoadFailed);

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(result.Stage, Is.EqualTo(SceneLoadStage.Prepare));
            Assert.That(_presenter.Log, Does.Contain("reveal"));
        });

        [UnityTest]
        public IEnumerator DataReachesTheInitializer() => UniTask.ToCoroutine(async () =>
        {
            SceneLoadContext seen = null;
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 0, context => seen = context);

            await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain, 7);

            Assert.That(seen.Key, Is.EqualTo(Target));
            Assert.That(seen.TryGetData(out int value), Is.True);
            Assert.That(value, Is.EqualTo(7));
            Assert.That(seen.TryGetData(out string _), Is.False);
        });

        [UnityTest]
        public IEnumerator InactiveObjectsAreNotInitialized() => UniTask.ToCoroutine(async () =>
        {
            int runs = 0;
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 0, _ => runs++).gameObject.SetActive(false);

            await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);

            Assert.That(runs, Is.Zero);
        });

        [UnityTest]
        public IEnumerator IntermediateSceneOpensFirstAndLeavesAfterSuccess() => UniTask.ToCoroutine(async () =>
        {
            var option = Plain;
            option.intermediateScene = Holding;

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, option);

            Assert.That(result.IsSuccess, Is.True);
            Assert.That(_source.Operations[0].Mode, Is.EqualTo(LoadSceneMode.Single));
            Assert.That(_source.Operations[1].Mode, Is.EqualTo(LoadSceneMode.Additive));
            Assert.That(_source.Operations[0].Unloaded, Is.True);
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(result.Scene));
            Assert.That(_presenter.Log, Is.EqualTo(new[] { "cover", "prepare", "show", "prepare", "hide", "reveal" }));
        });

        [UnityTest]
        public IEnumerator PrepareFailureOnTheIntermediateSceneOnlyWarns() => UniTask.ToCoroutine(async () =>
        {
            var option = Plain;
            option.intermediateScene = Holding;
            _presenter.PrepareFailure = new InvalidOperationException("no UI");
            _source.Populate = (scene, key) => { if (key == Target) _presenter.PrepareFailure = null; };
            LogAssert.Expect(LogType.Warning, new Regex("Prepare intermediate scene failed"));

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, option);

            Assert.That(result.IsSuccess, Is.True);
        });

        [UnityTest]
        public IEnumerator FailedTargetKeepsTheIntermediateScene() => UniTask.ToCoroutine(async () =>
        {
            var option = Plain;
            option.intermediateScene = Holding;
            _source.Populate = (scene, key) => _source.LoadFailure = new InvalidOperationException("broken bundle");
            LogAssert.Expect(LogType.Error, LoadFailed);

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, option);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(result.SceneChanged, Is.True);
            Assert.That(_source.Operations[0].Unloaded, Is.False);
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(_source.Created[0]));
            Assert.That(_presenter.Log, Does.Contain("reveal"));
        });

        [UnityTest]
        public IEnumerator CancelingBeforeThePostTaskSkipsItWithoutAnInitializer() => UniTask.ToCoroutine(async () =>
        {
            using var cancellation = new CancellationTokenSource();
            _presenter.OnPrepare = cancellation.Cancel;
            bool posted = false;
            var option = Plain;
            option.postInitializeTask = () => { posted = true; return UniTask.CompletedTask; };

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, option, null, cancellation.Token);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Canceled));
            Assert.That(result.Stage, Is.EqualTo(SceneLoadStage.Initialize));
            Assert.That(posted, Is.False);
            Assert.That(_presenter.Log, Does.Contain("reveal"));
        });

        [UnityTest]
        public IEnumerator CancelingDuringTheLastInitializerSkipsThePostTask() => UniTask.ToCoroutine(async () =>
        {
            using var cancellation = new CancellationTokenSource();
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 1, _ => cancellation.Cancel());
            bool posted = false;
            var option = Plain;
            option.postInitializeTask = () => { posted = true; return UniTask.CompletedTask; };

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, option, null, cancellation.Token);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Canceled));
            Assert.That(posted, Is.False);
        });

        [UnityTest]
        public IEnumerator CancelingDuringTheLoadAbandonsItAndCleansUp() => UniTask.ToCoroutine(async () =>
        {
            _source.Gate = new UniTaskCompletionSource();
            using var cancellation = new CancellationTokenSource();
            var pending = CustomSceneManager.Instance.LoadSceneAsync(Target, Plain, null, cancellation.Token);

            while (_source.Operations.Count == 0) await UniTask.Yield();
            cancellation.Cancel();
            var result = await pending;

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Canceled));
            Assert.That(result.SceneChanged, Is.False);
            Assert.That(_source.Operations[0].Abandoned, Is.True);
            Assert.That(_presenter.Log, Does.Contain("hide").And.Contain("reveal"));
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(_origin));
        });

        [UnityTest]
        public IEnumerator ALoadThatCannotStopFinishesThenReportsCanceled() => UniTask.ToCoroutine(async () =>
        {
            int runs = 0;
            _source.CanAbandon = false;
            _source.Gate = new UniTaskCompletionSource();
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 0, _ => runs++);
            using var cancellation = new CancellationTokenSource();
            var pending = CustomSceneManager.Instance.LoadSceneAsync(Target, Plain, null, cancellation.Token);

            while (_source.Operations.Count == 0) await UniTask.Yield();
            cancellation.Cancel();
            _source.Gate.TrySetResult();
            var result = await pending;

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Canceled));
            Assert.That(result.SceneChanged, Is.True);
            Assert.That(_source.Operations[0].Abandoned, Is.False);
            Assert.That(runs, Is.Zero);
        });

        [UnityTest]
        public IEnumerator PausedGameTimeDoesNotHoldTheTransition() => UniTask.ToCoroutine(async () =>
        {
            Time.timeScale = 0f;
            var option = Plain;
            option.minimumLoadingSeconds = 0.05f;

            var result = await CustomSceneManager.Instance.LoadSceneAsync(Target, option);

            Assert.That(result.IsSuccess, Is.True);
        });

        [UnityTest]
        public IEnumerator HigherPrioritySourceWinsAndSourceIdOverridesIt() => UniTask.ToCoroutine(async () =>
        {
            var higher = new FakeSceneSource("higher", Target);
            SceneSources.Register(higher, SceneSources.DefaultPriority + 1);
            try
            {
                await CustomSceneManager.Instance.LoadSceneAsync(Target, Plain);
                Assert.That(higher.Operations.Count, Is.EqualTo(1));
                Assert.That(_source.Operations, Is.Empty);

                var forced = Plain;
                forced.sourceId = _source.Id;
                await CustomSceneManager.Instance.LoadSceneAsync(Target, forced);
                Assert.That(_source.Operations.Count, Is.EqualTo(1));
            }
            finally
            {
                SceneSources.Unregister(higher);
                foreach (var scene in higher.Created) _source.Created.Add(scene);
            }
        });

        [UnityTest]
        public IEnumerator RequestWithoutOptionUsesTheDefaultOption() => UniTask.ToCoroutine(async () =>
        {
            var manager = CustomSceneManager.Instance;
            var option = Plain;
            option.loadingScreen = "from-default";
            manager.DefaultOption = option;

            await manager.LoadSceneAsync(Target);

            Assert.That(_presenter.LastOption.loadingScreen, Is.EqualTo("from-default"));
        });

#pragma warning disable CS0618 // The legacy overloads stay covered until their callers move.
        [UnityTest]
        public IEnumerator LegacyOverloadAppliesItsArguments() => UniTask.ToCoroutine(async () =>
        {
            bool posted = false;
            var manager = CustomSceneManager.Instance;
            manager.DefaultOption = Plain;

            var result = await manager.LoadSceneAsync(Target, "legacy-screen", () => { posted = true; return UniTask.CompletedTask; });

            Assert.That(result.IsSuccess, Is.True);
            Assert.That(posted, Is.True);
            Assert.That(_presenter.LastOption.loadingScreen, Is.EqualTo("legacy-screen"));
        });

        [UnityTest]
        public IEnumerator LegacyNamedPostInitializeCallStillWorks() => UniTask.ToCoroutine(async () =>
        {
            bool posted = false;
            var manager = CustomSceneManager.Instance;
            manager.DefaultOption = Plain;

            var result = await manager.LoadSceneAsync(Target, postInitializeTask: () => { posted = true; return UniTask.CompletedTask; });

            Assert.That(result.IsSuccess, Is.True);
            Assert.That(posted, Is.True);
        });
#pragma warning restore CS0618

        [UnityTest]
        public IEnumerator ReloadRunsInitializersAgainWithTheSameKey() => UniTask.ToCoroutine(async () =>
        {
            var keys = new List<string>();
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 0, context => keys.Add(context.Key));
            var manager = CustomSceneManager.Instance;
            manager.DefaultOption = Plain;

            await manager.LoadSceneAsync(Target);
            var result = await manager.ReloadActiveSceneAsync();

            Assert.That(result.IsSuccess, Is.True);
            Assert.That(keys, Is.EqualTo(new[] { Target, Target }));
        });

        [UnityTest]
        public IEnumerator AdditiveSceneLoadsWithoutVisualsAndUnloads() => UniTask.ToCoroutine(async () =>
        {
            int runs = 0, started = 0;
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 0, _ => runs++);
            CustomSceneManager.OnLoadStart = () => started++;
            var manager = CustomSceneManager.Instance;

            var loaded = await manager.LoadAdditiveAsync(Target);

            LogAssert.Expect(LogType.Warning, new Regex("Ignored"));
            var duplicate = await manager.LoadAdditiveAsync(Target);
            var unloaded = await manager.UnloadAdditiveAsync(Target);

            Assert.That(loaded.IsSuccess, Is.True);
            Assert.That(_source.Operations[0].Mode, Is.EqualTo(LoadSceneMode.Additive));
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(_origin));
            Assert.That(runs, Is.EqualTo(1));
            Assert.That(started, Is.Zero);
            Assert.That(_presenter.Log, Is.Empty);
            Assert.That(duplicate.Status, Is.EqualTo(SceneLoadStatus.Rejected));
            Assert.That(unloaded.IsSuccess, Is.True);
            Assert.That(_source.Operations[0].Unloaded, Is.True);
        });

        [UnityTest]
        public IEnumerator FailedAdditiveInitializerUnloadsTheScene() => UniTask.ToCoroutine(async () =>
        {
            _source.Populate = (scene, key) => RecordingInitializer.Add(scene, 0, _ => throw new InvalidOperationException("no data"));
            LogAssert.Expect(LogType.Error, LoadFailed);

            var result = await CustomSceneManager.Instance.LoadAdditiveAsync(Target);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(_source.Operations[0].Unloaded, Is.True);
        });

        [UnityTest]
        public IEnumerator FullSceneChangeForgetsAdditiveScenes() => UniTask.ToCoroutine(async () =>
        {
            var manager = CustomSceneManager.Instance;
            await manager.LoadAdditiveAsync(Holding);
            await manager.LoadSceneAsync(Target, Plain);

            LogAssert.Expect(LogType.Error, new Regex("Unload Failed"));
            var result = await manager.UnloadAdditiveAsync(Holding);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(result.Stage, Is.EqualTo(SceneLoadStage.Validate));
        });

        [Test]
        public void BlankSourceIdIsRefused()
        {
            Assert.That(() => SceneSources.Register(new FakeSceneSource(" ")), Throws.ArgumentException);
        }

        [UnityTest]
        public IEnumerator RegisteringTheSameIdReplacesTheSource() => UniTask.ToCoroutine(async () =>
        {
            var replacement = new FakeSceneSource(_source.Id, "Other");
            SceneSources.Register(replacement);
            try
            {
                var result = await CustomSceneManager.Instance.LoadSceneAsync("Other", Plain);

                Assert.That(result.IsSuccess, Is.True);
                Assert.That(replacement.Operations.Count, Is.EqualTo(1));
            }
            finally
            {
                SceneSources.Unregister(replacement);
                foreach (var scene in replacement.Created) _source.Created.Add(scene);
            }
        });
    }
}
