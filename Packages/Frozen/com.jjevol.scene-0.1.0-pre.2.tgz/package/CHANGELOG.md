# Changelog

## 0.1.0-pre.2 - 2026-11-07

- `postInitializeTask` no longer runs after cancellation. Without an initializer nothing checked the token at that point, and an initializer that ignored it had the same gap.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.1 — 2026-11-06

Local candidate from mobile 5bb8bcc5e4980959597ad966186e18025eb660cb `Assets/Common/Script/Scene`. `CustomSceneManager` and `SceneInitializerBase` keep their names and GUIDs. The flow itself is rewritten.

Changed from the source:

- `LoadSceneAsync` returns `UniTask<SceneLoadResult>`. `await` and `.Forget()` keep compiling, and the old string and `postInitializeTask` call shapes remain as obsolete overloads. Failures and overlapping requests are now visible to the caller.
- Build Settings scenes work with no other package. Addressable scenes move to `com.jjevol.scene.addressables`.
- No fixed `"Loading"` scene: `SceneLoadOption.intermediateScene` is opt-in. Without it the previous scene stays loaded and running until the target activates, so peak memory is both scenes. The source always swapped to `"Loading"` first.
- UI, fade and UI initialization calls move behind `ISceneTransitionPresenter`. `com.jjevol.scene.ui` will supply them.
- `CustomSceneManager` no longer derives from `PersistentSingleton`, which needs Addressables. `Instance` and `HasInstance` behave the same.
- Initializers are found by scanning the scene. `RegisterInitializer` and `UnregisterInitializer` are removed.
- A failed transition now removes the loading view and closes the fade.
- `OnLoadStart` and `OnLoadEnd` fire only for a full transition to a scene that exists, and `OnLoadEnd` fires after `IsLoading` turns false.
- A 300 ms scaled hold at 100% is replaced by unscaled `minimumLoadingSeconds`, measured from the start of the request, so time scale 0 cannot hold a transition and a slow load adds no extra wait.

Added: cancellation, scene data, additive load and unload, active scene reload, initializers for scenes opened outside a request. Opening a scene with initializers directly in the Editor now runs them, where the source did not.

PlayMode tests pass 37/37 in the Windows Editor, in a Host with only this package and UniTask. Player and device tests are NOT_RUN.
