# JJEvol Scene — local candidate

Unity 6000.3.9f1. 로컬 소스 후보이며 공식 릴리스나 고정 tarball이 아니다. Mobile/Steam Host와 소비 게임은 전환하지 않았다.

씬 전환 순서를 한곳에서 처리한다. 필요한 것은 UniTask뿐이고 Addressables, UI, URP가 없어도 동작한다. 원본은 Mobile `Assets/Common/Script/Scene`이며 클래스 이름과 GUID를 유지했다.

## 사용

설정 없이 호출하면 된다. `CustomSceneManager`는 처음 쓸 때 만들어진다.

~~~csharp
using jjevol;

var result = await CustomSceneManager.Instance.LoadSceneAsync("Battle");
if (!result.IsSuccess) Debug.Log(result.Status + " " + result.Stage);
~~~

키는 빌드 포함 씬의 이름이나 경로다. Addressable 씬은 `com.jjevol.scene.addressables`를 설치하면 같은 호출로 불러온다. 둘 다 있으면 Addressables부터 찾는다. 특정 위치를 강제하려면 `SceneLoadOption.sourceId`를 쓴다.

## 씬 초기화

`SceneInitializerBase`를 상속해 씬에 두면 된다. 등록은 필요 없다. 씬이 활성화된 뒤 활성 오브젝트에서 찾아 `Priority`가 낮은 순서로 실행한다. `ISceneInitializer`를 직접 구현해도 같다.

~~~csharp
public sealed class BattleInitializer : SceneInitializerBase
{
    public override UniTask OnInitializeAsync()
    {
        if (Context.TryGetData(out StageInfo stage)) Build(stage);
        return UniTask.CompletedTask;
    }
}

await CustomSceneManager.Instance.LoadSceneAsync("Battle", data: stageInfo);
~~~

요청을 거치지 않고 열린 씬(게임의 첫 씬, Editor에서 바로 실행한 씬, `SceneManager`로 직접 연 씬)도 초기화를 실행한다. 이때 `Context.Key`는 씬 이름이고 `Data`는 null이다. 다만 다른 요청이 진행 중일 때 직접 연 씬은 건너뛴다. 새 전환이 시작되면 이 초기화는 취소된다.

`Context`는 초기화가 실행되는 동안만 유효하다. 부팅을 거쳐야 하는 데이터가 있는 씬은 직접 실행했을 때 데이터 없음을 스스로 처리해야 한다.

## 결과

요청은 예외를 던지지 않고 `SceneLoadResult`를 돌려준다.

| Status | 뜻 |
|---|---|
| `Succeeded` | 전환 완료 |
| `Failed` | `Stage`까지 진행하다 실패. 원인은 `Exception`, 로그도 남는다 |
| `Rejected` | 다른 씬 작업이 진행 중이라 아무것도 하지 않음 |
| `Canceled` | 토큰 취소 또는 매니저 파괴 |

- 없는 키는 화면을 바꾸기 전에 `Validate` 단계에서 실패한다. 이 경우 `OnLoadStart`, `OnLoadEnd`, 진행률 알림은 나가지 않는다.
- `OnLoadStart`와 `OnLoadEnd`는 전체 전환에만 나간다. `LoadAdditiveAsync`에서는 나가지 않는다.
- `SceneChanged`가 false면 이전 씬이 그대로 남아 있다.
- 실패 후 재시도나 타이틀 복귀는 게임이 정한다. 중간 씬을 쓰다 대상 로드가 실패하면 중간 씬이 남는다.

## 옵션

| 설정 | 동작 |
|---|---|
| 옵션 없음 | `DefaultOption` 사용 |
| `SceneLoadOption.Loading()` | 로딩 화면 |
| `SceneLoadOption.WhiteFade()` | 페이드만 |
| `SceneLoadOption.Direct()` | 연출 없음 |
| `intermediateScene` | 대상 로드 전에 이 씬으로 먼저 교체해 이전 씬 메모리를 비움. 기본은 사용 안 함 |
| `minimumLoadingSeconds` | 최소 표시 시간(unscaled). 표시 담당이 없으면 무시 |
| `unloadUnusedAssets` | 로드 전 미사용 에셋 정리. 기본 true |

게임 전체 기본값은 시작할 때 `CustomSceneManager.Instance.DefaultOption`으로 정한다.

`intermediateScene`을 쓰지 않으면 대상 씬이 준비될 때까지 이전 씬이 메모리에 남고 그 씬의 로직도 계속 돈다. 메모리 피크는 이전 씬과 새 씬의 합이 된다. 씬이 무겁거나 전환 중 이전 씬이 멈춰야 하는 게임은 중간 씬을 지정한다.

## 그 외 호출

~~~csharp
await manager.ReloadActiveSceneAsync();          // 현재 씬 재로드, 초기화도 다시 실행
await manager.LoadAdditiveAsync("Stage3", data); // 연출 없이 위에 추가. 활성 씬은 그대로
await manager.UnloadAdditiveAsync("Stage3");
~~~

추가한 씬은 다음 전체 전환 때 함께 닫힌다.

## 화면 표시

UI 연결은 `com.jjevol.scene.ui`가 맡는다. 자체 로딩 화면을 쓰려면 `SceneTransitionPresenter`에서 필요한 단계만 재정의한다.

~~~csharp
public sealed class MyLoading : SceneTransitionPresenter
{
    public override void SetProgress(float progress) => slider.value = progress;
}

CustomSceneManager.Presenter = new MyLoading();
~~~

표시 단계의 실패는 경고만 남기고 전환을 계속한다. 요청한 씬의 `PrepareSceneAsync` 실패만 요청 실패로 처리한다. 이 메서드는 중간 씬에서도 호출되며, 그때 실패는 경고로 끝난다.

## 소스 추가

`ISceneSource`를 구현해 `SceneSources.Register`로 등록한다. 우선순위가 높은 소스부터 찾고, 같은 Id는 교체한다. 기본 우선순위는 100, 빌드 소스는 0이다. 패키지가 자동 등록할 때는 `RuntimeInitializeLoadType.BeforeSceneLoad`를 쓴다. 목록이 `SubsystemRegistration`에서 초기화되기 때문이다.

## 제약

- `SceneManager`로 시작한 Single 로드는 멈출 수 없다. 취소해도 대상 씬까지 활성화한 뒤 초기화를 건너뛰고 `Canceled`를 돌려준다.
- 빌드 소스의 Additive 로드를 취소하면 씬을 활성화한 뒤 내린다. 그 사이 `Awake`가 실행될 수 있다.

## 시험

`Tests/Runtime`은 PlayMode 시험이다. `BuildSceneSourceTests`는 실행 중 임시 씬을 Build Settings에 추가하고 끝나면 지운다.
