using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace jjevol
{
    public sealed class TableBuildRecoveryException : IOException
    {
        public TableBuildRecoveryException() : this(null) { }
        internal TableBuildRecoveryException(Exception cause) : base("Table build requires explicit recovery. No further build may overwrite the uncertain outputs.", cause) { }
    }

    /// <summary>One generated file that no longer matches the last recorded build.</summary>
    public sealed class TableFileDifference
    {
        public string Table { get; }
        public string Path { get; }
        public string Reason { get; }
        /// <summary>Why this file cannot become the new baseline. Empty when it can.</summary>
        public string Blocker { get; internal set; } = "";
        public bool CanAccept => Blocker.Length == 0;
        /// <summary>This file can be rebuilt with <see cref="TableBuilder.RegenerateCode"/>.</summary>
        public bool CanRegenerate { get; internal set; }
        internal bool IsCode => FullPath.EndsWith(".cs", StringComparison.Ordinal) || FullPath.EndsWith(".cs.meta", StringComparison.Ordinal);
        internal readonly string FullPath, Hash;
        internal TableFileDifference(string table, string path, string reason, string hash)
        { Table = table; FullPath = path; Path = TablePaths.Relative(path); Reason = reason; Hash = hash; }
        public override string ToString() => Path + ": " + Reason + (CanAccept ? "" : " (" + Blocker + ")");
    }

    public sealed class TablePreparedBuild
    {
        public TableBuildPlan Plan { get; }
        public bool IsNoOp { get; }
        public IReadOnlyList<string> OutputHashes { get; }
        public TableBuildState State { get; private set; } = TableBuildState.Prepared;
        public bool RequiresCompilation { get; }
        internal readonly TableManifest Result;
        internal readonly List<TableJournalEntry> Entries;
        private bool _applied;
        // Instance-scoped IO boundary: production uses flushed same-volume replacement, never source deletion fallback.
        internal Action<string, byte[]> WriteFile = TableFiles.AtomicWrite;
        internal Action<string, byte[], string> WriteCheckpoint = TableFiles.Checkpoint;
        internal TablePreparedBuild(TableBuildPlan plan)
        {
            plan.EnsureFresh(); Plan = plan; Result = plan.Basis.Copy(); Result.status = "Ready"; Result.journal = "";
            Entries = new List<TableJournalEntry>();
            foreach (TableOutputChange change in plan.Changes)
            {
                if (change.Action == TableOutputAction.Delete)
                {
                    Result.tables.RemoveAll(t => string.Equals(t.name, change.TableName, StringComparison.OrdinalIgnoreCase));
                    Add(change.Path, null); Add(change.Path + ".meta", null); continue;
                }
                if (change.Action == TableOutputAction.Conflict) throw new InvalidOperationException("Unmanaged conflict.");
                string plain = change.Document.RuntimeText;
                byte[] bytes;
                bool reuse = change.Action == TableOutputAction.Unchanged;
                if (change.Action == TableOutputAction.Adopt && File.Exists(change.Path))
                {
                    try { reuse = TableHash.SameContent(TableBuilder.Decode(File.ReadAllBytes(change.Path), plan.Request.UseEncrypt, plan.Decrypt), plain); } catch { reuse = false; }
                }
                if (reuse) bytes = File.ReadAllBytes(change.Path);
                else
                {
                    string contents = plain;
                    if (plan.Request.UseEncrypt)
                    {
                        byte[] source = Encoding.UTF8.GetBytes(plain), encoded;
                        try
                        {
                            byte[] result = plan.Encrypt((byte[])source.Clone());
                            encoded = result == null ? null : (byte[])result.Clone();
                            if (encoded == null || encoded.Length == 0 || !source.SequenceEqual(plan.Decrypt((byte[])encoded.Clone()))) throw new InvalidDataException();
                        }
                        catch (Exception e) { throw new InvalidDataException("Host codec round-trip failed (" + e.GetType().Name + "); no outputs were applied."); }
                        contents = Convert.ToBase64String(encoded);
                    }
                    bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(contents)).ToArray();
                }
                if (!TableHash.SameContent(TableBuilder.Decode(bytes, plan.Request.UseEncrypt, plan.Decrypt), plain)) throw new InvalidDataException("Prepared output differs from the validated plaintext.");
                byte[] meta = File.Exists(change.Path + ".meta") ? File.ReadAllBytes(change.Path + ".meta") : NewMeta();
                string guid = ReadGuid(meta);
                if (guid.Length != 32 || !guid.All(Uri.IsHexDigit)) throw new InvalidDataException("Output meta has no valid GUID; explicit repair is required.");
                Add(change.Path, bytes); Add(change.Path + ".meta", meta);
                Result.tables.RemoveAll(t => string.Equals(t.name, change.TableName, StringComparison.OrdinalIgnoreCase));
                Result.tables.Add(new TableManagedRecord { name = change.TableName, hash = TableHash.Content(bytes), metaHash = TableHash.Content(meta), guid = guid,
                    plainHash = TableHash.Content(plain), sourceHash = change.Document.Input.RawHash,
                    source = change.Document.Input.FilePath == null ? "pasted-text" : change.Document.Input.FilePath.StartsWith(TablePaths.Project + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ? TablePaths.Relative(change.Document.Input.FilePath) : "external-file:" + Path.GetFileName(change.Document.Input.FilePath) + "#" + TableHash.Text(change.Document.Input.FilePath),
                    sourceKind = change.Document.Input.Kind.ToString(), encrypted = plan.Request.UseEncrypt, codec = plan.CodecVersion });
            }
            if (plan.ConsumeTypes != null)
            {
                Result.consume = JsonUtility.FromJson<ConsumeCodeRecord>(JsonUtility.ToJson(plan.ConsumeTypes.Record));
                Result.hasConsume = true;
                Result.version = 2; // Legacy Authoring must reject code-owning manifests instead of ignoring C# outputs.
                string[] sources = { plan.ConsumeTypes.EnumSource, plan.ConsumeTypes.ExtensionsSource };
                string[] paths = ConsumeTypesCodeGenerator.Paths(Result.consume);
                for (int i = 0; i < paths.Length; i++)
                {
                    string path = paths[i]; byte[] bytes = new UTF8Encoding(false, true).GetBytes(sources[i]);
                    // A CRLF checkout of the same source needs no rewrite and no recompile.
                    if (TablePaths.HashContent(path) == TableHash.Content(bytes)) bytes = File.ReadAllBytes(path);
                    byte[] meta = File.Exists(path + ".meta") ? File.ReadAllBytes(path + ".meta") : NewMeta(true);
                    string guid = ReadGuid(meta);
                    if (guid.Length != 32 || !guid.All(Uri.IsHexDigit)) throw new InvalidDataException("Generated source meta has no valid GUID.");
                    Add(path, bytes); Add(path + ".meta", meta);
                    Result.consume.files.Add(new ConsumeCodeFile { name = Path.GetFileName(path), hash = TableHash.Content(bytes), metaHash = TableHash.Content(meta), guid = guid });
                }
                ConsumeTypesCodeGenerator.ValidateRecord(Result.consume);
            }
            Result.tables = Result.tables.OrderBy(t => t.name, StringComparer.Ordinal).ToList();
            RequiresCompilation = Result.consume != null && Entries.Any(e => e.path.EndsWith(".cs", StringComparison.Ordinal));
            IsNoOp = Entries.Count == 0 && TableHash.Bytes(Result.Bytes()) == plan.ManifestHash;
            if (!IsNoOp)
            {
                // These working files are needed only for a mutating Apply. Fixed-width IDs let
                // preparation check the exact length without creating a journal or staging file.
                TablePaths.RequireWindowsFile(TablePaths.Lock(plan.ManifestPath));
                string id = new string('0', 32);
                string journal = TableFiles.JournalDirectory(plan.OutputDirectory, id);
                TablePaths.RequireWindowsFile(Path.Combine(journal, "journal.json"));
                if (RequiresCompilation) TablePaths.RequireWindowsFile(Path.Combine(journal, "compile-failed.json"));
                TablePaths.RequireWindowsFile(Path.Combine(TablePaths.Project, "Library", "JJEvol", "TableAuthoring", "Atomic", ".jjevol-" + id + ".tmp"));
            }
            OutputHashes = Array.AsReadOnly(Result.tables.Select(t => t.name + ": " + t.hash + " / GUID " + t.guid)
                .Concat(Result.consume?.files.Select(f => f.name + ": " + f.hash + " / GUID " + f.guid) ?? Array.Empty<string>()).ToArray());
            plan.EnsureFresh();
        }
        internal static byte[] NewMeta(bool code = false, string guid = null) => new UTF8Encoding(false).GetBytes("fileFormatVersion: 2\nguid: " + (guid ?? Guid.NewGuid().ToString("N")) +
            (code ? "\nMonoImporter:\n  externalObjects: {}\n  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {instanceID: 0}\n" : "\nTextScriptImporter:\n  externalObjects: {}\n") + "  userData: \n  assetBundleName: \n  assetBundleVariant: \n");
        private static string ReadGuid(byte[] meta) => Encoding.UTF8.GetString(meta).Split('\n').FirstOrDefault(l => l.StartsWith("guid: ", StringComparison.Ordinal))?.Substring(6).Trim() ?? "";
        private void Add(string path, byte[] next)
        {
            var entry = TableFiles.Entry(path, next);
            if (entry != null) Entries.Add(entry);
        }
        public TableBuildResult Apply()
        {
            if (_applied) throw new InvalidOperationException("This prepared build was already applied.");
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) throw new InvalidOperationException("Apply requires an idle Editor outside PlayMode/compilation.");
            Plan.EnsureFresh();
            if (Plan.Basis.consume != null && TableCompilation.Status(Plan.OutputDirectory).State != TableBuildState.Ready)
                throw new InvalidOperationException("The preceding generated assembly must be compiled and verified before another Apply.");
            // A Host delegate may retain the same identity while its captured codec configuration changes.
            foreach (var change in Plan.Changes.Where(c => c.Document != null))
            {
                var staged = Entries.FirstOrDefault(e => e.path == TablePaths.Relative(change.Path));
                byte[] bytes = staged == null ? File.ReadAllBytes(change.Path) : Convert.FromBase64String(staged.newData);
                try { if (!TableHash.SameContent(TableBuilder.Decode(bytes, Plan.Request.UseEncrypt, Plan.Decrypt), change.Document.RuntimeText)) throw new InvalidDataException(); }
                catch (Exception e) { throw new InvalidDataException("Prepared output no longer passes the current Host decoder (" + e.GetType().Name + "); no files were applied."); }
            }
            Plan.EnsureFresh();
            if (IsNoOp) { _applied = true; State = TableBuildState.Ready; return BuildResult(true); }
            TableFiles.Commit(Plan.OutputDirectory, Plan.ManifestPath, Plan.ManifestHash, Entries, Result, RequiresCompilation, Plan.EnsureFresh, WriteFile, WriteCheckpoint, state => State = state);
            _applied = true;
            return BuildResult(false);
        }
        private TableBuildResult BuildResult(bool noOp) => new TableBuildResult(Plan.Changes.Where(c => c.Action != TableOutputAction.Delete).Select(c => c.Path)
            .Concat(Plan.ConsumeTypes == null ? Array.Empty<string>() : ConsumeTypesCodeGenerator.Paths(Result.consume)).ToList(),
            Plan.Changes.Count(c => c.Action == TableOutputAction.Delete), noOp, State);
    }

    [Serializable] internal sealed class TableJournalEntry
    {
        public string path, oldData, newData, oldHash, newHash;
    }
    [Serializable] internal sealed class TableJournal
    {
        public int version = 1;
        public string id, output, manifest, originalManifest, originalManifestHash, resultManifest, markerHash;
        public List<TableJournalEntry> entries;
        // Files that already differed from the original manifest when this journal began. Only code regeneration has any.
        public List<string> knownDifferences = new List<string>();
        internal static TableJournal Parse(string text)
        {
            var value = JsonUtility.FromJson<TableJournal>(text);
            // Null inline strings round-trip as "". Only the explicit missing hash permits null;
            // real zero-byte files retain their empty Base64 payload and non-missing hash.
            if (value != null)
            {
                if (value.originalManifestHash == "missing" && string.IsNullOrEmpty(value.originalManifest)) value.originalManifest = null;
                if (value.entries != null)
                    foreach (var entry in value.entries.Where(e => e != null))
                    {
                        if (entry.oldHash == "missing" && string.IsNullOrEmpty(entry.oldData)) entry.oldData = null;
                        if (entry.newHash == "missing" && string.IsNullOrEmpty(entry.newData)) entry.newData = null;
                    }
            }
            return value;
        }
        internal byte[] Bytes() => new UTF8Encoding(false, true).GetBytes(JsonUtility.ToJson(this, true));
    }
    [Serializable] internal sealed class TablePending
    {
        public int version = 1;
        public string output, journal;
        internal byte[] Bytes() => new UTF8Encoding(false, true).GetBytes(JsonUtility.ToJson(this));
    }
    internal static class TableFiles
    {
        internal static TableJournalEntry Entry(string path, byte[] next)
        {
            byte[] old = File.Exists(path) ? File.ReadAllBytes(path) : null;
            if ((old == null && next == null) || (old != null && next != null && old.SequenceEqual(next))) return null;
            return new TableJournalEntry { path = TablePaths.Relative(path), oldData = old == null ? null : Convert.ToBase64String(old), newData = next == null ? null : Convert.ToBase64String(next),
                oldHash = old == null ? "missing" : TableHash.Bytes(old), newHash = next == null ? "missing" : TableHash.Bytes(next) };
        }
        // The one writing transaction: journal, pending marker, verified writes, checkpoint. `check` runs once the gate is held.
        internal static void Commit(string output, string manifestPath, string manifestHash, List<TableJournalEntry> entries, TableManifest result, bool compile, Action check,
            Action<string, byte[]> write, Action<string, byte[], string> checkpoint, Action<TableBuildState> report, List<string> knownDifferences = null)
        {
            string metadataDirectory = Path.GetDirectoryName(manifestPath); TablePaths.NoReparse(metadataDirectory); Directory.CreateDirectory(metadataDirectory);
            using var gate = TablePaths.Gate(manifestPath);
            check?.Invoke();
            var journal = new TableJournal
            {
                version = result.hasConsume ? 2 : 1,
                output = TablePaths.Relative(output), manifest = TablePaths.Relative(manifestPath), originalManifest = File.Exists(manifestPath) ? Convert.ToBase64String(File.ReadAllBytes(manifestPath)) : null,
                originalManifestHash = manifestHash, entries = entries, resultManifest = Convert.ToBase64String(result.Bytes()), knownDifferences = knownDifferences ?? new List<string>()
            };
            string journalDirectory = JournalDirectory(output, Guid.NewGuid().ToString("N"));
            TablePaths.NoReparse(journalDirectory); Directory.CreateDirectory(journalDirectory);
            string journalPath = Path.Combine(journalDirectory, "journal.json");
            journal.id = TablePaths.Relative(journalPath);
            result.status = compile ? "AppliedAwaitingCompile" : "Ready";
            result.journal = compile ? journal.id : "";
            journal.resultManifest = Convert.ToBase64String(result.Bytes());
            var pending = new TablePending { output = journal.output, journal = journal.id };
            byte[] pendingBytes = pending.Bytes(); journal.markerHash = TableHash.Bytes(pendingBytes);
            // The complete recovery record is immutable; do not create then immediately replace it.
            AtomicWrite(journalPath, journal.Bytes());
            // A separate create-only marker protects a potentially torn metadata checkpoint.
            // This is the primary checkpoint protocol, not an exception fallback for File.Replace.
            CreatePending(manifestPath + ".pending", pendingBytes);
            if (compile) TableCompilation.ExpectCompile(); // Before the writes: Refresh can compile synchronously.
            bool editing = false;
            report(TableBuildState.Applying);
            try
            {
                AssetDatabase.DisallowAutoRefresh(); AssetDatabase.StartAssetEditing(); editing = true;
                foreach (TableJournalEntry entry in entries)
                {
                    string path = EntryPath(journal, entry);
                    if (TablePaths.HashFile(path) != entry.oldHash) throw new IOException("Output changed during Apply.");
                    if (entry.newData == null) File.Delete(path);
                    else { Directory.CreateDirectory(Path.GetDirectoryName(path)); write(path, Convert.FromBase64String(entry.newData)); }
                    if (TablePaths.HashFile(path) != entry.newHash) throw new IOException("Output write could not be verified.");
                }
                AssetDatabase.StopAssetEditing(); AssetDatabase.AllowAutoRefresh(); editing = false;
                AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
                foreach (TableJournalEntry entry in entries) if (TablePaths.HashFile(EntryPath(journal, entry)) != entry.newHash) throw new IOException("Output/meta changed on import; recovery is required.");
                if (!VerifyManifest(result)) throw new IOException("Complete output/meta generation could not be verified.");
                checkpoint(manifestPath, result.Bytes(), journal.originalManifestHash);
                if (TablePaths.HashFile(manifestPath) != TableHash.Bytes(result.Bytes())) throw new IOException("Manifest write was not confirmed.");
                foreach (TableJournalEntry entry in entries) if (TablePaths.HashFile(EntryPath(journal, entry)) != entry.newHash) throw new IOException("Output changed during checkpoint.");
                if (!VerifyManifest(result)) throw new IOException("Complete generation changed during checkpoint.");
                if (TablePaths.HashFile(manifestPath + ".pending") != journal.markerHash) throw new IOException("Pending marker changed during Apply.");
                if (!compile)
                {
                    File.Delete(manifestPath + ".pending");
                    if (File.Exists(manifestPath + ".pending")) throw new IOException("Commit marker removal was not confirmed.");
                }
                report(compile ? TableBuildState.AppliedAwaitingCompile : TableBuildState.Ready);
                if (compile) TableCompilation.Request();
            }
            catch (Exception failure)
            {
                if (editing) { AssetDatabase.StopAssetEditing(); AssetDatabase.AllowAutoRefresh(); editing = false; }
                if (!Restore(journal, manifestPath, write)) { report(TableBuildState.RecoveryRequired); throw new TableBuildRecoveryException(failure); }
                report(TableBuildState.Restored);
                throw;
            }
            finally { if (editing) { AssetDatabase.StopAssetEditing(); AssetDatabase.AllowAutoRefresh(); } }
        }
        internal static string JournalDirectory(string output, string id)
            => Path.Combine(TablePaths.Project, "Library", "JJEvol", "TableAuthoring", TableHash.Text(TablePaths.Relative(output)), id);
        internal static void CreatePending(string path, byte[] bytes)
        {
            TablePaths.NoReparse(path);
            using var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
            stream.Write(bytes, 0, bytes.Length); stream.Flush(true);
        }
        internal static void Checkpoint(string path, byte[] bytes, string expectedHash)
        {
            TablePaths.NoReparse(path);
            using var stream = new FileStream(path, expectedHash == "missing" ? FileMode.CreateNew : FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            if (expectedHash != "missing")
            {
                byte[] existing = new byte[checked((int)stream.Length)]; int offset = 0;
                while (offset < existing.Length) { int read = stream.Read(existing, offset, existing.Length - offset); if (read == 0) throw new IOException("Incomplete checkpoint read."); offset += read; }
                if (TableHash.Bytes(existing) != expectedHash) throw new IOException("Foreign metadata change; checkpoint was not overwritten.");
            }
            stream.Position = 0; stream.SetLength(0); stream.Write(bytes, 0, bytes.Length); stream.Flush(true);
        }
        internal static string EntryPath(TableJournal journal, TableJournalEntry entry)
        {
            string root = TablePaths.Output(Path.Combine(TablePaths.Project, journal.output));
            string full = Path.GetFullPath(Path.Combine(TablePaths.Project, entry.path));
            var result = TableManifest.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(journal.resultManifest)));
            var original = journal.originalManifest == null ? null : TableManifest.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(journal.originalManifest)));
            if (new[] { result?.consume, original?.consume }.Where(c => c != null).SelectMany(ConsumeTypesCodeGenerator.Paths).Any(p => string.Equals(p, full, StringComparison.OrdinalIgnoreCase) || string.Equals(p + ".meta", full, StringComparison.OrdinalIgnoreCase)))
            { TablePaths.NoReparse(full); return full; }
            if (!full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || Path.GetDirectoryName(full) != root || (!full.EndsWith(".txt", StringComparison.OrdinalIgnoreCase) && !full.EndsWith(".txt.meta", StringComparison.OrdinalIgnoreCase)))
                throw new InvalidDataException("Journal path escapes its managed table root.");
            TablePaths.NoReparse(full); return full;
        }
        internal static void AtomicWrite(string path, byte[] bytes)
        {
            TablePaths.NoReparse(path); string directory = Path.GetDirectoryName(Path.GetFullPath(path)); Directory.CreateDirectory(directory);
            // Crash leftovers must never become imported/shipped Resources Assets.
            string temporary = Path.Combine(TablePaths.Project, "Library", "JJEvol", "TableAuthoring", "Atomic");
            TablePaths.NoReparse(temporary);
            if (!string.Equals(Path.GetPathRoot(temporary), Path.GetPathRoot(path), StringComparison.OrdinalIgnoreCase)) throw new IOException("Staging and target must share a volume.");
            Directory.CreateDirectory(temporary);
            string temp = Path.Combine(temporary, ".jjevol-" + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { stream.Write(bytes, 0, bytes.Length); stream.Flush(true); }
                if (File.Exists(path)) Replace(temp, path, (source, destination) => File.Replace(source, destination, null), System.Threading.Thread.Sleep); else File.Move(temp, path);
            }
            catch (IOException e)
            {
                throw new IOException("Table Authoring file operation failed at " + TablePaths.Relative(path) + " (HRESULT 0x" + e.HResult.ToString("X8") + "). No fallback was attempted.", e);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
        // Windows refuses File.Replace with ERROR_UNABLE_TO_REMOVE_REPLACED while another process still holds the destination.
        // On-access scanning of a file closed moments earlier does this; both files then keep their original names.
        // Only that error waits and repeats the same replacement within a short budget. Nothing is deleted or moved instead,
        // other errors (a sharing violation included) are not repeated, and the last error is thrown once the budget is spent.
        internal const int ReplacedFileBusy = unchecked((int)0x80070497);
        internal const int ReplaceWaitBudgetMilliseconds = 2000;
        internal static void Replace(string temp, string path, Action<string, string> replace, Action<int> wait)
        {
            int waited = 0, delay = 10;
            while (true)
            {
                try { replace(temp, path); return; }
                catch (IOException e) when (e.HResult == ReplacedFileBusy && waited < ReplaceWaitBudgetMilliseconds && File.Exists(temp) && File.Exists(path))
                {
                    int step = Math.Min(delay, ReplaceWaitBudgetMilliseconds - waited);
                    wait(step); waited += step; delay = Math.Min(delay * 2, 250);
                }
            }
        }
        internal static bool Restore(TableJournal journal, string manifest, Action<string, byte[]> writer)
        {
            try
            {
                // Check every Asset before restoring any. A foreign writer's bytes are never overwritten.
                foreach (var entry in journal.entries)
                {
                    string hash = TablePaths.HashFile(EntryPath(journal, entry));
                    if (hash != entry.oldHash && hash != entry.newHash) return false;
                    VerifyData(entry.oldData, entry.oldHash); VerifyData(entry.newData, entry.newHash);
                }
                string manifestHash = TablePaths.HashFile(manifest);
                if (manifestHash != journal.originalManifestHash && !IsResultManifest(journal, manifestHash)) return false;
                if (TablePaths.HashFile(manifest + ".pending") != journal.markerHash) return false;
                AssetDatabase.DisallowAutoRefresh(); AssetDatabase.StartAssetEditing();
                try
                {
                    foreach (var entry in journal.entries.AsEnumerable().Reverse())
                    {
                        string path = EntryPath(journal, entry), hash = TablePaths.HashFile(path);
                        if (hash == entry.oldHash) continue;
                        if (hash != entry.newHash) return false;
                        if (entry.oldData == null) File.Delete(path); else writer(path, Convert.FromBase64String(entry.oldData));
                        if (TablePaths.HashFile(path) != entry.oldHash) return false;
                    }
                }
                finally { AssetDatabase.StopAssetEditing(); AssetDatabase.AllowAutoRefresh(); }
                VerifyData(journal.originalManifest, journal.originalManifestHash);
                manifestHash = TablePaths.HashFile(manifest);
                if (manifestHash != journal.originalManifestHash && !IsResultManifest(journal, manifestHash)) return false;
                if (manifestHash != journal.originalManifestHash)
                {
                    if (journal.originalManifest == null) File.Delete(manifest); else Checkpoint(manifest, Convert.FromBase64String(journal.originalManifest), manifestHash);
                }
                // Refresh can import changed meta; do not clear recovery state until the WHOLE original
                // generation is checked again, including unchanged managed files absent from entries.
                AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
                foreach (var entry in journal.entries) if (TablePaths.HashFile(EntryPath(journal, entry)) != entry.oldHash) return false;
                if (TablePaths.HashFile(manifest) != journal.originalManifestHash) return false;
                if (journal.originalManifest != null)
                {
                    var original = TableManifest.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(journal.originalManifest)));
                    if (original == null || (original.version != 1 && original.version != 2) || original.output != journal.output || original.tables == null) return false;
                    if (journal.knownDifferences.Count == 0 ? !VerifyManifest(original) : Differences(original).Any(d => !journal.knownDifferences.Contains(d.Path))) return false;
                }
                if (TablePaths.HashFile(manifest + ".pending") != journal.markerHash) return false;
                File.Delete(manifest + ".pending");
                return !File.Exists(manifest + ".pending");
            }
            catch (Exception e)
            {
                Exception cause = e; while (cause.InnerException != null) cause = cause.InnerException;
                Debug.LogWarning("[Table Authoring] Recovery stopped (" + cause.GetType().Name + ", HRESULT 0x" + cause.HResult.ToString("X8") + "). Pending state is retained; no success was reported.");
                return false;
            }
        }
        private static void VerifyData(string data, string hash)
        { if ((data == null ? "missing" : TableHash.Bytes(Convert.FromBase64String(data))) != hash) throw new InvalidDataException("Recovery backup hash mismatch."); }
        internal static bool Recover(string output)
        {
            output = TablePaths.Output(output); string manifestPath = TablePaths.Manifest(output); TablePaths.NoReparse(manifestPath);
            if (!File.Exists(manifestPath) && !File.Exists(manifestPath + ".pending")) return true;
            using var gate = TablePaths.Gate(manifestPath);
            if (!File.Exists(manifestPath + ".pending"))
            {
                TableManifest ready = TableManifest.Read(manifestPath, output);
                return ready.status == "Ready" && VerifyManifest(ready);
            }
            TablePending marker;
            try { TablePaths.NoReparse(manifestPath + ".pending"); marker = JsonUtility.FromJson<TablePending>(File.ReadAllText(manifestPath + ".pending")); }
            catch { return false; }
            if (marker == null || marker.version != 1 || marker.output != TablePaths.Relative(output) || string.IsNullOrEmpty(marker.journal)) return false;
            string path = Path.GetFullPath(Path.Combine(TablePaths.Project, marker.journal));
            string journalRoot = Path.Combine(TablePaths.Project, "Library", "JJEvol", "TableAuthoring") + Path.DirectorySeparatorChar;
            if (!path.StartsWith(journalRoot, StringComparison.OrdinalIgnoreCase) || !File.Exists(path)) return false;
            TablePaths.NoReparse(path);
            TableJournal journal;
            try { journal = TableJournal.Parse(File.ReadAllText(path)); }
            catch { return false; }
            if (journal == null || (journal.version != 1 && journal.version != 2) || journal.entries == null || journal.output != TablePaths.Relative(output) || journal.manifest != TablePaths.Relative(manifestPath) || journal.id != TablePaths.Relative(path)) return false;
            return Restore(journal, manifestPath, AtomicWrite);
        }
        internal static bool IsResultManifest(TableJournal journal, string hash)
        {
            byte[] bytes = Convert.FromBase64String(journal.resultManifest);
            if (hash == TableHash.Bytes(bytes)) return true;
            var result = TableManifest.Parse(Encoding.UTF8.GetString(bytes));
            if (result.status != "AppliedAwaitingCompile" || result.consume == null) return false;
            result.status = "Ready"; result.journal = "";
            return hash == TableHash.Bytes(result.Bytes());
        }
        internal static bool VerifyManifest(TableManifest manifest)
        {
            if (manifest == null || (manifest.version != 1 && (manifest.version != 2 || !manifest.hasConsume)) || manifest.hasConsume != (manifest.consume != null) || manifest.tables == null) return false;
            return Differences(manifest).Count == 0;
        }
        internal static IEnumerable<TableFileDifference> Compare(string table, string path, string hash, string metaHash, string guid)
        {
            string content = TablePaths.HashContent(path), meta = TablePaths.HashContent(path + ".meta"), id = TablePaths.Guid(path + ".meta");
            if (content != hash) yield return new TableFileDifference(table, path, content == "missing" ? "파일이 없습니다" : "내용이 마지막 빌드 기록과 다릅니다", content);
            if (meta != metaHash || id != guid)
                yield return new TableFileDifference(table, path + ".meta", meta == "missing" ? ".meta 파일이 없습니다" : id != guid ? "GUID가 달라졌습니다. 이 파일을 참조하는 곳이 끊길 수 있습니다" : ".meta 내용이 달라졌습니다", meta);
        }
        internal static List<TableFileDifference> Differences(TableManifest manifest)
        {
            var differences = new List<TableFileDifference>();
            string root = TablePaths.Output(Path.Combine(TablePaths.Project, manifest.output));
            foreach (var record in manifest.tables)
            {
                string path = TablePaths.RecordPath(root, record); TablePaths.NoReparse(path); TablePaths.NoReparse(path + ".meta");
                differences.AddRange(Compare(record.name, path, record.hash, record.metaHash, record.guid));
            }
            if (manifest.consume != null)
            {
                ConsumeTypesCodeGenerator.ValidateRecord(manifest.consume);
                foreach (string path in ConsumeTypesCodeGenerator.Paths(manifest.consume))
                {
                    var file = manifest.consume.files.Single(f => f.name == Path.GetFileName(path)); TablePaths.NoReparse(path); TablePaths.NoReparse(path + ".meta");
                    differences.AddRange(Compare(file.name, path, file.hash, file.metaHash, file.guid));
                }
            }
            return differences;
        }
        private static List<string> Problems(TableManifest manifest)
        {
            if (manifest.status != "Ready") return new List<string> { manifest.output + ": 빌드 기록 상태가 " + manifest.status + "입니다" };
            var found = Differences(manifest).Select(d => d.ToString()).ToList();
            return found.Count != 0 ? found : new List<string> { manifest.output + ": 빌드 기록 형식이 올바르지 않습니다" };
        }
        internal static string Describe(TableManifest manifest) => string.Join("; ", Problems(manifest));
        internal static TableDocument ReadApplied(string path, TableManagedRecord record, Func<byte[], byte[]> decrypt)
        {
            var document = TableDocument.Parse(TableInput.Snapshot(record.name, TableBuilder.Decode(File.ReadAllBytes(path), record.encrypted, decrypt), TableDialect.PlainTsv, TableInputKind.AppliedOutput, "applied:" + record.name));
            return document.IsValid ? document : throw new InvalidDataException("Applied table is not readable.");
        }
        // Differences plus what stops each file from becoming the baseline.
        private static List<TableFileDifference> Review(TableManifest manifest)
        {
            var differences = Differences(manifest);
            foreach (var difference in differences)
            {
                bool meta = difference.FullPath.EndsWith(".meta", StringComparison.Ordinal);
                string file = meta ? difference.FullPath.Substring(0, difference.FullPath.Length - 5) : difference.FullPath;
                bool code = file.EndsWith(".cs", StringComparison.Ordinal);
                if (!meta)
                {
                    // The record must describe the deterministic source, so an edited file cannot become the baseline.
                    if (code) difference.Blocker = RegenerateHint;
                    else if (difference.Hash != "missing")
                        try { ReadApplied(file, manifest.tables.Single(t => t.name == difference.Table), TableRuntimeOptions.DecryptBytes); }
                        catch { difference.Blocker = "표로 읽을 수 없습니다. 파일 내용과 복호화 설정을 확인하세요"; }
                }
                else if (code || File.Exists(file))
                {
                    string guid = TablePaths.Guid(difference.FullPath);
                    if (difference.Hash == "missing") difference.Blocker = code ? RegenerateHint : "Unity가 파일을 다시 가져와 .meta를 만든 뒤 시도하세요";
                    else if (!ValidGuid(guid)) difference.Blocker = code ? RegenerateHint : ".meta에 올바른 GUID가 없습니다";
                }
                difference.CanRegenerate = code && !difference.CanAccept;
            }
            return differences;
        }
        private static bool ValidGuid(string guid) => guid.Length == 32 && guid.All(Uri.IsHexDigit);
        internal static List<TableFileDifference> GetDifferences(string output)
        {
            output = TablePaths.Output(output); string path = TablePaths.Manifest(output);
            if (File.Exists(path + ".pending") || !File.Exists(path)) return new List<TableFileDifference>();
            return Review(TableManifest.Read(path, output));
        }
        // No journal: the manifest is the only file written, and it is replaced atomically.
        internal static void AcceptCurrentFiles(string output, IReadOnlyList<TableFileDifference> reviewed)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) throw new InvalidOperationException("Accepting files requires an idle Editor outside PlayMode/compilation.");
            output = TablePaths.Output(output); string path = TablePaths.Manifest(output); TablePaths.NoReparse(path);
            if (!File.Exists(path) && !File.Exists(path + ".pending")) return;
            using var gate = TablePaths.Gate(path);
            if (File.Exists(path + ".pending")) throw new InvalidOperationException("An interrupted build needs recovery first; current files were not accepted.");
            var manifest = TableManifest.Read(path, output);
            if (manifest.status != "Ready") throw new InvalidOperationException("Only a finished build record can take a new baseline.");
            var current = Reviewed(manifest, reviewed);
            if (current.Count == 0) return;
            // Generated code that only the regenerate button can fix stays as it is and does not hold back the other files.
            if (current.All(d => !d.CanAccept) || current.Any(d => !d.CanAccept && !d.CanRegenerate)) throw new InvalidOperationException("Some files cannot be accepted: " + string.Join("; ", current.Where(d => !d.CanAccept)));
            var next = manifest.Copy();
            foreach (var record in next.tables.ToArray())
            {
                string file = TablePaths.RecordPath(output, record), content = TablePaths.HashContent(file);
                if (content == "missing") { next.tables.Remove(record); continue; }
                if (content != record.hash) { record.hash = content; record.plainHash = TableHash.Content(ReadApplied(file, record, TableRuntimeOptions.DecryptBytes).RuntimeText); }
                record.metaHash = TablePaths.HashContent(file + ".meta"); record.guid = TablePaths.Guid(file + ".meta");
            }
            if (next.consume != null)
                foreach (var code in next.consume.files)
                {
                    string file = Path.GetFullPath(Path.Combine(TablePaths.Project, next.consume.output, code.name)); // The recorded output uses '/'.
                    if (current.Any(d => d.FullPath == file + ".meta" && !d.CanAccept)) continue;
                    code.metaHash = TablePaths.HashContent(file + ".meta"); code.guid = TablePaths.Guid(file + ".meta");
                }
            if (Differences(next).Any(left => !current.Any(d => d.CanRegenerate && d.Path == left.Path))) throw new IOException("Current files changed while the new baseline was prepared.");
            byte[] bytes = next.Bytes();
            AtomicWrite(path, bytes);
            if (TablePaths.HashFile(path) != TableHash.Bytes(bytes)) throw new IOException("Manifest write was not confirmed.");
        }
        private static List<TableFileDifference> Reviewed(TableManifest manifest, IReadOnlyList<TableFileDifference> reviewed)
        {
            var current = Review(manifest);
            if (!current.Select(d => d.Path + "\n" + d.Hash).SequenceEqual(reviewed.Select(d => d.Path + "\n" + d.Hash))) throw new IOException("Files changed after they were reviewed; review them again.");
            return current;
        }
        // The record already holds the deterministic definition, so this needs no source file and cannot take in a source edit.
        // It runs through the normal transaction: changed C# stays pending until the loaded assembly is verified.
        internal static TableBuildState RegenerateCode(string output, IReadOnlyList<TableFileDifference> reviewed)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) throw new InvalidOperationException("Regenerating code requires an idle Editor outside PlayMode/compilation.");
            output = TablePaths.Output(output); string path = TablePaths.Manifest(output); TablePaths.NoReparse(path);
            if (File.Exists(path + ".pending")) throw new InvalidOperationException("An interrupted build needs recovery first; generated code was not changed.");
            if (!File.Exists(path)) throw new InvalidOperationException("There is no recorded build.");
            var manifest = TableManifest.Read(path, output);
            if (manifest.status != "Ready" || manifest.consume == null) throw new InvalidOperationException("Only a finished build record with generated code can be regenerated.");
            var current = Reviewed(manifest, reviewed);
            if (!current.Any(d => d.CanRegenerate)) throw new InvalidOperationException("No generated code needs regeneration.");
            // Commit verifies the complete generation, and accepting tables first keeps that check exact.
            if (current.Any(d => !d.IsCode)) throw new InvalidOperationException("Accept or restore the other files first: " + string.Join("; ", current.Where(d => !d.IsCode)));
            var result = manifest.Copy(); var entries = new List<TableJournalEntry>();
            string[] paths = ConsumeTypesCodeGenerator.Paths(result.consume), sources = { ConsumeTypesCodeGenerator.EnumText(result.consume), ConsumeTypesCodeGenerator.ExtensionsText(result.consume) };
            for (int i = 0; i < paths.Length; i++)
            {
                var file = result.consume.files.Single(f => f.name == Path.GetFileName(paths[i]));
                byte[] bytes = new UTF8Encoding(false, true).GetBytes(sources[i]);
                if (TablePaths.HashContent(paths[i]) != file.hash) entries.Add(Entry(paths[i], bytes));
                string guid = TablePaths.Guid(paths[i] + ".meta");
                if (ValidGuid(guid)) { file.metaHash = TablePaths.HashContent(paths[i] + ".meta"); file.guid = guid; }
                else
                {
                    byte[] meta = TablePreparedBuild.NewMeta(true, file.guid);
                    entries.Add(Entry(paths[i] + ".meta", meta)); file.metaHash = TableHash.Content(meta);
                }
            }
            var state = TableBuildState.Prepared;
            Commit(output, path, TablePaths.HashFile(path), entries, result, entries.Any(e => e.path.EndsWith(".cs", StringComparison.Ordinal)), null, AtomicWrite, Checkpoint, value => state = value, current.Select(d => d.Path).ToList());
            return state;
        }
        internal const string RegenerateHint = "직접 고친 생성 코드는 기준으로 인정할 수 없습니다. '생성 코드 다시 만들기'를 누르세요";
        internal const string NextStep = "Custom/Create Table의 관리·복구 → 복구·진단에서 현재 파일을 새 기준으로 인정하세요. 생성 코드는 '생성 코드 다시 만들기'를 누르세요.";
        // One entry per file or record that blocks PlayMode and Player build.
        internal static List<string> Unresolved()
        {
            var found = new List<string>();
            string root = Path.Combine(TablePaths.Project, "ProjectSettings", "JJEvolTableAuthoring");
            if (!Directory.Exists(root)) return found;
            try
            {
                TablePaths.NoReparse(root);
                foreach (string pending in Directory.GetFiles(root, "*.pending")) found.Add(TablePaths.Relative(pending) + ": 적용이 끝나지 않았습니다. Unity 컴파일이 끝나기를 기다리거나 복구하세요");
                foreach (string path in Directory.GetFiles(root, "*.json"))
                {
                    if (File.Exists(path + ".pending")) continue;
                    var m = TableManifest.Parse(File.ReadAllText(path));
                    if (m == null || m.tables == null) { found.Add(TablePaths.Relative(path) + ": 빌드 기록을 읽을 수 없습니다"); continue; }
                    if (m.status != "Ready" || !VerifyManifest(m)) { found.AddRange(Problems(m)); continue; }
                    if (m.consume == null) continue;
                    var status = TableCompilation.Status(TablePaths.Output(Path.Combine(TablePaths.Project, m.output)));
                    if (status.State != TableBuildState.Ready) found.Add(TablePaths.Relative(path) + ": " + status.Reason);
                }
            }
            catch (Exception e) { found.Add("Table Authoring 상태를 확인할 수 없습니다 (" + e.GetType().Name + ")"); }
            return found;
        }
        internal static bool HasUnresolvedBuild() => Unresolved().Count != 0;
        internal static string UnresolvedMessage(string blocked, IReadOnlyList<string> found)
            => blocked + "\n" + string.Join("\n", found.Take(20).Select(f => "- " + f)) + (found.Count > 20 ? "\n- 외 " + (found.Count - 20) + "개" : "") + "\n" + NextStep;
    }

    [InitializeOnLoad] internal sealed class TableBuildGuard : IPreprocessBuildWithReport
    {
        static TableBuildGuard()
        {
            EditorApplication.playModeStateChanged += state =>
            {
                if (state != PlayModeStateChange.ExitingEditMode) return;
                var found = TableFiles.Unresolved();
                if (found.Count == 0) return;
                EditorApplication.isPlaying = false; Debug.LogError(TableFiles.UnresolvedMessage("[Table Authoring] PlayMode 진입을 막았습니다.", found));
            };
        }
        public int callbackOrder => -1000;
        public void OnPreprocessBuild(BuildReport report)
        {
            var found = TableFiles.Unresolved();
            if (found.Count != 0) throw new BuildFailedException(TableFiles.UnresolvedMessage("[Table Authoring] Player 빌드를 막았습니다.", found));
        }
    }
}
