namespace jjevol
{
    public interface ICommonDataToolSettings
    {
        string TableInputDirectory { get; }
        string TableOutputDirectory { get; }
        string LocalizationInputDirectory { get; }
        string LocalizationOutputDirectory { get; }
        string LocalizationSpreadsheet { get; }
        string GoogleApiKey { get; }
    }
    public static class CommonDataToolSettings
    {
        private sealed class Defaults : ICommonDataToolSettings
        {
            public string TableInputDirectory => "Assets/GameData/Table/TSV";
            public string TableOutputDirectory => "Assets/GameData/Table/Resources";
            public string LocalizationInputDirectory => "Assets/GameData/Localization/Csv";
            public string LocalizationOutputDirectory => "Assets/GameData/Localization/Tables";
            public string LocalizationSpreadsheet => string.Empty;
            public string GoogleApiKey => string.Empty;
        }
        public static ICommonDataToolSettings Current { get; set; } = new Defaults();
    }
}
