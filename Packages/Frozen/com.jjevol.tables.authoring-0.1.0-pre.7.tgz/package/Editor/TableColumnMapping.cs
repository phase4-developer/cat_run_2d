using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace jjevol
{
    /// <summary>Explicit schema target -> source header. Values and source bytes are never edited.</summary>
    public sealed class TableColumnMapping
    {
        public string TableName { get; }
        public IReadOnlyDictionary<string, string> SourcesByTarget { get; }
        public TableColumnMapping(string tableName, IEnumerable<KeyValuePair<string, string>> sourcesByTarget)
        {
            if (string.IsNullOrEmpty(tableName) || sourcesByTarget == null) throw new ArgumentException("An explicit table and header mapping are required.");
            TableName = tableName;
            var pairs = sourcesByTarget.ToArray();
            if (pairs.Any(p => string.IsNullOrEmpty(p.Key) || string.IsNullOrEmpty(p.Value)) || pairs.Select(p => p.Key).Distinct(StringComparer.Ordinal).Count() != pairs.Length)
                throw new ArgumentException("Mapping targets/sources must be nonempty and targets unique.");
            SourcesByTarget = new ReadOnlyDictionary<string, string>(pairs.ToDictionary(p => p.Key, p => p.Value, StringComparer.Ordinal));
        }
        internal string Fingerprint => TableHash.Parts(new[] { TableName }.Concat(SourcesByTarget.OrderBy(p => p.Key, StringComparer.Ordinal).SelectMany(p => new[] { p.Key, p.Value })));
        internal TableDocument Apply(TableDocument document, TableSchema schema, List<TableDiagnostic> diagnostics)
        {
            Action<string> error = reason => diagnostics.Add(new TableDiagnostic(TableDiagnosticSeverity.Error, "ColumnMapping", TableName, document.Input.Source, reason));
            if (string.Equals(TableName, "ConsumeTypes", StringComparison.OrdinalIgnoreCase)) { error("ConsumeTypes uses its fixed header contract and cannot be mapped."); return document; }
            if (schema == null) { error("A game-provided explicit TableSchema is required for manual column mapping."); return document; }
            if (!document.IsValid) return document;
            var targets = schema.Columns.Select(c => c.Name).ToArray();
            if (SourcesByTarget.Keys.Any(t => !targets.Contains(t, StringComparer.Ordinal))) { error("Mapping target is not a declared schema column."); return document; }
            var effective = targets.Where(t => document.Headers.Contains(t) || SourcesByTarget.ContainsKey(t))
                .ToDictionary(t => t, t => SourcesByTarget.TryGetValue(t, out string source) ? source : t, StringComparer.Ordinal);
            var missing = targets.Where(t => !effective.ContainsKey(t)).ToArray();
            if (missing.Length != 0) { error("Unconnected schema columns: " + string.Join(", ", missing)); return document; }
            if (effective.Values.Any(s => !document.Headers.Contains(s))) { error("Selected source header is absent from this input snapshot."); return document; }
            if (effective.Values.Distinct(StringComparer.Ordinal).Count() != effective.Count) { error("Each source header may connect to only one schema column."); return document; }
            string[] headers = document.Headers.Select(source => effective.FirstOrDefault(p => p.Value == source).Key ?? source).ToArray();
            if (headers.Distinct(StringComparer.OrdinalIgnoreCase).Count() != headers.Length) { error("Normalized header would collide with an unmapped source column. No columns are discarded."); return document; }
            return document.WithHeaders(headers);
        }
    }
}
