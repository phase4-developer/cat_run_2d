# Changelog

## 0.1.0-pre.7 - 2026-11-09

- Replacing an existing table, generated code or metadata file no longer fails when another process briefly holds a file that was written moments earlier. Windows reports this as `File.Replace` HRESULT `0x80070497` (`ERROR_UNABLE_TO_REMOVE_REPLACED`) and keeps both files under their original names. It was reproduced outside Unity under the project folder: about 1 in 300 to 1 in 500 write-then-replace pairs fail, `MoveFileEx` fails the same way, and Windows Search indexing is not the cause. On-access scanning is the likely holder.
- Only that error now waits and repeats the same `File.Replace`, starting at 10 ms and doubling to at most 250 ms per wait, for 2 seconds in total. When the budget is spent the same `IOException` as before is thrown. Nothing is deleted or moved instead, and every other error, a sharing violation included, still fails on the first attempt. The journal, checkpoint and recovery protocol are unchanged.
- This was the cause of `ConsumeTypesGenerationTests` failing one different case per run.
- New `TableReplaceWaitTests` drive the wait with a scripted replacement.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.6 - 2026-11-08

- Lock files move from `ProjectSettings` to `Library/JJEvol/TableAuthoring/Locks/`. They are taken and held exactly as before; only the location changes, so taking a lock no longer adds a file to `ProjectSettings`. This covers `ProjectSettings/JJEvolTableAuthoring/<hash>.json.lock` and `ProjectSettings/JJEvolTableAuthoringSettings.json.lock`.
- Existing `.lock` files in `ProjectSettings/JJEvolTableAuthoring/` and `ProjectSettings/JJEvolTableAuthoringSettings.json.lock` are no longer used and can be deleted while no Editor has the project open. Keep the `.json` and `.json.pending` files.
- Tests follow the new lock location.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.5 - 2026-11-07

- PlayMode, Player build, status and plan messages name each mismatching file and the reason.
- Create Table can accept the current files as the new baseline after a confirmation that lists them. It rewrites only the manifest record, and is unavailable while a `.pending` journal needs recovery. `TableBuilder.GetFileDifferences`, `TableBuilder.AcceptCurrentFiles` and `TableFileDifference` are the matching API.
- Create Table can rebuild hand-edited or missing generated code from the recorded definition after a confirmation that lists the files and says hand edits are lost. It uses the normal transaction, so changed C# stays pending until the compiled assembly is verified, and Recover puts the edited file back. `TableBuilder.RegenerateCode` and `TableFileDifference.CanRegenerate` are the matching API.
- Regenerating while a hand edit already breaks compilation is judged by the compile that follows. The earlier failure no longer records this generation as failed, and Recover stays hidden while that compile is awaited.
- Generated outputs are compared with line endings normalised to LF, so a CRLF conversion alone no longer blocks. A manifest recorded from LF files stays valid unchanged. An output recorded while it contained CRLF differs once and can be accepted.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.4 - 2026-11-06

- The Remove screen no longer reselects every input, and selection is limited to the visible managed list.
- Blank cells of optional Unique columns are not duplicates.

Unity tests for this candidate are NOT_RUN.

# 0.1.0-pre.1 — 2026-10-31

Optional Editor extraction of CreateTable and CommonDataToolSettings, preserving original script GUIDs and menu. Added a testable local builder, explicit plaintext mode, Host-owned codec/validator hooks, encrypted round-trip checks, failure-before-replacement and stable-GUID regeneration. Removed content previews and backend/JSON diagnostic dependencies. Table Core, existing packages and snapshots are unchanged. No publication or game installation.
