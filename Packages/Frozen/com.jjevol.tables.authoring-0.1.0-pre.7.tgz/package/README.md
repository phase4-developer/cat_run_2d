# JJEvol Table Authoring — development candidate

Editor companion to `com.jjevol.tables`. Runtime TSVRow/Codec, the `Custom/Create Table` menu, CreateTable GUID and CommonDataToolSettings interface are unchanged. No crypto implementation, keys or Sheets client is bundled. Game enum generation is an explicit Editor option described below. The current development version is `0.1.0-pre.6`; this workspace is not a release.

## Optional Minimal Table Flow sample (AE2)

Import **Minimal Table Flow** from this package's Samples in Package Manager. Its game-owned Row/parser, Local/Paste window, Preview/Prepare/Apply, real generated ConsumeTypes, Runtime lookup and existing display Provider are documented in [Usage](Samples~/MinimalTableFlow/Usage.md). Plaintext is explicit for this neutral example; no global crypto/source/preset is changed. Basic Tables/Authoring needs two packages. This full typed sample additionally uses existing Economy and Save (four-package closure); those remain optional sample dependencies, not new dependencies of this package. Tests live under `Tests/Samples~/MinimalTableFlow` and are imported only into an explicit sample QA Host. Existing production APIs and AE1 safety contracts are unchanged. A validated candidate's exact SHA and support scope are in the repository `Docs/PackageInstallation.md`, `Docs/Guide/Delivery.md` and `Docs/Guide/Verification.md`.

Register Host-owned providers before encrypted authoring:

```csharp
TableAuthoringOptions.EncryptBytes = gameEncrypt;
TableRuntimeOptions.DecryptBytes = gameDecrypt;
TableAuthoringOptions.CodecProfileVersion = "game-codec:v1"; // nonsecret configuration identity
TableAuthoringOptions.ValidateTables = gameValidator;
TableAuthoringOptions.ValidationVersion = "game-schema:v1";
```

Runtime bootstrap must separately register DecryptBytes after its subsystem reset. Host configuration/closure changes must advance the appropriate version; the tool does not inspect keys or arbitrary captured state. Prepared outputs are decoded again immediately before Apply.

The existing source call remains valid:

```csharp
TableBuilder.Build(inputDirectory, outputDirectory, useEncrypt: true, validate: gameValidator);
```

**Build is now safe Upsert.** It never implicitly prunes other `.txt` files. A pre-existing output without this tool's ownership manifest blocks overwrite until explicit adoption. Callers that intentionally deleted obsolete tables must migrate to an explicit Full/Remove plan.

For reviewable selected builds:

```csharp
var request = new TableBuildRequest(
    TableBuilder.ReadDirectory(inputDirectory), outputDirectory,
    useEncrypt: true, selected: new[] { "definitions", "usage" },
    requireValidator: true, catalogDirectory: inputDirectory);
var plan = TableBuilder.Plan(request); // no writes; inspect IsValid/Diagnostics/Changes/Coverage
var prepared = TableBuilder.Prepare(plan); // no writes; staged bytes and codec round-trip
var result = prepared.Apply(); // verifies freshness and the approved scope
```

`TableInput.FromText(name, text, TableDialect.Csv)` and `FromFile(path, dialect)` share parsing, validation and planning. Directory acquisition reads flat `.tsv`/`.txt` files, case insensitive. CSV is an explicit dialect, not guessed from a file extension. Paste input does not pass through a temporary TSV.

Plain TSV preserves literal quotes. Quoted TSV/CSV support doubled quotes and delimiters within quoted cells. Every cell must round-trip through the existing Runtime TSVRow parser. Internal tab/CR/LF cells are rejected before output; there is no trim, replacement, padding, silent numeric default or source rewrite. Strict UTF-8 and BOM-marked UTF-16 are supported; UTF-32 and invalid decoding fail. Diagnostics identify source/table, logical row/column/header and physical line/character (or invalid byte offset). Quoted input emits equivalent plain TSV; input bytes/text remain intact.

Structural validation does not impose `int id`. Optional `TableSchema`/`TableColumnRule` declare required/unique/Text/Int32/Int64/range rules. Unique compares values only: empty cells in an optional column never collide, and a required column reports them as empty. Game validators own IDs, FK and business rules. Preview reports coverage; `requireValidator:true` requires a game callback even with schemas. Throw `TableInputException` with a `TableDiagnostic` for structured game errors. Arbitrary provider exception text is hidden. Validators must be pure; Rows returns fresh compatibility views.

The validation context combines selected candidates with verified **actually applied** nonselected managed outputs. Unapplied source changes do not become FK truth. Missing decoder/applied context blocks validation. Use a common output root for tables requiring one context, or a game validator with independently verified external context.

Full requires `operation:TableBuildOperation.Full, completeCatalog:true` and a nonempty explicitly acquired full catalog. Its scope includes all acquired inputs. Only managed, unchanged obsolete outputs are deletion candidates. Remove requires explicit managed names. Unmanaged/manual/foreign-modified files are preserved or reported as conflicts. Adoption requires `adopt:new[]{"name"}` and review of current bytes/meta/GUID and prepared replacement. Ownership is never inferred from extension or folder location.

Output must be inside this project's Assets/Resources and disjoint from source. Unsafe/reserved names, duplicate/case-ambiguous names and junction/symlink paths are rejected. Preview/Prepare/Open Existing Folder never create an absent output directory. Input, output, meta, manifest, catalog inventory, provider delegate or version changes invalidate the plan. Apply requires an idle Editor. No-op verifies current decoder equivalence and preserves bytes/GUID/write times, including with a random-IV codec.

Encrypted wire remains UTF-8 plaintext → Host encryption → Base64 → UTF-8 `.txt`; plaintext mode needs the corresponding Runtime source setting. All outputs must round-trip before mutation. No plaintext fallback. Existing meta/GUIDs are retained; new TextAssets get a GUID verified after import.

Metadata is `ProjectSettings/JJEvolTableAuthoring/<output-path-hash>.json`, outside shipped Resources. Preserve it with its outputs. A data-less lock file under `Library/JJEvol/TableAuthoring/Locks/` serializes cooperative writers. Apply writes an immutable Library journal, a persistent create-only `<manifest>.pending` locator, output changes and a verified checkpoint. Table-only builds then remove their own marker; changed C# keeps it until compilation is verified. State JSON uses an exclusive hash-checked checkpoint write as its primary protocol. It can tear, so pending always takes precedence. Table/code replacement uses flushed same-volume staging outside Assets and native File.Replace for existing files. When Windows reports `0x80070497` (another process still holds a file written moments earlier; both files keep their names), the same File.Replace waits and repeats for at most 2 seconds, then throws the original error. Other errors are not repeated. No delete-original/Move fallback.

Restoration accepts only exact recorded old/new states and verified backup hashes. `TableBuilder.Recover(outputDirectory)` returns false for RecoveryRequired. Missing Library journals, torn/foreign metadata or changed markers remain blocked. Do not remove pending merely to unblock work. PlayMode/Player build guards reject unresolved managed output state. This is a recoverable Editor protocol, **not simultaneous filesystem atomicity or a hostile-writer guarantee**. External tools must honor the writer boundary. Destroyed journals and arbitrary process/filesystem races are not automatically recoverable.

A generated file that differs from the last build blocks PlayMode, Player build and new plans, and each message names the file and the reason. Outputs are compared with line endings normalised to LF, so a CRLF conversion alone is not a difference; the journal still keeps exact bytes. To keep a changed file, open **관리·복구 → 복구·진단** and use **현재 파일을 새 기준으로 인정**, which lists the files, asks for confirmation and rewrites only the manifest record (`TableBuilder.GetFileDifferences`, `TableBuilder.AcceptCurrentFiles`). A missing output leaves the record. The source TSV is not touched, so the next build of that table still writes the source content. The action is unavailable while a `.pending` journal needs recovery. An edited generated `.cs` file cannot be accepted because its record must match the definition. Use **생성 코드 다시 만들기** instead (`TableBuilder.RegenerateCode`). It rebuilds the file from the definition recorded by the last build, not from the current source TSV, and hand edits in it are lost. Like a normal build it keeps `.pending` until the compiled assembly is verified, and `Recover` puts the edited file back. When table files also differ, accept them first.

GUI: **일반 테이블 / ConsumeType / 관리·복구** tabs in the same window. The normal workflow is **변경사항 확인 → 적용**. Review runs validation and Prepare without output writes; Apply uses that exact preparation. Changed inputs/settings/outputs require another review. Full, managed Remove, adoption and migration live in management. Sheets authentication/network is absent.

Validation scope is in the Framework `Docs/Guide/Verification.md`. Native File.Replace `0x80070497` occurred in this authoring Host. It reproduces without Unity (a direct stress run failed 55 of 12,992 replaces) and on every combination of the `NotContentIndexed` attribute, so the attribute alone is not the cause. In 0.1.0-pre.7 it was traced to another process briefly holding a just-written file, and replacement now waits for it as described above. Production ciphertext/keys, other OSes, Player/device, release installations and original products are unverified.

### Bounded native IO and path verification (A~E first follow-up)

`TableNativeIoBoundaryTests` adds six Windows Editor cases in the existing package test assembly. They cover one create/replacement, actual read-shared locks that permit freshness reads but deny native replacement, failure after a new text file is created, a successful 259-character `.txt.meta` path, and rejection of a 260-character required path before Apply. The rejection case also verifies unchanged outputs/metadata/journals and permits an acquired but unselected long ordinary input. Its selected-code check prepares a valid synthetic game asmdef, verifies against that baseline, then removes only its raw boundary before allowing imports/reloads; it does not generate or compile C#. Each case uses a new synthetic Assets subtree in the current validation Host. Unexpected failures preserve that fixture, metadata and Library journal in place; old Hosts and failure evidence are not reused or cleaned.

The first bounded run, `A-Boundaries01`, passed 53 of 54 related cases. The 260-character meta case created candidate files but managed verification/recovery stopped with DirectoryNotFoundException `0x80070003`; old committed data/meta/manifest were preserved while pending and the candidate files remained RecoveryRequired. Its XML, fixture and journal are retained. This is a distinct path-length defect, not the intermittent native replacement error.

Windows Editor planning now rejects required table/code/meta and ownership paths of 260 characters or more before reading them. Mutating preparation also checks lock, exact-width journal/compile-receipt and staging paths before any files are written; no-op preparation does not require unused staging paths. Other OSes and supported shorter paths keep their existing semantics. Existing uncertain generations are not automatically repaired or removed. The rejection uses ArgumentException, preserving public signatures and ownership metadata formats.

The final coordinator-owned `A-Boundaries03` run in the new TableHost passed all **54/54** related Editor cases, with no failures or skips. The prior `A-Boundaries02` failed the added code-boundary fixture's asmdef precondition; only its test arrangement was corrected, retaining the Production source hashes and all 259/260-character safety requirements. Earlier failed XML/fixtures/journals are preserved. These results do not retry or resolve the intermittent native `0x80070497`, change the journal/checkpoint protocol, delete an original as a replacement fallback, or establish general long-path/Player/device support. A fixed archive installation remains separate validation.

## Game ConsumeTypes code generation (STEP 05-C)

Open the **ConsumeType** tab in `Custom/Create Table`, or pass explicit `ConsumeTypesGenerationSettings(approvedGameCodeFolder, gameNamespace, enumName)` as the optional `consumeTypes:` argument of `TableBuildRequest`. The tab recognizes `ConsumeTypes.tsv`/`.txt`, displays the definition before code settings exist, and requests game code settings once. No game or asmdef is selected or modified automatically.

Acquire/select the configured definition (default name `ConsumeTypes`) through the same Local/Paste pipeline. Exact headers `typeId` and `codeName` are required; `displayName`/`localizationKey` are optional Preview labels. IDs are explicit signed Int32, including negative/zero/min/max. No automatic numbering, None row or built-in kind policy. Explicit `None` must use 0; another member may own 0. ASCII identifiers, reserved/contextual keywords, containing-type/CLR names, duplicate IDs and case-only member duplicates are checked. Unsupported cells still fail with source coordinates; no source rewriting.

This is an **Authoring-only role**: it joins the same frozen game validation context but does not emit a Runtime ConsumeTypes table. Code-only selection needs no encryption provider unless applied table context requires decoding. Selecting ordinary tables and this definition uses one plan, preparation, journal and pending marker. A failed combined build cannot accept a successful code-only half.

The explicit code folder must be inside this project's Assets, outside Resources/Editor/StreamingAssets, below an existing game asmdef referencing `JJEvol.Economy.Runtime` by name or GUID. Exactly `<EnumName>.Generated.cs`, `<EnumName>Extensions.Generated.cs` and their meta are managed. Generated game code references Economy Runtime; Tables.Authoring does not. Type/folder ownership, manual source/meta/GUID changes and assembly-boundary freshness are checked. The table adoption option never adopts unowned C# files.

Generated `.ToConsumeTypeId()` uses the real signed wrapper constructor. `.TryTo<EnumName>(out value)` succeeds only for defined IDs; on false the unknown numeric value is retained, rather than substituted with None/0. ConsumeData/server JSON keep preserving unknown numeric kinds. No handlers, Runtime Registry, SOs, DTO model generation or generic Consumer API is added.

Output is deterministic UTF-8 without BOM, LF and signed ID order. Its marker covers generator version, namespace, enum and canonical ID/name mapping. Row order and optional Preview labels do not rewrite generated code or metadata. Identical input preserves bytes, GUIDs and write times. Change the generator version when its emitted contract changes.

Only additions apply by default. Renumbering existing/historical names and reusing retired IDs are blocked. Renames/retirements require exact ID lists plus a reason through `ConsumeTypeMigration(renameIds: ..., retireIds: ..., reason: ...)`; the window exposes those fields only in **관리·복구 → ID 이행**. Normal table/code review never forwards old migration or adoption approvals. Preview marks breaking changes. Successful history retains retired IDs, prior names and migration notes. Failed/rolled-back compilation cannot become successful history. Output/namespace/enum relocation requires a separate source migration and is blocked here. History is Editor safety metadata, not a Runtime data source.

States: Prepared → Applying → AppliedAwaitingCompile → Ready, or Restored/RecoveryRequired. Changed C# keeps persistent pending. Completion/reload checks files, meta/GUIDs, the actually loaded game's marker, exact enum values and conversions before checkpointing Ready and confirming marker removal. Old assemblies/matching files alone cannot complete a generation. Compile errors leave a durable failure receipt beside the journal and require explicit recovery. Domain Reload/restart scans pending; the window observes the actual recorded state automatically. Explicit verify/resume controls appear in management when awaiting compilation cannot complete automatically. No automatic IO retries.

Recover restores only recorded own changes, Refreshes, then checks the complete original table/code/meta generation. `Recover == true` confirms files; restored C# can still await compilation, so inspect `GetStatus` before use/new Apply. Foreign bytes, torn metadata, missing Library journal or unresolved compile remain blocked. Prepared/Applying are live states; interrupted Applying becomes RecoveryRequired. Restoration is an operation result; loaded-assembly verification determines readiness of the committed prior generation after restart.

Table-only metadata keeps its exact version-1 shape/no-op. Code-owning manifests/journals are written as version 2 so older Authoring rejects unsupported ownership. Preserve ProjectSettings metadata and Library recovery material; do not downgrade Authoring over code-managed outputs. Runtime TSV/ciphertext/DTO/Save/UI contracts are unchanged. This is an unreleased source candidate, not an installed game update.

## Simplified window workflow (STEP 05-C-UX)

- **전체 갱신**: Upsert every ordinary table acquired from the input folder; no pruning. `ConsumeTypes` is excluded from this ordinary role.
- **선택 갱신**: Upsert selected ordinary tables; other outputs remain untouched.
- **전체 데이터 갱신**: ordinary tables and ConsumeTypes in one frozen plan/preparation/journal, including actual compile verification.
- **관리 출력 정리**: explicit Full (complete-catalog approval) or Remove in management. The API's Full deletion semantics are unchanged. The Remove screen deletes only names ticked in the list it shows: it does not reread inputs automatically, selections outside the managed list are ignored, and an empty selection is blocked.

`ProjectSettings/JJEvolTableAuthoringSettings.json` stores only explicit input/output overrides and game code folder/namespace/enum. It is Editor configuration, separate from output ownership manifests; it stores no keys, credentials, provider delegates or Runtime state. `CommonDataToolSettings.Current` remains the default path source. Explicit project overrides win; a window's unsaved work is a draft. Saving uses a lock and expected file hash; another writer/reload change blocks Apply/Save until explicit reload. Closing/reopening the Editor reuses saved configuration. Saving a new output path does not move/adopt/delete any old output.

The normal window reads Host policy instead of offering security switches:

```csharp
TableAuthoringOptions.UseEncryption = true; // default; explicit plaintext policy remains available to a Host
TableAuthoringOptions.Schemas = new[] {
    new TableSchema("prices", new TableColumnRule("id", TableColumnKind.Int32),
        new TableColumnRule("priceValue", TableColumnKind.Int64))
};
// Continue registering EncryptBytes, DecryptBytes, ValidateTables and their versions as above.
```

Ordinary window updates require the Host game validator; Schema alone does not prove FK/business rules. Code-only has the built-in fixed definition validation and needs no unrelated encryption provider unless applied context must be decoded. Direct TableBuilder API policy remains explicit and source-compatible.

Headers already match by exact name through TableInput/TableSchema/TSVRow, independent of column order. Manual mapping is offered only for an ordinary table with one explicit game Schema and a header mismatch. Choose a source for each declared target; the UI never guesses aliases. Duplicate sources, missing/unknown targets/sources, normalized collisions, integer/range/type errors and unsupported Runtime cells block generation. Extra columns/values are preserved. Schema `Required` governs empty cells; declared schema headers are still expected.

`TableColumnMapping("prices", new[] { new KeyValuePair<string,string>("priceValue", "Cost") })` can be passed via the optional `columnMappings:` request argument. Normalized headers join the original frozen input/RawHash/FilePath, Schema/game validation and actual Runtime round-trip. Source files/text and physical data-cell locations remain intact. Changing a mapping invalidates window review. ConsumeTypes is excluded from mapping. No Schema/parser contract means no mapping UI. No ORM/reflection model mapper is introduced.

Detailed manifest/journal/hash/GUID and recovery diagnostics are management-only. A basic-screen conflict gives a route to the relevant management area; unresolved recorded state blocks new work. Prepare remains an internal/API operation rather than a required normal user action. Existing class/menu/meta/GUID and serialized field names are preserved.
