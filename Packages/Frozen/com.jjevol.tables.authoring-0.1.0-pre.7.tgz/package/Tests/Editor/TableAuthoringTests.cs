using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tables.Authoring.Tests
{
    public static class PipelineValidation
    {
        public const string Definition="id\tlabel\n123456001\tfixture\n123456002\t다국어";
        public const string Usage="id\tlabel\treference\n124456001\tuse\t123456001";
        public static void Validate(IReadOnlyList<TableBuildInput> inputs)
        {
            var allIds=new HashSet<int>();
            foreach(var input in inputs)
                foreach(var row in input.Rows)
                {
                    if(!int.TryParse(row.Get("id"),out int id) || id<=0 || !allIds.Add(id)) throw new InvalidDataException("Fixture ID invalid or duplicate.");
                    if(string.IsNullOrWhiteSpace(row.Get("label"))) throw new InvalidDataException("Fixture label is required.");
                }
            foreach(var input in inputs)
                foreach(var row in input.Rows)
                    if(row.Contains("reference") && (!int.TryParse(row.Get("reference"),out int reference) || !allIds.Contains(reference)))
                        throw new InvalidDataException("Fixture FK not found.");
        }
        public static void ForgetFixtureMetadata(string root)
        {
            string full = Path.GetFullPath(root);
            if (!full.StartsWith(Path.GetFullPath(Application.dataPath) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ||
                !Path.GetFileName(full).StartsWith("JJEvolStep", StringComparison.Ordinal)) throw new InvalidOperationException("Unsafe fixture metadata cleanup");
            string metadata = Path.GetFullPath(Path.Combine(Application.dataPath, "../ProjectSettings/JJEvolTableAuthoring"));
            if (!Directory.Exists(metadata)) return;
            foreach (string file in Directory.GetFiles(metadata, "*.json").Concat(Directory.GetFiles(metadata, "*.json.pending").Select(p => p.Substring(0,p.Length - ".pending".Length))).Distinct())
            {
                FixtureManifest record = null;
                foreach (string candidate in new[] { file, file + ".pending" })
                {
                    if (!File.Exists(candidate)) continue;
                    try { record = JsonUtility.FromJson<FixtureManifest>(File.ReadAllText(candidate)); if (record?.output != null) break; } catch (ArgumentException) { }
                }
                if (record?.output != null && Path.GetFullPath(record.output).StartsWith(full + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                { File.Delete(file); string gate = Path.Combine(Application.dataPath, "../Library/JJEvol/TableAuthoring/Locks", Path.GetFileName(file) + ".lock"); if (File.Exists(gate)) File.Delete(gate); if (File.Exists(file + ".pending")) File.Delete(file + ".pending"); }
            }
        }
        [Serializable] private sealed class FixtureManifest { public string output; }
    }
    public sealed class TableAuthoringTests
    {
        string root,input,output;
        [SetUp] public void Setup()
        {
            root="Assets/JJEvolStep8_"+Guid.NewGuid().ToString("N");input=root+"/TSV";output=root+"/Resources/Step8";
            Directory.CreateDirectory(input);Directory.CreateDirectory(output);
            File.WriteAllText(input+"/definition.tsv",PipelineValidation.Definition);
            File.WriteAllText(input+"/usage.txt",PipelineValidation.Usage);
            TableAuthoringOptions.EncryptBytes=LegacyFixture.Encrypt;TableRuntimeOptions.DecryptBytes=LegacyFixture.Decrypt;
            TableAuthoringOptions.ValidateTables=null;
        }
        [TearDown] public void Cleanup()
        {
            TableQaFailureEvidence.Capture(root,output);
            TableAuthoringOptions.EncryptBytes=null;TableRuntimeOptions.DecryptBytes=null;TableAuthoringOptions.ValidateTables=null;
            var full=Path.GetFullPath(root);
            if(!string.Equals(Path.GetDirectoryName(full),Path.GetFullPath(Application.dataPath),StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Unsafe fixture cleanup");
            PipelineValidation.ForgetFixtureMetadata(root);AssetDatabase.Refresh();AssetDatabase.DeleteAsset(root);
        }
        [TestCase(false)] [TestCase(true)] public void BuildPreservesUtf8TextAndLegacySimpleWire(bool encrypted)
        {
            var result=TableBuilder.Build(input,output,encrypted,PipelineValidation.Validate);
            Assert.AreEqual(2,result.OutputFiles.Count);
            string contents=File.ReadAllText(output+"/definition.txt");
            if(encrypted)
            {
                Assert.AreEqual(Convert.ToBase64String(LegacyFixture.Encrypt(Encoding.UTF8.GetBytes(PipelineValidation.Definition))),contents);
                contents=Encoding.UTF8.GetString(LegacyFixture.Decrypt(Convert.FromBase64String(contents)));
            }
            Assert.AreEqual(PipelineValidation.Definition,contents);
        }
        [Test] public void ExplicitFullPrunesOnlyPreviouslyManagedTablesAndKeepsGuidAndUnmanagedFiles()
        {
            File.WriteAllText(input+"/obsolete.tsv","id\tlabel\n125456001\tpreviously managed");
            TableBuilder.Build(input,output,false);string guid=AssetDatabase.AssetPathToGUID(output+"/definition.txt");Assert.IsNotEmpty(guid);
            File.Delete(input+"/obsolete.tsv");File.WriteAllText(output+"/unmanaged.txt","not owned");File.WriteAllText(output+"/keep.json","{}");
            File.WriteAllText(input+"/definition.tsv",PipelineValidation.Definition.Replace("fixture","modified"));
            var plan=TableBuilder.Plan(new TableBuildRequest(TableBuilder.ReadDirectory(input),output,false,TableBuildOperation.Full,completeCatalog:true,validate:PipelineValidation.Validate,catalogDirectory:input));
            Assert.That(plan.Changes.Single(c=>c.TableName=="obsolete").Action,Is.EqualTo(TableOutputAction.Delete));
            var result=TableBuilder.Prepare(plan).Apply();
            Assert.AreEqual(1,result.RemovedObsoleteFiles);Assert.IsFalse(File.Exists(output+"/obsolete.txt"));Assert.IsTrue(File.Exists(output+"/keep.json"));
            Assert.IsFalse(File.Exists(output+"/obsolete.txt.meta"));Assert.AreEqual("not owned",File.ReadAllText(output+"/unmanaged.txt"));
            Assert.AreEqual(guid,AssetDatabase.AssetPathToGUID(output+"/definition.txt"));StringAssert.Contains("modified",File.ReadAllText(output+"/definition.txt"));
        }
        [TestCase("bad\tlabel")] [TestCase("123456001\t")] [TestCase("123456001\ta\n123456001\tb")]
        public void GameValidatorRejectsInvalidIdRequiredAndDuplicateBeforeReplacing(string rows)
        {
            File.WriteAllText(output+"/definition.txt","last-good");File.WriteAllText(input+"/definition.tsv","id\tlabel\n"+rows);
            Assert.Throws<InvalidDataException>(()=>TableBuilder.Build(input,output,false,PipelineValidation.Validate));
            Assert.AreEqual("last-good",File.ReadAllText(output+"/definition.txt"));
        }
        [Test] public void GameValidatorRejectsBrokenFk()
        {
            File.WriteAllText(input+"/usage.txt",PipelineValidation.Usage.Replace("123456001","123456999"));
            Assert.Throws<InvalidDataException>(()=>TableBuilder.Build(input,output,false,PipelineValidation.Validate));
        }
        [Test] public void MissingProviderAndWrongDecoderPreservePreviousOutput()
        {
            File.WriteAllText(output+"/definition.txt","last-good");TableAuthoringOptions.EncryptBytes=null;
            Assert.Throws<InvalidOperationException>(()=>TableBuilder.Build(input,output));
            TableAuthoringOptions.EncryptBytes=LegacyFixture.Encrypt;TableRuntimeOptions.DecryptBytes=_=>new byte[]{1,2,3};
            Assert.Throws<InvalidDataException>(()=>TableBuilder.Build(input,output));Assert.AreEqual("last-good",File.ReadAllText(output+"/definition.txt"));
        }
        [Test] public void ActualLegacyWrongTestKeyCannotProduceAValidBuild()
        {
            File.WriteAllText(output+"/definition.txt","last-good");TableRuntimeOptions.DecryptBytes=LegacyFixture.Method("DecryptWithWrongTestSecret");
            Assert.Catch(()=>TableBuilder.Build(input,output));Assert.AreEqual("last-good",File.ReadAllText(output+"/definition.txt"));
        }
        [Test] public void EmptyInputAndOutputNameCollisionDoNotErasePreviousFiles()
        {
            File.WriteAllText(output+"/definition.txt","last-good");File.WriteAllText(input+"/definition.txt",PipelineValidation.Definition);
            Assert.Throws<InvalidDataException>(()=>TableBuilder.Build(input,output,false));
            foreach(var file in Directory.GetFiles(input))File.Delete(file);
            Assert.Throws<InvalidDataException>(()=>TableBuilder.Build(input,output,false));Assert.AreEqual("last-good",File.ReadAllText(output+"/definition.txt"));
        }
        [Test] public void InvalidPathsAndOverlappingDirectoriesAreRejected()
        {
            Assert.Throws<ArgumentException>(()=>TableBuilder.Build(input,root+"/NotResources",false));
            Assert.Throws<ArgumentException>(()=>TableBuilder.Build(input,Path.Combine(Application.dataPath,"../Outside/Resources"),false));
            Assert.Throws<ArgumentException>(()=>TableBuilder.Build(output,output,false));
            Assert.Throws<DirectoryNotFoundException>(()=>TableBuilder.Build(root+"/missing",output,false));
        }
        [Test] public void ExistingWindowMenuAndProviderValidationHookUseTheSameBuilder()
        {
            var window=ScriptableObject.CreateInstance<CreateTable>();bool validated=false;
            try
            {
                TableAuthoringOptions.ValidateTables=rows=>{PipelineValidation.Validate(rows);validated=true;};
                typeof(CreateTable).GetField("assetPath",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(window,input);
                typeof(CreateTable).GetField("savePath",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(window,output);
                LogAssert.Expect(LogType.Log,"[CreateTable] Complete. Table Count: 2");
                typeof(CreateTable).GetMethod("CreateTables",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(window,null);
                Assert.IsFalse(File.Exists(output+"/definition.txt"),"Preview must not write outputs");
                typeof(CreateTable).GetMethod("PrepareOutputs",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(window,null);
                Assert.IsFalse(File.Exists(output+"/definition.txt"),"Prepare must not write outputs");
                typeof(CreateTable).GetMethod("ApplyOutputs",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(window,null);
                Assert.IsTrue(validated);Assert.IsTrue(File.Exists(output+"/definition.txt"));
                Assert.AreEqual("Custom/Create Table",typeof(CreateTable).GetMethod("Init",BindingFlags.Static|BindingFlags.NonPublic).GetCustomAttribute<MenuItem>().menuItem);
            }
            finally{UnityEngine.Object.DestroyImmediate(window);}
        }
    }
}
