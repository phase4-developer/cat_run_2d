using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class TableAuthoringWorkflowTests
    {
        private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
        private string root, input, output, code, space, settingsPath;
        private byte[] previousSettings;
        private bool encryption;
        private IReadOnlyList<TableSchema> previousSchemas;
        private CreateTable window;
        private static readonly TableSchema Prices = new TableSchema("prices", new TableColumnRule("id", TableColumnKind.Int32), new TableColumnRule("priceType", TableColumnKind.Int32), new TableColumnRule("priceValue", TableColumnKind.Int64));
        [SetUp] public void Setup()
        {
            root = "Assets/JJEvolStep05Ux_" + Guid.NewGuid().ToString("N"); input = root + "/Inputs"; output = root + "/Resources/Tables"; code = root + "/Game/Generated"; space = "Step05Ux.G" + Guid.NewGuid().ToString("N");
            Directory.CreateDirectory(input); Directory.CreateDirectory(root + "/Game");
            File.WriteAllText(root + "/Game/Game.asmdef", "{\"name\":\"" + space + "\",\"references\":[\"JJEvol.Economy.Runtime\"]}");
            File.WriteAllText(input + "/prices.tsv", "id\tpriceType\tpriceValue\n1\t7\t4000000000");
            File.WriteAllText(input + "/ConsumeTypes.tsv", "typeId\tcodeName\n7\tCoins");
            settingsPath = Path.GetFullPath("ProjectSettings/JJEvolTableAuthoringSettings.json");
            previousSettings = File.Exists(settingsPath) ? File.ReadAllBytes(settingsPath) : null;
            encryption = TableAuthoringOptions.UseEncryption; previousSchemas = TableAuthoringOptions.Schemas;
            TableAuthoringOptions.UseEncryption = false; TableAuthoringOptions.Schemas = new[] { Prices };
            TableAuthoringOptions.ValidateTables = tables => { foreach (var table in tables.Where(t => t.TableName == "prices")) table.RequireInt64(0, "priceValue"); };
            TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null;
            EditorApplication.LockReloadAssemblies(); AssetDatabase.DisallowAutoRefresh(); AssetDatabase.StartAssetEditing();
            window = NewWindow();
        }
        private CreateTable NewWindow()
        {
            var value = ScriptableObject.CreateInstance<CreateTable>();
            Set(value, "assetPath", input); Set(value, "savePath", output); Set(value, "codeOutputPath", code); Set(value, "codeNamespace", space); Set(value, "codeEnumName", "GameConsumeType");
            return value;
        }
        [TearDown] public void Cleanup()
        {
            try
            {
                TableQaFailureEvidence.Capture(root, output);
                if (window != null) UnityEngine.Object.DestroyImmediate(window);
                if (previousSettings == null) { if (File.Exists(settingsPath)) File.Delete(settingsPath); }
                else File.WriteAllBytes(settingsPath, previousSettings);
                TableAuthoringOptions.UseEncryption = encryption; TableAuthoringOptions.Schemas = previousSchemas;
                TableAuthoringOptions.ValidateTables = null; TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null;
                PipelineValidation.ForgetFixtureMetadata(root);
                string full = Path.GetFullPath(root);
                if (Path.GetDirectoryName(full) != Path.GetFullPath(Application.dataPath) || !Path.GetFileName(full).StartsWith("JJEvolStep05Ux_", StringComparison.Ordinal)) throw new InvalidOperationException("Unsafe UX fixture cleanup.");
                if (Directory.Exists(full)) Directory.Delete(full, true);
                if (File.Exists(full + ".meta")) File.Delete(full + ".meta");
            }
            finally { AssetDatabase.StopAssetEditing(); AssetDatabase.AllowAutoRefresh(); EditorApplication.UnlockReloadAssemblies(); AssetDatabase.Refresh(); }
        }
        private static object Get(object target, string name) => target.GetType().GetField(name, Private).GetValue(target);
        private static void Set(object target, string name, object value) => target.GetType().GetField(name, Private).SetValue(target, value);
        private static object Call(object target, string name, params object[] args) => target.GetType().GetMethod(name, Private).Invoke(target, args);
        private static TableBuildPlan Plan(CreateTable value) => (TableBuildPlan)Get(value, "_plan");
        private static TablePreparedBuild Prepared(CreateTable value) => (TablePreparedBuild)Get(value, "_prepared");
        private void Review(string task)
        {
            var method = typeof(CreateTable).GetMethod("Preview", Private); var type = method.GetParameters()[0].ParameterType;
            method.Invoke(window, new[] { Enum.Parse(type, task) });
        }
        private TableBuildPlan Mapped(string text, TableColumnMapping mapping, TableSchema schema = null)
            => TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("prices", text) }, output, false, schemas: schema == null ? Array.Empty<TableSchema>() : new[] { schema }, columnMappings: new[] { mapping }));
        private static TableColumnMapping Mapping(params string[] pairs) => new TableColumnMapping("prices", Enumerable.Range(0, pairs.Length / 2).Select(i => new KeyValuePair<string, string>(pairs[i * 2], pairs[i * 2 + 1])));
        private static void Blocked(TableBuildPlan plan, string code) { Assert.That(plan.IsValid, Is.False); Assert.That(plan.Diagnostics.Any(d => d.Code == code), Is.True, string.Join("\n", plan.Diagnostics)); Assert.Throws<InvalidDataException>(() => TableBuilder.Prepare(plan)); }
        private void SaveGameSettings() { Call(window, "SaveSettings"); Assert.That(File.Exists(settingsPath), Is.True); }

        [Test] public void HeaderOrderAlreadyMatchesByNameWithoutMapping()
        {
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("prices", "priceValue\tid\tpriceType\n4000000000\t1\t7") }, output, false, schemas: new[] { Prices }));
            Assert.That(plan.IsValid, Is.True); Assert.That(plan.ValidationInputs.Single().Rows[0].GetLong("priceValue"), Is.EqualTo(4000000000));
            Assert.That(plan.Request.ColumnMappings, Is.Empty);
        }
        [Test] public void MissingHeaderNamesTheExactExpectedColumn()
        {
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("prices", "id\tpriceType\tCost\n1\t7\t9") }, output, false, schemas: new[] { Prices }));
            var error = plan.Diagnostics.Single(d => d.Code == "MissingColumn");
            Assert.That(error.Header, Is.EqualTo("priceValue")); Assert.That(error.Reason, Does.Contain("priceValue"));
        }
        [Test] public void ExplicitMappingPreservesRawFileAndLocationsThenLoadsThroughActualRuntimeRow()
        {
            string path = input + "/prices.tsv", text = "Cost\tid\tpriceType\n4000000000\t1\t7"; File.WriteAllText(path, text);
            byte[] original = File.ReadAllBytes(path);
            var source = TableInput.FromFile(path);
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { source }, output, false, schemas: new[] { Prices }, columnMappings: new[] { Mapping("priceValue", "Cost") }));
            Assert.That(plan.IsValid, Is.True, string.Join("\n", plan.Diagnostics));
            var mapped = plan.ValidationInputs.Single(); Assert.That(mapped.Document.Input, Is.SameAs(source));
            Assert.That(mapped.Document.Records[0][0].Line, Is.EqualTo(2)); Assert.That(mapped.Document.Records[0][0].Character, Is.EqualTo(1));
            Assert.That(mapped.Document.Headers, Is.EqualTo(new[] { "priceValue", "id", "priceType" }));
            var prepared = TableBuilder.Prepare(plan); Assert.That(File.Exists(output + "/prices.txt"), Is.False); Assert.That(File.ReadAllBytes(path), Is.EqualTo(original));
            prepared.Apply(); var row = TSVRow.FromTsv(File.ReadAllText(output + "/prices.txt")).Single();
            Assert.That(row.GetLong("priceValue"), Is.EqualTo(4000000000)); Assert.That(row.GetInt("id"), Is.EqualTo(1)); Assert.That(row.GetInt("priceType"), Is.EqualTo(7));
            Assert.That(File.ReadAllBytes(path), Is.EqualTo(original));
        }
        [Test] public void MappingWithoutExplicitGameSchemaIsBlocked() => Blocked(Mapped("Cost\tid\tpriceType\n9\t1\t7", Mapping("priceValue", "Cost")), "ColumnMapping");
        [TestCase("NotAColumn", "Cost")][TestCase("priceValue", "Absent")][TestCase("priceValue", "id")]
        public void UnknownTargetMissingSourceOrReusedSourceAreBlocked(string target, string source)
            => Blocked(Mapped("Cost\tid\tpriceType\n9\t1\t7", Mapping(target, source), Prices), "ColumnMapping");
        [Test] public void MappingCannotDropAColumnToHideTargetCollision()
            => Blocked(Mapped("Cost\tid\tpriceType\tpriceValue\n9\t1\t7\t8", Mapping("priceValue", "Cost"), Prices), "ColumnMapping");
        [Test] public void MappingMustConnectEverySchemaColumn()
            => Blocked(Mapped("Cost\tOther\n9\t1", Mapping("priceValue", "Cost"), Prices), "ColumnMapping");
        [Test] public void MappingKeepsSchemaOverflowValidation()
            => Blocked(Mapped("Cost\tid\tpriceType\n9223372036854775808\t1\t7", Mapping("priceValue", "Cost"), Prices), "SchemaValue");
        [Test] public void MappingCannotBeAppliedToConsumeTypes()
        {
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("ConsumeTypes", "id\tname\n7\tCoins") }, output, false,
                schemas: new[] { new TableSchema("ConsumeTypes", new TableColumnRule("typeId"), new TableColumnRule("codeName")) },
                columnMappings: new[] { new TableColumnMapping("ConsumeTypes", new[] { new KeyValuePair<string, string>("typeId", "id"), new KeyValuePair<string, string>("codeName", "name") }) }));
            Blocked(plan, "ColumnMapping");
        }
        [Test] public void ChangingMappingChangesFrozenPlanFingerprint()
        {
            string text = "Cost\tOther\tid\tpriceType\n9\t8\t1\t7";
            var first = Mapped(text, Mapping("priceValue", "Cost"), Prices); var second = Mapped(text, Mapping("priceValue", "Other"), Prices);
            Assert.That(first.IsValid && second.IsValid, Is.True); Assert.That(first.Fingerprint, Is.Not.EqualTo(second.Fingerprint));
            Assert.That(first.ValidationInputs.Single().Rows.Single().GetLong("priceValue"), Is.EqualTo(9));
            Assert.That(second.ValidationInputs.Single().Rows.Single().GetLong("priceValue"), Is.EqualTo(8));
        }
        [Test] public void OriginalMappedSourceChangeAfterReviewInvalidatesApply()
        {
            File.WriteAllText(input + "/prices.tsv", "Cost\tid\tpriceType\n9\t1\t7");
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromFile(input + "/prices.tsv") }, output, false, schemas: new[] { Prices }, columnMappings: new[] { Mapping("priceValue", "Cost") }));
            var prepared = TableBuilder.Prepare(plan); File.AppendAllText(input + "/prices.tsv", "\n10\t2\t7");
            Assert.Throws<IOException>(() => prepared.Apply()); Assert.That(Directory.Exists(output), Is.False);
        }
        [Test] public void NormalReviewPreparesWithoutWritingAndApplyUsesThatExactPreparation()
        {
            Review("AllTables"); var prepared = Prepared(window);
            Assert.That(prepared, Is.Not.Null); Assert.That(File.Exists(output + "/prices.txt"), Is.False);
            Assert.That(Plan(window).Request.Operation, Is.EqualTo(TableBuildOperation.Upsert)); Assert.That(Plan(window).Request.Selected, Is.EqualTo(new[] { "prices" }));
            Assert.That(Plan(window).ConsumeTypes, Is.Null); Assert.That(prepared, Is.SameAs(Prepared(window)));
            Call(window, "ApplyOutputs"); Assert.That(File.Exists(output + "/prices.txt"), Is.True); Assert.That(File.Exists(output + "/ConsumeTypes.txt"), Is.False);
        }
        [Test] public void WholeTableUpdateNeverPrunesOldManagedOrUnmanagedOutputs()
        {
            TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("old", "id\n99") }, output, false))).Apply();
            File.WriteAllText(output + "/unmanaged.txt", "keep"); byte[] meta = File.ReadAllBytes(output + "/old.txt.meta");
            Set(window, "completeCatalog", true); // An old Full approval cannot turn normal Upsert into pruning.
            Review("AllTables"); Assert.That(Plan(window).Changes.All(c => c.Action != TableOutputAction.Delete), Is.True); Call(window, "ApplyOutputs");
            Assert.That(File.ReadAllText(output + "/unmanaged.txt"), Is.EqualTo("keep")); Assert.That(File.ReadAllBytes(output + "/old.txt.meta"), Is.EqualTo(meta));
            Assert.That(File.ReadAllText(output + "/old.txt"), Is.EqualTo("id\n99"));
        }
        [Test] public void SelectedUpdateLeavesUnselectedBytesGuidAndTimeUntouched()
        {
            File.WriteAllText(input + "/other.tsv", "id\n2"); Review("AllTables"); Call(window, "ApplyOutputs");
            string path = output + "/other.txt"; byte[] old = File.ReadAllBytes(path), meta = File.ReadAllBytes(path + ".meta"); var time = File.GetLastWriteTimeUtc(path);
            File.WriteAllText(input + "/other.tsv", "id\n3"); File.WriteAllText(input + "/prices.tsv", "id\tpriceType\tpriceValue\n1\t7\t4000000001");
            ((IList<string>)Get(window, "_selected")).Add("prices"); Review("SelectedTables"); Assert.That(Plan(window).Request.Selected, Is.EqualTo(new[] { "prices" }));
            Call(window, "ApplyOutputs"); Assert.That(File.ReadAllBytes(path), Is.EqualTo(old)); Assert.That(File.ReadAllBytes(path + ".meta"), Is.EqualTo(meta)); Assert.That(File.GetLastWriteTimeUtc(path), Is.EqualTo(time));
        }
        [Test] public void DefinitionCanBeReadBeforeGameCodeSettingsExist()
        {
            Set(window, "codeOutputPath", ""); Set(window, "codeNamespace", ""); Call(window, "ReadDefinitions");
            Assert.That(((IEnumerable)Get(window, "_definitions")).Cast<ConsumeTypeDefinition>().Single().TypeId, Is.EqualTo(7));
            Assert.That(((IEnumerable)Get(window, "_definitionErrors")).Cast<TableDiagnostic>(), Is.Empty); Assert.That(Directory.Exists(code), Is.False);
        }
        [Test] public void CodeSettingsRequireExplicitSaveThenANewWindowReusesThem()
        {
            Assert.That(Call(window, "GameSettingsValid"), Is.False); SaveGameSettings(); Assert.That(Call(window, "GameSettingsValid"), Is.True);
            var second = ScriptableObject.CreateInstance<CreateTable>();
            try { Assert.That(Get(second, "codeNamespace"), Is.EqualTo(space)); Assert.That(Get(second, "codeOutputPath"), Is.EqualTo(code)); Assert.That(Get(second, "savePath"), Is.EqualTo(output)); Assert.That(Call(second, "GameSettingsValid"), Is.True); }
            finally { UnityEngine.Object.DestroyImmediate(second); }
        }
        [Test] public void WholeDataReviewContainsTablesAndDefinitionInOnePreparedPlan()
        {
            SaveGameSettings(); Review("AllData");
            Assert.That(Prepared(window), Is.Not.Null); Assert.That(Plan(window).ConsumeTypes, Is.Not.Null); Assert.That(Plan(window).ValidationInputs.Select(t => t.TableName), Is.EquivalentTo(new[] { "prices", "ConsumeTypes" }));
            Assert.That(Plan(window).Changes.Select(c => c.TableName), Is.EqualTo(new[] { "prices" })); Assert.That(Directory.Exists(code), Is.False); Assert.That(Directory.Exists(output), Is.False);
        }
        [Test] public void CodeOnlyReviewDoesNotCreateARuntimeConsumeTypesOutput()
        {
            SaveGameSettings(); Review("CodeOnly"); Assert.That(Prepared(window), Is.Not.Null); Assert.That(Plan(window).Changes, Is.Empty); Assert.That(Plan(window).ConsumeTypes.Changes.Count, Is.EqualTo(2));
            Assert.That(Plan(window).Request.RequireValidator, Is.False); Assert.That(Directory.Exists(output), Is.False);
        }
        [Test] public void ManagementMigrationApprovalsCannotLeakIntoNormalCodeReview()
        {
            SaveGameSettings(); Set(window, "renameIds", "7"); Set(window, "retireIds", "8"); Set(window, "migrationReason", "synthetic approval");
            Review("CodeOnly"); Assert.That(Plan(window).Request.ConsumeTypes.Migration.RenameIds, Is.Empty); Assert.That(Plan(window).Request.ConsumeTypes.Migration.RetireIds, Is.Empty);
            Review("Migration"); Assert.That(Plan(window).Request.ConsumeTypes.Migration.RenameIds, Is.EqualTo(new[] { 7 })); Assert.That(Plan(window).Request.ConsumeTypes.Migration.RetireIds, Is.EqualTo(new[] { 8 }));
        }
        [Test] public void ExistingOutputIsAConflictUntilExplicitAdoptionReview()
        {
            Directory.CreateDirectory(output); File.WriteAllText(output + "/prices.txt", "previous");
            Set(window, "adoptSelected", true); // An old adoption flag is not an approval in the normal flow.
            Review("AllTables"); Assert.That(Prepared(window), Is.Null); Assert.That(Plan(window).Diagnostics.Any(d => d.Code == "UnmanagedConflict"), Is.True);
            ((IList<string>)Get(window, "_selected")).Add("prices"); Review("Adoption"); Assert.That(Prepared(window), Is.Not.Null); Assert.That(Plan(window).Changes.Single().Action, Is.EqualTo(TableOutputAction.Adopt));
        }
        [Test] public void FullCleanupIsStillExplicitAndNeedsCompleteCatalogApproval()
        {
            Review("CleanupFull"); Assert.That(Prepared(window), Is.Null); Assert.That(Plan(window).Diagnostics.Any(d => d.Code == "IncompleteCatalog"), Is.True);
            Set(window, "completeCatalog", true); Review("CleanupFull"); Assert.That(Prepared(window), Is.Not.Null); Assert.That(Plan(window).Request.Operation, Is.EqualTo(TableBuildOperation.Full));
        }
        [Test] public void MissingHostValidatorCannotBeDisabledByOldWindowFlag()
        {
            TableAuthoringOptions.ValidateTables = null; Set(window, "requireValidator", false); Review("AllTables");
            Assert.That(Prepared(window), Is.Null); Assert.That(Plan(window).Diagnostics.Any(d => d.Code == "MissingValidator"), Is.True);
        }
        [Test] public void EncryptionPolicyComesFromHostAndMissingCodecBlocksTheReview()
        {
            TableAuthoringOptions.UseEncryption = true; Set(window, "useEncrypt", false); Review("AllTables");
            Assert.That(Prepared(window), Is.Null); Assert.That(Plan(window).Request.UseEncrypt, Is.True); Assert.That(Plan(window).Diagnostics.Any(d => d.Code == "MissingCodec"), Is.True);
        }
        [Test] public void ChangedHostSchemaInvalidatesTheWindowPreparation()
        {
            Review("AllTables"); Assert.That(Prepared(window), Is.Not.Null);
            TableAuthoringOptions.Schemas = new[] { new TableSchema("prices", new TableColumnRule("priceValue", TableColumnKind.Int32)) };
            Call(window, "ApplyOutputs"); Assert.That(File.Exists(output + "/prices.txt"), Is.False); Assert.That(Prepared(window), Is.Null);
        }
        [Test] public void AnotherSettingsWriterCannotBeOverwrittenOrAppliedOver()
        {
            SaveGameSettings(); Review("AllTables"); byte[] changed = System.Text.Encoding.UTF8.GetBytes("{\"version\":1,\"enumName\":\"Other\"}"); File.WriteAllBytes(settingsPath, changed);
            Assert.Throws<TargetInvocationException>(() => Call(window, "SaveSettings")); Assert.That(File.ReadAllBytes(settingsPath), Is.EqualTo(changed));
            Call(window, "ApplyOutputs"); Assert.That(File.Exists(output + "/prices.txt"), Is.False); Assert.That(File.ReadAllBytes(settingsPath), Is.EqualTo(changed));
        }
        [Test] public void SettingsChangedAcrossReloadAreNotSilentlyAcceptedAsTheOldDraft()
        {
            SaveGameSettings(); File.AppendAllText(settingsPath, "\n");
            Call(window, "LoadSettings", false);
            Assert.That(Get(window, "_settingsConflict"), Is.True); Assert.That(Prepared(window), Is.Null);
            Assert.Throws<TargetInvocationException>(() => Review("AllTables"));
        }
        [Test] public void ChangingAnExplicitConnectionInvalidatesTheWindowPreparation()
        {
            File.WriteAllText(input + "/prices.tsv", "Cost\tOther\tid\tpriceType\n4000000000\t5000000000\t1\t7");
            ((IList<string>)Get(window, "_mappingEnabled")).Add("prices");
            var list = (IList)Get(window, "_connections"); var type = list.GetType().GetGenericArguments()[0];
            foreach (var pair in new[] { new[] { "id", "id" }, new[] { "priceType", "priceType" }, new[] { "priceValue", "Cost" } })
            {
                var item = Activator.CreateInstance(type, true); type.GetField("table").SetValue(item, "prices"); type.GetField("target").SetValue(item, pair[0]); type.GetField("source").SetValue(item, pair[1]); list.Add(item);
            }
            Review("AllTables"); Assert.That(Prepared(window), Is.Not.Null);
            type.GetField("source").SetValue(list[2], "Other"); Call(window, "ApplyOutputs");
            Assert.That(File.Exists(output + "/prices.txt"), Is.False); Assert.That(Prepared(window), Is.Null);
        }
        [Test] public void ReloadedReadyResultIsNotReplacedByAutomaticSourceDiscovery()
        {
            Review("AllTables"); Call(window, "ApplyOutputs");
            Set(window, "_status", "AppliedAwaitingCompile — previous serialized window message");
            Set(window, "_recorded", null); Set(window, "_sourceKey", null); Set(window, "_interactive", true); Set(window, "_nextPoll", -1d);
            Call(window, "Poll");
            Assert.That((string)Get(window, "_status"), Does.StartWith("Ready"));
            Assert.That(((IEnumerable)Get(window, "_inputs")).Cast<TableInput>().Any(i => i.TableName == "prices"), Is.True);
        }
        private void OpenRemoveScreen()
        {
            Review("AllTables"); Call(window, "ApplyOutputs"); Assert.That(File.Exists(output + "/prices.txt"), Is.True);
            Set(window, "_tab", 2); Set(window, "_management", 1); Set(window, "_cleanup", 2);
            Selected.Clear(); Set(window, "_sourceKey", null); Set(window, "_interactive", true); Set(window, "_nextPoll", -1d);
        }
        private IList<string> Selected => (IList<string>)Get(window, "_selected");
        [Test] public void PollOnTheRemoveScreenNeverSelectsInputTables()
        {
            OpenRemoveScreen(); Set(window, "_managedNames", new[] { "prices" });
            Call(window, "Poll");
            Assert.That(Selected, Is.Empty); Assert.That((string[])Get(window, "_managedNames"), Is.EqualTo(new[] { "prices" }));
        }
        [Test] public void PollOutsideTheRemoveScreenStillDiscoversInputs()
        {
            OpenRemoveScreen(); Set(window, "_cleanup", 0);
            Call(window, "Poll");
            Assert.That(Selected, Has.Member("prices"));
        }
        [Test] public void RemoveWithNoVisibleSelectionIsBlockedWithoutAPlan()
        {
            OpenRemoveScreen(); Set(window, "_managedNames", new[] { "prices" });
            Review("Remove");
            Assert.That(Plan(window), Is.Null); Assert.That(Prepared(window), Is.Null); Assert.That((string)Get(window, "_status"), Does.Contain("삭제할 관리 출력"));
            Assert.That(File.Exists(output + "/prices.txt"), Is.True);
        }
        [Test] public void HiddenSelectionWithoutAManagedListCannotPlanARemoval()
        {
            OpenRemoveScreen(); Selected.Add("prices");
            Review("Remove");
            Assert.That(Plan(window), Is.Null); Assert.That(Prepared(window), Is.Null); Assert.That(File.Exists(output + "/prices.txt"), Is.True);
        }
        [Test] public void RemovalPlanKeepsOnlySelectedNamesOnTheManagedList()
        {
            File.WriteAllText(input + "/other.tsv", "id\n2"); OpenRemoveScreen();
            Set(window, "_managedNames", new[] { "other" }); Selected.Add("prices"); Selected.Add("OTHER");
            Review("Remove");
            Assert.That(Plan(window).Request.Selected, Is.EqualTo(new[] { "OTHER" })); Assert.That(Plan(window).Changes.Select(c => c.Action), Is.EqualTo(new[] { TableOutputAction.Delete }));
        }
        [Test] public void ExplicitlySelectedManagedTableIsStillRemoved()
        {
            OpenRemoveScreen(); Set(window, "_managedNames", new[] { "prices" }); Selected.Add("prices");
            Review("Remove"); Assert.That(Prepared(window), Is.Not.Null);
            Call(window, "ApplyOutputs"); Assert.That(File.Exists(output + "/prices.txt"), Is.False);
        }
    }
}
