# JJEvol UI Contracts

`com.jjevol.ui.contracts@0.1.0-pre.2`는 uGUI 계열(`com.jjevol.ui`, `com.jjevol.ui.addressables`)과 UI Toolkit 계열이 함께 쓰는 UI 시스템 중립 계약이다. uGUI, TextMeshPro, UniTask에 의존하지 않는다. Addressables(`com.unity.addressables` 4.0.1)에는 의존한다. Editor 생성기가 Addressables 그룹에서 ID를 읽기 때문이라, UI Toolkit 게임도 Addressables를 설치한다. 프로젝트는 UI 시스템을 하나만 쓰지만(D-02), 주소 규칙과 ID 생성기는 한 곳에서만 고친다(UI Toolkit 계획 결정 G1).

## 들어 있는 것

| 형식 | 역할 |
|---|---|
| `UIAddress` | 게임 소유 문자열 UI ID와 Addressables 주소 `UIScreen_{id}`, `UIPopup_{id}`, `UIHud_{id}` |
| `UIAddressIdAttribute` | Inspector에서 등록 주소 중 접두가 맞는 ID를 고르게 하는 속성. 그리기는 Editor의 `UIAddressIdDrawer` |
| `UIIdConstants` | `JJEvol/UI/Generate UI ID Constants`. 등록 주소를 읽어 게임 폴더에 `GameScreen`, `GamePopup`, `GameHud` 문자열 상수를 쓴다 |
| `IScreenData`, `IPopupData` | 화면·팝업에 넘기는 데이터 표시 계약 |
| `IUILoadingProgressView` | 전체 화면 로딩의 진행률·문구 표시 계약 |
| `NumberFormat`, `NumberFormatProfile`, `NumberFormatSettings` | 숫자 표기. 아래 「숫자 표기」 |

모든 형식은 namespace `jjevol`이다. 2026-11-11에 `com.jjevol.ui`와 `com.jjevol.ui.addressables`에서 이름·GUID를 그대로 두고 옮겼다.

## 숫자 표기

수치가 큰 게임은 `1.2K`, `1억 2000만`처럼 단위 기호로 줄여 쓴다. 몇 자리마다 바꿀지와 기호는 게임이 정한다. 게임이 아무것도 정하지 않으면 지금처럼 `N0`(모든 자리, 문화권 구분자)이다.

```csharp
var settings = new NumberFormatSettings(NumberFormatProfile.CreateThousands(decimalPlaces: 1))   // 그 밖 언어: 1.2K
    .SetLanguage("ko", NumberFormatProfile.CreateKorean(maxUnits: 2));                           // ko-KR 등: 1억 2000만
UIRuntimeOptions.NumberFormat = settings;     // uGUI
UIEconomyOptions.NumberFormat = settings;     // UI Toolkit
string text = NumberFormat.Format(123456789L, settings.Resolve("ko-KR"), CultureInfo.GetCultureInfo("ko-KR")); // "1억 2345만"
```

| 설정 | 뜻 | 예 |
|---|---|---|
| `Notation` | `Full`(N0) 또는 `Abbreviated` | |
| `UnitBase` | 기호 하나가 앞 기호의 몇 배인지 | 1000(K·M), 10000(만·억) |
| `Symbols` | `UnitBase`¹, ²… 순서의 기호. 마지막 기호를 넘는 값은 마지막 기호에 큰 수를 붙인다 | `K,M,B,T` → `9,223,372.03T` |
| `AbbreviateFrom` | 이 값보다 작으면 `N0`. 0이면 `UnitBase` | 10000이면 9,999는 그대로, 10,000은 `10K` |
| `DecimalPlaces` | 마지막으로 쓰는 단위의 소수 자릿수. 반올림하지 않고 버리며 끝의 0은 지운다 | 2면 999,999는 `999.99K` |
| `MaxUnits` | 쓰는 단위 수. 0인 단위는 건너뛴다 | 2면 `1억 2345만`, 3이면 `1억 2345만 6789` |
| `UnitSeparator` | 단위 사이 문자열 | 기본 공백 |
| `GroupDigits` | 한 단위 안에 문화권 자릿수 구분자를 쓸지 | 한국어 기본은 false(`1234만`) |

언어는 정확히 같은 이름(`ko-KR`), 그다음 앞부분(`ko`), 그다음 `Default` 순으로 고른다. 음수는 문화권 음수 기호를 앞에 붙인다. 프로필은 `[Serializable]`이라 라벨 Inspector에 둘 수 있고, 범위를 벗어난 Inspector 값은 표시할 때 안전한 값으로 줄인다. 코드에서 만들 때는 생성자가 잘못된 값을 거부한다.

라벨 연결: uGUI `PriceLabel`·`PriceBtn`·`ResourceLabel`·`NumberAnimator`는 `UIRuntimeOptions.NumberFormat`, UI Toolkit `PriceLabel`·`PriceBtn`·`ResourceLabel`은 `UIEconomyOptions.NumberFormat`을 따르고, 라벨마다 덮어쓸 수 있다(각 패키지 README). 실행 중에 설정을 바꾸면 `NotifyLocaleChanged()`를 불러 다시 그린다.

## 설치와 참조

`com.jjevol.ui`와 `com.jjevol.ui.addressables`가 이 패키지에 의존하므로 manifest에 함께 적는다. Assembly-CSharp는 자동으로 참조한다. 게임이 자체 asmdef를 쓰고 위 형식을 직접 쓰면 그 asmdef에 `JJEvol.UI.Contracts.Runtime`(생성기를 부르는 Editor 코드는 `JJEvol.UI.Contracts.Editor`)를 더한다.

## 검증

Editor 시험 `JJEvol.UI.Contracts.Tests.Editor`(ID 생성기, 숫자 표기 경계값·프로필·언어 선택). 결과는 `Docs/Guide/Verification.md`에 적는다.
