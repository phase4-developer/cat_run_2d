# Changelog

## 0.1.0-pre.2 - 2026-11-19

- 새 숫자 표기 API `NumberFormat.Format(value, profile, culture)`, `NumberFormatProfile`, `NumberFormatSettings`(중앙 요청 7eee4387e98c). 단위 간격(1000·10000 등), 기호 목록, 축약 시작 값, 소수 자릿수(버림), 표시할 최대 단위 수, 단위 구분자, 자릿수 구분 여부, 언어별 프로필 선택을 정한다. 기본 `NumberFormatProfile.Full`은 `ToString("N0")`과 같다. 미리 만든 `CreateThousands`(K·M·B·T), `CreateKorean`(만·억·조·경, 기본 2단위). `Copy()`로 프로필을 복제한다. uGUI와 UI Toolkit 라벨이 같이 쓴다.

## 0.1.0-pre.1 - 2026-11-11

- New package. UI system neutral contracts moved here unchanged so uGUI and UI Toolkit share one copy (UI Toolkit plan decision G1, 2026-11-11): `UIAddress` and `UIAddressIdAttribute` with its Inspector drawer (from ui.addressables), `IUILoadingProgressView` (from ui), `IScreenData` and `IPopupData` (from ui.addressables `UIScreen.cs`/`UIPopup.cs`), and the `JJEvol/UI/Generate UI ID Constants` generator `UIIdConstants` with its tests. Namespace `jjevol`, type names and the GUIDs of moved files are unchanged.
- No uGUI, TextMeshPro or UniTask dependency. The Editor assembly uses Addressables to read registered addresses.
