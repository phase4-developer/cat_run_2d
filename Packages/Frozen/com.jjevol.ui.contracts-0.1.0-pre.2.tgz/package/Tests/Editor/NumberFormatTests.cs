using System;
using System.Globalization;
using NUnit.Framework;

namespace jjevol.UI.Tests
{
    public sealed class NumberFormatTests
    {
        private static readonly CultureInfo En = CultureInfo.GetCultureInfo("en-US");
        private static readonly CultureInfo De = CultureInfo.GetCultureInfo("de-DE");

        [Test]
        public void DefaultIsTheSameAsN0()
        {
            foreach (long value in new[] { 0L, 999L, 1000L, 9999L, 10000L, -1234567L, long.MaxValue, long.MinValue })
            {
                Assert.That(NumberFormat.Format(value, null, En), Is.EqualTo(value.ToString("N0", En)));
                Assert.That(NumberFormat.Format(value, NumberFormatProfile.Full, De), Is.EqualTo(value.ToString("N0", De)));
                Assert.That(NumberFormat.Format(value, new NumberFormatProfile(), En), Is.EqualTo(value.ToString("N0", En)));
                Assert.That(new NumberFormatSettings().Resolve("ko-KR"), Is.SameAs(NumberFormatProfile.Full));
            }
        }

        [Test]
        public void ThousandsTruncateAndKeepTheLastSymbolPastTheList()
        {
            var cases = new (long value, string expected)[]
            {
                (0L, "0"),
                (999L, "999"),
                (1000L, "1K"),
                (1050L, "1.05K"),
                (9999L, "9.99K"),
                (10000L, "10K"),
                (999999L, "999.99K"),
                (1000000L, "1M"),
                (1234567L, "1.23M"),
                (-1234567L, "-1.23M"),
                (-999L, "-999"),
                (1000000000000L, "1T"),
                (1234567890123456L, "1,234.56T"),
                (long.MaxValue, "9,223,372.03T")
            };
            foreach (var (value, expected) in cases)
            {
                Assert.That(NumberFormat.Format(value, NumberFormatProfile.CreateThousands(), En), Is.EqualTo(expected), value.ToString());
            }
        }

        [Test]
        public void AbbreviationStartsAtTheConfiguredValue()
        {
            var cases = new (long value, string expected)[]
            {
                (9999L, "9,999"),
                (10000L, "10K"),
                (12345L, "12.3K")
            };
            foreach (var (value, expected) in cases)
            {
                var profile = NumberFormatProfile.CreateThousands(decimalPlaces: 1, abbreviateFrom: 10000);
                Assert.That(NumberFormat.Format(value, profile, En), Is.EqualTo(expected), value.ToString());
            }
        }

        [Test]
        public void KoreanShowsUpToTwoUnits()
        {
            var cases = new (long value, string expected)[]
            {
                (0L, "0"),
                (999L, "999"),
                (9999L, "9,999"),
                (10000L, "1만"),
                (10005L, "1만 5"),
                (12345L, "1만 2345"),
                (100000000L, "1억"),
                (120000000L, "1억 2000만"),
                (123456789L, "1억 2345만"),
                (100000005L, "1억"),
                (-123456789L, "-1억 2345만"),
                (1000000000000L, "1조"),
                (12345678901234567L, "1경 2345조"),
                (long.MaxValue, "922경 3372조")
            };
            foreach (var (value, expected) in cases)
            {
                Assert.That(NumberFormat.Format(value, NumberFormatProfile.CreateKorean(), En), Is.EqualTo(expected), value.ToString());
            }
        }

        [Test]
        public void KoreanSingleUnitUsesDecimalsAndThreeUnitsShowsMore()
        {
            Assert.That(NumberFormat.Format(123456789L, NumberFormatProfile.CreateKorean(maxUnits: 1, decimalPlaces: 2), En), Is.EqualTo("1.23억"));
            Assert.That(NumberFormat.Format(123456789L, NumberFormatProfile.CreateKorean(maxUnits: 3), En), Is.EqualTo("1억 2345만 6789"));
            Assert.That(NumberFormat.Format(123456789L, NumberFormatProfile.CreateKorean(maxUnits: 2, decimalPlaces: 1), En), Is.EqualTo("1억 2345.6만"));
        }

        [Test]
        public void CustomSymbolsBaseSeparatorAndCulture()
        {
            var profile = new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new[] { "k", "m" }, decimalPlaces: 2, maxUnits: 2, unitSeparator: "/");
            Assert.That(NumberFormat.Format(1234567L, profile, En), Is.EqualTo("1m/234.56k"));
            Assert.That(NumberFormat.Format(1200L, NumberFormatProfile.CreateThousands(), De), Is.EqualTo("1,2K"));
            Assert.That(NumberFormat.Format(1234567890123456L, NumberFormatProfile.CreateThousands(), De), Is.EqualTo("1.234,56T"));
            Assert.That(NumberFormat.Format(-1200L, NumberFormatProfile.CreateThousands(), De), Is.EqualTo("-1,2K"));
        }

        [Test]
        public void DecimalValuesAndLargeBasesDoNotOverflow()
        {
            Assert.That(NumberFormat.Format(1999.999m, NumberFormatProfile.CreateThousands(), En), Is.EqualTo("1.99K"));
            Assert.That(NumberFormat.Format(decimal.MaxValue, NumberFormatProfile.CreateKorean(), En), Is.Not.Empty);
            var huge = new NumberFormatProfile(NumberNotation.Abbreviated, 1000000000, new[] { "a", "b", "c", "d", "e" });
            Assert.That(NumberFormat.Format(decimal.MaxValue, huge, En), Does.EndWith("c"));
            var manyDecimals = new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new[] { "K" }, decimalPlaces: 10);
            Assert.That(NumberFormat.Format(1e22m, manyDecimals, En), Is.EqualTo("10,000,000,000,000,000,000K"));
            Assert.That(NumberFormat.Format(decimal.MaxValue, manyDecimals, En), Does.EndWith("K"));
        }

        [Test]
        public void LanguageSelectionUsesExactThenNeutralThenDefault()
        {
            var thousands = NumberFormatProfile.CreateThousands();
            var korean = NumberFormatProfile.CreateKorean();
            var settings = new NumberFormatSettings(thousands).SetLanguage("ko", korean);
            Assert.That(settings.Resolve("ko-KR"), Is.SameAs(korean));
            Assert.That(settings.Resolve("KO"), Is.SameAs(korean));
            Assert.That(settings.Resolve("en-US"), Is.SameAs(thousands));
            Assert.That(settings.Resolve(null), Is.SameAs(thousands));
            var exact = NumberFormatProfile.Full;
            settings.SetLanguage("ko-KR", exact);
            Assert.That(settings.Resolve("ko-KR"), Is.SameAs(exact));
            Assert.That(settings.Resolve("ko_KP"), Is.SameAs(korean));
            settings.SetLanguage("ko", null);
            Assert.That(settings.Resolve("ko-KP"), Is.SameAs(thousands));
            settings.Default = null;
            Assert.That(settings.Resolve("en"), Is.SameAs(NumberFormatProfile.Full));
            Assert.That(NumberFormatProfile.CreateAbbreviatedFor("ko-KR").UnitBase, Is.EqualTo(10000));
            Assert.That(NumberFormatProfile.CreateAbbreviatedFor("en-US").UnitBase, Is.EqualTo(1000));
            var copy = korean.Copy();
            Assert.That(copy, Is.Not.SameAs(korean));
            Assert.That(copy.Symbols, Is.EqualTo(korean.Symbols));
            Assert.That(NumberFormat.Format(123456789L, copy, En), Is.EqualTo("1억 2345만"));
        }

        [Test]
        public void InvalidProfilesAreRejected()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new NumberFormatProfile(NumberNotation.Abbreviated, 1, new[] { "K" }));
            Assert.Throws<ArgumentOutOfRangeException>(() => new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new[] { "K" }, -1));
            Assert.Throws<ArgumentOutOfRangeException>(() => new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new[] { "K" }, decimalPlaces: 11));
            Assert.Throws<ArgumentOutOfRangeException>(() => new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new[] { "K" }, maxUnits: 0));
            Assert.Throws<ArgumentException>(() => new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new string[0]));
            Assert.Throws<ArgumentException>(() => new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new string[] { null }));
            Assert.Throws<ArgumentException>(() => new NumberFormatSettings().SetLanguage(" ", NumberFormatProfile.Full));
        }
    }
}
