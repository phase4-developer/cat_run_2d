using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    public sealed class AddressableScopeMB : MonoBehaviour
    {
        [Header("해제 옵션")]
        [SerializeField] private bool _releaseOnDisable = false;
        [SerializeField] private bool _releaseOnDestroy = true;
        [SerializeField] private bool _destroyInstancesOnRelease = true;
        readonly List<(string key, Action release, bool instanceSafe, GameObject instance)> _keys = new(8);
        readonly List<GameObject> _instances = new(8);
        int _version;
        bool _destroyed;
        bool _awake;
        bool _warnedNeverActivated;
        void Awake() { _awake = true; }
        // Unity sends OnDestroy only to objects that were active once, so ownership taken here would never return automatically.
        void WarnIfNeverActivated()
        {
            if (_awake || _warnedNeverActivated) return;
            _warnedNeverActivated = true;
            Debug.LogWarning($"[AddressableScopeMB] '{name}' has never been active, so OnDestroy will not run. Call ReleaseAll explicitly.", this);
        }
        public void RegisterKey(string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (_destroyed) throw new ObjectDisposedException(nameof(AddressableScopeMB));
            WarnIfNeverActivated();
            _keys.Add((key, AddressablesManager.HasInstance ? AddressablesManager.Instance.CaptureRelease(key) : null, false, null));
        }
        public T Borrow<T>(string key, bool registerToRelease = true) where T : UnityEngine.Object
        {
            if (_destroyed) return null;
            var asset = AddressablesManager.Instance?.GetAsset<T>(key);
            if (asset != null && registerToRelease) RegisterKey(key);
            return asset;
        }
        public void ReleaseNow(string key)
        {
            int index = _keys.FindIndex(entry => entry.key == key);
            if (index < 0) return;
            var entry = _keys[index]; _keys.RemoveAt(index);
            if (entry.instanceSafe) entry.release?.Invoke();
            else ReturnAfterInstances(_instances.ToArray(), new[] { entry.release }).Forget();
        }
        public async UniTask<T> LoadAsync<T>(string key, CancellationToken ct = default) where T : UnityEngine.Object
        {
            if (string.IsNullOrEmpty(key) || _destroyed) return null;
            WarnIfNeverActivated();
            int version = _version;
            var manager = AddressablesManager.HasInstance ? AddressablesManager.Instance : null;
            var asset = await AddressablesManager.LoadAssetAsync<T>(key, ct);
            if (asset == null) return null;
            var release = manager.CaptureRelease(key);
            if (!this || _destroyed || version != _version) { release?.Invoke(); return null; }
            _keys.Add((key, release, false, null)); return asset;
        }
        public async UniTask<GameObject> InstantiateAsync(string key, Transform parent = null, CancellationToken ct = default)
        {
            if (_destroyed) return null;
            WarnIfNeverActivated();
            int version = _version;
            var lease = await AddressableScope.GetPrefab(key, ct);
            if (lease == null) return null;
            if (!this || _destroyed || version != _version) { lease.Dispose(); return null; }
            GameObject go;
            try { go = Instantiate(lease.Asset, parent); }
            catch { lease.Dispose(); throw; }
            var deferred = AddressableScope.RetainUntilDestroyed(go, lease);
            _keys.Add((key, deferred.Dispose, true, go)); TrackInstance(go); return go;
        }
        public void TrackInstance(GameObject go) { if (go) _instances.Add(go); }
        public void DestroyInstanceNow(GameObject go)
        {
            if (!go || !_instances.Remove(go)) return;
            Destroy(go);
            // The prefab token of an InstantiateAsync clone ends with that clone; it returns after the actual destruction.
            int index = _keys.FindIndex(entry => entry.instance == go);
            if (index < 0) return;
            var owned = _keys[index]; _keys.RemoveAt(index); owned.release?.Invoke();
        }
        public void ReleaseAll()
        {
            unchecked { _version++; }
            var instances = _instances.ToArray();
            if (_destroyInstancesOnRelease) DestroyAllInstances(); else _instances.Clear();
            var entries = _keys.ToArray(); _keys.Clear();
            var remaining = new List<Action>();
            foreach (var entry in entries)
                if (entry.instanceSafe) entry.release?.Invoke(); else remaining.Add(entry.release);
            ReturnAfterInstances(instances, remaining.ToArray()).Forget();
        }
        static async UniTaskVoid ReturnAfterInstances(GameObject[] instances, Action[] releases)
        {
            if (Array.Exists(instances, instance => instance))
                await UniTask.WaitUntil(() => !Array.Exists(instances, instance => instance));
            foreach (var release in releases) release?.Invoke();
        }
        public void DestroyAllInstances()
        {
            foreach (var go in _instances) if (go) Destroy(go);
            _instances.Clear();
        }
        void OnDisable() { if (_releaseOnDisable) ReleaseAll(); }
        void OnDestroy() { _destroyed = true; if (_releaseOnDestroy) ReleaseAll(); }
    }
    public static class AddressableScopeMBExtensions
    {
        public static AddressableScopeMB GetAddressableScope(this Component c)
        {
            if (!c) return null;
            var scope = c.GetComponent<AddressableScopeMB>();
            return scope ? scope : c.gameObject.AddComponent<AddressableScopeMB>();
        }
    }
}
