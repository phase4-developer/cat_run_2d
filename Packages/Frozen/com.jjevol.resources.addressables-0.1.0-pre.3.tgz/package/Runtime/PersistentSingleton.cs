﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Dynamic;

namespace jjevol
{
    public abstract class PersistentSingleton<T> : MonoBehaviour where T : MonoBehaviour
    {
        protected static T _instance = null;
        public static bool applicationIsQuitting = false;
        protected bool _enabled;

        // Runs once per closed T, possibly on Unity's loading thread, so it only queues the reset.
        static PersistentSingleton() => PersistentSingletonSession.Register(ResetSession);

        static void ResetSession()
        {
            Application.quitting -= MarkQuitting;
            _instance = null;
            applicationIsQuitting = false;
        }

        static void MarkQuitting() => applicationIsQuitting = true;

        public static T Instance
        {
            get
            {
                if (applicationIsQuitting)
                {
                    return null;
                }

                if (!Application.isPlaying)
                {
                    return null;
                }

                if (_instance == null)
                {
                    _instance = FindAnyObjectByType<T>();

                    if (_instance == null)
                    {

                        _instance = new GameObject().AddComponent<T>();
                        _instance.gameObject.name = _instance.GetType().FullName;
                    }
                }

                return _instance;

            }
        }


        public static bool HasInstance
        {
            get
            {
                return !IsDestroyed;
            }
        }

        public static bool IsDestroyed
        {
            get
            {
                if (applicationIsQuitting || _instance == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        protected virtual void Awake()
        {
            InitializeSingleton();
        }

        /// <summary>
        /// Initializes the singleton.
        /// </summary>
        protected virtual void InitializeSingleton()
        {
            if (!Application.isPlaying)
                return;

            // One subscription per T, however many instances wake up or how many Play sessions share this domain.
            Application.quitting -= MarkQuitting;
            Application.quitting += MarkQuitting;

            if (_instance == null)
            {
                _instance = this as T;
            }
            else if (this != _instance)
            {
                Destroy(gameObject);
                return;
            }

            // DontDestroyOnLoad는 root GameObject에만 정상 적용된다.
            if (transform.parent != null)
                transform.SetParent(null);

            DontDestroyOnLoad(gameObject);
            _enabled = true;
        }

        protected virtual void OnDestroy()
        {
            if (_instance == this)
                _instance = null;
        }


        protected virtual void OnApplicationQuit()
        {
            _instance = null;
            applicationIsQuitting = true;
        }
    }

    // Unity ignores RuntimeInitializeOnLoadMethod on generic types, so each closed singleton registers here.
    // The list itself survives a disabled Domain Reload, which is exactly when the registered resets are needed.
    internal static class PersistentSingletonSession
    {
        static readonly List<Action> Resets = new List<Action>();

        internal static void Register(Action reset)
        {
            lock (Resets) Resets.Add(reset);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetAll()
        {
            Action[] resets;
            lock (Resets) resets = Resets.ToArray();
            foreach (var reset in resets) reset();
        }
    }
}
