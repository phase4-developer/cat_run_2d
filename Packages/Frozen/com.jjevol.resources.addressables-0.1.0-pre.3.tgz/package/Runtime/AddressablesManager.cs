﻿using Cysharp.Threading.Tasks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.SceneManagement;

namespace jjevol
{
    public class AddressablesManager : PersistentSingleton<AddressablesManager>
    {
        public Func<UniTask> AfterSceneReload { get; set; }
        readonly CancellationTokenSource _lifetime = new();
        bool _disposing;
        bool _ownsLifetime;
        readonly Dictionary<string,float> _releaseDeadlines = new();
        readonly HashSet<GameObject> _instances = new();
        readonly HashSet<AsyncOperationHandle<SceneInstance>> _sceneLoads = new();
        readonly List<AsyncOperationHandle<SceneInstance>> _failedSceneLoads = new();
        readonly Dictionary<SceneInstance,string> _sceneKeys = new();
        readonly HashSet<SceneInstance> _unloading = new();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetSession() { _instance = null; applicationIsQuitting = false; Isinitialized = false; _missingManagerWarnings.Clear(); }
        protected override void Awake() { base.Awake(); _ownsLifetime = _instance == this; if (_ownsLifetime) SceneManager.sceneUnloaded += SceneUnloaded; }
        void SceneUnloaded(Scene scene)
        {
            foreach (var entry in loadedScenes.Where(s => s.Scene == scene).ToArray()) { loadedScenes.Remove(entry); _sceneKeys.Remove(entry); _unloading.Remove(entry); }
            _sceneLoads.RemoveWhere(h => !h.IsValid() || (h.IsDone && h.Status == AsyncOperationStatus.Succeeded && h.Result.Scene == scene));
        }
        void OnDisable() { StopAllCoroutines(); _releaseCoroutines.Clear(); }
        void OnEnable() { foreach (var entry in _releaseDeadlines.ToArray()) StartReleaseCoroutine(entry.Key, Mathf.Max(0, entry.Value - Time.realtimeSinceStartup)); }
        protected override void OnDestroy()
        {
            if (!_ownsLifetime) { base.OnDestroy(); return; }
            _ownsLifetime = false;
            _disposing = true; _lifetime.Cancel();
            SceneManager.sceneUnloaded -= SceneUnloaded;
            StopAllCoroutines(); _releaseCoroutines.Clear(); _releaseDeadlines.Clear();
            var instances = _instances.ToArray();
            foreach (var instance in instances) if (instance) Destroy(instance);
            _instances.Clear();
            var assets = _assetRefInfos.Values.ToArray(); _assetRefInfos.Clear();
            ReleaseAfterDestroy(assets, instances).Forget();
            foreach (var scene in _sceneLoads.ToArray()) if (scene.IsValid())
            {
                if (scene.IsDone) CloseScene(scene);
                else scene.Completed += CloseScene;
            }
            loadedScenes.Clear(); _sceneLoads.Clear(); _failedSceneLoads.Clear(); _sceneKeys.Clear();
            Isinitialized = false; base.OnDestroy(); _lifetime.Dispose();
        }
        static async UniTaskVoid ReleaseAfterDestroy(AssetRefInfo[] assets, GameObject[] instances)
        {
            if (Array.Exists(instances, instance => instance))
                await UniTask.WaitUntil(() => !Array.Exists(instances, instance => instance));
            await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);
            foreach (var info in assets) if (info.handle.IsValid()) Addressables.Release(info.handle);
        }
        static void CloseScene(AsyncOperationHandle<SceneInstance> handle)
        {
            if (!handle.IsValid()) return;
            if (handle.Status == AsyncOperationStatus.Succeeded && handle.Result.Scene.isLoaded) Addressables.UnloadSceneAsync(handle);
            else Addressables.Release(handle);
        }
        internal void TrackInstance(GameObject instance) { if (instance) _instances.Add(instance); }
        internal void UntrackInstance(GameObject instance) { _instances.Remove(instance); }
        internal Action CaptureRelease(string key)
        {
            if (!_assetRefInfos.TryGetValue(key, out var acquired)) return null;
            bool returned = false;
            return () =>
            {
                if (returned) return; returned = true;
                if (!_disposing && this && _assetRefInfos.TryGetValue(key, out var current) && ReferenceEquals(acquired, current)) ReleaseAsset(key);
            };
        }
        private sealed class AssetRefInfo
        {
            public string key { get; }
            public AsyncOperationHandle handle { get; }
            public object result { get; }
            public int refCount { get; private set; }

            public bool IsUsed => refCount > 0;

            public AssetRefInfo(string key, AsyncOperationHandle handle, object result, int initialRefCount)
            {
                this.key = key;
                this.handle = handle;
                this.result = result;
                refCount = Mathf.Max(0, initialRefCount);
            }

            public void AddRef()
            {
                refCount++;
            }

            public int RemoveRef()
            {
                refCount = Mathf.Max(0, refCount - 1);
                return refCount;
            }
        }

        public static string LocalPath => Addressables.RuntimePath;

        // Match the installed SDK's platform folder names in Editor and Player, including Windows.
        public static string BuildTarget => PlatformMappingService.GetPlatformPathSubFolder();

        public static string RemotePath => Application.persistentDataPath;

        public static bool Isinitialized = false;

        private readonly Dictionary<string, AssetRefInfo> _assetRefInfos = new Dictionary<string, AssetRefInfo>();
        private readonly Dictionary<string, Coroutine> _releaseCoroutines = new Dictionary<string, Coroutine>();
        private readonly Dictionary<string, LoadLock> _loadLocks = new Dictionary<string, LoadLock>();
        private static readonly HashSet<string> _missingManagerWarnings = new HashSet<string>();

        private sealed class LoadLock
        {
            public readonly SemaphoreSlim Gate = new SemaphoreSlim(1, 1);
            public int Users;
        }

        private bool IsLoadedInternal(string key)
        {
            return !string.IsNullOrEmpty(key) && _assetRefInfos.ContainsKey(key);
        }

        public static bool IsLoaded(string key)
        {
            return HasInstance && Instance.IsLoadedInternal(key);
        }

        // Static loads return null without a manager; say why once per key instead of leaving only an empty screen.
        private static void WarnMissingManager(string key)
        {
            if (applicationIsQuitting || !_missingManagerWarnings.Add(key ?? string.Empty)) return;
            Debug.LogWarning($"[AddressablesManager] Load returned null because no manager exists. Access AddressablesManager.Instance before loading. key:{key}");
        }

        private LoadLock AcquireLoadLock(string key)
        {
            if (!_loadLocks.TryGetValue(key, out var loadLock))
            {
                loadLock = new LoadLock();
                _loadLocks.Add(key, loadLock);
            }

            loadLock.Users++;
            return loadLock;
        }

        private void ReturnLoadLock(string key, LoadLock loadLock)
        {
            if (--loadLock.Users > 0) return;

            _loadLocks.Remove(key);
            loadLock.Gate.Dispose();
        }

        private void CancelReleaseCoroutine(string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            _releaseDeadlines.Remove(key);
            if (!_releaseCoroutines.TryGetValue(key, out var coroutine)) return;

            StopCoroutine(coroutine);
            _releaseCoroutines.Remove(key);
        }

        private void StartReleaseCoroutine(string key, float delayTime)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (_releaseCoroutines.ContainsKey(key)) return;
            if (!_assetRefInfos.ContainsKey(key)) return;
            _releaseDeadlines[key] = Time.realtimeSinceStartup + delayTime;
            if (!isActiveAndEnabled) return;
            _releaseCoroutines.Add(key, StartCoroutine(ReleaseAssetDelayed(key, delayTime)));
        }

        private IEnumerator ReleaseAssetDelayed(string key, float delayTime)
        {
            yield return new WaitForSecondsRealtime(delayTime);

            ReleaseAssetRefInfo(key);

            _releaseCoroutines.Remove(key);
            _releaseDeadlines.Remove(key);
        }

        private void ReleaseAssetRefInfo(string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (!_assetRefInfos.TryGetValue(key, out var info)) return;
            if (info.IsUsed) return;

            if (info.handle.IsValid())
                Addressables.Release(info.handle);

            _assetRefInfos.Remove(key);
        }

        public static UniTask<T> LoadAssetAsync<T>(string key, CancellationTokenSource cts = null)
            where T : UnityEngine.Object
        {
            return LoadAssetAsync<T>(key, cts?.Token ?? PlaySession.Token);
        }

        public static async UniTask<T> LoadAssetAsync<T>(string key, CancellationToken ct)
            where T : UnityEngine.Object
        {
            if (!HasInstance) { WarnMissingManager(key); return null; }
            if (string.IsNullOrEmpty(key)) return null;
            
            var manager = Instance;
            if (manager._disposing) return null;
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, manager._lifetime.Token);
            ct = linked.Token;
            var loadLock = manager.AcquireLoadLock(key);

            try
            {
                await loadLock.Gate.WaitAsync(ct);
            }
            catch (OperationCanceledException)
            {
                manager.ReturnLoadLock(key, loadLock);
                return null;
            }

            try
            {
                if (manager._assetRefInfos.TryGetValue(key, out var cachedInfo))
                {
                    if (cachedInfo.result is T cachedAsset)
                    {
                        cachedInfo.AddRef();
                        manager.CancelReleaseCoroutine(key);
                        return cachedAsset;
                    }

                    Debug.LogError($"[AddressablesManager] Loaded asset type mismatch. key:{key}, requested:{typeof(T).Name}, actual:{cachedInfo.result?.GetType().Name}");
                    return null;
                }

                var handle = Addressables.LoadAssetAsync<T>(key);
                (bool IsCanceled, T Result) loadResult;
                try { loadResult = await handle.ToUniTask(cancellationToken: ct).SuppressCancellationThrow(); }
                catch
                {
                    if (handle.IsValid()) Addressables.Release(handle);
                    throw;
                }

                if (loadResult.IsCanceled || ct.IsCancellationRequested || manager._disposing)
                {
                    if (handle.IsValid())
                        Addressables.Release(handle);

                    return null;
                }

                if (handle.Result == null)
                {
                    Debug.LogError($"[AddressablesManager] LoadAssetAsync failed. key:{key}, type:{typeof(T).Name}, status:{handle.Status}");

                    if (handle.IsValid())
                        Addressables.Release(handle);

                    return null;
                }

                var info = new AssetRefInfo(key, handle, handle.Result, 1);
                manager._assetRefInfos.Add(key, info);

                return handle.Result;
            }
            finally
            {
                loadLock.Gate.Release();
                manager.ReturnLoadLock(key, loadLock);
            }
        }

        public static async UniTask<Dictionary<string, T>> LoadAssetsAsync<T>(IEnumerable<string> keys, CancellationToken ct)
            where T : UnityEngine.Object
        {
            var results = new Dictionary<string, T>();

            if (!HasInstance) { WarnMissingManager("(key batch)"); return results; }
            if (keys == null) return results;

            var loadTasks = new List<UniTask<KeyValuePair<string, T>>>();
            var owner = Instance;
            var successful = new List<Action>();
            bool failed = false;
            async UniTask<KeyValuePair<string,T>> LoadOwned(string key)
            {
                var pair = await LoadSingleAssetPairAsync<T>(key, ct);
                if (pair.Value != null)
                {
                    var release = owner.CaptureRelease(key);
                    if (failed) release?.Invoke(); else successful.Add(release);
                }
                return pair;
            }

            foreach (var key in keys.Distinct())
            {
                if (string.IsNullOrEmpty(key)) continue;

                loadTasks.Add(LoadOwned(key));
            }

            if (loadTasks.Count == 0)
                return results;

            KeyValuePair<string,T>[] loadedPairs;
            try { loadedPairs = await UniTask.WhenAll(loadTasks); }
            catch
            {
                failed = true;
                foreach (var release in successful) release?.Invoke();
                successful.Clear(); throw;
            }

            foreach (var pair in loadedPairs)
            {
                if (pair.Value == null) continue;
                results[pair.Key] = pair.Value;
            }

            return results;
        }

        private static async UniTask<KeyValuePair<string, T>> LoadSingleAssetPairAsync<T>(string key, CancellationToken ct)
            where T : UnityEngine.Object
        {
            var asset = await LoadAssetAsync<T>(key, ct);
            return new KeyValuePair<string, T>(key, asset);
        }

        public static UniTask<IList<T>> LoadAssetsAsync<T>(string labelOrKey, CancellationTokenSource cts = null)
            where T : UnityEngine.Object
        {
            return LoadAssetsAsync<T>(labelOrKey, cts?.Token ?? PlaySession.Token);
        }

        public static async UniTask<IList<T>> LoadAssetsAsync<T>(string labelOrKey, CancellationToken ct)
            where T : UnityEngine.Object
        {
            if (!HasInstance) { WarnMissingManager(labelOrKey); return null; }
            if (string.IsNullOrEmpty(labelOrKey)) return null;

            var manager = Instance;
            if (manager._disposing) return null;
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, manager._lifetime.Token);
            ct = linked.Token;
            var loadLock = manager.AcquireLoadLock(labelOrKey);

            try
            {
                await loadLock.Gate.WaitAsync(ct);
            }
            catch (OperationCanceledException)
            {
                manager.ReturnLoadLock(labelOrKey, loadLock);
                return null;
            }

            try
            {
                if (manager._assetRefInfos.TryGetValue(labelOrKey, out var cachedInfo))
                {
                    if (cachedInfo.result is IList<T> cachedAssets)
                    {
                        cachedInfo.AddRef();
                        manager.CancelReleaseCoroutine(labelOrKey);
                        return cachedAssets;
                    }

                    Debug.LogError($"[AddressablesManager] Loaded asset list type mismatch. key:{labelOrKey}, requested:IList<{typeof(T).Name}>, actual:{cachedInfo.result?.GetType().Name}");
                    return null;
                }

                var handle = Addressables.LoadAssetsAsync<T>(labelOrKey, null);
                (bool IsCanceled, IList<T> Result) loadResult;
                try { loadResult = await handle.ToUniTask(cancellationToken: ct).SuppressCancellationThrow(); }
                catch { if (handle.IsValid()) Addressables.Release(handle); throw; }

                if (loadResult.IsCanceled || ct.IsCancellationRequested || manager._disposing)
                {
                    if (handle.IsValid())
                        Addressables.Release(handle);

                    return null;
                }

                if (handle.Result == null)
                {
                    Debug.LogError($"[AddressablesManager] LoadAssetsAsync failed. key:{labelOrKey}, type:{typeof(T).Name}, status:{handle.Status}");

                    if (handle.IsValid())
                        Addressables.Release(handle);

                    return null;
                }

                var info = new AssetRefInfo(labelOrKey, handle, handle.Result, 1);
                manager._assetRefInfos.Add(labelOrKey, info);

                return handle.Result;
            }
            finally
            {
                loadLock.Gate.Release();
                manager.ReturnLoadLock(labelOrKey, loadLock);
            }
        }

        public static void ReleaseAsset(IEnumerable<string> keys, float delayTime = 0f)
        {
            if (!HasInstance) return;
            if (keys == null) return;

            foreach (var key in keys)
                ReleaseAsset(key, delayTime);
        }

        /// <summary>Return one manually owned acquisition. Never also return the same acquisition through a lease or scope.</summary>
        public static void ReleaseAsset(string key, float delayTime = 0f)
        {
            if (!HasInstance) return;
            if (string.IsNullOrEmpty(key)) return;

            var manager = Instance;

            if (!manager._assetRefInfos.TryGetValue(key, out var info))
            {
                Debug.LogWarning($"[AddressablesManager] ReleaseAsset has no cached acquisition to return. Check for a duplicate return. key:{key}");
                return;
            }

            if (!info.IsUsed)
                Debug.LogWarning($"[AddressablesManager] ReleaseAsset returned an entry that has no owners left. Check for a duplicate return. key:{key}");

            info.RemoveRef();

            if (info.IsUsed)
                return;

            if (delayTime > 0f)
            {
                manager.StartReleaseCoroutine(key, delayTime);
                return;
            }

            manager.CancelReleaseCoroutine(key);
            manager.ReleaseAssetRefInfo(key);
        }

        public GameObject GetPrefab(string key)
        {
            return GetAsset<GameObject>(key);
        }

        public T GetAsset<T>(string key)
        {
            if (string.IsNullOrEmpty(key)) return default;

            if (!_assetRefInfos.TryGetValue(key, out var info))
                return default;

            if (info.result is not T asset)
            {
                Debug.LogError($"[AddressablesManager] GetAsset type mismatch. key:{key}, requested:{typeof(T).Name}, actual:{info.result?.GetType().Name}");
                return default;
            }

            info.AddRef();
            CancelReleaseCoroutine(key);

            return asset;
        }

        public bool TryGetLoadedAsset<T>(string key, out T asset)
        {
            asset = default;

            if (string.IsNullOrEmpty(key)) return false;
            if (!_assetRefInfos.TryGetValue(key, out var info)) return false;
            if (info.result is not T typedAsset) return false;

            asset = typedAsset;
            return true;
        }

        public int GetRefCount(string key)
        {
            if (string.IsNullOrEmpty(key)) return 0;
            return _assetRefInfos.TryGetValue(key, out var info) ? info.refCount : 0;
        }

        /// <summary>Immediately release cached entries with no owners, including pending delayed returns. Active acquisitions are retained.</summary>
        public void ReleaseUnusedAssets()
        {
            foreach (var key in _assetRefInfos.Where(entry => !entry.Value.IsUsed).Select(entry => entry.Key).ToArray())
            {
                CancelReleaseCoroutine(key);
                ReleaseAssetRefInfo(key);
            }
        }

        /// <summary>Force-clear every cached asset, including assets still in use. End consumers and destroy clones first; use ReleaseUnusedAssets for normal cleanup.</summary>
        public void ReleaseAllLoadedAssets()
        {
            var keys = _assetRefInfos.Keys.ToList();

            foreach (var key in keys)
            {
                CancelReleaseCoroutine(key);

                if (_assetRefInfos.TryGetValue(key, out var info))
                {
                    if (info.handle.IsValid())
                        Addressables.Release(info.handle);
                }

                _assetRefInfos.Remove(key);
            }
        }

        public string GetCatalogName()
        {
            return $"catalog_{Application.version}.json";
        }

        public string GetRemoteCatalogPath()
        {
            return Path.Combine(RemotePath, GetCatalogName());
        }

        public string GetLocalCatalogPath()
        {
#if UNITY_EDITOR
            return Path.Combine(Path.GetDirectoryName(Application.dataPath), LocalPath, "catalog.json");
#else
            return Path.Combine(LocalPath, "catalog.json");
#endif
        }

        /// <summary>Initialize the SDK. A failed initialization throws; cancellation only ends this caller's wait.</summary>
        public async UniTask InitAsync(CancellationToken ct = default)
        {
            if (Isinitialized) return;

            // The SDK hands every concurrent caller the same operation, so nobody here owns a reference to release.
            // Auto-release ends the handle at completion: failure surfaces as the awaited exception, never through Status.
            var initHandle = Addressables.InitializeAsync(true);
            var result = await initHandle.ToUniTask(cancellationToken: ct).SuppressCancellationThrow();
            if (!result.IsCanceled && !_disposing) Isinitialized = true;
        }

        #region Scene

        public List<SceneInstance> loadedScenes { get; private set; } = new List<SceneInstance>();

        public IEnumerator ReloadActiveSceneAsync()
        {
            SceneInstance activeSceneInstance = loadedScenes.Find(scene => scene.Scene == SceneManager.GetActiveScene());

            if (activeSceneInstance.Scene.IsValid() == false)
            {
                Debug.LogError("[AddressablesManager] ReloadActiveSceneAsync failed. active scene is not tracked.");
                yield break;
            }

            string sceneName = _sceneKeys.TryGetValue(activeSceneInstance, out var key) ? key : activeSceneInstance.Scene.name;

            var handle = LoadSceneCore(sceneName, LoadSceneMode.Single, true, 100, false);
            yield return handle;

            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                SceneManager.SetActiveScene(handle.Result.Scene);
                if (AfterSceneReload != null) yield return AfterSceneReload().ToCoroutine();

                Debug.Log($"Scene {sceneName} reloaded successfully.");
            }
            else
            {
                Debug.LogError($"Failed to reload scene: {sceneName}");
                _sceneLoads.Remove(handle);
                if (handle.IsValid()) Addressables.Release(handle);
            }
        }

        /// <summary>
        /// Start a scene load. A failed handle stays readable for the caller until the next LoadSceneAsync, which releases it;
        /// read Status before starting another load. The caller may also release a failed handle itself.
        /// </summary>
        public AsyncOperationHandle<SceneInstance> LoadSceneAsync(string sceneName, LoadSceneMode loadSceneMode = LoadSceneMode.Single, bool activateOnLoad = true, int priority = 100)
        {
            return LoadSceneCore(sceneName, loadSceneMode, activateOnLoad, priority, true);
        }

        private void ReleaseFailedSceneLoads()
        {
            foreach (var failed in _failedSceneLoads)
            {
                _sceneLoads.Remove(failed);
                if (failed.IsValid()) Addressables.Release(failed);
            }

            _failedSceneLoads.Clear();
        }

        // releaseFailureOnNextLoad is false only for ReloadActiveSceneAsync, which reads Status later and closes the handle itself.
        private AsyncOperationHandle<SceneInstance> LoadSceneCore(string sceneName, LoadSceneMode loadSceneMode, bool activateOnLoad, int priority, bool releaseFailureOnNextLoad)
        {
            ReleaseFailedSceneLoads();

            var handle = Addressables.LoadSceneAsync(sceneName, loadSceneMode, activateOnLoad, priority);
            _sceneLoads.Add(handle);
            handle.Completed += operation =>
            {
                if (_disposing) return;
                if (operation.Status == AsyncOperationStatus.Succeeded)
                {
                    _sceneKeys[operation.Result] = sceneName;
                    if (!loadedScenes.Contains(operation.Result))
                        loadedScenes.Add(operation.Result);

                    Debug.Log($"Scene {sceneName} loaded successfully.");
                }
                else
                {
                    Debug.LogError($"Failed to load scene: {sceneName}");
                    if (releaseFailureOnNextLoad) _failedSceneLoads.Add(handle);
                }
            };

            return handle;
        }

        public AsyncOperationHandle<SceneInstance> UnloadSceneAsync(SceneInstance sceneInstance)
        {
            if (!loadedScenes.Contains(sceneInstance))
            {
                Debug.LogWarning($"Scene {sceneInstance.Scene.name} is not in the loaded list.");
                return default;
            }
            if (!_unloading.Add(sceneInstance)) return default;

            var handle = Addressables.UnloadSceneAsync(sceneInstance);
            handle.Completed += operation =>
            {
                if (operation.Status == AsyncOperationStatus.Succeeded)
                {
                    loadedScenes.Remove(sceneInstance);
                    _sceneKeys.Remove(sceneInstance);
                    Debug.Log($"Scene {sceneInstance.Scene.name} unloaded successfully.");
                }
                else
                {
                    Debug.LogError($"Failed to unload scene: {sceneInstance.Scene.name}");
                }
                _unloading.Remove(sceneInstance);
            };

            return handle;
        }

        #endregion

        #region Update Catalog

        /// <summary>Manual SDK catalog update. Do not call while a Managed Addressables Revision Session owns the catalog; it replaces content that session selected.</summary>
        public async UniTask UpdateCatalog(CancellationToken ct = default)
        {
            var checkHandle = Addressables.CheckForCatalogUpdates(false);
            List<string> catalogsToUpdate = null;
            try
            {
                var checkResult = await checkHandle.ToUniTask(cancellationToken: ct).SuppressCancellationThrow();
                if (checkResult.IsCanceled) return;
                if (checkHandle.Status == AsyncOperationStatus.Succeeded) catalogsToUpdate = checkHandle.Result;
            }
            finally { if (checkHandle.IsValid()) Addressables.Release(checkHandle); }

            if (catalogsToUpdate == null || catalogsToUpdate.Count == 0)
                return;

            foreach (var catalog in catalogsToUpdate)
                Debug.LogWarning("UpdateCatalog : " + catalog);

            var updateHandle = Addressables.UpdateCatalogs(catalogsToUpdate, false);
            try
            {
                var updateResult = await updateHandle.ToUniTask(cancellationToken: ct).SuppressCancellationThrow();
                if (!updateResult.IsCanceled && updateHandle.Status != AsyncOperationStatus.Succeeded)
                    Debug.LogError($"[AddressablesManager] UpdateCatalogs failed. status:{updateHandle.Status}");
            }
            finally { if (updateHandle.IsValid()) Addressables.Release(updateHandle); }
        }

        /// <summary>Manual SDK catalog load. Do not call while a Managed Addressables Revision Session owns the catalog; it adds locators that session does not track.</summary>
        public async UniTask LoadCatalogAsync(CancellationToken ct = default)
        {
            Debug.LogWarning("LocalCatalog Path : " + GetLocalCatalogPath());

            await LoadCatalogAt(GetLocalCatalogPath(), ct);
        }

        /// <summary>Manual SDK catalog load. Do not call while a Managed Addressables Revision Session owns the catalog; it adds locators that session does not track.</summary>
        public async UniTask LoadRemoteCatalogAsync(CancellationToken ct = default)
        {
            Debug.LogWarning("RemoteCatalog Path : " + GetRemoteCatalogPath());

            await LoadCatalogAt(GetRemoteCatalogPath(), ct);
        }
        private static async UniTask LoadCatalogAt(string path, CancellationToken ct)
        {
            var handle = Addressables.LoadContentCatalogAsync(path, false);
            try
            {
                var result = await handle.ToUniTask(cancellationToken: ct).SuppressCancellationThrow();
                if (!result.IsCanceled && handle.Status != AsyncOperationStatus.Succeeded)
                    Debug.LogError($"[AddressablesManager] Load catalog failed. status:{handle.Status}");
            }
            finally { if (handle.IsValid()) Addressables.Release(handle); }
        }

        #endregion
    }
}
