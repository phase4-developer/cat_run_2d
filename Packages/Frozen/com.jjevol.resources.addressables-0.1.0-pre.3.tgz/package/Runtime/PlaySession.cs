// PlaySession.cs (신규, 어딘가 공용 Runtime 폴더)
using System.Threading;
using UnityEngine;

public static class PlaySession
{
    static CancellationTokenSource _cts;
    public static CancellationToken Token => _cts?.Token ?? CancellationToken.None;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Init()
    {
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = new CancellationTokenSource();
        Application.quitting -= OnQuit;
        Application.quitting += OnQuit;
    }
    static void OnQuit()
    {
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = null;
        Application.quitting -= OnQuit;
    }

    /// <summary>Cancel every token handed out so far and start a fresh session token. Later default-token loads run normally.</summary>
    public static void Cancel()
    {
        var previous = _cts;
        if (previous == null) return;
        // Swap first so cancellation callbacks already observe the new token. The old source stays undisposed because
        // callers may still hold copies of its token.
        _cts = new CancellationTokenSource();
        previous.Cancel();
    }
}
