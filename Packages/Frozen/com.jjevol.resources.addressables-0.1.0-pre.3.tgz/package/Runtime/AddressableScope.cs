using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    public sealed class AddressableLease<T> : IDisposable where T : UnityEngine.Object
    {
        public string Key { get; private set; }
        public T Asset { get; private set; }
        Action _release;
        internal AddressableLease(string key, T asset, Action release)
        { Key = key; Asset = asset; _release = release; }
        public static implicit operator T(AddressableLease<T> lease) => lease?.Asset;
        public void Dispose()
        {
            var release = Interlocked.Exchange(ref _release, null);
            release?.Invoke(); Asset = null; Key = null;
        }
    }
    public sealed class AddressableMultiScope : IDisposable
    {
        readonly List<(string key, Action release)> _keys = new(8);
        internal bool IsDisposed { get; private set; }
        public void Add(string key)
        {
            if (IsDisposed) throw new ObjectDisposedException(nameof(AddressableMultiScope));
            if (string.IsNullOrEmpty(key)) return;
            _keys.Add((key, AddressablesManager.HasInstance ? AddressablesManager.Instance.CaptureRelease(key) : null));
        }
        public void ReleaseNow(string key)
        {
            int index = _keys.FindIndex(entry => entry.key == key);
            if (index < 0) return;
            var entry = _keys[index]; _keys.RemoveAt(index); entry.release?.Invoke();
        }
        public void Dispose()
        {
            if (IsDisposed) return; IsDisposed = true;
            foreach (var entry in _keys) entry.release?.Invoke(); _keys.Clear();
        }
    }
    public static class AddressableScope
    {
        public static async UniTask<AddressableLease<T>> Get<T>(string key, CancellationToken ct = default) where T : UnityEngine.Object
        {
            if (string.IsNullOrEmpty(key)) return null;
            var manager = AddressablesManager.HasInstance ? AddressablesManager.Instance : null;
            var asset = await AddressablesManager.LoadAssetAsync<T>(key, ct);
            if (asset == null) return null;
            return new AddressableLease<T>(key, asset, manager.CaptureRelease(key));
        }
        public static T AddToScope<T>(this AddressableMultiScope scope, string key)
        {
            if (scope == null || string.IsNullOrEmpty(key)) return default;
            if (scope.IsDisposed) throw new ObjectDisposedException(nameof(AddressableMultiScope));
            var manager = AddressablesManager.Instance;
            if (manager == null) return default; // Application shutdown.
            var asset = manager.GetAsset<T>(key);
            if (asset != null) scope.Add(key);
            return asset;
        }
        public static async UniTask<AddressableLease<GameObject>> GetPrefab(string key, CancellationToken ct = default)
            => await Get<GameObject>(key, ct);
        public static async UniTask<(GameObject instance, IDisposable lease, IDisposable destroyOnDispose)>
            InstantiateWithLease(string key, Transform parent = null, CancellationToken ct = default)
        {
            var lease = await GetPrefab(key, ct);
            if (lease == null || lease.Asset == null) return (null, null, null);
            GameObject go;
            try { go = UnityEngine.Object.Instantiate(lease.Asset, parent); }
            catch { lease.Dispose(); throw; }
            return (go, RetainUntilDestroyed(go, lease), new ActionDisposable(() => { if (go) UnityEngine.Object.Destroy(go); }));
        }
        internal static IDisposable RetainUntilDestroyed(GameObject instance, IDisposable lease)
        {
            var manager = AddressablesManager.Instance;
            if (manager != null) manager.TrackInstance(instance); // Null during application shutdown; the lease still returns.
            return new ActionDisposable(() => ReturnAfterDestroy(instance, lease, manager).Forget());
        }
        static async UniTaskVoid ReturnAfterDestroy(GameObject instance, IDisposable lease, AddressablesManager manager)
        {
            if (instance) await UniTask.WaitUntil(() => !instance);
            await UniTask.Yield(PlayerLoopTiming.LastPostLateUpdate);
            if (manager != null) manager.UntrackInstance(instance);
            lease.Dispose();
        }
        sealed class ActionDisposable : IDisposable
        {
            Action _dispose;
            public ActionDisposable(Action dispose) => _dispose = dispose;
            public void Dispose() => Interlocked.Exchange(ref _dispose, null)?.Invoke();
        }
    }
}
