using System;
using System.Collections;
using System.Threading;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.TestTools;
using jjevol.Audio;
using jjevol.Effect;

namespace jjevol.Resource.Coexist.Tests
{
    public sealed class ResourceCoexistTests
    {
        sealed class Provider:ResourceProviderBase
        {
            readonly string id="shared-sdk-"+Guid.NewGuid();public override string ProviderId=>id;
            public int Loads,Releases;
            public override void Provide(ProvideHandle handle)
            {
                Loads++;
                UnityEngine.Object value=handle.Location.ResourceType==typeof(AudioClip)?(UnityEngine.Object)AudioClip.Create("shared-test",4410,1,44100,false):new GameObject("shared-prefab");
                handle.Complete(value,true,null);
            }
            public override void Release(IResourceLocation location,object asset){Releases++;UnityEngine.Object.Destroy((UnityEngine.Object)asset);}
        }
        Provider provider;ResourceLocationMap locator;AddressablesManager manager;
        [UnitySetUp] public IEnumerator Setup()
        {
            var init=Addressables.InitializeAsync(false);yield return init;Assert.AreEqual(AsyncOperationStatus.Succeeded,init.Status);Addressables.Release(init);
            provider=new Provider();Addressables.ResourceManager.ResourceProviders.Add(provider);locator=new ResourceLocationMap("shared-"+Guid.NewGuid());
            locator.Add("shared-prefab",new ResourceLocationBase("shared-prefab","prefab",provider.ProviderId,typeof(GameObject)));
            locator.Add("shared-clip",new ResourceLocationBase("shared-clip","clip",provider.ProviderId,typeof(AudioClip)));
            Addressables.AddResourceLocator(locator);manager=new GameObject("shared-manager").AddComponent<AddressablesManager>();
        }
        [UnityTearDown]public IEnumerator Cleanup()
        {
            manager.ReleaseAllLoadedAssets();UnityEngine.Object.Destroy(manager.gameObject);yield return null;yield return null;
            Addressables.RemoveResourceLocator(locator);Addressables.ResourceManager.ResourceProviders.Remove(provider);
        }
        [UnityTest]public IEnumerator GeneralAndEffectProvidersReturnOnlyTheirOwnSdkAcquisition()
        {
            var general=AddressablesManager.LoadAssetAsync<GameObject>("shared-prefab").AsTask();while(!general.IsCompleted)yield return null;Assert.IsFalse(general.IsFaulted);
            var effects=new AddressablesEffectPrefabProvider();var effect=effects.LoadAsync("shared-prefab",CancellationToken.None).AsTask();while(!effect.IsCompleted)yield return null;
            Assert.IsFalse(effect.IsFaulted);Assert.AreSame(general.Result,effect.Result.Prefab);Assert.AreEqual(1,provider.Loads);
            AddressablesManager.ReleaseAsset("shared-prefab");Assert.AreEqual(0,provider.Releases);Assert.AreEqual(0,manager.GetRefCount("shared-prefab"));
            effect.Result.Dispose();yield return null;Assert.AreEqual(1,provider.Releases);
        }
        [UnityTest]public IEnumerator GeneralAndAudioClipLeasesRetainIndependentSdkOwnership()
        {
            var general=AddressablesManager.LoadAssetAsync<AudioClip>("shared-clip").AsTask();while(!general.IsCompleted)yield return null;Assert.IsFalse(general.IsFaulted);
            using var audio=new AddressablesClipProvider();var clip=audio.AcquireAsync(AudioTrack.Sfx,"shared-clip");while(!clip.IsCompleted)yield return null;
            Assert.IsFalse(clip.IsFaulted);Assert.AreSame(general.Result,clip.Result.Clip);Assert.AreEqual(1,provider.Loads);
            clip.Result.Dispose();Assert.AreEqual(0,provider.Releases);Assert.AreEqual(1,manager.GetRefCount("shared-clip"));
            AddressablesManager.ReleaseAsset("shared-clip");yield return null;Assert.AreEqual(1,provider.Releases);
        }
    }
}
