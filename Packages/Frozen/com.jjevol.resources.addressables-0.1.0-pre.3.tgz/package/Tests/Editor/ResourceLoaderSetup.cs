using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace jjevol.Resource.Tests
{
    // Kept apart from ResourceLoaderSetup: a fixture that implements IPrebuildSetup runs Setup in EditMode too,
    // where the untitled scene rejects the additive scenes that Setup creates.
    public sealed class ResourceLoaderPlatformTests
    {
        [NUnit.Framework.Test]
        public void PlatformFolderMatchesTheActiveAddressablesBuildTarget()
        {
            string expected;
            switch (EditorUserBuildSettings.activeBuildTarget)
            {
                case BuildTarget.StandaloneWindows:
                case BuildTarget.StandaloneWindows64: expected = "Windows"; break;
                case BuildTarget.Android: expected = "Android"; break;
                case BuildTarget.iOS: expected = "iOS"; break;
                case BuildTarget.StandaloneOSX: expected = "OSX"; break;
                case BuildTarget.StandaloneLinux64: expected = "Linux"; break;
                default: NUnit.Framework.Assert.Ignore("Run with a supported desktop/mobile target selected."); return;
            }
            NUnit.Framework.Assert.That(AddressablesManager.BuildTarget, NUnit.Framework.Is.EqualTo(expected));
        }
    }

    public sealed class ResourceLoaderSetup : IPrebuildSetup, IPostBuildCleanup
    {
        internal const string PreviousDefaultKey = "JJEvolTestsPreviousDefaultSettings";
        internal const string PreviousPathKey = "JJEvolTestsPreviousRuntimeDataPath";
        const string NothingSaved = "nothing-saved";

        public void Setup()
        {
            string root="Assets/JJEvolResourceTests_"+Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets",Path.GetFileName(root));
            var settings=AddressableAssetSettings.Create(root,"Settings",true,true);
            for(int i=0;i<settings.DataBuilders.Count;i++)if(settings.DataBuilders[i] is BuildScriptFastMode)settings.ActivePlayModeDataBuilderIndex=i;
            var prior=SceneManager.GetActiveScene();
            for(int i=1;i<=2;i++)
            {
                var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
                var marker=new GameObject("Step9-scene-marker");SceneManager.MoveGameObjectToScene(marker,scene);
                string path=root+"/FixtureScene"+i+".unity";EditorSceneManager.SaveScene(scene,path);
                if(prior.IsValid())SceneManager.SetActiveScene(prior);EditorSceneManager.CloseScene(scene,true);
                var entry=settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path),settings.DefaultGroup);entry.address="Step9/scene-"+i;
            }
            var prefab=new GameObject("Step9-prefab-fixture");new GameObject("fixture-child").transform.SetParent(prefab.transform,false);
            PrefabUtility.SaveAsPrefabAsset(prefab,root+"/Fixture.prefab");UnityEngine.Object.DestroyImmediate(prefab);
            var texture=new Texture2D(2,2);texture.SetPixel(0,0,Color.green);texture.Apply();AssetDatabase.CreateAsset(texture,root+"/FixtureTexture.asset");
            File.WriteAllText(root+"/FixtureText.txt","step9-independent-text");AssetDatabase.Refresh();
            foreach(var pair in new[]{("/Fixture.prefab","Step9/builtin-prefab"),("/FixtureTexture.asset","Step9/builtin-texture"),("/FixtureText.txt","Step9/builtin-text")})
                settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(root+pair.Item1),settings.DefaultGroup).address=pair.Item2;
            EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();
            SessionState.SetString("Step9ResourceRoot",root);
            SavePreviousPath();
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
            // Entering PlayMode rebuilds the default Settings and overwrites the runtime path, so a Host that has
            // default Settings must use this fixture's Settings for the run. A Host without them is left unchanged.
            if(AddressableAssetSettingsDefaultObject.SettingsExists)
            {
                SavePreviousDefault();
                AddressableAssetSettingsDefaultObject.Settings=settings;
            }
        }
        public void Cleanup()
        {
            RestorePreviousPath();
            RestorePreviousDefault();
            string root=SessionState.GetString("Step9ResourceRoot","");
            if(root.StartsWith("Assets/JJEvolResourceTests_")&&AssetDatabase.IsValidFolder(root))
            {
                if(!string.Equals(Path.GetDirectoryName(Path.GetFullPath(root)),Path.GetFullPath(Application.dataPath),StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Unsafe fixture cleanup");
                AssetDatabase.DeleteAsset(root);
            }
            SessionState.EraseString("Step9ResourceRoot");
        }

        // Every fixture uses this key, so in a chained run the first one's save, the Host's own Settings, is the one kept.
        internal static void SavePreviousDefault()
        {
            if (SessionState.GetString(PreviousDefaultKey, "") != "") return;
            SessionState.SetString(PreviousDefaultKey, AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(AddressableAssetSettingsDefaultObject.Settings)));
        }

        // Setting a deleted asset would clear the Host's default Settings GUID.
        internal static void RestorePreviousDefault()
        {
            string previous = SessionState.GetString(PreviousDefaultKey, "");
            SessionState.EraseString(PreviousDefaultKey);
            if (previous == "") return;
            var settings = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(AssetDatabase.GUIDToAssetPath(previous));
            if (settings != null) AddressableAssetSettingsDefaultObject.Settings = settings;
        }

        // An empty path is a real previous value, so "nothing saved" needs its own marker. The first fixture's save is
        // kept, and the later Cleanup in a chain finds nothing to restore instead of erasing what the first one put back.
        internal static void SavePreviousPath()
        {
            if (SessionState.GetString(PreviousPathKey, NothingSaved) != NothingSaved) return;
            SessionState.SetString(PreviousPathKey, SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, ""));
        }

        internal static void RestorePreviousPath()
        {
            string previous = SessionState.GetString(PreviousPathKey, NothingSaved);
            if (previous == NothingSaved) return;
            SessionState.EraseString(PreviousPathKey);
            bool deleted = previous.StartsWith("GUID:") && AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(AssetDatabase.GUIDToAssetPath(previous.Substring(5))) == null;
            if (previous == "" || deleted) SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            else SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, previous);
        }
    }
}
