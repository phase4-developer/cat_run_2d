using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEngine.AddressableAssets;

namespace jjevol.Resource.Tests
{
    public sealed class ResourceLoaderSetupDefaultSettingsTests
    {
        const string Deleted = "0123456789abcdef0123456789abcdef";
        const string Unset = "unset";
        string _saved, _savedPathKey, _savedPath;

        static string RuntimePath => SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, Unset);
        static string SavedPath => SessionState.GetString(ResourceLoaderSetup.PreviousPathKey, Unset);
        static void Put(string key, string value) { if (value == Unset) SessionState.EraseString(key); else SessionState.SetString(key, value); }

        [SetUp] public void SetUp()
        {
            _saved = SessionState.GetString(ResourceLoaderSetup.PreviousDefaultKey, ""); SessionState.EraseString(ResourceLoaderSetup.PreviousDefaultKey);
            _savedPathKey = SavedPath; _savedPath = RuntimePath; SessionState.EraseString(ResourceLoaderSetup.PreviousPathKey);
        }
        [TearDown] public void TearDown()
        {
            if (_saved == "") SessionState.EraseString(ResourceLoaderSetup.PreviousDefaultKey);
            else SessionState.SetString(ResourceLoaderSetup.PreviousDefaultKey, _saved);
            Put(ResourceLoaderSetup.PreviousPathKey, _savedPathKey); Put(Addressables.kAddressablesRuntimeDataPath, _savedPath);
        }

        [Test] public void ASavedPreviousValueSurvivesAChainedFixture()
        {
            SessionState.SetString(ResourceLoaderSetup.PreviousDefaultKey, "first-fixture-saved-this");
            ResourceLoaderSetup.SavePreviousDefault();
            Assert.That(SessionState.GetString(ResourceLoaderSetup.PreviousDefaultKey, ""), Is.EqualTo("first-fixture-saved-this"));
        }
        [Test] public void TheFirstFixtureSavesTheDefaultSettings()
        {
            Assume.That(AddressableAssetSettingsDefaultObject.SettingsExists, "Needs a Host with default Settings.");
            ResourceLoaderSetup.SavePreviousDefault();
            Assert.That(SessionState.GetString(ResourceLoaderSetup.PreviousDefaultKey, ""), Is.EqualTo(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(AddressableAssetSettingsDefaultObject.Settings))));
        }
        [Test] public void ADeletedPreviousAssetIsNeverRestored()
        {
            var current = AddressableAssetSettingsDefaultObject.GetSettings(false);
            SessionState.SetString(ResourceLoaderSetup.PreviousDefaultKey, Deleted);
            ResourceLoaderSetup.RestorePreviousDefault();
            Assert.That(AddressableAssetSettingsDefaultObject.GetSettings(false), Is.SameAs(current));
            Assert.That(SessionState.GetString(ResourceLoaderSetup.PreviousDefaultKey, ""), Is.Empty);
        }
        [Test] public void AnEmptySavedPathSurvivesAChainedFixture()
        {
            SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            ResourceLoaderSetup.SavePreviousPath();
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:" + Deleted);
            ResourceLoaderSetup.SavePreviousPath();
            Assert.That(SavedPath, Is.Empty);
            ResourceLoaderSetup.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo(Unset));
        }
        [Test] public void ADeletedPreviousPathIsNeverRestored()
        {
            SessionState.SetString(ResourceLoaderSetup.PreviousPathKey, "GUID:" + Deleted);
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:fixture-being-removed");
            ResourceLoaderSetup.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo(Unset));
            Assert.That(SavedPath, Is.EqualTo(Unset));
        }
        [Test] public void TheLaterCleanupInAChainLeavesTheRestoredPathAlone()
        {
            SessionState.SetString(ResourceLoaderSetup.PreviousPathKey, "Host/Path");
            ResourceLoaderSetup.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo("Host/Path"));
            ResourceLoaderSetup.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo("Host/Path"));
        }
    }
}
