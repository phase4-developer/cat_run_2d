using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.Resource.Tests
{
    [PrebuildSetup("jjevol.Resource.Tests.ResourceLoaderSetup")]
    [PostBuildCleanup("jjevol.Resource.Tests.ResourceLoaderSetup")]
    public sealed class ResourceLoaderTests
    {
        sealed class Provider : ResourceProviderBase
        {
            readonly string id="step9-"+Guid.NewGuid().ToString("N");
            public override string ProviderId=>id;
            public int Loads,Releases;
            public bool Hold,Fail;
            public string FailKey;
            public Action OnRelease;
            public readonly List<ProvideHandle> Pending=new();
            public readonly List<UnityEngine.Object> Returned=new();
            public override void Provide(ProvideHandle handle){Loads++;if(Hold)Pending.Add(handle);else Finish(handle);}
            void Finish(ProvideHandle handle)
            {
                if(Fail || handle.Location.InternalId == FailKey){handle.Complete<UnityEngine.Object>(null,false,new InvalidOperationException("step9 expected provider failure"));return;}
                UnityEngine.Object asset=handle.Location.ResourceType==typeof(Texture2D)?(UnityEngine.Object)new Texture2D(2,2):new GameObject("SDK-source-prefab");
                handle.Complete(asset,true,null);
            }
            public void FinishPending(){foreach(var handle in Pending)Finish(handle);Pending.Clear();}
            public override void Release(IResourceLocation location,object asset){Releases++;OnRelease?.Invoke();if(asset is UnityEngine.Object value){Returned.Add(value);Object.Destroy(value);}}
        }
        sealed class SessionProbe:PersistentSingleton<SessionProbe>{}
        sealed class HeldInitOperation:AsyncOperationBase<IResourceLocator>
        {
            protected override void Execute(){}
            public void Finish(bool success)=>Complete(success?Addressables.ResourceLocators.First():null,success,success?null:new InvalidOperationException("step9 expected init failure"));
        }
        sealed class CountingDisposable:IDisposable
        {
            public int Count;
            public void Dispose()=>Count++;
        }
        Provider provider;ResourceLocationMap locator;AddressablesManager manager;
        readonly List<GameObject> owned=new();
        Action<AsyncOperationHandle,Exception> previousExceptionHandler;
        static IEnumerator Complete(Task task)
        {
            float end=Time.realtimeSinceStartup+6;
            while(!task.IsCompleted&&Time.realtimeSinceStartup<end)yield return null;
            Assert.IsTrue(task.IsCompleted,"SDK operation timed out");if(task.IsFaulted)Assert.Fail(task.Exception.ToString());
        }
        static IEnumerator Until(Func<bool> predicate)
        {
            float end=Time.realtimeSinceStartup+6;while(!predicate()&&Time.realtimeSinceStartup<end)yield return null;
            Assert.IsTrue(predicate(),"Lifetime condition timed out");
        }
        AddressableScopeMB Scope()
        {
            var go=new GameObject("step9-scope");owned.Add(go);return go.AddComponent<AddressableScopeMB>();
        }
        static void Field(object obj,string name,object value)=>obj.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(obj,value);
        // Installs a pending operation the way the SDK does while another caller's initialization is running.
        static AsyncOperationHandle<IResourceLocator> PendingInit(out HeldInitOperation operation,bool autoRelease)
        {
            operation=new HeldInitOperation();var handle=Addressables.ResourceManager.StartOperation(operation,default);
            if(autoRelease)handle.ReleaseHandleOnCompletion();
            var impl=typeof(Addressables).GetProperty("Instance",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);
            impl.GetType().GetField("m_InitializationOperation",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(impl,handle);
            AddressablesManager.Isinitialized=false;return handle;
        }
        int LoadLocks()=>((IDictionary)typeof(AddressablesManager).GetField("_loadLocks",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(manager)).Count;
        int SceneLoads()=>((ICollection<AsyncOperationHandle<SceneInstance>>)typeof(AddressablesManager).GetField("_sceneLoads",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(manager)).Count;
        static int ProbeQuitSubscribers()
        {
            var subscribers=(Delegate)typeof(Application).GetField("quitting",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);
            return subscribers==null?0:subscribers.GetInvocationList().Count(entry=>entry.Method.DeclaringType==typeof(PersistentSingleton<SessionProbe>));
        }
        static List<string> CaptureWarnings(string text,out Application.LogCallback capture)
        {
            var warnings=new List<string>();
            capture=(message,_,type)=>{if(type==LogType.Warning&&message.Contains(text))warnings.Add(message);};
            Application.logMessageReceived+=capture;return warnings;
        }
        [UnitySetUp] public IEnumerator Setup()
        {
            var initialized=Addressables.InitializeAsync(false);yield return initialized;
            Assert.AreEqual(AsyncOperationStatus.Succeeded,initialized.Status);Addressables.Release(initialized);
            previousExceptionHandler=ResourceManager.ExceptionHandler;
            provider=new Provider();Addressables.ResourceManager.ResourceProviders.Add(provider);locator=new ResourceLocationMap("step9-"+Guid.NewGuid());
            var prefab=new ResourceLocationBase("prefab","prefab",provider.ProviderId,typeof(GameObject));
            var other=new ResourceLocationBase("other","other",provider.ProviderId,typeof(GameObject));
            locator.Add("prefab",prefab);locator.Add("other",other);locator.Add("label",prefab);locator.Add("label",other);
            locator.Add("texture",new ResourceLocationBase("texture","texture",provider.ProviderId,typeof(Texture2D)));
            Addressables.AddResourceLocator(locator);manager=new GameObject("step9-manager").AddComponent<AddressablesManager>();yield return null;
        }
        [UnityTearDown] public IEnumerator Cleanup()
        {
            provider.Hold=false;provider.Fail=false;provider.FinishPending();
            foreach(var go in owned)if(go)Object.Destroy(go);owned.Clear();yield return null;
            // Clean even the original implementation's failed-test cache, without changing production behavior.
            if(!ReferenceEquals(manager,null))
            {
                var field=typeof(AddressablesManager).GetField("_assetRefInfos",BindingFlags.Instance|BindingFlags.NonPublic);
                var entries=(IDictionary)field.GetValue(manager);
                foreach(var entry in entries.Values.Cast<object>().ToArray())
                {
                    var handle=(AsyncOperationHandle)entry.GetType().GetProperty("handle").GetValue(entry);
                    if(handle.IsValid())Addressables.Release(handle);
                }
                entries.Clear();
            }
            if(manager)Object.Destroy(manager.gameObject);yield return null;yield return null;
            // Scene cleanup uses real SDK unload operations.
            for(int i=SceneManager.sceneCount-1;i>=0;i--){var scene=SceneManager.GetSceneAt(i);if(scene.name.StartsWith("FixtureScene"))yield return SceneManager.UnloadSceneAsync(scene);}
            ResourceManager.ExceptionHandler=previousExceptionHandler;
            Addressables.RemoveResourceLocator(locator);Addressables.ResourceManager.ResourceProviders.Remove(provider);
        }
        [UnityTest] public IEnumerator RepeatedLoadsGetAndReadOnlyPeekKeepOriginalCounts()
        {
            var a=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(a);
            var b=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(b);
            Assert.AreSame(a.Result,b.Result);Assert.AreEqual(1,provider.Loads);Assert.AreEqual(2,manager.GetRefCount("prefab"));
            Assert.IsTrue(manager.TryGetLoadedAsset("prefab",out GameObject peek));Assert.AreSame(a.Result,peek);Assert.AreEqual(2,manager.GetRefCount("prefab"));
            Assert.AreSame(a.Result,manager.GetPrefab("prefab"));Assert.AreEqual(3,manager.GetRefCount("prefab"));
            AddressablesManager.ReleaseAsset(new[]{"prefab","prefab"});Assert.AreEqual(1,manager.GetRefCount("prefab"));Assert.AreEqual(0,provider.Releases);
            AddressablesManager.ReleaseAsset("prefab");AddressablesManager.ReleaseAsset("prefab");yield return null;Assert.AreEqual(1,provider.Releases);
        }
        [UnityTest] public IEnumerator ConcurrentSameKeyRequestsShareSdkOperation()
        {
            provider.Hold=true;var a=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();var b=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();
            yield return Until(()=>provider.Pending.Count==1);provider.FinishPending();yield return Complete(Task.WhenAll(a,b));
            Assert.AreEqual(1,provider.Loads);Assert.AreEqual(2,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator UnusedCleanupKeepsOwnersAndReturnsOnlyUnownedCachedAssets()
        {
            var ownedAsset = AddressableScope.Get<GameObject>("prefab").AsTask();
            yield return Complete(ownedAsset);
            var unusedAsset = AddressablesManager.LoadAssetAsync<GameObject>("other").AsTask();
            yield return Complete(unusedAsset);
            AddressablesManager.ReleaseAsset("other", 60);

            manager.ReleaseUnusedAssets();
            Assert.That(AddressablesManager.IsLoaded("other"), Is.False);
            Assert.That(manager.GetRefCount("prefab"), Is.EqualTo(1));
            Assert.That(ownedAsset.Result.Asset, Is.Not.Null);
            Assert.That(provider.Releases, Is.EqualTo(1));
            manager.ReleaseUnusedAssets();
            Assert.That(provider.Releases, Is.EqualTo(1));

            ownedAsset.Result.Dispose();
            yield return null;
            Assert.That(provider.Releases, Is.EqualTo(2));
        }

        [UnityTest] public IEnumerator UnusedCleanupDoesNotInvalidateAnInflightAcquisition()
        {
            provider.Hold = true;
            var load = AddressableScope.Get<GameObject>("prefab").AsTask();
            yield return Until(() => provider.Pending.Count == 1);
            manager.ReleaseUnusedAssets();
            provider.FinishPending();
            yield return Complete(load);
            Assert.That(load.Result.Asset, Is.Not.Null);
            Assert.That(manager.GetRefCount("prefab"), Is.EqualTo(1));
            load.Result.Dispose();
            yield return null;
            Assert.That(provider.Releases, Is.EqualTo(1));
        }
        [UnityTest] public IEnumerator TextureLabelAndDistinctKeyBatchUseRealSdk()
        {
            var texture=AddressablesManager.LoadAssetAsync<Texture2D>("texture").AsTask();yield return Complete(texture);Assert.AreEqual(2,texture.Result.width);
            var label=AddressablesManager.LoadAssetsAsync<GameObject>("label").AsTask();yield return Complete(label);Assert.AreEqual(2,label.Result.Count);Assert.AreEqual(1,manager.GetRefCount("label"));
            AddressablesManager.ReleaseAsset("label");AddressablesManager.ReleaseAsset("texture");yield return null;
            var keys=AddressablesManager.LoadAssetsAsync<GameObject>(new[]{"prefab","prefab","other","",null},CancellationToken.None).AsTask();yield return Complete(keys);
            Assert.AreEqual(2,keys.Result.Count);Assert.AreEqual(1,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator LeaseAndMultiScopeReturnExactlyTheirOwnAcquisitions()
        {
            var task=AddressableScope.Get<GameObject>("prefab").AsTask();yield return Complete(task);var lease=task.Result;
            var scope=new AddressableMultiScope();Assert.IsNotNull(scope.AddToScope<GameObject>("prefab"));Assert.AreEqual(2,manager.GetRefCount("prefab"));
            scope.Dispose();scope.Dispose();Assert.AreEqual(1,manager.GetRefCount("prefab"));lease.Dispose();lease.Dispose();Assert.IsNull(lease.Asset);Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator DisposedMultiScopeCannotAcquireAndLeak()
        {
            var load=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(load);
            var scope=new AddressableMultiScope();scope.Dispose();Assert.Throws<ObjectDisposedException>(()=>scope.AddToScope<GameObject>("prefab"));Assert.AreEqual(1,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator ScopeMbCanLoadAndReleaseAgainAfterReleaseAll()
        {
            var scope=Scope();var first=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Complete(first);scope.ReleaseAll();yield return null;
            var second=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Complete(second);scope.ReleaseAll();yield return null;Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator DestroyedScopeRejectsAndReturnsLateLoad()
        {
            var scope=Scope();provider.Hold=true;var task=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Until(()=>provider.Pending.Count==1);
            Object.Destroy(scope.gameObject);yield return null;provider.FinishPending();yield return Complete(task);
            Assert.IsNull(task.Result);Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator ExplicitReleaseAllInvalidatesPendingScopeLoad()
        {
            var scope=Scope();provider.Hold=true;var task=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Until(()=>provider.Pending.Count==1);
            scope.ReleaseAll();provider.FinishPending();yield return Complete(task);Assert.IsNull(task.Result);Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator PrefabInstanceIsDestroyedBeforeItsSourceHandleIsReturned()
        {
            var scope=Scope();var task=scope.InstantiateAsync("prefab").AsTask();yield return Complete(task);var instance=task.Result;owned.Add(instance);
            bool early=false;provider.OnRelease=()=>early|=instance!=null;scope.ReleaseAll();yield return null;yield return null;
            Assert.IsFalse(early,"SDK source was released while clone was alive");Assert.IsTrue(instance==null);Assert.AreEqual(1,provider.Releases);
        }
        [UnityTest] public IEnumerator ExplicitInstanceLeaseCannotReturnPrefabBeforeDestroyToken()
        {
            var task=AddressableScope.InstantiateWithLease("prefab").AsTask();yield return Complete(task);owned.Add(task.Result.instance);
            task.Result.lease.Dispose();Assert.AreEqual(1,manager.GetRefCount("prefab"));
            task.Result.destroyOnDispose.Dispose();yield return null;yield return null;Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator ScopeDisableCanBeUsedInMultipleEnableCycles()
        {
            var scope=Scope();Field(scope,"_releaseOnDisable",true);var task=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Complete(task);
            scope.gameObject.SetActive(false);yield return null;scope.gameObject.SetActive(true);
            task=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Complete(task);scope.gameObject.SetActive(false);yield return null;Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator ManagerDisableRetainsReferencesAndResumesDelayedRelease()
        {
            var task=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(task);manager.gameObject.SetActive(false);
            AddressablesManager.ReleaseAsset("prefab",0.1f);yield return new WaitForSecondsRealtime(0.2f);manager.gameObject.SetActive(true);yield return Until(()=>provider.Releases==1);
        }
        [UnityTest] public IEnumerator DestroyManagerReturnsOwnedSdkHandles()
        {
            var task=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(task);Object.Destroy(manager.gameObject);yield return null;yield return null;Assert.AreEqual(1,provider.Releases);
        }
        [UnityTest] public IEnumerator DestroyManagerDuringLoadCannotCacheALateResult()
        {
            provider.Hold=true;var task=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Until(()=>provider.Pending.Count==1);
            Object.Destroy(manager.gameObject);yield return null;provider.FinishPending();yield return Complete(task);yield return null;Assert.IsNull(task.Result);Assert.AreEqual(1,provider.Releases);
        }
        [UnityTest] public IEnumerator OldLeaseCannotReleaseANewManagerAcquisition()
        {
            var task=AddressableScope.Get<GameObject>("prefab").AsTask();yield return Complete(task);var old=task.Result;
            Object.Destroy(manager.gameObject);yield return null;yield return null;manager=new GameObject("replacement-manager").AddComponent<AddressablesManager>();
            var next=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(next);old.Dispose();Assert.AreEqual(1,manager.GetRefCount("prefab"));
        }
        [UnityTest] public IEnumerator CancellationAndDelayedReacquisitionPreserveOutstandingOwner()
        {
            using var cts=new CancellationTokenSource();cts.Cancel();var canceled=AddressablesManager.LoadAssetAsync<GameObject>("prefab",cts.Token).AsTask();yield return Complete(canceled);Assert.IsNull(canceled.Result);
            var task=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(task);AddressablesManager.ReleaseAsset("prefab",0.1f);
            Assert.IsNotNull(manager.GetAsset<GameObject>("prefab"));yield return new WaitForSecondsRealtime(0.2f);Assert.AreEqual(0,provider.Releases);AddressablesManager.ReleaseAsset("prefab");
        }
        [UnityTest] public IEnumerator RepeatedLoadReleaseDoesNotAccumulateProviderReferences()
        {
            for(int i=0;i<8;i++){var task=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(task);AddressablesManager.ReleaseAsset("prefab");yield return null;}
            Assert.AreEqual(8,provider.Loads);Assert.AreEqual(8,provider.Releases);
        }
        [UnityTest] public IEnumerator ActualAddressableSceneLoadsAndUnloads()
        {
            var handle=manager.LoadSceneAsync("Step9/scene-1",LoadSceneMode.Additive);yield return handle;
            Assert.AreEqual(AsyncOperationStatus.Succeeded,handle.Status);var instance=handle.Result;Assert.IsTrue(instance.Scene.isLoaded);Assert.Contains(instance,manager.loadedScenes);
            var unload=manager.UnloadSceneAsync(instance);yield return unload;yield return null;Assert.IsFalse(instance.Scene.isLoaded);Assert.IsEmpty(manager.loadedScenes);
        }
        [UnityTest] public IEnumerator SceneKeyDifferentFromSceneNameCanReloadWithoutUiDependency()
        {
            var load=manager.LoadSceneAsync("Step9/scene-1",LoadSceneMode.Additive);yield return load;Assert.AreEqual(AsyncOperationStatus.Succeeded,load.Status);SceneManager.SetActiveScene(load.Result.Scene);
            int called=0;manager.AfterSceneReload=()=>{called++;return UniTask.CompletedTask;};yield return manager.ReloadActiveSceneAsync();Assert.AreEqual(1,called);Assert.AreEqual(1,manager.loadedScenes.Count);
        }
        [UnityTest] public IEnumerator LabelFailureDoesNotGrowSdkOperationCache()
        {
            var errors=new List<Exception>();ResourceManager.ExceptionHandler=(_,error)=>errors.Add(error);provider.Fail=true;
            int Count()=> (int)typeof(ResourceManager).GetProperty("OperationCacheCount",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(Addressables.ResourceManager);
            int previous=-1;
            for(int i=0;i<3;i++)
            {
                var task=AddressablesManager.LoadAssetsAsync<GameObject>("label").AsTask();yield return Until(()=>task.IsCompleted);Assert.IsTrue(task.IsFaulted);_ = task.Exception;
                yield return null;if(previous>=0)Assert.AreEqual(previous,Count(),"Failed group handle leaked in real ResourceManager cache");previous=Count();
            }
            Assert.IsNotEmpty(errors);
        }
        [UnityTest]public IEnumerator InitAndRepeatInitializationUseActualSdkHandle()
        {
            var init=manager.InitAsync().AsTask();yield return Complete(init);Assert.IsTrue(AddressablesManager.Isinitialized);
            yield return Complete(manager.InitAsync().AsTask());
        }
        [UnityTest]public IEnumerator InFlightCancellationDoesNotCancelAnotherOwner()
        {
            provider.Hold=true;using var cts=new CancellationTokenSource();
            var first=AddressablesManager.LoadAssetAsync<GameObject>("prefab",cts.Token).AsTask();
            var second=AddressablesManager.LoadAssetAsync<GameObject>("prefab",CancellationToken.None).AsTask();
            yield return Until(()=>provider.Pending.Count==1);cts.Cancel();yield return null;yield return null;
            provider.Hold=false;provider.FinishPending();yield return Complete(Task.WhenAll(first,second));Assert.IsNull(first.Result);Assert.IsNotNull(second.Result);
            Assert.AreEqual(1,manager.GetRefCount("prefab"));Assert.IsFalse(provider.Returned.Any(value=>ReferenceEquals(value,second.Result)));
            AddressablesManager.ReleaseAsset("prefab");yield return Until(()=>provider.Releases==provider.Loads);
        }
        [UnityTest]public IEnumerator OldLeaseAfterForceClearCannotReturnNewCacheEntry()
        {
            var old=AddressableScope.Get<GameObject>("prefab").AsTask();yield return Complete(old);manager.ReleaseAllLoadedAssets();yield return null;
            var current=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(current);old.Result.Dispose();Assert.AreEqual(1,manager.GetRefCount("prefab"));
        }
        [UnityTest]public IEnumerator ManualTrackedCloneIsDestroyedBeforeScopeAssetReturn()
        {
            var scope=Scope();var asset=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Complete(asset);
            var instance=Object.Instantiate(asset.Result);owned.Add(instance);scope.TrackInstance(instance);bool early=false;
            provider.OnRelease=()=>early|=instance!=null;scope.ReleaseAll();yield return null;yield return null;
            Assert.IsFalse(early);Assert.IsTrue(instance==null);Assert.AreEqual(1,provider.Releases);
        }
        [UnityTest]public IEnumerator ManagerDestructionUnloadsRealAddressableScene()
        {
            var load=manager.LoadSceneAsync("Step9/scene-1",LoadSceneMode.Additive);yield return load;Assert.AreEqual(AsyncOperationStatus.Succeeded,load.Status);
            var scene=load.Result.Scene;Object.Destroy(manager.gameObject);yield return Until(()=>!scene.isLoaded);
        }
        [UnityTest]public IEnumerator DeferredSceneActivationCanActivateAndUnload()
        {
            var load=manager.LoadSceneAsync("Step9/scene-2",LoadSceneMode.Additive,false);yield return load;
            Assert.AreEqual(AsyncOperationStatus.Succeeded,load.Status);var instance=load.Result;
            yield return instance.ActivateAsync();Assert.IsTrue(instance.Scene.isLoaded);yield return manager.UnloadSceneAsync(instance);yield return null;
            Assert.IsFalse(instance.Scene.isLoaded);
        }
        [UnityTest]public IEnumerator FailedBatchReturnsAnySuccessfulAcquisitions()
        {
            var errors=new List<Exception>();ResourceManager.ExceptionHandler=(_,error)=>errors.Add(error);provider.FailKey="other";
            var task=AddressablesManager.LoadAssetsAsync<GameObject>(new[]{"prefab","other"},CancellationToken.None).AsTask();
            yield return Until(()=>task.IsCompleted);Assert.IsTrue(task.IsFaulted);_ = task.Exception;yield return null;
            Assert.AreEqual(0,manager.GetRefCount("prefab"),"Batch exception returned no ownership to caller");Assert.IsNotEmpty(errors);
        }
        [UnityTest]public IEnumerator RealPrefabTextureAndTextAssetsUseSdkAssetDatabaseProviders()
        {
            var text=AddressablesManager.LoadAssetAsync<TextAsset>("Step9/builtin-text").AsTask();yield return Complete(text);Assert.AreEqual("step9-independent-text",text.Result.text);
            var texture=AddressablesManager.LoadAssetAsync<Texture2D>("Step9/builtin-texture").AsTask();yield return Complete(texture);Assert.AreEqual(2,texture.Result.width);
            var scope=Scope();var prefab=scope.InstantiateAsync("Step9/builtin-prefab").AsTask();yield return Complete(prefab);owned.Add(prefab.Result);
            Assert.IsNotNull(prefab.Result.transform.Find("fixture-child"));scope.ReleaseAll();yield return null;yield return null;
            Assert.IsTrue(prefab.Result==null);Assert.AreEqual(0,manager.GetRefCount("Step9/builtin-prefab"));
            AddressablesManager.ReleaseAsset("Step9/builtin-text");AddressablesManager.ReleaseAsset("Step9/builtin-texture");Assert.IsFalse(AddressablesManager.IsLoaded("Step9/builtin-text"));
        }
        [UnityTest]public IEnumerator ManagerShutdownDestroysManagedClonesBeforeReturningSource()
        {
            var task=AddressableScope.InstantiateWithLease("prefab").AsTask();yield return Complete(task);var instance=task.Result.instance;owned.Add(instance);
            bool early=false;provider.OnRelease=()=>early|=instance!=null;Object.Destroy(manager.gameObject);yield return Until(()=>provider.Releases==1);
            Assert.IsTrue(instance==null);Assert.IsFalse(early);Assert.AreEqual(1,provider.Releases);task.Result.lease.Dispose();task.Result.destroyOnDispose.Dispose();
        }
        [UnityTest]public IEnumerator QuitCallbackClearingSingletonDoesNotSkipDestroyCleanup()
        {
            var task=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(task);
            typeof(PersistentSingleton<AddressablesManager>).GetMethod("OnApplicationQuit",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(manager,null);
            Assert.IsFalse(AddressablesManager.HasInstance);Object.Destroy(manager.gameObject);
            yield return Until(()=>provider.Releases==1);
            AddressablesManager.applicationIsQuitting=false;
        }
        [UnityTest]public IEnumerator ConcurrentInitSharesAnotherOwnersOperationWithoutReleasingIt()
        {
            var handle=PendingInit(out var operation,false);var first=manager.InitAsync().AsTask();var second=manager.InitAsync().AsTask();
            yield return null;operation.Finish(true);yield return Complete(Task.WhenAll(first,second));yield return null;
            Assert.IsTrue(AddressablesManager.Isinitialized);Assert.IsTrue(handle.IsValid(),"InitAsync released a handle it does not own");
            Addressables.Release(handle);Assert.IsFalse(handle.IsValid());
        }
        [UnityTest]public IEnumerator InitFailureIsReportedByExceptionAfterAutoRelease()
        {
            var errors=new List<Exception>();ResourceManager.ExceptionHandler=(_,error)=>errors.Add(error);
            var handle=PendingInit(out var operation,true);var first=manager.InitAsync().AsTask();var second=manager.InitAsync().AsTask();
            yield return null;operation.Finish(false);yield return Until(()=>first.IsCompleted&&second.IsCompleted);
            Assert.IsTrue(first.IsFaulted);Assert.IsTrue(second.IsFaulted);_ = first.Exception;_ = second.Exception;
            Assert.IsFalse(AddressablesManager.Isinitialized);Assert.IsFalse(handle.IsValid());Assert.IsNotEmpty(errors);
        }
        [UnityTest]public IEnumerator InitCancellationEndsOnlyThatCallersWait()
        {
            var handle=PendingInit(out var operation,false);using var cts=new CancellationTokenSource();
            var canceled=manager.InitAsync(cts.Token).AsTask();cts.Cancel();yield return Complete(canceled);
            Assert.IsFalse(AddressablesManager.Isinitialized);Assert.IsTrue(handle.IsValid());Assert.IsFalse(handle.IsDone);
            operation.Finish(true);yield return Complete(manager.InitAsync().AsTask());Assert.IsTrue(AddressablesManager.Isinitialized);
            Addressables.Release(handle);
        }
        [UnityTest]public IEnumerator PlaySessionCancelEndsIssuedTokensButNotLaterLoads()
        {
            var previous=PlaySession.Token;bool observedCancelled=true;
            previous.Register(()=>observedCancelled=PlaySession.Token.IsCancellationRequested);PlaySession.Cancel();
            Assert.IsTrue(previous.IsCancellationRequested);Assert.IsFalse(observedCancelled);Assert.IsFalse(PlaySession.Token.IsCancellationRequested);
            var load=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(load);
            Assert.IsNotNull(load.Result,"Default-token load stayed cancelled after PlaySession.Cancel");
        }
        [UnityTest]public IEnumerator DestroyInstanceNowReturnsOnlyThatClonesPrefabToken()
        {
            var scope=Scope();var first=scope.InstantiateAsync("prefab").AsTask();yield return Complete(first);owned.Add(first.Result);
            var second=scope.InstantiateAsync("prefab").AsTask();yield return Complete(second);owned.Add(second.Result);Assert.AreEqual(2,manager.GetRefCount("prefab"));
            scope.DestroyInstanceNow(first.Result);yield return Until(()=>manager.GetRefCount("prefab")==1);
            Assert.IsTrue(first.Result==null);Assert.IsTrue(second.Result!=null);
            scope.DestroyInstanceNow(first.Result);Assert.AreEqual(1,manager.GetRefCount("prefab"));
            scope.ReleaseAll();yield return Until(()=>manager.GetRefCount("prefab")==0);Assert.IsTrue(second.Result==null);
        }
        [UnityTest]public IEnumerator MissingManagerStillReturnsNullAndWarnsOncePerKey()
        {
            Object.Destroy(manager.gameObject);yield return null;yield return null;Assert.IsFalse(AddressablesManager.HasInstance);
            string key="step9-no-manager-"+Guid.NewGuid().ToString("N");var warnings=CaptureWarnings(key,out var capture);
            try
            {
                for(int i=0;i<3;i++)
                {
                    var asset=AddressablesManager.LoadAssetAsync<GameObject>(key).AsTask();yield return Complete(asset);Assert.IsNull(asset.Result);
                    var label=AddressablesManager.LoadAssetsAsync<GameObject>(key).AsTask();yield return Complete(label);Assert.IsNull(label.Result);
                }
            }
            finally{Application.logMessageReceived-=capture;}
            Assert.AreEqual(1,warnings.Count);
        }
        [UnityTest]public IEnumerator LoadFailureThrowsWhileCancellationReturnsNull()
        {
            var errors=new List<Exception>();ResourceManager.ExceptionHandler=(_,error)=>errors.Add(error);provider.FailKey="other";
            var failed=AddressablesManager.LoadAssetAsync<GameObject>("other").AsTask();yield return Until(()=>failed.IsCompleted);
            Assert.IsTrue(failed.IsFaulted);_ = failed.Exception;yield return null;Assert.IsFalse(AddressablesManager.IsLoaded("other"));
            using var cts=new CancellationTokenSource();cts.Cancel();var canceled=AddressablesManager.LoadAssetAsync<GameObject>("prefab",cts.Token).AsTask();
            yield return Complete(canceled);Assert.IsNull(canceled.Result);Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest]public IEnumerator SameAddressRequestedAsAnotherTypeLogsAndReturnsNull()
        {
            var prefab=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(prefab);
            LogAssert.Expect(LogType.Error,new Regex("Loaded asset type mismatch"));
            var other=AddressablesManager.LoadAssetAsync<Texture2D>("prefab").AsTask();yield return Complete(other);
            Assert.IsNull(other.Result);Assert.AreEqual(1,manager.GetRefCount("prefab"));
        }
        [UnityTest]public IEnumerator NullLeaseConvertsToNullAsset()
        {
            AddressableLease<GameObject> missing=null;GameObject asset=missing;Assert.IsNull(asset);yield return null;
        }
        [UnityTest]public IEnumerator ScopeHelpersSurviveShutdownWithoutTheManager()
        {
            var clone=new GameObject("step9-shutdown-clone");var lease=new CountingDisposable();IDisposable token;object borrowed;
            var retain=typeof(AddressableScope).GetMethod("RetainUntilDestroyed",BindingFlags.Static|BindingFlags.NonPublic);
            AddressablesManager.applicationIsQuitting=true;
            try
            {
                borrowed=new AddressableMultiScope().AddToScope<GameObject>("prefab");
                token=(IDisposable)retain.Invoke(null,new object[]{clone,lease});token.Dispose();
            }
            finally{AddressablesManager.applicationIsQuitting=false;}
            Assert.IsNull(borrowed);Object.Destroy(clone);yield return Until(()=>lease.Count==1);
        }
        [UnityTest]public IEnumerator ScopeOnNeverActivatedObjectWarnsAndNeedsExplicitRelease()
        {
            var go=new GameObject("step9-inactive-scope");go.SetActive(false);owned.Add(go);var scope=go.AddComponent<AddressableScopeMB>();
            LogAssert.Expect(LogType.Warning,new Regex("has never been active"));
            var load=scope.LoadAsync<GameObject>("prefab").AsTask();yield return Complete(load);Assert.AreEqual(1,manager.GetRefCount("prefab"));
            scope.ReleaseAll();yield return null;Assert.AreEqual(0,manager.GetRefCount("prefab"));
        }
        [UnityTest]public IEnumerator FailedSceneHandleStaysReadableUntilTheNextLoadReleasesIt()
        {
            ResourceManager.ExceptionHandler=(_,error)=>{};LogAssert.Expect(LogType.Error,"Failed to load scene: Step9/missing-scene");
            var failed=manager.LoadSceneAsync("Step9/missing-scene",LoadSceneMode.Additive);yield return failed;yield return null;
            Assert.AreEqual(AsyncOperationStatus.Failed,failed.Status);Assert.AreEqual(1,SceneLoads());
            var next=manager.LoadSceneAsync("Step9/scene-1",LoadSceneMode.Additive);Assert.IsFalse(failed.IsValid());Assert.AreEqual(1,SceneLoads());
            yield return next;Assert.AreEqual(AsyncOperationStatus.Succeeded,next.Status);yield return manager.UnloadSceneAsync(next.Result);
        }
        [UnityTest]public IEnumerator CallerMayReleaseAFailedSceneHandleBeforeTheNextLoad()
        {
            ResourceManager.ExceptionHandler=(_,error)=>{};LogAssert.Expect(LogType.Error,"Failed to load scene: Step9/missing-scene");
            var failed=manager.LoadSceneAsync("Step9/missing-scene",LoadSceneMode.Additive);yield return failed;yield return null;
            Addressables.Release(failed);var next=manager.LoadSceneAsync("Step9/scene-1",LoadSceneMode.Additive);yield return next;
            Assert.AreEqual(AsyncOperationStatus.Succeeded,next.Status);Assert.AreEqual(1,SceneLoads());yield return manager.UnloadSceneAsync(next.Result);
        }
        [UnityTest]public IEnumerator FailedReloadReadsStatusAndClosesItsOwnHandle()
        {
            var load=manager.LoadSceneAsync("Step9/scene-1",LoadSceneMode.Additive);yield return load;Assert.AreEqual(AsyncOperationStatus.Succeeded,load.Status);
            SceneManager.SetActiveScene(load.Result.Scene);((IDictionary)typeof(AddressablesManager).GetField("_sceneKeys",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(manager))[load.Result]="Step9/missing-scene";
            ResourceManager.ExceptionHandler=(_,error)=>{};LogAssert.Expect(LogType.Error,"Failed to load scene: Step9/missing-scene");LogAssert.Expect(LogType.Error,"Failed to reload scene: Step9/missing-scene");
            int called=0;manager.AfterSceneReload=()=>{called++;return UniTask.CompletedTask;};yield return manager.ReloadActiveSceneAsync();yield return null;
            Assert.Zero(called);Assert.AreEqual(1,SceneLoads(),"The failed reload handle was left for manager destruction");
        }
        [UnityTest]public IEnumerator KeyLoadLocksAreRemovedWhenNoLoadWaits()
        {
            provider.Hold=true;var first=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();var second=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();
            using var cts=new CancellationTokenSource();var canceled=AddressablesManager.LoadAssetAsync<GameObject>("prefab",cts.Token).AsTask();
            yield return Until(()=>provider.Pending.Count==1);Assert.AreEqual(1,LoadLocks());cts.Cancel();yield return Complete(canceled);Assert.AreEqual(1,LoadLocks());
            provider.FinishPending();yield return Complete(Task.WhenAll(first,second));Assert.AreEqual(2,manager.GetRefCount("prefab"));Assert.Zero(LoadLocks());
            provider.Hold=false;var label=AddressablesManager.LoadAssetsAsync<GameObject>("label").AsTask();yield return Complete(label);Assert.Zero(LoadLocks());
        }
        [UnityTest]public IEnumerator ReturnsPastZeroWarnAndKeepTheirBehavior()
        {
            var warnings=CaptureWarnings("Check for a duplicate return",out var capture);
            try
            {
                var load=AddressablesManager.LoadAssetAsync<GameObject>("prefab").AsTask();yield return Complete(load);
                AddressablesManager.ReleaseAsset("prefab",60);Assert.IsEmpty(warnings);Assert.IsTrue(AddressablesManager.IsLoaded("prefab"));
                AddressablesManager.ReleaseAsset("prefab",60);Assert.AreEqual(1,warnings.Count);Assert.IsTrue(AddressablesManager.IsLoaded("prefab"));
                AddressablesManager.ReleaseAsset("prefab");Assert.AreEqual(2,warnings.Count);Assert.IsFalse(AddressablesManager.IsLoaded("prefab"));
                AddressablesManager.ReleaseAsset("prefab");Assert.AreEqual(3,warnings.Count);
            }
            finally{Application.logMessageReceived-=capture;}
        }
        [UnityTest]public IEnumerator DuplicateSingletonsKeepOneQuitSubscription()
        {
            var first=new GameObject("step9-probe-a");owned.Add(first);first.AddComponent<SessionProbe>();
            var second=new GameObject("step9-probe-b");owned.Add(second);second.AddComponent<SessionProbe>();yield return null;
            Assert.IsTrue(second==null);Assert.AreEqual(1,ProbeQuitSubscribers());
        }
        [UnityTest]public IEnumerator SessionResetClearsAClosedSingletonRegisteredByItsType()
        {
            var go=new GameObject("step9-probe");owned.Add(go);go.AddComponent<SessionProbe>();yield return null;Assert.IsTrue(SessionProbe.HasInstance);
            var session=typeof(AddressablesManager).Assembly.GetType("jjevol.PersistentSingletonSession");
            var registered=(List<Action>)session.GetField("Resets",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);
            Assert.IsTrue(registered.Exists(reset=>reset.Method.DeclaringType==typeof(PersistentSingleton<SessionProbe>)));
            SessionProbe.applicationIsQuitting=true;
            typeof(PersistentSingleton<SessionProbe>).GetMethod("ResetSession",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,null);
            Assert.IsFalse(SessionProbe.applicationIsQuitting);Assert.IsFalse(SessionProbe.HasInstance);Assert.Zero(ProbeQuitSubscribers());
        }
    }
}
