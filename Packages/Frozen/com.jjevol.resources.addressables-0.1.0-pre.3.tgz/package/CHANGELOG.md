# Changelog

## 0.1.0-pre.3 - 2026-11-07

- The test fixture no longer clears a Host's default Addressables Settings when several fixtures run together. All fixtures share one saved value, the first save is kept, and a deleted asset is never restored.
- The saved runtime data path follows the same rules, so a chained run cannot restore a deleted Settings GUID.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.2 - 2026-11-06

- Fixed `InitAsync` over-releasing a shared init handle.
- `PlaySession.Cancel` issues a new token and `DestroyInstanceNow` returns its prefab reference.
- Added warnings for a missing manager and over-release, documented the failure contract, and defined failed Scene handle ownership.
- Key locks are cleaned up, null leases and shutdown paths are safe, and `PersistentSingleton` no longer accumulates quitting subscriptions.

Unity tests for this candidate are NOT_RUN.

# 0.1.0-pre.1 — 2026-10-31

Local extraction of the existing AddressablesManager and Scope/Lease helpers, retaining public call shapes and script GUIDs. Explicit UniTask.Addressables asmdef reference. UI reload initialization replaced by an optional game callback. Fixed reproduced scope reuse/late completion, prefab source lifetime, stale ownership, manager shutdown, inactive delayed release, batch partial-failure cleanup and scene-key reload paths. Manual catalog operations use explicit handle ownership/finally cleanup; remote/catalog execution remains unverified. Existing Audio/Effect providers and all prior packages are unchanged. No publication or frozen snapshot.
