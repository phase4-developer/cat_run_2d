# JJEvol Addressables Runtime Resources — local candidate

Local extraction candidate for Unity 6000.3.9f1 / Addressables 4.0.1. Basic runtime loading/lifetime scenarios passed Editor SDK tests. Manual catalog APIs, remote deployment, Player/device and all lifecycle combinations remain unverified; this is not a published/frozen release.

Dependencies: com.unity.addressables 4.0.1 and com.cysharp.unitask 2.5.10. The Host must pin/install UniTask's actual source (validation uses Git commit f213ff497e4ff462a77319cf677cf20cc0860ca9). Runtime assembly JJEvol.Resources.Addressables.Runtime explicitly references Unity.Addressables, Unity.ResourceManager, UniTask and UniTask.Addressables. No Managed Addressables, UI, Platform, Runner, Table, Audio or Effect dependency is added.

Existing classes/namespaces and source script GUIDs are retained: jjevol.AddressablesManager, AddressableScope, AddressableLease<T>, AddressableMultiScope, AddressableScopeMB/Extensions, PersistentSingleton<T>, and global PlaySession. The last two are the small original supporting types, not Common-wide extraction. Do not install alongside the same legacy source/classes/GUIDs.

```csharp
var manager = AddressablesManager.Instance; // static load calls do not create it
await manager.InitAsync();
using (var lease = await AddressableScope.Get<Texture2D>(gameTextureKey, cancellationToken))
{
    if (lease != null) { /* consume lease.Asset only during ownership */ }
}
```

Every successful LoadAssetAsync/GetAsset/GetPrefab acquires one manager reference. TryGetLoadedAsset is read-only: it neither acquires ownership nor cancels pending delayed release. A label load acquires one list reference under the label; a key batch acquires once per distinct nonempty key. Return the same key/label exactly once per acquisition. Raw string ReleaseAsset cannot authenticate who owns that reference. Do not mix a lease with manual ReleaseAsset for the same acquisition.

```csharp
var scope = component.GetAddressableScope();
var instance = await scope.InstantiateAsync(gamePrefabKey, parent, cancellationToken);
// Scope defaults: release on Destroy, retain on Disable, destroy tracked instances on release.
scope.ReleaseAll();
```

Prefab instances are made with Unity Object.Instantiate, not Addressables.InstantiateAsync. Do not call Addressables.ReleaseInstance on them. InstantiateWithLease retains its existing tuple `(instance, lease, destroyOnDispose)`; dispose both tokens. Its lease is now a deferred IDisposable rather than a concrete AddressableLease: do not cast it. Requesting lease return while the instance survives delays source release until actual destruction. DestroyInstanceNow also returns that clone's prefab acquisition after the clone is actually destroyed. Scope ReleaseAll can be reused and rejects late completion from prior scope lifetimes. Disposed MultiScope rejects new ownership. Tokens capture the original manager/cache generation so stale tokens cannot release replacement acquisitions.

RegisterKey/MultiScope.Add register an already acquired reference; they do not acquire one. Borrow(registerToRelease:false) still acquires through GetAsset and transfers manual return responsibility to the caller, as before. Scope flags opting out of automatic release/destruction require explicit caller cleanup. Manually tracked clones conservatively retain related scope returns until tracked objects are destroyed. Unity sends OnDestroy only to objects that were active at least once, so a scope on a never-activated object does not release automatically: it logs a warning, and the owner must call ReleaseAll. Do not destroy the manager while external untracked consumers still need its resources.

## Load contract

| Case | Result |
| --- | --- |
| No manager (static load calls never create one) | null, or an empty dictionary for key batches. Logs one warning per key per session. |
| Empty key, manager shutting down, or cancellation | null. A key batch leaves that key out of its result. No exception. |
| Load failure | The awaited call throws. No reference is acquired. A key batch returns every acquisition it already made before throwing. |
| Key already cached as another type | Logs an error and returns null. The cache has one entry per key, so one Address cannot be held as two types at once. This is a known limit: load it as the same type everywhere. |

Treat null and exceptions separately: null means nothing was acquired and there is nothing to return. `AddressableLease<T>` converts to its asset, and a null lease converts to null.

ReleaseAsset logs a warning when it returns an entry that has no owners left, or a key with no cached entry. The behavior is unchanged: a return with no delay still closes an idle entry at once. A duplicate return can remove another owner's reference, and the warning shows up at the return that finds nothing left, which may not be the mistaken one.

ReleaseUnusedAssets immediately returns cached entries with zero manager references, including entries waiting for delayed release. It retains active acquisitions and does not cancel in-flight loads. ReleaseAllLoadedAssets remains the original force-clear API, ignoring positive manager refcounts. End consumers and destroy clones before using it; use ReleaseUnusedAssets for normal cleanup. Manager destruction cancels asset loads, destroys instances created through the managed Scope helpers, closes owned scenes and returns its handles after actual tracked instance destruction. Disable retains assets; real-time delayed returns resume when enabled. Main-thread use is required; per-key semaphore coordination does not make Unity calls thread-safe.

Scene load/unload signatures are retained. ReloadActiveSceneAsync remembers the original Address key rather than assuming Scene.name is its key. UIManagerCreater is not bundled: set manager.AfterSceneReload to a game-owned UniTask callback if the game needs UI initialization after reload. Scene load handles are tracked; SDK unload consumes the scene acquisition, and default unload handles auto-release. Do not independently release the same successful load acquisition and then also ask the manager to unload it. A failed scene handle stays readable after the load, so callers can check Status. The next LoadSceneAsync releases it, whoever calls it, so read Status before starting another load. If another caller's LoadSceneAsync arrives in the same frame the failure completes, a handle that a caller is still waiting on with yield can already be released when that caller resumes, and reading Status on it then throws. Read Status in a Completed callback, or right after completion once IsValid() confirms the handle is still open. A caller may also release a failed handle itself. ReloadActiveSceneAsync closes its own failed handle after reading Status. Any tracked handle left over is closed at manager destruction.

InitAsync only initializes the SDK. It never runs Managed Sync/ApplyGlobal/build/deployment. Concurrent calls share the SDK's operation, and the SDK releases it on completion. A failed initialization throws; cancellation ends only that caller's wait. The SDK does not restart initialization after a failure, so a later InitAsync does not retry it and can succeed with only the locators that did load. Existing UpdateCatalog/LoadCatalogAsync/LoadRemoteCatalogAsync remain explicit manual SDK operations and are NOT verified for remote/product content. Catalog naming/path signatures are retained. BuildTarget now uses the installed Addressables PlatformMappingService: Editor uses the selected build target, Player uses its runtime platform (Windows/Android/iOS/OSX/Linux folder names follow the SDK). This does not validate a platform build or migrate existing catalogs. Products own keys, settings and startup catalog orchestration; choose a single orchestrator when Managed Addressables is also present. Do not call UpdateCatalog, LoadCatalogAsync or LoadRemoteCatalogAsync while a Managed Addressables Revision Session owns the catalog: they change the SDK's locators behind that session. Unity execution of the 2026-11-02 local improvements is pending.

PlaySession.Cancel cancels the tokens already issued and starts a new session token, so later default-token loads run normally. With Domain Reload disabled, PersistentSingleton resets its instance and quit flag for every closed type at subsystem registration, and keeps one Application.quitting subscription per type.

Tests/Runtime and Tests/Editor use real SDK ResourceManager operations plus independent Prefab/Texture/TextAsset/Scene assets in an isolated FastMode Host. Tests/Coexist~ is excluded from normal import and is copied only into the dedicated coexistence Host; it tests shared SDK acquisitions without making this package depend on Audio/Effect. See Docs/ResourceExtraction/STEP9_ResourceExtraction.md in the Framework repository for compatibility, exact results and limitations.
