# Changelog

## 0.1.0-pre.2 - 2026-11-20

- 깨짐: `CountdownText.UtcNow`를 없앴다. 남은 시간의 믿을 시계는 `UIDisplayOptions.UtcNow`(`com.jjevol.ui.contracts@0.1.0-pre.5`)다(사용자 결정 2026-11-20 「ui.contracts 중립 설정」·「uGUI도 맞춤」).
- `AnimatedNumberText`·`CooldownOverlay`·`CountdownText`가 문화권·숫자 표기·로케일 변경 알림을 `UIDisplayOptions`에서 읽는다. UI Toolkit 위젯·재화 라벨과 같은 설정이다. 표시는 그대로다.

## 0.1.0-pre.1 - 2026-11-20

- New package (사용자 요청 2026-11-20: 애니메이트 슬라이더 게이지와 숫자 레이블, 토스트 메시지, 버튼 애니메이션, 그 밖의 위젯. 결정: uGUI·UI Toolkit 양쪽, 새 widgets 패키지, 자체 경량 트윈). 정크버스터즈 `UIAnimateSlider`·`DisplaySlider`·`UIButtonHoldRepeat`를 참고만 하고 DOTween 없이 새로 짰다.
- `AnimatedNumberText`, `AnimatedGauge`, `ToastPresenter`·`ToastView`, `ButtonFeedback`, `HoldRepeatButton`, `CooldownOverlay`, `CountdownText`, `AttentionPulse`, `TypewriterText`. 상태와 계산은 `com.jjevol.ui.contracts@0.1.0-pre.4` 위젯 모델을 쓴다.
