using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace jjevol.UI.Widgets.Tests
{
    // TMP needs a default font; the uGUI core tests' prebuild step imports TMP Essential Resources in the host.
    [PrebuildSetup("jjevol.UI.Tests.UITestTMPSetup")]
    public sealed class UIWidgetsPlayTests
    {
        private readonly List<Object> _objects = new List<Object>();
        private TMP_Settings _priorSettings, _settings;
        private TMP_FontAsset _font;

        [SetUp]
        public void Setup()
        {
            FieldInfo field = typeof(TMP_Settings).GetField("s_Instance", BindingFlags.Static | BindingFlags.NonPublic);
            _priorSettings = (TMP_Settings)field.GetValue(null);
            _settings = ScriptableObject.CreateInstance<TMP_Settings>();
            _font = TMP_FontAsset.CreateFontAsset("Arial", "Regular", 32);
            Assert.That(_font, Is.Not.Null, "The Windows validation host requires its installed Arial font.");
            typeof(TMP_Settings).GetField("m_defaultFontAsset", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(_settings, _font);
            field.SetValue(null, _settings);
        }

        [UnityTearDown]
        public IEnumerator Cleanup()
        {
            foreach (Object item in _objects) if (item) Object.Destroy(item);
            _objects.Clear();
            yield return null;
            typeof(TMP_Settings).GetField("s_Instance", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, _priorSettings);
            if (_font) { if (_font.material) Object.Destroy(_font.material); foreach (Texture2D texture in _font.atlasTextures) if (texture) Object.Destroy(texture); Object.Destroy(_font); }
            Object.Destroy(_settings);
            UIDisplayOptions.NumberFormat = null; UIDisplayOptions.Culture = null; UIDisplayOptions.Language = null;
            UIDisplayOptions.UtcNow = null;
            yield return null;
        }

        private GameObject New(string name, bool active = true, Transform parent = null)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.SetActive(active);
            if (parent != null) go.transform.SetParent(parent, false);
            _objects.Add(go);
            return go;
        }

        private static void Set(object target, string field, object value)
        {
            FieldInfo info = target.GetType().GetField(field, BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.That(info, Is.Not.Null, field);
            info.SetValue(target, value);
        }

        private static Image Filled(GameObject parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent.transform, false);
            var image = go.GetComponent<Image>();
            image.type = Image.Type.Filled;
            image.fillAmount = 1f;
            return image;
        }

        private static void TickFor(Action<float> tick, float seconds, float step = 0.02f)
        {
            for (float t = 0f; t < seconds; t += step) tick(step);
        }

        [Test]
        public void NumberTextCountsWithTheGameProfileAndItsOwnOverride()
        {
            UIDisplayOptions.Culture = () => System.Globalization.CultureInfo.InvariantCulture;
            UIDisplayOptions.NumberFormat = new NumberFormatSettings(NumberFormatProfile.CreateThousands(1));
            GameObject go = New("number", false);
            var text = go.AddComponent<TextMeshProUGUI>();
            var number = go.AddComponent<AnimatedNumberText>();
            go.SetActive(true);

            number.SetValue(0m);
            Assert.That(text.text, Is.EqualTo("0"));
            int completed = 0;
            number.CountCompleted += () => completed++;
            number.CountTo(1500m);
            Assert.That(number.IsCounting, Is.True);
            number.Tick(0.1f);
            Assert.That(number.Value, Is.GreaterThan(0m).And.LessThan(1500m));
            TickFor(number.Tick, 2f);
            Assert.That(text.text, Is.EqualTo("1.5K"));
            Assert.That(completed, Is.EqualTo(1));
            Assert.That(go.transform.localScale, Is.EqualTo(Vector3.one), "The pop returns to rest");

            number.Prefix = "x"; number.Suffix = "!";
            Assert.That(text.text, Is.EqualTo("x1.5K!"));
            number.NumberFormatOverride = NumberFormatProfile.Full;
            Assert.That(text.text, Is.EqualTo("x1,500!"));
            Assert.That(number.FormatNumber(2000m), Is.EqualTo("2,000"));
        }

        [Test]
        public void GaugeDropsTheFillLeavesATrailAndRestoresTheImpactTarget()
        {
            GameObject go = New("gauge", false);
            Image fill = Filled(go, "fill"), trail = Filled(go, "trail"), lead = Filled(go, "lead");
            var gauge = go.AddComponent<AnimatedGauge>();
            Set(gauge, "fill", fill); Set(gauge, "trail", trail); Set(gauge, "lead", lead);
            go.SetActive(true);

            float size = 0f; bool heavy = false; int lapEvents = 0;
            gauge.OnDecreased.AddListener((s, h) => { size = s; heavy = h; });
            gauge.OnLapCompleted.AddListener(() => lapEvents++);
            gauge.SetInstant(100m, 100m);
            Assert.That(fill.fillAmount, Is.EqualTo(1f));
            Assert.That(trail.color.a, Is.EqualTo(0f), "No trail on first display");

            gauge.SetValue(40m, 100m);
            Assert.That(fill.fillAmount, Is.EqualTo(0.4f).Within(1e-4f));
            Assert.That(trail.fillAmount, Is.EqualTo(1f));
            Assert.That(trail.color.a, Is.GreaterThan(0.9f));
            Assert.That(size, Is.EqualTo(0.6f).Within(1e-4f));
            Assert.That(heavy, Is.True);
            gauge.Tick(0.05f);
            Assert.That(go.transform.localScale, Is.Not.EqualTo(Vector3.one), "Heavy hits punch");

            TickFor(gauge.Tick, 2f);
            Assert.That(trail.fillAmount, Is.EqualTo(0.4f).Within(1e-4f));
            Assert.That(trail.color.a, Is.EqualTo(0f));
            Assert.That(go.transform.localScale, Is.EqualTo(Vector3.one));
            Assert.That(((RectTransform)go.transform).anchoredPosition, Is.EqualTo(Vector2.zero));

            gauge.SetValue(20m, 100m, laps: 1);
            TickFor(gauge.Tick, 2f);
            Assert.That(lapEvents, Is.EqualTo(1));
            Assert.That(fill.fillAmount, Is.EqualTo(0.2f).Within(1e-4f));
        }

        [Test]
        public void GaugeSetBeforeAwakeKeepsThePrefabColours()
        {
            GameObject go = New("gauge early", false);
            Image fill = Filled(go, "fill"), trail = Filled(go, "trail");
            trail.color = Color.red;
            var gauge = go.AddComponent<AnimatedGauge>();
            Set(gauge, "fill", fill); Set(gauge, "trail", trail);
            gauge.SetInstant(50m, 100m);
            go.SetActive(true);
            gauge.SetValue(10m, 100m);
            Assert.That(trail.color.r, Is.EqualTo(1f));
            Assert.That(trail.color.a, Is.GreaterThan(0.9f), "The trail shows in the prefab colour");
        }

        [Test]
        public void ButtonFeedbackDoesNotUndoALayoutMoveAndHoldRepeatReleaseIsNotAClick()
        {
            GameObject go = New("moved button");
            go.AddComponent<Image>();
            var button = go.AddComponent<Button>();
            var feedback = go.AddComponent<ButtonFeedback>();
            var hold = go.AddComponent<HoldRepeatButton>();
            var rect = (RectTransform)go.transform;
            rect.anchoredPosition = new Vector2(120f, 30f);   // a layout group placed it after Awake
            var data = new PointerEventData(null) { button = PointerEventData.InputButton.Left, eligibleForClick = true };
            feedback.OnPointerDown(data);
            hold.OnPointerDown(data);
            TickFor(f => { feedback.Tick(f); hold.Tick(f); }, 0.5f);
            Assert.That(hold.RepeatCount, Is.GreaterThan(0));
            feedback.OnPointerUp(data);
            hold.OnPointerUp(data);
            Assert.That(data.eligibleForClick, Is.False, "No extra click after repeats");
            TickFor(feedback.Tick, 0.5f);
            Assert.That(rect.anchoredPosition, Is.EqualTo(new Vector2(120f, 30f)));
            Assert.That(rect.localScale, Is.EqualTo(Vector3.one));

            var tap = new PointerEventData(null) { button = PointerEventData.InputButton.Left, eligibleForClick = true };
            hold.OnPointerDown(tap);
            hold.OnPointerUp(tap);
            Assert.That(tap.eligibleForClick, Is.True, "A short tap stays a click");
        }

        [Test]
        public void CooldownKeepsAButtonTheGameTurnedOff()
        {
            GameObject go = New("cooldown off", false);
            Image overlay = Filled(go, "overlay");
            go.AddComponent<Image>();
            var button = go.AddComponent<Button>();
            button.interactable = false;
            var group = go.AddComponent<CanvasGroup>();
            var cooldown = go.AddComponent<CooldownOverlay>();
            Set(cooldown, "overlay", overlay);
            Set(cooldown, "lockGroup", group);
            go.SetActive(true);
            Assert.That(button.interactable, Is.False, "Awake does not turn it on");
            cooldown.Begin(1f);
            cooldown.Tick(2f);
            Assert.That(button.interactable, Is.False, "The game's value is never written");
            Assert.That(button.IsInteractable(), Is.False);
        }

        [Test]
        public void ToastPresenterShowsUpToTheLimitMergesAndReturnsViewsToThePool()
        {
            GameObject prefabGo = New("toast prefab", false);
            prefabGo.AddComponent<CanvasGroup>();
            var view = prefabGo.AddComponent<ToastView>();
            GameObject messageGo = New("message", true, prefabGo.transform);
            Set(view, "messageText", messageGo.AddComponent<TextMeshProUGUI>());
            GameObject countGo = New("count", true, prefabGo.transform);
            Set(view, "countText", countGo.AddComponent<TextMeshProUGUI>());

            GameObject presenterGo = New("toasts", false);
            var presenter = presenterGo.AddComponent<ToastPresenter>();
            Set(presenter, "viewPrefab", view);
            Set(presenter, "maxVisible", 2);
            Set(presenter, "defaultDuration", 1f);
            Set(presenter, "leaveDuration", 0.2f);
            presenterGo.SetActive(true);

            presenter.Show("a");
            Toast gold = presenter.Show("+10", mergeKey: "gold");
            presenter.Show("c");
            Assert.That(ActiveChildren(presenterGo.transform), Is.EqualTo(2));
            presenter.Show("+20", mergeKey: "gold");
            Assert.That(gold.Count, Is.EqualTo(2));
            ToastView goldView = FindView(presenterGo.transform, "+20");
            Assert.That(goldView, Is.Not.Null, "The merged view shows the newest message");
            Assert.That(goldView.GetComponentsInChildren<TextMeshProUGUI>(true)[1].text, Is.EqualTo("x2"));

            TickFor(presenter.Tick, 1.3f);
            Assert.That(ActiveChildren(presenterGo.transform), Is.EqualTo(1), "\"c\" took the free place");
            Assert.That(FindView(presenterGo.transform, "c"), Is.Not.Null);
            TickFor(presenter.Tick, 1.5f);
            Assert.That(ActiveChildren(presenterGo.transform), Is.EqualTo(0));
            Assert.That(presenterGo.transform.childCount, Is.LessThanOrEqualTo(2), "Views are reused from the pool");
        }

        private static int ActiveChildren(Transform parent)
        {
            int count = 0;
            foreach (Transform child in parent) if (child.gameObject.activeSelf) count++;
            return count;
        }

        private static ToastView FindView(Transform parent, string message)
        {
            foreach (ToastView view in parent.GetComponentsInChildren<ToastView>(false))
                if (view.MessageText.text == message) return view;
            return null;
        }

        [Test]
        public void ButtonFeedbackShrinksOnPressAndShakesWhenNotInteractable()
        {
            GameObject es = New("event system");
            es.AddComponent<EventSystem>();
            GameObject go = New("button");
            go.AddComponent<Image>();
            var button = go.AddComponent<Button>();
            var feedback = go.AddComponent<ButtonFeedback>();
            var data = new PointerEventData(EventSystem.current) { button = PointerEventData.InputButton.Left };

            feedback.OnPointerDown(data);
            TickFor(feedback.Tick, 0.2f);
            Assert.That(go.transform.localScale.x, Is.EqualTo(0.92f).Within(1e-3f));
            feedback.OnPointerUp(data);
            TickFor(feedback.Tick, 0.5f);
            Assert.That(go.transform.localScale.x, Is.EqualTo(1f).Within(1e-3f));

            button.interactable = false;
            feedback.OnPointerDown(data);
            Assert.That(feedback.IsPressed, Is.False, "No press while not interactable");
            feedback.OnPointerClick(data);
            float moved = 0f;
            for (int i = 0; i < 6; i++) { feedback.Tick(0.02f); moved = Mathf.Max(moved, Mathf.Abs(((RectTransform)go.transform).anchoredPosition.x)); }
            Assert.That(moved, Is.GreaterThan(0.5f), "Shakes while not interactable");
            TickFor(feedback.Tick, 0.5f);
            Assert.That(((RectTransform)go.transform).anchoredPosition, Is.EqualTo(Vector2.zero));
        }

        [Test]
        public void HoldRepeatButtonRepeatsWhileHeldAndStopsWhenNotInteractable()
        {
            GameObject go = New("hold");
            go.AddComponent<Image>();
            var button = go.AddComponent<Button>();
            var hold = go.AddComponent<HoldRepeatButton>();
            int repeats = 0;
            hold.OnRepeat.AddListener(() => repeats++);
            var data = new PointerEventData(null) { button = PointerEventData.InputButton.Left };

            hold.OnPointerDown(data);
            hold.Tick(0.3f);
            Assert.That(repeats, Is.EqualTo(0));
            hold.Tick(0.15f);
            Assert.That(repeats, Is.EqualTo(1));
            button.interactable = false;
            hold.Tick(1f);
            Assert.That(repeats, Is.EqualTo(1));
            Assert.That(hold.IsHeld, Is.False);
        }

        [Test]
        public void CooldownOverlayEmptiesAndLocksTheButtonUntilReady()
        {
            GameObject go = New("cooldown", false);
            Image overlay = Filled(go, "overlay");
            go.AddComponent<Image>();
            var button = go.AddComponent<Button>();
            var group = go.AddComponent<CanvasGroup>();
            var cooldown = go.AddComponent<CooldownOverlay>();
            Set(cooldown, "overlay", overlay);
            Set(cooldown, "lockGroup", group);
            go.SetActive(true);
            int ready = 0;
            cooldown.OnReady.AddListener(() => ready++);

            cooldown.Begin(2f);
            Assert.That(overlay.enabled, Is.True);
            Assert.That(button.IsInteractable(), Is.False);
            button.interactable = true;   // the game writes its own value every frame
            Assert.That(button.IsInteractable(), Is.False, "The cooldown still blocks");
            cooldown.Tick(1f);
            Assert.That(overlay.fillAmount, Is.EqualTo(0.5f).Within(1e-4f));
            cooldown.Tick(1.1f);
            Assert.That(overlay.enabled, Is.False);
            Assert.That(button.IsInteractable(), Is.True);
            Assert.That(ready, Is.EqualTo(1));
        }

        [Test]
        public void CountdownTextFollowsTheGameClockAndShowsTheFinishedText()
        {
            var now = new DateTime(2026, 11, 20, 0, 0, 0, DateTimeKind.Utc);
            UIDisplayOptions.UtcNow = () => now;
            UIDisplayOptions.Culture = () => System.Globalization.CultureInfo.InvariantCulture;
            GameObject go = New("countdown", false);
            var text = go.AddComponent<TextMeshProUGUI>();
            var countdown = go.AddComponent<CountdownText>();
            Set(countdown, "finishedText", "Done");
            go.SetActive(true);
            int finished = 0;
            countdown.OnFinished.AddListener(() => finished++);

            countdown.SetEndTime(now.AddSeconds(65));
            Assert.That(text.text, Is.EqualTo("01:05"));
            now = now.AddSeconds(30);
            countdown.Tick(0f);
            Assert.That(text.text, Is.EqualTo("00:35"));
            now = now.AddSeconds(40);
            countdown.Tick(0f);
            Assert.That(text.text, Is.EqualTo("Done"));
            Assert.That(finished, Is.EqualTo(1));

            countdown.SetRemaining(3);
            countdown.Tick(1.5f);
            Assert.That(text.text, Is.EqualTo("00:02"));
        }

        [Test]
        public void AttentionPulseBreathesAndRestoresTheScale()
        {
            GameObject go = New("pulse", false);
            var pulse = go.AddComponent<AttentionPulse>();
            Set(pulse, "strength", 0.1f);
            Set(pulse, "period", 1f);
            go.SetActive(true);
            Assert.That(pulse.IsPlaying, Is.True);
            pulse.Tick(0.5f);
            Assert.That(go.transform.localScale.x, Is.EqualTo(1.1f).Within(1e-4f));
            pulse.Stop();
            Assert.That(go.transform.localScale, Is.EqualTo(Vector3.one));
        }

        [Test]
        public void TypewriterTextRevealsWithMaxVisibleCharacters()
        {
            GameObject go = New("typewriter", false);
            var text = go.AddComponent<TextMeshProUGUI>();
            var writer = go.AddComponent<TypewriterText>();
            Set(writer, "charactersPerSecond", 10f);
            go.SetActive(true);
            int completed = 0;
            writer.Completed += () => completed++;

            writer.Play("<b>ab</b>c");
            Assert.That(text.maxVisibleCharacters, Is.EqualTo(0));
            writer.Tick(0.25f);
            Assert.That(text.maxVisibleCharacters, Is.EqualTo(2));
            writer.Skip();
            Assert.That(writer.IsPlaying, Is.False);
            Assert.That(text.maxVisibleCharacters, Is.GreaterThanOrEqualTo(3));
            Assert.That(completed, Is.EqualTo(1));
        }
    }
}
