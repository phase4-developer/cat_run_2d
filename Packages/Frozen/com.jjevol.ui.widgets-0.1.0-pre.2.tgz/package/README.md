# JJEvol UI Widgets

`com.jjevol.ui.widgets@0.1.0-pre.2`는 uGUI(TextMeshPro·Image) 게임이 화면에 바로 붙여 쓰는 위젯 모음이다. 같은 동작의 UI Toolkit판은 `com.jjevol.uitoolkit.widgets`다. 상태와 계산(카운트, 게이지 잔상, 토스트 대기열 등)은 `com.jjevol.ui.contracts`의 위젯 모델이 맡고, 이 패키지는 그것을 Prefab의 Image·Text·RectTransform에 그린다. 트윈 라이브러리(DOTween 등)가 필요 없다.

## 들어 있는 것

| 컴포넌트 | 붙이는 곳 | 하는 일 |
|---|---|---|
| `AnimatedNumberText` | TMP_Text가 있는 오브젝트 | `CountTo(value)`로 숫자를 세며 바꾼다. 숫자 표기는 `UIDisplayOptions.NumberFormat`(게임 프로필)을 따르고 라벨마다 덮어쓸 수 있다. 접두·접미, `{0}` 형식, 0 숨김, 언어별 축약, 바뀔 때 팝·증감 색 |
| `AnimatedGauge` | 게이지 루트 | Filled Image 3장(채움·잔상·앞선 막대). 감소하면 채움이 바로 내려가고 잔상이 지연 뒤 따라온다. 큰 감소는 펀치와 흔들기. 증가는 앞선 막대가 먼저 보인다. `SetValue(current, max, laps)`의 laps로 경험치처럼 여러 바퀴 채운다. 선택으로 `AnimatedNumberText` 두 개(현재·최대)를 연결한다. Inspector 이벤트 `OnDecreased(크기, 큰 감소)`·`OnIncreased`·`OnLapCompleted`로 소리·Animator를 건다 |
| `ToastPresenter` + `ToastView` | 토스트를 놓을 컨테이너 + 토스트 Prefab | `Show("메시지")` 또는 `Show(ToastRequest)`. 동시 표시 수, 대기 상한, 우선순위, 같은 `MergeKey` 합치기(x2, x3), 등장·퇴장 움직임. View는 `ObjectPool<T>`로 재사용한다. 아이콘·스타일은 `ToastView`를 상속해 `Bind`에서 그린다 |
| `ButtonFeedback` | 버튼 | 누르면 줄고 떼면 튀어 오른다. 마우스 올림 배율(선택). 비활성 버튼을 누르면 좌우로 흔들린다. 입력은 EventSystem 포인터 이벤트다 |
| `HoldRepeatButton` | 버튼 | 길게 누르는 동안 `OnRepeat`를 점점 빠르게 부른다(수량 +/-). 짧게 누르면 버튼의 보통 클릭이고, 반복이 나간 뒤 손을 떼는 것은 클릭이 아니다 |
| `CooldownOverlay` | 스킬·버튼 | Filled Image가 1에서 0으로 줄고, 남은 초(3초 아래는 소수 1자리)를 보인다. 버튼을 막으려면 쿨다운만 쓰는 `CanvasGroup`을 `lockGroup`에 연결한다(쿨다운 동안 `interactable` false). 버튼의 `Selectable.interactable`은 게임 것이고 `IsInteractable()`이 둘을 함께 본다. 끝나면 팝과 `OnReady` |
| `CountdownText` | TMP_Text | 남은 시간 `05:09`·`1h 2m`·`1일 1시간`. 끝 시각은 게임 시계 `UIDisplayOptions.UtcNow`(서버 시각 등) 기준. 끝나면 `finishedText`와 `OnFinished` |
| `AttentionPulse` | 눈길을 끌 버튼 | 숨쉬기(크기 반복)·팝·흔들기를 쉬는 시간과 함께 반복. 끄면 원래 크기·위치로 돌아간다 |
| `TypewriterText` | TMP_Text | 글자를 차례로 드러낸다(`maxVisibleCharacters`, 리치 텍스트 유지, 문장부호 뒤 쉼). `Skip()`으로 전부 보인다 |

모든 컴포넌트는 namespace `jjevol.UI.Widgets`다. 움직이는 컴포넌트는 `useUnscaledTime`(기본 켬)을 고를 수 있고 `Tick(deltaTime)`을 공개해 시험이나 게임 시간으로 직접 돌릴 수 있다. 비활성화되면 진행 중이던 움직임을 끝 상태로 정리해, 다시 켤 때 옛 연출이 이어지지 않는다. 예외는 `CooldownOverlay`로, 꺼져 있는 동안 남은 시간이 멈춘다. 게임의 실제 쿨다운과 맞추려면 다시 켤 때 `Begin(전체 초, 남은 초)`로 다시 맞춘다.

움직임의 기준 배율·위치는 움직임이 시작될 때 읽고 끝날 때 한 번 되돌린다. 그래서 레이아웃 그룹이나 재사용 셀이 그 사이에 옮긴 위치를 되돌리지 않는다. `CooldownOverlay`는 버튼의 `Selectable.interactable`을 쓰지 않고 자기 `lockGroup`만 바꾼다. 게임이 쿨다운 중에 버튼 값을 써도 쿨다운이 계속 막고, 끝나도 게임 값을 덮지 않는다. `HoldRepeatButton`은 반복이 한 번이라도 나가면 손을 뗄 때 클릭으로 치지 않는다. `ToastView.enterOffset`은 `motionTarget`이 있을 때만 쓴다.

## 시작

```csharp
// 부팅 때 한 번(숫자 표기는 재화 라벨·UI Toolkit과 같은 UIDisplayOptions)
UIDisplayOptions.NumberFormat = new NumberFormatSettings(NumberFormatProfile.CreateThousands(1))
    .SetLanguage("ko", NumberFormatProfile.CreateKorean());

// 화면
[SerializeField] AnimatedGauge hpGauge;      // Prefab에서 fill·trail·lead Image 연결
[SerializeField] AnimatedNumberText gold;
[SerializeField] ToastPresenter toasts;      // viewPrefab에 ToastView Prefab 연결

void OnShow(Player p) { hpGauge.SetInstant(p.Hp, p.MaxHp); gold.SetValue(p.Gold); }   // 첫 표시는 즉시
void OnDamaged(Player p) => hpGauge.SetValue(p.Hp, p.MaxHp);
void OnGoldChanged(long v) => gold.CountTo(v);
void OnReward(int amount) => toasts.Show(new ToastRequest($"+{amount}") { MergeKey = "gold" });
```

## 게임이 맡을 일

- Prefab: 게이지 Image(Image Type = Filled, 방향·색·스프라이트), 토스트 Prefab(CanvasGroup + `ToastView` + 메시지 TMP_Text), 토스트 컨테이너 배치(예: VerticalLayoutGroup). 생김새는 모두 Prefab이 정본이고 컴포넌트는 fillAmount·alpha·배율·위치만 바꾼다.
- 숫자 프로필(`UIDisplayOptions.NumberFormat`)과 로케일 변경 알림(`UIDisplayOptions.NotifyLocaleChanged()`).
- 남은 시간의 믿을 시계(`UIDisplayOptions.UtcNow`). 비우면 기기 시각이다.
- 소리·햅틱·Animator 트리거는 Inspector 이벤트에 연결한다.

## 주의

- 레이아웃 그룹이 위치를 정하는 오브젝트에 움직임을 주면 그룹이 덮어쓴다. `ToastView.motionTarget`, `ButtonFeedback.target`, `AnimatedGauge.impactTarget`은 자식 RectTransform을 가리키게 한다.
- `ToastPresenter`는 일반 알림 토스트다. 스킬 이름·캐릭터가 나오는 일회성 연출은 `com.jjevol.effects.ui`의 `ToastMessageEffectRenderer`(Effect 시스템)를 쓴다.
- `TypewriterText`는 쉼 계산에 태그를 뺀 글자를 쓰고, TMP의 `<sprite>`는 TMP가 한 글자로 센다. 스프라이트가 섞인 문장은 끝날 때 전부 보이게 맞춘다.
- 같은 대상의 배율을 두 컴포넌트가 함께 움직이면 서로 덮어쓴다. 예를 들어 `ButtonFeedback`과 `AttentionPulse`를 한 버튼에 쓰면 `target`을 서로 다른 RectTransform(버튼과 그 안의 그림)으로 나눈다.
- `com.jjevol.ui`의 `NumberAnimator`는 그대로 둔다. 새 화면은 `AnimatedNumberText`를 쓰고, 옛 것은 이 패키지가 검증된 뒤 따로 정리한다.
- Player·기기에서의 확인은 게임에서 한다(검증 상태는 `Docs/Guide/Verification.md`).

## 설치와 참조

manifest에 `com.jjevol.ui.widgets`, `com.jjevol.ui`, `com.jjevol.ui.contracts`, `com.unity.ugui`를 적는다(`com.jjevol.ui`의 전이 의존성 UniTask 포함). 게임 asmdef는 `JJEvol.UI.Widgets.Runtime`과 `JJEvol.UI.Contracts.Runtime`을 참조한다.

## 검증

PlayMode 시험 `JJEvol.UI.Widgets.Tests.Runtime`(숫자 카운트와 프로필, 게이지 잔상·충격 복원·바퀴, 토스트 표시 수·합치기·풀 재사용, 버튼 누름·비활성 흔들기, 길게 누르기, 쿨다운, 남은 시간, 맥동, 타자기). TMP 기본 폰트 준비는 `com.jjevol.ui` 시험의 `UITestTMPSetup`을 쓰므로 같은 Host에서 돌린다.
