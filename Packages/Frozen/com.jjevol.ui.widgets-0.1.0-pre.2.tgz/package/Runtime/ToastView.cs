using TMPro;
using UnityEngine;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// One toast on screen, placed on the toast prefab. The prefab owns the look; this component writes the message and
    /// plays the enter and exit motion. Subclass and override <see cref="Bind"/> to show icons or styles from
    /// <see cref="ToastRequest.Icon"/>, <see cref="ToastRequest.Style"/> or <see cref="ToastRequest.Payload"/>.
    /// </summary>
    [RequireComponent(typeof(CanvasGroup))]
    public class ToastView : MonoBehaviour
    {
        [SerializeField] private TMP_Text messageText;
        [SerializeField, Tooltip("Optional. Shows the merge count, for example x3. Hidden for a single toast.")] private TMP_Text countText;
        [SerializeField] private string countFormat = "x{0}";
        [SerializeField, Tooltip("Moved and scaled by the motion. Empty uses this transform. Keep it a child when a layout group places this object.")]
        private RectTransform motionTarget;

        [Header("Motion")]
        [SerializeField, Min(0.01f)] private float enterDuration = 0.22f;
        [SerializeField, Tooltip("Start offset of the enter motion. Used only with a motionTarget; without one the layout places the view and only scale and alpha move.")]
        private Vector2 enterOffset = new Vector2(0f, -40f);
        [SerializeField, Range(0f, 1f)] private float enterScale = 0.85f;
        [SerializeField, Tooltip("Scale pop when a merged toast restarts. 0 turns it off.")] private float mergePop = 0.1f;

        private readonly FloatTween _enter = new FloatTween();
        private readonly FloatTween _alpha = new FloatTween();
        private readonly Impulse _pop = new Impulse();
        private CanvasGroup _group;
        private Vector2 _restPosition;
        private Vector3 _restScale = Vector3.one;
        private bool _restKnown;

        public Toast Toast { get; private set; }
        public TMP_Text MessageText => messageText;
        private RectTransform Target => motionTarget != null ? motionTarget : transform as RectTransform;

        protected virtual void Awake()
        {
            _group = GetComponent<CanvasGroup>();
            if (messageText == null) Debug.LogError("[ToastView] messageText is required.", this);
        }

        /// <summary>Writes the toast into the view. Called when it is shown and again when a merge updates it.</summary>
        public virtual void Bind(Toast toast)
        {
            Toast = toast;
            if (messageText != null) messageText.text = toast.Request.Message;
            if (countText != null)
            {
                bool many = toast.Count > 1;
                countText.gameObject.SetActive(many);
                if (many) countText.text = string.Format(countFormat, toast.Count);
            }
        }

        public virtual void PlayEnter()
        {
            RememberRest();
            _enter.Play(0f, 1f, enterDuration, Ease.OutBack);
            _alpha.Play(0f, 1f, enterDuration * 0.7f, Ease.OutQuad);
            Apply();
        }

        public virtual void PlayMerge()
        {
            if (mergePop != 0f) _pop.Play(ImpulseKind.Punch, mergePop, 0.2f, 2);
        }

        public virtual void PlayExit(float duration)
        {
            _enter.Complete();
            _alpha.Play(Group.alpha, 0f, duration, Ease.InQuad);
        }

        /// <summary>Clears motion and data before the view goes back to the pool.</summary>
        public virtual void ResetView()
        {
            _enter.Set(1f); _alpha.Set(1f); _pop.Stop();
            Apply();
            Toast = null;
        }

        /// <summary>Advances the motion. The presenter calls it with its own delta time.</summary>
        public virtual void Tick(float deltaTime)
        {
            bool changed = _enter.Tick(deltaTime);
            changed |= _alpha.Tick(deltaTime);
            changed |= _pop.Tick(deltaTime) || _pop.IsPlaying;
            if (changed) Apply();
        }

        private CanvasGroup Group => _group != null ? _group : _group = GetComponent<CanvasGroup>();

        private void RememberRest()
        {
            // Read again on every enter: a layout group or the pool may have moved the view since last time.
            if (Target == null) return;
            _restPosition = Target.anchoredPosition; _restScale = Target.localScale; _restKnown = true;
        }

        private void Apply()
        {
            Group.alpha = _alpha.Value;
            RectTransform target = Target;
            if (target == null || !_restKnown) return;
            float t = _enter.Value;
            // Without a motionTarget the view itself is placed by the container's layout, so only scale moves.
            if (motionTarget != null) target.anchoredPosition = _restPosition + enterOffset * (1f - t);
            float scale = Mathf.LerpUnclamped(enterScale, 1f, t) * (1f + _pop.X);
            target.localScale = _restScale * scale;
        }
    }
}
