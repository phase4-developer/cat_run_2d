using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// Reveals a TextMeshPro text a few characters at a time (dialogue, tutorial). Uses TMP maxVisibleCharacters, so
    /// layout does not jump and rich text tags stay intact. Call <see cref="Skip"/> from a tap to show everything.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class TypewriterText : MonoBehaviour
    {
        [SerializeField] private TMP_Text label;
        [SerializeField, Min(0f), Tooltip("0 shows everything at once.")] private float charactersPerSecond = 30f;
        [SerializeField, Tooltip("Characters followed by a pause.")] private string pauseCharacters = ".!?,…。！？、";
        [SerializeField, Min(0f)] private float pauseSeconds = 0.12f;
        [SerializeField] private bool useUnscaledTime = true;
        [SerializeField] private UnityEvent onCompleted = new UnityEvent();

        private readonly Typewriter _writer = new Typewriter();

        public bool IsPlaying => _writer.IsPlaying;
        public int VisibleCharacters => _writer.Visible;
        public UnityEvent OnCompleted => onCompleted;
        public event Action Completed;

        private void Awake()
        {
            if (label == null) label = GetComponent<TMP_Text>();
            if (label == null) Debug.LogError("[TypewriterText] A TMP_Text label is required.", this);
            Hook();
        }

        private void OnDisable() { if (_writer.IsPlaying) Skip(); }

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        public void Play(string text)
        {
            if (label == null) label = GetComponent<TMP_Text>();
            if (label == null) { Debug.LogError("[TypewriterText] A TMP_Text label is required.", this); return; }
            Hook();
            _writer.CharactersPerSecond = charactersPerSecond;
            _writer.PauseCharacters = pauseCharacters;
            _writer.PauseSeconds = pauseSeconds;
            label.text = text ?? string.Empty;
            label.maxVisibleCharacters = 0;
            _writer.Start(text);
            Apply();
        }

        private bool _hooked;

        private void Hook()
        {
            if (_hooked) return;
            _hooked = true;
            _writer.Completed += () => { onCompleted.Invoke(); Completed?.Invoke(); };
        }

        /// <summary>Shows the whole text now.</summary>
        public void Skip() { _writer.Complete(); Apply(); }

        /// <summary>Advances the reveal. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            if (_writer.Tick(deltaTime)) Apply();
        }

        private void Apply()
        {
            if (label == null) return;
            // TMP counts sprites as one character each; when done, show all to cover any difference.
            label.maxVisibleCharacters = _writer.IsPlaying ? _writer.Visible : 99999;
        }
    }
}
