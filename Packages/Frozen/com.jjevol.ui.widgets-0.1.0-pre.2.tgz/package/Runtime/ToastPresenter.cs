using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// Shows toast messages from a <see cref="ToastQueue"/> with views made from one prefab and kept in an
    /// <see cref="ObjectPool{T}"/>. The container places them (for example with a VerticalLayoutGroup); the prefab owns
    /// the look. This is the general notice toast; the effect-system toast in com.jjevol.effects.ui is a separate
    /// one-shot effect.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ToastPresenter : MonoBehaviour
    {
        [SerializeField, Tooltip("Prefab with a ToastView (or subclass). Required.")] private ToastView viewPrefab;
        [SerializeField, Tooltip("Parent of the views. Empty uses this transform.")] private RectTransform container;
        [SerializeField, Tooltip("New toasts go first in the container instead of last.")] private bool newestFirst;
        [SerializeField, Min(1)] private int maxVisible = 3;
        [SerializeField, Min(0.1f)] private float defaultDuration = 2f;
        [SerializeField, Min(0f), Tooltip("Seconds of the exit motion before a view goes back to the pool.")] private float leaveDuration = 0.25f;
        [SerializeField, Min(0), Tooltip("Waiting toasts kept at most. 0 means no limit.")] private int maxPending = 20;
        [SerializeField] private bool useUnscaledTime = true;

        private readonly ToastQueue _queue = new ToastQueue();
        private readonly Dictionary<Toast, ToastView> _views = new Dictionary<Toast, ToastView>();
        private ObjectPool<ToastView> _pool;

        public ToastQueue Queue => _queue;
        private Transform Container => container != null ? container : transform;

        private void Awake()
        {
            if (viewPrefab == null) Debug.LogError("[ToastPresenter] viewPrefab is required.", this);
            ApplySettings();
            _pool = new ObjectPool<ToastView>(Create, v => v.gameObject.SetActive(true), Release, v => { if (v != null) Destroy(v.gameObject); },
                collectionCheck: true, defaultCapacity: maxVisible, maxSize: Mathf.Max(maxVisible, 1) * 2);
            _queue.Shown += HandleShown;
            _queue.Updated += HandleUpdated;
            _queue.Leaving += HandleLeaving;
            _queue.Removed += HandleRemoved;
        }

        private void OnValidate() { if (Application.isPlaying) ApplySettings(); }

        private void OnDisable() => ClearImmediate();

        private void OnDestroy() => _pool?.Dispose();

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        public Toast Show(string message, float duration = 0f, string mergeKey = null) =>
            Show(new ToastRequest(message) { Duration = duration, MergeKey = mergeKey });

        /// <summary>Queues a toast. Returns null when the presenter cannot show it (no prefab) or the queue dropped it.</summary>
        public Toast Show(ToastRequest request)
        {
            if (viewPrefab == null || _pool == null) { Debug.LogError("[ToastPresenter] Cannot show a toast without viewPrefab.", this); return null; }
            return _queue.Enqueue(request);
        }

        public void Dismiss(Toast toast) => _queue.Dismiss(toast);

        /// <summary>Starts the exit of every toast and drops waiting ones.</summary>
        public void Clear() => _queue.Clear();

        /// <summary>Advances the queue and the views. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            _queue.Tick(deltaTime);
            foreach (ToastView view in _views.Values) view.Tick(deltaTime);
        }

        private void ApplySettings()
        {
            _queue.MaxVisible = maxVisible;
            _queue.DefaultDuration = defaultDuration;
            _queue.LeaveDuration = leaveDuration;
            _queue.MaxPending = maxPending;
        }

        private ToastView Create() => Instantiate(viewPrefab, Container, false);

        private void Release(ToastView view)
        {
            view.ResetView();
            view.gameObject.SetActive(false);
        }

        private void HandleShown(Toast toast)
        {
            ToastView view = _pool.Get();
            if (view.transform.parent != Container) view.transform.SetParent(Container, false);
            if (newestFirst) view.transform.SetAsFirstSibling(); else view.transform.SetAsLastSibling();
            _views[toast] = view;
            view.Bind(toast);
            view.PlayEnter();
        }

        private void HandleUpdated(Toast toast)
        {
            if (!_views.TryGetValue(toast, out ToastView view)) return;
            view.Bind(toast);
            view.PlayMerge();
        }

        private void HandleLeaving(Toast toast)
        {
            if (_views.TryGetValue(toast, out ToastView view)) view.PlayExit(leaveDuration);
        }

        private void HandleRemoved(Toast toast)
        {
            if (!_views.TryGetValue(toast, out ToastView view)) return;
            _views.Remove(toast);
            _pool.Release(view);
        }

        private void ClearImmediate()
        {
            float leave = _queue.LeaveDuration;
            _queue.LeaveDuration = 0f;
            _queue.Clear();
            _queue.LeaveDuration = leave;
        }
    }
}
