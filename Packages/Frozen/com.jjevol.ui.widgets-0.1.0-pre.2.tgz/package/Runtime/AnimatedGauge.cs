using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace jjevol.UI.Widgets
{
    [Serializable] public sealed class GaugeDecreaseEvent : UnityEvent<float, bool> { }
    [Serializable] public sealed class GaugeIncreaseEvent : UnityEvent<float> { }

    /// <summary>
    /// A gauge (health, experience, progress) drawn with three Filled Images from its prefab: the fill, a trail that
    /// stays behind a decrease and drains after a delay, and a lead that shows a gain while the fill catches up.
    /// Optional number texts count along. The images and their look belong to the prefab; this component only sets
    /// fillAmount and alpha.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AnimatedGauge : MonoBehaviour
    {
        [Header("Images (Filled)")]
        [SerializeField, Tooltip("The real value. Required.")] private Image fill;
        [SerializeField, Tooltip("Optional bar behind the fill that drains after a decrease.")] private Image trail;
        [SerializeField, Tooltip("Optional bar behind the fill that shows a gain first.")] private Image lead;

        [Header("Numbers (optional)")]
        [SerializeField, Tooltip("Counts to the current value.")] private AnimatedNumberText valueText;
        [SerializeField, Tooltip("Shows the maximum without counting, for a \"120 / 300\" layout made of two texts.")] private AnimatedNumberText maxText;

        [Header("Motion")]
        [SerializeField] private GaugeTiming timing = new GaugeTiming();
        [SerializeField] private bool useUnscaledTime = true;

        [Header("Impact on decrease")]
        [SerializeField, Tooltip("Moved by the punch and shake. Empty uses this transform.")] private RectTransform impactTarget;
        [SerializeField] private float lightPunch = 0.04f;
        [SerializeField] private float heavyPunch = 0.09f;
        [SerializeField, Min(0.01f)] private float punchDuration = 0.12f;
        [SerializeField, Tooltip("Pixels of shake on a heavy decrease. 0 turns it off.")] private float heavyShake = 6f;
        [SerializeField, Min(0.01f)] private float shakeDuration = 0.16f;

        [Header("Events")]
        [SerializeField, Tooltip("Size of the decrease (0..1) and whether it was heavy. For sound or an Animator trigger.")]
        private GaugeDecreaseEvent onDecreased = new GaugeDecreaseEvent();
        [SerializeField] private GaugeIncreaseEvent onIncreased = new GaugeIncreaseEvent();
        [SerializeField] private UnityEvent onLapCompleted = new UnityEvent();

        private GaugeModel _model;
        private readonly Impulse _punch = new Impulse();
        private readonly Impulse _shake = new Impulse();
        private Vector3 _restScale;
        private Vector2 _restPosition;
        private bool _impactActive;
        private Color _trailColor, _leadColor;
        private decimal _max = 1m;

        public GaugeModel Model => _model ??= CreateModel();
        public float Normalized => Model.Target;
        public decimal Max => _max;
        public GaugeDecreaseEvent OnDecreased => onDecreased;
        public GaugeIncreaseEvent OnIncreased => onIncreased;
        public UnityEvent OnLapCompleted => onLapCompleted;

        private RectTransform ImpactTarget => impactTarget != null ? impactTarget : transform as RectTransform;

        private void Awake()
        {
            if (fill == null) { Debug.LogError("[AnimatedGauge] The fill Image is required.", this); enabled = false; return; }
            _ = Model;
            Apply();
        }

        private void OnDisable()
        {
            // Coming back shows the final state, not the rest of an old animation.
            if (_model != null) { _model.Complete(); Apply(); }
            StopImpact();
        }

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        /// <summary>Shows a value at once (first display, reuse). The maximum must be above 0.</summary>
        public void SetInstant(decimal current, decimal max)
        {
            _max = max;
            Model.SetInstant(Ratio(current, max));
            if (valueText != null) valueText.SetValue(current);
            if (maxText != null) maxText.SetValue(max);
            Apply();
        }

        /// <summary>Animates to a value. <paramref name="laps"/> fills past the end that many times first (an experience bar gaining levels).</summary>
        public void SetValue(decimal current, decimal max, int laps = 0)
        {
            bool maxChanged = max != _max;
            _max = max;
            Model.AnimateTo(Ratio(current, max), laps);
            if (valueText != null) valueText.CountTo(current);
            if (maxText != null && maxChanged) maxText.SetValue(max);
            Apply();
        }

        public void SetNormalized(float value, bool animate = true)
        {
            if (animate) Model.AnimateTo(value); else Model.SetInstant(value);
            Apply();
        }

        public void Complete() { Model.Complete(); if (valueText != null) valueText.Complete(); Apply(); }

        /// <summary>Advances the bars and the impact. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            if (_model == null) return;
            if (_model.Tick(deltaTime)) Apply();
            if (!_impactActive) return;
            _punch.Tick(deltaTime);
            _shake.Tick(deltaTime);
            RectTransform target = ImpactTarget;
            if (target != null)
            {
                target.localScale = _restScale * (1f + _punch.X);
                target.anchoredPosition = _restPosition + new Vector2(_shake.X, _shake.Y);
            }
            if (!_punch.IsPlaying && !_shake.IsPlaying) StopImpact();
        }

        private GaugeModel CreateModel()
        {
            // The prefab colours are read here, before the first Apply, so a call before Awake keeps them.
            if (trail != null) _trailColor = trail.color;
            if (lead != null) _leadColor = lead.color;
            var model = new GaugeModel(timing, fill != null ? fill.fillAmount : 1f);
            model.Decreased += HandleDecreased;
            model.Increased += d => onIncreased.Invoke(d);
            model.LapCompleted += () => onLapCompleted.Invoke();
            return model;
        }

        private void HandleDecreased(float size, bool heavy)
        {
            RectTransform target = ImpactTarget;
            if (target != null && isActiveAndEnabled)
            {
                if (!_impactActive) { _restScale = target.localScale; _restPosition = target.anchoredPosition; }
                _impactActive = true;
                float punch = heavy ? heavyPunch : lightPunch;
                if (punch != 0f) _punch.Play(ImpulseKind.Punch, punch, punchDuration, 8); else _punch.Stop();
                if (heavy && heavyShake > 0f) _shake.Play(ImpulseKind.Shake, heavyShake, shakeDuration, 12, Time.frameCount); else _shake.Stop();
            }
            onDecreased.Invoke(size, heavy);
        }

        private void StopImpact()
        {
            if (!_impactActive) return;
            _punch.Stop(); _shake.Stop();
            RectTransform target = ImpactTarget;
            if (target != null) { target.localScale = _restScale; target.anchoredPosition = _restPosition; }
            _impactActive = false;
        }

        private void Apply()
        {
            if (_model == null) return;
            if (fill != null) fill.fillAmount = _model.Fill;
            if (trail != null)
            {
                trail.fillAmount = _model.Trail;
                trail.color = WithAlpha(_trailColor, _model.TrailAlpha);
            }
            if (lead != null)
            {
                lead.fillAmount = _model.Lead;
                lead.color = WithAlpha(_leadColor, _model.LeadAlpha);
            }
        }

        private static Color WithAlpha(Color color, float alpha) { color.a *= Mathf.Clamp01(alpha); return color; }

        private static float Ratio(decimal current, decimal max)
        {
            if (max <= 0m) return 0f;
            decimal ratio = current / max;
            return ratio <= 0m ? 0f : ratio >= 1m ? 1f : (float)ratio;
        }
    }
}
