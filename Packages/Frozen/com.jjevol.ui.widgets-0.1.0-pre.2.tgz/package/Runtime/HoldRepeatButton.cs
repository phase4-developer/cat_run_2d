using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// Fires <see cref="OnRepeat"/> again and again while a button is held, speeding up over time (quantity +/-).
    /// A short tap is the button's normal click; once a repeat has fired, the release is no longer a click.
    /// Repeats start after the initial delay. Input comes from
    /// EventSystem pointer events. Stops when the pointer leaves, the selectable stops being interactable or the
    /// object is disabled.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class HoldRepeatButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        [SerializeField, Tooltip("Read for interactable. Empty looks on this object.")] private Selectable selectable;
        [SerializeField] private HoldRepeatTiming timing = new HoldRepeatTiming();
        [SerializeField] private bool useUnscaledTime = true;
        [SerializeField] private UnityEvent onRepeat = new UnityEvent();

        private HoldRepeat _hold;

        public UnityEvent OnRepeat => onRepeat;
        public bool IsHeld => Hold.IsHeld;
        public int RepeatCount => Hold.RepeatCount;
        private HoldRepeat Hold => _hold ??= new HoldRepeat(timing);
        private bool Interactable => selectable == null || selectable.IsInteractable();

        private void Awake() { if (selectable == null) selectable = GetComponent<Selectable>(); }

        private void OnDisable() => Hold.Release();

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        public void OnPointerDown(PointerEventData eventData)
        {
            if (eventData.button == PointerEventData.InputButton.Left && Interactable) Hold.Press();
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            // After repeats the release is not also a click, so a +1 button does not add one more at the end.
            // RepeatCount stays until the next press, so leaving and coming back before release is covered too.
            if (Hold.RepeatCount > 0) eventData.eligibleForClick = false;
            Hold.Release();
        }

        public void OnPointerExit(PointerEventData eventData) => Hold.Release();

        /// <summary>Advances the hold and fires the repeats. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            if (!Hold.IsHeld) return;
            if (!Interactable) { Hold.Release(); return; }
            Hold.Timing = timing;
            int count = Hold.Tick(deltaTime);
            for (int i = 0; i < count && Hold.IsHeld; i++) onRepeat.Invoke();
        }
    }
}
