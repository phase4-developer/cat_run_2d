using UnityEngine;

namespace jjevol.UI.Widgets
{
    public enum AttentionStyle
    {
        // Grows and shrinks smoothly.
        Breathe,
        // A short pop, then a rest.
        Pop,
        // A short sideways shake, then a rest.
        Shake
    }

    /// <summary>
    /// Repeats a small motion to draw the eye to a button (claimable reward, new item). Turn it on and off with
    /// <see cref="Play"/> and <see cref="Stop"/> or by enabling the component; the target returns to its resting state
    /// when stopped.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AttentionPulse : MonoBehaviour
    {
        [SerializeField, Tooltip("Moved. Empty uses this transform.")] private RectTransform target;
        [SerializeField] private AttentionStyle style = AttentionStyle.Breathe;
        [SerializeField, Tooltip("Breathe/Pop: extra scale (0.06 = 6%). Shake: pixels.")] private float strength = 0.06f;
        [SerializeField, Min(0.05f), Tooltip("Seconds of one motion.")] private float period = 1.2f;
        [SerializeField, Min(0f), Tooltip("Pop/Shake: seconds of rest between motions.")] private float rest = 1.5f;
        [SerializeField] private bool playOnEnable = true;
        [SerializeField] private bool useUnscaledTime = true;

        private readonly Impulse _impulse = new Impulse();
        private Vector3 _restScale = Vector3.one;
        private Vector2 _restPosition;
        private float _time;
        private bool _playing, _restKnown;

        public bool IsPlaying => _playing;
        private RectTransform Target => target != null ? target : transform as RectTransform;

        private void OnEnable() { if (playOnEnable) Play(); }

        private void OnDisable() => Stop();

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        public void Play()
        {
            if (_playing) return;
            RectTransform t = Target;
            if (t == null) return;
            _restScale = t.localScale; _restPosition = t.anchoredPosition; _restKnown = true;
            _time = 0f; _playing = true;
            StartMotion();
        }

        public void Stop()
        {
            if (!_playing) return;
            _playing = false;
            _impulse.Stop();
            RectTransform t = Target;
            if (t != null && _restKnown) { t.localScale = _restScale; t.anchoredPosition = _restPosition; }
        }

        /// <summary>Advances the motion. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            if (!_playing) return;
            RectTransform t = Target;
            if (t == null) return;
            _time += Mathf.Max(0f, deltaTime);

            if (style == AttentionStyle.Breathe)
            {
                t.localScale = _restScale * (1f + strength * Oscillation.Pulse(_time, period));
                return;
            }

            _impulse.Tick(deltaTime);
            if (style == AttentionStyle.Pop) t.localScale = _restScale * (1f + _impulse.X);
            else t.anchoredPosition = _restPosition + new Vector2(_impulse.X, 0f);
            if (_time >= period + rest) { _time = 0f; StartMotion(); }
        }

        private void StartMotion()
        {
            if (style == AttentionStyle.Pop) _impulse.Play(ImpulseKind.Punch, strength, period, 2);
            else if (style == AttentionStyle.Shake) _impulse.Play(ImpulseKind.Punch, strength, period, 6);
        }
    }
}
