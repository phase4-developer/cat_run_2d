using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// A cooldown on a skill or button: a Filled Image (radial or bar) that empties over the cooldown, optional remaining
    /// time text, and an optional CanvasGroup lock (lockGroup) that blocks the button until it ends. The overlay image and text are shown
    /// only while cooling.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CooldownOverlay : MonoBehaviour
    {
        [SerializeField, Tooltip("Filled Image. fillAmount goes from 1 to 0. Required.")] private Image overlay;
        [SerializeField, Tooltip("Optional remaining time.")] private TMP_Text remainingText;
        [SerializeField, Tooltip("Under this many seconds the text shows one decimal (2.4). 0 always shows whole seconds.")]
        private float decimalsBelow = 3f;
        [SerializeField, Tooltip("Optional CanvasGroup on the button (or around it) that only the cooldown uses: not interactable while cooling. The button's own Selectable.interactable stays the game's, and IsInteractable() reads both.")]
        private CanvasGroup lockGroup;
        [SerializeField, Tooltip("Pop when the cooldown ends. 0 turns it off. Scales this transform.")] private float readyPop = 0.12f;
        [SerializeField] private bool useUnscaledTime;
        [SerializeField] private UnityEvent onReady = new UnityEvent();

        private readonly Impulse _pop = new Impulse();
        private float _duration, _remaining;
        private Vector3 _restScale = Vector3.one;
        private bool _popping;
        private string _written;

        public bool IsCooling => _remaining > 0f;
        public float Remaining => Mathf.Max(0f, _remaining);
        public float Duration => _duration;
        public UnityEvent OnReady => onReady;

        private void Awake()
        {
            if (overlay == null) Debug.LogError("[CooldownOverlay] The overlay Image is required.", this);
            Apply();
        }

        private void OnDisable()
        {
            if (_popping) { _pop.Stop(); transform.localScale = _restScale; _popping = false; }
        }

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        /// <summary>Starts a cooldown of <paramref name="seconds"/>, or continues one already running with <paramref name="remaining"/> left.</summary>
        public void Begin(float seconds, float remaining = -1f)
        {
            _duration = Mathf.Max(0f, seconds);
            _remaining = remaining < 0f ? _duration : Mathf.Min(remaining, _duration);
            _written = null;
            Apply();
            if (_remaining <= 0f) Finish(false);
        }

        /// <summary>Ends the cooldown now without the ready pop.</summary>
        public void Cancel() { _remaining = 0f; Apply(); }

        /// <summary>Advances the cooldown. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            if (_popping)
            {
                _pop.Tick(deltaTime);
                transform.localScale = _restScale * (1f + _pop.X);
                if (!_pop.IsPlaying) { transform.localScale = _restScale; _popping = false; }
            }
            if (_remaining <= 0f) return;
            _remaining -= Mathf.Max(0f, deltaTime);
            Apply();
            if (_remaining <= 0f) Finish(true);
        }

        private void Finish(bool pop)
        {
            _remaining = 0f;
            Apply();
            if (pop && readyPop != 0f && isActiveAndEnabled)
            {
                if (!_popping) _restScale = transform.localScale;
                _popping = true;
                _pop.Play(ImpulseKind.Punch, readyPop, 0.25f, 2);
            }
            onReady.Invoke();
        }

        private void Apply()
        {
            bool cooling = _remaining > 0f;
            if (overlay != null)
            {
                overlay.enabled = cooling;
                overlay.fillAmount = _duration > 0f ? Mathf.Clamp01(_remaining / _duration) : 0f;
            }
            // The lock group belongs to the cooldown alone; the game keeps writing Selectable.interactable as it likes.
            if (lockGroup != null) lockGroup.interactable = !cooling;
            if (remainingText == null) return;
            remainingText.enabled = cooling;
            if (!cooling) return;
            string text = _remaining < decimalsBelow
                ? (Mathf.Ceil(_remaining * 10f) / 10f).ToString("0.0", UIDisplayOptions.DisplayCulture)
                : Mathf.CeilToInt(_remaining).ToString(UIDisplayOptions.DisplayCulture);
            if (text == _written) return;
            _written = text;
            remainingText.text = text;
        }
    }
}
