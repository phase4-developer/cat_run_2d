using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// A TextMeshPro number that counts to new values. Numbers are written with the game's number profile
    /// (<see cref="UIDisplayOptions.NumberFormat"/>) unless this text has its own. Replaces NumberAnimator for new work.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AnimatedNumberText : MonoBehaviour
    {
        [SerializeField] private TMP_Text label;

        [Header("Count")]
        [SerializeField, Min(0f)] private float duration = 0.6f;
        [SerializeField, Min(0f), Tooltip("Extra seconds per order of magnitude of the change. 0 keeps the duration fixed.")]
        private float durationPerDigit;
        [SerializeField, Min(0f), Tooltip("Longest count when durationPerDigit lengthens it.")]
        private float maxDuration = 1.5f;
        [SerializeField] private Ease ease = Ease.OutCubic;
        [SerializeField, Range(0, 10), Tooltip("Digits after the decimal point while counting.")]
        private int decimalPlaces;
        [SerializeField] private bool useUnscaledTime = true;

        [Header("Text")]
        [SerializeField] private string prefix = string.Empty;
        [SerializeField] private string suffix = string.Empty;
        [SerializeField, Tooltip("Optional .NET composite format with {0} for the number, for example \"x{0}\" or \"{0}%\".")]
        private string format = string.Empty;
        [SerializeField] private bool hideIfZero;
        [SerializeField, Tooltip("Shorten with the language's built-in abbreviation (1.2K, 1억 2000만) when the game profile shows every digit.")]
        private bool abbreviate;
        [SerializeField, Tooltip("Use the profile below instead of the game-wide one.")]
        private bool overrideNumberFormat;
        [SerializeField] private NumberFormatProfile numberFormat = new NumberFormatProfile();

        [Header("Change feedback")]
        [SerializeField, Tooltip("Scale pop each time a count starts. 0 turns it off.")]
        private float popScale = 0.12f;
        [SerializeField, Min(0.01f)] private float popDuration = 0.25f;
        [SerializeField] private bool tintChanges;
        [SerializeField] private Color increaseColor = new Color(0.45f, 1f, 0.45f);
        [SerializeField] private Color decreaseColor = new Color(1f, 0.4f, 0.35f);
        [SerializeField] private UnityEvent onCountCompleted = new UnityEvent();

        private readonly NumberCounter _counter = new NumberCounter();
        private readonly Impulse _pop = new Impulse();
        private Color _baseColor;
        private bool _baseColorKnown;
        private Vector3 _baseScale = Vector3.one;
        private bool _popping;

        public decimal Value => _counter.Current;
        public decimal Target => _counter.Target;
        public bool IsCounting => _counter.IsPlaying;
        public TMP_Text Label => label;
        public UnityEvent OnCountCompleted => onCountCompleted;
        public event Action CountCompleted;

        public string Prefix { get => prefix; set { prefix = value ?? string.Empty; Redraw(); } }
        public string Suffix { get => suffix; set { suffix = value ?? string.Empty; Redraw(); } }
        public string Format { get => format; set { format = value ?? string.Empty; Redraw(); } }

        /// <summary>This text's own number profile, or null when it follows the game-wide one.</summary>
        public NumberFormatProfile NumberFormatOverride
        {
            get => overrideNumberFormat ? numberFormat : null;
            set { overrideNumberFormat = value != null; numberFormat = value?.Copy() ?? new NumberFormatProfile(); Redraw(); }
        }

        private void Awake()
        {
            if (label == null) label = GetComponent<TMP_Text>();
            if (label == null) Debug.LogError("[AnimatedNumberText] A TMP_Text label is required.", this);
            _counter.Completed += HandleCompleted;
            ApplySettings();
            Redraw();
        }

        private void OnEnable() => UIDisplayOptions.LocaleChanged += Redraw;

        private void OnDisable()
        {
            UIDisplayOptions.LocaleChanged -= Redraw;
            // A hidden text shows its final state when it comes back.
            _counter.Complete();
            StopPop();
            Redraw();
        }

        private void OnValidate() { if (Application.isPlaying && _counter != null) { ApplySettings(); Redraw(); } }

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        /// <summary>Shows <paramref name="value"/> at once, for first display and reuse.</summary>
        public void SetValue(decimal value)
        {
            StopPop();
            _counter.Set(value);
            RestoreColor();
            Redraw();
        }

        /// <summary>Counts from the shown value to <paramref name="value"/>.</summary>
        public void CountTo(decimal value)
        {
            if (value == _counter.Current && !_counter.IsPlaying) { _counter.CountTo(value); Redraw(); return; }
            ApplySettings();
            decimal from = _counter.Current;
            _counter.CountTo(value);
            if (tintChanges && label != null && value != from && _counter.IsPlaying)
            {
                RememberColor();
                label.color = value > from ? increaseColor : decreaseColor;
            }
            if (popScale != 0f && isActiveAndEnabled)
            {
                if (!_popping) _baseScale = transform.localScale;
                _popping = true;
                _pop.Play(ImpulseKind.Punch, popScale, popDuration, 2);
            }
            Redraw();
        }

        /// <summary>Ends the count at its target.</summary>
        public void Complete() { _counter.Complete(); Redraw(); }

        /// <summary>Advances the count and the pop. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            if (_counter.Tick(deltaTime)) Redraw();
            if (_popping)
            {
                _pop.Tick(deltaTime);
                transform.localScale = _baseScale * (1f + _pop.X);
                if (!_pop.IsPlaying) StopPop();
            }
        }

        /// <summary>The text for <paramref name="value"/> with this label's prefix, suffix, format and number profile.</summary>
        public string FormatValue(decimal value)
        {
            if (hideIfZero && value == 0m) return string.Empty;
            string number = FormatNumber(value);
            if (!string.IsNullOrEmpty(format))
            {
                try { number = string.Format(UIDisplayOptions.DisplayCulture, format, number); }
                catch (FormatException) { Debug.LogWarning("[AnimatedNumberText] format is not a valid composite format: " + format, this); }
            }
            return prefix + number + suffix;
        }

        /// <summary>The number alone with this label's profile, for a related label such as the maximum of a gauge.</summary>
        public string FormatNumber(decimal value) =>
            UIDisplayOptions.FormatNumber(value, abbreviate ? UIDisplayOptions.AbbreviatedNumberFormat(NumberFormatOverride) : NumberFormatOverride);

        public void Redraw()
        {
            if (label != null) label.text = FormatValue(_counter.Current);
        }

        private void ApplySettings()
        {
            _counter.Duration = duration;
            _counter.DurationPerUnit = durationPerDigit;
            _counter.MaxDuration = maxDuration;
            _counter.Ease = ease;
            _counter.DecimalPlaces = decimalPlaces;
        }

        private void HandleCompleted()
        {
            RestoreColor();
            onCountCompleted.Invoke();
            CountCompleted?.Invoke();
        }

        private void RememberColor()
        {
            if (_baseColorKnown || label == null) return;
            _baseColor = label.color; _baseColorKnown = true;
        }

        private void RestoreColor()
        {
            if (!_baseColorKnown || label == null) return;
            label.color = _baseColor; _baseColorKnown = false;
        }

        private void StopPop()
        {
            if (!_popping) return;
            _pop.Stop();
            transform.localScale = _baseScale;
            _popping = false;
        }
    }
}
