using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// Remaining time in a TextMeshPro text (event end, free reward, energy refill). Counts to an end time on a clock
    /// the game supplies (server time, for example), or down from a number of seconds. The text changes only when the
    /// written value changes.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class CountdownText : MonoBehaviour
    {
        [SerializeField] private TMP_Text label;
        [SerializeField] private DurationFormatProfile format = new DurationFormatProfile();
        [SerializeField, Tooltip("Optional composite format with {0} for the time, for example \"Ends in {0}\".")] private string template = string.Empty;
        [SerializeField, Tooltip("Text when the time is over. Empty keeps the zero time.")] private string finishedText = string.Empty;
        [SerializeField] private UnityEvent onFinished = new UnityEvent();

        private DateTime? _endUtc;
        private double _remaining;
        private bool _running, _started;
        private string _written;

        public UnityEvent OnFinished => onFinished;
        public bool IsRunning => _running;
        public DurationFormatProfile Format { get => format; set { format = value?.Copy() ?? new DurationFormatProfile(); Redraw(true); } }

        public double RemainingSeconds => _endUtc.HasValue ? Math.Max(0d, (_endUtc.Value - Now()).TotalSeconds) : Math.Max(0d, _remaining);

        private void Awake()
        {
            if (label == null) label = GetComponent<TMP_Text>();
            if (label == null) Debug.LogError("[CountdownText] A TMP_Text label is required.", this);
        }

        private void OnEnable()
        {
            UIDisplayOptions.LocaleChanged += RedrawForced;
            // An end time stays correct while hidden; a remaining count resumes where it stopped.
            Redraw(true);
        }

        private void OnDisable() => UIDisplayOptions.LocaleChanged -= RedrawForced;

        private void Update() => Tick(Time.unscaledDeltaTime);

        /// <summary>Counts to an end time in UTC on the <see cref="UIDisplayOptions.UtcNow"/> clock.</summary>
        public void SetEndTime(DateTime endUtc)
        {
            _endUtc = endUtc.Kind == DateTimeKind.Local ? endUtc.ToUniversalTime() : endUtc;
            _running = true; _started = true;
            Redraw(true);
            CheckFinished();
        }

        /// <summary>Counts down from <paramref name="seconds"/> of real time.</summary>
        public void SetRemaining(double seconds)
        {
            _endUtc = null; _remaining = Math.Max(0d, seconds); _running = true; _started = true;
            Redraw(true);
            CheckFinished();
        }

        public void Stop() => _running = false;

        /// <summary>Advances a remaining count and redraws. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            if (!_running) return;
            if (!_endUtc.HasValue) _remaining -= Math.Max(0f, deltaTime);
            Redraw(false);
            CheckFinished();
        }

        private void CheckFinished()
        {
            if (!_running || RemainingSeconds > 0d) return;
            _running = false;
            Redraw(true);
            onFinished.Invoke();
        }

        private void RedrawForced() => Redraw(true);

        private void Redraw(bool force)
        {
            if (label == null) return;
            double remaining = RemainingSeconds;
            string text;
            if (_started && !_running && remaining <= 0d && !string.IsNullOrEmpty(finishedText)) text = finishedText;
            else
            {
                text = DurationFormat.Format(remaining, format, UIDisplayOptions.DisplayCulture);
                if (!string.IsNullOrEmpty(template))
                {
                    try { text = string.Format(UIDisplayOptions.DisplayCulture, template, text); }
                    catch (FormatException) { Debug.LogWarning("[CountdownText] template is not a valid composite format: " + template, this); }
                }
            }
            if (!force && text == _written) return;
            _written = text;
            label.text = text;
        }

        private static DateTime Now() => UIDisplayOptions.Now;
    }
}
