using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace jjevol.UI.Widgets
{
    /// <summary>
    /// Press feedback for any button or selectable: shrinks while pressed, pops on release, optional hover scale, and a
    /// short shake when a non-interactable selectable is clicked. Input comes from EventSystem pointer events, so popups
    /// and raycast blockers stop it like any button. Put it on the button; the scaled target can be a child.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class ButtonFeedback : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
    {
        [SerializeField, Tooltip("Scaled and shaken. Empty uses this transform.")] private RectTransform target;
        [SerializeField, Tooltip("Read for interactable. Empty looks on this object.")] private Selectable selectable;
        [SerializeField] private bool useUnscaledTime = true;

        [Header("Press")]
        [SerializeField] private float pressedScale = 0.92f;
        [SerializeField, Min(0.01f)] private float pressDuration = 0.08f;
        [SerializeField, Tooltip("Pop on release. 0 turns it off.")] private float releasePop = 0.08f;
        [SerializeField, Min(0.01f)] private float releaseDuration = 0.25f;

        [Header("Hover (mouse)")]
        [SerializeField, Tooltip("1 turns hover off.")] private float hoverScale = 1f;

        [Header("Not interactable")]
        [SerializeField, Tooltip("Pixels of shake when clicked while not interactable. 0 turns it off.")] private float disabledShake = 8f;
        [SerializeField, Min(0.01f)] private float disabledShakeDuration = 0.25f;

        private readonly FloatTween _scale = new FloatTween(1f);
        private readonly Impulse _pop = new Impulse();
        private readonly Impulse _shake = new Impulse();
        private Vector3 _restScale = Vector3.one;
        private Vector2 _restPosition;
        private bool _scaleActive, _shakeActive, _pressed, _hovered;

        public bool IsPressed => _pressed;
        private RectTransform Target => target != null ? target : transform as RectTransform;
        private bool Interactable => selectable == null || selectable.IsInteractable();

        private void Awake()
        {
            if (selectable == null) selectable = GetComponent<Selectable>();
        }

        private void OnDisable()
        {
            _pressed = false; _hovered = false;
            _scale.Set(1f); _pop.Stop(); _shake.Stop();
            EndScale(); EndShake();
        }

        private void Update() => Tick(useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime);

        public void OnPointerDown(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left || !Interactable) return;
            _pressed = true;
            BeginScale();
            _pop.Stop();
            _scale.Play(pressedScale, pressDuration, Ease.OutQuad);
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (!_pressed) return;
            _pressed = false;
            _scale.Play(RestingScale, releaseDuration * 0.5f, Ease.OutQuad);
            if (releasePop != 0f && eventData.pointerCurrentRaycast.gameObject != null && IsInside(eventData)) _pop.Play(ImpulseKind.Punch, releasePop, releaseDuration, 2);
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            _hovered = true;
            if (!_pressed && Interactable && !Mathf.Approximately(hoverScale, 1f)) { BeginScale(); _scale.Play(RestingScale, pressDuration, Ease.OutQuad); }
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            _hovered = false;
            if (!_pressed && _scaleActive) _scale.Play(1f, pressDuration, Ease.OutQuad);
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left || Interactable || disabledShake <= 0f) return;
            Shake();
        }

        /// <summary>Plays the release pop from code, for example when a key or gamepad triggers the button.</summary>
        public void Pop() { if (releasePop == 0f) return; BeginScale(); _pop.Play(ImpulseKind.Punch, releasePop, releaseDuration, 2); }

        /// <summary>Plays the not-interactable shake from code.</summary>
        public void Shake()
        {
            if (disabledShake <= 0f) return;
            BeginShake();
            _shake.Play(ImpulseKind.Shake, disabledShake, disabledShakeDuration, 10, Time.frameCount);
        }

        /// <summary>Advances the motion. Called from Update; tests call it directly.</summary>
        public void Tick(float deltaTime)
        {
            _scale.Tick(deltaTime); _pop.Tick(deltaTime); _shake.Tick(deltaTime);
            RectTransform t = Target;
            if (t == null) return;
            if (_scaleActive)
            {
                t.localScale = _restScale * (_scale.Value * (1f + _pop.X));
                if (!_pressed && !_scale.IsPlaying && !_pop.IsPlaying && Mathf.Approximately(_scale.Value, 1f)) EndScale();
            }
            if (_shakeActive)
            {
                t.anchoredPosition = _restPosition + new Vector2(_shake.X, 0f);
                if (!_shake.IsPlaying) EndShake();
            }
        }

        private float RestingScale => _hovered && Interactable ? hoverScale : 1f;

        private bool IsInside(PointerEventData eventData)
        {
            Transform hit = eventData.pointerCurrentRaycast.gameObject.transform;
            return hit == transform || hit.IsChildOf(transform);
        }

        // The resting scale and position are read when a motion starts from rest and written back once when it ends,
        // so a layout group or a reused cell that moves the button in between is not undone.
        private void BeginScale()
        {
            if (_scaleActive || Target == null) return;
            _restScale = Target.localScale; _scaleActive = true;
        }

        private void EndScale()
        {
            if (!_scaleActive) return;
            if (Target != null) Target.localScale = _restScale;
            _scaleActive = false;
        }

        private void BeginShake()
        {
            if (_shakeActive || Target == null) return;
            _restPosition = Target.anchoredPosition; _shakeActive = true;
        }

        private void EndShake()
        {
            if (!_shakeActive) return;
            if (Target != null) Target.anchoredPosition = _restPosition;
            _shakeActive = false;
        }
    }
}
