using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace jjevol.Badge
{
    /// <summary>
    /// Seen store kept in a <see cref="DataContainer"/>, so it saves and loads with the game's data repository.
    /// Stored shape (key <c>badgeSeen</c> by default):
    /// <code>{ "badgeSeen": { "version": 1, "scopes": { "costume": ["1203", "1204@2"], "mail": [] } } }</code>
    /// Tokens are written sorted (ordinal). An update merges per scope: a scope in the update replaces that scope.
    /// Reading is strict: a version other than the integer 1, an unknown field, a non-string or empty token, or a duplicate
    /// token rejects the whole change.
    /// </summary>
    public sealed class BadgeSeenContainer : DataContainer, IBadgeSeenStore
    {
        public const string DefaultKey = "badgeSeen";
        public const int Version = 1;

        private sealed class SeenState
        {
            public static readonly SeenState Empty = new SeenState(new Dictionary<string, HashSet<string>>(StringComparer.Ordinal));
            public readonly Dictionary<string, HashSet<string>> Scopes;
            public SeenState(Dictionary<string, HashSet<string>> scopes) { Scopes = scopes; }
        }

        private static readonly string[] NoTokens = new string[0];

        public BadgeSeenContainer(string key = DefaultKey) : base(key, SeenState.Empty)
        {
            base.Changed += change => SeenChanged?.Invoke(change.ChangedKeys);
        }

        private event Action<IReadOnlyList<string>> SeenChanged;

        event Action<IReadOnlyList<string>> IBadgeSeenStore.Changed
        {
            add => SeenChanged += value;
            remove => SeenChanged -= value;
        }

        private SeenState Current => (SeenState)State;

        public IReadOnlyCollection<string> ScopeNames => new List<string>(Current.Scopes.Keys);

        public bool IsKnown(string scope)
        {
            BadgeSeenRules.ValidateScope(scope);
            return Current.Scopes.ContainsKey(scope);
        }

        public bool IsSeen(string scope, string token)
        {
            BadgeSeenRules.ValidateScope(scope);
            return token != null && Current.Scopes.TryGetValue(scope, out HashSet<string> set) && set.Contains(token);
        }

        public IReadOnlyCollection<string> Seen(string scope)
        {
            BadgeSeenRules.ValidateScope(scope);
            return Current.Scopes.TryGetValue(scope, out HashSet<string> set) ? (IReadOnlyCollection<string>)new List<string>(set) : NoTokens;
        }

        /// <summary>Adds tokens through <see cref="DataContainer.UpdateJson"/>, so a registered repository applies and tracks it.</summary>
        public bool MarkSeen(string scope, IEnumerable<string> tokens)
        {
            BadgeSeenRules.ValidateScope(scope);
            List<string> list = BadgeSeenRules.Tokens(tokens);
            var next = Current.Scopes.TryGetValue(scope, out HashSet<string> set)
                ? new HashSet<string>(set, StringComparer.Ordinal)
                : new HashSet<string>(StringComparer.Ordinal);
            bool changed = set == null;
            foreach (string token in list) changed |= next.Add(token);
            return changed && UpdateJson(Patch(scope, next));
        }

        public bool Retain(string scope, IEnumerable<string> keep)
        {
            BadgeSeenRules.ValidateScope(scope);
            var kept = new HashSet<string>(BadgeSeenRules.Tokens(keep), StringComparer.Ordinal);
            if (!Current.Scopes.TryGetValue(scope, out HashSet<string> set)) return false;
            var next = new HashSet<string>(set, StringComparer.Ordinal);
            if (next.RemoveWhere(token => !kept.Contains(token)) == 0) return false;
            return UpdateJson(Patch(scope, next));
        }

        /// <summary>An update document for one scope, in the stored shape.</summary>
        public JObject Patch(string scope, IEnumerable<string> tokens)
        {
            BadgeSeenRules.ValidateScope(scope);
            return new JObject { [DataKey] = Body(new Dictionary<string, IEnumerable<string>> { [scope] = tokens }) };
        }

        protected override StateChange ParseState(JObject data, bool replace)
        {
            if (!data.TryGetValue(DataKey, out JToken token))
            {
                if (replace) throw new FormatException("Missing seen data: " + DataKey);
                return new StateChange(Current, new string[0]);
            }
            if (!(token is JObject body)) throw new FormatException(DataKey + " must be an object.");
            JToken version = body["version"];
            if (version == null || version.Type != JTokenType.Integer || version.Value<long>() != Version)
                throw new FormatException(DataKey + ".version must be the integer " + Version + ".");
            if (!(body["scopes"] is JObject scopes)) throw new FormatException(DataKey + ".scopes must be an object.");
            foreach (JProperty property in body.Properties())
                if (property.Name != "version" && property.Name != "scopes") throw new FormatException("Unknown seen data field: " + DataKey + "." + property.Name);

            var incoming = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);
            foreach (JProperty property in scopes.Properties())
            {
                try { BadgeSeenRules.ValidateScope(property.Name); }
                catch (ArgumentException exception) { throw new FormatException(exception.Message); }
                if (!(property.Value is JArray array)) throw new FormatException(DataKey + ".scopes." + property.Name + " must be an array.");
                var set = new HashSet<string>(StringComparer.Ordinal);
                foreach (JToken item in array)
                {
                    if (item.Type != JTokenType.String) throw new FormatException("Seen tokens must be strings: " + property.Name);
                    string value = (string)item;
                    try { BadgeSeenRules.ValidateToken(value); }
                    catch (ArgumentException exception) { throw new FormatException(exception.Message); }
                    if (!set.Add(value)) throw new FormatException("Duplicate seen token '" + value + "' in " + property.Name);
                }
                incoming[property.Name] = set;
            }

            Dictionary<string, HashSet<string>> old = Current.Scopes;
            var next = replace ? new Dictionary<string, HashSet<string>>(StringComparer.Ordinal) : new Dictionary<string, HashSet<string>>(old, StringComparer.Ordinal);
            foreach (KeyValuePair<string, HashSet<string>> pair in incoming) next[pair.Key] = pair.Value;

            var changed = new List<string>();
            foreach (KeyValuePair<string, HashSet<string>> pair in next)
                if (!old.TryGetValue(pair.Key, out HashSet<string> before) || !before.SetEquals(pair.Value)) changed.Add(pair.Key);
            foreach (string scope in old.Keys)
                if (!next.ContainsKey(scope)) changed.Add(scope);
            return new StateChange(changed.Count == 0 ? Current : new SeenState(next), changed);
        }

        protected override JObject WriteState(object state)
        {
            var scopes = new Dictionary<string, IEnumerable<string>>(StringComparer.Ordinal);
            foreach (KeyValuePair<string, HashSet<string>> pair in ((SeenState)state).Scopes) scopes[pair.Key] = pair.Value;
            return new JObject { [DataKey] = Body(scopes) };
        }

        private static JObject Body(Dictionary<string, IEnumerable<string>> scopes)
        {
            var names = new List<string>(scopes.Keys);
            names.Sort(StringComparer.Ordinal);
            var json = new JObject();
            foreach (string name in names)
            {
                var tokens = new List<string>(scopes[name]);
                tokens.Sort(StringComparer.Ordinal);
                json[name] = new JArray(tokens);
            }
            return new JObject { ["version"] = Version, ["scopes"] = json };
        }
    }
}
