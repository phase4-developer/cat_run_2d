using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace jjevol.Badge.Tests
{
    public sealed class BadgeTreeTests
    {
        private ManualBadgeScheduler _scheduler;
        private BadgeTree _tree;
        private List<string> _errors;

        [SetUp]
        public void SetUp()
        {
            _scheduler = new ManualBadgeScheduler();
            _tree = new BadgeTree(_scheduler);
            _errors = new List<string>();
            _tree.Error += (key, exception) => _errors.Add((key ?? "<tree>") + ": " + exception.Message);
        }

        // ---------- totals ----------

        [Test]
        public void ParentTotalsChildCountsAndDotsDoNotAddToCounts()
        {
            _tree.Set("lobby/quest/daily", BadgeValue.Of(2));
            _tree.Set("lobby/quest/weekly", BadgeValue.Of(3));
            _tree.Set("lobby/shop/new", BadgeValue.Dot);
            _scheduler.Run();

            Assert.AreEqual(BadgeValue.Of(5), _tree.Get("lobby/quest"));
            Assert.AreEqual(BadgeValue.Dot, _tree.Get("lobby/shop"));
            BadgeValue lobby = _tree.Get("lobby");
            Assert.AreEqual(5, lobby.Count);
            Assert.IsTrue(lobby.On);
            Assert.IsEmpty(_errors);
        }

        [Test]
        public void ParentOnlyWithDotChildIsOnWithZeroCount()
        {
            _tree.Set("menu/a", BadgeValue.Dot);
            _scheduler.Run();
            Assert.AreEqual(0, _tree.Get("menu").Count);
            Assert.IsTrue(_tree.Get("menu").On);
        }

        [Test]
        public void LinkedKeyCountsOnceUnderACommonAncestor()
        {
            _tree.Set("lobby/quest/pass", BadgeValue.Of(4));
            _tree.Link("lobby/event", "lobby/quest/pass");
            _scheduler.Run();

            Assert.AreEqual(4, _tree.Get("lobby/event").Count);
            Assert.AreEqual(4, _tree.Get("lobby/quest").Count);
            Assert.AreEqual(4, _tree.Get("lobby").Count, "reached by two paths, counted once");
        }

        [Test]
        public void UnlinkRemovesTheExtraParentTotal()
        {
            _tree.Set("a/b", BadgeValue.Of(1));
            _tree.Link("c", "a/b");
            _scheduler.Run();
            Assert.AreEqual(1, _tree.Get("c").Count);

            _tree.Unlink("c", "a/b");
            _scheduler.Run();
            Assert.AreEqual(BadgeValue.None, _tree.Get("c"));
            Assert.AreEqual(1, _tree.Get("a").Count);
        }

        [Test]
        public void HugeCountsClampInsteadOfOverflowing()
        {
            _tree.Set("r/a", BadgeValue.Of(int.MaxValue));
            _tree.Set("r/b", BadgeValue.Of(5));
            _scheduler.Run();
            Assert.AreEqual(int.MaxValue, _tree.Get("r").Count);
        }

        [Test]
        public void NegativeCountIsRejected()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => BadgeValue.Of(-1));
        }

        // ---------- invalidation ----------

        [Test]
        public void ManyInvalidationsInOneFrameReadEachProviderOnceAndRequestOnce()
        {
            int readsA = 0, readsB = 0, count = 1;
            _tree.Register("q/a", () => { readsA++; return BadgeValue.Of(count); });
            _tree.Register("q/b", () => { readsB++; return BadgeValue.Dot; });
            _scheduler.Run();
            Assert.AreEqual(1, readsA);
            int requestsBefore = _scheduler.Requests;

            count = 3;
            for (int i = 0; i < 10; i++) { _tree.Invalidate("q/a"); _tree.InvalidateUnder("q"); }
            Assert.AreEqual(requestsBefore + 1, _scheduler.Requests, "one request per dirty period");
            Assert.AreEqual(1, _tree.Get("q").Count, "nothing recomputes before the scheduler runs");

            _scheduler.Run();
            Assert.AreEqual(2, readsA);
            Assert.AreEqual(2, readsB);
            Assert.AreEqual(3, _tree.Get("q").Count);
            Assert.AreEqual(BadgeValue.Of(3), _tree.Get("q/a"));
            Assert.IsFalse(_tree.IsDirty);
        }

        [Test]
        public void CleanTreeRequestsNothing()
        {
            _tree.Set("a", BadgeValue.Dot);
            _scheduler.Run();
            int requests = _scheduler.Requests;
            _tree.Set("a", BadgeValue.Dot);           // same value
            _tree.Invalidate("unknown/key");         // not registered
            Assert.AreEqual(requests, _scheduler.Requests);
            Assert.IsFalse(_scheduler.IsPending);
        }

        [Test]
        public void WatchersHearOnlyChangedTotalsOncePerRecompute()
        {
            var heard = new List<string>();
            _tree.Watch("lobby", v => heard.Add("lobby=" + v));
            _tree.Watch("lobby/quest", v => heard.Add("quest=" + v));
            _tree.Watch("lobby/shop", v => heard.Add("shop=" + v));
            heard.Clear();   // initial calls

            _tree.Set("lobby/quest/a", BadgeValue.Of(1));
            _tree.Set("lobby/quest/b", BadgeValue.Of(1));
            _scheduler.Run();
            CollectionAssert.AreEqual(new[] { "lobby=2", "quest=2" }, heard);

            heard.Clear();
            _tree.Set("lobby/quest/a", BadgeValue.Of(1));
            _scheduler.Run();
            Assert.IsEmpty(heard);
        }

        [Test]
        public void WatchCallsAtOnceWithTheCurrentValue()
        {
            _tree.Set("a/b", BadgeValue.Of(2));
            _scheduler.Run();
            BadgeValue seen = BadgeValue.None;
            _tree.Watch("a", v => seen = v);
            Assert.AreEqual(BadgeValue.Of(2), seen);
        }

        [Test]
        public void ChangesMadeByWatchersRecomputeInTheSameFlush()
        {
            _tree.Watch("a", v => { if (v.On) _tree.Set("b", BadgeValue.Dot); });
            _tree.Set("a", BadgeValue.Dot);
            _scheduler.Run();
            Assert.AreEqual(BadgeValue.Dot, _tree.Get("b"));
            Assert.IsFalse(_scheduler.IsPending);
        }

        [Test]
        public void WatcherThatAlwaysChangesBadgesIsCutAndReported()
        {
            int n = 0;
            _tree.Watch("a", v => _tree.Set("a", BadgeValue.Of(++n)));
            _scheduler.Run();
            Assert.AreEqual(BadgeTree.MaxPassesPerFlush, _tree.Recomputes);
            Assert.IsTrue(_scheduler.IsPending, "the rest waits for the next request");
            Assert.AreEqual(1, _errors.Count);
        }

        [Test]
        public void ImmediateSchedulerRecomputesRightAway()
        {
            var tree = new BadgeTree(new ImmediateBadgeScheduler());
            tree.Set("x/y", BadgeValue.Of(2));
            Assert.AreEqual(2, tree.Get("x").Count);
        }

        [Test]
        public void ProviderErrorIsReportedAndCountsAsNone()
        {
            _tree.Register("a/bad", () => throw new InvalidOperationException("boom"));
            _tree.Set("a/good", BadgeValue.Of(1));
            _scheduler.Run();
            Assert.AreEqual(1, _tree.Get("a").Count);
            Assert.AreEqual(1, _errors.Count);
            StringAssert.StartsWith("a/bad", _errors[0]);
        }

        [Test]
        public void WatcherErrorDoesNotStopOtherWatchers()
        {
            bool other = false;
            _tree.Watch("a", v => throw new InvalidOperationException("view broke"));
            _tree.Watch("a", v => other = v.On);
            _tree.Set("a", BadgeValue.Dot);
            _scheduler.Run();
            Assert.IsTrue(other);
            Assert.AreEqual(2, _errors.Count, "initial call and the change both threw");
        }

        [Test]
        public void ProvidersCannotChangeStructure()
        {
            _tree.Register("a", () => { _tree.Set("b", BadgeValue.Dot); return BadgeValue.Dot; });
            _scheduler.Run();
            Assert.AreEqual(1, _errors.Count);
            Assert.IsFalse(_tree.Contains("b"));
        }

        [Test]
        public void SourceKindsDoNotMix()
        {
            IDisposable registration = _tree.Register("a", () => BadgeValue.Dot);
            Assert.Throws<InvalidOperationException>(() => _tree.Set("a", BadgeValue.Dot));
            Assert.Throws<InvalidOperationException>(() => _tree.Register("a", () => BadgeValue.None));
            registration.Dispose();
            _tree.Set("a", BadgeValue.Dot);
            Assert.Throws<InvalidOperationException>(() => _tree.Register("a", () => BadgeValue.None));
        }

        [Test]
        public void DisposingARegistrationTurnsTheSourceOff()
        {
            IDisposable registration = _tree.Register("p/a", () => BadgeValue.Of(2));
            _scheduler.Run();
            registration.Dispose();
            registration.Dispose();
            _scheduler.Run();
            Assert.AreEqual(BadgeValue.None, _tree.Get("p"));
        }

        [Test]
        public void PostedWorkRunsAfterNotificationsOutsideProviders()
        {
            var order = new List<string>();
            _tree.Watch("a", v => { if (v.On) order.Add("watch"); });
            _tree.Set("a", BadgeValue.Dot);
            _tree.Post(() => { order.Add("post"); _tree.Set("b", BadgeValue.Dot); });
            _scheduler.Run();
            CollectionAssert.AreEqual(new[] { "watch", "post" }, order);
            Assert.AreEqual(BadgeValue.Dot, _tree.Get("b"), "a change made by posted work recomputes in the same flush");
            Assert.IsFalse(_scheduler.IsPending);
            Assert.IsEmpty(_errors);
        }

        [Test]
        public void WatcherAddedDuringNotificationsHearsTheValueOnce()
        {
            var heard = new List<BadgeValue>();
            _tree.Watch("a", v => { if (v.On && heard.Count == 0) _tree.Watch("b", heard.Add); });
            _tree.Set("a", BadgeValue.Dot);
            _tree.Set("b", BadgeValue.Of(2));
            _scheduler.Run();
            CollectionAssert.AreEqual(new[] { BadgeValue.Of(2) }, heard);
        }

        // ---------- dynamic keys ----------

        [Test]
        public void DynamicItemKeysAddAndRemove()
        {
            var heard = new List<BadgeValue>();
            _tree.Watch("list", v => heard.Add(v));
            _tree.Watch(BadgeKey.Child("list", 2), v => heard.Add(v));
            heard.Clear();

            for (int id = 1; id <= 3; id++) _tree.Set(BadgeKey.Child("list", id), BadgeValue.Of(1));
            _scheduler.Run();
            Assert.AreEqual(3, _tree.Get("list").Count);

            heard.Clear();
            Assert.AreEqual(1, _tree.Remove("list/2"));
            _scheduler.Run();
            Assert.AreEqual(2, _tree.Get("list").Count);
            Assert.IsFalse(_tree.Contains("list/2"));
            CollectionAssert.AreEquivalent(new[] { BadgeValue.Of(2), BadgeValue.None }, heard, "item watcher hears none");

            Assert.AreEqual(3, _tree.Remove("list"));
            _scheduler.Run();
            Assert.AreEqual(0, _tree.Keys.Count);
        }

        [Test]
        public void RemovingAKeyAlsoDropsItsLinks()
        {
            _tree.Set("items/1", BadgeValue.Of(1));
            _tree.Link("hub", "items/1");
            _scheduler.Run();
            _tree.Remove("items");
            _scheduler.Run();
            Assert.AreEqual(BadgeValue.None, _tree.Get("hub"));
            _tree.Set("items/1", BadgeValue.Of(1));
            _scheduler.Run();
            Assert.AreEqual(BadgeValue.None, _tree.Get("hub"), "a new key with the same name is not linked again");
        }

        [Test]
        public void RemoveAndAddAgainBeforeRecomputeKeepsWatchersRight()
        {
            BadgeValue seen = BadgeValue.None;
            _tree.Watch("l/1", v => seen = v);
            _tree.Set("l/1", BadgeValue.Of(1));
            _scheduler.Run();
            Assert.AreEqual(BadgeValue.Of(1), seen);

            _tree.Remove("l/1");
            _tree.Define("l/1");
            _scheduler.Run();
            Assert.AreEqual(BadgeValue.None, seen);
        }

        [Test]
        public void KeysOfRemovedItemsDoNotStayBehind()
        {
            for (int round = 0; round < 50; round++)
            {
                _tree.Set(BadgeKey.Child("feed", round), BadgeValue.Dot);
                _scheduler.Run();
                _tree.Remove(BadgeKey.Child("feed", round));
                _scheduler.Run();
            }
            CollectionAssert.AreEquivalent(new[] { "feed" }, _tree.Keys);
        }

        // ---------- cycles and keys ----------

        [Test]
        public void LinksThatMakeCyclesAreRejected()
        {
            _tree.Define("a/b/c");
            Assert.Throws<InvalidOperationException>(() => _tree.Link("a/b/c", "a"));
            Assert.Throws<InvalidOperationException>(() => _tree.Link("a/b", "a"));
            Assert.Throws<ArgumentException>(() => _tree.Link("a", "a"));

            _tree.Link("x", "a");
            Assert.Throws<InvalidOperationException>(() => _tree.Link("a/b/c", "x"), "x -> a -> a/b -> a/b/c -> x");
            _tree.Link("y", "x");
            Assert.Throws<InvalidOperationException>(() => _tree.Link("a/b", "y"));
            Assert.IsEmpty(_errors);
        }

        [Test]
        public void InvalidKeysAreRejected()
        {
            foreach (string bad in new[] { null, "", "/", "a/", "/a", "a//b", " a", "a /b" })
                Assert.IsFalse(BadgeKey.IsValid(bad), bad ?? "null");
            Assert.Throws<ArgumentException>(() => _tree.Set("a//b", BadgeValue.Dot));
            Assert.Throws<ArgumentException>(() => BadgeKey.Child("a", "x/y"));
            Assert.AreEqual("a/b/7", BadgeKey.Child(BadgeKey.Join("a", "b"), 7));
            Assert.AreEqual("a/b", BadgeKey.ParentOf("a/b/7"));
            Assert.IsNull(BadgeKey.ParentOf("a"));
            Assert.IsTrue(BadgeKey.IsUnder("a/b", "a"));
            Assert.IsFalse(BadgeKey.IsUnder("ab", "a"));
        }
    }
}
