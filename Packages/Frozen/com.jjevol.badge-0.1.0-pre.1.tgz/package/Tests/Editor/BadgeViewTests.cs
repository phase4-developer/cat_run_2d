using NUnit.Framework;
using UnityEngine;

namespace jjevol.Badge.Tests
{
    public sealed class BadgeViewTests
    {
        private GameObject _root;

        [TearDown]
        public void TearDown()
        {
            if (_root != null) Object.DestroyImmediate(_root);
            BadgeHub.Use(null);
        }

        private BadgeView MakeView(out GameObject dot, out GameObject count)
        {
            _root = new GameObject("badge");
            dot = new GameObject("dot");
            dot.transform.SetParent(_root.transform);
            count = new GameObject("count");
            count.transform.SetParent(_root.transform);
            var view = _root.AddComponent<BadgeView>();
            var serialized = new UnityEditor.SerializedObject(view);
            serialized.FindProperty("dot").objectReferenceValue = dot;
            serialized.FindProperty("countRoot").objectReferenceValue = count;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            return view;
        }

        [Test]
        public void ViewShowsDotOrNumberForItsKey()
        {
            var scheduler = new ManualBadgeScheduler();
            var tree = new BadgeTree(scheduler);
            BadgeView view = MakeView(out GameObject dot, out GameObject count);
            view.Bind("lobby/quest", tree);
            Assert.IsFalse(dot.activeSelf);
            Assert.IsFalse(count.activeSelf);

            tree.Set("lobby/quest/daily", BadgeValue.Of(3));
            scheduler.Run();
            Assert.IsTrue(dot.activeSelf, "dot mode ignores the number");
            Assert.IsFalse(count.activeSelf);
            Assert.AreEqual(BadgeValue.Of(3), view.Value);

            view.Mode = BadgeViewMode.Count;
            Assert.IsFalse(dot.activeSelf);
            Assert.IsTrue(count.activeSelf);

            tree.Set("lobby/quest/daily", BadgeValue.None);
            tree.Set("lobby/quest/new", BadgeValue.Dot);
            scheduler.Run();
            Assert.IsTrue(dot.activeSelf, "count mode falls back to the dot");
            Assert.IsFalse(count.activeSelf);

            view.Unbind();
            Assert.IsFalse(dot.activeSelf);
            tree.Set("lobby/quest/daily", BadgeValue.Of(1));
            scheduler.Run();
            Assert.IsFalse(dot.activeSelf, "no longer watching");
        }

        [Test]
        public void ViewBindsToTheHubTree()
        {
            var tree = new BadgeTree(new ImmediateBadgeScheduler());
            tree.Set("menu", BadgeValue.Dot);
            BadgeView view = MakeView(out GameObject dot, out _);
            view.Bind("menu");
            Assert.IsFalse(dot.activeSelf, "no hub tree yet");
            BadgeHub.Use(tree);
            view.Bind("menu");
            Assert.IsTrue(dot.activeSelf);
        }

        [Test]
        public void NumberTextCapsAtTheLimit()
        {
            Assert.AreEqual("7", BadgeView.Format(7, 99));
            Assert.AreEqual("99", BadgeView.Format(99, 99));
            Assert.AreEqual("99+", BadgeView.Format(100, 99));
        }
    }
}
