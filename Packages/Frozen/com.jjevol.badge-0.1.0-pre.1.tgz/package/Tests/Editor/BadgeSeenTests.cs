using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace jjevol.Badge.Tests
{
    public sealed class BadgeSeenTests
    {
        // ---------- container storage ----------

        [Test]
        public void SeenContainerRoundTripsThroughJson()
        {
            var first = new BadgeSeenContainer();
            Assert.IsTrue(first.MarkSeen("costume", new[] { "12", "3@2" }));
            Assert.IsTrue(first.MarkSeen("mail", new string[0]));
            JObject saved = first.ExportJson();

            Assert.AreEqual(
                JObject.Parse("{\"badgeSeen\":{\"version\":1,\"scopes\":{\"costume\":[\"12\",\"3@2\"],\"mail\":[]}}}").ToString(),
                saved.ToString(), "stored shape, scopes and tokens sorted");

            var second = new BadgeSeenContainer();
            Assert.IsTrue(second.ImportJson(saved));
            Assert.IsTrue(second.IsSeen("costume", "3@2"));
            Assert.IsFalse(second.IsSeen("costume", "3"));
            Assert.IsTrue(second.IsKnown("mail"));
            Assert.IsFalse(second.IsKnown("shop"));
            Assert.AreEqual(saved.ToString(), second.ExportJson().ToString());
        }

        [Test]
        public void SeenContainerSavesAndLoadsThroughARepository()
        {
            var repository = new DataRepository("badge-test-profile");
            var seen = new BadgeSeenContainer();
            repository.Register(seen);
            var changes = new List<string>();
            repository.Changed += change => { foreach (ContainerChange c in change.Containers) changes.AddRange(c.ChangedKeys); };

            Assert.IsTrue(seen.MarkSeen("costume", new[] { "1" }));
            CollectionAssert.AreEqual(new[] { "costume" }, changes, "goes through the repository");
            JObject export = repository.ExportJson();
            repository.Dispose();

            var reloaded = new DataRepository("badge-test-profile-2");
            var again = new BadgeSeenContainer();
            reloaded.Register(again);
            Assert.IsTrue(reloaded.ImportJson(export, BadgeSeenContainer.DefaultKey));
            Assert.IsTrue(again.IsSeen("costume", "1"));
            reloaded.Dispose();
        }

        [Test]
        public void UpdateMergesPerScope()
        {
            var seen = new BadgeSeenContainer();
            seen.MarkSeen("a", new[] { "1", "2" });
            seen.MarkSeen("b", new[] { "9" });
            Assert.IsTrue(seen.UpdateJson(seen.Patch("a", new[] { "2", "3" })));
            CollectionAssert.AreEquivalent(new[] { "2", "3" }, seen.Seen("a"));
            CollectionAssert.AreEquivalent(new[] { "9" }, seen.Seen("b"), "scopes not in the update stay");
            Assert.IsFalse(seen.UpdateJson(new JObject { ["other"] = 1 }), "an update without the key changes nothing");
        }

        [Test]
        public void StrictReadingRejectsTheWholeChange()
        {
            var seen = new BadgeSeenContainer();
            seen.MarkSeen("a", new[] { "1" });
            string before = seen.ExportJson().ToString();
            foreach (string bad in new[]
            {
                "{\"badgeSeen\":{\"version\":2,\"scopes\":{}}}",
                "{\"badgeSeen\":{\"version\":1}}",
                "{\"badgeSeen\":{\"version\":1,\"scopes\":{\"a\":[1]}}}",
                "{\"badgeSeen\":{\"version\":1,\"scopes\":{\"a\":[\"\"]}}}",
                "{\"badgeSeen\":{\"version\":1,\"scopes\":{\"a\":[\"x\",\"x\"]}}}",
                "{\"badgeSeen\":{\"version\":1,\"scopes\":{\"b\":[\"ok\"],\"a\":\"x\"}}}",
                "{\"badgeSeen\":[]}",
                "{\"badgeSeen\":{\"version\":\"1\",\"scopes\":{}}}",
                "{\"badgeSeen\":{\"version\":1.0,\"scopes\":{}}}",
                "{\"badgeSeen\":{\"version\":{},\"scopes\":{}}}",
                "{\"badgeSeen\":{\"version\":1,\"scopes\":{},\"extra\":true}}",
            })
            {
                Assert.Throws<FormatException>(() => seen.UpdateJson(JObject.Parse(bad)), bad);
                Assert.AreEqual(before, seen.ExportJson().ToString(), bad);
            }
            Assert.Throws<FormatException>(() => new BadgeSeenContainer().ImportJson(new JObject()), "replace needs the key");
        }

        [Test]
        public void RetainDropsTokensNotKept()
        {
            foreach (IBadgeSeenStore store in new IBadgeSeenStore[] { new MemoryBadgeSeenStore(), new BadgeSeenContainer() })
            {
                var heard = new List<string>();
                store.Changed += scopes => heard.AddRange(scopes);
                store.MarkSeen("a", new[] { "1", "2", "3" });
                Assert.IsFalse(store.MarkSeen("a", new[] { "1" }), "nothing new");
                Assert.IsTrue(store.Retain("a", new[] { "2", "99" }));
                CollectionAssert.AreEquivalent(new[] { "2" }, store.Seen("a"));
                Assert.IsFalse(store.Retain("a", new[] { "2" }));
                Assert.IsFalse(store.Retain("never", new[] { "2" }));
                CollectionAssert.AreEqual(new[] { "a", "a" }, heard, store.GetType().Name);
                Assert.Throws<ArgumentException>(() => store.MarkSeen(" a", new[] { "1" }));
                Assert.Throws<ArgumentException>(() => store.MarkSeen("a", new[] { "" }));
            }
        }

        // ---------- new-item tracker ----------

        [Test]
        public void FirstListIsSeenAndLaterItemsAreNew()
        {
            foreach (IBadgeSeenStore store in new IBadgeSeenStore[] { new MemoryBadgeSeenStore(), new BadgeSeenContainer() })
            {
                var scheduler = new ManualBadgeScheduler();
                var tree = new BadgeTree(scheduler);
                var tracker = new BadgeNewTracker(tree, store, "costume", "lobby/costume", counted: true);

                tracker.SetItems(new[] { "1", "2" });
                scheduler.Run();
                Assert.AreEqual(BadgeValue.None, tree.Get("lobby"), "starter items are not new");

                tracker.SetItems(new[] { "1", "2", "3", "4" });
                scheduler.Run();
                Assert.AreEqual(2, tree.Get("lobby").Count);
                Assert.IsTrue(tracker.IsNew("3"));
                Assert.AreEqual(BadgeValue.Of(1), tree.Get(tracker.KeyOf("4")));

                tracker.MarkSeen("3");
                scheduler.Run();
                Assert.AreEqual(1, tree.Get("lobby").Count, "store change invalidates the tracker keys");

                tracker.MarkAllSeen();
                scheduler.Run();
                Assert.AreEqual(BadgeValue.None, tree.Get("lobby"));

                tracker.SetItems(new[] { "1" });
                scheduler.Run();
                Assert.IsFalse(tree.Contains(tracker.KeyOf("2")), "items that left the list leave the tree");
                Assert.IsTrue(tracker.PruneSeen());
                CollectionAssert.AreEquivalent(new[] { "1" }, store.Seen("costume"));

                tracker.Dispose();
                Assert.IsFalse(tree.Contains(tracker.KeyOf("1")));
                Assert.IsTrue(tree.Contains("lobby/costume"), "the root key may be shared and stays");
            }
        }

        [Test]
        public void VersionedTokenShowsAgainAfterAChange()
        {
            var store = new MemoryBadgeSeenStore();
            var tree = new BadgeTree(new ImmediateBadgeScheduler());
            var tracker = new BadgeNewTracker(tree, store, "notice", "lobby/notice", firstListIsSeen: false);

            tracker.SetItems(new[] { BadgeSeenRules.Versioned("n1", 1) });
            Assert.IsTrue(tree.Get("lobby").On, "without the first-list rule everything starts new");
            tracker.MarkAllSeen();
            Assert.IsFalse(tree.Get("lobby").On);

            tracker.SetItems(new[] { BadgeSeenRules.Versioned("n1", 2) });
            Assert.IsTrue(tree.Get("lobby").On);
            Assert.AreEqual(0, tree.Get("lobby").Count, "dot by default");
        }

        [Test]
        public void TrackerOnAnEmptyFirstListStillMarksTheScopeKnown()
        {
            var store = new MemoryBadgeSeenStore();
            var tree = new BadgeTree(new ImmediateBadgeScheduler());
            var tracker = new BadgeNewTracker(tree, store, "mail", "lobby/mail");
            tracker.SetItems(new string[0]);
            Assert.IsTrue(store.IsKnown("mail"));
            tracker.SetItems(new[] { "m1" });
            Assert.IsTrue(tracker.IsNew("m1"), "first mail after an empty start is new");
        }

        [Test]
        public void SetItemsInsideARepositoryNotificationStillRegistersAndRecordsLater()
        {
            var repository = new DataRepository("badge-test-profile-notify");
            var seen = new BadgeSeenContainer();
            repository.Register(seen);
            var scheduler = new ManualBadgeScheduler();
            var tree = new BadgeTree(scheduler);
            var errors = new List<string>();
            tree.Error += (key, exception) => errors.Add(exception.Message);
            var tracker = new BadgeNewTracker(tree, seen, "costume", "lobby/costume", counted: true);

            // A game reacts to its own data arriving (for example a save load) inside the repository notification.
            var items = new SeenProbeContainer();
            repository.Register(items, saveLocal: false);
            items.Changed += _ => tracker.SetItems(new[] { "1", "2" });
            Assert.IsTrue(repository.UpdateJson(new JObject { [SeenProbeContainer.Key] = 1 }, SeenProbeContainer.Key));

            Assert.AreEqual(2, tracker.Items.Count, "items registered although the store was busy");
            Assert.IsTrue(tracker.IsFirstListPending);
            Assert.IsFalse(seen.IsKnown("costume"));
            scheduler.Run();
            Assert.AreEqual(BadgeValue.None, tree.Get("lobby"), "the first list counts as seen while it waits");
            Assert.IsFalse(tracker.IsFirstListPending, "recorded after the recompute");
            CollectionAssert.AreEquivalent(new[] { "1", "2" }, seen.Seen("costume"));
            Assert.IsEmpty(errors);

            tracker.SetItems(new[] { "1", "2", "3" });
            scheduler.Run();
            Assert.AreEqual(1, tree.Get("lobby").Count);
            repository.Dispose();
        }

        [Test]
        public void BadTokensAreRejectedBeforeAnythingChanges()
        {
            var store = new MemoryBadgeSeenStore();
            var tree = new BadgeTree(new ManualBadgeScheduler());
            var tracker = new BadgeNewTracker(tree, store, "s", "root");
            Assert.Throws<ArgumentException>(() => tracker.SetItems(new[] { "ok", "a/b" }));
            Assert.IsFalse(store.IsKnown("s"));
            Assert.AreEqual(0, tracker.Items.Count);
            Assert.Throws<ArgumentException>(() => tracker.MarkSeen("x/y"));
        }

        private sealed class SeenProbeContainer : DataContainer
        {
            public const string Key = "badgeProbe";
            public SeenProbeContainer() : base(Key, 0L) { }
            protected override StateChange ParseState(JObject data, bool replace)
            {
                long value = data.Value<long>(Key);
                return new StateChange(value, (long)State == value ? new string[0] : new[] { "value" });
            }
            protected override JObject WriteState(object state) => new JObject { [Key] = (long)state };
        }
    }
}
