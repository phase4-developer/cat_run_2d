# Provenance and distribution boundary

New code written in this Framework on 2026-11-10 at the user's request. The requirements (key hierarchy with parent totals, provider updates, seen state for new items, list item badges, a view component) were generalized from the behavior of two existing games the user works on. No code, key names, values or game names from those games were copied; keys in tests and documents are synthetic.

No paid Vendor source is used. Unity Newtonsoft JSON, uGUI, JJEvol Data and Save are declared dependencies.

This is an unfrozen local validation candidate. Publishing and installing into existing games remain separate steps.
