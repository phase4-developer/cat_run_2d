using System;

namespace jjevol.Badge
{
    /// <summary>
    /// One badge value. <see cref="Count"/> is the number a count badge shows; <see cref="On"/> is whether a dot shows.
    /// A dot-only source (<see cref="Dot"/>) turns the dot on without adding to any count.
    /// </summary>
    public readonly struct BadgeValue : IEquatable<BadgeValue>
    {
        public static readonly BadgeValue None = default;
        public static readonly BadgeValue Dot = new BadgeValue(0, true);

        public int Count { get; }
        public bool On { get; }

        private BadgeValue(int count, bool on) { Count = count; On = on; }

        /// <summary>A counted source. Zero is off; a negative count is rejected.</summary>
        public static BadgeValue Of(int count)
        {
            if (count < 0) throw new ArgumentOutOfRangeException(nameof(count), "A badge count cannot be negative.");
            return new BadgeValue(count, count > 0);
        }

        /// <summary>A dot-only source.</summary>
        public static BadgeValue Flag(bool on) => on ? Dot : None;

        internal static BadgeValue Combine(int count, bool on) => new BadgeValue(count, on || count > 0);

        public bool Equals(BadgeValue other) => Count == other.Count && On == other.On;
        public override bool Equals(object obj) => obj is BadgeValue other && Equals(other);
        public override int GetHashCode() => (Count * 397) ^ (On ? 1 : 0);
        public static bool operator ==(BadgeValue a, BadgeValue b) => a.Equals(b);
        public static bool operator !=(BadgeValue a, BadgeValue b) => !a.Equals(b);
        public override string ToString() => Count > 0 ? Count.ToString() : On ? "dot" : "none";
    }
}
