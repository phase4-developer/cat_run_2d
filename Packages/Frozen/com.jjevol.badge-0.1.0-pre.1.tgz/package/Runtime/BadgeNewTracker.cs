using System;
using System.Collections.Generic;

namespace jjevol.Badge
{
    /// <summary>
    /// "New" badges for one list: each current token that is not in the seen store gets a badge at
    /// <c>rootKey/token</c>. Tokens are path segments, so they cannot contain <c>/</c>.
    /// </summary>
    public sealed class BadgeNewTracker : IDisposable
    {
        private readonly BadgeTree _tree;
        private readonly IBadgeSeenStore _store;
        private readonly bool _counted;
        private readonly bool _firstListIsSeen;
        private readonly Dictionary<string, IDisposable> _items = new Dictionary<string, IDisposable>(StringComparer.Ordinal);
        private bool _disposed;
        private HashSet<string> _pendingFirstList;

        /// <param name="scope">Seen store scope for this list.</param>
        /// <param name="rootKey">Badge key the items sit under.</param>
        /// <param name="counted">True: each new item adds 1 to parent counts. False: dot only.</param>
        /// <param name="firstListIsSeen">True: the first list given for a scope that was never recorded counts as already
        /// seen, so a fresh install or an update that adds this tracker does not mark everything new.</param>
        public BadgeNewTracker(BadgeTree tree, IBadgeSeenStore store, string scope, string rootKey, bool counted = false, bool firstListIsSeen = true)
        {
            _tree = tree ?? throw new ArgumentNullException(nameof(tree));
            _store = store ?? throw new ArgumentNullException(nameof(store));
            BadgeSeenRules.ValidateScope(scope);
            BadgeKey.Validate(rootKey);
            Scope = scope;
            RootKey = rootKey;
            _counted = counted;
            _firstListIsSeen = firstListIsSeen;
            _tree.Define(rootKey);
            _store.Changed += OnStoreChanged;
        }

        public string Scope { get; }
        public string RootKey { get; }
        public IReadOnlyCollection<string> Items => _items.Keys;

        public string KeyOf(string token) => BadgeKey.Child(RootKey, token);

        public bool IsNew(string token)
            => _items.ContainsKey(token) && !_store.IsSeen(Scope, token) && (_pendingFirstList == null || !_pendingFirstList.Contains(token));

        /// <summary>True while the first list waits to be recorded in the store.</summary>
        public bool IsFirstListPending => _pendingFirstList != null;

        /// <summary>
        /// Replaces the current list. Keys of tokens no longer listed are removed from the tree.
        /// Call it with the complete list: an empty first list (data not loaded yet) records the scope as known,
        /// and every later item becomes new.
        /// Safe inside a data repository notification: if the store cannot record the first list now, the tracker treats
        /// those items as seen and records them after the next badge recompute (or on the next call).
        /// </summary>
        public void SetItems(IEnumerable<string> tokens)
        {
            EnsureAlive();
            List<string> list = ValidTokens(tokens);
            var next = new HashSet<string>(list, StringComparer.Ordinal);
            if (_pendingFirstList != null) TryRecordFirstList();   // an earlier record failed; try again
            else if (_firstListIsSeen && !_store.IsKnown(Scope))
            {
                _pendingFirstList = new HashSet<string>(next, StringComparer.Ordinal);
                if (!TryRecordFirstList()) _tree.Post(RecordFirstListLater);
            }

            var gone = new List<string>();
            foreach (string token in _items.Keys) if (!next.Contains(token)) gone.Add(token);
            foreach (string token in gone)
            {
                _items[token].Dispose();
                _items.Remove(token);
                _tree.Remove(KeyOf(token));
            }
            foreach (string token in next)
            {
                if (_items.ContainsKey(token)) continue;
                string captured = token;
                _items[token] = _tree.Register(KeyOf(token), () => Value(captured));
            }
        }

        public bool MarkSeen(string token) => MarkSeen(new[] { token });

        public bool MarkSeen(IEnumerable<string> tokens)
        {
            EnsureAlive();
            List<string> list = ValidTokens(tokens);
            HashSet<string> pending = _pendingFirstList;
            if (pending != null) list.AddRange(pending);
            bool changed = _store.MarkSeen(Scope, list);
            if (pending != null && ReferenceEquals(_pendingFirstList, pending)) _pendingFirstList = null;
            return changed;
        }

        /// <summary>Marks every current item seen, for example when the list screen opens.</summary>
        public bool MarkAllSeen() => MarkSeen(new List<string>(_items.Keys));

        /// <summary>Drops seen tokens that are not in the current list, so the store does not grow forever.
        /// Call only when the current list is complete (not while it is still loading).</summary>
        public bool PruneSeen()
        {
            EnsureAlive();
            return _store.Retain(Scope, _items.Keys);
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _store.Changed -= OnStoreChanged;
            foreach (KeyValuePair<string, IDisposable> item in _items)
            {
                item.Value.Dispose();
                _tree.Remove(KeyOf(item.Key));
            }
            _items.Clear();
        }

        private BadgeValue Value(string token)
        {
            if (_store.IsSeen(Scope, token) || (_pendingFirstList != null && _pendingFirstList.Contains(token))) return BadgeValue.None;
            return _counted ? BadgeValue.Of(1) : BadgeValue.Dot;
        }

        private bool TryRecordFirstList()
        {
            HashSet<string> pending = _pendingFirstList;
            if (pending == null) return true;
            try { _store.MarkSeen(Scope, pending); }
            catch (InvalidOperationException) { return false; }   // the store is busy (for example inside its own notification)
            if (ReferenceEquals(_pendingFirstList, pending)) _pendingFirstList = null;
            return true;
        }

        private void RecordFirstListLater()
        {
            if (!_disposed) TryRecordFirstList();   // still busy: the next SetItems or MarkSeen tries again
        }

        private List<string> ValidTokens(IEnumerable<string> tokens)
        {
            List<string> list = BadgeSeenRules.Tokens(tokens);
            foreach (string token in list)
                if (!BadgeKey.IsValid(token) || token.IndexOf(BadgeKey.Separator) >= 0)
                    throw new ArgumentException("A tracked token must be one badge key segment (no '/'): '" + token + "'.", nameof(tokens));
            return list;
        }

        private void OnStoreChanged(IReadOnlyList<string> scopes)
        {
            foreach (string scope in scopes)
                if (scope == Scope) { _tree.InvalidateUnder(RootKey); return; }
        }

        private void EnsureAlive()
        {
            if (_disposed) throw new ObjectDisposedException(nameof(BadgeNewTracker));
        }
    }
}
