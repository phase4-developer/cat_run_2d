using System;
using System.Text;

namespace jjevol.Badge
{
    /// <summary>
    /// Badge keys are paths such as <c>lobby/quest/daily/1203</c>. A key's path parent (<c>lobby/quest/daily</c>)
    /// is always its parent. Segments are nonempty and contain no <c>/</c> and no whitespace at either end.
    /// </summary>
    public static class BadgeKey
    {
        public const char Separator = '/';

        /// <summary>Joins a parent key and one child segment. The segment may be any id, such as a row id.</summary>
        public static string Child(string parent, string segment)
        {
            Validate(parent);
            ValidateSegment(segment);
            return parent + Separator + segment;
        }

        public static string Child(string parent, int id) => Child(parent, id.ToString(System.Globalization.CultureInfo.InvariantCulture));

        public static string Join(params string[] segments)
        {
            if (segments == null || segments.Length == 0) throw new ArgumentException("A badge key needs at least one segment.", nameof(segments));
            var builder = new StringBuilder();
            for (int i = 0; i < segments.Length; i++)
            {
                ValidateSegment(segments[i]);
                if (i > 0) builder.Append(Separator);
                builder.Append(segments[i]);
            }
            return builder.ToString();
        }

        /// <summary>The path parent, or null for a root key.</summary>
        public static string ParentOf(string key)
        {
            Validate(key);
            int index = key.LastIndexOf(Separator);
            return index < 0 ? null : key.Substring(0, index);
        }

        public static bool IsValid(string key)
        {
            if (string.IsNullOrEmpty(key)) return false;
            foreach (string segment in key.Split(Separator))
                if (!IsValidSegment(segment)) return false;
            return true;
        }

        /// <summary>True when <paramref name="key"/> is <paramref name="root"/> or lies under it by path.</summary>
        public static bool IsUnder(string key, string root)
            => key == root || (key.Length > root.Length && key[root.Length] == Separator && key.StartsWith(root, StringComparison.Ordinal));

        public static void Validate(string key)
        {
            if (!IsValid(key)) throw new ArgumentException("Invalid badge key: '" + key + "'. Use nonempty segments separated by '/'.", nameof(key));
        }

        private static void ValidateSegment(string segment)
        {
            if (!IsValidSegment(segment)) throw new ArgumentException("Invalid badge key segment: '" + segment + "'.", nameof(segment));
        }

        private static bool IsValidSegment(string segment)
            => !string.IsNullOrEmpty(segment) && segment.IndexOf(Separator) < 0
               && !char.IsWhiteSpace(segment[0]) && !char.IsWhiteSpace(segment[segment.Length - 1]);
    }
}
