using System;

namespace jjevol.Badge
{
    /// <summary>
    /// Decides when a dirty tree recomputes. The tree calls <see cref="Request"/> once per dirty period;
    /// the scheduler later calls the given action once.
    /// </summary>
    public interface IBadgeScheduler
    {
        void Request(Action flush);
    }

    /// <summary>Recomputes only when <see cref="Run"/> is called. For tests and for hosts with their own loop.</summary>
    public sealed class ManualBadgeScheduler : IBadgeScheduler
    {
        private Action _pending;
        public bool IsPending => _pending != null;
        public int Requests { get; private set; }

        public void Request(Action flush)
        {
            if (flush == null) throw new ArgumentNullException(nameof(flush));
            Requests++;
            _pending = flush;
        }

        /// <summary>Runs the pending recompute. Returns false when nothing was pending.</summary>
        public bool Run()
        {
            Action flush = _pending;
            _pending = null;
            if (flush == null) return false;
            flush();
            return true;
        }
    }

    /// <summary>
    /// Recomputes right after every change. For servers, tools and code without frames.
    /// A request made while recomputing runs after the current pass instead of nesting.
    /// </summary>
    public sealed class ImmediateBadgeScheduler : IBadgeScheduler
    {
        public const int MaxChainedPasses = 16;
        private bool _running;
        private Action _again;

        public void Request(Action flush)
        {
            if (flush == null) throw new ArgumentNullException(nameof(flush));
            if (_running) { _again = flush; return; }
            _running = true;
            try
            {
                flush();
                for (int pass = 0; _again != null; pass++)
                {
                    if (pass >= MaxChainedPasses)
                    {
                        _again = null;
                        throw new InvalidOperationException("Badge recompute kept requesting itself. A watcher or provider changes badges on every pass.");
                    }
                    Action next = _again;
                    _again = null;
                    next();
                }
            }
            finally { _running = false; _again = null; }
        }
    }
}
