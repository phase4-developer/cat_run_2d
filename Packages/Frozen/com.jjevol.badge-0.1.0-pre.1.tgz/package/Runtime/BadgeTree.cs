using System;
using System.Collections.Generic;
using System.Threading;

namespace jjevol.Badge
{
    /// <summary>
    /// Badge keys, their sources and their totals.
    /// <list type="bullet">
    /// <item>A key's total is the sum over its distinct descendants (itself included) that have a source.
    /// A key reached by two paths counts once.</item>
    /// <item>Sources are pull (<see cref="Register"/>, read on recompute after <see cref="Invalidate"/>) or push (<see cref="Set"/>).</item>
    /// <item>Changes only mark keys dirty. The scheduler runs one recompute later; watchers hear only keys whose total changed.</item>
    /// </list>
    /// Use the tree on its creating thread.
    /// </summary>
    public sealed class BadgeTree
    {
        /// <summary>Recompute passes in one flush when watchers keep changing badges. Further changes go to the next request.</summary>
        public const int MaxPassesPerFlush = 8;

        private sealed class Node
        {
            public readonly string Key;
            public readonly Node PathParent;
            public readonly HashSet<Node> Parents = new HashSet<Node>();
            public readonly HashSet<Node> Children = new HashSet<Node>();
            public readonly HashSet<Node> LinkedParents = new HashSet<Node>();
            public Func<BadgeValue> Provider;
            public object Registration;
            public bool Pushed;
            public BadgeValue Own;
            public BadgeValue Total;
            public bool Removed;
            public Node(string key, Node pathParent) { Key = key; PathParent = pathParent; }
            public bool HasSource => Provider != null || Pushed;
        }

        private sealed class Registration : IDisposable
        {
            private BadgeTree _tree;
            private readonly string _key;
            public Registration(BadgeTree tree, string key) { _tree = tree; _key = key; }
            public void Dispose()
            {
                if (_tree == null) return;
                _tree.Unregister(_key, this);   // throws on a wrong thread before anything changes
                _tree = null;
            }
        }

        private sealed class Watcher : IDisposable
        {
            private BadgeTree _tree;
            public readonly string Key;
            public readonly Action<BadgeValue> Callback;
            public Watcher(BadgeTree tree, string key, Action<BadgeValue> callback) { _tree = tree; Key = key; Callback = callback; }
            public bool HasLast;
            public BadgeValue Last;
            public bool Active => _tree != null;
            public void Dispose()
            {
                if (_tree == null) return;
                _tree.RemoveWatcher(this);
                _tree = null;
            }
        }

        private readonly int _threadId = Thread.CurrentThread.ManagedThreadId;
        private readonly IBadgeScheduler _scheduler;
        private readonly Dictionary<string, Node> _nodes = new Dictionary<string, Node>(StringComparer.Ordinal);
        private readonly Dictionary<string, List<Watcher>> _watchers = new Dictionary<string, List<Watcher>>(StringComparer.Ordinal);
        private readonly HashSet<Node> _stale = new HashSet<Node>();       // pull sources to read again
        private readonly HashSet<Node> _dirty = new HashSet<Node>();       // totals of these and their ancestors to recompute
        private readonly List<Action> _posted = new List<Action>();
        private readonly Dictionary<string, BadgeValue> _removed = new Dictionary<string, BadgeValue>(StringComparer.Ordinal);
        private readonly Action _scheduledFlush;
        private bool _requested;
        private bool _flushing;
        private bool _readingSources;

        public BadgeTree(IBadgeScheduler scheduler)
        {
            _scheduler = scheduler ?? throw new ArgumentNullException(nameof(scheduler));
            _scheduledFlush = () => { _requested = false; Flush(); };
        }

        /// <summary>A provider, watcher or scheduler threw. Badges keep working; the failed source counts as none.</summary>
        public event Action<string, Exception> Error;

        public bool IsDirty { get { EnsureAccess(); return _stale.Count > 0 || _dirty.Count > 0 || _removed.Count > 0 || _posted.Count > 0; } }
        public int Recomputes { get; private set; }
        public IReadOnlyCollection<string> Keys { get { EnsureAccess(); return _nodes.Keys; } }

        public bool Contains(string key) { EnsureAccess(); return key != null && _nodes.ContainsKey(key); }

        /// <summary>The total from the last recompute. Unknown keys and keys changed since then may read stale.</summary>
        public BadgeValue Get(string key)
        {
            EnsureAccess();
            BadgeKey.Validate(key);
            return _nodes.TryGetValue(key, out Node node) ? node.Total : BadgeValue.None;
        }

        // ---------- sources ----------

        /// <summary>Registers a pull source. The provider is read on the next recompute and again after each <see cref="Invalidate"/>.</summary>
        public IDisposable Register(string key, Func<BadgeValue> provider)
        {
            EnsureStructural();
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            Node node = Ensure(key);
            if (node.HasSource) throw new InvalidOperationException("Badge key already has a source: " + key);
            var registration = new Registration(this, key);
            node.Provider = provider;
            node.Registration = registration;
            _stale.Add(node);
            RequestFlush();
            return registration;
        }

        /// <summary>Sets a push source. The key must not have a registered provider.</summary>
        public void Set(string key, BadgeValue value)
        {
            EnsureStructural();
            Node node = Ensure(key);
            if (node.Provider != null) throw new InvalidOperationException("Badge key has a registered provider; invalidate it instead: " + key);
            if (node.Pushed && node.Own == value) return;
            node.Pushed = true;
            node.Own = value;
            MarkDirty(node);
        }

        /// <summary>Removes a push source set with <see cref="Set"/>. The key itself stays.</summary>
        public void Clear(string key)
        {
            EnsureStructural();
            BadgeKey.Validate(key);
            if (!_nodes.TryGetValue(key, out Node node) || !node.Pushed) return;
            node.Pushed = false;
            node.Own = BadgeValue.None;
            MarkDirty(node);
        }

        /// <summary>Marks one pull source to be read again on the next recompute. Unknown keys are ignored.</summary>
        public void Invalidate(string key)
        {
            EnsureAccess();
            BadgeKey.Validate(key);
            if (_nodes.TryGetValue(key, out Node node) && node.Provider != null) { _stale.Add(node); RequestFlush(); }
        }

        /// <summary>Marks every pull source at or under <paramref name="root"/> by path.</summary>
        public void InvalidateUnder(string root)
        {
            EnsureAccess();
            BadgeKey.Validate(root);
            bool any = false;
            foreach (Node node in _nodes.Values)
                if (node.Provider != null && BadgeKey.IsUnder(node.Key, root)) { _stale.Add(node); any = true; }
            if (any) RequestFlush();
        }

        public void InvalidateAll()
        {
            EnsureAccess();
            bool any = false;
            foreach (Node node in _nodes.Values)
                if (node.Provider != null) { _stale.Add(node); any = true; }
            if (any) RequestFlush();
        }

        private void Unregister(string key, Registration registration)
        {
            if (Thread.CurrentThread.ManagedThreadId != _threadId) throw new InvalidOperationException("Use a badge tree on its creating thread.");
            if (_readingSources) throw new InvalidOperationException("Badge keys cannot change while providers are being read.");
            if (!_nodes.TryGetValue(key, out Node node) || node.Registration != registration) return;
            node.Provider = null;
            node.Registration = null;
            node.Own = BadgeValue.None;
            _stale.Remove(node);
            MarkDirty(node);
        }

        // ---------- structure ----------

        /// <summary>Creates a key (and its path ancestors) without a source, so it can total children or be linked.</summary>
        public void Define(string key)
        {
            EnsureStructural();
            Ensure(key);
        }

        /// <summary>
        /// Adds <paramref name="child"/> under one more parent besides its path parent, for a badge that shows in two places.
        /// A link that would make a key its own ancestor is rejected.
        /// </summary>
        public void Link(string parent, string child)
        {
            EnsureStructural();
            BadgeKey.Validate(parent);
            BadgeKey.Validate(child);
            if (parent == child) throw new ArgumentException("A badge key cannot be its own parent: " + parent);
            Node c = Ensure(child);
            Node p = Ensure(parent);
            if (p.Children.Contains(c)) return;
            if (IsDescendant(p, c)) throw new InvalidOperationException("Badge link would make a cycle: " + parent + " -> " + child);
            p.Children.Add(c);
            c.Parents.Add(p);
            c.LinkedParents.Add(p);
            MarkDirty(c);
        }

        public void Unlink(string parent, string child)
        {
            EnsureStructural();
            BadgeKey.Validate(parent);
            BadgeKey.Validate(child);
            if (!_nodes.TryGetValue(parent, out Node p) || !_nodes.TryGetValue(child, out Node c) || !c.LinkedParents.Remove(p)) return;
            p.Children.Remove(c);
            c.Parents.Remove(p);
            MarkDirty(p);
        }

        /// <summary>
        /// Removes <paramref name="root"/> and every key under it by path, with their sources and links.
        /// Watchers stay and hear the removed keys as none. Returns the number of removed keys.
        /// </summary>
        public int Remove(string root)
        {
            EnsureStructural();
            BadgeKey.Validate(root);
            var doomed = new List<Node>();
            foreach (Node node in _nodes.Values)
                if (BadgeKey.IsUnder(node.Key, root)) doomed.Add(node);
            if (doomed.Count == 0) return 0;
            var set = new HashSet<Node>(doomed);
            foreach (Node node in doomed)
            {
                foreach (Node parent in node.Parents)
                    if (!set.Contains(parent)) { parent.Children.Remove(node); _dirty.Add(parent); }
                foreach (Node child in node.Children)
                    if (!set.Contains(child)) { child.Parents.Remove(node); child.LinkedParents.Remove(node); }
                node.Removed = true;
                _nodes.Remove(node.Key);
                _stale.Remove(node);
                _dirty.Remove(node);
                if (!_removed.ContainsKey(node.Key)) _removed[node.Key] = node.Total;
            }
            RequestFlush();
            return doomed.Count;
        }

        // ---------- watching ----------

        /// <summary>
        /// Calls <paramref name="onChanged"/> now with the current total and after each recompute that changes it.
        /// The key need not exist yet. Dispose to stop.
        /// </summary>
        public IDisposable Watch(string key, Action<BadgeValue> onChanged)
        {
            EnsureAccess();
            BadgeKey.Validate(key);
            if (onChanged == null) throw new ArgumentNullException(nameof(onChanged));
            var watcher = new Watcher(this, key, onChanged);
            if (!_watchers.TryGetValue(key, out List<Watcher> list)) _watchers[key] = list = new List<Watcher>();
            list.Add(watcher);
            Call(watcher, Get(key));
            return watcher;
        }

        private void RemoveWatcher(Watcher watcher)
        {
            EnsureAccess();
            if (!_watchers.TryGetValue(watcher.Key, out List<Watcher> list)) return;
            list.Remove(watcher);
            if (list.Count == 0) _watchers.Remove(watcher.Key);
        }

        /// <summary>
        /// Runs an action after the next recompute's notifications, outside providers. For work that cannot run where a
        /// change was noticed (for example a store write inside the store's own notification).
        /// </summary>
        public void Post(Action action)
        {
            EnsureAccess();
            if (action == null) throw new ArgumentNullException(nameof(action));
            _posted.Add(action);
            RequestFlush();
        }

        // ---------- recompute ----------

        /// <summary>Recomputes now. The scheduler normally calls this once per dirty period.</summary>
        public void Flush()
        {
            EnsureAccess();
            if (_flushing) return;
            _flushing = true;
            try
            {
                for (int pass = 0; IsDirty; pass++)
                {
                    if (pass >= MaxPassesPerFlush)
                    {
                        Report(null, new InvalidOperationException("Badge watchers changed badges on every pass; the rest waits for the next recompute."));
                        break;
                    }
                    Pass();
                }
            }
            finally { _flushing = false; }
            if (IsDirty) RequestFlush();
        }

        private void Pass()
        {
            Recomputes++;
            // 1. Read stale pull sources. Structure cannot change while providers run.
            Node[] stale = Drain(_stale);
            _readingSources = true;
            try
            {
                foreach (Node node in stale)
                {
                    if (node.Removed || node.Provider == null) continue;
                    BadgeValue value;
                    try { value = node.Provider(); }
                    catch (Exception exception) { Report(node.Key, exception); value = BadgeValue.None; }
                    if (value != node.Own) { node.Own = value; _dirty.Add(node); }
                }
            }
            finally { _readingSources = false; }

            // 2. Collect dirty keys and every ancestor, then recompute their totals.
            var affected = new HashSet<Node>();
            var stack = new Stack<Node>(Drain(_dirty));
            while (stack.Count > 0)
            {
                Node node = stack.Pop();
                if (node.Removed || !affected.Add(node)) continue;
                foreach (Node parent in node.Parents) stack.Push(parent);
            }
            var changed = new List<KeyValuePair<string, BadgeValue>>();
            foreach (Node node in affected)
            {
                BadgeValue total = Total(node);
                if (total == node.Total) continue;
                node.Total = total;
                changed.Add(new KeyValuePair<string, BadgeValue>(node.Key, total));
            }
            foreach (KeyValuePair<string, BadgeValue> removed in _removed)
                if (removed.Value != BadgeValue.None && !_nodes.ContainsKey(removed.Key))
                    changed.Add(new KeyValuePair<string, BadgeValue>(removed.Key, BadgeValue.None));
            _removed.Clear();
            changed.Sort((a, b) => string.CompareOrdinal(a.Key, b.Key));

            // 3. Tell watchers. They may change badges; that marks the tree dirty for the next pass.
            foreach (KeyValuePair<string, BadgeValue> change in changed)
            {
                if (!_watchers.TryGetValue(change.Key, out List<Watcher> list)) continue;
                foreach (Watcher watcher in list.ToArray())
                    if (watcher.Active) Call(watcher, change.Value);
            }

            // 4. Posted work. Anything it posts again waits for the next pass.
            if (_posted.Count == 0) return;
            Action[] posted = _posted.ToArray();
            _posted.Clear();
            foreach (Action action in posted)
                try { action(); } catch (Exception exception) { Report(null, exception); }
        }

        private static BadgeValue Total(Node root)
        {
            long count = 0;
            bool on = false;
            var seen = new HashSet<Node>();
            var stack = new Stack<Node>();
            stack.Push(root);
            while (stack.Count > 0)
            {
                Node node = stack.Pop();
                if (!seen.Add(node)) continue;
                if (node.HasSource) { count += node.Own.Count; on |= node.Own.On; }
                foreach (Node child in node.Children) stack.Push(child);
            }
            return BadgeValue.Combine(count > int.MaxValue ? int.MaxValue : (int)count, on);
        }

        // ---------- helpers ----------

        private Node Ensure(string key)
        {
            BadgeKey.Validate(key);
            if (_nodes.TryGetValue(key, out Node node)) return node;
            string parentKey = BadgeKey.ParentOf(key);
            Node parent = parentKey == null ? null : Ensure(parentKey);
            node = new Node(key, parent);
            if (parent != null) { parent.Children.Add(node); node.Parents.Add(parent); }
            _nodes.Add(key, node);
            if (_removed.TryGetValue(key, out BadgeValue last))
            {
                // Removed and added again before a recompute: compare against what watchers last heard.
                _removed.Remove(key);
                node.Total = last;
                _dirty.Add(node);
                RequestFlush();
            }
            return node;
        }

        private static bool IsDescendant(Node candidate, Node root)
        {
            var seen = new HashSet<Node>();
            var stack = new Stack<Node>();
            stack.Push(root);
            while (stack.Count > 0)
            {
                Node node = stack.Pop();
                if (node == candidate) return true;
                if (!seen.Add(node)) continue;
                foreach (Node child in node.Children) stack.Push(child);
            }
            return false;
        }

        private void MarkDirty(Node node)
        {
            _dirty.Add(node);
            RequestFlush();
        }

        private void RequestFlush()
        {
            if (_requested || _flushing) return;
            _requested = true;
            try { _scheduler.Request(_scheduledFlush); }
            catch (Exception exception) { _requested = false; Report(null, exception); }
        }

        private void Call(Watcher watcher, BadgeValue value)
        {
            if (watcher.HasLast && watcher.Last == value) return;   // a watcher added during this recompute already has it
            watcher.HasLast = true;
            watcher.Last = value;
            try { watcher.Callback(value); }
            catch (Exception exception) { Report(watcher.Key, exception); }
        }

        private void Report(string key, Exception exception)
        {
            Action<string, Exception> handler = Error;
            if (handler == null) return;
            foreach (Action<string, Exception> subscriber in handler.GetInvocationList())
                try { ((Action<string, Exception>)subscriber)(key, exception); } catch { /* an error handler cannot fail the tree */ }
        }

        private static Node[] Drain(HashSet<Node> set)
        {
            var items = new Node[set.Count];
            set.CopyTo(items);
            set.Clear();
            return items;
        }

        private void EnsureStructural()
        {
            EnsureAccess();
            if (_readingSources) throw new InvalidOperationException("Badge keys cannot change while providers are being read.");
        }

        private void EnsureAccess()
        {
            if (Thread.CurrentThread.ManagedThreadId != _threadId) throw new InvalidOperationException("Use a badge tree on its creating thread.");
        }
    }
}
