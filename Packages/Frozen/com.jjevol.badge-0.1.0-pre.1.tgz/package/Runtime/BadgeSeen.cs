using System;
using System.Collections.Generic;

namespace jjevol.Badge
{
    /// <summary>
    /// What the player has already seen, per scope. A scope is one list of "new" things (for example costumes);
    /// a token is one item in it, optionally with a version (<c>1203</c>, <c>1203@2</c>) so a changed item shows again.
    /// A scope is "known" once anything was recorded for it, even an empty list.
    /// </summary>
    public interface IBadgeSeenStore
    {
        bool IsKnown(string scope);
        bool IsSeen(string scope, string token);
        IReadOnlyCollection<string> Seen(string scope);

        /// <summary>Adds tokens to a scope and makes the scope known. Returns true when anything changed.</summary>
        bool MarkSeen(string scope, IEnumerable<string> tokens);

        /// <summary>Keeps only the given tokens in a scope. Returns true when anything was dropped.</summary>
        bool Retain(string scope, IEnumerable<string> keep);

        /// <summary>Scopes whose seen set changed, after the change is in place.</summary>
        event Action<IReadOnlyList<string>> Changed;
    }

    /// <summary>Validation and plain set logic shared by store implementations.</summary>
    public static class BadgeSeenRules
    {
        public static void ValidateScope(string scope)
        {
            if (string.IsNullOrWhiteSpace(scope) || scope.Trim() != scope)
                throw new ArgumentException("A seen scope must be nonempty without surrounding spaces: '" + scope + "'.", nameof(scope));
        }

        public static void ValidateToken(string token)
        {
            if (string.IsNullOrWhiteSpace(token) || token.Trim() != token)
                throw new ArgumentException("A seen token must be nonempty without surrounding spaces: '" + token + "'.", nameof(token));
        }

        /// <summary>A token for an item whose content can change: <c>id@version</c>.</summary>
        public static string Versioned(string id, long version)
        {
            ValidateToken(id);
            return id + "@" + version.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        public static List<string> Tokens(IEnumerable<string> tokens)
        {
            if (tokens == null) throw new ArgumentNullException(nameof(tokens));
            var list = new List<string>();
            foreach (string token in tokens) { ValidateToken(token); list.Add(token); }
            return list;
        }
    }

    /// <summary>A seen store kept in memory. For tests, servers and games that persist seen state elsewhere.</summary>
    public sealed class MemoryBadgeSeenStore : IBadgeSeenStore
    {
        private static readonly string[] NoTokens = new string[0];
        private readonly Dictionary<string, HashSet<string>> _scopes = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);

        public event Action<IReadOnlyList<string>> Changed;

        public bool IsKnown(string scope) { BadgeSeenRules.ValidateScope(scope); return _scopes.ContainsKey(scope); }

        public bool IsSeen(string scope, string token)
        {
            BadgeSeenRules.ValidateScope(scope);
            return token != null && _scopes.TryGetValue(scope, out HashSet<string> set) && set.Contains(token);
        }

        public IReadOnlyCollection<string> Seen(string scope)
        {
            BadgeSeenRules.ValidateScope(scope);
            return _scopes.TryGetValue(scope, out HashSet<string> set) ? (IReadOnlyCollection<string>)new List<string>(set) : NoTokens;
        }

        public bool MarkSeen(string scope, IEnumerable<string> tokens)
        {
            BadgeSeenRules.ValidateScope(scope);
            List<string> list = BadgeSeenRules.Tokens(tokens);
            bool changed = false;
            if (!_scopes.TryGetValue(scope, out HashSet<string> set)) { _scopes[scope] = set = new HashSet<string>(StringComparer.Ordinal); changed = true; }
            foreach (string token in list) changed |= set.Add(token);
            if (changed) Changed?.Invoke(new[] { scope });
            return changed;
        }

        public bool Retain(string scope, IEnumerable<string> keep)
        {
            BadgeSeenRules.ValidateScope(scope);
            var kept = new HashSet<string>(BadgeSeenRules.Tokens(keep), StringComparer.Ordinal);
            if (!_scopes.TryGetValue(scope, out HashSet<string> set)) return false;
            if (set.RemoveWhere(token => !kept.Contains(token)) == 0) return false;
            Changed?.Invoke(new[] { scope });
            return true;
        }
    }
}
