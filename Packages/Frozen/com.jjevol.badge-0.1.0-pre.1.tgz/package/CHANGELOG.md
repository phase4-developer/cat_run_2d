# Changelog

## 0.1.0-pre.1 — 2026-11-10

- 첫 후보. 키 트리(경로 부모 + 추가 부모 링크, 순환 거절), 자식 합산(같은 자손은 한 번), 개수형·점형 값.
- 제공자 등록(pull)과 값 넣기(push). 무효화는 표시만 하고 스케줄러가 한 번 다시 계산한다. 값이 바뀐 키만 알린다.
- 동적 키 추가·삭제(`Remove`는 경로 아래 전체와 링크를 지운다).
- 「새로 생김」 본 적 저장: `IBadgeSeenStore`, 메모리 구현, `BadgeSeenContainer`(`com.jjevol.data`), 목록용 `BadgeNewTracker`.
- Unity: `BadgeFrameScheduler`(다시 계산할 때만 켜지는 LateUpdate), `BadgeHub`. uGUI: `BadgeView`.
