# JJEvol Badge

`com.jjevol.badge@0.1.0-pre.1`은 알림 빨간 점(뱃지) 코어다. 로비 → 메뉴 → 탭 → 항목처럼 키를 경로로 쌓고, 부모는 자식을 합산한다. 기능은 제공자로 「켜짐·개수」를 알리고, 바뀌면 무효화만 한다. 다시 계산은 프레임 끝에 한 번이다. Unity 6000.3.9f1 기준이다.

설계와 두 사례 비교는 [Docs/FrameworkImprovement/Badge](../../Docs/FrameworkImprovement/Badge/README.md)에 있다.

## 어셈블리

| 어셈블리 | 참조 | 내용 |
|---|---|---|
| `JJEvol.Badge.Runtime` | 없음(`noEngineReferences`) | `BadgeTree`, `BadgeKey`, `BadgeValue`, 스케줄러(`Manual`·`Immediate`), `IBadgeSeenStore`, `MemoryBadgeSeenStore`, `BadgeNewTracker` |
| `JJEvol.Badge.Data` | Runtime, `JJEvol.Data.Runtime` | `BadgeSeenContainer`(본 적 저장) |
| `JJEvol.Badge.Unity` | Runtime | `BadgeFrameScheduler`, `BadgeHub` |
| `JJEvol.Badge.UGUI` | Runtime, Unity, uGUI, TextMeshPro | `BadgeView` |

## 시작

```csharp
// 부팅 때 한 번
BadgeTree badges = BadgeHub.CreateForPlayMode();          // LateUpdate에서 한 번 다시 계산
var seen = new BadgeSeenContainer();                      // 키 "badgeSeen"
repository.Register(seen);                                // saveLocal: true(기본)

// 기능: 값을 계산하는 함수를 등록하고, 상태가 바뀌면 무효화만 한다
IDisposable mailBadge = badges.Register("lobby/mail", () => BadgeValue.Of(mail.UnreadCount));
mail.Changed += () => badges.Invalidate("lobby/mail");

// 이미 값을 가진 쪽은 넣는다
badges.Set("lobby/event/attendance", BadgeValue.Flag(attendance.CanClaim));
```

화면에서는 버튼에 `BadgeView`를 붙이고 Inspector에 키(`lobby/mail`)와 점·숫자 오브젝트를 넣는다. 목록 항목은 `view.Bind(BadgeKey.Child("lobby/quest/daily", row.Id))`로 바꾼다.

## 규칙

- 키는 `/`로 나눈 경로다. 경로 부모가 곧 부모다. 다른 곳에도 보여야 하면 `Link(parent, child)`로 부모를 더한다. 자기 자신을 조상으로 만드는 링크는 거절한다.
- 합산은 자손을 한 번씩만 센다(두 길로 닿아도 한 번). `BadgeValue.Of(n)`은 개수에 더하고, `BadgeValue.Dot`은 점만 켠다.
- 한 키의 값 출처는 하나다(`Register` 또는 `Set`). 부모 키도 출처를 가질 수 있지만 보통은 자식 합산만 쓴다.
- `Invalidate`·`Set`·`Remove`는 표시만 한다. 스케줄러가 한 번 다시 계산하고, 합계가 바뀐 키의 감시자만 부른다. 다시 계산 전 `Get`은 지난 값이다.
- 제공자 안에서 할 수 없는 일(저장소 쓰기 등)은 `Post(action)`으로 다음 다시 계산의 알림 뒤에 실행한다.
- 제공자 안에서는 키 구조를 바꿀 수 없다(오류로 보고하고 그 값은 없음). 감시자 안의 변경은 같은 다시 계산의 다음 회차에 반영된다(최대 8회).
- 제공자·감시자 예외는 `BadgeTree.Error`로 보고하고 다른 키는 계속 동작한다.
- 만든 스레드에서만 쓴다.

## 동적 키

```csharp
foreach (QuestRow row in rows) badges.Set(BadgeKey.Child("lobby/quest/daily", row.Id), BadgeValue.Flag(row.Claimable));
badges.Remove("lobby/quest/daily/1203");   // 목록에서 빠진 항목. 그 아래 키와 링크도 지운다
```

`Remove`는 경로 아래 전체를 지운다. 감시자는 남고 「없음」을 받는다. 같은 키를 다시 만들면 그대로 이어서 받는다.

## 새로 생김(본 적 저장)

```csharp
var costumes = new BadgeNewTracker(badges, seen, scope: "costume", rootKey: "lobby/costume");
costumes.SetItems(owned.Select(c => c.Id.ToString()));    // 목록이 바뀔 때마다. 완전한 목록으로
costumes.MarkSeen(id);                                     // 항목을 봤을 때. 저장소를 거쳐 저장된다
costumes.PruneSeen();                                      // 목록이 완전할 때만, 사라진 항목 기록 정리
```

- 저장 형태: `{ "badgeSeen": { "version": 1, "scopes": { "costume": ["12", "3@2"] } } }`. 토큰은 정렬해 쓴다. 병합은 범위(scope) 단위로 바꾼다. 읽기는 엄격하다(정수 버전 1, 모르는 필드, 문자열·빈 값·중복).
- 내용이 바뀌면 다시 보여야 하는 항목은 `BadgeSeenRules.Versioned(id, version)`(`id@version`)을 토큰으로 쓴다.
- 처음 보는 범위의 첫 목록은 본 것으로 기록한다(`firstListIsSeen`, 기본 켬). 새로 설치했거나 이 기능이 나중에 들어와도 전부 「새로」가 되지 않는다. 그래서 데이터를 불러오기 전 빈 목록으로 `SetItems`를 부르지 않는다(그 뒤 항목이 모두 「새로」가 된다).
- `SetItems`는 저장소 알림 안에서 불러도 된다. 저장소가 바빠 첫 목록을 지금 기록하지 못하면 그 항목을 본 것으로 다루고, 다음 다시 계산 뒤(또는 다음 호출 때) 기록한다(`IsFirstListPending`).
- 토큰은 키 경로 한 조각이라 `/`를 넣을 수 없다. 잘못된 토큰이 하나라도 있으면 아무것도 바꾸지 않고 거절한다.
- 저장은 게임 저장소(`RepositoryStorageAdapter.Save`)가 한다. `MarkSeen`은 Container를 바꿀 뿐이다.

## 주의

- 폴링하지 않는다. `Update`에서 `Invalidate`를 부르면 매 프레임 다시 계산한다. 상태가 바뀌는 곳(Container `Changed`, 요청 성공)에서 부른다.
- `BadgeFrameScheduler`는 Play 모드에서만 만들 수 있다(Edit 모드면 예외). `BadgeHub.CreateForPlayMode`를 다시 부르면 앞의 스케줄러를 정리한다. Edit 모드 시험은 `ManualBadgeScheduler`, 서버·도구는 `ImmediateBadgeScheduler`를 쓴다.
- `DataRepository` 알림 안에서 `MarkSeen`을 직접 부르면 저장소가 같은 저장소 변경을 거부한다. `badges.Post(() => tracker.MarkSeen(id))`로 미룬다.
- UI Toolkit 표시 요소는 아직 없다. `BadgeTree.Watch`로 직접 연결한다.

## 시험

`Tests/Editor`(`JJEvol.Badge.Tests.Editor`): 트리 합산·링크, 무효화 묶음, 감시자 알림, 오류 격리, 동적 키 추가·삭제, 순환 거절, 본 적 저장 왕복·엄격 읽기·저장소 경유, 새로 생김 추적, `BadgeView`. 검증 결과는 [검증 상태](../../Docs/Guide/Verification.md)를 본다.
