using System;
using System.Globalization;
using TMPro;
using UnityEngine;

namespace jjevol.Badge
{
    public enum BadgeViewMode
    {
        /// <summary>Shows the dot when the key is on. Counts are ignored.</summary>
        Dot = 0,
        /// <summary>Shows the number when the count is above zero, otherwise the dot when the key is on.</summary>
        Count = 1,
    }

    /// <summary>
    /// Shows one badge key on uGUI objects. Set the key in the Inspector, or call <see cref="Bind"/> from list items.
    /// Binds to <see cref="BadgeHub.Current"/> unless a tree is given.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("JJEvol/Badge View")]
    public sealed class BadgeView : MonoBehaviour
    {
        [SerializeField] private string key = "";
        [SerializeField] private BadgeViewMode mode = BadgeViewMode.Dot;
        [Tooltip("Shown when the key is on and no number is shown.")]
        [SerializeField] private GameObject dot;
        [Tooltip("Shown with the number in Count mode. May be the same object as the text.")]
        [SerializeField] private GameObject countRoot;
        [SerializeField] private TMP_Text countText;
        [Min(1)] [SerializeField] private int maxCount = 99;

        private BadgeTree _tree;
        private IDisposable _watch;
        private bool _hubListening;

        public string Key => key;
        public BadgeViewMode Mode { get => mode; set { mode = value; Show(Value); } }
        public BadgeValue Value { get; private set; }

        /// <summary>Raised after the shown value changes (for animation or sound).</summary>
        public event Action<BadgeValue> ValueChanged;

        /// <summary>Binds to a key. A null tree means <see cref="BadgeHub.Current"/>. An empty key shows nothing.</summary>
        public void Bind(string badgeKey, BadgeTree tree = null)
        {
            if (!string.IsNullOrEmpty(badgeKey)) BadgeKey.Validate(badgeKey);
            key = badgeKey ?? "";
            _tree = tree;
            if (enabled && gameObject.activeInHierarchy) Rebind();
        }

        public void Unbind() => Bind("", _tree);

        private void OnEnable()
        {
            if (!_hubListening) { BadgeHub.CurrentChanged += Rebind; _hubListening = true; }
            Rebind();
        }

        private void OnDisable()
        {
            if (_hubListening) { BadgeHub.CurrentChanged -= Rebind; _hubListening = false; }
            _watch?.Dispose();
            _watch = null;
        }

        private void Rebind()
        {
            _watch?.Dispose();
            _watch = null;
            BadgeTree tree = _tree ?? BadgeHub.Current;
            if (tree == null || string.IsNullOrEmpty(key) || !BadgeKey.IsValid(key)) { Show(BadgeValue.None); return; }
            _watch = tree.Watch(key, Show);
        }

        private void Show(BadgeValue value)
        {
            if (this == null) { _watch?.Dispose(); _watch = null; return; }   // destroyed while still watching
            bool number = mode == BadgeViewMode.Count && value.Count > 0;
            if (countRoot != null) countRoot.SetActive(number);
            if (countText != null)
            {
                if (countRoot == null) countText.gameObject.SetActive(number);
                if (number) countText.text = Format(value.Count, maxCount);
            }
            if (dot != null) dot.SetActive(value.On && !number);
            if (value == Value) return;
            Value = value;
            ValueChanged?.Invoke(value);
        }

        /// <summary>The number text: the count, or <c>max+</c> above the limit.</summary>
        public static string Format(int count, int max)
            => count > max ? max.ToString(CultureInfo.InvariantCulture) + "+" : count.ToString(CultureInfo.InvariantCulture);
    }
}
