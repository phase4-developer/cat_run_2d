using System;
using UnityEngine;

namespace jjevol.Badge
{
    /// <summary>
    /// Runs a dirty tree's recompute once in the next LateUpdate. The driver component is enabled only while a
    /// recompute is pending, so a clean tree costs nothing per frame. Play mode only; in Edit mode tests use
    /// <see cref="ManualBadgeScheduler"/>.
    /// </summary>
    public sealed class BadgeFrameScheduler : IBadgeScheduler, IDisposable
    {
        private readonly BadgeFrameDriver _driver;
        private bool _disposed;

        /// <exception cref="InvalidOperationException">Outside Play mode, where LateUpdate does not run.</exception>
        public BadgeFrameScheduler()
        {
            if (!Application.isPlaying) throw new InvalidOperationException("BadgeFrameScheduler runs in Play mode only. Use ManualBadgeScheduler or ImmediateBadgeScheduler in Edit mode.");
            var host = new GameObject("[JJEvol Badge Scheduler]") { hideFlags = HideFlags.HideInHierarchy | HideFlags.DontSave };
            UnityEngine.Object.DontDestroyOnLoad(host);
            _driver = host.AddComponent<BadgeFrameDriver>();
            _driver.enabled = false;
        }

        public void Request(Action flush)
        {
            if (flush == null) throw new ArgumentNullException(nameof(flush));
            if (_disposed || _driver == null) throw new ObjectDisposedException(nameof(BadgeFrameScheduler));
            _driver.Pending = flush;
            _driver.enabled = true;
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            if (_driver == null) return;
            _driver.Pending = null;
            UnityEngine.Object.Destroy(_driver.gameObject);
        }
    }

    [AddComponentMenu("")]
    internal sealed class BadgeFrameDriver : MonoBehaviour
    {
        internal Action Pending;

        private void LateUpdate()
        {
            Action flush = Pending;
            Pending = null;
            enabled = false;
            if (flush == null) return;
            try { flush(); }
            catch (Exception exception) { Debug.LogException(exception, this); }
        }
    }

    /// <summary>
    /// The tree that badge components bind to when none is given in code. The game sets it once at boot.
    /// </summary>
    public static class BadgeHub
    {
        private static BadgeTree _current;
        private static BadgeFrameScheduler _ownedScheduler;

        public static BadgeTree Current => _current;

        /// <summary>Raised after <see cref="Current"/> changes, so components enabled before boot can bind.</summary>
        public static event Action CurrentChanged;

        public static void Use(BadgeTree tree)
        {
            if (ReferenceEquals(_current, tree)) return;
            _current = tree;
            CurrentChanged?.Invoke();
        }

        /// <summary>
        /// Creates a tree on a <see cref="BadgeFrameScheduler"/>, logs its errors, and makes it current.
        /// Calling it again replaces the tree and disposes the scheduler the hub made before.
        /// </summary>
        public static BadgeTree CreateForPlayMode()
        {
            var scheduler = new BadgeFrameScheduler();
            _ownedScheduler?.Dispose();
            _ownedScheduler = scheduler;
            var tree = new BadgeTree(scheduler);
            tree.Error += (key, exception) => Debug.LogException(key == null ? exception : new InvalidOperationException("Badge '" + key + "' failed.", exception));
            Use(tree);
            return tree;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetForDomainReloadOff()
        {
            _current = null;
            _ownedScheduler = null;
            CurrentChanged = null;
        }
    }
}
