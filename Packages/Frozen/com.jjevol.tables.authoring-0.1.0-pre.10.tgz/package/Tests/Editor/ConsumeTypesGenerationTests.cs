using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Tables.Authoring.Tests
{
    public sealed class ConsumeTypesGenerationTests
    {
        private string root, output, code, space;
        private static readonly Type Compilation = typeof(TableBuilder).Assembly.GetType("jjevol.TableCompilation", true);
        private const BindingFlags Statics = BindingFlags.Static | BindingFlags.NonPublic;
        private static readonly FieldInfo CompileRequest = Compilation.GetField("RequestCompilation", Statics);
        private object realCompileRequest;
        private int compileRequests;
        private static readonly BindingFlags Fields = BindingFlags.Instance | BindingFlags.NonPublic;
        private static TableInput Definition(string rows) => TableInput.FromText("ConsumeTypes", "typeId\tcodeName\n" + rows);
        private static TableInput Table(string label = "old") => TableInput.FromText("a", "key\tlabel\nx\t" + label);
        private ConsumeTypesGenerationSettings Settings(ConsumeTypeMigration migration = null) => new ConsumeTypesGenerationSettings(code, space, migration: migration);
        private TableBuildPlan Plan(string rows = "1\tWealth\n5\tItem", bool together = false, ConsumeTypeMigration migration = null)
            => TableBuilder.Plan(new TableBuildRequest(together ? new[] { Table("new"), Definition(rows) } : new[] { Definition(rows) }, output, false, consumeTypes: Settings(migration)));
        [SetUp] public void Setup()
        {
            realCompileRequest = CompileRequest.GetValue(null); compileRequests = 0;
            CompileRequest.SetValue(null, (Action)(() => compileRequests++)); // These tests must never start a compile in the Host.
            string id = Guid.NewGuid().ToString("N");
            root = "Assets/JJEvolStep05CUnits_" + id; output = root + "/Resources/Tables"; code = root + "/Game/Generated"; space = "JJEvol.Synthetic.G" + id;
            Directory.CreateDirectory(root + "/Game");
            File.WriteAllText(root + "/Game/UnitGame.asmdef", "{\"name\":\"JJEvol.Synthetic.G" + id + "\",\"references\":[\"JJEvol.Economy.Runtime\"]}");
            TableAuthoringOptions.ValidateTables = null; TableAuthoringOptions.EncryptBytes = null; TableRuntimeOptions.DecryptBytes = null;
            // These synchronous file-boundary tests do not test compilation/import. Keep temporary
            // per-case asmdefs/sources unimported until removed; the separate Host tests real reloads.
            AssetDatabase.DisallowAutoRefresh(); AssetDatabase.StartAssetEditing();
            EditorApplication.LockReloadAssemblies();
        }
        [TearDown] public void Cleanup()
        {
            try
            {
                TableQaFailureEvidence.Capture(root, output);
                PipelineValidation.ForgetFixtureMetadata(root);
                string full = Path.GetFullPath(root), assets = Path.GetFullPath(Application.dataPath);
                if (Path.GetDirectoryName(full) != assets || !Path.GetFileName(full).StartsWith("JJEvolStep05CUnits_", StringComparison.Ordinal)) throw new InvalidOperationException("Unsafe synthetic cleanup.");
                if (Directory.Exists(full)) Directory.Delete(full, true);
                if (File.Exists(full + ".meta")) File.Delete(full + ".meta");
            }
            finally { CompileRequest.SetValue(null, realCompileRequest); AssetDatabase.StopAssetEditing(); AssetDatabase.AllowAutoRefresh(); EditorApplication.UnlockReloadAssemblies(); AssetDatabase.Refresh(); }
        }
        private static object Field(object value, string name) => value.GetType().GetField(name, Fields | BindingFlags.Public).GetValue(value);
        private static void Writer(TablePreparedBuild prepared, Func<Action<string, byte[]>, Action<string, byte[]>> wrap)
        { var field = typeof(TablePreparedBuild).GetField("WriteFile", Fields); field.SetValue(prepared, wrap((Action<string, byte[]>)field.GetValue(prepared))); }
        // Pure history/no-op tests seed recorded bytes without asserting compilation success.
        // Actual Unity compilation/JSON tests are a separate multi-process synthetic Host validation.
        private void Seed(string rows = "1\tWealth\n5\tItem", ConsumeTypeMigration migration = null, bool together = false)
        {
            var prepared = TableBuilder.Prepare(Plan(rows, together, migration));
            foreach (object entry in (IEnumerable)Field(prepared, "Entries"))
            {
                string path = (string)Field(entry, "path"), data = (string)Field(entry, "newData");
                if (data == null) { if (File.Exists(path)) File.Delete(path); }
                else { Directory.CreateDirectory(Path.GetDirectoryName(path)); File.WriteAllBytes(path, Convert.FromBase64String(data)); }
            }
            Directory.CreateDirectory(Path.GetDirectoryName(prepared.Plan.ManifestPath));
            File.WriteAllText(prepared.Plan.ManifestPath, JsonUtility.ToJson(Field(prepared, "Result"), true) + "\n", new UTF8Encoding(false));
        }
        private static void Error(TableBuildPlan plan, string code)
        { Assert.That(plan.IsValid, Is.False); Assert.That(plan.Diagnostics.Any(d => d.Code == code), Is.True, string.Join("\n", plan.Diagnostics)); Assert.Throws<InvalidDataException>(() => TableBuilder.Prepare(plan)); }

        [Test] public void AuthoringOnlyPreviewAndPrepareDoNotWriteOrRequireACodec()
        {
            var plan = TableBuilder.Plan(new TableBuildRequest(new[] { Definition("-1\tJunk\n0\tWealth\n2147483647\tMaximum\n-2147483648\tMinimum") }, output, true, consumeTypes: Settings()));
            Assert.That(plan.IsValid, Is.True); Assert.That(plan.Changes, Is.Empty); Assert.That(plan.ConsumeTypes.Changes.Count, Is.EqualTo(2));
            Assert.That(plan.ConsumeTypes.Definitions.Select(d => d.TypeId), Is.EqualTo(new[] { int.MinValue, -1, 0, int.MaxValue }));
            Assert.That(plan.ConsumeTypes.EnumSource, Does.Contain("Minimum = -2147483648,").And.Contain("Maximum = 2147483647,").And.Not.Contain("None ="));
            Assert.That(plan.ConsumeTypes.ExtensionsSource, Does.Contain("new global::jjevol.ConsumeTypeId((int)value)").And.Contain("return false"));
            var prepared = TableBuilder.Prepare(plan);
            Assert.That(prepared.State, Is.EqualTo(TableBuildState.Prepared)); Assert.That(prepared.RequiresCompilation, Is.True);
            Assert.That(Directory.Exists(code), Is.False); Assert.That(Directory.Exists(output), Is.False); Assert.That(File.Exists(plan.ManifestPath), Is.False);
        }
        [Test] public void LegacyTableOnlyMetadataKeepsItsShapeAndNoOpContract()
        {
            var request = new TableBuildRequest(new[] { Table() }, output, false);
            TableBuilder.Prepare(TableBuilder.Plan(request)).Apply();
            string manifest = File.ReadAllText(TableBuilder.GetManifestPath(output));
            Assert.That(manifest, Does.Not.Contain("\"consume\"").And.Not.Contain("\"hasConsume\""));
            var prepared = TableBuilder.Prepare(TableBuilder.Plan(request));
            Assert.That(prepared.IsNoOp, Is.True); Assert.That(prepared.Apply().State, Is.EqualTo(TableBuildState.Ready));
        }
        [TestCase("0\tNone")][TestCase("0\tWealth")][TestCase("-7\tNegative")][TestCase("1\t_")]
        public void ExplicitZeroNoneNegativeAndAsciiIdentifierAreAccepted(string rows) => Assert.That(Plan(rows).IsValid, Is.True);
        [TestCase("1\tNone", "ConsumeNone")]
        [TestCase("1\tclass", "ConsumeCodeName")][TestCase("1\trecord", "ConsumeCodeName")]
        [TestCase("1\t@Item", "ConsumeCodeName")][TestCase("1\t한글", "ConsumeCodeName")]
        [TestCase("1\tA-B", "ConsumeCodeName")][TestCase("1\t9Item", "ConsumeCodeName")]
        [TestCase("1\tvalue__", "ConsumeCodeName")][TestCase("1\tGameConsumeType", "ConsumeCodeName")]
        [TestCase("1\tX\n1\tY", "DuplicateTypeId")][TestCase("0\tX\n0\tY", "DuplicateTypeId")]
        [TestCase("1\tItem\n2\tItem", "DuplicateCodeName")][TestCase("1\tItem\n2\titem", "DuplicateCodeName")]
        [TestCase("2147483648\tItem", "ConsumeTypeId")][TestCase("-2147483649\tItem", "ConsumeTypeId")]
        [TestCase("1.0\tItem", "ConsumeTypeId")][TestCase(" 1\tItem", "ConsumeTypeId")][TestCase("\tItem", "ConsumeTypeId")]
        public void InvalidDefinitionIsLocatedAndCannotPrepare(string rows, string diagnostic)
        {
            var plan = Plan(rows); Error(plan, diagnostic);
            var error = plan.Diagnostics.First(d => d.Code == diagnostic);
            Assert.That(error.Row, Is.GreaterThanOrEqualTo(2)); Assert.That(error.Column, Is.GreaterThanOrEqualTo(1)); Assert.That(error.Header, Is.Not.Empty);
            Assert.That(Directory.Exists(code), Is.False);
        }
        [Test] public void DefinitionErrorsReportTheSourceRowAfterSkippedBlankRows()
        {
            // Source rows 3 and 5 are blank and skipped; each error keeps its pasted row number.
            var plan = Plan("1\tWealth\n\t\nx\tItem\n \t \n1\tGold\n2\tclass");
            Assert.That(plan.Diagnostics.Single(d => d.Code == "ConsumeTypeId").Row, Is.EqualTo(4));
            Assert.That(plan.Diagnostics.Single(d => d.Code == "DuplicateTypeId").Row, Is.EqualTo(6));
            Assert.That(plan.Diagnostics.Single(d => d.Code == "ConsumeCodeName").Row, Is.EqualTo(7));
        }
        [Test] public void RequiredColumnsAndSelectionAreExplicit()
        {
            var input = TableInput.FromText("ConsumeTypes", "id\tname\n1\tWealth");
            Error(TableBuilder.Plan(new TableBuildRequest(new[] { input }, output, false, consumeTypes: Settings())), "ConsumeTypesColumns");
            Error(TableBuilder.Plan(new TableBuildRequest(new[] { Table(), Definition("1\tWealth") }, output, false, selected: new[] { "a" }, consumeTypes: Settings())), "ConsumeTypesMissing");
        }
        [TestCase("Bad..Space", "Type")][TestCase("class.Game", "Type")][TestCase("Game", "class")][TestCase("", "Type")][TestCase("Game", "A/B")]
        public void InvalidNamespaceOrEnumIsRejectedWithoutAnyWrites(string ns, string name)
        {
            Assert.Throws<ArgumentException>(() => TableBuilder.Plan(new TableBuildRequest(new[] { Definition("1\tItem") }, output, false, consumeTypes: new ConsumeTypesGenerationSettings(code, ns, name))));
            Assert.That(Directory.Exists(code), Is.False);
        }
        [Test] public void SourceOrderAndNoncodeLabelsDoNotRewriteGeneratedFilesOrMetadata()
        {
            Seed(); var files = Directory.GetFiles(code); var hashes = files.Select(File.ReadAllBytes).ToArray(); var times = files.Select(File.GetLastWriteTimeUtc).ToArray();
            var reordered = Plan("5\tItem\n1\tWealth"); var prepared = TableBuilder.Prepare(reordered);
            Assert.That(prepared.IsNoOp, Is.True); Assert.That(prepared.RequiresCompilation, Is.False);
            Assert.That(reordered.ConsumeTypes.EnumSource, Is.EqualTo(Plan().ConsumeTypes.EnumSource));
            for (int i = 0; i < files.Length; i++) { Assert.That(File.ReadAllBytes(files[i]), Is.EqualTo(hashes[i])); Assert.That(File.GetLastWriteTimeUtc(files[i]), Is.EqualTo(times[i])); }
            var labels = TableInput.FromText("ConsumeTypes", "typeId\tcodeName\tdisplayName\tlocalizationKey\n1\tWealth\tCoins\tcoin.name\n5\tItem\tItems\titem.name");
            Assert.That(TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(new[] { labels }, output, false, consumeTypes: Settings()))).IsNoOp, Is.True);
        }
        [Test] public void MatchingFilesAloneCannotClaimACompiledReadyGeneration()
        {
            Seed();
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            Assert.That(TableBuilder.VerifyCompiledGeneration(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            var prepared = TableBuilder.Prepare(Plan());
            Assert.Throws<InvalidOperationException>(() => prepared.Apply());
        }
        [Test] public void NewIdsAreExplicitAndOldNumericIdsAreNeverRenumbered()
        {
            Seed(); var plan = Plan("1\tWealth\n5\tItem\n100\tAd");
            Assert.That(plan.IsValid, Is.True); Assert.That(plan.ConsumeTypes.Differences, Does.Contain("Add ID 100: Ad"));
            Assert.That(plan.ConsumeTypes.EnumSource, Does.Contain("Wealth = 1,").And.Contain("Item = 5,").And.Contain("Ad = 100,"));
        }
        [Serializable] private sealed class ManifestVersion { public int version; public bool hasConsume; }
        [Test] public void CodeOwnershipUsesVersionTwoWhileLegacyTableMetadataRemainsVersionOne()
        {
            Seed(); var metadata = JsonUtility.FromJson<ManifestVersion>(File.ReadAllText(TableBuilder.GetManifestPath(output)));
            Assert.That(metadata.version, Is.EqualTo(2)); Assert.That(metadata.hasConsume, Is.True);
        }
        [Test] public void RenameRequiresScopedApprovalAndKeepsItsId()
        {
            Seed(); Error(Plan("1\tCurrency\n5\tItem"), "RenameApprovalRequired");
            var migration = new ConsumeTypeMigration(new[] { 1 }, reason: "Synthetic reference migration");
            var plan = Plan("1\tCurrency\n5\tItem", migration: migration);
            Assert.That(plan.IsValid, Is.True); Assert.That(plan.ConsumeTypes.Differences.Any(d => d.StartsWith("BREAKING rename ID 1:")), Is.True);
            Assert.That(plan.ConsumeTypes.EnumSource, Does.Contain("Currency = 1,").And.Not.Contain("Wealth ="));
        }
        [Test] public void RenumberCannotBeApprovedAsRetireAndAdd()
        {
            Seed(); Error(Plan("2\tWealth\n5\tItem", migration: new ConsumeTypeMigration(retireIds: new[] { 1 }, reason: "Cannot override wire identity")), "RenumberTypeId");
        }
        [Test] public void RetirementIsExplicitAndItsIdAndHistoricalNameRemainReserved()
        {
            Seed(); Error(Plan("5\tItem"), "RetireApprovalRequired");
            Seed("5\tItem", new ConsumeTypeMigration(retireIds: new[] { 1 }, reason: "Synthetic retirement"));
            Error(Plan("1\tNewKind\n5\tItem"), "RetiredTypeId");
            Error(Plan("2\tWealth\n5\tItem"), "RenumberTypeId");
            Assert.That(Plan("5\tItem\n100\tAd").IsValid, Is.True);
        }
        [Test] public void RenameCannotReleaseHistoricalNameToAnotherId()
        {
            Seed(); Seed("1\tCurrency\n5\tItem", new ConsumeTypeMigration(new[] { 1 }, reason: "Rename"));
            Error(Plan("1\tCurrency\n5\tItem\n7\tWealth"), "RenumberTypeId");
        }
        [Test] public void MigrationApprovalRequiresAReason() => Assert.Throws<ArgumentException>(() => new ConsumeTypeMigration(new[] { 1 }));
        [Test] public void WindowRecompileSerializationRetainsExplicitFilesAndSelection()
        {
            var window = ScriptableObject.CreateInstance<CreateTable>();
            var clone = ScriptableObject.CreateInstance<CreateTable>();
            try
            {
                ((IList<string>)Field(window, "_files")).Add(root + "/ConsumeTypes.tsv");
                ((IList<string>)Field(window, "_selected")).Add("ConsumeTypes");
                EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(window), clone);
                Assert.That((IEnumerable)Field(clone, "_files"), Is.EqualTo(new[] { root + "/ConsumeTypes.tsv" }));
                Assert.That((IEnumerable)Field(clone, "_selected"), Is.EqualTo(new[] { "ConsumeTypes" }));
            }
            finally { UnityEngine.Object.DestroyImmediate(window); UnityEngine.Object.DestroyImmediate(clone); }
        }
        [TestCase("source")][TestCase("meta")]
        public void ManualGeneratedChangesAreConflictsIncludingTableOnlyBuilds(string kind)
        {
            Seed(); string path = code + "/GameConsumeType.Generated.cs" + (kind == "meta" ? ".meta" : "");
            File.AppendAllText(path, "\n// synthetic foreign change"); byte[] changed = File.ReadAllBytes(path);
            Error(Plan("1\tWealth\n5\tItem\n100\tAd"), "GeneratedManagedConflict");
            Error(TableBuilder.Plan(new TableBuildRequest(new[] { Table() }, output, false)), "GeneratedManagedConflict");
            Assert.That(File.ReadAllBytes(path), Is.EqualTo(changed));
        }
        [Test] public void EditedGeneratedSourceIsListedButCannotBecomeTheBaseline()
        {
            Seed(); string path = code + "/GameConsumeType.Generated.cs";
            File.AppendAllText(path, "\n// synthetic foreign change"); byte[] manifest = File.ReadAllBytes(TableBuilder.GetManifestPath(output));
            var difference = TableBuilder.GetFileDifferences(output).Single();
            Assert.That(difference.Path, Is.EqualTo(path)); Assert.That(difference.CanAccept, Is.False); Assert.That(difference.CanRegenerate, Is.True);
            Assert.That(difference.ToString(), Does.Contain("생성 코드 다시 만들기").And.Not.Contain("버전 관리"));
            Assert.Throws<InvalidOperationException>(() => TableBuilder.AcceptCurrentFiles(output, TableBuilder.GetFileDifferences(output)));
            Assert.That(File.ReadAllBytes(TableBuilder.GetManifestPath(output)), Is.EqualTo(manifest));
        }
        private string Source => code + "/GameConsumeType.Generated.cs";
        private TableBuildState Regenerate() => TableBuilder.RegenerateCode(output, TableBuilder.GetFileDifferences(output));
        [Test] public void EditedGeneratedSourceIsRebuiltAndWaitsForCompilationLikeANormalBuild()
        {
            Seed(); byte[] generated = File.ReadAllBytes(Source); string manifest = TableBuilder.GetManifestPath(output);
            File.AppendAllText(Source, "\n// synthetic hand edit");
            Assert.That(Regenerate(), Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            Assert.That(compileRequests, Is.EqualTo(1));
            Assert.That(File.ReadAllBytes(Source), Is.EqualTo(generated));
            Assert.That(File.Exists(manifest + ".pending"), Is.True);
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            Assert.That(TableBuilder.GetFileDifferences(output), Is.Empty, "The button is hidden while the journal is pending.");
            Assert.That(TableBuilder.VerifyCompiledGeneration(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile), "Matching files alone do not finish it.");
        }
        [Test] public void RecoverPutsTheHandEditBackAndOffersTheButtonAgain()
        {
            Seed(); File.AppendAllText(Source, "\n// synthetic hand edit"); byte[] edited = File.ReadAllBytes(Source);
            string manifest = TableBuilder.GetManifestPath(output); byte[] recorded = File.ReadAllBytes(manifest);
            Regenerate();
            Assert.That(TableBuilder.Recover(output), Is.True);
            Assert.That(File.ReadAllBytes(Source), Is.EqualTo(edited)); Assert.That(File.ReadAllBytes(manifest), Is.EqualTo(recorded));
            Assert.That(File.Exists(manifest + ".pending"), Is.False);
            Assert.That(TableBuilder.GetFileDifferences(output).Single().CanRegenerate, Is.True);
        }
        [Test] public void MissingSourceAndMetaComeBackWithTheRecordedGuid()
        {
            Seed(); string guid = File.ReadAllLines(Source + ".meta").First(l => l.StartsWith("guid: ", StringComparison.Ordinal));
            File.Delete(Source); File.Delete(Source + ".meta");
            var differences = TableBuilder.GetFileDifferences(output);
            Assert.That(differences.Count, Is.EqualTo(2)); Assert.That(differences.All(d => d.CanRegenerate), Is.True);
            Regenerate();
            Assert.That(File.ReadAllLines(Source + ".meta"), Does.Contain(guid));
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
        }
        [Test] public void AMissingMetaAloneIsRestoredWithoutACompile()
        {
            Seed(); File.Delete(Source + ".meta");
            Assert.That(Regenerate(), Is.EqualTo(TableBuildState.Ready));
            Assert.That(compileRequests, Is.Zero);
            Assert.That(File.Exists(TableBuilder.GetManifestPath(output) + ".pending"), Is.False);
            Assert.That(TableBuilder.GetFileDifferences(output), Is.Empty);
        }
        [Test] public void ACurrentMetaIsKeptAndRecordedWhenTheSourceIsRebuilt()
        {
            Seed(); File.AppendAllText(Source, "\n// synthetic hand edit"); File.AppendAllText(Source + ".meta", "# synthetic importer change\n"); byte[] meta = File.ReadAllBytes(Source + ".meta");
            Regenerate();
            Assert.That(File.ReadAllBytes(Source + ".meta"), Is.EqualTo(meta));
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
        }
        [Test] public void TablesAreAcceptedFirstThenCodeIsRebuilt()
        {
            Seed(together: true); File.AppendAllText(Source, "\n// synthetic hand edit"); File.WriteAllText(output + "/a.txt", "key\tlabel\nx\tedited\n");
            Assert.Throws<InvalidOperationException>(() => Regenerate());
            TableBuilder.AcceptCurrentFiles(output, TableBuilder.GetFileDifferences(output));
            var left = TableBuilder.GetFileDifferences(output).Single();
            Assert.That(left.Path, Is.EqualTo(Source)); Assert.That(left.CanRegenerate, Is.True);
            Assert.That(Regenerate(), Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
        }
        [Test] public void ATableEditIsAcceptedPastDamagedGeneratedMetaWhichThenComesBackWithItsGuid()
        {
            Seed(together: true); string guid = File.ReadAllLines(Source + ".meta").First(l => l.StartsWith("guid: ", StringComparison.Ordinal));
            File.WriteAllText(output + "/a.txt", "key\tlabel\nx\tedited\n");
            File.WriteAllText(Source + ".meta", File.ReadAllText(Source + ".meta").Replace("guid: ", "guid: 0"));
            TableBuilder.AcceptCurrentFiles(output, TableBuilder.GetFileDifferences(output));
            var left = TableBuilder.GetFileDifferences(output).Single();
            Assert.That(left.Path, Is.EqualTo(Source + ".meta")); Assert.That(left.CanRegenerate, Is.True);
            Assert.That(Regenerate(), Is.EqualTo(TableBuildState.Ready));
            Assert.That(File.ReadAllLines(Source + ".meta"), Does.Contain(guid));
            Assert.That(TableBuilder.GetFileDifferences(output), Is.Empty);
        }
        [Test] public void RegenerationIsRefusedWhileAJournalIsPendingOrFilesChangedAfterReview()
        {
            Seed(); File.AppendAllText(Source, "\n// first"); var reviewed = TableBuilder.GetFileDifferences(output);
            File.AppendAllText(Source, "\n// second"); byte[] edited = File.ReadAllBytes(Source);
            Assert.Throws<IOException>(() => TableBuilder.RegenerateCode(output, reviewed));
            string pending = TableBuilder.GetManifestPath(output) + ".pending"; File.WriteAllText(pending, "{}");
            try { Assert.Throws<InvalidOperationException>(() => TableBuilder.RegenerateCode(output, reviewed)); }
            finally { File.Delete(pending); }
            Assert.That(File.ReadAllBytes(Source), Is.EqualTo(edited));
        }
        private static void CompileEvent(string method, params object[] values) => Compilation.GetMethod(method, Statics).Invoke(null, values);
        private static void WhileTheCompileFailedFlagIsOn(Action test)
        {
            var flag = Compilation.GetField("ScriptCompilationFailed", Statics); object original = flag.GetValue(null);
            flag.SetValue(null, (Func<bool>)(() => true));
            try { test(); }
            finally { flag.SetValue(null, original); Compilation.GetField("failureFlagIsOld", Statics).SetValue(null, false); }
        }
        [Test] public void ACleanCompileAfterAHandEditBrokeCompilationIsNotRecordedAsFailed() => WhileTheCompileFailedFlagIsOn(() =>
        {
            Seed(); File.AppendAllText(Source, "\nsynthetic hand edit that does not compile");
            Assert.That(Regenerate(), Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            // Before the compile: nothing has failed yet, so the Recover button must stay hidden.
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            CompileEvent("OnCompilationStarted", new object[] { null });
            CompileEvent("OnAssemblyCompilationFinished", "JJEvol.Synthetic", Array.Empty<UnityEditor.Compilation.CompilerMessage>());
            CompileEvent("OnCompilationFinished", new object[] { null });
            // The flag still reads true at compilationFinished, and no failure record may result from it.
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
            Assert.That(TableBuilder.VerifyCompiledGeneration(output).State, Is.EqualTo(TableBuildState.AppliedAwaitingCompile));
        });
        [Test] public void AnActualCompileErrorAfterRegenerationIsRecordedAndCanBeRecovered() => WhileTheCompileFailedFlagIsOn(() =>
        {
            Seed(); File.AppendAllText(Source, "\nsynthetic hand edit"); byte[] edited = File.ReadAllBytes(Source);
            Regenerate();
            CompileEvent("OnCompilationStarted", new object[] { null });
            CompileEvent("OnAssemblyCompilationFinished", "JJEvol.Synthetic", new[] { new UnityEditor.Compilation.CompilerMessage { type = UnityEditor.Compilation.CompilerMessageType.Error, message = "synthetic" } });
            CompileEvent("OnCompilationFinished", new object[] { null });
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.RecoveryRequired));
            Assert.That(TableBuilder.Recover(output), Is.True);
            Assert.That(File.ReadAllBytes(Source), Is.EqualTo(edited));
        });
        [Test] public void TheFlagStillBlocksWhenNothingWasWrittenAfterIt() => WhileTheCompileFailedFlagIsOn(() =>
        {
            Seed();
            Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.RecoveryRequired));
        });
        [Test] public void GeneratedMetaChangeBecomesTheBaselineAndKeepsTheRecordValid()
        {
            Seed(); File.AppendAllText(code + "/GameConsumeType.Generated.cs.meta", "# synthetic importer change\n");
            TableBuilder.AcceptCurrentFiles(output, TableBuilder.GetFileDifferences(output));
            Assert.That(TableBuilder.GetFileDifferences(output), Is.Empty);
            Assert.That(Plan().IsValid, Is.True);
        }
        [Test] public void CrlfCheckoutOfGeneratedSourceNeedsNoRewriteOrRecompile()
        {
            Seed(); string path = code + "/GameConsumeType.Generated.cs";
            File.WriteAllBytes(path, Encoding.UTF8.GetBytes(Encoding.UTF8.GetString(File.ReadAllBytes(path)).Replace("\n", "\r\n")));
            var plan = Plan(); Assert.That(plan.IsValid, Is.True, string.Join("\n", plan.Diagnostics));
            Assert.That(plan.ConsumeTypes.Changes.All(c => c.Action == TableOutputAction.Unchanged), Is.True);
            Assert.That(TableBuilder.Prepare(plan).RequiresCompilation, Is.False);
        }
        [Test] public void ExistingUnownedGeneratedFilenameCannotBeAdoptedByTheGenerator()
        {
            Directory.CreateDirectory(code); string path = code + "/GameConsumeType.Generated.cs"; File.WriteAllText(path, "// user-owned");
            Error(Plan(), "GeneratedUnmanagedConflict"); Assert.That(File.ReadAllText(path), Is.EqualTo("// user-owned"));
        }
        [Test] public void GeneratedIdentityChangesAreNotAutomaticSourceRelocations()
        {
            Seed();
            var request = new TableBuildRequest(new[] { Definition("1\tWealth\n5\tItem") }, output, false, consumeTypes: new ConsumeTypesGenerationSettings(code, space + ".Other"));
            Error(TableBuilder.Plan(request), "ConsumeIdentityChange");
        }
        [Test] public void OtherManifestAndPendingGenerationCannotAcquireTheSameCodeScope()
        {
            Seed();
            var otherOutput = root + "/Other/Resources/Tables";
            Error(TableBuilder.Plan(new TableBuildRequest(new[] { Definition("1\tWealth") }, otherOutput, false, consumeTypes: Settings())), "GeneratedOwnerConflict");
            File.WriteAllText(TableBuilder.GetManifestPath(output) + ".pending", "synthetic unresolved marker");
            Error(TableBuilder.Plan(new TableBuildRequest(new[] { Definition("1\tWealth") }, otherOutput, false, consumeTypes: new ConsumeTypesGenerationSettings(root + "/Game/Other", space + ".Other"))), "OtherPendingGeneration");
        }
        [TestCase("code")][TestCase("assembly")][TestCase("file")]
        public void ChangesAfterPreviewInvalidateTheWholePreparedScope(string kind)
        {
            var plan = Plan(together: true);
            if (kind == "code") { Directory.CreateDirectory(code); File.WriteAllText(code + "/unmanaged.txt", "external"); }
            else if (kind == "assembly") File.AppendAllText(root + "/Game/UnitGame.asmdef", " ");
            else { Directory.CreateDirectory(code); File.WriteAllText(code + "/GameConsumeType.Generated.cs", "// foreign"); }
            Assert.Throws<IOException>(() => TableBuilder.Prepare(plan)); Assert.That(Directory.Exists(output), Is.False);
        }
        [Test] public void CombinedCodeAndEncryptedTableUseTheSameFrozenValidatorInput()
        {
            TableAuthoringOptions.EncryptBytes = LegacyFixture.Encrypt; TableRuntimeOptions.DecryptBytes = LegacyFixture.Decrypt;
            int calls = 0;
            var request = new TableBuildRequest(new[] { Table("validated"), Definition("1\tWealth\n5\tItem") }, output, true,
                validate: inputs => { calls++; Assert.That(inputs.Count, Is.EqualTo(2)); Assert.That(inputs.Single(i => i.TableName == "a").Rows[0].Get("label"), Is.EqualTo("validated")); Assert.That(inputs.Single(i => i.TableName == "ConsumeTypes").Rows[0].Get("typeId"), Is.EqualTo("1")); },
                consumeTypes: Settings());
            var plan = TableBuilder.Plan(request); var prepared = TableBuilder.Prepare(plan);
            Assert.That(calls, Is.GreaterThan(1)); Assert.That(plan.Changes.Count, Is.EqualTo(1)); Assert.That(plan.ConsumeTypes.Changes.Count, Is.EqualTo(2));
            Assert.That(prepared.OutputHashes.Count, Is.EqualTo(3)); Assert.That(Directory.Exists(output), Is.False); Assert.That(Directory.Exists(code), Is.False);
        }
        [TestCase("first")][TestCase("firstCode")][TestCase("secondCode")][TestCase("checkpoint")]
        public void FailedCombinedApplyRestoresOnlyItsOwnEntireFileGeneration(string boundary)
        {
            TableBuilder.Prepare(TableBuilder.Plan(new TableBuildRequest(new[] { Table() }, output, false))).Apply();
            string manifest = TableBuilder.GetManifestPath(output); byte[] old = File.ReadAllBytes(output + "/a.txt"), meta = File.ReadAllBytes(output + "/a.txt.meta"), previous = File.ReadAllBytes(manifest);
            var prepared = TableBuilder.Prepare(Plan(together: true)); int writes = 0;
            Writer(prepared, original => (path, bytes) =>
            {
                writes++;
                bool fail = boundary == "first" ? writes == 1 : boundary == "firstCode" ? path.EndsWith("GameConsumeType.Generated.cs", StringComparison.Ordinal) : boundary == "secondCode" && path.EndsWith("Extensions.Generated.cs", StringComparison.Ordinal);
                if (fail) throw new IOException("Synthetic exact write boundary");
                original(path, bytes);
            });
            if (boundary == "checkpoint") typeof(TablePreparedBuild).GetField("WriteCheckpoint", Fields).SetValue(prepared, (Action<string, byte[], string>)((p, b, h) => { throw new IOException("Synthetic checkpoint"); }));
            Assert.Throws<IOException>(() => prepared.Apply()); Assert.That(prepared.State, Is.EqualTo(TableBuildState.Restored));
            Assert.That(File.ReadAllBytes(output + "/a.txt"), Is.EqualTo(old)); Assert.That(File.ReadAllBytes(output + "/a.txt.meta"), Is.EqualTo(meta));
            Assert.That(File.ReadAllBytes(manifest), Is.EqualTo(previous)); Assert.That(File.Exists(manifest + ".pending"), Is.False);
            Assert.That(File.Exists(code + "/GameConsumeType.Generated.cs"), Is.False); Assert.That(File.Exists(code + "/GameConsumeTypeExtensions.Generated.cs"), Is.False);
        }
        [TestCase("source")][TestCase("meta")]
        public void ForeignGeneratedBytesDuringRollbackRemainUntouchedAndPending(string kind)
        {
            var prepared = TableBuilder.Prepare(Plan(together: true)); string foreign = code + "/GameConsumeType.Generated.cs" + (kind == "meta" ? ".meta" : "");
            Writer(prepared, original => (path, bytes) =>
            {
                if (path.EndsWith("Extensions.Generated.cs", StringComparison.Ordinal)) { File.AppendAllText(foreign, "\n// foreign"); throw new IOException("Synthetic second source failure plus foreign change"); }
                original(path, bytes);
            });
            Assert.Throws<TableBuildRecoveryException>(() => prepared.Apply()); Assert.That(prepared.State, Is.EqualTo(TableBuildState.RecoveryRequired));
            byte[] changed = File.ReadAllBytes(foreign); Assert.That(File.Exists(prepared.Plan.ManifestPath + ".pending"), Is.True);
            Assert.That(TableBuilder.Recover(output), Is.False); Assert.That(File.ReadAllBytes(foreign), Is.EqualTo(changed)); Assert.That(Plan().IsValid, Is.False);
        }
        [Serializable] private sealed class Locator { public string journal; }
        [TestCase(false)][TestCase(true)]
        public void ReopenedFirstGenerationJournalRestoresMissingFilesOrBlocksWhenLost(bool loseJournal)
        {
            var prepared = TableBuilder.Prepare(Plan(together: true)); FileStream held = null;
            Writer(prepared, original => (path, bytes) =>
            {
                if (path.EndsWith("Extensions.Generated.cs", StringComparison.Ordinal))
                {
                    held = new FileStream(code + "/GameConsumeType.Generated.cs", FileMode.Open, FileAccess.Read, FileShare.None);
                    throw new IOException("Synthetic failure while created source is exclusively held.");
                }
                original(path, bytes);
            });
            try { Assert.Throws<TableBuildRecoveryException>(() => prepared.Apply()); }
            finally { held?.Dispose(); }
            string pending = prepared.Plan.ManifestPath + ".pending";
            Assert.That(File.Exists(pending), Is.True);
            if (loseJournal)
            {
                string path = Path.GetFullPath(JsonUtility.FromJson<Locator>(File.ReadAllText(pending)).journal);
                string allowed = Path.GetFullPath("Library/JJEvol/TableAuthoring") + Path.DirectorySeparatorChar;
                Assert.That(path.StartsWith(allowed, StringComparison.OrdinalIgnoreCase) && Path.GetFileName(path) == "journal.json", Is.True);
                File.Delete(path);
                Assert.That(TableBuilder.Recover(output), Is.False); Assert.That(TableBuilder.GetStatus(output).State, Is.EqualTo(TableBuildState.RecoveryRequired));
                Assert.That(File.Exists(pending), Is.True); Assert.That(Plan().IsValid, Is.False);
            }
            else
            {
                Assert.That(TableBuilder.Recover(output), Is.True);
                Assert.That(File.Exists(pending), Is.False); Assert.That(File.Exists(prepared.Plan.ManifestPath), Is.False);
                Assert.That(File.Exists(output + "/a.txt"), Is.False); Assert.That(File.Exists(output + "/a.txt.meta"), Is.False);
                Assert.That(File.Exists(code + "/GameConsumeType.Generated.cs"), Is.False); Assert.That(File.Exists(code + "/GameConsumeType.Generated.cs.meta"), Is.False);
            }
        }
    }
}
