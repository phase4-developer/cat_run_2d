using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;

namespace jjevol.Tables.Authoring.Tests
{
    // Columns are matched by header name. Sheet data pasted into a TSV file keeps working when its
    // column order differs, names carry stray spaces or case, or it has unused, unnamed or missing columns.
    public sealed class TableColumnNameTests
    {
        private string _root;
        private string Output => _root + "/Resources/Tables";
        private static readonly TableSchema Items = new TableSchema("items",
            new TableColumnRule("id", TableColumnKind.Int32, unique: true),
            new TableColumnRule("priceValue", TableColumnKind.Int64),
            new TableColumnRule("grade", TableColumnKind.Int32, required: false));

        [SetUp] public void Setup() { _root = "Assets/JJEvolStepColumnNames_" + Guid.NewGuid().ToString("N"); Directory.CreateDirectory(_root); }
        [TearDown] public void Cleanup() { PipelineValidation.ForgetFixtureMetadata(_root); AssetDatabase.Refresh(); AssetDatabase.DeleteAsset(_root); }

        private TableBuildPlan Plan(string text, params TableSchema[] schemas)
            => TableBuilder.Plan(new TableBuildRequest(new[] { TableInput.FromText("items", text) }, Output, false, schemas: schemas));
        private static TSVRow[] Runtime(TableBuildPlan plan) => TSVRow.FromTsv(plan.ValidationInputs.Single().Document.RuntimeText).ToArray();
        private static readonly string[] ColumnCodes = { "HeaderSpacing", "HeaderCase", "UnusedColumn", "UnnamedColumn", "MissingColumn", "MissingCells", "ExtraCells", "BlankRecord" };
        private static string Codes(TableBuildPlan plan) => string.Join("\n", plan.Diagnostics);
        private static TableDiagnostic Warning(TableBuildPlan plan, string code)
        {
            var warning = plan.Diagnostics.Single(d => d.Code == code);
            Assert.That(warning.Severity, Is.EqualTo(TableDiagnosticSeverity.Warning), Codes(plan));
            return warning;
        }

        [TestCase("id\tpriceValue\tgrade\n7\t100\t2")]
        [TestCase("grade\tpriceValue\tid\n2\t100\t7")]
        [TestCase("priceValue\tid\tgrade\n100\t7\t2")]
        public void ColumnOrderDoesNotMatter(string text)
        {
            var plan = Plan(text, Items);
            Assert.That(plan.IsValid, Is.True, Codes(plan));
            Assert.That(plan.Diagnostics.Where(d => ColumnCodes.Contains(d.Code)), Is.Empty, Codes(plan));
            var row = Runtime(plan).Single();
            Assert.That(row.GetInt("id"), Is.EqualTo(7)); Assert.That(row.GetLong("priceValue"), Is.EqualTo(100)); Assert.That(row.GetInt("grade"), Is.EqualTo(2));
        }

        [Test]
        public void HeaderSpacesAndCaseAreWarnedAndWrittenAsTheSchemaName()
        {
            var plan = Plan(" ID \tpricevalue\tGrade\n7\t100\t2", Items);
            Assert.That(plan.IsValid, Is.True, Codes(plan));
            Assert.That(Warning(plan, "HeaderSpacing").Column, Is.EqualTo(1));
            Assert.That(plan.Diagnostics.Count(d => d.Code == "HeaderCase" && d.Severity == TableDiagnosticSeverity.Warning), Is.EqualTo(3), Codes(plan));
            Assert.That(plan.ValidationInputs.Single().Document.Headers, Is.EqualTo(new[] { "id", "priceValue", "grade" }));
            Assert.That(plan.ValidationInputs.Single().Document.RuntimeText.Split('\n')[0], Is.EqualTo("id\tpriceValue\tgrade"));
        }

        [Test]
        public void HeaderSpacesAreTrimmedWithoutASchema()
        {
            var document = TableDocument.Parse(TableInput.FromText("items", "id \t name\n1\tsword"));
            Assert.That(document.IsValid, Is.True); Assert.That(document.Headers, Is.EqualTo(new[] { "id", "name" }));
            Assert.That(document.Diagnostics.Count(d => d.Code == "HeaderSpacing"), Is.EqualTo(2));
            Assert.That(TSVRow.FromTsv(document.RuntimeText).Single().Get("name"), Is.EqualTo("sword"));
        }

        [Test]
        public void ColumnOutsideTheSchemaIsWarnedAndKept()
        {
            var plan = Plan("id\tmemo\tpriceValue\n7\tdesigner note\t100", Items);
            Assert.That(plan.IsValid, Is.True, Codes(plan));
            Assert.That(Warning(plan, "UnusedColumn").Header, Is.EqualTo("memo"));
            Assert.That(Runtime(plan).Single().Get("memo"), Is.EqualTo("designer note"));
        }

        [Test]
        public void UnnamedColumnIsWarnedAndItsValuesAreDropped()
        {
            var plan = Plan("id\t\tpriceValue\n7\tstray\t100", Items);
            Assert.That(plan.IsValid, Is.True, Codes(plan));
            Assert.That(Warning(plan, "UnnamedColumn").Column, Is.EqualTo(2));
            Assert.That(plan.ValidationInputs.Single().Document.RuntimeText, Is.EqualTo("id\tpriceValue\n7\t100"));
            Assert.That(Runtime(plan).Single().GetLong("priceValue"), Is.EqualTo(100));
        }

        [Test]
        public void MissingOptionalSchemaColumnIsWarnedAndUsesTheDefault()
        {
            var plan = Plan("priceValue\tid\n100\t7", Items);
            Assert.That(plan.IsValid, Is.True, Codes(plan));
            Assert.That(Warning(plan, "MissingColumn").Header, Is.EqualTo("grade"));
            Assert.That(Runtime(plan).Single().GetInt("grade", 3), Is.EqualTo(3));
        }

        [Test]
        public void MissingRequiredSchemaColumnStillBlocks()
        {
            var plan = Plan("grade\tpriceValue\n1\t100", Items);
            var error = plan.Diagnostics.Single(d => d.Code == "MissingColumn");
            Assert.That(plan.IsValid, Is.False); Assert.That(error.Severity, Is.EqualTo(TableDiagnosticSeverity.Error)); Assert.That(error.Header, Is.EqualTo("id"));
        }

        [Test]
        public void SchemaValueErrorsReportTheSourceColumnAfterDroppedColumns()
        {
            var plan = Plan("\tpriceValue\tid\nx\tcheap\t7", Items);
            var error = plan.Diagnostics.Single(d => d.Code == "SchemaValue");
            Assert.That(error.Header, Is.EqualTo("priceValue")); Assert.That(error.Column, Is.EqualTo(2)); Assert.That(error.Row, Is.EqualTo(2));
        }

        [Test]
        public void ErrorsReportTheSourceRowAfterSkippedBlankRows()
        {
            // Rows 2 and 3 are blank and skipped; the bad value stays on source row 5.
            var plan = Plan("id\tpriceValue\n\t\n \t \n7\t100\n8\tcheap", Items);
            var error = plan.Diagnostics.Single(d => d.Code == "SchemaValue");
            Assert.That(error.Row, Is.EqualTo(5)); Assert.That(error.Column, Is.EqualTo(2));
        }

        [Test]
        public void RequireInt64FindsTheHeaderIgnoringCaseAndReportsTheSourceCell()
        {
            var view = Plan("\tID\tPriceValue\n\t\t\nx\t7\tcheap").ValidationInputs.Single();
            Assert.That(view.RequireInt64(0, " id "), Is.EqualTo(7));
            var failure = Assert.Throws<System.IO.InvalidDataException>(() => view.RequireInt64(0, "priceValue"));
            Assert.That(failure.Message, Does.Contain("row 3, column 3"));
        }

        [Test]
        public void PastedSheetWithTrailingEmptyColumnsAndRowsBuilds()
        {
            // A spreadsheet selection copied wider and taller than its data.
            string pasted = "id\tpriceValue\tgrade\t\t\r\n7\t100\t2\t\t\r\n8\t200\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n";
            var plan = Plan(pasted, Items);
            Assert.That(plan.IsValid, Is.True, Codes(plan));
            Assert.That(plan.Diagnostics.Count(d => d.Code == "BlankRecord"), Is.EqualTo(2));
            Assert.That(plan.Diagnostics.Count(d => d.Code == "UnnamedColumn"), Is.EqualTo(2));
            Assert.That(plan.Diagnostics.Where(d => d.Severity == TableDiagnosticSeverity.Error), Is.Empty);
            var rows = Runtime(plan);
            Assert.That(rows.Select(r => r.GetInt("id")), Is.EqualTo(new[] { 7, 8 }));
            Assert.That(rows[1].GetInt("grade", 5), Is.EqualTo(5));
        }

        [Test]
        public void PastedSheetAppliesAndLoadsThroughRuntimeRows()
        {
            var plan = Plan(" grade\tID\tpriceValue\t\n2\t7\t100\t\n", Items);
            Assert.That(plan.IsValid, Is.True, Codes(plan));
            TableBuilder.Prepare(plan).Apply();
            var row = TSVRow.FromTsv(File.ReadAllText(Output + "/items.txt")).Single();
            Assert.That(row.GetInt("id"), Is.EqualTo(7)); Assert.That(row.GetInt("grade"), Is.EqualTo(2)); Assert.That(row.GetLong("priceValue"), Is.EqualTo(100));
        }
    }
}
