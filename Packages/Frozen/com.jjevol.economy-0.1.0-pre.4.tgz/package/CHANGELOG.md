# Changelog

## 0.1.0-pre.4 - 2026-11-08

- Moved `DataRepository`, `DataContainer`, `RepositoryStorageAdapter` and `ContainerJson` to the new `com.jjevol.data` package. Class names and the `jjevol` namespace are unchanged; consumers add the `JJEvol.Data.Runtime` reference.
- `ResourceService` now publishes reservations through the repository overlay connection instead of the repository knowing the resource service.
- Local rewards require the wealth container to be saved locally.

Unity tests on Hosts/NetworkValidationHost passed: compile, the 124 non-parameterized Editor tests and the 2 PlayMode tests (job network-host-1, candidate 55f2b91), and the 160 parameterized `[TestCase]` Editor tests (job economy-param-1, candidate 68e3857).

## 0.1.0-pre.3 - 2026-11-06

- `ResourceService.Dispose` in recovery no longer hides the original save exception. An uncertain write now reports Dispose and reopen.
- Documented that `Sequence` is not an idempotency key. Reset profile ownership when Domain Reload is disabled.

Unity tests for this candidate are NOT_RUN.
