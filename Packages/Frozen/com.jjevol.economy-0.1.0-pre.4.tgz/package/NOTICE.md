# Provenance and distribution boundary

The user requested STEP 10 extraction from their existing mobile implementation into this local Framework candidate. Original code paths and hashes are recorded in `Docs/EconomyExtraction/TransferManifest.json` and the STEP 10 report. Central SourceOwnership confirmations are reused only within their stated scopes; this extraction request is not a blanket public redistribution license or proof of company/contract title.

No MIT or other public license has been assigned to the user's code. No CodeStage, SGuard implementation, Spine, MoreMountains, OSA, paid Vendor source, original game data or art is bundled. Unity Newtonsoft JSON, Save and Tables are declared dependencies rather than copied SDK source. Standalone marker/interface/converter units extracted from user utility files are identified separately from their surrounding SDK/UI integrations.

This is an unfrozen local validation candidate. Publishing, packaging for distribution and installing into existing games remain separate review steps.
