using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace PlatformLibrary.Tracking.Tests
{
    internal sealed class FakeTrackingHost : ITrackingHost
    {
        private sealed class Timer
        {
            public float Due;
            public Action Action;
        }

        private readonly List<Timer> _timers = new List<Timer>();
        private readonly Queue<Action> _held = new Queue<Action>();
        private float _now;
        public bool HoldPosts;
        public readonly List<Exception> Exceptions = new List<Exception>();
        public int PendingTimers => _timers.Count;

        public void Post(Action action)
        {
            if (HoldPosts) _held.Enqueue(action);
            else action();
        }

        public void RunHeldPosts()
        {
            HoldPosts = false;
            while (_held.Count > 0) _held.Dequeue()();
        }

        public Action Schedule(float seconds, Action action)
        {
            var timer = new Timer { Due = _now + seconds, Action = action };
            _timers.Add(timer);
            return () => _timers.Remove(timer);
        }

        public void Advance(float seconds)
        {
            _now += seconds;
            while (true)
            {
                Timer next = _timers.Where(timer => timer.Due <= _now).OrderBy(timer => timer.Due).FirstOrDefault();
                if (next == null) return;
                _timers.Remove(next);
                next.Action();
            }
        }

        public void LogException(Exception exception) => Exceptions.Add(exception);
    }

    internal sealed class FakeTrackingProvider : ITrackingConsentProvider
    {
        public TrackingConsentStatus Current = TrackingConsentStatus.NotDetermined;
        public Exception ThrowOnRequest;
        public readonly List<Action<TrackingConsentStatus>> Requests = new List<Action<TrackingConsentStatus>>();

        public TrackingConsentStatus Status => Current;

        public void Request(Action<TrackingConsentStatus> completed)
        {
            if (ThrowOnRequest != null) throw ThrowOnRequest;
            Requests.Add(completed);
        }

        public void Decide(TrackingConsentStatus status)
        {
            Current = status;
            Requests[Requests.Count - 1](status);
        }
    }

    public sealed class TrackingConsentManagerTests
    {
        private FakeTrackingHost _host;
        private FakeTrackingProvider _provider;
        private List<TrackingConsentStatus> _answers;

        [SetUp]
        public void SetUp()
        {
            TrackingConsentManager.ResetState();
            _host = new FakeTrackingHost();
            _provider = new FakeTrackingProvider();
            _answers = new List<TrackingConsentStatus>();
        }

        [TearDown]
        public void TearDown() => TrackingConsentManager.ResetState();

        private void UseProvider() => TrackingConsentManager.SetProvider(_provider, _host);

        [Test]
        public void WithoutAProviderTheStatusIsUnsupported()
        {
            Assert.That(TrackingConsentManager.Status, Is.EqualTo(TrackingConsentStatus.Unsupported));
            TrackingConsentManager.RequestIfNeeded(_answers.Add);
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Unsupported }));
        }

        [Test]
        public void ADecidedStatusAnswersWithoutAsking()
        {
            _provider.Current = TrackingConsentStatus.Denied;
            UseProvider();
            TrackingConsentManager.RequestIfNeeded(_answers.Add);

            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Denied }));
            Assert.That(_provider.Requests, Is.Empty);
        }

        [Test]
        public void AnUndecidedStatusAsksOnceAndAnswersTheDecision()
        {
            UseProvider();
            TrackingConsentManager.RequestIfNeeded(_answers.Add);
            Assert.That(TrackingConsentManager.IsRequesting, Is.True);
            Assert.That(_answers, Is.Empty);

            _provider.Decide(TrackingConsentStatus.Authorized);
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Authorized }));
            Assert.That(TrackingConsentManager.IsRequesting, Is.False);
        }

        [Test]
        public void CallsWhileThePromptIsOpenShareItsAnswer()
        {
            UseProvider();
            var second = new List<TrackingConsentStatus>();
            TrackingConsentManager.RequestIfNeeded(_answers.Add);
            TrackingConsentManager.RequestIfNeeded(second.Add);

            Assert.That(_provider.Requests, Has.Count.EqualTo(1), "The prompt is shown once.");
            _provider.Decide(TrackingConsentStatus.Denied);
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Denied }));
            Assert.That(second, Is.EqualTo(new[] { TrackingConsentStatus.Denied }));
        }

        [Test]
        public void ATimeLimitAnswersTheCurrentStatusAndTheLateDecisionIsNotRepeated()
        {
            UseProvider();
            TrackingConsentManager.RequestIfNeeded(_answers.Add, 60f);
            _host.Advance(59f);
            Assert.That(_answers, Is.Empty);

            _host.Advance(1f);
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.NotDetermined }));
            Assert.That(TrackingConsentManager.IsRequesting, Is.True, "The prompt stays open.");

            _provider.Decide(TrackingConsentStatus.Authorized);
            Assert.That(_answers, Has.Count.EqualTo(1));
            Assert.That(TrackingConsentManager.Status, Is.EqualTo(TrackingConsentStatus.Authorized));
        }

        [Test]
        public void ADecisionCancelsTheTimeLimit()
        {
            UseProvider();
            TrackingConsentManager.RequestIfNeeded(_answers.Add, 60f);
            _provider.Decide(TrackingConsentStatus.Authorized);
            Assert.That(_host.PendingTimers, Is.EqualTo(0));
        }

        [Test]
        public void AnAnswerFromAnotherThreadWaitsForTheMainThread()
        {
            UseProvider();
            _host.HoldPosts = true;
            TrackingConsentManager.RequestIfNeeded(_answers.Add);
            _provider.Decide(TrackingConsentStatus.Authorized);
            Assert.That(_answers, Is.Empty);

            _host.RunHeldPosts();
            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Authorized }));
        }

        [Test]
        public void AThrowingProviderAnswersTheCurrentStatus()
        {
            _provider.ThrowOnRequest = new InvalidOperationException("native failed");
            UseProvider();
            TrackingConsentManager.RequestIfNeeded(_answers.Add);

            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.NotDetermined }));
            Assert.That(_host.Exceptions, Has.Count.EqualTo(1));
            Assert.That(TrackingConsentManager.IsRequesting, Is.False);
        }

        [Test]
        public void ChangingTheProviderAnswersWaitingCallsWithTheNewStatus()
        {
            UseProvider();
            TrackingConsentManager.RequestIfNeeded(_answers.Add);
            TrackingConsentManager.SetProvider(null, null);

            Assert.That(_answers, Is.EqualTo(new[] { TrackingConsentStatus.Unsupported }));
            _provider.Decide(TrackingConsentStatus.Authorized);
            Assert.That(_answers, Has.Count.EqualTo(1), "The old provider's late answer is ignored.");
        }

        [Test]
        public void AThrowingCallbackIsLogged()
        {
            UseProvider();
            TrackingConsentManager.RequestIfNeeded(_ => throw new InvalidOperationException("game bug"));
            _provider.Decide(TrackingConsentStatus.Denied);
            Assert.That(_host.Exceptions, Has.Count.EqualTo(1));
        }

        [Test]
        public void TheTimeLimitMustBePositive()
        {
            UseProvider();
            Assert.Throws<ArgumentOutOfRangeException>(() => TrackingConsentManager.RequestIfNeeded(_answers.Add, 0f));
            Assert.Throws<ArgumentOutOfRangeException>(() => TrackingConsentManager.RequestIfNeeded(_answers.Add, -1f));
            Assert.Throws<ArgumentOutOfRangeException>(() => TrackingConsentManager.RequestIfNeeded(_answers.Add, float.NaN));
            Assert.That(_provider.Requests, Is.Empty);
        }
    }
}
