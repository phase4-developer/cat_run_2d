using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Tracking.Tests.Editor")]
