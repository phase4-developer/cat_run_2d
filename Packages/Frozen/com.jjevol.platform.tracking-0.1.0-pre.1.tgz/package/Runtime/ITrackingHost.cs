using System;

namespace PlatformLibrary.Tracking
{
    /// <summary>What <see cref="TrackingConsentManager"/> needs from Unity. Tests replace it to control time and threads.</summary>
    internal interface ITrackingHost
    {
        /// <summary>Runs on the main thread, immediately when already on it.</summary>
        void Post(Action action);

        /// <summary>Runs on the main thread after real time passes. The returned action cancels it.</summary>
        Action Schedule(float seconds, Action action);

        void LogException(Exception exception);
    }
}
