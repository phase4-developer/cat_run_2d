using System;
using System.Collections.Generic;
using UnityEngine;

namespace PlatformLibrary.Tracking
{
    /// <summary>
    /// The only tracking consent API a game uses. Call it from the Unity main thread; every callback runs once, on the
    /// main thread. With no provider set, the status is <see cref="TrackingConsentStatus.Unsupported"/>. When to ask,
    /// for example before starting an attribution SDK, belongs to the project.
    /// </summary>
    public static class TrackingConsentManager
    {
        private sealed class Waiter
        {
            public Action<TrackingConsentStatus> Callback;
            public Action CancelTimeout;
            public bool Done;
        }

        private static ITrackingConsentProvider _provider;
        private static ITrackingHost _host;
        private static List<Waiter> _waiting;
        private static int _request;

        /// <summary>The current answer. <see cref="TrackingConsentStatus.Unsupported"/> without a provider.</summary>
        public static TrackingConsentStatus Status => _provider == null ? TrackingConsentStatus.Unsupported : ProviderStatus(_provider, _host);

        /// <summary>The system prompt is open, or a request is waiting for it.</summary>
        public static bool IsRequesting => _waiting != null;

        /// <summary>Sets the provider, or removes it with null. Waiting calls answer with the new status.</summary>
        public static void SetProvider(ITrackingConsentProvider provider) => SetProvider(provider, provider == null ? null : UnityTrackingHost.Instance);

        /// <summary>
        /// Asks the player when the status is not determined, and answers the decided status. A decided or unsupported
        /// status answers at once without asking. Calls made while a prompt is open share its answer. After
        /// <paramref name="timeoutSeconds"/> the call answers with the status at that moment; the prompt itself stays.
        /// </summary>
        public static void RequestIfNeeded(Action<TrackingConsentStatus> callback, float timeoutSeconds = float.PositiveInfinity)
        {
            if (!(timeoutSeconds > 0f)) throw new ArgumentOutOfRangeException(nameof(timeoutSeconds), timeoutSeconds, "A positive time limit is required. Use infinity for none.");

            TrackingConsentStatus status = Status;
            if (status != TrackingConsentStatus.NotDetermined)
            {
                Reply(callback, status, _host);
                return;
            }

            ITrackingHost host = _host;
            var waiter = new Waiter { Callback = callback };
            if (!float.IsPositiveInfinity(timeoutSeconds))
                waiter.CancelTimeout = host.Schedule(timeoutSeconds, () => Answer(waiter, Status, host));

            if (_waiting != null)
            {
                _waiting.Add(waiter);
                return;
            }

            _waiting = new List<Waiter> { waiter };
            int request = ++_request;
            try
            {
                _provider.Request(answer => host.Post(() => Finish(request, answer, host)));
            }
            catch (Exception exception)
            {
                host.LogException(exception);
                Finish(request, Status, host);
            }
        }

        internal static void SetProvider(ITrackingConsentProvider provider, ITrackingHost host)
        {
            if (ReferenceEquals(_provider, provider) && ReferenceEquals(_host, host)) return;
            List<Waiter> waiting = _waiting;
            _waiting = null;
            _request++;
            _provider = provider;
            _host = host;
            if (waiting == null) return;
            foreach (Waiter waiter in waiting) Answer(waiter, Status, host);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        internal static void ResetState()
        {
            _provider = null;
            _host = null;
            _waiting = null;
            _request++;
        }

        private static void Finish(int request, TrackingConsentStatus status, ITrackingHost host)
        {
            if (request != _request || _waiting == null) return;
            List<Waiter> waiting = _waiting;
            _waiting = null;
            foreach (Waiter waiter in waiting) Answer(waiter, status, host);
        }

        private static void Answer(Waiter waiter, TrackingConsentStatus status, ITrackingHost host)
        {
            if (waiter.Done) return;
            waiter.Done = true;
            waiter.CancelTimeout?.Invoke();
            Reply(waiter.Callback, status, host);
        }

        private static TrackingConsentStatus ProviderStatus(ITrackingConsentProvider provider, ITrackingHost host)
        {
            try { return provider.Status; }
            catch (Exception exception)
            {
                Log(host, exception);
                return TrackingConsentStatus.Unsupported;
            }
        }

        private static void Reply(Action<TrackingConsentStatus> callback, TrackingConsentStatus status, ITrackingHost host)
        {
            if (callback == null) return;
            try { callback(status); }
            catch (Exception exception) { Log(host, exception); }
        }

        private static void Log(ITrackingHost host, Exception exception)
        {
            if (host != null) host.LogException(exception);
            else Debug.LogException(exception);
        }
    }
}
