using System;

namespace PlatformLibrary.Tracking
{
    /// <summary>One platform's tracking consent behind <see cref="TrackingConsentManager"/>.</summary>
    public interface ITrackingConsentProvider
    {
        TrackingConsentStatus Status { get; }

        /// <summary>
        /// Shows the system prompt if the status is not determined, and calls <paramref name="completed"/> once with
        /// the decided status, from any thread. The manager handles time limits and exceptions.
        /// </summary>
        void Request(Action<TrackingConsentStatus> completed);
    }
}
