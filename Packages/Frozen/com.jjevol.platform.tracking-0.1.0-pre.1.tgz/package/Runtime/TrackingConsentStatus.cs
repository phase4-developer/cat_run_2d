namespace PlatformLibrary.Tracking
{
    /// <summary>The player's answer about tracking across apps, such as Apple's App Tracking Transparency.</summary>
    public enum TrackingConsentStatus
    {
        /// <summary>Not asked yet, or the request is still open.</summary>
        NotDetermined,
        /// <summary>The device does not allow asking, for example parental controls.</summary>
        Restricted,
        Denied,
        Authorized,
        /// <summary>No provider, or the platform has no such consent.</summary>
        Unsupported
    }
}
