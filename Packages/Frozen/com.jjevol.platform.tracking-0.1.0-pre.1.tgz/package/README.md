# JJEvol Platform Tracking

Tracking consent, such as Apple App Tracking Transparency, behind one manager. The game or start-up code calls `TrackingConsentManager` only; the project picks the provider. With no provider the status is `Unsupported`.

Status: local validation candidate. An iOS Player and the real system prompt are NOT_RUN.

## Use

```csharp
using PlatformLibrary.Tracking;

#if UNITY_IOS
TrackingConsentManager.SetProvider(new PlatformLibrary.Tracking.Apple.AppleTrackingConsentProvider());
#endif

// For example, ask before starting an attribution SDK.
TrackingConsentManager.RequestIfNeeded(status =>
{
    AnalyticsManager.AddProvider(new AppsFlyerAnalyticsProvider(settings));
}, timeoutSeconds: 60f);
```

| API | Meaning |
|---|---|
| `SetProvider(provider)` | Sets or removes the provider. Waiting calls answer with the new status |
| `Status` | `NotDetermined`, `Restricted`, `Denied`, `Authorized` or `Unsupported` |
| `IsRequesting` | The system prompt is open, or a request waits for it |
| `RequestIfNeeded(callback, timeoutSeconds)` | Asks only when the status is not determined. The callback runs once, on the main thread |

- A decided or unsupported status answers at once without asking.
- Calls made while the prompt is open share its answer, so the prompt is shown once.
- After `timeoutSeconds` the call answers with the status at that moment, usually `NotDetermined`; the prompt itself stays. The default is no limit. The limit must be positive. A platform that silently ignores the request, such as iOS without its usage description, never answers without a limit, so pass one when start-up waits.

## Left to the project

When to ask, what to start after the answer, and the platform check in start-up code.
