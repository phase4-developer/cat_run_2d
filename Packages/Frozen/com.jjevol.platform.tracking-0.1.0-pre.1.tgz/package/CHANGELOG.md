# Changelog

## 0.1.0-pre.1 - 2026-11-08

- First candidate. `TrackingConsentManager` (`SetProvider`, `Status`, `IsRequesting`, `RequestIfNeeded` with a time limit), `ITrackingConsentProvider`, `TrackingConsentStatus`.

Unity tests for this candidate are recorded in Docs/PlatformReviewTracking/Report.md.
