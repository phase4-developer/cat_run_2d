using System;
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace jjevol.Tables.Tests
{
    public sealed class TableEncryptionTests
    {
        private static readonly byte[] Plain = Encoding.UTF8.GetBytes("id\tname\n1001001\t골드\n");

        [Test]
        public void RoundTripReturnsThePlainBytesAndTheTextCarriesTheMarker()
        {
            byte[] key = TableEncryption.NewKey();
            byte[] encrypted = TableEncryption.Encrypt(key, Plain);
            Assert.That(TableEncryption.Decrypt(key, encrypted), Is.EqualTo(Plain));
            string text = Convert.ToBase64String(encrypted);
            Assert.That(TableEncryption.IsEncryptedText(text), Is.True);
            Assert.That(TableEncryption.IsEncryptedText("﻿" + text), Is.True);
            Assert.That(TableEncryption.IsEncryptedText("id\tname\n1\ta"), Is.False);
            Assert.That(TableEncryption.IsEncryptedText(""), Is.False);
            Assert.That(TableEncryption.IsEncryptedText(null), Is.False);
        }

        [Test]
        public void EachEncryptionUsesAFreshIv()
        {
            byte[] key = TableEncryption.NewKey();
            Assert.That(TableEncryption.Encrypt(key, Plain), Is.Not.EqualTo(TableEncryption.Encrypt(key, Plain)));
        }

        [Test]
        public void WrongKeyOrChangedBytesAreRejected()
        {
            byte[] key = TableEncryption.NewKey();
            byte[] encrypted = TableEncryption.Encrypt(key, Plain);
            Assert.Throws<InvalidDataException>(() => TableEncryption.Decrypt(TableEncryption.NewKey(), encrypted));
            byte[] changed = (byte[])encrypted.Clone(); changed[changed.Length / 2] ^= 1;
            Assert.Throws<InvalidDataException>(() => TableEncryption.Decrypt(key, changed));
            Assert.Throws<InvalidDataException>(() => TableEncryption.Decrypt(key, Plain));
            Assert.Throws<ArgumentException>(() => TableEncryption.Encrypt(new byte[16], Plain));
        }

        [Test]
        public void KeyIdIsStableAndDiffersBetweenKeys()
        {
            byte[] key = TableEncryption.NewKey();
            Assert.That(TableEncryption.KeyId(key), Is.EqualTo(TableEncryption.KeyId(key.ToArray())));
            Assert.That(TableEncryption.KeyId(key), Has.Length.EqualTo(8));
            Assert.That(TableEncryption.KeyId(key), Is.Not.EqualTo(TableEncryption.KeyId(TableEncryption.NewKey())));
        }
    }
}
