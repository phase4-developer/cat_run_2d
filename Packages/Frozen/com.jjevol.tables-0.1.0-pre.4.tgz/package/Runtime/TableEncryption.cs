using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// Built-in table encryption that the Table Builder turns on from its project settings.
    /// AES-256-CBC with an HMAC-SHA256 check. The output text is Base64 of
    /// <c>"JJTBL1" + IV(16) + cipher + HMAC(32)</c>, so it always starts with <see cref="TextMarker"/>.
    /// Loading recognizes that marker by itself: game boot code does not have to pass <c>useEncrypt</c>
    /// or register <see cref="TableRuntimeOptions.DecryptBytes"/> for these tables.
    /// The key ships inside the build, so this keeps tables from being read casually; it is not secret storage.
    /// </summary>
    public static class TableEncryption
    {
        /// <summary>Resources name of the raw 32-byte key the Table Builder writes next to the table outputs.</summary>
        public const string KeyResourceName = "JJEvolTableKey";
        public const int KeyLength = 32;
        /// <summary>Base64 of the "JJTBL1" header. Every built-in encrypted table text starts with it.</summary>
        public const string TextMarker = "SkpUQkwx";

        private static readonly byte[] Magic = Encoding.ASCII.GetBytes("JJTBL1");
        private const int IvLength = 16, MacLength = 32;
        private static byte[] s_resourceKey;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState() => s_resourceKey = null;

        /// <summary>Drops the cached Resources key, so the next load reads the key file again (the Table Builder calls it after writing a new key).</summary>
        public static void ForgetLoadedKey() => s_resourceKey = null;

        /// <summary>True when <paramref name="tableText"/> was written by the built-in encryption (a leading BOM is ignored).</summary>
        public static bool IsEncryptedText(string tableText)
        {
            if (string.IsNullOrEmpty(tableText)) return false;
            int start = tableText[0] == '﻿' ? 1 : 0;
            return string.CompareOrdinal(tableText, start, TextMarker, 0, TextMarker.Length) == 0;
        }

        public static byte[] NewKey()
        {
            var key = new byte[KeyLength];
            using (var random = RandomNumberGenerator.Create()) random.GetBytes(key);
            return key;
        }

        /// <summary>Short nonsecret identity of a key, used to tell builds made with different keys apart.</summary>
        public static string KeyId(byte[] key)
        {
            CheckKey(key);
            using var sha = SHA256.Create();
            return string.Concat(sha.ComputeHash(key).Take(4).Select(b => b.ToString("x2")));
        }

        public static byte[] Encrypt(byte[] key, byte[] plain)
        {
            CheckKey(key);
            if (plain == null) throw new ArgumentNullException(nameof(plain));
            Derive(key, out byte[] encryptionKey, out byte[] macKey);
            var iv = new byte[IvLength];
            using (var random = RandomNumberGenerator.Create()) random.GetBytes(iv);
            byte[] cipher;
            using (var aes = NewAes(encryptionKey, iv))
            using (var encryptor = aes.CreateEncryptor())
                cipher = encryptor.TransformFinalBlock(plain, 0, plain.Length);
            var result = new byte[Magic.Length + IvLength + cipher.Length + MacLength];
            Buffer.BlockCopy(Magic, 0, result, 0, Magic.Length);
            Buffer.BlockCopy(iv, 0, result, Magic.Length, IvLength);
            Buffer.BlockCopy(cipher, 0, result, Magic.Length + IvLength, cipher.Length);
            byte[] mac = Mac(macKey, result, result.Length - MacLength);
            Buffer.BlockCopy(mac, 0, result, result.Length - MacLength, MacLength);
            return result;
        }

        public static byte[] Decrypt(byte[] key, byte[] data)
        {
            CheckKey(key);
            if (data == null || data.Length < Magic.Length + IvLength + 16 + MacLength || !Magic.SequenceEqual(data.Take(Magic.Length)))
                throw new InvalidDataException("Not a built-in encrypted table.");
            Derive(key, out byte[] encryptionKey, out byte[] macKey);
            int body = data.Length - MacLength;
            byte[] expected = Mac(macKey, data, body);
            int difference = 0;
            for (int i = 0; i < MacLength; i++) difference |= expected[i] ^ data[body + i];
            if (difference != 0) throw new InvalidDataException("Table key does not match, or the table file is damaged.");
            var iv = new byte[IvLength];
            Buffer.BlockCopy(data, Magic.Length, iv, 0, IvLength);
            int offset = Magic.Length + IvLength;
            using var aes = NewAes(encryptionKey, iv);
            using var decryptor = aes.CreateDecryptor();
            return decryptor.TransformFinalBlock(data, offset, body - offset);
        }

        /// <summary>Decrypts a built-in encrypted table text with the key shipped in Resources.</summary>
        public static string DecryptText(string tableText)
        {
            if (!IsEncryptedText(tableText)) throw new InvalidDataException("Not a built-in encrypted table.");
            string base64 = tableText[0] == '﻿' ? tableText.Substring(1) : tableText;
            return Encoding.UTF8.GetString(Decrypt(ResourceKey(), Convert.FromBase64String(base64.Trim())));
        }

        private static byte[] ResourceKey()
        {
            if (s_resourceKey != null) return s_resourceKey;
            var asset = Resources.Load<TextAsset>(KeyResourceName);
            byte[] key = asset != null ? asset.bytes : null;
            if (key == null || key.Length != KeyLength)
                throw new InvalidOperationException("Table key '" + KeyResourceName + "' is missing from Resources. Save the Table Builder project settings with encryption on to write it.");
            return s_resourceKey = key;
        }

        private static void CheckKey(byte[] key)
        {
            if (key == null || key.Length != KeyLength) throw new ArgumentException("A 32-byte table key is required.", nameof(key));
        }

        private static void Derive(byte[] key, out byte[] encryptionKey, out byte[] macKey)
        {
            using var hmac = new HMACSHA256(key);
            encryptionKey = hmac.ComputeHash(Encoding.ASCII.GetBytes("jjevol.tables.aes"));
            macKey = hmac.ComputeHash(Encoding.ASCII.GetBytes("jjevol.tables.mac"));
        }

        private static byte[] Mac(byte[] macKey, byte[] data, int count)
        {
            using var hmac = new HMACSHA256(macKey);
            return hmac.ComputeHash(data, 0, count);
        }

        private static Aes NewAes(byte[] key, byte[] iv)
        {
            var aes = Aes.Create();
            aes.KeySize = 256; aes.BlockSize = 128; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
            aes.Key = key; aes.IV = iv;
            return aes;
        }
    }
}
