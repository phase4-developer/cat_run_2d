using System;
using System.Globalization;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// Game-wide display settings shared by every UI package of both UI systems: number culture, language, number
    /// profiles, the trusted clock and the locale change notice. uGUI (com.jjevol.ui, ui.widgets, ui.economy) and
    /// UI Toolkit (uitoolkit.economy, uitoolkit.widgets) labels all read this one place, so a game sets it once at boot:
    /// <code>
    /// UIDisplayOptions.Culture = () => LocalizationSettings.SelectedLocale?.Identifier.CultureInfo;
    /// UIDisplayOptions.NumberFormat = numberFormatSettings;
    /// LocalizationSettings.SelectedLocaleChanged += _ => UIDisplayOptions.NotifyLocaleChanged();
    /// </code>
    /// </summary>
    public static class UIDisplayOptions
    {
        /// <summary>Culture for digits, separators and dates. Null uses CultureInfo.CurrentCulture.</summary>
        public static Func<CultureInfo> Culture { get; set; }
        /// <summary>Language used to pick a number profile. Null uses <see cref="DisplayCulture"/>.Name.</summary>
        public static Func<string> Language { get; set; }
        /// <summary>Game-wide number profiles. Null shows every digit (N0). Call <see cref="NotifyLocaleChanged"/> after changing it at runtime.</summary>
        public static NumberFormatSettings NumberFormat { get; set; }
        /// <summary>The trusted clock for countdown end times (server time). Null uses DateTime.UtcNow.</summary>
        public static Func<DateTime> UtcNow { get; set; }

        public static CultureInfo DisplayCulture => Culture?.Invoke() ?? CultureInfo.CurrentCulture;
        public static string CurrentLanguage => Language?.Invoke() ?? DisplayCulture.Name;
        public static NumberFormatProfile CurrentNumberFormat => NumberFormat?.Resolve(CurrentLanguage) ?? NumberFormatProfile.Full;
        public static DateTime Now => UtcNow?.Invoke() ?? DateTime.UtcNow;

        /// <summary>Writes a number. An element's own profile wins over the game-wide one.</summary>
        public static string FormatNumber(decimal value, NumberFormatProfile elementProfile = null) =>
            global::jjevol.NumberFormat.Format(value, elementProfile ?? CurrentNumberFormat, DisplayCulture);

        /// <summary>
        /// The profile a label with abbreviate on uses: its own or the game-wide one when that already abbreviates,
        /// otherwise the abbreviated profile for <see cref="CurrentLanguage"/>.
        /// </summary>
        public static NumberFormatProfile AbbreviatedNumberFormat(NumberFormatProfile elementProfile = null)
        {
            NumberFormatProfile profile = elementProfile ?? CurrentNumberFormat;
            return profile.Notation == NumberNotation.Abbreviated ? profile : NumberFormatProfile.CreateAbbreviatedFor(CurrentLanguage);
        }

        /// <summary>Raised by <see cref="NotifyLocaleChanged"/>; labels already shown redraw.</summary>
        public static event Action LocaleChanged;
        /// <summary>The game calls this when its locale or one of these settings changes at runtime.</summary>
        public static void NotifyLocaleChanged() => LocaleChanged?.Invoke();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetState()
        {
            Culture = null; Language = null; NumberFormat = null; UtcNow = null; LocaleChanged = null;
        }
    }
}
