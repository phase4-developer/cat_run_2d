using System;

namespace jjevol
{
    public enum ImpulseKind
    {
        // A decaying back-and-forth on one axis, for scale pops (DOPunchScale).
        Punch,
        // A decaying random offset on two axes, for hits (DOShakeAnchorPos).
        Shake
    }

    /// <summary>
    /// A short decaying motion. The view multiplies <see cref="X"/> and <see cref="Y"/> by its own unit
    /// (scale or pixels). Shake is deterministic for one seed, so tests can compare values.
    /// </summary>
    public sealed class Impulse
    {
        private float _duration, _elapsed, _strength;
        private int _vibrato;
        private ImpulseKind _kind;
        private uint _seed = 1;

        public float X { get; private set; }
        public float Y { get; private set; }
        public bool IsPlaying { get; private set; }

        /// <param name="strength">Peak amount in the view's unit.</param>
        /// <param name="vibrato">Swings over the whole duration. At least 1.</param>
        public void Play(ImpulseKind kind, float strength, float duration, int vibrato = 8, int seed = 1)
        {
            _kind = kind; _strength = strength; _duration = Math.Max(0.0001f, duration); _vibrato = Math.Max(1, vibrato);
            _seed = (uint)(seed == 0 ? 1 : seed); _elapsed = 0f; IsPlaying = true; X = 0f; Y = 0f;
        }

        public void Stop() { IsPlaying = false; X = 0f; Y = 0f; }

        public bool Tick(float deltaTime)
        {
            if (!IsPlaying) return false;
            if (deltaTime < 0f || float.IsNaN(deltaTime)) deltaTime = 0f;
            _elapsed += deltaTime;
            if (_elapsed >= _duration) { Stop(); return true; }

            float t = _elapsed / _duration;
            float decay = 1f - t;
            if (_kind == ImpulseKind.Punch)
            {
                // First swing goes toward +strength, like DOPunchScale with a positive punch.
                X = (float)Math.Sin(t * _vibrato * Math.PI) * _strength * decay;
                Y = X;
            }
            else
            {
                int step = (int)(t * _vibrato);
                double angle = Noise(_seed, step) * Math.PI * 2;
                X = (float)Math.Cos(angle) * _strength * decay;
                Y = (float)Math.Sin(angle) * _strength * decay;
            }
            return true;
        }

        // 0..1 from a seed and a step, the same on every platform.
        private static double Noise(uint seed, int step)
        {
            uint h = seed * 747796405u + (uint)step * 2891336453u;
            h ^= h >> 16; h *= 2246822519u; h ^= h >> 13; h *= 3266489917u; h ^= h >> 16;
            return h / (double)uint.MaxValue;
        }
    }

    /// <summary>A looping 0..1..0 wave for attention effects such as a pulsing button.</summary>
    public static class Oscillation
    {
        /// <summary>0 at time 0, 1 at half a period, back to 0 at a full period. A period of 0 or less returns 0.</summary>
        public static float Pulse(float time, float period)
        {
            if (period <= 0f || float.IsNaN(time)) return 0f;
            double phase = time / period % 1.0;
            if (phase < 0) phase += 1.0;
            return (float)(0.5 - 0.5 * Math.Cos(phase * Math.PI * 2));
        }
    }
}
