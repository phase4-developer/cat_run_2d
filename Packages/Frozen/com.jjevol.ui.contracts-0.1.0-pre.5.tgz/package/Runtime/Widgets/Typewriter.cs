using System;
using System.Text;

namespace jjevol
{
    /// <summary>
    /// Reveal progress of typewriter text, without any view. Counts visible characters only; rich text tags
    /// such as &lt;b&gt; or &lt;color=#f00&gt; are not counted and never cut in half (see <see cref="RichText"/>).
    /// </summary>
    public sealed class Typewriter
    {
        private float _budget;
        private int _total;

        /// <summary>Characters per second. 0 or less shows everything at once.</summary>
        public float CharactersPerSecond { get; set; } = 30f;
        /// <summary>Extra seconds after these characters, for a natural pause at the end of a sentence.</summary>
        public string PauseCharacters { get; set; } = ".!?,…。！？、";
        public float PauseSeconds { get; set; } = 0.12f;

        public string Text { get; private set; } = string.Empty;
        public string PlainText { get; private set; } = string.Empty;
        public int Visible { get; private set; }
        public int Total => _total;
        public bool IsPlaying => Visible < _total;
        public event Action Completed;

        public void Start(string text)
        {
            Text = text ?? string.Empty;
            PlainText = RichText.Strip(Text);
            _total = PlainText.Length;
            Visible = 0; _budget = 0f;
            if (CharactersPerSecond <= 0f || _total == 0) Complete();
        }

        public void Complete()
        {
            bool was = Visible < _total || _total == 0;
            Visible = _total;
            if (was) Completed?.Invoke();
        }

        /// <summary>Advances the reveal. Returns true when more characters became visible.</summary>
        public bool Tick(float deltaTime)
        {
            if (!IsPlaying) return false;
            if (deltaTime < 0f || float.IsNaN(deltaTime)) deltaTime = 0f;
            _budget += deltaTime;
            int before = Visible;
            float perChar = 1f / CharactersPerSecond;
            while (Visible < _total)
            {
                float cost = perChar;
                if (Visible > 0 && PauseCharacters != null && PauseCharacters.IndexOf(PlainText[Visible - 1]) >= 0) cost += Math.Max(0f, PauseSeconds);
                if (_budget < cost) break;
                _budget -= cost;
                Visible++;
            }
            if (Visible >= _total && before < _total) Completed?.Invoke();
            return Visible != before;
        }
    }

    /// <summary>Helpers for text with rich text tags in angle brackets, shared by TextMeshPro and UI Toolkit labels.</summary>
    public static class RichText
    {
        /// <summary>The text without tags. A '&lt;' that does not start a tag is kept.</summary>
        public static string Strip(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            var plain = new StringBuilder(text.Length);
            for (int i = 0; i < text.Length; i++)
            {
                int end = TagEnd(text, i);
                if (end >= 0) { i = end; continue; }
                plain.Append(text[i]);
            }
            return plain.ToString();
        }

        /// <summary>
        /// The first <paramref name="visible"/> characters of the text with every tag before the cut kept, so styles
        /// stay correct. Open tags are left open; TextMeshPro and UI Toolkit close them at the end.
        /// </summary>
        public static string Cut(string text, int visible)
        {
            if (string.IsNullOrEmpty(text) || visible <= 0) return KeepTags(text, 0);
            var result = new StringBuilder(text.Length);
            int shown = 0;
            for (int i = 0; i < text.Length; i++)
            {
                int end = TagEnd(text, i);
                if (end >= 0) { result.Append(text, i, end - i + 1); i = end; continue; }
                if (shown >= visible) break;
                result.Append(text[i]);
                shown++;
            }
            return result.ToString();
        }

        private static string KeepTags(string text, int start)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            var result = new StringBuilder();
            for (int i = start; i < text.Length; i++)
            {
                int end = TagEnd(text, i);
                if (end < 0) break;
                result.Append(text, i, end - i + 1); i = end;
            }
            return result.ToString();
        }

        // Index of the '>' closing a tag that starts at i, or -1. A tag has no spaces right after '<' and no '<' inside.
        private static int TagEnd(string text, int i)
        {
            if (text[i] != '<' || i + 1 >= text.Length) return -1;
            char first = text[i + 1];
            if (!(char.IsLetter(first) || first == '/' || first == '#')) return -1;
            for (int j = i + 1; j < text.Length; j++)
            {
                if (text[j] == '>') return j;
                if (text[j] == '<' || text[j] == '\n') return -1;
            }
            return -1;
        }
    }
}
