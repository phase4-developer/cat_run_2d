using System;
using System.Collections.Generic;

namespace jjevol
{
    /// <summary>Timing of an animated gauge. Serializable so a gauge keeps its own values in the Inspector.</summary>
    [Serializable]
    public sealed class GaugeTiming
    {
        [UnityEngine.Tooltip("Seconds the trail waits at the old value after a decrease.")]
        public float decreaseDelay = 0.15f;
        [UnityEngine.Tooltip("Seconds the trail takes to drain to the new value.")]
        public float decreaseDuration = 0.35f;
        public Ease decreaseEase = Ease.OutCubic;
        [UnityEngine.Tooltip("Scale delay and drain time by how large the decrease is, between the min and max values below.")]
        public bool scaleByAmount = true;
        public float minDecreaseDelay = 0.08f;
        public float maxDecreaseDelay = 0.35f;
        public float minDecreaseDuration = 0.18f;
        public float maxDecreaseDuration = 0.5f;
        [UnityEngine.Tooltip("A decrease of at least this much (0..1 of the gauge) is heavy: longest timing and the strong impact.")]
        [UnityEngine.Range(0f, 1f)] public float heavyThreshold = 0.18f;

        [UnityEngine.Tooltip("Fill grows to the new value over time. Off jumps at once and only the lead bar shows the gain.")]
        public bool animateIncrease = true;
        public float increaseDuration = 0.25f;
        public Ease increaseEase = Ease.OutCubic;
        [UnityEngine.Tooltip("Seconds each full lap takes when a gauge fills past the end, such as an experience bar gaining levels.")]
        public float lapDuration = 0.3f;

        [UnityEngine.Tooltip("Seconds the trail and lead bars take to fade out after they finish.")]
        public float ghostFadeDuration = 0.18f;

        public GaugeTiming Copy() => (GaugeTiming)MemberwiseClone();
    }

    /// <summary>
    /// The state of an animated gauge (health, experience, progress) without any view. Values are 0..1 of the gauge.
    /// <list type="bullet">
    /// <item><see cref="Fill"/> is the real value.</item>
    /// <item><see cref="Trail"/> stays behind a decrease and drains after a delay (damage ghost).</item>
    /// <item><see cref="Lead"/> jumps ahead of an increase while the fill catches up (heal ghost).</item>
    /// </list>
    /// A view draws the three bars and applies <see cref="TrailAlpha"/> and <see cref="LeadAlpha"/>.
    /// </summary>
    public sealed class GaugeModel
    {
        private readonly FloatTween _fill = new FloatTween();
        private readonly FloatTween _trail = new FloatTween();
        private readonly FloatTween _trailAlpha = new FloatTween();
        private readonly FloatTween _leadAlpha = new FloatTween();
        private readonly Queue<float> _segments = new Queue<float>();
        private GaugeTiming _timing;
        private float _target;
        private float _lead;
        private int _pendingLaps;

        public GaugeModel(GaugeTiming timing = null, float value = 1f)
        {
            _timing = timing ?? new GaugeTiming();
            SetInstant(value);
        }

        public GaugeTiming Timing
        {
            get => _timing;
            set => _timing = value ?? new GaugeTiming();
        }

        public float Fill => _fill.Value;
        public float Trail => _trail.Value;
        public float Lead => _lead;
        public float TrailAlpha => _trailAlpha.Value;
        public float LeadAlpha => _leadAlpha.Value;
        /// <summary>The value the gauge is moving to.</summary>
        public float Target => _target;
        public bool IsAnimating => _fill.IsPlaying || _trail.IsPlaying || _trailAlpha.IsPlaying || _leadAlpha.IsPlaying || _segments.Count > 0;

        /// <summary>A decrease happened: its size (0..1) and whether it reached <see cref="GaugeTiming.heavyThreshold"/>.</summary>
        public event Action<float, bool> Decreased;
        /// <summary>An increase happened: its size (0..1, laps not included).</summary>
        public event Action<float> Increased;
        /// <summary>The fill passed the end during <see cref="AnimateTo(float, int)"/> with laps.</summary>
        public event Action LapCompleted;

        /// <summary>Shows <paramref name="value"/> at once with no trail or lead, for first display and reuse.</summary>
        public void SetInstant(float value)
        {
            value = Clamp01(value);
            _segments.Clear();
            _pendingLaps = 0;
            _target = value; _lead = value;
            _fill.Set(value); _trail.Set(value); _trailAlpha.Set(0f); _leadAlpha.Set(0f);
        }

        public void AnimateTo(float value) => AnimateTo(value, 0);

        /// <summary>
        /// Moves to <paramref name="value"/>. <paramref name="laps"/> greater than 0 fills to the end that many times first,
        /// wrapping to 0 each time (an experience bar gaining levels). Laps only apply to increases.
        /// </summary>
        public void AnimateTo(float value, int laps)
        {
            value = Clamp01(value);
            laps = Math.Max(0, laps);
            if (laps == 0 && Math.Abs(value - _target) < 0.0001f && _segments.Count == 0) return;

            // Compared with the shown fill, so a lower target during a running increase still grows from the fill.
            if (laps == 0 && value < Fill) { Decrease(value); return; }

            // Finish any trail at once; an increase covers it.
            _trail.Set(Fill); _trailAlpha.Set(0f);
            _segments.Clear();
            for (int i = 0; i < laps; i++) _segments.Enqueue(1f);
            _segments.Enqueue(value);
            float gained = laps > 0 ? (1f - Fill) + (laps - 1) + value : value - Fill;
            _target = value;
            NextSegment();
            // Events go last so a handler that sets the gauge again (a level-up handler) sees a settled state.
            Increased?.Invoke(Math.Max(0f, Math.Min(1f, gained)));
            RaiseLaps();
        }

        /// <summary>Ends every motion at its final state.</summary>
        public void Complete() => SetInstant(_target);

        public bool Tick(float deltaTime)
        {
            bool changed = false;
            changed |= _trailAlpha.Tick(deltaTime);
            changed |= _leadAlpha.Tick(deltaTime);
            if (_trail.Tick(deltaTime))
            {
                changed = true;
                if (!_trail.IsPlaying) _trailAlpha.Play(TrailAlpha, 0f, _timing.ghostFadeDuration, Ease.OutQuad);
            }
            if (_fill.Tick(deltaTime))
            {
                changed = true;
                if (!_fill.IsPlaying && FinishSegment()) NextSegment();
                RaiseLaps();
            }
            return changed;
        }

        private void Decrease(float value)
        {
            _segments.Clear();
            _pendingLaps = 0;
            float before = Fill;
            float delta = before - value;
            bool heavy = delta >= _timing.heavyThreshold;

            // Hide the lead of an increase that was still running.
            _lead = value; _leadAlpha.Set(0f);
            // A trail already draining keeps its higher value so repeated hits read as one long drain.
            float trailStart = Math.Max(_trail.IsPlaying || TrailAlpha > 0f ? Trail : before, before);
            _target = value;
            _fill.Set(value);

            float delay = _timing.decreaseDelay, duration = _timing.decreaseDuration;
            if (_timing.scaleByAmount)
            {
                float rate = _timing.heavyThreshold <= 0f ? 1f : Clamp01(delta / _timing.heavyThreshold);
                delay = Lerp(_timing.minDecreaseDelay, _timing.maxDecreaseDelay, rate);
                duration = Lerp(_timing.minDecreaseDuration, _timing.maxDecreaseDuration, rate);
            }
            _trail.Play(trailStart, value, Math.Max(0.0001f, duration), _timing.decreaseEase, Math.Max(0f, delay));
            _trailAlpha.Set(1f);
            Decreased?.Invoke(delta, heavy);
        }

        // Starts the segment at the head of the queue. Instant segments are finished in this loop, not by recursion,
        // so many laps with no lap time do not grow the stack.
        private void NextSegment()
        {
            while (_segments.Count > 0)
            {
                float next = _segments.Peek();
                bool lap = _segments.Count > 1;
                _lead = next; _leadAlpha.Set(1f);
                float duration = lap ? _timing.lapDuration : _timing.increaseDuration;
                bool instant = (!_timing.animateIncrease && !lap) || duration <= 0f;
                if (!instant)
                {
                    _fill.Play(Fill, next, duration, lap ? Ease.Linear : _timing.increaseEase);
                    return;
                }
                _fill.Set(next);
                if (!FinishSegment()) return;
            }
        }

        // The head segment reached its end. Returns true when another segment follows (the fill wrapped to 0).
        private bool FinishSegment()
        {
            if (_segments.Count == 0) return false;
            _segments.Dequeue();
            if (_segments.Count > 0)
            {
                _fill.Set(0f); _trail.Set(0f);
                _pendingLaps++;
                return true;
            }
            _trail.Set(Fill);
            _leadAlpha.Play(LeadAlpha, 0f, _timing.ghostFadeDuration, Ease.OutQuad);
            return false;
        }

        // Raised after the state is settled. A handler calling SetInstant clears the rest.
        private void RaiseLaps()
        {
            while (_pendingLaps > 0)
            {
                _pendingLaps--;
                LapCompleted?.Invoke();
            }
        }

        private static float Clamp01(float value) => float.IsNaN(value) ? 0f : Math.Max(0f, Math.Min(1f, value));
        private static float Lerp(float a, float b, float t) => a + (b - a) * t;
    }
}
