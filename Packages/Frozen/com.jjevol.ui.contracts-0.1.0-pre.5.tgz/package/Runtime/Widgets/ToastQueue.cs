using System;
using System.Collections.Generic;

namespace jjevol
{
    /// <summary>One toast to show. The view decides how <see cref="Icon"/> is loaded (for example as an Addressables key).</summary>
    public sealed class ToastRequest
    {
        public ToastRequest(string message) { Message = message ?? string.Empty; }

        public string Message { get; set; }
        public string Icon { get; set; }
        /// <summary>Seconds on screen. 0 or less uses <see cref="ToastQueue.DefaultDuration"/>.</summary>
        public float Duration { get; set; }
        /// <summary>Higher shows first among waiting toasts. Toasts already on screen are not pushed out.</summary>
        public int Priority { get; set; }
        /// <summary>Toasts with the same key are merged: the count goes up and the timer restarts. Null never merges.</summary>
        public string MergeKey { get; set; }
        /// <summary>A style name the view may use, for example "warning" for a USS modifier class or a prefab variant.</summary>
        public string Style { get; set; }
        /// <summary>Game data the view may read.</summary>
        public object Payload { get; set; }
    }

    /// <summary>A toast in the queue or on screen.</summary>
    public sealed class Toast
    {
        internal Toast(int id, ToastRequest request, long order) { Id = id; Request = request; Order = order; Count = 1; }

        public int Id { get; }
        public ToastRequest Request { get; internal set; }
        /// <summary>How many requests were merged into this toast. 1 for a single request.</summary>
        public int Count { get; internal set; }
        /// <summary>Seconds left before it starts leaving.</summary>
        public float Remaining { get; internal set; }
        public bool IsVisible { get; internal set; }
        /// <summary>True from the moment it starts leaving until it is removed.</summary>
        public bool IsLeaving { get; internal set; }
        internal long Order { get; }
        internal float LeaveElapsed { get; set; }
    }

    /// <summary>
    /// Queue, merge and timing of toast messages without any view. The view listens to the events: it shows a toast on
    /// <see cref="Shown"/>, redraws on <see cref="Updated"/>, plays its exit on <see cref="Leaving"/> and returns the
    /// item to its pool on <see cref="Removed"/>.
    /// </summary>
    public sealed class ToastQueue
    {
        private readonly List<Toast> _visible = new List<Toast>();
        private readonly List<Toast> _pending = new List<Toast>();
        private int _nextId = 1;
        private long _nextOrder;
        private int _maxVisible = 3;

        public int MaxVisible { get => _maxVisible; set => _maxVisible = Math.Max(1, value); }
        public float DefaultDuration { get; set; } = 2f;
        /// <summary>Seconds a toast stays after <see cref="Leaving"/> so the view can play its exit.</summary>
        public float LeaveDuration { get; set; } = 0.25f;
        /// <summary>Waiting toasts kept at most. A new toast past this replaces the oldest lowest-priority one, or is dropped if it is lower. 0 or less means no limit.</summary>
        public int MaxPending { get; set; } = 20;

        /// <summary>Toasts on screen, oldest first, including ones that are leaving.</summary>
        public IReadOnlyList<Toast> Visible => _visible;
        public int PendingCount => _pending.Count;

        public event Action<Toast> Shown;
        public event Action<Toast> Updated;
        public event Action<Toast> Leaving;
        public event Action<Toast> Removed;
        /// <summary>A waiting toast was dropped because <see cref="MaxPending"/> was reached.</summary>
        public event Action<Toast> Dropped;

        /// <summary>Adds a toast. Returns the toast it shows in (a merged one or a new one), or null when it was dropped.</summary>
        public Toast Enqueue(ToastRequest request)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));

            if (request.MergeKey != null)
            {
                foreach (Toast toast in _visible)
                {
                    if (toast.IsLeaving || toast.Request.MergeKey != request.MergeKey) continue;
                    toast.Request = request; toast.Count++; toast.Remaining = DurationOf(request);
                    Updated?.Invoke(toast);
                    return toast;
                }
                foreach (Toast toast in _pending)
                {
                    if (toast.Request.MergeKey != request.MergeKey) continue;
                    toast.Request = request; toast.Count++;
                    return toast;
                }
            }

            var added = new Toast(_nextId++, request, _nextOrder++);
            if (MaxPending > 0 && _pending.Count >= MaxPending)
            {
                Toast lowest = LowestPending();
                if (lowest.Request.Priority > request.Priority) { Dropped?.Invoke(added); return null; }
                _pending.Remove(lowest);
                Dropped?.Invoke(lowest);
            }
            _pending.Add(added);
            Fill();
            return added;
        }

        /// <summary>Starts the exit of a toast on screen, or removes a waiting one.</summary>
        public void Dismiss(Toast toast)
        {
            if (toast == null) return;
            if (_pending.Remove(toast)) return;
            if (toast.IsVisible && !toast.IsLeaving) StartLeaving(toast);
            Fill();
        }

        /// <summary>Removes every waiting toast and starts the exit of every toast on screen.</summary>
        public void Clear()
        {
            _pending.Clear();
            foreach (Toast toast in _visible.ToArray()) if (!toast.IsLeaving) StartLeaving(toast);
        }

        public void Tick(float deltaTime)
        {
            if (deltaTime < 0f || float.IsNaN(deltaTime)) deltaTime = 0f;
            foreach (Toast toast in _visible.ToArray())
            {
                if (toast.IsLeaving)
                {
                    toast.LeaveElapsed += deltaTime;
                    if (toast.LeaveElapsed >= LeaveDuration) Remove(toast);
                    continue;
                }
                toast.Remaining -= deltaTime;
                if (toast.Remaining <= 0f) StartLeaving(toast);
            }
            Fill();
        }

        private void StartLeaving(Toast toast)
        {
            toast.IsLeaving = true; toast.Remaining = 0f; toast.LeaveElapsed = 0f;
            Leaving?.Invoke(toast);
            if (LeaveDuration <= 0f) Remove(toast);
        }

        private void Remove(Toast toast)
        {
            if (!_visible.Remove(toast)) return;
            toast.IsVisible = false;
            Removed?.Invoke(toast);
        }

        private void Fill()
        {
            while (_pending.Count > 0 && _visible.Count < _maxVisible)
            {
                Toast next = HighestPending();
                _pending.Remove(next);
                next.IsVisible = true; next.Remaining = DurationOf(next.Request);
                _visible.Add(next);
                Shown?.Invoke(next);
            }
        }

        private Toast HighestPending()
        {
            Toast best = _pending[0];
            foreach (Toast toast in _pending)
                if (toast.Request.Priority > best.Request.Priority || (toast.Request.Priority == best.Request.Priority && toast.Order < best.Order)) best = toast;
            return best;
        }

        private Toast LowestPending()
        {
            Toast worst = _pending[0];
            foreach (Toast toast in _pending)
                if (toast.Request.Priority < worst.Request.Priority || (toast.Request.Priority == worst.Request.Priority && toast.Order < worst.Order)) worst = toast;
            return worst;
        }

        private float DurationOf(ToastRequest request) => request.Duration > 0f ? request.Duration : Math.Max(0.01f, DefaultDuration);
    }
}
