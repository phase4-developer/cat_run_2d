using System;
using System.Globalization;
using System.Text;
using UnityEngine;

namespace jjevol
{
    public enum DurationStyle
    {
        // 05:09, 1:02:03, and 2d 01:02:03 past a day.
        Clock,
        // 2h 5m, 1일 3시간, with the largest units first.
        Units
    }

    /// <summary>How remaining time is written. Serializable so a label keeps its own profile in the Inspector.</summary>
    [Serializable]
    public sealed class DurationFormatProfile
    {
        [SerializeField] private DurationStyle style;
        [Tooltip("Clock: always write hours, 0:05:09 instead of 05:09.")]
        [SerializeField] private bool alwaysShowHours;
        [Tooltip("Units: how many units are written at most, for example 2 for 1h 5m.")]
        [SerializeField] private int maxUnits = 2;
        [SerializeField] private string daySymbol = "d";
        [SerializeField] private string hourSymbol = "h";
        [SerializeField] private string minuteSymbol = "m";
        [SerializeField] private string secondSymbol = "s";
        [SerializeField] private string unitSeparator = " ";
        [Tooltip("Units: leave out zero units after the first, 1h instead of 1h 0m. A left-out unit still counts toward the maximum.")]
        [SerializeField] private bool skipZeroUnits = true;
        [Tooltip("Round partial seconds up, so a countdown shows 1 until it really ends.")]
        [SerializeField] private bool roundUp = true;

        public DurationFormatProfile() { }

        public DurationFormatProfile(DurationStyle style, int maxUnits = 2, string day = "d", string hour = "h", string minute = "m", string second = "s",
            string unitSeparator = " ", bool alwaysShowHours = false, bool skipZeroUnits = true, bool roundUp = true)
        {
            if (maxUnits < 1) throw new ArgumentOutOfRangeException(nameof(maxUnits));
            this.style = style; this.maxUnits = maxUnits;
            daySymbol = day ?? string.Empty; hourSymbol = hour ?? string.Empty; minuteSymbol = minute ?? string.Empty; secondSymbol = second ?? string.Empty;
            this.unitSeparator = unitSeparator ?? string.Empty; this.alwaysShowHours = alwaysShowHours; this.skipZeroUnits = skipZeroUnits; this.roundUp = roundUp;
        }

        public DurationStyle Style => style;
        public bool AlwaysShowHours => alwaysShowHours;
        public int MaxUnits => Math.Max(1, maxUnits);
        public string DaySymbol => daySymbol ?? string.Empty;
        public string HourSymbol => hourSymbol ?? string.Empty;
        public string MinuteSymbol => minuteSymbol ?? string.Empty;
        public string SecondSymbol => secondSymbol ?? string.Empty;
        public string UnitSeparator => unitSeparator ?? string.Empty;
        public bool SkipZeroUnits => skipZeroUnits;
        public bool RoundUp => roundUp;

        public DurationFormatProfile Copy() => (DurationFormatProfile)MemberwiseClone();

        public static DurationFormatProfile Clock { get; } = new DurationFormatProfile();
        public static DurationFormatProfile CreateEnglishUnits(int maxUnits = 2) => new DurationFormatProfile(DurationStyle.Units, maxUnits);
        public static DurationFormatProfile CreateKoreanUnits(int maxUnits = 2) => new DurationFormatProfile(DurationStyle.Units, maxUnits, "일", "시간", "분", "초");
    }

    public static class DurationFormat
    {
        /// <summary>Writes <paramref name="time"/> with <paramref name="profile"/> (Clock when null). Negative time is written as zero.</summary>
        public static string Format(TimeSpan time, DurationFormatProfile profile = null, IFormatProvider culture = null)
        {
            profile ??= DurationFormatProfile.Clock;
            culture ??= CultureInfo.InvariantCulture;
            long ticks = Math.Max(0L, time.Ticks);
            long seconds = ticks / TimeSpan.TicksPerSecond;
            if (profile.RoundUp && ticks % TimeSpan.TicksPerSecond != 0) seconds++;

            long days = seconds / 86400, hours = seconds / 3600 % 24, minutes = seconds / 60 % 60, secs = seconds % 60;
            return profile.Style == DurationStyle.Units
                ? Units(profile, culture, days, hours, minutes, secs)
                : Clock(profile, culture, days, hours, minutes, secs);
        }

        public static string Format(double seconds, DurationFormatProfile profile = null, IFormatProvider culture = null)
        {
            if (double.IsNaN(seconds) || seconds <= 0) return Format(TimeSpan.Zero, profile, culture);
            if (seconds >= TimeSpan.MaxValue.TotalSeconds) return Format(TimeSpan.MaxValue, profile, culture);
            return Format(TimeSpan.FromTicks((long)Math.Ceiling(seconds * TimeSpan.TicksPerSecond)), profile, culture);
        }

        private static string Clock(DurationFormatProfile profile, IFormatProvider culture, long days, long hours, long minutes, long secs)
        {
            var text = new StringBuilder();
            if (days > 0) text.Append(days.ToString(culture)).Append(profile.DaySymbol).Append(profile.UnitSeparator);
            if (days > 0) text.Append(hours.ToString("00", culture)).Append(':');
            else if (hours > 0 || profile.AlwaysShowHours) text.Append(hours.ToString(culture)).Append(':');
            text.Append(minutes.ToString("00", culture)).Append(':').Append(secs.ToString("00", culture));
            return text.ToString();
        }

        private static string Units(DurationFormatProfile profile, IFormatProvider culture, long days, long hours, long minutes, long secs)
        {
            long[] values = { days, hours, minutes, secs };
            string[] symbols = { profile.DaySymbol, profile.HourSymbol, profile.MinuteSymbol, profile.SecondSymbol };
            int first = 0;
            while (first < 3 && values[first] == 0) first++;

            var text = new StringBuilder();
            int written = 0;
            for (int i = first; i < 4 && written < profile.MaxUnits; i++)
            {
                if (values[i] == 0 && profile.SkipZeroUnits && written > 0)
                {
                    // A zero unit still uses a slot, so 1h 0m 5s with two units is 1h, not 1h 5s.
                    written++;
                    continue;
                }
                if (text.Length > 0) text.Append(profile.UnitSeparator);
                text.Append(values[i].ToString(culture)).Append(symbols[i]);
                written++;
            }
            return text.ToString();
        }
    }
}
