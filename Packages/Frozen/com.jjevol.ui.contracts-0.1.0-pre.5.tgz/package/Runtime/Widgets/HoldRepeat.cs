using System;

namespace jjevol
{
    /// <summary>Timing of press-and-hold repeat. Serializable for the Inspector.</summary>
    [Serializable]
    public sealed class HoldRepeatTiming
    {
        [UnityEngine.Tooltip("Seconds the press must be held before the first repeat.")]
        public float initialDelay = 0.4f;
        [UnityEngine.Tooltip("Seconds between repeats at the start.")]
        public float startInterval = 0.15f;
        [UnityEngine.Tooltip("Shortest seconds between repeats after speeding up.")]
        public float minInterval = 0.04f;
        [UnityEngine.Tooltip("Seconds of holding after the first repeat to go from the start interval to the shortest one. 0 never speeds up.")]
        public float accelerationTime = 1.5f;
        [UnityEngine.Tooltip("Repeats allowed in one tick at most, so a long frame does not fire a burst.")]
        public int maxRepeatsPerTick = 3;

        public HoldRepeatTiming Copy() => (HoldRepeatTiming)MemberwiseClone();
    }

    /// <summary>
    /// Press-and-hold repeat (a +1 button that keeps adding while held) without input handling. The view calls
    /// <see cref="Press"/> and <see cref="Release"/> from its pointer events and <see cref="Tick"/> each frame.
    /// The press itself is not a repeat: the view handles the normal click.
    /// </summary>
    public sealed class HoldRepeat
    {
        private float _held, _sinceRepeat;
        private bool _repeating;

        public HoldRepeat(HoldRepeatTiming timing = null) { Timing = timing ?? new HoldRepeatTiming(); }

        public HoldRepeatTiming Timing { get; set; }
        public bool IsHeld { get; private set; }
        /// <summary>Repeats since the press.</summary>
        public int RepeatCount { get; private set; }

        public void Press() { IsHeld = true; _held = 0f; _sinceRepeat = 0f; _repeating = false; RepeatCount = 0; }

        public void Release() { IsHeld = false; _repeating = false; }

        /// <summary>Advances the hold. Returns how many repeats fire this tick.</summary>
        public int Tick(float deltaTime)
        {
            if (!IsHeld) return 0;
            if (deltaTime < 0f || float.IsNaN(deltaTime)) deltaTime = 0f;
            HoldRepeatTiming timing = Timing ?? new HoldRepeatTiming();
            _held += deltaTime;
            int fired = 0;
            int limit = Math.Max(1, timing.maxRepeatsPerTick);

            if (!_repeating)
            {
                if (_held < timing.initialDelay) return 0;
                _repeating = true;
                _sinceRepeat = _held - timing.initialDelay;
                fired++; RepeatCount++;
            }
            else
            {
                _sinceRepeat += deltaTime;
            }

            while (fired < limit)
            {
                float interval = CurrentInterval(timing);
                if (_sinceRepeat < interval) break;
                _sinceRepeat -= interval;
                fired++; RepeatCount++;
            }
            // Drop time that the limit did not let fire.
            if (fired >= limit) _sinceRepeat = 0f;
            return fired;
        }

        private float CurrentInterval(HoldRepeatTiming timing)
        {
            float start = Math.Max(0.001f, timing.startInterval);
            float min = Math.Max(0.001f, Math.Min(start, timing.minInterval));
            if (timing.accelerationTime <= 0f) return start;
            float t = Math.Min(1f, Math.Max(0f, (_held - timing.initialDelay) / timing.accelerationTime));
            return t >= 1f ? min : start + (min - start) * t;
        }
    }
}
