using System;

namespace jjevol
{
    /// <summary>Easing curves shared by the uGUI and UI Toolkit widgets. No tween library is needed.</summary>
    public enum Ease
    {
        Linear,
        InQuad,
        OutQuad,
        InOutQuad,
        InCubic,
        OutCubic,
        InOutCubic,
        OutQuart,
        OutExpo,
        // Overshoots past 1 and comes back. Good for pop-ins and button release.
        OutBack,
        OutElastic,
        OutBounce
    }

    public static class Easing
    {
        /// <summary>The eased value of <paramref name="t"/>. t is clamped to 0..1; the result can leave 0..1 for OutBack and OutElastic.</summary>
        public static float Evaluate(Ease ease, float t)
        {
            if (float.IsNaN(t) || t <= 0f) return 0f;
            if (t >= 1f) return 1f;
            switch (ease)
            {
                case Ease.InQuad: return t * t;
                case Ease.OutQuad: return 1f - (1f - t) * (1f - t);
                case Ease.InOutQuad: return t < 0.5f ? 2f * t * t : 1f - Pow(-2f * t + 2f, 2) / 2f;
                case Ease.InCubic: return t * t * t;
                case Ease.OutCubic: return 1f - Pow(1f - t, 3);
                case Ease.InOutCubic: return t < 0.5f ? 4f * t * t * t : 1f - Pow(-2f * t + 2f, 3) / 2f;
                case Ease.OutQuart: return 1f - Pow(1f - t, 4);
                case Ease.OutExpo: return 1f - (float)Math.Pow(2, -10 * t);
                case Ease.OutBack:
                {
                    const float c1 = 1.70158f, c3 = c1 + 1f;
                    return 1f + c3 * Pow(t - 1f, 3) + c1 * Pow(t - 1f, 2);
                }
                case Ease.OutElastic:
                {
                    const float c4 = (float)(2 * Math.PI / 3);
                    return (float)(Math.Pow(2, -10 * t) * Math.Sin((t * 10 - 0.75) * c4) + 1);
                }
                case Ease.OutBounce: return Bounce(t);
                default: return t;
            }
        }

        public static float Lerp(float from, float to, Ease ease, float t) => from + (to - from) * Evaluate(ease, t);

        private static float Pow(float value, int power)
        {
            float result = 1f;
            for (int i = 0; i < power; i++) result *= value;
            return result;
        }

        private static float Bounce(float t)
        {
            const float n1 = 7.5625f, d1 = 2.75f;
            if (t < 1f / d1) return n1 * t * t;
            if (t < 2f / d1) { t -= 1.5f / d1; return n1 * t * t + 0.75f; }
            if (t < 2.5f / d1) { t -= 2.25f / d1; return n1 * t * t + 0.9375f; }
            t -= 2.625f / d1; return n1 * t * t + 0.984375f;
        }
    }

    /// <summary>
    /// One float moving from a start to an end over time. The owner calls <see cref="Tick"/> with its own delta time,
    /// so scaled, unscaled and test time all work the same way.
    /// </summary>
    public sealed class FloatTween
    {
        private float _from, _to, _duration, _delay, _elapsed;
        private Ease _ease;

        public float Value { get; private set; }
        public float From => _from;
        public float To => _to;
        public bool IsPlaying { get; private set; }

        public FloatTween(float value = 0f) { Value = value; _from = value; _to = value; }

        /// <summary>Starts from the current value. A duration of 0 or less with no delay jumps at once.</summary>
        public void Play(float to, float duration, Ease ease = Ease.OutCubic, float delay = 0f) => Play(Value, to, duration, ease, delay);

        public void Play(float from, float to, float duration, Ease ease = Ease.OutCubic, float delay = 0f)
        {
            _from = from; _to = to; _duration = Math.Max(0f, duration); _delay = Math.Max(0f, delay); _ease = ease; _elapsed = 0f;
            Value = from;
            IsPlaying = true;
            if (_duration <= 0f && _delay <= 0f) Complete();
        }

        /// <summary>Jumps to <paramref name="value"/> and stops.</summary>
        public void Set(float value) { Value = value; _from = value; _to = value; IsPlaying = false; }

        public void Complete() { Value = _to; IsPlaying = false; }

        public void Stop() => IsPlaying = false;

        /// <summary>Advances the tween. Returns true while the value changed this tick.</summary>
        public bool Tick(float deltaTime)
        {
            if (!IsPlaying) return false;
            if (deltaTime < 0f || float.IsNaN(deltaTime)) deltaTime = 0f;
            _elapsed += deltaTime;
            float active = _elapsed - _delay;
            if (active < 0f) return false;
            if (_duration <= 0f || active >= _duration) { Complete(); return true; }
            Value = Easing.Lerp(_from, _to, _ease, active / _duration);
            return true;
        }
    }
}
