using System;

namespace jjevol
{
    /// <summary>
    /// A decimal value that counts toward a target over time, the model behind the animated number labels. The shown
    /// value never passes the target and moves in whole steps of <see cref="DecimalPlaces"/>, so a count from 0 to 1000
    /// never shows 1000.4 or 1001.
    /// </summary>
    public sealed class NumberCounter
    {
        private decimal _from, _to;
        private float _elapsed, _duration;
        private int _decimalPlaces;

        public NumberCounter(decimal value = 0m) { Current = value; _from = value; _to = value; }

        public decimal Current { get; private set; }
        public decimal Target => _to;
        public bool IsPlaying { get; private set; }
        public Ease Ease { get; set; } = Ease.OutCubic;

        /// <summary>Seconds a count takes. With <see cref="DurationPerUnit"/> it is the shortest time.</summary>
        public float Duration { get; set; } = 0.6f;

        /// <summary>Extra seconds per order of magnitude of the change (log10), so small changes are quick and large ones
        /// read longer. 0 keeps <see cref="Duration"/> fixed.</summary>
        public float DurationPerUnit { get; set; }

        /// <summary>Longest time when <see cref="DurationPerUnit"/> lengthens a count. 0 or less means no limit.</summary>
        public float MaxDuration { get; set; } = 1.5f;

        /// <summary>Digits after the decimal point of the values shown during a count. 0 shows whole numbers.</summary>
        public int DecimalPlaces
        {
            get => _decimalPlaces;
            set => _decimalPlaces = Math.Max(0, Math.Min(10, value));
        }

        /// <summary>Raised once when a count reaches its target.</summary>
        public event Action Completed;

        public void Set(decimal value)
        {
            bool wasPlaying = IsPlaying;
            Current = value; _from = value; _to = value; IsPlaying = false;
            if (wasPlaying) Completed?.Invoke();
        }

        /// <summary>Counts from the shown value to <paramref name="target"/>. A count to the shown value completes at once.</summary>
        public void CountTo(decimal target)
        {
            _from = Current; _to = target; _elapsed = 0f;
            _duration = ResolveDuration(target - Current);
            if (target == Current || _duration <= 0f) { Current = target; IsPlaying = false; Completed?.Invoke(); return; }
            IsPlaying = true;
        }

        public void Complete()
        {
            if (!IsPlaying) return;
            Current = _to; IsPlaying = false; Completed?.Invoke();
        }

        /// <summary>Advances the count. Returns true when <see cref="Current"/> changed.</summary>
        public bool Tick(float deltaTime)
        {
            if (!IsPlaying) return false;
            if (deltaTime < 0f || float.IsNaN(deltaTime)) deltaTime = 0f;
            _elapsed += deltaTime;
            if (_elapsed >= _duration) { decimal before = Current; Complete(); return before != Current; }

            decimal progress = (decimal)Easing.Evaluate(Ease, _elapsed / _duration);
            decimal raw = _from + (_to - _from) * progress;
            decimal next = TowardStart(raw);
            // Overshooting eases (OutBack) must not show a value past the target.
            if (_to >= _from) next = Math.Min(next, _to); else next = Math.Max(next, _to);
            if (next == Current) return false;
            Current = next;
            return true;
        }

        private decimal TowardStart(decimal raw)
        {
            decimal scale = 1m;
            for (int i = 0; i < _decimalPlaces; i++) scale *= 10m;
            try
            {
                decimal scaled = raw * scale;
                decimal stepped = _to >= _from ? decimal.Floor(scaled) : decimal.Ceiling(scaled);
                return stepped / scale;
            }
            catch (OverflowException)
            {
                return decimal.Truncate(raw);
            }
        }

        private float ResolveDuration(decimal delta)
        {
            float duration = Math.Max(0f, Duration);
            if (DurationPerUnit > 0f && delta != 0m)
            {
                double magnitude = Math.Log10((double)Math.Abs(delta) + 1d);
                duration += (float)magnitude * DurationPerUnit;
                if (MaxDuration > 0f) duration = Math.Min(duration, Math.Max(Duration, MaxDuration));
            }
            return duration;
        }
    }
}
