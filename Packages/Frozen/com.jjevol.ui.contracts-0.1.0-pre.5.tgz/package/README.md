# JJEvol UI Contracts

`com.jjevol.ui.contracts@0.1.0-pre.5`는 uGUI 계열(`com.jjevol.ui`, `com.jjevol.ui.addressables`)과 UI Toolkit 계열이 함께 쓰는 UI 시스템 중립 계약이다. uGUI, TextMeshPro, UniTask에 의존하지 않는다. Addressables(`com.unity.addressables` 4.0.1)에는 의존한다. Editor 생성기가 Addressables 그룹에서 ID를 읽기 때문이라, UI Toolkit 게임도 Addressables를 설치한다. 프로젝트는 UI 시스템을 하나만 쓰지만(D-02), 주소 규칙과 ID 생성기는 한 곳에서만 고친다(UI Toolkit 계획 결정 G1).

## 들어 있는 것

| 형식 | 역할 |
|---|---|
| `UIAddress` | 게임 소유 문자열 UI ID와 Addressables 주소 `UIScreen_{id}`, `UIPopup_{id}`, `UIHud_{id}` |
| `UIAddressIdAttribute` | Inspector에서 등록 주소 중 접두가 맞는 ID를 고르게 하는 속성. 그리기는 Editor의 `UIAddressIdDrawer` |
| `UIIdConstants` | `JJEvol/UI/Generate UI ID Constants`. 등록 주소를 읽어 게임 폴더에 `GameScreen`, `GamePopup`, `GameHud` 문자열 상수를 쓴다 |
| `IScreenData`, `IPopupData` | 화면·팝업에 넘기는 데이터 표시 계약 |
| `IUILoadingProgressView` | 전체 화면 로딩의 진행률·문구 표시 계약 |
| `NumberFormat`, `NumberFormatProfile`, `NumberFormatSettings` | 숫자 표기. 아래 「숫자 표기」 |
| `Ease`, `Easing`, `FloatTween`, `Impulse`, `Oscillation` | 위젯 움직임. 트윈 라이브러리 없이 보간·펀치·흔들기·맥동을 계산한다. 아래 「위젯 모델」 |
| `NumberCounter`, `GaugeModel`·`GaugeTiming`, `ToastQueue`·`ToastRequest`·`Toast`, `HoldRepeat`·`HoldRepeatTiming`, `DurationFormat`·`DurationFormatProfile`, `Typewriter`·`RichText` | 위젯 상태. 화면 없이 시간만 받아 동작하고, uGUI·UI Toolkit 위젯 패키지가 같이 쓴다 |

모든 형식은 namespace `jjevol`이다. 2026-11-11에 `com.jjevol.ui`와 `com.jjevol.ui.addressables`에서 이름·GUID를 그대로 두고 옮겼다.

## 숫자 표기

수치가 큰 게임은 `1.2K`, `1억 2000만`처럼 단위 기호로 줄여 쓴다. 몇 자리마다 바꿀지와 기호는 게임이 정한다. 게임이 아무것도 정하지 않으면 지금처럼 `N0`(모든 자리, 문화권 구분자)이다.

```csharp
var settings = new NumberFormatSettings(NumberFormatProfile.CreateThousands(decimalPlaces: 1))   // 그 밖 언어: 1.2K
    .SetLanguage("ko", NumberFormatProfile.CreateKorean(maxUnits: 2));                           // ko-KR 등: 1억 2000만
UIDisplayOptions.NumberFormat = settings;     // uGUI·UI Toolkit 공통, 한 번
string text = NumberFormat.Format(123456789L, settings.Resolve("ko-KR"), CultureInfo.GetCultureInfo("ko-KR")); // "1억 2345만"
```

| 설정 | 뜻 | 예 |
|---|---|---|
| `Notation` | `Full`(N0) 또는 `Abbreviated` | |
| `UnitBase` | 기호 하나가 앞 기호의 몇 배인지 | 1000(K·M), 10000(만·억) |
| `Symbols` | `UnitBase`¹, ²… 순서의 기호. 마지막 기호를 넘는 값은 마지막 기호에 큰 수를 붙인다 | `K,M,B,T` → `9,223,372.03T` |
| `AbbreviateFrom` | 이 값보다 작으면 `N0`. 0이면 `UnitBase` | 10000이면 9,999는 그대로, 10,000은 `10K` |
| `DecimalPlaces` | 마지막으로 쓰는 단위의 소수 자릿수. 기본은 버리고 끝의 0을 지운다(`Rounding`, `KeepTrailingZeros`로 바꾼다) | 2면 999,999는 `999.99K` |
| `MaxUnits` | 쓰는 단위 수. 0인 단위는 건너뛴다 | 2면 `1억 2345만`, 3이면 `1억 2345만 6789` |
| `UnitSeparator` | 단위 사이 문자열 | 기본 공백 |
| `GroupDigits` | 한 단위 안에 문화권 자릿수 구분자를 쓸지 | 한국어 기본은 false(`1234만`) |
| `Rounding` | 마지막으로 쓰는 단위(1의 자리 포함)를 `Truncate`(버림, 기본) 또는 `HalfUp`(0.5에서 올림)으로 정리. 단위는 반올림 전에 고르고, 여러 단위를 쓰면 올림이 위 단위로 넘어간다 | 소수 1자리 `HalfUp`이면 12,350은 `12.4K`, 999,950은 `1000.0K`. 2단위 한국어 `HalfUp`이면 199,995,000은 `2억` |
| `KeepTrailingZeros` | 소수 자릿수만큼 끝의 0을 남길지(기본 false) | true면 12,000은 `12.0K` |

언어는 정확히 같은 이름(`ko-KR`), 그다음 앞부분(`ko`), 그다음 `Default` 순으로 고른다. 음수는 문화권 음수 기호를 앞에 붙인다. 프로필은 `[Serializable]`이라 라벨 Inspector에 둘 수 있고, 범위를 벗어난 Inspector 값은 표시할 때 안전한 값으로 줄인다. 코드에서 만들 때는 생성자가 잘못된 값을 거부한다.

라벨 연결: uGUI(`NumberAnimator`, `ui.economy`의 `PriceLabel`·`PriceBtn`·`ResourceLabel`, `ui.widgets`)와 UI Toolkit(`uitoolkit.economy`의 `PriceLabel`·`PriceBtn`·`ResourceLabel`, `uitoolkit.widgets`)이 모두 아래 `UIDisplayOptions.NumberFormat`을 따르고, 라벨마다 덮어쓸 수 있다(각 패키지 README). 실행 중에 설정을 바꾸면 `UIDisplayOptions.NotifyLocaleChanged()`를 불러 다시 그린다.

## 표시 설정 `UIDisplayOptions`

두 UI 시스템의 모든 패키지가 읽는 게임 전체 표시 설정 한 곳이다(2026-11-20 사용자 결정 「ui.contracts 중립 설정」·「uGUI도 맞춤」). 게임은 부트에서 한 번 설정한다. 패키지끼리 잇는 줄은 필요 없다.

```csharp
UIDisplayOptions.Culture = () => LocalizationSettings.SelectedLocale?.Identifier.CultureInfo;   // 비우면 CultureInfo.CurrentCulture
UIDisplayOptions.Language = () => currentLanguageCode;   // 숫자 프로필을 고를 언어. 비우면 Culture 이름
UIDisplayOptions.NumberFormat = settings;                 // 비우면 N0
UIDisplayOptions.UtcNow = () => serverClock.UtcNow;       // 남은 시간 위젯의 믿을 시계. 비우면 DateTime.UtcNow
LocalizationSettings.SelectedLocaleChanged += _ => UIDisplayOptions.NotifyLocaleChanged();
```

| 멤버 | 뜻 |
|---|---|
| `Culture`·`Language`·`NumberFormat`·`UtcNow` | 게임이 넣는 값. 모두 비워도 동작한다 |
| `DisplayCulture`·`CurrentLanguage`·`CurrentNumberFormat`·`Now` | 위 값을 기본값까지 풀어 읽은 결과 |
| `FormatNumber(value, elementProfile)` | 라벨 프로필이 있으면 그것, 없으면 게임 프로필로 쓴 숫자 |
| `AbbreviatedNumberFormat(elementProfile)` | 축약을 켠 라벨이 쓸 프로필. 라벨·게임 프로필이 축약이면 그것, 아니면 언어별 기본 축약 |
| `LocaleChanged`·`NotifyLocaleChanged()` | 이미 보이는 라벨을 다시 그리게 하는 알림 |

정적 상태는 Domain Reload를 끈 Play 진입에 대비해 `SubsystemRegistration`에서 비운다. 그 뒤(부트스트랩·`BeforeSceneLoad` 이후)에 설정한다. uGUI 전용 `UIRuntimeOptions`(`com.jjevol.ui`)에는 `Localize`·`RegisterLoadingCounter`만 남았다.

## 위젯 모델

`com.jjevol.ui.widgets`(uGUI)와 `com.jjevol.uitoolkit.widgets`(UI Toolkit)가 같은 동작을 내도록 상태와 계산을 여기 둔다. 모두 소유자가 `Tick(deltaTime)`을 불러 진행하므로 scaled·unscaled 시간과 시험 시간이 같은 길로 간다. 화면 객체는 만들지 않는다.

| 형식 | 동작 |
|---|---|
| `Easing.Evaluate(ease, t)`·`FloatTween` | 이징 곡선 12종과 지연·길이가 있는 float 보간. 길이 0이면 바로 끝난다 |
| `Impulse` | 감쇠하는 펀치(한 축 왕복)와 흔들기(두 축, 같은 시드면 같은 값). 단위(배율·픽셀)는 화면이 곱한다 |
| `NumberCounter` | decimal 카운트. 표시값은 목표를 넘지 않고 `DecimalPlaces` 단위로 시작 쪽으로 끊는다. `DurationPerUnit`·`MaxDuration`으로 변화가 클수록 조금 더 길게 센다 |
| `GaugeModel` | 감소: 채움은 바로 내려가고 잔상(Trail)이 지연 뒤 따라 내려온 뒤 사라진다. 연속 감소는 높은 잔상을 이어 간다. `heavyThreshold` 이상이면 큰 감소로 알린다. 증가: 앞선 막대(Lead)가 먼저 보이고 채움이 따라간다. `AnimateTo(value, laps)`는 끝까지 채우고 0으로 넘어가기를 laps번 한다(경험치) |
| `ToastQueue` | 동시 표시 수, 대기 상한, 우선순위, 같은 `MergeKey` 합치기(개수 증가·시간 재시작), 퇴장 시간. 화면은 `Shown`·`Updated`·`Leaving`·`Removed` 이벤트로 그린다 |
| `HoldRepeat` | 길게 누르기 반복. 첫 지연 뒤 반복하고 점점 빨라진다. 한 틱 최대 횟수로 긴 프레임의 몰아치기를 막는다 |
| `DurationFormat` | 남은 시간 `05:09`·`1:02:03`·`2d 01:02:03`(Clock) 또는 `1h 2m`·`1일 1시간`(Units). 기본은 초를 올려 0이 되기 전까지 1초를 보인다 |
| `Typewriter`·`RichText` | 초당 글자 수와 문장부호 뒤 쉼. 리치 텍스트 태그는 세지 않고 자르지 않는다 |

## 설치와 참조

`com.jjevol.ui`와 `com.jjevol.ui.addressables`가 이 패키지에 의존하므로 manifest에 함께 적는다. Assembly-CSharp는 자동으로 참조한다. 게임이 자체 asmdef를 쓰고 위 형식을 직접 쓰면 그 asmdef에 `JJEvol.UI.Contracts.Runtime`(생성기를 부르는 Editor 코드는 `JJEvol.UI.Contracts.Editor`)를 더한다.

## 검증

Editor 시험 `JJEvol.UI.Contracts.Tests.Editor`(ID 생성기, 숫자 표기 경계값·프로필·언어 선택, 위젯 모델 `WidgetMotionTests`·`WidgetTextAndQueueTests`). 결과는 `Docs/Guide/Verification.md`에 적는다.
