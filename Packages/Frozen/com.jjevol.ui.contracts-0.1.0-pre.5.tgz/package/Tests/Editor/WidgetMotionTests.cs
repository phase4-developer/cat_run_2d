using System.Collections.Generic;
using NUnit.Framework;

namespace jjevol.UI.Tests
{
    public sealed class WidgetMotionTests
    {
        [Test]
        public void EasingStartsAtZeroEndsAtOneAndClampsTime()
        {
            foreach (Ease ease in System.Enum.GetValues(typeof(Ease)))
            {
                Assert.That(Easing.Evaluate(ease, 0f), Is.EqualTo(0f), ease.ToString());
                Assert.That(Easing.Evaluate(ease, 1f), Is.EqualTo(1f), ease.ToString());
                Assert.That(Easing.Evaluate(ease, -3f), Is.EqualTo(0f), ease.ToString());
                Assert.That(Easing.Evaluate(ease, 5f), Is.EqualTo(1f), ease.ToString());
                Assert.That(Easing.Evaluate(ease, float.NaN), Is.EqualTo(0f), ease.ToString());
            }
            Assert.That(Easing.Evaluate(Ease.Linear, 0.25f), Is.EqualTo(0.25f).Within(1e-6f));
            Assert.That(Easing.Evaluate(Ease.OutBack, 0.7f), Is.GreaterThan(1f), "OutBack overshoots");
        }

        [Test]
        public void FloatTweenWaitsForDelayThenReachesTheEnd()
        {
            var tween = new FloatTween(0f);
            tween.Play(10f, 1f, Ease.Linear, delay: 0.5f);
            Assert.That(tween.Tick(0.4f), Is.False);
            Assert.That(tween.Value, Is.EqualTo(0f));
            tween.Tick(0.6f);
            Assert.That(tween.Value, Is.EqualTo(5f).Within(1e-4f));
            tween.Tick(10f);
            Assert.That(tween.Value, Is.EqualTo(10f));
            Assert.That(tween.IsPlaying, Is.False);

            tween.Play(3f, 0f);
            Assert.That(tween.Value, Is.EqualTo(3f), "Zero duration jumps at once");
            Assert.That(tween.IsPlaying, Is.False);
        }

        [Test]
        public void ImpulseDecaysToZeroAndShakeIsTheSameForOneSeed()
        {
            var a = new Impulse();
            var b = new Impulse();
            a.Play(ImpulseKind.Shake, 6f, 0.2f, 10, seed: 7);
            b.Play(ImpulseKind.Shake, 6f, 0.2f, 10, seed: 7);
            for (int i = 0; i < 5; i++)
            {
                a.Tick(0.03f); b.Tick(0.03f);
                Assert.That(a.X, Is.EqualTo(b.X)); Assert.That(a.Y, Is.EqualTo(b.Y));
                Assert.That(System.Math.Abs(a.X), Is.LessThanOrEqualTo(6f));
            }
            a.Tick(1f);
            Assert.That(a.IsPlaying, Is.False);
            Assert.That(a.X, Is.EqualTo(0f)); Assert.That(a.Y, Is.EqualTo(0f));

            var punch = new Impulse();
            punch.Play(ImpulseKind.Punch, 0.1f, 1f, vibrato: 1);
            punch.Tick(0.25f);
            Assert.That(punch.X, Is.GreaterThan(0f), "The first swing of a punch is positive");
            Assert.That(punch.X, Is.EqualTo(punch.Y));
        }

        [Test]
        public void PulseIsZeroAtPeriodEdgesAndOneAtHalf()
        {
            Assert.That(Oscillation.Pulse(0f, 2f), Is.EqualTo(0f).Within(1e-6f));
            Assert.That(Oscillation.Pulse(1f, 2f), Is.EqualTo(1f).Within(1e-6f));
            Assert.That(Oscillation.Pulse(2f, 2f), Is.EqualTo(0f).Within(1e-6f));
            Assert.That(Oscillation.Pulse(1f, 0f), Is.EqualTo(0f));
        }

        [Test]
        public void NumberCounterMovesInWholeStepsAndNeverPassesTheTarget()
        {
            var counter = new NumberCounter(0m) { Duration = 1f, Ease = Ease.OutBack };
            int completed = 0;
            counter.Completed += () => completed++;
            counter.CountTo(1000m);
            var seen = new List<decimal>();
            for (int i = 0; i < 25; i++) { counter.Tick(0.05f); seen.Add(counter.Current); }
            foreach (decimal value in seen)
            {
                Assert.That(value, Is.LessThanOrEqualTo(1000m));
                Assert.That(value, Is.EqualTo(decimal.Floor(value)), "Whole numbers only");
            }
            Assert.That(counter.Current, Is.EqualTo(1000m));
            Assert.That(completed, Is.EqualTo(1));

            counter.Ease = Ease.Linear;
            counter.DecimalPlaces = 1;
            counter.CountTo(999m);
            counter.Tick(0.5f);
            Assert.That(counter.Current, Is.EqualTo(999.5m), "Counting down rounds toward the start");
        }

        [Test]
        public void NumberCounterToTheSameValueCompletesAtOnceAndLongCountsAreCapped()
        {
            var counter = new NumberCounter(5m) { Duration = 0.2f, DurationPerUnit = 1f, MaxDuration = 0.5f };
            int completed = 0;
            counter.Completed += () => completed++;
            counter.CountTo(5m);
            Assert.That(completed, Is.EqualTo(1));
            Assert.That(counter.IsPlaying, Is.False);

            counter.CountTo(5_000_000m);
            counter.Tick(0.49f);
            Assert.That(counter.IsPlaying, Is.True);
            counter.Tick(0.02f);
            Assert.That(counter.Current, Is.EqualTo(5_000_000m), "MaxDuration caps the count at 0.5s");

            counter.CountTo(decimal.MaxValue);
            counter.Tick(0.1f);
            counter.Set(1m);
            Assert.That(counter.Current, Is.EqualTo(1m));
        }

        [Test]
        public void GaugeDecreaseDropsTheFillAndDrainsTheTrailAfterTheDelay()
        {
            var timing = new GaugeTiming { scaleByAmount = false, decreaseDelay = 0.1f, decreaseDuration = 0.2f, decreaseEase = Ease.Linear, ghostFadeDuration = 0.1f, heavyThreshold = 0.3f };
            var gauge = new GaugeModel(timing, 1f);
            float size = 0f; bool heavy = true;
            gauge.Decreased += (d, h) => { size = d; heavy = h; };

            gauge.AnimateTo(0.8f);
            Assert.That(gauge.Fill, Is.EqualTo(0.8f).Within(1e-5f));
            Assert.That(gauge.Trail, Is.EqualTo(1f));
            Assert.That(gauge.TrailAlpha, Is.EqualTo(1f));
            Assert.That(size, Is.EqualTo(0.2f).Within(1e-5f));
            Assert.That(heavy, Is.False);

            gauge.Tick(0.1f);
            Assert.That(gauge.Trail, Is.EqualTo(1f), "Waits for the delay");
            gauge.Tick(0.1f);
            Assert.That(gauge.Trail, Is.EqualTo(0.9f).Within(1e-4f));
            gauge.Tick(0.1f);
            Assert.That(gauge.Trail, Is.EqualTo(0.8f).Within(1e-4f));
            gauge.Tick(0.2f);
            Assert.That(gauge.TrailAlpha, Is.EqualTo(0f));
            Assert.That(gauge.IsAnimating, Is.False);

            gauge.AnimateTo(0.2f);
            Assert.That(heavy, Is.True);
        }

        [Test]
        public void GaugeRepeatedHitsKeepTheHigherTrail()
        {
            var gauge = new GaugeModel(new GaugeTiming { scaleByAmount = false, decreaseDelay = 0.5f }, 1f);
            gauge.AnimateTo(0.8f);
            gauge.Tick(0.1f);
            gauge.AnimateTo(0.6f);
            Assert.That(gauge.Trail, Is.EqualTo(1f), "The second hit keeps the first trail start");
            Assert.That(gauge.Fill, Is.EqualTo(0.6f).Within(1e-5f));
        }

        [Test]
        public void GaugeIncreaseShowsTheLeadAndGrowsTheFill()
        {
            var timing = new GaugeTiming { increaseDuration = 0.2f, increaseEase = Ease.Linear, ghostFadeDuration = 0.1f };
            var gauge = new GaugeModel(timing, 0.2f);
            float gained = 0f;
            gauge.Increased += d => gained = d;
            gauge.AnimateTo(0.6f);
            Assert.That(gauge.Lead, Is.EqualTo(0.6f));
            Assert.That(gauge.LeadAlpha, Is.EqualTo(1f));
            Assert.That(gauge.Fill, Is.EqualTo(0.2f).Within(1e-5f));
            Assert.That(gained, Is.EqualTo(0.4f).Within(1e-5f));
            gauge.Tick(0.1f);
            Assert.That(gauge.Fill, Is.EqualTo(0.4f).Within(1e-4f));
            gauge.Tick(0.1f);
            Assert.That(gauge.Fill, Is.EqualTo(0.6f).Within(1e-5f));
            gauge.Tick(0.1f);
            Assert.That(gauge.LeadAlpha, Is.EqualTo(0f));

            timing.animateIncrease = false;
            gauge.AnimateTo(0.9f);
            Assert.That(gauge.Fill, Is.EqualTo(0.9f).Within(1e-5f), "No animation jumps at once");
        }

        [Test]
        public void GaugeLapsWrapToZeroAndRaiseAnEventEachTime()
        {
            var gauge = new GaugeModel(new GaugeTiming { lapDuration = 0.1f, increaseDuration = 0.1f }, 0.5f);
            int laps = 0;
            gauge.LapCompleted += () => laps++;
            gauge.AnimateTo(0.3f, 2);
            for (int i = 0; i < 10; i++) gauge.Tick(0.1f);
            Assert.That(laps, Is.EqualTo(2));
            Assert.That(gauge.Fill, Is.EqualTo(0.3f).Within(1e-5f));
            Assert.That(gauge.IsAnimating, Is.False);
        }

        [Test]
        public void GaugeLapHandlersMaySetTheGaugeAndManyInstantLapsDoNotRecurse()
        {
            var gauge = new GaugeModel(new GaugeTiming { lapDuration = 0.1f, increaseDuration = 0.1f }, 0.5f);
            int laps = 0;
            gauge.LapCompleted += () => { laps++; gauge.SetInstant(0.9f); };
            gauge.AnimateTo(0.3f, 3);
            for (int i = 0; i < 10; i++) gauge.Tick(0.1f);
            Assert.That(laps, Is.EqualTo(1), "SetInstant in the handler ends the rest");
            Assert.That(gauge.Fill, Is.EqualTo(0.9f).Within(1e-5f));
            Assert.That(gauge.IsAnimating, Is.False);

            var instant = new GaugeModel(new GaugeTiming { lapDuration = 0f, increaseDuration = 0f }, 0f);
            int count = 0;
            instant.LapCompleted += () => count++;
            instant.AnimateTo(0.5f, 100000);
            Assert.That(count, Is.EqualTo(100000));
            Assert.That(instant.Fill, Is.EqualTo(0.5f).Within(1e-5f));
        }

        [Test]
        public void GaugeSetInstantClearsEverything()
        {
            var gauge = new GaugeModel(null, 1f);
            gauge.AnimateTo(0.1f);
            gauge.SetInstant(0.5f);
            Assert.That(gauge.Fill, Is.EqualTo(0.5f));
            Assert.That(gauge.Trail, Is.EqualTo(0.5f));
            Assert.That(gauge.TrailAlpha, Is.EqualTo(0f));
            Assert.That(gauge.IsAnimating, Is.False);
            gauge.SetInstant(float.NaN);
            Assert.That(gauge.Fill, Is.EqualTo(0f));
            gauge.AnimateTo(3f);
            Assert.That(gauge.Target, Is.EqualTo(1f), "Clamped to 0..1");
        }

        [Test]
        public void HoldRepeatWaitsThenRepeatsFasterAndLimitsBursts()
        {
            var hold = new HoldRepeat(new HoldRepeatTiming { initialDelay = 0.4f, startInterval = 0.2f, minInterval = 0.05f, accelerationTime = 1f, maxRepeatsPerTick = 3 });
            Assert.That(hold.Tick(1f), Is.EqualTo(0), "Not pressed");
            hold.Press();
            Assert.That(hold.Tick(0.3f), Is.EqualTo(0));
            Assert.That(hold.Tick(0.1f), Is.EqualTo(1), "First repeat at the delay");
            Assert.That(hold.Tick(0.2f), Is.EqualTo(1));
            Assert.That(hold.Tick(5f), Is.EqualTo(3), "Long frame is limited");
            Assert.That(hold.Tick(0.05f), Is.EqualTo(1), "At full speed one repeat every 0.05s");
            hold.Release();
            Assert.That(hold.Tick(1f), Is.EqualTo(0));
            Assert.That(hold.RepeatCount, Is.EqualTo(6));
        }
    }
}
