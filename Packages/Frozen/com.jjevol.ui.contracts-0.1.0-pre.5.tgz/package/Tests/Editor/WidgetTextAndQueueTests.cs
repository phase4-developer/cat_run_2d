using System;
using System.Collections.Generic;
using System.Globalization;
using NUnit.Framework;

namespace jjevol.UI.Tests
{
    public sealed class WidgetTextAndQueueTests
    {
        [Test]
        public void ToastQueueShowsUpToTheLimitAndFillsAfterRemoval()
        {
            var queue = new ToastQueue { MaxVisible = 2, DefaultDuration = 1f, LeaveDuration = 0.2f };
            var log = new List<string>();
            queue.Shown += t => log.Add("show " + t.Request.Message);
            queue.Leaving += t => log.Add("leave " + t.Request.Message);
            queue.Removed += t => log.Add("remove " + t.Request.Message);

            queue.Enqueue(new ToastRequest("a"));
            queue.Enqueue(new ToastRequest("b"));
            queue.Enqueue(new ToastRequest("c"));
            Assert.That(queue.Visible.Count, Is.EqualTo(2));
            Assert.That(queue.PendingCount, Is.EqualTo(1));

            queue.Tick(1f);
            Assert.That(queue.Visible.Count, Is.EqualTo(2), "Leaving toasts stay for the exit");
            queue.Tick(0.2f);
            Assert.That(log, Is.EqualTo(new[] { "show a", "show b", "leave a", "leave b", "remove a", "remove b", "show c" }));
        }

        [Test]
        public void ToastQueueMergesTheSameKeyAndRestartsTheTimer()
        {
            var queue = new ToastQueue { DefaultDuration = 1f };
            int updated = 0;
            queue.Updated += _ => updated++;
            Toast first = queue.Enqueue(new ToastRequest("+10 gold") { MergeKey = "gold" });
            queue.Tick(0.8f);
            Toast merged = queue.Enqueue(new ToastRequest("+20 gold") { MergeKey = "gold" });
            Assert.That(merged, Is.SameAs(first));
            Assert.That(first.Count, Is.EqualTo(2));
            Assert.That(first.Request.Message, Is.EqualTo("+20 gold"));
            Assert.That(first.Remaining, Is.EqualTo(1f));
            Assert.That(updated, Is.EqualTo(1));
            Assert.That(queue.Enqueue(new ToastRequest("other")), Is.Not.SameAs(first), "No key never merges");
        }

        [Test]
        public void ToastQueueShowsHigherPriorityFirstAndDropsTheLowestPastTheLimit()
        {
            var queue = new ToastQueue { MaxVisible = 1, MaxPending = 2, LeaveDuration = 0f };
            var dropped = new List<string>();
            queue.Dropped += t => dropped.Add(t.Request.Message);
            queue.Enqueue(new ToastRequest("on screen"));
            queue.Enqueue(new ToastRequest("low"));
            queue.Enqueue(new ToastRequest("high") { Priority = 5 });
            Assert.That(queue.Enqueue(new ToastRequest("lower") { Priority = -1 }), Is.Null);
            queue.Enqueue(new ToastRequest("mid") { Priority = 1 });
            Assert.That(dropped, Is.EqualTo(new[] { "lower", "low" }));

            queue.Dismiss(queue.Visible[0]);
            Assert.That(queue.Visible[0].Request.Message, Is.EqualTo("high"));
            queue.Clear();
            Assert.That(queue.Visible.Count, Is.EqualTo(0));
            Assert.That(queue.PendingCount, Is.EqualTo(0));
            Assert.Throws<ArgumentNullException>(() => queue.Enqueue(null));
        }

        [Test]
        public void DurationClockStyle()
        {
            var en = CultureInfo.InvariantCulture;
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(309), null, en), Is.EqualTo("05:09"));
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(3723), null, en), Is.EqualTo("1:02:03"));
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(2 * 86400 + 3723), null, en), Is.EqualTo("2d 01:02:03"));
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(-5), null, en), Is.EqualTo("00:00"));
            Assert.That(DurationFormat.Format(0.2, null, en), Is.EqualTo("00:01"), "Partial seconds round up");
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(9), new DurationFormatProfile(DurationStyle.Clock, alwaysShowHours: true), en), Is.EqualTo("0:00:09"));
        }

        [Test]
        public void DurationUnitsStyle()
        {
            var en = CultureInfo.InvariantCulture;
            DurationFormatProfile english = DurationFormatProfile.CreateEnglishUnits();
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(3723), english, en), Is.EqualTo("1h 2m"));
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(3605), english, en), Is.EqualTo("1h"), "A zero minute uses a slot");
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(45), english, en), Is.EqualTo("45s"));
            Assert.That(DurationFormat.Format(TimeSpan.Zero, english, en), Is.EqualTo("0s"));
            Assert.That(DurationFormat.Format(TimeSpan.FromSeconds(90061), DurationFormatProfile.CreateKoreanUnits(3), en), Is.EqualTo("1일 1시간 1분"));
        }

        [Test]
        public void RichTextStripAndCutKeepTags()
        {
            const string text = "Hi <b>bold</b> <color=#f00>red</color> a<b";
            Assert.That(RichText.Strip(text), Is.EqualTo("Hi bold red a<b"));
            Assert.That(RichText.Cut(text, 5), Is.EqualTo("Hi <b>bo"));
            Assert.That(RichText.Cut(text, 7), Is.EqualTo("Hi <b>bold</b>"));
            Assert.That(RichText.Cut("<b>x</b>", 0), Is.EqualTo("<b>"));
            Assert.That(RichText.Cut(null, 3), Is.EqualTo(string.Empty));
        }

        [Test]
        public void TypewriterRevealsAtTheRateAndPausesAfterPunctuation()
        {
            var writer = new Typewriter { CharactersPerSecond = 10f, PauseSeconds = 0.5f, PauseCharacters = "." };
            int completed = 0;
            writer.Completed += () => completed++;
            writer.Start("<b>a.</b>bc");
            Assert.That(writer.Total, Is.EqualTo(4));
            writer.Tick(0.2f);
            Assert.That(writer.Visible, Is.EqualTo(2));
            writer.Tick(0.3f);
            Assert.That(writer.Visible, Is.EqualTo(2), "Waits after the period");
            writer.Tick(0.35f);
            Assert.That(writer.Visible, Is.EqualTo(3));
            writer.Complete();
            Assert.That(writer.Visible, Is.EqualTo(4));
            Assert.That(completed, Is.EqualTo(1));
            writer.Complete();
            Assert.That(completed, Is.EqualTo(1), "Complete twice raises once");
        }
    }
}
