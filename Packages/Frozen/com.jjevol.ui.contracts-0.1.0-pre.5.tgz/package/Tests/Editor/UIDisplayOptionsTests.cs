using System;
using System.Globalization;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace jjevol.UI.Tests
{
    public sealed class UIDisplayOptionsTests
    {
        static readonly MethodInfo Reset = typeof(UIDisplayOptions).GetMethod("ResetState", BindingFlags.Static | BindingFlags.NonPublic);

        [TearDown]
        public void Cleanup() => Reset.Invoke(null, null);

        [Test]
        public void DefaultsShowEveryDigitInTheCurrentCulture()
        {
            Assert.That(UIDisplayOptions.DisplayCulture, Is.SameAs(CultureInfo.CurrentCulture));
            Assert.That(UIDisplayOptions.CurrentLanguage, Is.EqualTo(CultureInfo.CurrentCulture.Name));
            Assert.That(UIDisplayOptions.CurrentNumberFormat, Is.SameAs(NumberFormatProfile.Full));
            Assert.That(UIDisplayOptions.FormatNumber(1234567m), Is.EqualTo(1234567m.ToString("N0", CultureInfo.CurrentCulture)));
            Assert.That((UIDisplayOptions.Now - DateTime.UtcNow).Duration(), Is.LessThan(TimeSpan.FromMinutes(1)));
        }

        [Test]
        public void TheLanguagePicksTheProfileAndAnElementProfileWins()
        {
            UIDisplayOptions.Culture = () => CultureInfo.GetCultureInfo("de-DE");
            UIDisplayOptions.NumberFormat = new NumberFormatSettings(NumberFormatProfile.CreateThousands(1)).SetLanguage("ko", NumberFormatProfile.CreateKorean());
            Assert.That(UIDisplayOptions.CurrentLanguage, Is.EqualTo("de-DE"));
            Assert.That(UIDisplayOptions.FormatNumber(1500m), Is.EqualTo("1,5K"));
            Assert.That(UIDisplayOptions.FormatNumber(1500m, NumberFormatProfile.Full), Is.EqualTo("1.500"));

            UIDisplayOptions.Language = () => "ko-KR";
            Assert.That(UIDisplayOptions.FormatNumber(12345m), Is.EqualTo(NumberFormat.Format(12345m, NumberFormatProfile.CreateKorean(), CultureInfo.GetCultureInfo("de-DE"))));
        }

        [Test]
        public void AbbreviateKeepsAnAbbreviatedProfileAndOtherwiseUsesTheLanguageDefault()
        {
            UIDisplayOptions.Language = () => "en-US";
            NumberFormatProfile own = NumberFormatProfile.CreateThousands(2);
            Assert.That(UIDisplayOptions.AbbreviatedNumberFormat(own), Is.SameAs(own));
            Assert.That(UIDisplayOptions.AbbreviatedNumberFormat(NumberFormatProfile.Full).Notation, Is.EqualTo(NumberNotation.Abbreviated));

            NumberFormatProfile gameWide = NumberFormatProfile.CreateThousands(1);
            UIDisplayOptions.NumberFormat = new NumberFormatSettings(gameWide);
            Assert.That(UIDisplayOptions.AbbreviatedNumberFormat(), Is.SameAs(gameWide));
            Assert.That(UIDisplayOptions.AbbreviatedNumberFormat(NumberFormatProfile.Full), Is.Not.SameAs(gameWide), "the element profile wins before abbreviating");
        }

        [Test]
        public void TheTrustedClockIsUsed()
        {
            var server = new DateTime(2026, 11, 20, 12, 0, 0, DateTimeKind.Utc);
            UIDisplayOptions.UtcNow = () => server;
            Assert.That(UIDisplayOptions.Now, Is.EqualTo(server));
        }

        [Test]
        public void StateResetsAtSubsystemRegistration()
        {
            Assert.That(Reset, Is.Not.Null);
            var attribute = Reset.GetCustomAttributes<RuntimeInitializeOnLoadMethodAttribute>().Single();
            Assert.That(attribute.loadType, Is.EqualTo(RuntimeInitializeLoadType.SubsystemRegistration));

            int notified = 0;
            UIDisplayOptions.Culture = () => CultureInfo.InvariantCulture;
            UIDisplayOptions.Language = () => "ko";
            UIDisplayOptions.NumberFormat = new NumberFormatSettings(NumberFormatProfile.CreateThousands(1));
            UIDisplayOptions.UtcNow = () => DateTime.MinValue;
            UIDisplayOptions.LocaleChanged += () => notified++;
            UIDisplayOptions.NotifyLocaleChanged();
            Assert.That(notified, Is.EqualTo(1));

            Reset.Invoke(null, null);
            UIDisplayOptions.NotifyLocaleChanged();
            Assert.That(notified, Is.EqualTo(1), "Subscriptions from an earlier Play session must not survive.");
            Assert.That(UIDisplayOptions.Culture, Is.Null);
            Assert.That(UIDisplayOptions.Language, Is.Null);
            Assert.That(UIDisplayOptions.NumberFormat, Is.Null);
            Assert.That(UIDisplayOptions.UtcNow, Is.Null);
        }
    }
}
