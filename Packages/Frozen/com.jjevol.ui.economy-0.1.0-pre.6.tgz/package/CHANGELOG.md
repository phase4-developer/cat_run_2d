# Changelog

## 0.1.0-pre.6 - 2026-11-11

- Depends on UI Addressables 0.1.0-pre.6, which brings `com.jjevol.ui.contracts`. No source change.

## 0.1.0-pre.5 - 2026-11-08

- Depends on `com.jjevol.economy@0.1.0-pre.4`. The repository now comes from `com.jjevol.data`; the Runtime and test assemblies reference `JJEvol.Data.Runtime`. No UI source change.

Unity compile and the 29 PlayMode tests passed on Hosts/UiEconomyValidationHost (job ui-economy-1, candidate 68e3857).

## 0.1.0-pre.4 - 2026-11-07

- Breaking: removed the `PriceBtn` `commonButton` field. Assign the Unity `Button` to `button`, or a `UIButtonLock` to `buttonLock` with the `lockedState` to show.

## 0.1.0-pre.3 - 2026-11-06

- Updated internal dependency versions. No source change.

Unity tests for this candidate are NOT_RUN.
