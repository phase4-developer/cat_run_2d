# JJEvol Economy UI — Container binding candidate

`com.jjevol.ui.economy@0.1.0-pre.6`은 외부에서 초기화한 ResourceService를 표시한다. UI가 Repository/Session/서비스를 생성하거나 저장 namespace·프로필·복구 정책을 결정하지 않는다. Economy 0.1.0-pre.4 / Data 0.1.0-pre.1 / Save 0.1.0-pre.3의 AES PlayerPrefs 계약을 사용하며 과거 파일 백엔드 Save tgz와 혼합하지 않는다. 고정 후보의 버전·SHA는 Framework 저장소의 `Docs/PackageInstallation.md`, 검증 범위는 `Docs/Guide/Verification.md`를 따른다. 이 폴더의 변경 가능한 소스와 설치할 고정 후보는 별도로 대조한다.

```csharp
// 게임 초기화에서 Repository/Storage 로드와 ResourceService 생성까지 완료한다.
resourceLabel.ShowUI(resources, gameWealthTypeId, itemId);
confirmedLabel.ShowUI(resources, gameWealthTypeId, itemId, ResourceQuantityView.Confirmed);
priceButton.ShowUI(resources, gamePrice);
priceLabel.ShowCosts(resources, gameCosts, gamePresentation);
priceButton.ShowFree(resources, gameLocalizedFreeText);
priceLabel.ShowProduct(resources, gamePrices, productId, quantity: 2);
```

ResourceLabel의 기본은 예약을 제외한 Get이고 Confirmed는 GetRaw다. 최초/재진입 시 조회하고 ResourceService.Changed의 item/type/profile·수량 변경 종류를 필터해 SetDirty 후 다시 읽는다. payload를 실제 잔액으로 보관하지 않는다. Quantity와 NumberAnimator 값은 표시/애니메이션 상태다. animateChanges를 Inspector에서 켜면 같은 서비스의 변경을 애니메이션으로 표시하며 신규 바인딩은 즉시 표시한다. 재화 범위 0..long.MaxValue와 decimal 애니메이션 끝점을 검증했다.

PriceLabel은 비용 DTO를 복제하고 중복 key를 checked long으로 합산하며, 동일 ResourceService.CheckSpend로 전체 비용을 검사한다. 미지원 종류·ID, 음수·범위·overflow는 유효 구매가로 표시하지 않는다. 여러 재화는 이름과 수량을 별도 행으로 표시하고 통화를 합산하지 않는다. Required는 단일 통화일 때만 의미가 있고 여러 통화에서는 0이다. 게임이 TMP 크기와 행 배치를 제공한다.

null 가격은 누락이다. 등록된 종류/ID의 비용 0은 유효한 0 비용이며 무료 상품과 같다고 추정하지 않는다. 무료 표시는 ShowFree로 명시하고 IsFree로 구분한다. 빈 ShowCosts는 ShowFree를 사용하도록 오류를 낸다. 무료 문구는 게임에서 지역화해 전달하고, 언어 변경 시 필요한 문구 갱신도 게임이 제공한다.

PriceBtn은 affordability와 별도 InputAllowed만 표시한다. 실제 Button/UnityEvent 입력은 게임의 구매 계층에 연결한다. UI에서 비용 선차감·보상·결제·저장 성공 판단을 하지 않는다. CanAfford는 금액 검사이며 거래 실행 승인이 아니다.

## 선택적인 Scene 연결부

LocalEconomyUIContext는 여러 widget에 서비스·표시 Provider·상품 가격 변경을 전달하는 비소유 연결부다. 필요 없으면 위 직접 바인딩을 쓴다.

```csharp
context.Bind(resources, gamePresentation);
context.SetProductPrices(gamePrices); // IProductPriceSource: GetPrice/Changed
resourceLabel.ShowUI(context, itemId);
priceLabel.ShowProduct(context, productId);
```

기존 Bind(LocalSaveRepository, WealthTable, factory)/Reconnect/파일 경로 Identity/Error 처리를 제거했다. 저장·서비스를 외부에서 준비한 후 Bind(ResourceService)를 호출한다. Identity는 프로필 식별이다. 다른 서비스로 Bind하거나 Unbind하면 이전 상품 Provider를 해제하므로 새 사용자의 가격 source를 다시 명시한다.

ConsumePresentation/게임 Provider로 table/name/description/icon/atlas/grade를 연결할 수 있다. Provider가 없을 때는 해당 서비스의 게임 WealthTable 메타데이터를 사용한다. 게임이 폰트·텍스트·아이콘·Atlas·테이블·Localization을 소유한다. 실제 수량 조회는 Provider나 table이 아닌 ResourceService다.

## 수명·이벤트·저장 상태

신규 바인딩은 ResourceService.Changed 인스턴스만 구독한다. OnDisable/Destroy에 해제하고 재활성화 시 최신값을 읽는다. Context/Provider 구독은 개별 식별로 오래된 callback을 차단한다. 서비스 Dispose는 서비스 수명 정보만 확인해 UI 연결을 정리한다. UI를 닫아도 사용자 Repository/서비스를 Dispose하지 않는다.

LocalAuthority의 Ready/IsDirty/Conflict/RecoveryRequired 및 ServerCache 오류 처리는 게임 상위 제어 계층이 판단한다. 필요하면 PriceBtn.SetInputAllowed로 잠그고 실제 구매 처리에서도 상태를 다시 검증한다. Label은 Reload·저장 retry·보상 재지급·초기화를 하지 않는다. dirty 메모리 표시를 durable 완료로 안내하지 않는다.

Session 서비스·LegacyEconomyUIEvents/static bridge·legacy kind/Identity fallback은 STEP 04-C에서 제거했다. 모든 widget은 Container를 참조하는 ResourceService만 받는다. Runtime asmdef의 Save 직접 참조도 제거했다. Economy의 Storage 기능을 통한 Save 전이 의존성은 유지한다. Context는 여러 widget/상품 가격 Provider를 연결하는 비소유 역할로 남기며 필요 없으면 직접 바인딩한다. 변경 API와 버전 경계는 CHANGELOG를 따른다.

## 검증

ContainerEconomyUIPlayTests 19개와 Container로 전환한 EconomyUIPlayTests 9개는 별도 fixture다. 후자는 기존 장수량·필터·구독·버튼·저장 실패·Locale·가격·Context 검증 범위를 유지한다. 실제 Canvas/TMP/Button에서 예약·확정·저장·복구·프로필 전환·수명·가격·Locale를 검증한다. 테스트 scene은 격리 Runtime Scene이며 제품 Prefab을 복사하지 않는다.

UI Core의 NumberAnimator/축약 formatter는 UIRuntimeOptions.DisplayCulture를 사용한다. UIBase와 기존 serialized widget 필드/GUID는 보존한다. 검증 범위는 Framework `Docs/Guide/Verification.md`를 따른다. Player/실기기/제품 화면 미감은 검증 완료가 아니며 현행 저장 의존성은 Economy 0.1.0-pre.4 / Data 0.1.0-pre.1 / Save 0.1.0-pre.3의 AES PlayerPrefs다. UI는 저장 매체를 소유하지 않는다. 이전 File.Replace 조사 기록은 Git 이력에 있다.

## 표시 metadata 조회 (STEP 05-E)

ResourceLabel은 이미 알고 있는 TypeId/ItemId로 Provider.TryResolve를 호출한다. 표시만을 위한 0수량 ConsumeData를 생성하지 않는다. 수량은 계속 ResourceService의 Raw/Available 조회와 instance Changed 이벤트를 사용한다. 표시 조회 실패는 아이콘을 비우며 정상 수량/HasData를 별도 게임 상태로 만들거나 0으로 덮지 않는다. Provider를 연결했을 때 실패를 WealthTable이나 다른 종류로 재해석하지 않는다. Provider가 없는 기존 Wealth 표시만 해당 서비스의 WealthTypeId/Definitions를 사용한다.

PriceLabel/PriceBtn/ShowProduct는 수량이 포함된 기존 ConsumeData Present 경로를 유지한다. 가격 합산/상품 배수·예약·버튼 상태는 변경하지 않는다. 기존 가격 정규화가 전달하는 DTO의 의미와, 원본 ConsumeData.Present가 보존하는 Source 의미를 구분한다. 현재 공통 패키지에 별도 ProductLabel 클래스는 없다.

LocalEconomyUIContext는 비소유 Provider/ResourceService 전달부로 유지한다. 기존 LocaleChanged 구독으로 metadata를 재조회하며 새 전역 Locator를 추가하지 않는다. Icon/Atlas key는 기존 AddressableImage에 전달하고, 로딩·실패·Rebind/Disable/Destroy lease 정책은 변경하지 않는다. 기본 Disable은 기존처럼 lease를 유지하고, ReleaseOnDisable 설정 또는 Destroy는 기존 로더가 반환한다.

`Tests/Integration~`는 실제 생성 enum, 게임 소유 ItemTable/Provider, 암호화 Resources와 빌드된 Atlas/Localization을 검증하는 opt-in 합성 게임 예제다. Runtime 패키지의 고정 게임 규칙이 아니며, 지정한 격리 Host에만 가져온다. 이 예제는 합본 시험에 들어 있지 않다.
