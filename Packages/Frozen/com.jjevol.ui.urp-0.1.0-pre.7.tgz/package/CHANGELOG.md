# Changelog

## 0.1.0-pre.7 - 2026-11-10

- A root ScreenSpaceCamera Canvas under the manager that has no camera is bound to the UI Camera, with one warning per creator. Unity reports such a Canvas as ScreenSpaceOverlay, so the creator sets the UI Camera and keeps it only if the Canvas then reads as ScreenSpaceCamera. Real Overlay Canvases are left as they were and remembered until the camera is rebound. Before this, a code-made Canvas without a camera was never bound.
- Tests: `CameralessScreenSpaceCameraCanvasIsBoundWithOneWarning`.

Unity 6000.3.9f1 on `Hosts/CombinedValidationHost`: the Editor tests in job `pkg1110-comb-edit-core-01` (62/62 with Data, Save and Scene.UI) and PlayMode with a graphics device, job `pkg1110-comb-play-urp-01`, 35/35 passed. Player is NOT_RUN.

## 0.1.0-pre.6 - 2026-11-09

- Compiles on Unity 6.7. `UIManagerCreater` keeps the requested and ready scene as `Scene`, not `Scene.handle`: 6.7 turns the handle into `SceneHandle` and makes its int conversion a compile error. Scene equality compares the handle on both 6000.3 and 6.7, and `default` stands for no scene where -1 did. These fields are private and not serialized.
- Tests only. `InstalledUrpAndAssemblyIdentityMatchValidatedCombination` checks URP 17.3.0 with 6000.3.9f1 on 6000.3 and URP 17.7.0 with 6000.7.0b8 on 6.7, which ships URP 17.7 as a built-in package.
- Tests only. If `UrpFixtureSetup.Setup` fails after taking its settings snapshot, it restores the Host's settings before rethrowing, since the test framework then skips `Cleanup`. This came after the 0.1.0-pre.5 tgz in the first delivery bundle, packed from master `ab3456c`, so that tgz does not have it. Runtime and Editor code are unchanged.

## 0.1.0-pre.5 - 2026-11-08

- Tests only. `UrpFixtureSetup` now restores what it changed after a run: the default and quality render pipeline, the sprite packer mode and the Addressables default settings object. `RebuildOwnFixtures` restores them too. The sprite packer mode is set to Sprite Atlas V2 at the start of every run, not only when the fixture is first authored, so a Host that keeps the fixture still packs its atlas.
- Tests only. The rendering test writes `urp-stack-composed.png` and `urp-base-only.png` to the Host's `Logs/UrpRendering/` instead of the folder above the Host.
- Runtime and Editor code are unchanged.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.4 - 2026-11-07

- Breaking: `UIManagerCreater` no longer starts itself. The game calls `StartInitAsync`, and only a started creator follows scene changes (`IsStarted`).
- Breaking: `InitScreenType` is removed. Open each scene's first screen from a scene initializer.
- `cashScreenTypes` and `cashHudTypes` are string IDs.

## 0.1.0-pre.3 - 2026-11-07

- README: a root Canvas created in code must have its camera assigned at creation. Documentation only.

## 0.1.0-pre.2 - 2026-11-06

- `UIManagerCreater` rebinds cameras only on change, removing the per frame Canvas walk and allocation.

Unity tests for this candidate are NOT_RUN.
