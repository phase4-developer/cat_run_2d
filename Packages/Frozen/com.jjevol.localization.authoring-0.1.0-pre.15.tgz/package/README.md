# JJEvol Localization Authoring

com.jjevol.localization.authoring@0.1.0-pre.15는 기존 사용자 제작 도구를 보존한 Editor 전용 선택 패키지입니다. 공식 릴리스와 소비 게임 적용은 별도입니다.

- GoogleSheetExporterWindow.cs의 실제 클래스는 GoogleSheetLocImporterWindow입니다. 원본 파일명·클래스명·메뉴·기존 serialized field·Script GUID를 유지합니다.
- `LocalizeTmpTextEvent`와 그 Inspector(`LocalizeTmpTextEventEditor`)는 0.1.0-pre.13부터 `com.jjevol.localization.tmp`에 있습니다. 이 패키지는 TMP를 참조하지 않습니다.
- Runtime은 com.jjevol.localization이 소유합니다. Runtime만 설치할 때 이 패키지나 Tables Authoring은 필요하지 않습니다.

## 설치와 경계

Unity 6000.3.9f1, Localization 1.5.12, Addressables 4.0.1, Newtonsoft 3.2.2 기준입니다. 필수 패키지는 Localization Runtime과 Tables Authoring입니다. CommonDataToolSettings.Current를 재사용하며 설정 타입을 복사하지 않습니다. JJEvol.Localization.Authoring.Editor는 Editor 전용입니다. Player 빌드·제품 적용을 Editor 시험으로 대체하지 않습니다.

메뉴는 `JJEvol/Localization/Sheet Import`입니다(창 제목 `Localization Sheet Import`). 창의 버튼은 Download & Preview이고, 자산은 Apply를 눌러야 바뀝니다. Google 다운로드는 소비자의 spreadsheet·권한·인증 설정을 사용합니다. 운영 키/Sheet는 UPM·테스트·문서에 포함하지 않습니다. 패키지를 설치하거나 창을 여는 것만으로 다운로드가 시작되지 않습니다.

Fetch Sheets는 시트 이름과 gid를 함께 받아 체크 목록으로 보여 줍니다. 처음에는 모두 체크되어 있고, 체크한 시트만 내려받습니다. Manual Sheets에는 `시트이름=gid`를 쉼표로 적습니다(예: `UI=0,Shop=1234567890`, gid는 시트 주소의 `#gid=` 뒤 숫자). 같은 시트 이름이 양쪽에 있으면 Fetch Sheets의 gid로 한 번만 받습니다. Spreadsheet를 바꾸면 Fetch Sheets를 다시 실행해야 합니다.

Manual Sheets는 0.1.0-pre.15부터 저장됩니다. 창을 열면 이 PC에 저장한 값이 있으면 그것을, 없으면 프로젝트 목록 `CommonDataToolSettings.Current.LocalizationSheets`(tables.authoring 0.1.0-pre.14, 기본 빈 값)를 채웁니다. 창에서 고친 값(Clear 포함)은 이 PC·이 프로젝트의 EditorPrefs(`JJEvol.Localization.Authoring.ManualSheets.<PlayerSettings.productGUID>`)에 남아 다음에 열 때 돌아옵니다. **Default**는 저장한 값을 지우고 프로젝트 목록으로 되돌립니다. 프로젝트 목록과 같은 값은 따로 저장하지 않으므로 그 뒤 프로젝트 목록이 바뀌면 창도 따라갑니다. 팀이 함께 쓸 목록은 게임의 `ICommonDataToolSettings` 구현에 `public string LocalizationSheets => "ui=0,msg=1";`처럼 적습니다. 기존 구현은 고치지 않아도 컴파일됩니다(인터페이스 기본 구현).

다운로드 주소는 `export?format=csv&gid=`입니다. gviz 조회 주소는 열 형식과 머리 행을 추측해 셀 값을 빠뜨리거나 합칠 수 있어 쓰지 않습니다.

API Key는 창과 함께 직렬화하지 않고 프로젝트 설정(`CommonDataToolSettings`)에서도 읽지 않습니다. 이 PC의 EditorPrefs(`JJEvol.Localization.Authoring.GoogleApiKey`)에만 저장하고, 입력란은 가려 표시합니다. Forget은 저장한 키를 지웁니다.

HTTP는 Editor update에서 비동기로 완료되며 요청별 Timeout·Cancel을 지원합니다. 창을 닫거나 컴파일 재로드/종료가 시작되면 대기 요청을 취소하고 늦은 응답을 적용하지 않습니다. 진단은 query·fragment·userinfo·인증값을 제거하고 HTTP 상태와 오류 원인을 표시합니다.

## 입력과 전체 교체 의미

다운로드 결과는 기존 CSV/TSV 파서로 준비합니다. 로컬 파일 시험과 아래 무인 가져오기도 같은 파서와 적용 경계를 호출합니다.

Locale 컬럼은 CultureInfo/Unity Add Locale 목록으로 검사합니다. 중복 Locale, 일반/지역 Locale 충돌, strict 모드의 누락 Locale/Table은 거절합니다. 끝나지 않은 quoted field·Locale/header 오류는 자산을 변경하기 전에 차단합니다. 로컬 파일 시험은 잘못된 UTF-8도 엄격하게 거절합니다.

## Preview 후 Apply

Download & Preview는 모든 시트를 받아 파싱만 하고 자산과 출력 파일을 바꾸지 않습니다. 컬렉션마다 기존·입력·추가·삭제 Key 수, 삭제 비율, 빈 Key 행 수(그중 텍스트가 있어 가져오지 않는 행 수), 삭제될 Key 앞 20개를 보여 줍니다. Apply나 Discard Preview를 눌러야 다른 입력을 편집할 수 있습니다.

- **Key 0건은 건너뜀(0.1.0-pre.15부터):** Key가 있는 행이 하나도 없는 시트(머리 행만 있거나, 텍스트는 있지만 Key가 빈 행뿐인 시트)는 그 시트만 건너뜁니다. 그 컬렉션은 만들지도, 지우지도, 바꾸지도 않으며 받은 사본도 다시 쓰지 않습니다. 기존 Key가 있어도 전체 삭제로 해석하지 않으므로 삭제 확인 대상이 아닙니다. Preview에 「Skipped (no Key rows)」와 기존 Key 수, 빈 Key 행 수(그중 텍스트가 있는 행 수)를 경고로 보여 주고 `[Loc Import] Skipped (no Key rows)` 경고 로그를 남깁니다. 나머지 시트는 평소대로 가져옵니다. 요청한 시트가 모두 Key 0건이면 가져올 것이 없으므로 Preview 단계에서 거절합니다. 머리 행·Locale 검사는 건너뛰는 시트에도 그대로 적용됩니다. pre.14까지는 한 시트만 Key 0건이어도 요청 전체를 거절했습니다.
- **삭제 확인:** 한 컬렉션이라도 기존 Key의 10%를 넘게 지우거나 51개 이상 지우면 삭제를 확인하는 체크를 켜야 Apply할 수 있습니다. 새 컬렉션은 지울 Key가 없으므로 해당하지 않습니다. 기준은 LocalizationImportImpact의 ConfirmationRatio·ConfirmationCount입니다.
- **Preview 유효 범위:** Preview 한 번은 Apply 시도 한 번에만 쓰입니다. Preview 뒤 컬렉션의 Key나 Key ID가 바뀌었으면 Apply를 거절하고 다시 Preview하게 합니다. Apply가 실패해도 Preview는 사라집니다. 창을 닫거나 도메인이 다시 로드되면 Preview는 버려지고 자산은 그대로입니다.

## 전체 교체 규칙

입력에서 빠진 Key는 SharedData와 모든 Locale Table에서 삭제하고 orphan entry를 정리하는 **전체 교체**입니다. Key는 SDK처럼 대소문자를 구별합니다. Title과 title은 별도 ID이며, 입력에 없는 exact Key는 남기지 않습니다. 동일 exact Key의 반복 행은 마지막 값이 이깁니다. 유지되는 exact Key의 ID와 기존 Locale/Table GUID를 보존합니다.

명시적인 빈 셀은 빈 번역 entry이며 없는 Key와 다릅니다. 짧은 행의 보정 셀은 기존처럼 null Value entry가 될 수 있습니다. 인용 구분자·중간 따옴표·내장 개행과 CleanText의 trim/BOM/zero-width/NBSP·양끝 따옴표 처리 의미를 유지합니다.

## 요청 전체 성공과 제한된 복구

한 번의 Preview·Apply 요청에 포함된 **모든 Collection·Locale·Key**가 성공해야 Completed입니다. 모든 다운로드와 파싱·요청 집합·SDK 출력 경로 소유권을 먼저 준비합니다. 일부 시트나 언어의 실패를 성공 개수로 집계하지 않습니다. 신규 Collection/Shared/Table의 SDK 예정 경로에 다른 자산이나 meta가 있으면 차단합니다.

적용 전에 요청 Collection/Shared/StringTable, 필요한 Locale, SDK가 연결하는 Addressables 설정·Group·Schema 및 다운로드 출력의 기존 bytes/meta/직렬화 상태를 보존합니다. 영향을 받는 기존 자산이 이미 dirty면 먼저 명시적으로 저장해야 합니다. 무관한 dirty 자산을 자동 저장하지 않습니다.

SDK 내부 SaveAssets도 **동기 적용 구간에서만** 소유 경로로 제한합니다. 최종 저장은 소유권·초기 dirty 상태·읽기 전용 여부를 확인한 자산을 명시적으로 dirty로 표시하고, 정확한 자기 경로의 scope 안에서 SaveAssetIfDirty로 수행합니다. 기존 Group/Schema의 보존용 snapshot은 저장 권한을 뜻하지 않습니다. 기존 Group에서는 요청 자산 GUID의 entry 변화만 쓰기 대상으로 인정하고, 다른 Group 속성·무관 entry·기존 Schema의 미저장 변경은 저장하거나 복원으로 덮지 않습니다. Addressables Settings에서는 이번 요청의 새 Group 참조와 Localization label 추가만 허용하고, 다른 설정값의 변경은 저장하거나 복구로 덮지 않습니다. 그런 변경이 요청 도중 끼면 RecoveryRequired로 남깁니다. 변경 없는 무관 dirty Group/Schema는 그대로 유지하며, 실제 필요한 Group 연결이 미저장 사용자 편집 때문에 지속될 수 없으면 완료하지 않습니다. 적용 후 값·exact Key·기존 ID/GUID·Locale/Addressables 연결을 다시 검사합니다. 적용 중 Localization label을 지정하며 Managed Sync/ApplyGlobal·배포를 자동 실행하지 않습니다.

저장 성공은 dirty flag나 AssetDatabase의 live cache만으로 판단하지 않습니다. 실제 파일에서 분리된 동일 타입의 비영속 ScriptableObject를 읽어 준비된 전체 직렬화 내용·GUID/meta/bytes를 확인하고, 로드와 정리 전후 live graph·dirty 상태·SDK cache identity가 보존되는지도 검사합니다. Addressables의 파생 m_currentHash만 비교에서 분리하며 실제 데이터·ID·참조는 생략하지 않습니다. 이 읽기 과정의 부작용이 감지되면 원본을 덮지 않고 RecoveryRequired로 남깁니다.

CSV/TSV 다운로드 출력은 ScriptableObject 저장과 분리해 실제 bytes/BOM 및 meta/GUID를 확인합니다. 반복 다운로드에서도 기존 출력 GUID를 유지하며, 실패 시 기록된 이전 bytes/meta를 복원합니다. 새 출력은 정확히 소유한 파일/meta부터 제거하고, 그 후 비어 있음이 확인된 자기 폴더만 정리합니다.
진행 중 예외·관측된 취소는 기록된 자기 변경을 복원하고 bytes/meta/GUID·Locale 등록을 확인합니다. 이번 요청이 만든 정확한 경로/GUID의 자산만 정리합니다. 무관한 새 Group/Schema의 소유권이 불분명하면 이를 삭제하거나 공유 설정으로 덮지 않습니다. 복구는 비어 있음이 확인된 자기 폴더만 정리합니다.

복구가 불확실하면 Library/JJEvol/LocalizationImport/pending.json을 보존하고 **RecoveryRequired**로 새 가져오기를 차단합니다. 창의 **Recover recorded import**에서만 명시적으로 재시도합니다. 수동 복구는 디스크 bytes/meta/GUID 및 관측한 Editor 직렬화 상태를 확인하므로, 이후 사용자가 Inspector에서 수정한 미저장 내용이나 외부 파일 변경을 덮어쓰지 않습니다. 불일치하면 기록을 유지한 채 복구를 거부합니다. 기록이나 사용자 편집을 임의 삭제해 차단을 우회하지 마세요.

이 복구는 Unity AssetDatabase의 원자적 트랜잭션이 아닙니다. 동기 적용 중 포착한 실패와 저장된 복구 체크포인트를 대상으로 합니다. Editor 강제 종료·전원 장애·디스크 고갈로 마지막 기록이 불완전하면 완전한 자동 복원을 보장하지 않으며, 다음 실행에서 성공이나 자동 재시도로 처리하지 않습니다. 원본과 체크포인트의 수동 확인이 필요합니다. Addressables Catalog·Runtime 수명 구조는 변경하지 않습니다.

## 무인 가져오기(AI·실행기 setup 잡)

0.1.0-pre.15부터 창을 열지 않고 같은 가져오기를 돌리는 진입점 `jjevol.LocalizationSheetBatchImport`가 있습니다. 창의 숨은 인스턴스를 그대로 구동하므로 파서, 머리 행·Locale 검사, Preview 계산, 삭제 확인 기준, 전체 교체, 트랜잭션 복구가 창과 같은 코드입니다. 경로와 주소는 `CommonDataToolSettings.Current`에서 읽습니다(시트 사본 `LocalizationInputDirectory`, 테이블 `LocalizationOutputDirectory`, 주소 `LocalizationSpreadsheet`).

| `-executeMethod` | 입력 | 인자 |
|---|---|---|
| `jjevol.LocalizationSheetBatchImport.ImportInputDirectoryAndExit` | 이미 받은 사본: `LocalizationInputDirectory`의 `*.tsv`·`*.csv`(하위 폴더 제외). 파일 이름이 컬렉션 이름이고 `.tsv`는 탭, `.csv`는 쉼표로 읽습니다. 사본은 다시 쓰지 않습니다 | 선택 `-jjevolLocSheets "ui,name"`(읽을 사본만 고름, 없는 이름은 거절), 선택 `-jjevolLocConfirmDeletion` |
| `jjevol.LocalizationSheetBatchImport.ImportSpreadsheetAndExit` | `LocalizationSpreadsheet`에서 받기. 창의 Download & Preview처럼 받은 시트를 `LocalizationInputDirectory`에 TSV(UTF-8 BOM)로 저장하고 적용합니다 | 선택 `-jjevolLocSheets "UI=0,Shop=1234567890"`(창의 Manual Sheets 형식). 없으면 창과 같은 목록(이 PC에 저장한 Manual Sheets, 없으면 `LocalizationSheets`)을 받고, 그것도 비었으면 `Failed`. 선택 `-jjevolLocConfirmDeletion`, 선택 `-jjevolLocTimeout <초>`(기본 30, 창과 같이 1~300으로 맞춤) |

종료 코드는 `LocalizationBatchImportOutcome`입니다. 배치 모드에서만 스스로 `EditorApplication.Exit`로 끝나며(`-quit` 불필요), Editor 창에서 부르면 로그만 남기고 끝내지 않습니다.

| 코드 | 결과 | 자산 |
|---|---|---|
| 0 `Completed` | 요청한 모든 컬렉션 적용 | 바뀜 |
| 1 `Failed` | 입력·머리 행·Locale·UTF-8 검사 거절, 모든 시트가 Key 0건, 적용 중 실패(되돌림 성공) | 그대로 |
| 2 `DeletionNotConfirmed` | 한 컬렉션이라도 기존 Key의 10% 초과 또는 51개 이상 삭제인데 `-jjevolLocConfirmDeletion`이 없음 | 그대로 |
| 3 `RecoveryRequired` | 앞선 가져오기가 미해결이거나 이번 실패의 복구가 불확실 | 창의 Recover recorded import로 처리 |

로그는 `[JJEvol Localization Batch]`로 시작합니다. 컬렉션마다 창의 Preview 설명(기존·입력·추가·삭제 Key 수와 삭제 Key 앞 20개)을 남기고, 끝에 결과와 컬렉션별 `existing, incoming, added, removed` 줄을 남깁니다. 성공은 `Debug.Log`, 그 밖은 `Debug.LogError`입니다.

- **삭제 확인은 인자로만 넘깁니다.** 기본은 거절이고 창의 체크 상자와 같은 기준입니다. 거절되면 Preview를 버리고 아무것도 바꾸지 않습니다.
- **Key 0건 시트·사본은 창과 같이 건너뜁니다.** 그 컬렉션은 바꾸지 않고 결과의 `SkippedSheets`와 로그에 남깁니다(`Collections`에는 들어가지 않음). 모두 Key 0건이면 `Failed`입니다.
- 한 사본이라도 검사에서 거절되면 요청 전체가 멈추고 어떤 자산도 바뀌지 않습니다.
- 시트에서 받기는 API Key를 쓰지 않습니다. 시트가 링크로 읽을 수 있어야 하며, 창과 같이 비공개 시트 인증 흐름은 없습니다.
- 중앙 실행기의 `setup` 잡은 메서드 인자를 넘기지 않습니다. 그 경로로는 `ImportInputDirectoryAndExit`(모든 사본) 또는 `ImportSpreadsheetAndExit`(창과 같은 시트 목록)를 삭제 확인 없이 돌리게 됩니다. 큰 삭제는 창에서 확인하거나 인자를 넘길 수 있는 실행으로 처리합니다.

C#에서는 `LocalizationSheetBatchImport.ImportInputDirectory(options)`(동기)와 `ImportSpreadsheetAsync(options)`가 `LocalizationBatchImportResult`(`Outcome`, `ExitCode`, `Collections`, `SkippedSheets`, `Message`)를 돌려줍니다. `LocalizationBatchImportOptions`의 `Sheets`·`ConfirmDeletion`·`TimeoutSeconds`가 위 인자와 같습니다.

## Player 빌드 전 검사

`Localization` 레이블이 붙은 StringTable의 Locale이 등록되어 있지 않으면 `LocalizationManager` 초기화가 실행 중 실패합니다. 그래서 Player 빌드를 시작할 때 이런 테이블을 찾아 경로와 Locale 코드를 알려 주고 빌드를 멈춥니다. Localization Settings에 Locale을 추가하거나 테이블을 제거하면 됩니다. 빌드에서 제외한 Addressables Group은 검사하지 않습니다.

## 검증 기록

STEP24 보고서는 당시의 로컬 importer/Inspector 검증 기록입니다. 이후 변경의 검증 범위·고정 후보는 현재 Framework 내부 보완 검증 결과를 따릅니다. 실제 Google 인증·운영 Sheet·제품 콘텐츠 검증을 합성/loopback 시험과 구분해야 합니다.

RecoveryRestartProofTests의 두 Explicit 시험은 정확한 메서드를 서로 다른 Editor 프로세스에서 실행해야 합니다. CreatePendingImport가 제한된 실패·복구 기록과 신규 다운로드 출력을 남기고, RecoverPendingImportAfterEditorRestart가 재시작 후 기존 bytes/ID/GUID 보존 및 정상 재실행을 확인합니다. 같은 프로세스의 두 번째 호출을 재시작 증거로 인정하지 않습니다.
