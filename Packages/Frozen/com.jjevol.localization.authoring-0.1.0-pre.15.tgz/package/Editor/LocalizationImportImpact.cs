using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

/// <summary>What one prepared full replacement does to a collection's keys, before any asset changes.</summary>
internal sealed class LocalizationImportImpact
{
    internal const double ConfirmationRatio = 0.1;
    internal const int ConfirmationCount = 50;
    private const int ListedKeyLimit = 20;

    internal string Collection { get; }
    internal int ExistingKeys { get; }
    internal int IncomingKeys { get; }
    internal int AddedKeys { get; }
    internal IReadOnlyList<string> RemovedKeys { get; }
    /// <summary>Rows without a Key are skipped by the import. Rows that also carry text lose that text.</summary>
    internal int EmptyKeyRows { get; }
    internal int EmptyKeyRowsWithText { get; }
    /// <summary>The sheet has no Key rows. The import leaves its collection as it is, so nothing is added or removed.</summary>
    internal bool Skipped { get; }
    internal double RemovedRatio => ExistingKeys == 0 ? 0 : (double)RemovedKeys.Count / ExistingKeys;
    internal bool RequiresConfirmation => RemovedKeys.Count > ConfirmationCount || RemovedRatio > ConfirmationRatio;

    internal LocalizationImportImpact(string collection, IEnumerable<string> existingKeys, IEnumerable<string> incomingKeys, int emptyKeyRows, int emptyKeyRowsWithText)
        : this(collection, existingKeys, incomingKeys, emptyKeyRows, emptyKeyRowsWithText, false) { }

    internal LocalizationImportImpact(string collection, IEnumerable<string> existingKeys, IEnumerable<string> incomingKeys, int emptyKeyRows, int emptyKeyRowsWithText, bool skipped)
    {
        var existing = new HashSet<string>(existingKeys, StringComparer.Ordinal);
        var incoming = new HashSet<string>(incomingKeys, StringComparer.Ordinal);
        Collection = collection; ExistingKeys = existing.Count; IncomingKeys = incoming.Count;
        Skipped = skipped;
        AddedKeys = skipped ? 0 : incoming.Count(key => !existing.Contains(key));
        RemovedKeys = Array.AsReadOnly(skipped ? Array.Empty<string>() : existing.Where(key => !incoming.Contains(key)).OrderBy(key => key, StringComparer.Ordinal).ToArray());
        EmptyKeyRows = emptyKeyRows; EmptyKeyRowsWithText = emptyKeyRowsWithText;
    }

    internal string Describe()
    {
        if (Skipped) return $"{Collection}\nSkipped (no Key rows): the collection is left unchanged, {ExistingKeys} existing keys kept\nEmpty Key rows: {EmptyKeyRows} ({EmptyKeyRowsWithText} with text that will not be imported)";
        string ratio = (RemovedRatio * 100).ToString("0.#", CultureInfo.InvariantCulture);
        string text = $"{Collection}\nKeys: {ExistingKeys} existing, {IncomingKeys} in sheet, {AddedKeys} added, {RemovedKeys.Count} removed ({ratio}%)\nEmpty Key rows: {EmptyKeyRows} ({EmptyKeyRowsWithText} with text that will not be imported)";
        if (RemovedKeys.Count == 0) return text;
        text += "\nRemoved: " + string.Join(", ", RemovedKeys.Take(ListedKeyLimit));
        return RemovedKeys.Count > ListedKeyLimit ? text + $" and {RemovedKeys.Count - ListedKeyLimit} more" : text;
    }
}
