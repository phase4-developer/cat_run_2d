using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;

[assembly: InternalsVisibleTo("JJEvol.Localization.Authoring.Tests.Editor")]

namespace jjevol
{
    /// <summary>How an unattended import ended. The value is the process exit code of the -executeMethod entries.</summary>
    public enum LocalizationBatchImportOutcome
    {
        Completed = 0,
        /// <summary>Input, header, Locale or Apply check refused the request. No asset changed, or the change was rolled back.</summary>
        Failed = 1,
        /// <summary>A collection would lose more than 10% or more than 50 of its keys and the deletion was not confirmed. No asset changed.</summary>
        DeletionNotConfirmed = 2,
        /// <summary>A previous import is unresolved. New imports are blocked until it is recovered in the Sheet Import window.</summary>
        RecoveryRequired = 3,
    }

    /// <summary>What one collection's full replacement does, as the window's Preview reports it.</summary>
    public sealed class LocalizationBatchCollectionResult
    {
        public string Collection { get; }
        public int ExistingKeys { get; }
        public int IncomingKeys { get; }
        public int AddedKeys { get; }
        public IReadOnlyList<string> RemovedKeys { get; }
        public bool RequiresConfirmation { get; }

        internal LocalizationBatchCollectionResult(LocalizationImportImpact impact)
        {
            Collection = impact.Collection; ExistingKeys = impact.ExistingKeys; IncomingKeys = impact.IncomingKeys;
            AddedKeys = impact.AddedKeys; RemovedKeys = impact.RemovedKeys; RequiresConfirmation = impact.RequiresConfirmation;
        }

        public override string ToString()
            => string.Format(CultureInfo.InvariantCulture, "{0}: {1} existing, {2} incoming, {3} added, {4} removed{5}",
                Collection, ExistingKeys, IncomingKeys, AddedKeys, RemovedKeys.Count, RequiresConfirmation ? " (deletion needs confirmation)" : string.Empty);
    }

    public sealed class LocalizationBatchImportResult
    {
        public LocalizationBatchImportOutcome Outcome { get; }
        public int ExitCode => (int)Outcome;
        public bool Applied => Outcome == LocalizationBatchImportOutcome.Completed;
        /// <summary>Empty when the request stopped before Preview.</summary>
        public IReadOnlyList<LocalizationBatchCollectionResult> Collections { get; }
        /// <summary>Sheets without Key rows. They are skipped and their collections left unchanged.</summary>
        public IReadOnlyList<string> SkippedSheets { get; }
        public string Message { get; }

        internal LocalizationBatchImportResult(LocalizationBatchImportOutcome outcome, string message, IReadOnlyList<LocalizationBatchCollectionResult> collections = null, IReadOnlyList<string> skipped = null)
        {
            Outcome = outcome; Message = message ?? string.Empty;
            Collections = collections ?? Array.Empty<LocalizationBatchCollectionResult>();
            SkippedSheets = skipped ?? Array.Empty<string>();
        }

        public override string ToString()
        {
            var lines = new List<string> { $"{Outcome} (exit {ExitCode}){(Message.Length == 0 ? string.Empty : ": " + Message)}" };
            lines.AddRange(Collections.Select(collection => "  " + collection));
            if (SkippedSheets.Count != 0) lines.Add("  skipped, no Key rows (collection unchanged): " + string.Join(", ", SkippedSheets));
            return string.Join("\n", lines);
        }
    }

    public sealed class LocalizationBatchImportOptions
    {
        /// <summary>Spreadsheet mode: <c>Name=gid</c>, comma-separated, as the window's Manual Sheets. Empty uses the window's list:
        /// this PC's saved Manual Sheets, else <c>CommonDataToolSettings.Current.LocalizationSheets</c>.
        /// Input folder mode: optional names (<c>Name</c> or <c>Name=gid</c>) that limit the copies read; empty reads every copy.</summary>
        public string Sheets { get; set; } = string.Empty;
        /// <summary>The window's deletion check box. Without it a request that deletes more than 10% or more than 50 keys of a collection is refused.</summary>
        public bool ConfirmDeletion { get; set; }
        public int TimeoutSeconds { get; set; } = 30;
        internal Func<string, int, CancellationToken, Task<string>> RequestText { get; set; }
    }

    /// <summary>
    /// Unattended import through the Sheet Import window's own implementation: the same parser, header and Locale checks,
    /// Preview, deletion check, full replacement and recoverable transaction. Paths and the spreadsheet come from
    /// <see cref="CommonDataToolSettings.Current"/>: sheet copies in LocalizationInputDirectory, tables in LocalizationOutputDirectory.
    /// </summary>
    public static class LocalizationSheetBatchImport
    {
        public const string SheetsArgument = "-jjevolLocSheets";
        public const string ConfirmDeletionArgument = "-jjevolLocConfirmDeletion";
        public const string TimeoutArgument = "-jjevolLocTimeout";
        private const string LogPrefix = "[JJEvol Localization Batch] ";

        /// <summary>
        /// -executeMethod jjevol.LocalizationSheetBatchImport.ImportInputDirectoryAndExit
        ///   [-jjevolLocSheets "ui,name"] [-jjevolLocConfirmDeletion]
        /// Reads the copies already in LocalizationInputDirectory. In batch mode the Editor exits with <see cref="LocalizationBatchImportOutcome"/>.
        /// </summary>
        public static void ImportInputDirectoryAndExit()
        {
            LocalizationBatchImportResult result;
            try { result = ImportInputDirectory(ParseCommandLine(Environment.GetCommandLineArgs())); }
            catch (Exception error) { result = Unexpected(error); }
            Exit(result);
        }

        /// <summary>
        /// -executeMethod jjevol.LocalizationSheetBatchImport.ImportSpreadsheetAndExit
        ///   [-jjevolLocSheets "UI=0,Shop=1234567890"] [-jjevolLocConfirmDeletion] [-jjevolLocTimeout 30]
        /// Without -jjevolLocSheets it downloads the window's list (saved Manual Sheets, else LocalizationSheets).
        /// Downloads LocalizationSpreadsheet, saves each sheet to LocalizationInputDirectory like the window, and applies it.
        /// The Editor keeps updating until the downloads finish, then exits in batch mode.
        /// </summary>
        public static void ImportSpreadsheetAndExit()
        {
            Task<LocalizationBatchImportResult> import;
            try { import = ImportSpreadsheetAsync(ParseCommandLine(Environment.GetCommandLineArgs())); }
            catch (Exception error) { Exit(Unexpected(error)); return; }
            EditorApplication.CallbackFunction wait = null;
            wait = () =>
            {
                if (!import.IsCompleted) return;
                EditorApplication.update -= wait;
                Exit(import.Status == TaskStatus.RanToCompletion ? import.Result : Unexpected(import.Exception?.GetBaseException() ?? new OperationCanceledException()));
            };
            EditorApplication.update += wait;
        }

        /// <summary>Imports the *.tsv/*.csv copies in LocalizationInputDirectory. Each file name is its collection name.</summary>
        public static LocalizationBatchImportResult ImportInputDirectory(LocalizationBatchImportOptions options = null)
        {
            options ??= new LocalizationBatchImportOptions();
            if (LocalizationImportTransaction.RecoveryRequired) return Log(RecoveryBlocked());
            var settings = CommonDataToolSettings.Current;
            string input = settings.LocalizationInputDirectory;
            if (string.IsNullOrWhiteSpace(input) || !Directory.Exists(input))
                return Log(new LocalizationBatchImportResult(LocalizationBatchImportOutcome.Failed, "LocalizationInputDirectory does not exist: " + input));
            var files = Directory.GetFiles(input, "*.*", SearchOption.TopDirectoryOnly)
                .Where(path => IsSheetCopy(path)).Select(path => path.Replace('\\', '/'))
                .OrderBy(path => path, StringComparer.Ordinal).ToList();
            var names = SheetNames(options.Sheets);
            if (names.Count != 0)
            {
                var missing = names.Where(name => !files.Any(path => string.Equals(Path.GetFileNameWithoutExtension(path), name, StringComparison.Ordinal))).ToArray();
                if (missing.Length != 0)
                    return Log(new LocalizationBatchImportResult(LocalizationBatchImportOutcome.Failed, "No *.tsv/*.csv copy in " + input + " for: " + string.Join(", ", missing)));
                files = files.Where(path => names.Contains(Path.GetFileNameWithoutExtension(path))).ToList();
            }
            if (files.Count == 0)
                return Log(new LocalizationBatchImportResult(LocalizationBatchImportOutcome.Failed, "No *.tsv/*.csv copy in " + input));
            var window = CreateWindow(settings, string.Empty, string.Empty, options);
            try
            {
                var preview = window.PreviewLocalFiles(files);
                if (!preview.IsCompleted) throw new InvalidOperationException("Reading the input copies did not finish synchronously.");
                return Log(PreviewThenApply(window, options));
            }
            finally { UnityEngine.Object.DestroyImmediate(window); }
        }

        /// <summary>Downloads the listed sheets of LocalizationSpreadsheet, then imports them as the window's Download &amp; Preview and Apply do.</summary>
        public static async Task<LocalizationBatchImportResult> ImportSpreadsheetAsync(LocalizationBatchImportOptions options)
        {
            options ??= new LocalizationBatchImportOptions();
            if (LocalizationImportTransaction.RecoveryRequired) return Log(RecoveryBlocked());
            // Without -jjevolLocSheets the list is the window's: this PC's saved Manual Sheets, else the project's LocalizationSheets.
            string sheets = string.IsNullOrWhiteSpace(options.Sheets) ? GoogleSheetLocImporterWindow.SavedOrProjectSheets() : options.Sheets;
            if (string.IsNullOrWhiteSpace(sheets))
                return Log(new LocalizationBatchImportResult(LocalizationBatchImportOutcome.Failed, "Spreadsheet mode needs the sheets as Name=gid: set CommonDataToolSettings.Current.LocalizationSheets, save Manual Sheets in the window, or pass " + SheetsArgument + " \"UI=0,Shop=1234567890\"."));
            var settings = CommonDataToolSettings.Current;
            if (string.IsNullOrWhiteSpace(settings.LocalizationSpreadsheet))
                return Log(new LocalizationBatchImportResult(LocalizationBatchImportOutcome.Failed, "CommonDataToolSettings.Current.LocalizationSpreadsheet is empty."));
            var window = CreateWindow(settings, settings.LocalizationSpreadsheet, sheets, options);
            try
            {
                await window.DownloadAndPreview();
                return Log(PreviewThenApply(window, options));
            }
            finally { if (window) UnityEngine.Object.DestroyImmediate(window); }
        }

        internal static LocalizationBatchImportOptions ParseCommandLine(IReadOnlyList<string> args)
        {
            var options = new LocalizationBatchImportOptions();
            for (int index = 0; index < (args?.Count ?? 0); ++index)
            {
                string arg = args[index];
                if (string.Equals(arg, ConfirmDeletionArgument, StringComparison.OrdinalIgnoreCase)) options.ConfirmDeletion = true;
                else if (string.Equals(arg, SheetsArgument, StringComparison.OrdinalIgnoreCase))
                    options.Sheets = index + 1 < args.Count ? args[++index] : throw new ArgumentException(SheetsArgument + " needs a value.");
                else if (string.Equals(arg, TimeoutArgument, StringComparison.OrdinalIgnoreCase))
                {
                    if (index + 1 >= args.Count || !int.TryParse(args[++index], NumberStyles.None, CultureInfo.InvariantCulture, out int seconds) || seconds < 1)
                        throw new ArgumentException(TimeoutArgument + " needs a positive number of seconds.");
                    options.TimeoutSeconds = seconds;
                }
            }
            return options;
        }

        private static GoogleSheetLocImporterWindow CreateWindow(ICommonDataToolSettings settings, string spreadsheet, string sheets, LocalizationBatchImportOptions options)
        {
            var window = ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            window.hideFlags = HideFlags.HideAndDontSave;
            window.ConfigureForBatch(spreadsheet, sheets, settings.LocalizationInputDirectory, settings.LocalizationOutputDirectory, options.TimeoutSeconds, options.RequestText);
            return window;
        }

        // The window's Preview → (deletion check) → Apply, with the check box replaced by ConfirmDeletion.
        private static LocalizationBatchImportResult PreviewThenApply(GoogleSheetLocImporterWindow window, LocalizationBatchImportOptions options)
        {
            if (window.ImportStatus != "PreviewReady") return Stopped(window, null);
            var collections = window.PreviewImpacts.Where(impact => !impact.Skipped).Select(impact => new LocalizationBatchCollectionResult(impact)).ToArray();
            var skipped = window.PreviewImpacts.Where(impact => impact.Skipped).Select(impact => impact.Collection).ToArray();
            foreach (var impact in window.PreviewImpacts) Debug.Log(LogPrefix + "Preview\n" + impact.Describe());
            if (!options.ConfirmDeletion && collections.Any(collection => collection.RequiresConfirmation))
            {
                window.DiscardPreview();
                return new LocalizationBatchImportResult(LocalizationBatchImportOutcome.DeletionNotConfirmed,
                    "The deletion above needs confirmation (" + ConfirmDeletionArgument + "). No asset changed.", collections, skipped);
            }
            var apply = window.ApplyPreview(options.ConfirmDeletion);
            if (!apply.IsCompleted) throw new InvalidOperationException("Apply did not finish synchronously.");
            return window.ImportStatus == "Completed" ? new LocalizationBatchImportResult(LocalizationBatchImportOutcome.Completed, null, collections, skipped) : Stopped(window, collections, skipped);
        }

        private static LocalizationBatchImportResult Stopped(GoogleSheetLocImporterWindow window, IReadOnlyList<LocalizationBatchCollectionResult> collections, IReadOnlyList<string> skipped = null)
            => window.ImportStatus == "RecoveryRequired"
                ? new LocalizationBatchImportResult(LocalizationBatchImportOutcome.RecoveryRequired, window.LastError ?? RecoveryBlocked().Message, collections, skipped)
                : new LocalizationBatchImportResult(LocalizationBatchImportOutcome.Failed, window.LastError ?? window.ImportStatus, collections, skipped);

        private static LocalizationBatchImportResult RecoveryBlocked()
            => new LocalizationBatchImportResult(LocalizationBatchImportOutcome.RecoveryRequired,
                "A previous import is unresolved (" + LocalizationImportTransaction.JournalPath + "). Recover it in JJEvol/Localization/Sheet Import before importing again.");

        private static LocalizationBatchImportResult Unexpected(Exception error)
        {
            Debug.LogException(error);
            return new LocalizationBatchImportResult(LocalizationImportTransaction.RecoveryRequired ? LocalizationBatchImportOutcome.RecoveryRequired : LocalizationBatchImportOutcome.Failed, error.Message);
        }

        private static bool IsSheetCopy(string path)
        {
            string extension = Path.GetExtension(path);
            return string.Equals(extension, ".tsv", StringComparison.OrdinalIgnoreCase) || string.Equals(extension, ".csv", StringComparison.OrdinalIgnoreCase);
        }

        private static HashSet<string> SheetNames(string sheets)
            => new HashSet<string>((sheets ?? string.Empty).Split(',').Select(entry => entry.Trim()).Where(entry => entry.Length != 0)
                .Select(entry => { int separator = entry.LastIndexOf('='); return (separator > 0 ? entry.Substring(0, separator) : entry).Trim(); }), StringComparer.Ordinal);

        private static LocalizationBatchImportResult Log(LocalizationBatchImportResult result)
        {
            if (result.Applied) Debug.Log(LogPrefix + result);
            else Debug.LogError(LogPrefix + result);
            return result;
        }

        private static void Exit(LocalizationBatchImportResult result)
        {
            if (Application.isBatchMode) EditorApplication.Exit(result.ExitCode);
        }
    }
}
