using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Localization;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Tables;
using UnityEngine.TestTools;

namespace jjevol.Localization.Authoring.Tests
{
    /// <summary>Argument parsing needs no Localization assets, so it runs outside the approved fixture Host.</summary>
    public class BatchImportCommandLineTests
    {
        [Test] public void DefaultsRefuseDeletionAndReadEveryCopy()
        {
            var options = LocalizationSheetBatchImport.ParseCommandLine(new[] { "Unity.exe", "-batchmode", "-executeMethod", "jjevol.LocalizationSheetBatchImport.ImportInputDirectoryAndExit" });
            Assert.IsFalse(options.ConfirmDeletion); Assert.AreEqual(string.Empty, options.Sheets); Assert.AreEqual(30, options.TimeoutSeconds);
        }

        [Test] public void ArgumentsSetSheetsConfirmationAndTimeout()
        {
            var options = LocalizationSheetBatchImport.ParseCommandLine(new[] { "-jjevolLocSheets", "UI=0,Shop=12", "-JJEVOLLOCCONFIRMDELETION", "-jjevolLocTimeout", "45" });
            Assert.AreEqual("UI=0,Shop=12", options.Sheets); Assert.IsTrue(options.ConfirmDeletion); Assert.AreEqual(45, options.TimeoutSeconds);
        }

        [Test] public void ArgumentWithoutAValidValueIsRejected()
        {
            foreach (var args in new[] { new[] { "-jjevolLocSheets" }, new[] { "-jjevolLocTimeout" }, new[] { "-jjevolLocTimeout", "0" }, new[] { "-jjevolLocTimeout", "ten" } })
                Assert.Throws<ArgumentException>(() => LocalizationSheetBatchImport.ParseCommandLine(args), string.Join(" ", args));
        }

        [Test] public void ExitCodesAreStable()
        {
            Assert.AreEqual(0, (int)LocalizationBatchImportOutcome.Completed); Assert.AreEqual(1, (int)LocalizationBatchImportOutcome.Failed);
            Assert.AreEqual(2, (int)LocalizationBatchImportOutcome.DeletionNotConfirmed); Assert.AreEqual(3, (int)LocalizationBatchImportOutcome.RecoveryRequired);
        }
    }

    /// <summary>The unattended entry against real Localization assets. Paths come from CommonDataToolSettings.Current, as in a game.</summary>
    public class BatchImportTests
    {
        private sealed class FixtureSettings : ICommonDataToolSettings
        {
            public string TableInputDirectory => "Assets/GameData/Table/TSV";
            public string TableOutputDirectory => "Assets/GameData/Table/Resources";
            public string LocalizationInputDirectory { get; set; }
            public string LocalizationOutputDirectory { get; set; }
            public string LocalizationSpreadsheet { get; set; } = string.Empty;
            public string LocalizationSheets { get; set; } = string.Empty;
        }

        private ICommonDataToolSettings previous;
        private FixtureSettings settings;
        private jjevol.Step24.Tests.HostResidue residue;
        private string first, second;
        private bool createdJournal;
        private string savedSheets;
        private static string Journal => (string)typeof(GoogleSheetLocImporterWindow).Assembly.GetType("LocalizationImportTransaction", true).GetProperty("JournalPath", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);

        [SetUp] public void Setup()
        {
            jjevol.Step24.Tests.ImportTestUtil.Guard();
            Assert.IsFalse(File.Exists(Journal), "A previous unresolved import must not be overwritten by tests.");
            string id = Guid.NewGuid().ToString("N"), directory = "Assets/T1LocalizationFixtures/batch_" + id;
            residue = new jjevol.Step24.Tests.HostResidue(directory);
            first = "bt_a_" + id; second = "bt_b_" + id;
            settings = new FixtureSettings { LocalizationInputDirectory = directory + "/Sheet", LocalizationOutputDirectory = directory + "/Tables" };
            Directory.CreateDirectory(settings.LocalizationInputDirectory); Directory.CreateDirectory(settings.LocalizationOutputDirectory); AssetDatabase.Refresh();
            previous = CommonDataToolSettings.Current; CommonDataToolSettings.Current = settings;
            // This PC's Manual Sheets for the Host project are put back after the test.
            string key = GoogleSheetLocImporterWindow.ManualSheetsPreference;
            savedSheets = EditorPrefs.HasKey(key) ? EditorPrefs.GetString(key) : null; EditorPrefs.DeleteKey(key);
        }

        [TearDown] public void Cleanup()
        {
            CommonDataToolSettings.Current = previous;
            if (savedSheets != null) EditorPrefs.SetString(GoogleSheetLocImporterWindow.ManualSheetsPreference, savedSheets);
            else EditorPrefs.DeleteKey(GoogleSheetLocImporterWindow.ManualSheetsPreference);
            LogAssert.ignoreFailingMessages = false;
            if (createdJournal) { File.Delete(Journal); createdJournal = false; }
            residue?.Clean();
        }

        private void Write(string name, string content, string extension = ".tsv") => File.WriteAllText(settings.LocalizationInputDirectory + "/" + name + extension, content, new UTF8Encoding(true));
        private static StringTable Table(string name, string locale) => LocalizationEditorSettings.GetStringTableCollection(name).GetTable(new LocaleIdentifier(locale)) as StringTable;
        private static LocalizationBatchCollectionResult Collection(LocalizationBatchImportResult result, string name) => result.Collections.Single(collection => collection.Collection == name);
        private LocalizationBatchImportResult Seed()
        {
            Write(first, "Key\tko\ten\nkeep\t유지\tkeep\nremove\t삭제\tremove\nthird\t셋\tthree");
            Write(second, "Key,ko,en\nhello,안녕,hello", ".csv");
            return LocalizationSheetBatchImport.ImportInputDirectory();
        }

        [Test] public void InputCopiesReplaceTheirCollectionsAndReportCounts()
        {
            var result = Seed();
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, result.Outcome, result.ToString()); Assert.AreEqual(0, result.ExitCode);
            Assert.AreEqual(3, Collection(result, first).AddedKeys); Assert.AreEqual(1, Collection(result, second).AddedKeys);
            Assert.AreEqual("삭제", Table(first, "ko").GetEntry("remove").Value); Assert.AreEqual("hello", Table(second, "en").GetEntry("hello").Value);
            var path = AssetDatabase.GetAssetPath(LocalizationEditorSettings.GetStringTableCollection(first));
            StringAssert.StartsWith(settings.LocalizationOutputDirectory + "/", path);

            Write(first, "Key\tko\ten\nkeep\t유지\tupdated\nremove\t삭제\tremove\nthird\t셋\tthree\nfresh\t새\tfresh");
            byte[] input = File.ReadAllBytes(settings.LocalizationInputDirectory + "/" + first + ".tsv");
            result = LocalizationSheetBatchImport.ImportInputDirectory();
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, result.Outcome, result.ToString());
            Assert.AreEqual(1, Collection(result, first).AddedKeys); Assert.AreEqual(0, Collection(result, first).RemovedKeys.Count); Assert.AreEqual(3, Collection(result, first).ExistingKeys);
            Assert.AreEqual("updated", Table(first, "en").GetEntry("keep").Value);
            CollectionAssert.AreEqual(input, File.ReadAllBytes(settings.LocalizationInputDirectory + "/" + first + ".tsv"), "The input copy is not written back.");
        }

        [Test] public void LargeDeletionIsRefusedUnlessConfirmed()
        {
            Assert.IsTrue(Seed().Applied);
            Write(first, "Key\tko\ten\nkeep\t유지\tkeep");
            LogAssert.ignoreFailingMessages = true;
            var refused = LocalizationSheetBatchImport.ImportInputDirectory();
            Assert.AreEqual(LocalizationBatchImportOutcome.DeletionNotConfirmed, refused.Outcome); Assert.AreEqual(2, refused.ExitCode);
            Assert.IsTrue(Collection(refused, first).RequiresConfirmation); CollectionAssert.AreEqual(new[] { "remove", "third" }, Collection(refused, first).RemovedKeys);
            Assert.NotNull(Table(first, "en").GetEntry("remove")); Assert.NotNull(Table(first, "en").GetEntry("third"));

            var confirmed = LocalizationSheetBatchImport.ImportInputDirectory(new LocalizationBatchImportOptions { ConfirmDeletion = true });
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, confirmed.Outcome, confirmed.ToString());
            Assert.AreEqual(2, Collection(confirmed, first).RemovedKeys.Count);
            Assert.IsNull(Table(first, "en").GetEntry("remove")); Assert.AreEqual(1, LocalizationEditorSettings.GetStringTableCollection(first).SharedData.Entries.Count);
        }

        [Test] public void OneInvalidCopyStopsTheWholeRequestBeforeAnyChange()
        {
            Assert.IsTrue(Seed().Applied);
            string path = AssetDatabase.GetAssetPath(Table(first, "en")); byte[] before = File.ReadAllBytes(path);
            Write(first, "Key\tko\ten\nkeep\t유지\tchanged\nremove\t삭제\tremove\nthird\t셋\tthree");
            Write(second, "Wrong,ko,en\nhello,안녕,hello", ".csv");
            LogAssert.ignoreFailingMessages = true;
            var result = LocalizationSheetBatchImport.ImportInputDirectory();
            Assert.AreEqual(LocalizationBatchImportOutcome.Failed, result.Outcome); Assert.AreEqual(1, result.ExitCode);
            StringAssert.Contains("key column", result.Message);
            Assert.AreEqual("keep", Table(first, "en").GetEntry("keep").Value); CollectionAssert.AreEqual(before, File.ReadAllBytes(path));
        }

        [Test] public void KeyLessCopyIsSkippedAndItsCollectionKept()
        {
            Assert.IsTrue(Seed().Applied);
            Write(first, "Key\tko\ten\r\n\t텍스트만\ttext only\r\n");
            Write(second, "Key,ko,en\nhello,안녕,hi", ".csv");
            var result = LocalizationSheetBatchImport.ImportInputDirectory();
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, result.Outcome, result.ToString());
            CollectionAssert.AreEqual(new[] { first }, result.SkippedSheets); Assert.AreEqual(1, result.Collections.Count);
            Assert.AreEqual(3, LocalizationEditorSettings.GetStringTableCollection(first).SharedData.Entries.Count); Assert.AreEqual("hi", Table(second, "en").GetEntry("hello").Value);
        }

        [Test] public void EveryCopyWithoutKeyRowsIsAFailure()
        {
            Write(first, "Key\tko\ten");
            LogAssert.ignoreFailingMessages = true;
            var result = LocalizationSheetBatchImport.ImportInputDirectory();
            Assert.AreEqual(LocalizationBatchImportOutcome.Failed, result.Outcome); Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(first));
        }

        [Test] public void SheetNamesLimitTheCopiesAndUnknownNamesAreRejected()
        {
            Write(first, "Key\tko\ten\na\t가\ta");
            Write(second, "Key,ko,en\nb,나,b", ".csv");
            var result = LocalizationSheetBatchImport.ImportInputDirectory(new LocalizationBatchImportOptions { Sheets = second + "=7" });
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, result.Outcome, result.ToString());
            Assert.AreEqual(second, result.Collections.Single().Collection); Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(first));

            LogAssert.ignoreFailingMessages = true;
            var unknown = LocalizationSheetBatchImport.ImportInputDirectory(new LocalizationBatchImportOptions { Sheets = first + ",absent" });
            Assert.AreEqual(LocalizationBatchImportOutcome.Failed, unknown.Outcome); StringAssert.Contains("absent", unknown.Message);
            Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(first));
        }

        [Test] public void UnresolvedImportBlocksWithRecoveryRequired()
        {
            Write(first, "Key\tko\ten\na\t가\ta");
            Directory.CreateDirectory(Path.GetDirectoryName(Journal)); File.WriteAllText(Journal, "{}"); createdJournal = true;
            LogAssert.ignoreFailingMessages = true;
            var result = LocalizationSheetBatchImport.ImportInputDirectory();
            Assert.AreEqual(LocalizationBatchImportOutcome.RecoveryRequired, result.Outcome); Assert.AreEqual(3, result.ExitCode);
            Assert.IsNull(LocalizationEditorSettings.GetStringTableCollection(first));
        }

        [Test] public void SpreadsheetModeDownloadsSavesTheCopyAndApplies()
        {
            settings.LocalizationSpreadsheet = "https://docs.google.com/spreadsheets/d/synthetic_spreadsheet_id_123456789/edit";
            string requested = null;
            var options = new LocalizationBatchImportOptions
            {
                Sheets = first + "=42",
                RequestText = (url, timeout, token) => { requested = url; return Task.FromResult("Key,ko,en\r\nhello,안녕,\"Hello, you\"\r\n"); },
            };
            var import = LocalizationSheetBatchImport.ImportSpreadsheetAsync(options);
            Assert.IsTrue(import.IsCompleted, "Synchronous responses finish inside the call.");
            var result = import.Result;
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, result.Outcome, result.ToString());
            Assert.AreEqual("https://docs.google.com/spreadsheets/d/synthetic_spreadsheet_id_123456789/export?format=csv&gid=42", requested);
            Assert.AreEqual("Hello, you", Table(first, "en").GetEntry("hello").Value);
            byte[] saved = File.ReadAllBytes(settings.LocalizationInputDirectory + "/" + first + ".tsv");
            CollectionAssert.AreEqual(Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes("Key\tko\ten\nhello\t안녕\tHello, you")).ToArray(), saved);
        }

        [Test] public void ManualSheetsStartFromTheProjectListAndAnEditIsKeptUntilDefault()
        {
            settings.LocalizationSheets = "ui=0,msg=1";
            GoogleSheetLocImporterWindow Open() => ScriptableObject.CreateInstance<GoogleSheetLocImporterWindow>();
            string Sheets(GoogleSheetLocImporterWindow window) => (string)typeof(GoogleSheetLocImporterWindow).GetField("manualSheets", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(window);
            var window = Open();
            try
            {
                Assert.AreEqual("ui=0,msg=1", Sheets(window)); Assert.IsFalse(EditorPrefs.HasKey(GoogleSheetLocImporterWindow.ManualSheetsPreference));
                window.StoreManualSheets("ui=0,msg=1,name=3");
                UnityEngine.Object.DestroyImmediate(window); window = Open();
                Assert.AreEqual("ui=0,msg=1,name=3", Sheets(window), "An edit survives closing and reopening the window.");
                window.StoreManualSheets(string.Empty);
                UnityEngine.Object.DestroyImmediate(window); window = Open();
                Assert.AreEqual(string.Empty, Sheets(window), "Clear is kept too.");
                window.StoreManualSheets(GoogleSheetLocImporterWindow.ProjectSheets);
                Assert.IsFalse(EditorPrefs.HasKey(GoogleSheetLocImporterWindow.ManualSheetsPreference), "Default removes the saved edit.");
                settings.LocalizationSheets = "ui=0";
                UnityEngine.Object.DestroyImmediate(window); window = Open();
                Assert.AreEqual("ui=0", Sheets(window), "Without an edit the window follows the project list.");
            }
            finally { UnityEngine.Object.DestroyImmediate(window); }
        }

        [Test] public void SpreadsheetModeUsesTheSavedOrProjectSheetsWithoutAnArgument()
        {
            settings.LocalizationSpreadsheet = "synthetic_spreadsheet_id_123456789";
            settings.LocalizationSheets = first + "=7";
            var requested = new System.Collections.Generic.List<string>();
            var options = new LocalizationBatchImportOptions { RequestText = (url, timeout, token) => { requested.Add(url); return Task.FromResult("Key,ko,en\nhello,안녕,hello"); } };
            var result = LocalizationSheetBatchImport.ImportSpreadsheetAsync(options).Result;
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, result.Outcome, result.ToString());
            StringAssert.EndsWith("gid=7", requested.Single());

            EditorPrefs.SetString(GoogleSheetLocImporterWindow.ManualSheetsPreference, second + "=9");
            result = LocalizationSheetBatchImport.ImportSpreadsheetAsync(options).Result;
            Assert.AreEqual(LocalizationBatchImportOutcome.Completed, result.Outcome, result.ToString());
            StringAssert.EndsWith("gid=9", requested.Last()); Assert.AreEqual(second, result.Collections.Single().Collection);
        }

        [Test] public void SpreadsheetModeNeedsSheetsAndASpreadsheet()
        {
            LogAssert.ignoreFailingMessages = true;
            var noSheets = LocalizationSheetBatchImport.ImportSpreadsheetAsync(new LocalizationBatchImportOptions());
            Assert.AreEqual(LocalizationBatchImportOutcome.Failed, noSheets.Result.Outcome);
            var noSpreadsheet = LocalizationSheetBatchImport.ImportSpreadsheetAsync(new LocalizationBatchImportOptions { Sheets = first + "=0", RequestText = (url, timeout, token) => Task.FromResult("Key,ko\na,가") });
            Assert.AreEqual(LocalizationBatchImportOutcome.Failed, noSpreadsheet.Result.Outcome); StringAssert.Contains("LocalizationSpreadsheet", noSpreadsheet.Result.Message);
        }
    }
}
