# Changelog

## 0.1.0-pre.4 - 2026-11-10

- Game data versions. `LocalSaveCodec` takes `dataVersion` (default 0), writes it as `dataVersion` in every envelope and runs `ILocalSaveMigration` steps from the stored data version up to it when a save is read. Saves written before this read as data version 0. Before this, migrations were keyed to the package's own format version, which is fixed at 1, so a game could not migrate its payload and changing the payload structure left existing players unable to open their save.
- A save with a higher data version than the codec's (an older app) is `UnsupportedVersion`. A missing step is `MigrationFailed`. Migration happens in memory on read; the stored values change only when the game saves.
- Breaking: `LocalSaveDocument.OriginalVersion` is replaced by `DataVersion` and `OriginalDataVersion`; `WasMigrated` compares those. `ILocalSaveMigration.FromVersion` is a data version. A format version other than 1 is `UnsupportedVersion`.
- Damaged slots are named. `LocalSaveLoadResult.SlotStatuses` gives each slot as read and `DamagedSlots` the corrupt ones; the Corrupt error message names them.
- `LocalSaveRepository.Repair()` is an explicit repair the game calls, never automatic. When exactly one slot is corrupt and the other holds an authenticated revision, it rewrites the damaged slot with that revision's snapshot as the next revision. Key, version, migration and storage failures, two damaged slots and two intact slots that do not form one history are refused.

Unity 6000.3.9f1 on `Hosts/CombinedValidationHost`: EditMode job `pkg1110-comb-edit-core-01` 62/62 (Data, Save, UI URP Editor, Scene.UI Editor) and PlayMode job `pkg1110-comb-play-save-01` 1/1 passed. Player and devices are NOT_RUN.

## 0.1.0-pre.3 — PlayerPrefs AES consolidation

Replaced the file backend with Unity PlayerPrefs and two alternating encrypted revisions. Removed path APIs, the file constructor, File.Replace/temporary-file/lock/archive protocols and their dedicated active tests. Historical logs and frozen candidates are preserved outside the package. Codec output now always requires a key. Corruption blocks normal opening/writing; explicit backup salvage is read-only. Unconfirmed writes preserve live memory and require outcome reconciliation before another mutation. Added real PlayerPrefs tests and an ignored independent Player QA harness. Consumers require an explicit API/key/profile migration after internal platform gates pass.

## 0.1.0-pre.2 — STEP 06-SAVE-R1 internal candidate

Game-provided AES-256-CBC/HMAC-SHA256 protection is required for repository writes. Existing Codec/Repository/Session constructor signatures and the inner v1 document schema remain available. Existing plaintext can be inspected with the legacy codec; it is never migrated or overwritten automatically. Missing keys, plaintext in a protected profile, unknown encryption versions/key IDs and oversized files block writes.

Windows error 1175 permits at most two replacement retries while the exact staged candidate, main and backup bytes are unchanged under both locks. Other error codes and uncertain/foreign states stop. Exact persisted main candidates are reconciled without applying a second mutation.

## 0.1.0-pre.1

Initial extraction from mobile ac18cfbdea56f03447a7d5927395d6bc88ddfd9f. Validation results are recorded outside the package.
