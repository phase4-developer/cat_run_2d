using System;
using System.Collections;
using System.Linq;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Tests
{
    public sealed class EncryptedSavePlayTests
    {
        [UnityTest] public IEnumerator RealPlayerPrefsSessionUpdatesAndReopensAcrossFrames()
        {
            string profile = "qa:" + Guid.NewGuid().ToString("N"); const string prefix = "qa.playerprefs.play";
            var codec = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("synthetic-play-v1", Enumerable.Range(0, 32).Select(i => (byte)i).ToArray()));
            var repository = new LocalSaveRepository(profile, codec, prefix);
            try
            {
                Func<int, LocalSaveSnapshot> snapshot = value => new LocalSaveSnapshot(new JObject { ["attempts"] = value });
                var session = LocalSaveSession.Open(repository, () => snapshot(0)); yield return null;
                session.CommitMutation(0, snapshot(1)); yield return null; session.CommitMutation(1, snapshot(2));
                var reopened = LocalSaveSession.Open(new LocalSaveRepository(profile, codec, prefix)); Assert.That(reopened.StateRevision, Is.EqualTo(2)); Assert.That((int)reopened.Snapshot.Payload["attempts"], Is.EqualTo(2));
            }
            finally { PlayerPrefs.DeleteKey(repository.Slot0Key); PlayerPrefs.DeleteKey(repository.Slot1Key); PlayerPrefs.Save(); }
        }
    }
}