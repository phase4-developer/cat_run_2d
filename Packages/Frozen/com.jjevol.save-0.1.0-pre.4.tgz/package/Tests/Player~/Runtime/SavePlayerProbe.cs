using System;
using System.IO;
using System.Linq;
using System.Text;
using jjevol;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace JJEvol.Save.PlayerQA
{
    // Explicitly copied to an independent QA Host. Never loaded by a consumer package by default.
    public static class SavePlayerProbe
    {
        private const string Prefix = "qa.playerprefs.player.r1";
        private const string Marker = "qa.playerprefs.player.r1.nextPhase";
        private static readonly byte[] SyntheticKey = Enumerable.Range(0, 32).Select(i => (byte)(31 - i)).ToArray();
        private static LocalSaveCodec Codec => LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("synthetic-player-only-v1", SyntheticKey));
        private static string Arg(string key, string fallback = null)
        {
            string[] args = Environment.GetCommandLineArgs(); int i = Array.IndexOf(args, key);
            return i >= 0 && i + 1 < args.Length ? args[i + 1] : fallback;
        }
        private static void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        private static LocalSaveRepository Store(string profile, ILocalSavePreferences preferences = null, LocalSaveCodec codec = null) => new LocalSaveRepository(profile, codec ?? Codec, Prefix, preferences);
        private static JObject Data(long value) => new JObject { ["wealthInfos"] = new JArray(new JObject { ["wealthType"] = "qa-gold", ["quantity"] = value }), ["privateProgress"] = "SYNTHETIC-PLAYER-PRIVATE-PROGRESS" };
        private static DataRepository Open(string profile, LocalSaveRepository store, out RepositoryStorageAdapter adapter, out WealthContainer wealth, bool create)
        {
            var repository = new DataRepository(profile); wealth = new WealthContainer(); repository.Register(wealth);
            adapter = RepositoryStorageAdapter.Open(repository, store, "qa:player:v1", RepositoryStorageMode.LocalAuthority, create ? () => Data(100) : (Func<JObject>)null);
            return repository;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Run()
        {
            string phase = Arg("-saveQaPhase", PlayerPrefs.GetString(Marker, "write"));
            string identity = Arg("-saveQaIdentity", "qa-player-a310"); LocalSaveRepository.ValidateProfileId(identity);
            string profile = identity + ":data", sessionProfile = identity + ":session", failureProfile = identity + ":failure";
            string output = Arg("-saveQaReport", Path.Combine(Application.persistentDataPath, "save-qa-" + phase + ".json"));
            var report = new JObject { ["phase"] = phase, ["platform"] = Application.platform.ToString(), ["unity"] = Application.unityVersion, ["company"] = Application.companyName, ["product"] = Application.productName, ["applicationId"] = Application.identifier, ["utc"] = DateTime.UtcNow.ToString("O"), ["keyKind"] = "synthetic-test-only" };
            try
            {
                Check(Application.companyName == "JJEvolQa20261104" && Application.productName == "PlayerPrefsAES_a310", "Independent QA Player identity required");
                if (Application.platform == RuntimePlatform.Android) Check(Application.identifier == "com.jjevol.qa.playerprefsaes.a310", "Unexpected QA Android application ID");
                var store = Store(profile);
                if (phase == "write")
                {
                    Check(store.Load().Status == LocalSaveLoadStatus.Missing, "Write phase requires a new synthetic profile");
                    using (var owner = Open(profile, store, out var adapter, out var wealth, true))
                    {
                        var original = wealth;
                        for (int i = 1; i <= 12; i++) { adapter.ApplyAndSave(Data(100 + i), true, "wealthInfos"); Check(ReferenceEquals(original, owner.Get<WealthContainer>("wealthInfos")), "Container identity changed"); }
                        Check(adapter.SavedRevision == 12 && wealth.Get("qa-gold") == 112, "First/continuous updates did not publish the expected state");
                        report["revision"] = adapter.SavedRevision; report["quantity"] = wealth.Get("qa-gold");
                    }
                    var session = LocalSaveSession.Open(Store(sessionProfile), () => new LocalSaveSnapshot(new JObject { ["checkpoint"] = 0 }));
                    session.CommitMutation(0, new LocalSaveSnapshot(new JObject { ["checkpoint"] = 1 })); report["sessionRevision"] = session.StateRevision;
                    PlayerPrefs.SetString(Marker, "reopen"); PlayerPrefs.Save();
                }
                else if (phase == "reopen")
                {
                    using (var owner = Open(profile, store, out var adapter, out var wealth, false))
                    {
                        Check(adapter.SavedRevision == 12 && wealth.Get("qa-gold") == 112, "Fresh Player process did not restore the exact state");
                        adapter.ApplyAndSave(Data(113), true, "wealthInfos"); Check(adapter.SavedRevision == 13, "First update after process restart failed"); report["revision"] = adapter.SavedRevision; report["quantity"] = wealth.Get("qa-gold");
                    }
                    var session = LocalSaveSession.Open(Store(sessionProfile)); Check(session.StateRevision == 1 && (int)session.Snapshot.Payload["checkpoint"] == 1, "Session restart mismatch");
                    PlayerPrefs.SetString(Marker, "verify"); PlayerPrefs.Save();
                }
                else if (phase == "verify")
                {
                    using (var owner = Open(profile, store, out var adapter, out var wealth, false)) { Check(adapter.SavedRevision == 13 && wealth.Get("qa-gold") == 113, "Second restart mismatch"); report["revision"] = adapter.SavedRevision; report["quantity"] = wealth.Get("qa-gold"); }
                    string[] before = Values(store);
                    var wrong = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("synthetic-player-only-v1", SyntheticKey.Reverse().ToArray()));
                    Check(!Store(profile, codec: wrong).Load().Success, "Wrong key was accepted"); Check(Values(store).SequenceEqual(before), "Wrong key altered stored values");
                    byte[] bytes = Convert.FromBase64String(before[1]); bytes[bytes.Length - 1] ^= 1;
                    try
                    {
                        PlayerPrefs.SetString(store.Slot1Key, Convert.ToBase64String(bytes)); PlayerPrefs.Save();
                        Check(store.Load().Status == LocalSaveLoadStatus.Corrupt, "Tampered slot was accepted"); var recovery = store.LoadRecovery();
                        Check(recovery.Status == LocalSaveLoadStatus.RecoveredBackup && recovery.Document.StateRevision == 12, "Explicit previous revision recovery failed");
                        report["wrongKeyRejected"] = true; report["tamperRejected"] = true; report["recoveryRevision"] = recovery.Document.StateRevision;
                    }
                    finally { PlayerPrefs.SetString(store.Slot1Key, before[1]); PlayerPrefs.Save(); }
                    Check(Values(store).SequenceEqual(before), "Synthetic tamper fixture restoration failed");
                    PlayerPrefs.SetString(Marker, "verify"); PlayerPrefs.Save();
                }
                else if (phase == "uncertain")
                {
                    var preferences = new AcknowledgementLossPreferences(); var failureStore = Store(failureProfile, preferences);
                    Check(failureStore.Load().Status == LocalSaveLoadStatus.Missing, "Uncertain phase requires a new synthetic profile");
                    using (var owner = Open(failureProfile, failureStore, out var adapter, out var wealth, true))
                    {
                        string old = PlayerPrefs.GetString(failureStore.Slot0Key); preferences.Fail = true;
                        try { adapter.ApplyAndSave(Data(90), true, "wealthInfos"); throw new InvalidOperationException("Synthetic flush acknowledgement failure did not fail"); }
                        catch (LocalSaveWriteException) { }
                        Check(adapter.Status == RepositoryStorageStatus.RecoveryRequired && adapter.SavedRevision == 0 && wealth.Get("qa-gold") == 100, "Unconfirmed write was published");
                        Check(PlayerPrefs.GetString(failureStore.Slot0Key) == old, "Previous normal slot changed on failure");
                        report["memoryQuantity"] = wealth.Get("qa-gold"); report["memoryRevision"] = adapter.SavedRevision; report["status"] = adapter.Status.ToString(); report["previousNormalSlotPreserved"] = true;
                    }
                }
                else if (phase == "reconcile")
                {
                    using (var owner = Open(failureProfile, Store(failureProfile), out var adapter, out var wealth, false))
                    { Check(adapter.SavedRevision == 1 && wealth.Get("qa-gold") == 90, "Fresh process did not reconcile the write that persisted before acknowledgement loss"); report["revision"] = adapter.SavedRevision; report["quantity"] = wealth.Get("qa-gold"); report["mutationRetried"] = false; }
                }
                else throw new ArgumentException("Unknown QA phase");
                var evidenceStore = phase == "uncertain" || phase == "reconcile" ? Store(failureProfile) : store;
                report["slot0Key"] = evidenceStore.Slot0Key; report["slot1Key"] = evidenceStore.Slot1Key;
                report["slot0Ciphertext"] = PlayerPrefs.GetString(evidenceStore.Slot0Key); report["slot1Ciphertext"] = PlayerPrefs.GetString(evidenceStore.Slot1Key);
                foreach (string value in Values(evidenceStore).Where(value => !string.IsNullOrEmpty(value))) Check(!Encoding.UTF8.GetString(Convert.FromBase64String(value)).Contains("SYNTHETIC-PLAYER-PRIVATE-PROGRESS"), "Plaintext leaked to PlayerPrefs");
                try { using (var gcm = new System.Security.Cryptography.AesGcm(SyntheticKey)) report["aesGcmCapability"] = "constructed"; }
                catch (Exception exception) { report["aesGcmCapability"] = exception.GetType().Name; }
                report["result"] = "PASS"; Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output))); File.WriteAllText(output, report.ToString());
                Debug.Log("SAVE_PLAYER_QA_PASS " + phase); Application.Quit(0);
            }
            catch (Exception exception)
            {
                report["result"] = "FAIL"; report["error"] = exception.GetType().Name + ": " + exception.Message; report["stack"] = exception.StackTrace;
                Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output))); File.WriteAllText(output, report.ToString()); Debug.LogException(exception); Application.Quit(2);
            }
        }
        private static string[] Values(LocalSaveRepository store) => new[] { PlayerPrefs.GetString(store.Slot0Key), PlayerPrefs.GetString(store.Slot1Key) };
        private sealed class AcknowledgementLossPreferences : ILocalSavePreferences
        {
            public bool Fail;
            public bool HasKey(string key) => PlayerPrefs.HasKey(key);
            public string GetString(string key) => PlayerPrefs.GetString(key);
            public void SetString(string key, string value) => PlayerPrefs.SetString(key, value);
            public void Save() { PlayerPrefs.Save(); if (Fail) throw new IOException("Synthetic loss of acknowledgement after actual PlayerPrefs.Save"); }
        }
    }
}
