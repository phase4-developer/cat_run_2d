using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace JJEvol.Save.PlayerQA
{
    // Test evidence only: export this QA application's own platform backing file, never game progress to a second backend.
    internal static class NativePlayerPrefsExport
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Register()
        {
            if (Application.identifier != "com.jjevol.qa.playerprefsaes.a310" || Application.companyName != "JJEvolQa20261104") return;
            Application.quitting += Export;
        }
        private static void Export()
        {
            string[] args = Environment.GetCommandLineArgs(); int index = Array.IndexOf(args, "-saveQaReport");
            if (index < 0 || index + 1 >= args.Length) return;
            string report = args[index + 1], xml = Path.ChangeExtension(report, ".native.xml"), receipt = Path.ChangeExtension(report, ".native.json");
            var result = new JObject { ["applicationId"] = Application.identifier, ["scope"] = "QA app's own native SharedPreferences file only", ["utc"] = DateTime.UtcNow.ToString("O") };
            try
            {
                using var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                using var activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                using var info = activity.Call<AndroidJavaObject>("getApplicationInfo");
                string directory = info.Get<string>("dataDir");
                string source = Path.Combine(directory, "shared_prefs", Application.identifier + ".v2.playerprefs.xml");
                byte[] bytes = File.ReadAllBytes(source);
                if (bytes.Length == 0 || bytes.Length > 2 * 1024 * 1024) throw new InvalidDataException("Unexpected QA native PlayerPrefs evidence size");
                File.WriteAllBytes(xml, bytes);
                using var hash = SHA256.Create();
                string digest = string.Concat(hash.ComputeHash(bytes).Select(b => b.ToString("x2")));
                if (!File.ReadAllBytes(source).SequenceEqual(bytes)) throw new IOException("Native PlayerPrefs changed during evidence export");
                result["source"] = source; result["bytes"] = bytes.Length; result["sha256"] = digest; result["result"] = "PASS";
            }
            catch (Exception exception) { result["result"] = "FAIL"; result["error"] = exception.GetType().Name + ": " + exception.Message; }
            File.WriteAllText(receipt, result.ToString());
        }
#endif
    }
}
