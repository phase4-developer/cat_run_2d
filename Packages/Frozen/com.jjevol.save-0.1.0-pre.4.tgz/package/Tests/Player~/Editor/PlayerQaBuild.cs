using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace JJEvol.Save.PlayerQA
{
    public static class PlayerQaBuild
    {
        public static void BuildWindows() => Build(false);
        public static void BuildAndroid() => Build(true);
        private static void Build(bool android)
        {
            try
            {
                string host = Path.GetFullPath(Application.dataPath).Replace('\\', '/');
                if (!host.StartsWith("C:/Project/JJEvolFramework/.local/playerprefs-aes-r1-20261104-a310/PlayerHost/", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Independent Player Host only");
                string root = "C:/Project/JJEvolFramework/.local/playerprefs-aes-r1-20261104-a310/Builds/Candidate4";
                string scenePath = "Assets/SaveProbe.unity";
                Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single); EditorSceneManager.SaveScene(scene, scenePath);
                PlayerSettings.companyName = "JJEvolQa20261104"; PlayerSettings.productName = "PlayerPrefsAES_a310";
                PlayerSettings.bundleVersion = "0.0.1";
                var target = android ? BuildTarget.Android : BuildTarget.StandaloneWindows64;
                var namedTarget = android ? NamedBuildTarget.Android : NamedBuildTarget.Standalone;
                PlayerSettings.SetApplicationIdentifier(namedTarget, "com.jjevol.qa.playerprefsaes.a310");
                PlayerSettings.SetScriptingBackend(namedTarget, android ? ScriptingImplementation.IL2CPP : ScriptingImplementation.Mono2x);
                PlayerSettings.SetManagedStrippingLevel(namedTarget, ManagedStrippingLevel.Low);
                if (android)
                {
                    // The dedicated BlueStacks QA environment cannot run this Unity Vulkan debug path.
                    PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
                    PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { UnityEngine.Rendering.GraphicsDeviceType.OpenGLES3 });
                    PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
                    PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
                    PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel35;
                    PlayerSettings.Android.useCustomKeystore = false;
                    EditorUserBuildSettings.buildAppBundle = false; EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
                }
                AssetDatabase.SaveAssets();
                string output = android ? root + "/Android/SavePlayerQa.apk" : root + "/Windows/SavePlayerQa.exe";
                Directory.CreateDirectory(Path.GetDirectoryName(output));
                BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes = new[] { scenePath }, locationPathName = output, target = target, options = BuildOptions.Development });
                File.WriteAllText(root + (android ? "/AndroidBuild.json" : "/WindowsBuild.json"), JsonUtility.ToJson(new BuildReceipt { result = report.summary.result.ToString(), errors = report.summary.totalErrors, warnings = report.summary.totalWarnings, output = output, unity = Application.unityVersion, backend = android ? "IL2CPP-ARM64" : "Mono-x64", totalBytes = report.summary.totalSize }, true));
                if (report.summary.result != BuildResult.Succeeded) throw new InvalidOperationException("Independent Player build failed");
                EditorApplication.Exit(0);
            }
            catch (Exception exception) { Debug.LogException(exception); EditorApplication.Exit(2); }
        }
        [Serializable] private sealed class BuildReceipt { public string result, output, unity, backend; public int errors, warnings; public ulong totalBytes; }
    }
}
