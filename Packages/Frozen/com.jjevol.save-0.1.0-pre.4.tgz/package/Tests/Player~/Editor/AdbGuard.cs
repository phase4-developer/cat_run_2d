using System;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace JJEvol.Save.PlayerQA
{
    // QA Host process only. Never installed in a consumer or included in the runtime package assembly.
    [InitializeOnLoad]
    internal static class AdbGuard
    {
        private static readonly FieldInfo QuitCallbacks = typeof(EditorApplication).GetField("editorApplicationQuit", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
        static AdbGuard()
        {
            string host = Path.GetFullPath(Application.dataPath).Replace('\\', '/');
            if (!host.StartsWith("C:/Project/JJEvolFramework/.local/", StringComparison.OrdinalIgnoreCase)) return;
            SuppressOwnCleanup();
            EditorApplication.update += SuppressOwnCleanup;
            EditorApplication.quitting += SuppressOwnCleanup;
            AssemblyReloadEvents.afterAssemblyReload += SuppressOwnCleanup;
        }
        private static void SuppressOwnCleanup()
        {
            if (QuitCallbacks == null) throw new InvalidOperationException("Known Unity QA ADB cleanup field is unavailable. Do not continue SDK validation.");
            var callbacks = (Delegate)QuitCallbacks.GetValue(null);
            if (callbacks == null) return;
            var removals = callbacks.GetInvocationList().Where(callback => callback.Method.DeclaringType?.FullName == "UnityEditor.Android.ADB" && callback.Method.Name == "CleanupADB").ToArray();
            foreach (var callback in removals) callbacks = Delegate.Remove(callbacks, callback);
            if (removals.Length == 0) return;
            QuitCallbacks.SetValue(null, callbacks);
            Debug.Log("SAVE_QA_ADB_GUARD: removed own process CleanupADB callback; EditorPrefs and SDK files unchanged.");
        }
    }
}
