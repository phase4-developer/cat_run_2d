using System;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace jjevol.Tests
{
    public sealed class LocalSaveEncryptionTests
    {
        private static readonly byte[] SyntheticKey = Enumerable.Range(0, 32).Select(x => (byte)x).ToArray();
        [Test] public void ActualAesRoundTripUsesFreshIvAndHidesJson()
        {
            var encryption = new LocalSaveEncryption("synthetic-v1", SyntheticKey); byte[] plain = Encoding.UTF8.GetBytes("{\"syntheticPrivateProgress\":123}");
            byte[] a = encryption.Encrypt(plain, "qa:one"), b = encryption.Encrypt(plain, "qa:one"); Assert.That(a, Is.Not.EqualTo(b)); Assert.That(Encoding.UTF8.GetString(a), Does.Not.Contain("syntheticPrivateProgress")); Assert.That(encryption.Decrypt(a, "qa:one"), Is.EqualTo(plain));
        }
        [TestCase(0)] [TestCase(11)] [TestCase(32)] [TestCase(55)] [TestCase(-1)] public void ModifiedHeaderIvCiphertextAndTagAreRejected(int position)
        {
            var encryption = new LocalSaveEncryption("synthetic-v1", SyntheticKey); byte[] wire = encryption.Encrypt(Encoding.UTF8.GetBytes("synthetic-secret-progress"), "qa:one"); wire[position < 0 ? wire.Length - 1 : position] ^= 1;
            var error = Assert.Catch(() => encryption.Decrypt(wire, "qa:one"));
            Assert.That(error is InvalidDataException || error is LocalSaveProtectionException, Is.True);
        }
        [Test] public void WrongKeyAndProfileAreRejected()
        {
            var encryption = new LocalSaveEncryption("synthetic-v1", SyntheticKey); byte[] wire = encryption.Encrypt(new byte[] { 1, 2, 3 }, "qa:one");
            Assert.Throws<InvalidDataException>(() => encryption.Decrypt(wire, "qa:two")); Assert.Throws<InvalidDataException>(() => new LocalSaveEncryption("synthetic-v1", SyntheticKey.Reverse().ToArray()).Decrypt(wire, "qa:one"));
        }
        [Test] public void CallerKeyMutationCannotChangeDerivedKeys()
        {
            byte[] key = (byte[])SyntheticKey.Clone(); var encryption = new LocalSaveEncryption("synthetic-v1", key); byte[] wire = encryption.Encrypt(new byte[] { 1 }, "qa:one"); Array.Clear(key, 0, key.Length); Assert.That(encryption.Decrypt(wire, "qa:one"), Is.EqualTo(new byte[] { 1 }));
        }
        [TestCase(0)] [TestCase(16)] [TestCase(31)] [TestCase(33)] public void MasterKeyMustHave32Bytes(int length)
        { Assert.Throws<ArgumentException>(() => new LocalSaveEncryption("synthetic-v1", new byte[length])); }
        [TestCase("")] [TestCase("bad key")] [TestCase("bad:key")] public void UnsafeKeyIdentifierIsRejected(string id)
        { Assert.Throws<ArgumentException>(() => new LocalSaveEncryption(id, SyntheticKey)); }
        [Test] public void JsonMetadataUnknownFieldsAndExactLongsRoundTrip()
        {
            var codec = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("synthetic-v1", SyntheticKey)); var snapshot = new LocalSaveSnapshot(new JObject { ["quantity"] = long.MaxValue, ["unknown"] = new JObject { ["v"] = 7 } });
            var result = codec.Decode(codec.Encode(snapshot, "qa:one", 42, DateTime.UtcNow), "qa:one"); Assert.That(result.Snapshot.Payload.Value<long>("quantity"), Is.EqualTo(long.MaxValue)); Assert.That((int)result.Snapshot.Payload["unknown"]["v"], Is.EqualTo(7)); Assert.That(result.StateRevision, Is.EqualTo(42));
        }
    }
}
