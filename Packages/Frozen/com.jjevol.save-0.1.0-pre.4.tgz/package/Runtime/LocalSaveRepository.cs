using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using UnityEngine;

namespace jjevol
{
    public enum LocalSaveLoadStatus { Missing, Loaded, RecoveredBackup, Corrupt, UnsupportedVersion, MigrationFailed, ProtectionFailed, StorageUnavailable }

    public sealed class LocalSaveLoadResult
    {
        private static readonly IReadOnlyList<LocalSaveLoadStatus> NotRead = Array.AsReadOnly(new LocalSaveLoadStatus[0]);
        private static readonly IReadOnlyList<int> NoSlots = Array.AsReadOnly(new int[0]);
        public LocalSaveLoadStatus Status { get; }
        public LocalSaveDocument Document { get; }
        public string Error { get; }
        public bool Success => Status == LocalSaveLoadStatus.Loaded || Status == LocalSaveLoadStatus.RecoveredBackup;
        /// <summary>
        /// Each slot as read: index 0 is <see cref="LocalSaveRepository.Slot0Key"/>, 1 is Slot1Key. Missing, Loaded, or the
        /// slot's own failure. Empty when the slots were not read (no key, uncertain write).
        /// </summary>
        public IReadOnlyList<LocalSaveLoadStatus> SlotStatuses { get; }
        /// <summary>Slots whose value is damaged (Corrupt). <see cref="LocalSaveRepository.Repair"/> rewrites one from the other.</summary>
        public IReadOnlyList<int> DamagedSlots { get; }
        internal LocalSaveLoadResult(LocalSaveLoadStatus status, LocalSaveDocument document = null, string error = null, LocalSaveLoadStatus[] slots = null)
        {
            Status = status; Document = document; Error = error;
            SlotStatuses = slots == null ? NotRead : Array.AsReadOnly((LocalSaveLoadStatus[])slots.Clone());
            DamagedSlots = slots == null ? NoSlots : Array.AsReadOnly(Enumerable.Range(0, slots.Length).Where(i => slots[i] == LocalSaveLoadStatus.Corrupt).ToArray());
        }
    }

    public sealed class LocalSaveConflictException : InvalidOperationException
    {
        public LocalSaveConflictException() : base("The persisted local save changed; reopen and prepare the mutation again.") { }
    }

    public sealed class LocalSaveWriteException : IOException
    {
        public LocalSaveWriteException(Exception inner) : base("PlayerPrefs write was not confirmed. Do not retry the mutation; restart and reconcile the persisted revision.", inner) { }
    }

    /// <summary>PlayerPrefs access seam for failure tests. Production uses Unity PlayerPrefs only.</summary>
    public interface ILocalSavePreferences
    {
        bool HasKey(string key);
        string GetString(string key);
        void SetString(string key, string value);
        void Save();
    }

    /// <summary>
    /// One encrypted PlayerPrefs profile with two alternating revisions. No file backend. Payload migrations run on read
    /// (<see cref="LocalSaveCodec.DataVersion"/>); nothing is rewritten until the game saves or calls <see cref="Repair"/>.
    /// </summary>
    public sealed class LocalSaveRepository
    {
        public const int MaxStoredCharacters = 2 * 1024 * 1024;
        private static readonly object PreferencesGate = new object();
        private static bool _writing;
        private readonly int _thread = Thread.CurrentThread.ManagedThreadId;
        private readonly LocalSaveCodec _codec;
        private readonly ILocalSavePreferences _preferences;
        private bool _writeUncertain;
        public string ProfileId { get; }
        public string Slot0Key { get; }
        public string Slot1Key { get; }

        // Deliberately different from the removed (profileId, persistentDataPath, codec) file constructor.
        public LocalSaveRepository(string profileId, LocalSaveCodec codec, string keyNamespace = "jjevol.save.v2", ILocalSavePreferences preferences = null)
        {
            ValidateProfileId(profileId);
            if (string.IsNullOrEmpty(keyNamespace) || keyNamespace.Length > 80) throw new ArgumentException("An explicit safe PlayerPrefs namespace is required.", nameof(keyNamespace));
            foreach (char c in keyNamespace)
                if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') && !(c >= '0' && c <= '9') && c != '.' && c != '-' && c != '_') throw new ArgumentException("Unsafe PlayerPrefs namespace.", nameof(keyNamespace));
            ProfileId = profileId;
            _codec = codec ?? throw new ArgumentNullException(nameof(codec));
            _preferences = preferences ?? new UnityPreferences();
            Slot0Key = keyNamespace + ":" + profileId + ":0";
            Slot1Key = keyNamespace + ":" + profileId + ":1";
        }

        public static void ValidateProfileId(string profileId)
        {
            if (string.IsNullOrWhiteSpace(profileId) || profileId.Length > 80) throw new ArgumentException("Profile ID must contain 1 to 80 safe characters.", nameof(profileId));
            foreach (char c in profileId)
                if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') && !(c >= '0' && c <= '9') && c != '-' && c != '_' && c != ':') throw new ArgumentException("Profile ID contains an unsafe character.", nameof(profileId));
        }

        private void EnsureAccess()
        {
            if (Thread.CurrentThread.ManagedThreadId != _thread) throw new InvalidOperationException("Use the repository on its creating Unity main thread.");
            if (_writing) throw new InvalidOperationException("A PlayerPrefs save is already in progress.");
        }

        public LocalSaveLoadResult Load() => Load(false);
        /// <summary>Explicit read-only salvage. Normal Open/Save remain blocked while a slot is damaged.</summary>
        public LocalSaveLoadResult LoadRecovery() => Load(true);

        private LocalSaveLoadResult Load(bool recovery)
        {
            lock (PreferencesGate)
            {
                EnsureAccess();
                if (_writeUncertain) return new LocalSaveLoadResult(LocalSaveLoadStatus.StorageUnavailable, error: "A write is uncertain; restart and reconcile.");
                if (!_codec.IsEncrypted) return new LocalSaveLoadResult(LocalSaveLoadStatus.ProtectionFailed, error: "A game-provided encryption key is required.");
                return Select(Read(Slot0Key), Read(Slot1Key), recovery);
            }
        }

        public LocalSaveDocument Save(LocalSaveSnapshot snapshot, LocalSaveDocument expected)
            => Save(snapshot, checked((expected?.StateRevision ?? -1) + 1), expected?.StateRevision ?? -1, expected, true);
        public LocalSaveDocument Save(LocalSaveSnapshot snapshot, long stateRevision, long expectedRevision)
            => Save(snapshot, stateRevision, expectedRevision, null, false);

        private LocalSaveDocument Save(LocalSaveSnapshot snapshot, long stateRevision, long expectedRevision, LocalSaveDocument expected, bool compareDocument)
        {
            lock (PreferencesGate)
            {
                EnsureAccess();
                if (_writeUncertain) throw new InvalidOperationException("The previous write is uncertain; restart and reconcile.");
                if (!_codec.IsEncrypted) throw new LocalSaveProtectionException(LocalSaveProtectionFailure.KeyRequired, "Saving requires a game-provided encryption key.");
                if (expectedRevision < -1 || stateRevision != checked(expectedRevision + 1)) throw new ArgumentOutOfRangeException(nameof(stateRevision));
                byte[] bytes = _codec.Encode(snapshot, ProfileId, stateRevision, DateTime.UtcNow, expected?.ExtraEnvelope);
                string value = Convert.ToBase64String(bytes);
                if (value.Length > MaxStoredCharacters) throw new LocalSaveProtectionException(LocalSaveProtectionFailure.SizeLimitExceeded, "The PlayerPrefs save exceeds the supported size.");
                LocalSaveDocument candidate = _codec.Decode(bytes, ProfileId);
                Slot first = Read(Slot0Key), second = Read(Slot1Key);
                LocalSaveLoadResult current = Select(first, second, false);
                if (!current.Success && current.Status != LocalSaveLoadStatus.Missing) throw new InvalidDataException("PlayerPrefs save blocked: " + current.Status);
                if ((current.Document?.StateRevision ?? -1) != expectedRevision || (compareDocument && !(expected == null ? current.Document == null : expected.Matches(current.Document)))) throw new LocalSaveConflictException();
                string target = first.Document == null || (second.Document != null && first.Document.StateRevision < second.Document.StateRevision) ? Slot0Key : Slot1Key;
                // Only the inactive/older slot changes. The latest confirmed slot stays untouched.
                return Write(target, value, candidate);
            }
        }

        /// <summary>
        /// Explicit repair, never automatic: when exactly one slot is damaged (Corrupt) and the other holds an authenticated
        /// revision, rewrites the damaged slot with that revision's snapshot as the next revision, so both slots form one
        /// history again. Returns the new latest document. If the damaged slot held the newer revision, its changes are
        /// lost; read <see cref="LoadRecovery"/> first to show the player what remains. Key, version, migration and
        /// storage failures, two damaged slots, and two intact slots that do not form one history are not repaired.
        /// </summary>
        public LocalSaveDocument Repair()
        {
            lock (PreferencesGate)
            {
                EnsureAccess();
                if (_writeUncertain) throw new InvalidOperationException("The previous write is uncertain; restart and reconcile.");
                if (!_codec.IsEncrypted) throw new LocalSaveProtectionException(LocalSaveProtectionFailure.KeyRequired, "Repair requires a game-provided encryption key.");
                Slot first = Read(Slot0Key), second = Read(Slot1Key);
                bool firstDamaged = first.Failure == LocalSaveLoadStatus.Corrupt, secondDamaged = second.Failure == LocalSaveLoadStatus.Corrupt;
                if (firstDamaged && secondDamaged) throw new InvalidOperationException("Both slots are damaged; there is no intact revision to repair from.");
                if (!firstDamaged && !secondDamaged) throw new InvalidOperationException("No slot is damaged; there is nothing to repair.");
                Slot intact = firstDamaged ? second : first;
                if (intact.Document == null)
                    throw new InvalidOperationException("The other slot is " + (intact.Failure?.ToString() ?? "Missing") + "; there is no intact revision to repair from.");
                LocalSaveDocument source = intact.Document;
                long revision = checked(source.StateRevision + 1);
                byte[] bytes = _codec.Encode(source.Snapshot, ProfileId, revision, DateTime.UtcNow, source.ExtraEnvelope);
                string value = Convert.ToBase64String(bytes);
                if (value.Length > MaxStoredCharacters) throw new LocalSaveProtectionException(LocalSaveProtectionFailure.SizeLimitExceeded, "The PlayerPrefs save exceeds the supported size.");
                return Write(firstDamaged ? Slot0Key : Slot1Key, value, _codec.Decode(bytes, ProfileId));
            }
        }

        private LocalSaveDocument Write(string target, string value, LocalSaveDocument candidate)
        {
            _writing = true;
            try
            {
                _preferences.SetString(target, value);
                _preferences.Save();
                if (!_preferences.HasKey(target) || !string.Equals(_preferences.GetString(target), value, StringComparison.Ordinal)) throw new IOException("PlayerPrefs readback differs from the candidate.");
                return candidate;
            }
            catch (Exception exception)
            {
                // Save returns void; readback observes Unity's cache, not a durable disk acknowledgement.
                // Failed writes may persist later. Do not roll back, retry, or publish the candidate.
                _writeUncertain = true;
                throw new LocalSaveWriteException(exception);
            }
            finally { _writing = false; }
        }

        private Slot Read(string key)
        {
            try
            {
                if (!_preferences.HasKey(key)) return new Slot();
                string value = _preferences.GetString(key);
                if (string.IsNullOrEmpty(value)) return new Slot(LocalSaveLoadStatus.Corrupt);
                if (value.Length > MaxStoredCharacters) return new Slot(LocalSaveLoadStatus.ProtectionFailed);
                return new Slot { Document = _codec.Decode(Convert.FromBase64String(value), ProfileId) };
            }
            catch (LocalSaveProtectionException) { return new Slot(LocalSaveLoadStatus.ProtectionFailed); }
            catch (UnsupportedLocalSaveVersionException) { return new Slot(LocalSaveLoadStatus.UnsupportedVersion); }
            catch (LocalSaveMigrationException) { return new Slot(LocalSaveLoadStatus.MigrationFailed); }
            catch (Exception exception) when (exception is InvalidDataException || exception is FormatException) { return new Slot(LocalSaveLoadStatus.Corrupt); }
            catch (Exception) { return new Slot(LocalSaveLoadStatus.StorageUnavailable); }
        }

        private static LocalSaveLoadResult Select(Slot first, Slot second, bool recovery)
        {
            var slots = new[] { first.Status, second.Status };
            foreach (LocalSaveLoadStatus failure in new[] { LocalSaveLoadStatus.StorageUnavailable, LocalSaveLoadStatus.ProtectionFailed, LocalSaveLoadStatus.UnsupportedVersion, LocalSaveLoadStatus.MigrationFailed })
                if (first.Failure == failure || second.Failure == failure) return new LocalSaveLoadResult(failure, error: "PlayerPrefs slot validation failed; original values were preserved.", slots: slots);
            bool corrupt = first.Failure == LocalSaveLoadStatus.Corrupt || second.Failure == LocalSaveLoadStatus.Corrupt;
            if (first.Document != null && second.Document != null)
            {
                long a = first.Document.StateRevision, b = second.Document.StateRevision;
                if (a == b || Math.Max(a, b) - Math.Min(a, b) != 1) return new LocalSaveLoadResult(LocalSaveLoadStatus.Corrupt, error: "The PlayerPrefs revisions do not form one history.", slots: slots);
            }
            LocalSaveDocument latest = first.Document == null ? second.Document : second.Document == null || first.Document.StateRevision > second.Document.StateRevision ? first.Document : second.Document;
            if (corrupt && (!recovery || latest == null))
                return new LocalSaveLoadResult(LocalSaveLoadStatus.Corrupt, error: "Slot " + string.Join(", ", Enumerable.Range(0, 2).Where(i => slots[i] == LocalSaveLoadStatus.Corrupt)) + " is damaged; normal loading and writing are blocked. LoadRecovery reads the other slot and Repair rewrites the damaged one.", slots: slots);
            return latest == null ? new LocalSaveLoadResult(LocalSaveLoadStatus.Missing, slots: slots) : new LocalSaveLoadResult(corrupt ? LocalSaveLoadStatus.RecoveredBackup : LocalSaveLoadStatus.Loaded, latest, slots: slots);
        }

        private sealed class Slot
        {
            public LocalSaveDocument Document;
            public LocalSaveLoadStatus? Failure;
            public LocalSaveLoadStatus Status => Failure ?? (Document == null ? LocalSaveLoadStatus.Missing : LocalSaveLoadStatus.Loaded);
            public Slot() { }
            public Slot(LocalSaveLoadStatus failure) { Failure = failure; }
        }

        private sealed class UnityPreferences : ILocalSavePreferences
        {
            public bool HasKey(string key) => PlayerPrefs.HasKey(key);
            public string GetString(string key) => PlayerPrefs.GetString(key);
            public void SetString(string key, string value) => PlayerPrefs.SetString(key, value);
            public void Save() => PlayerPrefs.Save();
        }
    }
}
