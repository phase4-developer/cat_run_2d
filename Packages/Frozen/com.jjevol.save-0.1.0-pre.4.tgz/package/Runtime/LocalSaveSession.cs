using System;
using System.IO;
using System.Threading;

namespace jjevol
{
    public sealed class LocalSaveSession
    {
        private readonly LocalSaveRepository _repository;
        private LocalSaveDocument _current;
        private int _committing;
        public string ProfileId => _repository.ProfileId;
        public LocalSaveLoadStatus OpenStatus { get; }
        public LocalSaveDocument Current => Volatile.Read(ref _current);
        public long StateRevision => Current.StateRevision;
        public LocalSaveSnapshot Snapshot => Current.Snapshot;

        private LocalSaveSession(LocalSaveRepository repository, LocalSaveDocument current, LocalSaveLoadStatus openStatus)
        { _repository = repository; _current = current; OpenStatus = openStatus; }

        public static LocalSaveSession Open(LocalSaveRepository repository, Func<LocalSaveSnapshot> createInitial = null)
        {
            if (repository == null) throw new ArgumentNullException(nameof(repository));
            LocalSaveLoadResult loaded = repository.Load();
            if (loaded.Success) return new LocalSaveSession(repository, loaded.Document, loaded.Status);
            if (loaded.Status != LocalSaveLoadStatus.Missing)
                throw new InvalidDataException("Cannot open local save: " + loaded.Status + ". " + loaded.Error);
            if (createInitial == null) throw new InvalidOperationException("An initial snapshot is required for a missing local profile.");
            LocalSaveSnapshot initial = createInitial() ?? throw new InvalidOperationException("The initial snapshot factory returned no data.");
            LocalSaveDocument current = repository.Save(initial, null);
            return new LocalSaveSession(repository, current, LocalSaveLoadStatus.Missing);
        }

        public void CommitMutation(long expectedRevision, LocalSaveSnapshot nextSnapshot)
        {
            if (nextSnapshot == null) throw new ArgumentNullException(nameof(nextSnapshot));
            if (Interlocked.CompareExchange(ref _committing, 1, 0) != 0) throw new InvalidOperationException("A local save mutation is already being committed.");
            try
            {
                LocalSaveDocument basis = Current;
                if (basis.StateRevision != expectedRevision) throw new LocalSaveConflictException();
                LocalSaveDocument saved = _repository.Save(nextSnapshot, basis);
                Volatile.Write(ref _current, saved);
            }
            finally { Volatile.Write(ref _committing, 0); }
        }
    }
}
