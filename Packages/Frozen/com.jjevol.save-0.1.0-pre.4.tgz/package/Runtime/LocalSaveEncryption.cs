using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace jjevol
{
    public enum LocalSaveProtectionFailure { KeyRequired, LegacyPlaintext, UnknownKey, UnsupportedVersion, SizeLimitExceeded }

    public sealed class LocalSaveProtectionException : IOException
    {
        public LocalSaveProtectionFailure Reason { get; }
        internal LocalSaveProtectionException(LocalSaveProtectionFailure reason, string message) : base(message) { Reason = reason; }
    }

    /// <summary>Versioned AES-256-CBC encrypt-then-MAC storage. The game supplies a secret 32-byte master key.</summary>
    public sealed class LocalSaveEncryption
    {
        public const int FormatVersion = 1;
        public const int MaxPlaintextBytes = 16 * 1024 * 1024;
        private static readonly byte[] Magic = { 0x4a, 0x4a, 0x45, 0x53, 0x41, 0x56, 0x45, 0x00 };
        private const byte Algorithm = 1; // AES-256-CBC / PKCS7 + HMAC-SHA256; HKDF-SHA256 subkeys.
        private readonly byte[] _keyId;
        private readonly byte[] _encryptionKey;
        private readonly byte[] _authenticationKey;

        public LocalSaveEncryption(string keyId, byte[] masterKey)
        {
            if (string.IsNullOrEmpty(keyId) || keyId.Length > 48) throw new ArgumentException("A key identifier of 1 to 48 safe characters is required.", nameof(keyId));
            foreach (char c in keyId)
                if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') && !(c >= '0' && c <= '9') && c != '-' && c != '_' && c != '.')
                    throw new ArgumentException("The key identifier contains unsafe characters.", nameof(keyId));
            if (masterKey == null || masterKey.Length != 32) throw new ArgumentException("A secret 32-byte master key is required.", nameof(masterKey));
            _keyId = Encoding.ASCII.GetBytes(keyId);
            byte[] copy = (byte[])masterKey.Clone();
            byte[] keys = null;
            try
            {
                keys = Hkdf(copy, Encoding.ASCII.GetBytes("JJEvol.LocalSave.Encryption.v1"), Encoding.ASCII.GetBytes("AES256CBC-HMACSHA256:" + keyId), 64);
                _encryptionKey = new byte[32]; _authenticationKey = new byte[32];
                Buffer.BlockCopy(keys, 0, _encryptionKey, 0, 32);
                Buffer.BlockCopy(keys, 32, _authenticationKey, 0, 32);
            }
            finally { Array.Clear(copy, 0, copy.Length); if (keys != null) Array.Clear(keys, 0, keys.Length); }
        }

        public byte[] Encrypt(byte[] plaintext, string profileId)
        {
            LocalSaveRepository.ValidateProfileId(profileId);
            if (plaintext == null || plaintext.Length == 0 || plaintext.Length > MaxPlaintextBytes) throw new ArgumentException("The local save document has an invalid size.", nameof(plaintext));
            byte[] iv = new byte[16];
            using (var random = RandomNumberGenerator.Create()) random.GetBytes(iv);
            byte[] ciphertext;
            using (var aes = Aes.Create())
            {
                aes.KeySize = 256; aes.BlockSize = 128; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
                aes.Key = _encryptionKey; aes.IV = iv;
                using var transform = aes.CreateEncryptor();
                ciphertext = transform.TransformFinalBlock(plaintext, 0, plaintext.Length);
            }
            int header = 31 + _keyId.Length;
            var output = new byte[checked(header + ciphertext.Length + 32)];
            Buffer.BlockCopy(Magic, 0, output, 0, Magic.Length);
            output[8] = FormatVersion; output[9] = Algorithm; output[10] = (byte)_keyId.Length;
            Buffer.BlockCopy(_keyId, 0, output, 11, _keyId.Length);
            Buffer.BlockCopy(iv, 0, output, 11 + _keyId.Length, iv.Length);
            WriteLength(output, 27 + _keyId.Length, ciphertext.Length);
            Buffer.BlockCopy(ciphertext, 0, output, header, ciphertext.Length);
            byte[] tag = Authenticate(output, header + ciphertext.Length, profileId);
            Buffer.BlockCopy(tag, 0, output, header + ciphertext.Length, tag.Length);
            return output;
        }

        public byte[] Decrypt(byte[] encrypted, string profileId)
        {
            LocalSaveRepository.ValidateProfileId(profileId);
            if (encrypted != null && encrypted.Length > MaxPlaintextBytes + 128)
                throw new LocalSaveProtectionException(LocalSaveProtectionFailure.SizeLimitExceeded, "The local save exceeds the supported size; original values were preserved.");
            if (!IsEncrypted(encrypted))
            {
                // Identify legacy JSON before parsing: duplicate keys, truncation, or trailing text must not
                // permit a backup recovery to archive or convert a plaintext progress document implicitly.
                // Do not let backup recovery archive or convert it implicitly.
                int offset = encrypted != null && encrypted.Length >= 3 && encrypted[0] == 0xef && encrypted[1] == 0xbb && encrypted[2] == 0xbf ? 3 : 0;
                while (encrypted != null && offset < encrypted.Length && (encrypted[offset] == 0x20 || encrypted[offset] == 0x09 || encrypted[offset] == 0x0a || encrypted[offset] == 0x0d)) offset++;
                if (encrypted != null && offset < encrypted.Length && encrypted[offset] == (byte)'{')
                    throw new LocalSaveProtectionException(LocalSaveProtectionFailure.LegacyPlaintext, "An existing plaintext save requires an explicit migration decision; original values were preserved.");
                throw new InvalidDataException("The encrypted local save header is invalid.");
            }
            if (encrypted.Length < 11) throw new InvalidDataException("The encrypted local save header is truncated.");
            if (encrypted[8] != FormatVersion || encrypted[9] != Algorithm)
                throw new LocalSaveProtectionException(LocalSaveProtectionFailure.UnsupportedVersion, "The encrypted local save format is unsupported; original values were preserved.");
            int keyLength = encrypted[10];
            if (keyLength < 1 || keyLength > 48 || encrypted.Length < 31 + keyLength + 16 + 32 || encrypted.Length > MaxPlaintextBytes + 128)
                throw new InvalidDataException("The encrypted local save length is invalid.");
            if (keyLength != _keyId.Length || !Equal(encrypted, 11, _keyId, 0, keyLength))
                throw new LocalSaveProtectionException(LocalSaveProtectionFailure.UnknownKey, "The encrypted local save requires a different key identifier; original values were preserved.");
            int header = 31 + keyLength;
            int ciphertextLength = ReadLength(encrypted, 27 + keyLength);
            if (ciphertextLength < 16 || ciphertextLength % 16 != 0 || ciphertextLength > MaxPlaintextBytes + 16 || (long)header + ciphertextLength + 32 != encrypted.Length)
                throw new InvalidDataException("The encrypted local save length is invalid.");
            byte[] tag = Authenticate(encrypted, header + ciphertextLength, profileId);
            if (!Equal(tag, 0, encrypted, header + ciphertextLength, 32))
                throw new InvalidDataException("The encrypted local save authentication failed.");
            // Authenticate every byte and the profile context before decrypting or checking CBC padding.
            byte[] iv = new byte[16]; Buffer.BlockCopy(encrypted, 11 + keyLength, iv, 0, iv.Length);
            try
            {
                using var aes = Aes.Create();
                aes.KeySize = 256; aes.BlockSize = 128; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
                aes.Key = _encryptionKey; aes.IV = iv;
                using var transform = aes.CreateDecryptor();
                return transform.TransformFinalBlock(encrypted, header, ciphertextLength);
            }
            catch (CryptographicException exception) { throw new InvalidDataException("The encrypted local save could not be decrypted.", exception); }
        }

        internal static bool IsEncrypted(byte[] bytes)
        {
            if (bytes == null || bytes.Length < Magic.Length) return false;
            return Equal(bytes, 0, Magic, 0, Magic.Length);
        }

        private byte[] Authenticate(byte[] bytes, int count, string profileId)
        {
            byte[] context = Encoding.UTF8.GetBytes(profileId);
            var input = new byte[checked(count + 2 + context.Length)];
            Buffer.BlockCopy(bytes, 0, input, 0, count);
            input[count] = (byte)(context.Length >> 8); input[count + 1] = (byte)context.Length;
            Buffer.BlockCopy(context, 0, input, count + 2, context.Length);
            using var hmac = new HMACSHA256(_authenticationKey);
            return hmac.ComputeHash(input);
        }

        private static bool Equal(byte[] first, int firstOffset, byte[] second, int secondOffset, int length)
        {
            int difference = 0;
            for (int i = 0; i < length; i++) difference |= first[firstOffset + i] ^ second[secondOffset + i];
            return difference == 0;
        }

        private static void WriteLength(byte[] bytes, int offset, int value)
        { bytes[offset] = (byte)(value >> 24); bytes[offset + 1] = (byte)(value >> 16); bytes[offset + 2] = (byte)(value >> 8); bytes[offset + 3] = (byte)value; }
        private static int ReadLength(byte[] bytes, int offset)
            => (bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3];

        // RFC 5869 extract-and-expand. Key material is never serialized or exposed through properties.
        private static byte[] Hkdf(byte[] inputKey, byte[] salt, byte[] info, int count)
        {
            if (count < 1 || count > 255 * 32) throw new ArgumentOutOfRangeException(nameof(count));
            byte[] prk;
            using (var extract = new HMACSHA256(salt)) prk = extract.ComputeHash(inputKey);
            byte[] previous = Array.Empty<byte>();
            var output = new byte[count];
            try
            {
                using var expand = new HMACSHA256(prk);
                int written = 0;
                for (byte block = 1; written < count; block++)
                {
                    var input = new byte[previous.Length + info.Length + 1];
                    Buffer.BlockCopy(previous, 0, input, 0, previous.Length);
                    Buffer.BlockCopy(info, 0, input, previous.Length, info.Length);
                    input[input.Length - 1] = block;
                    byte[] next = expand.ComputeHash(input);
                    Array.Clear(input, 0, input.Length);
                    Array.Clear(previous, 0, previous.Length); previous = next;
                    int length = Math.Min(next.Length, count - written);
                    Buffer.BlockCopy(next, 0, output, written, length); written += length;
                }
                return output;
            }
            finally { Array.Clear(prk, 0, prk.Length); Array.Clear(previous, 0, previous.Length); }
        }
    }
}
