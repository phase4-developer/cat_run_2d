using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Text;

namespace jjevol
{
    public sealed class LocalSaveSnapshot
    {
        private readonly JObject _payload;
        public JObject Payload => (JObject)_payload.DeepClone();

        public LocalSaveSnapshot(JObject payload)
        {
            if (payload == null) throw new ArgumentNullException(nameof(payload));
            // Normalize dates and other CLR values to their JSON representation before hashing or cloning.
            _payload = LocalSaveCodec.ReadEnvelope(Encoding.UTF8.GetBytes(payload.ToString(Formatting.None)));
        }
    }
}
