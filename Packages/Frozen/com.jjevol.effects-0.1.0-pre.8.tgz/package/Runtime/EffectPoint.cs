using System;
using UnityEngine;

namespace jjevol.Effect
{
    /// <summary>
    /// 이펙트 비행의 출발·경유·도착 자리 하나. 매 프레임 다시 읽으므로 대상이 움직이거나 카메라가 움직여도 따라간다.
    /// 이펙트가 놓인 곳(월드 또는 uGUI Canvas)에 맞게 바꾼다. 월드 자리를 UI 이펙트로 보내면 월드 카메라로 화면에 투영하고,
    /// UI 앵커·화면 자리를 월드 이펙트로 보내면 월드 카메라로 되돌린다.
    /// </summary>
    public readonly struct EffectPoint
    {
        /// <summary>화면 자리(px, 왼아래 원점)를 돌려준다. false면 이번 프레임에는 자리가 없다(마지막 자리를 쓴다).</summary>
        public delegate bool ScreenSource(out Vector2 screen);

        internal enum PointKind { None, Raw, World, Follow, Screen, ScreenSource, Anchor, Local }

        internal readonly PointKind Kind;
        readonly Vector3 _value;
        readonly Transform _transform;
        readonly ScreenSource _source;
        readonly Camera _camera;

        EffectPoint(PointKind kind, Vector3 value, Transform transform, ScreenSource source, Camera camera)
        {
            Kind = kind;
            _value = value;
            _transform = transform;
            _source = source;
            _camera = camera;
        }

        /// <summary>자리가 정해지지 않았다. 출발에 쓰면 요청이 놓은 자리에서, 경유에 쓰면 앞 자리에 머문다.</summary>
        public bool IsNone => Kind == PointKind.None;

        /// <summary>고정 월드 자리. <paramref name="worldCamera"/>는 UI 이펙트로 투영할 때 쓰고 없으면 Camera.main이다.</summary>
        public static EffectPoint World(Vector3 position, Camera worldCamera = null)
            => new EffectPoint(PointKind.World, position, null, null, worldCamera);

        /// <summary>
        /// 움직이는 월드 대상(Transform.position + offset, offset은 월드 단위). 대상이 사라지면 마지막 자리로 간다.
        /// <paramref name="worldCamera"/>는 UI 이펙트로 투영할 때 쓰고 없으면 Camera.main이다.
        /// </summary>
        public static EffectPoint Follow(Transform target, Vector3 offset = default, Camera worldCamera = null)
            => new EffectPoint(PointKind.Follow, offset, target ? target : throw new ArgumentNullException(nameof(target)), null, worldCamera);

        /// <summary>
        /// uGUI 요소의 가운데(+ offset, 화면 px). 다른 Canvas에 있어도 된다. 요소가 사라지면 마지막 자리로 간다.
        /// <paramref name="worldCamera"/>는 월드 이펙트로 되돌릴 때 쓰고 없으면 Camera.main이다.
        /// </summary>
        public static EffectPoint Anchor(RectTransform anchor, Vector2 offset = default, Camera worldCamera = null)
            => new EffectPoint(PointKind.Anchor, offset, anchor ? anchor : throw new ArgumentNullException(nameof(anchor)), null, worldCamera);

        /// <summary>고정 화면 자리(px, 왼아래 원점). <paramref name="worldCamera"/>는 월드 이펙트로 되돌릴 때 쓴다.</summary>
        public static EffectPoint Screen(Vector2 screen, Camera worldCamera = null)
            => new EffectPoint(PointKind.Screen, screen, null, null, worldCamera);

        /// <summary>매 프레임 화면 자리를 묻는다(게임이 HUD 자리를 직접 계산할 때).</summary>
        public static EffectPoint FromScreen(ScreenSource source, Camera worldCamera = null)
            => new EffectPoint(PointKind.ScreenSource, Vector3.zero, null, source ?? throw new ArgumentNullException(nameof(source)), worldCamera);

        /// <summary>이미 이펙트가 놓인 곳의 월드 좌표인 자리(바꾸지 않는다).</summary>
        internal static EffectPoint Raw(Vector3 position) => new EffectPoint(PointKind.Raw, position, null, null, null);

        /// <summary>
        /// <paramref name="space"/>의 로컬 자리(이펙트 부모 기준, 튕김이 내려앉은 자리처럼 부모를 따라 움직인다).
        /// space가 null이면 월드 자리다. space가 사라지면 자리가 없다(마지막 자리를 쓴다).
        /// </summary>
        internal static EffectPoint Local(Transform space, Vector3 local) => new EffectPoint(PointKind.Local, local, space, null, null);

        /// <summary>이펙트가 놓인 곳의 월드 좌표로 바꾼다. 자리가 없으면 false.</summary>
        internal bool TryResolve(in EffectSpace space, out Vector3 position)
        {
            position = default;
            switch (Kind)
            {
                case PointKind.Raw:
                    position = _value;
                    return true;
                case PointKind.Local:
                    if (ReferenceEquals(_transform, null)) { position = _value; return true; }
                    if (!_transform) return false;
                    position = _transform.TransformPoint(_value);
                    return true;
                case PointKind.World:
                    return FromWorld(_value, space, out position);
                case PointKind.Follow:
                    if (!_transform) return false;
                    return FromWorld(_transform.position + _value, space, out position);
                case PointKind.Screen:
                    return FromScreen((Vector2)_value, space, out position);
                case PointKind.ScreenSource:
                    if (!_source(out var screen)) return false;
                    return FromScreen(screen, space, out position);
                case PointKind.Anchor:
                {
                    var anchor = _transform as RectTransform;
                    if (!anchor) return false;
                    var canvas = anchor.GetComponentInParent<Canvas>(true);
                    var root = canvas ? canvas.rootCanvas : null;
                    var cam = root && root.renderMode != RenderMode.ScreenSpaceOverlay ? root.worldCamera : null;
                    Vector2 at = RectTransformUtility.WorldToScreenPoint(cam, anchor.TransformPoint(anchor.rect.center));
                    return FromScreen(at + (Vector2)_value, space, out position);
                }
                default:
                    return false;
            }
        }

        Camera WorldCamera => _camera ? _camera : Camera.main;

        bool FromWorld(Vector3 world, in EffectSpace space, out Vector3 position)
        {
            position = world;
            if (!space.IsUI) return true;
            var cam = WorldCamera;
            if (!cam) return false;
            var screen = cam.WorldToScreenPoint(world);
            return space.ScreenToPlane(screen, out position);
        }

        bool FromScreen(Vector2 screen, in EffectSpace space, out Vector3 position)
        {
            if (space.IsUI) return space.ScreenToPlane(screen, out position);
            position = default;
            var cam = WorldCamera;
            if (!cam) return false;
            // 원근 카메라는 이펙트가 지금 있는 깊이로 되돌린다.
            float depth = cam.orthographic ? cam.nearClipPlane : Vector3.Dot(space.Reference - cam.transform.position, cam.transform.forward);
            if (!cam.orthographic && depth <= 0f) depth = cam.nearClipPlane;
            position = cam.ScreenToWorldPoint(new Vector3(screen.x, screen.y, depth));
            if (cam.orthographic) position.z = space.Reference.z;
            return true;
        }
    }

    /// <summary>이펙트가 놓인 곳. 부모가 Canvas 아래 RectTransform이면 UI, 아니면 월드다.</summary>
    internal readonly struct EffectSpace
    {
        public readonly bool IsUI;
        public readonly RectTransform Plane;
        public readonly Camera UICamera;
        /// <summary>월드 이펙트를 화면 자리에서 되돌릴 깊이 기준(이펙트의 지금 자리).</summary>
        public readonly Vector3 Reference;

        EffectSpace(bool isUI, RectTransform plane, Camera uiCamera, Vector3 reference)
        {
            IsUI = isUI;
            Plane = plane;
            UICamera = uiCamera;
            Reference = reference;
        }

        public static EffectSpace Of(Transform effect)
        {
            var plane = effect.parent as RectTransform;
            var canvas = plane ? plane.GetComponentInParent<Canvas>(true) : null;
            if (!canvas) return new EffectSpace(false, null, null, effect.position);
            var root = canvas.rootCanvas;
            var cam = root.renderMode != RenderMode.ScreenSpaceOverlay ? root.worldCamera : null;
            return new EffectSpace(true, plane, cam, effect.position);
        }

        public EffectSpace WithReference(Vector3 reference) => new EffectSpace(IsUI, Plane, UICamera, reference);

        public bool ScreenToPlane(Vector2 screen, out Vector3 position)
            => RectTransformUtility.ScreenPointToWorldPointInRectangle(Plane, screen, UICamera, out position);

        /// <summary>곡선을 휘게 할 면의 법선. UI는 판의 앞, 월드는 카메라 앞(없으면 +Z).</summary>
        public Vector3 Normal => NormalFor(null);

        /// <summary><see cref="Normal"/>과 같고 월드에서는 <paramref name="worldCamera"/>(없으면 Camera.main)의 앞이다.</summary>
        public Vector3 NormalFor(Camera worldCamera)
        {
            if (IsUI) return Plane.forward;
            var cam = worldCamera ? worldCamera : Camera.main;
            return cam ? cam.transform.forward : Vector3.forward;
        }
    }
}
