using System.Collections.Generic;
using UnityEngine;

namespace jjevol.Effect.Behaviours
{
    /// <summary>
    /// <see cref="EffectFlight.PlayFlight"/>가 Handle에 붙이는 비행 동작. Handle을 경로대로 옮기고, 마지막 구간이 끝나면 도착을 알린 뒤
    /// (route.endOnArrive면) 요청을 Completed로 끝낸다. 자리는 매 프레임 다시 읽어 대상·카메라가 움직여도 따라간다.
    /// 연출 값은 프리팹의 <see cref="EffectFlightProfile"/>(없으면 route.legs, 그것도 없으면 0.5초 직선)이다.
    /// 튕김(<see cref="EffectFlightLegKind.Bounce"/>) 구간은 구간을 시작할 때의 자리를 부모 기준으로 고정하고 그 자리에서 튀어
    /// 내려앉는다(같은 패키지 <see cref="JumpPopBehaviour"/>·<see cref="UIJumpPopBehaviour"/>의 포물선 튐, 튈 때마다 감쇠).
    /// </summary>
    public sealed class EffectFlightBehaviour : MonoBehaviour, IEffectBehaviour
    {
        static readonly EffectFlightLeg[] DefaultLegs = { new EffectFlightLeg() };

        public bool IsFinished { get; private set; }

        EffectHandle _handle;
        int _version;
        bool _arrived;
        Camera _camera;
        EffectFlightRoute _route;
        EffectFlightState _state;

        IReadOnlyList<EffectFlightLeg> _legs;
        bool _started;
        int _leg;
        bool _legBegun;
        float _t;
        bool _holding;
        float _scaleFrom, _startScale = 1f;
        Vector3 _baseScale;
        float _arcSign = 1f;
        EffectSpace _space;
        EffectPoint _legFrom;
        Vector3 _lastFrom, _lastTo;
        readonly List<(Transform t, int layer)> _layers = new();

        // 튕김 구간: 첫 튐 가로·높이(무작위 반영), 가로·세로 축(월드 벡터, 길이 = 1단위), 내려앉을 자리.
        float _bounceX, _bounceY;
        Vector3 _bounceRight, _bounceUp;
        EffectPoint _bounceLanding;

        // 도착한 자리(마지막 구간이 읽던 자리). endOnArrive=false로 머물 때 매 프레임 다시 읽는다.
        EffectPoint _arrivedAt;

        public void Begin(EffectHandle handle)
        {
            _handle = handle;
            IsFinished = false;
            _started = false;
            _arrived = false;
        }

        internal void Configure(EffectFlightRoute route, EffectFlightState state)
        {
            _route = route;
            _state = state;
            _camera = route.worldCamera;
            _version = _handle != null ? _handle.RequestVersion : 0;
            if (_handle == null) { IsFinished = true; return; }

            // 재생 시작 전(로드 중)에도 출발 자리에 둔다.
            var space = EffectSpace.Of(_handle.transform);
            if (!route.from.IsNone && route.from.TryResolve(space, out var start))
                _handle.transform.position = start;
        }

        void StartFlight()
        {
            _started = true;
            var root = _handle.transform;
            var profile = root.GetComponentInChildren<EffectFlightProfile>(true);
            _legs = profile != null && profile.legs != null && profile.legs.Count > 0 ? profile.legs
                : _route.legs != null && _route.legs.Count > 0 ? _route.legs
                : DefaultLegs;
            _startScale = profile != null ? profile.startScale : 1f;
            _baseScale = root.localScale;
            _scaleFrom = _startScale;
            _space = EffectSpace.Of(root);
            _legFrom = _route.from.IsNone ? EffectPoint.Raw(root.position) : _route.from;
            _lastFrom = root.position;
            _lastTo = _lastFrom;
            _leg = 0;
            _legBegun = false;
            _t = 0f;
            _holding = false;
            _arrivedAt = default;

            if (_space.IsUI && (profile == null || profile.matchUILayer)) MatchLayer(root, _space.Plane.gameObject.layer);

            if (_legFrom.TryResolve(_space.WithReference(root.position), out var start)) { root.position = start; _lastFrom = start; }
            root.localScale = _baseScale * _startScale;
        }

        public void Tick(float dt)
        {
            if (IsFinished) return;
            if (_handle == null || !_handle.IsCurrent(_version)) { IsFinished = true; return; }
            if (!_started) StartFlight();

            var root = _handle.transform;
            if (_arrived) { StayAtTarget(root); return; }
            _t += Mathf.Max(0f, dt);

            while (_leg < _legs.Count)
            {
                var leg = _legs[_leg] ?? DefaultLegs[0];
                bool last = _leg == _legs.Count - 1;
                bool bounce = leg.kind == EffectFlightLegKind.Bounce;
                var space = _space.WithReference(root.position);

                if (_legFrom.TryResolve(space, out var a)) _lastFrom = a;
                a = _lastFrom;
                if (!_legBegun) BeginLeg(leg, bounce, a, root, space);

                var target = bounce ? _bounceLanding : TargetOf(_leg, last);
                if (target.IsNone) _lastTo = a;
                else if (target.TryResolve(space, out var b)) _lastTo = b;
                var to = _lastTo;

                if (!_holding)
                {
                    float k = leg.duration > 0f ? Mathf.Clamp01(_t / leg.duration) : 1f;
                    float e = leg.ease != null && leg.ease.length > 0 ? leg.ease.Evaluate(k) : k;
                    if (bounce)
                    {
                        // 떠난 자리는 BeginLeg에서 부모 기준으로 고정했다. 끝(k = 1)에서는 내려앉은 자리와 같다.
                        root.position = k < 1f ? a + BounceOffset(leg, k) : to;
                        root.localScale = _baseScale * Mathf.LerpUnclamped(_scaleFrom, leg.scale, e);
                    }
                    else
                    {
                        root.position = Along(a, to, e, leg.arc * _arcSign, space.NormalFor(_camera));
                        root.localScale = _baseScale * Mathf.LerpUnclamped(_scaleFrom, leg.scale, e);
                    }
                    if (k < 1f) return;

                    _t -= leg.duration;
                    // 머무는 자리는 비행 중과 같은 자리다: 튕김이면 부모 기준 착지 자리, 대상이 없으면 구간을 시작한 자리.
                    if (last) { _arrivedAt = target.IsNone ? _legFrom : target; break; }
                    _holding = leg.holdAfter > 0f;
                    if (!_holding) { NextLeg(target, leg); continue; }
                }

                root.position = to;
                if (_t < leg.holdAfter) return;
                _t -= leg.holdAfter;
                _holding = false;
                NextLeg(target, leg);
            }

            Arrive(root.position);
        }

        void BeginLeg(EffectFlightLeg leg, bool bounce, Vector3 from, Transform root, in EffectSpace space)
        {
            _legBegun = true;
            _arcSign = !bounce && leg.randomArcSide && Random.value < 0.5f ? -1f : 1f;
            if (!bounce) return;

            float side = leg.randomBounceSide && Random.value < 0.5f ? -1f : 1f;
            float jitter = Mathf.Clamp01(leg.bounceJitter);
            _bounceX = leg.bounceForce.x * side * (1f + Random.Range(-jitter, jitter));
            _bounceY = leg.bounceForce.y * (1f + Random.Range(-jitter, jitter));

            if (space.IsUI)
            {
                // UI 판 단위(px): 판의 가로·세로 1단위를 월드 벡터로.
                _bounceRight = space.Plane.TransformVector(Vector3.right);
                _bounceUp = space.Plane.TransformVector(Vector3.up);
            }
            else
            {
                var cam = _camera ? _camera : Camera.main;
                if (leg.bounceAxes == EffectBounceAxes.Camera && cam)
                {
                    // 화면 기준: 화면 위·오른쪽(탑다운 카메라에서도 화면에 튀어 보인다).
                    _bounceUp = cam.transform.up;
                    _bounceRight = cam.transform.right;
                }
                else
                {
                    // 월드 단위: 세로는 월드 위, 가로는 카메라에서 본 오른쪽(카메라가 바로 내려다보면 월드 오른쪽).
                    _bounceUp = Vector3.up;
                    var right = Vector3.Cross(Vector3.up, space.NormalFor(_camera));
                    _bounceRight = right.sqrMagnitude > 1e-8f ? right.normalized : Vector3.right;
                }
            }

            // 떠난 자리와 내려앉을 자리를 부모 기준으로 고정한다(떠난 대상이 움직여도 튕긴 이펙트는 따라가지 않는다).
            var parent = root.parent;
            var landing = from + BounceOffset(leg, 1f);
            _legFrom = EffectPoint.Local(parent, parent ? parent.InverseTransformPoint(from) : from);
            _bounceLanding = EffectPoint.Local(parent, parent ? parent.InverseTransformPoint(landing) : landing);
        }

        /// <summary>튕김 구간 진행 k(0~1)의 떠난 자리 기준 위치. 튈 때마다 거리·높이가 damping배, 시간은 √damping배다.</summary>
        Vector3 BounceOffset(EffectFlightLeg leg, float k)
        {
            int count = Mathf.Max(1, leg.bounceCount);
            float damping = Mathf.Clamp01(leg.bounceDamping);
            float timeRatio = Mathf.Sqrt(damping);

            float totalTime = 0f, w = 1f;
            for (int i = 0; i < count; i++) { totalTime += w; w *= timeRatio; }

            float x = 0f, y = 0f, scale = 1f, at = 0f;
            w = 1f;
            for (int i = 0; i < count; i++)
            {
                float span = totalTime > 0f ? w / totalTime : 0f;
                float hopX = _bounceX * scale;
                if (span > 0f && k < at + span)
                {
                    float u = Mathf.Clamp01((k - at) / span);
                    x += hopX * u;
                    y = 4f * u * (1f - u) * _bounceY * scale;
                    return _bounceRight * x + _bounceUp * y;
                }
                x += hopX;
                at += span;
                scale *= damping;
                w *= timeRatio;
            }
            return _bounceRight * x;
        }

        EffectPoint TargetOf(int leg, bool last)
        {
            if (last) return _route.to;
            var via = _route.via;
            return via != null && leg < via.Length ? via[leg] : default;
        }

        void NextLeg(EffectPoint reached, EffectFlightLeg leg)
        {
            if (!reached.IsNone) _legFrom = reached;
            _lastFrom = _lastTo;
            _scaleFrom = leg.scale;
            _leg++;
            _legBegun = false;
        }

        static Vector3 Along(Vector3 a, Vector3 b, float e, float arc, Vector3 normal)
        {
            if (Mathf.Approximately(arc, 0f)) return Vector3.LerpUnclamped(a, b, e);
            var d = b - a;
            var side = Vector3.Cross(d, normal);
            if (side.sqrMagnitude < 1e-10f) return Vector3.LerpUnclamped(a, b, e);
            var control = (a + b) * 0.5f + side.normalized * (arc * d.magnitude);
            float u = 1f - e;
            return u * u * a + 2f * u * e * control + e * e * b;
        }

        void Arrive(Vector3 position)
        {
            var handle = _handle;
            int version = _version;
            bool end = _route == null || _route.endOnArrive;
            // endOnArrive=false면 요청이 끝날 때까지 도착 자리에 머문다(UI 레이어도 그때 되돌린다).
            if (end) IsFinished = true;
            else _arrived = true;
            _state?.Arrive(position);
            if (end && _route != null && handle != null && handle.IsCurrent(version))
                handle.Terminate(EffectEndReason.Completed);
        }

        /// <summary>
        /// 도착 뒤 끝내지 않는 비행: 도착 자리(움직이는 대상이면 그 대상)에 머문다. 마지막 구간이 튕김이면 내려앉은 자리를
        /// 부모 기준으로 다시 읽어 부모를 따라간다.
        /// </summary>
        void StayAtTarget(Transform root)
        {
            var to = _arrivedAt;
            if (!to.IsNone && to.TryResolve(_space.WithReference(root.position), out var at)) _lastTo = at;
            root.position = _lastTo;
        }

        void MatchLayer(Transform root, int layer)
        {
            _layers.Clear();
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                _layers.Add((t, t.gameObject.layer));
                t.gameObject.layer = layer;
            }
        }

        public void End()
        {
            foreach (var (t, layer) in _layers)
                if (t) t.gameObject.layer = layer;
            _layers.Clear();
            _handle = null;
            _route = null;
            _state = null;
            _legs = null;
            _started = false;
            _arrived = false;
            _camera = null;
            _legBegun = false;
            _bounceLanding = default;
            _arrivedAt = default;
            IsFinished = true;
        }
    }
}
