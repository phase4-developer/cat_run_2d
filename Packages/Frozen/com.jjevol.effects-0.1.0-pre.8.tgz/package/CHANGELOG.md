# Changelog

## 0.1.0-pre.8 - 2026-11-20

Low findings of the pre.7 review (FW-FX-ARRIVE, central request `9ee9a8f1901c`). No code or public API change; pre.5 to pre.7 code keeps working.

- Docs: `endOnArrive = false` after a final `Move` leg without `route.to` stays on the point that leg started from and follows it while staying, for example `from = Follow(moving source)` in a single leg (after earlier legs that point is the last `via` or a bounce landing). This is the behaviour since pre.7; pre.6 stayed on the last world position. The README stay sentence now names every case.
- Tests: staying after a final bounce with `route.to` set stays on the landing fixed to the effect parent and does not jump to `to` (the pre.6 regression). The pooled reuse test comment states its scope: it checks the reset of the stay state through `_arrived`; the stay point `_arrivedAt` is always rewritten before it is read, so a stale value cannot be observed.

## 0.1.0-pre.7 - 2026-11-20

Low findings of the pre.6 review (FW-FX-ARRIVE, central request `9ee9a8f1901c`). No public API change; pre.5 and pre.6 code keeps working.

- `endOnArrive = false` after a final `Bounce` leg: the effect now stays on the landing fixed to the effect parent, so it moves with the parent like during the bounce. In pre.6 it stayed on the last world position, and with `route.to` set it jumped from the landing to `to`.
- Tests: staying after a final bounce follows the effect parent; the pooled reuse test now ends its first flight with `endOnArrive = false` and `Despawn`, so it checks that the stay state is reset for the next flight.

## 0.1.0-pre.6 - 2026-11-20

Follow-ups of FW-FX-ARRIVE (central request `9ee9a8f1901c`). Public members are only added; pre.5 code keeps working.

- `endOnArrive = false`: after `onArrived` the effect now stays on the target (following a moving target) until the game ends the request, and under a UI plane it keeps the plane's layer until then. In pre.5 the flight behaviour finished on arrival, so the effect stopped where it was and got its original layers back at once (it could disappear from a UI camera).
- New `EffectFlightRoute.worldCamera`: the camera for the arc plane and the world bounce axes (default `Camera.main`). Points keep their own projection camera.
- New `EffectFlightLeg.bounceAxes` (`EffectBounceAxes.WorldUp` default, or `Camera`): world bounces can hop along the camera's up and right, so they show in top-down views. UI bounces always use the plane axes.
- Tests: bounce fixed to the effect parent, pooled handle reuse with one arrival per flight, `endOnArrive = false` layer and target, camera-axis bounce, canceled burst.

## 0.1.0-pre.5 - 2026-11-20

- New flight with an arrival event (FW-FX-ARRIVE, central request `9ee9a8f1901c`). `IEffectPlayer.PlayFlight(request, EffectFlightRoute)` plays an effect and flies it from `from` through `via` to `to`, calls `onArrived(position)` once on arrival, then ends the request as `Completed` (`endOnArrive`, default true). `onEnded(bool arrived)` runs exactly once for every end, also when `Play` is rejected, so game counters such as gauges never stall.
- `EffectPoint`: world point, moving `Transform` (`Follow`), uGUI `Anchor` on any Canvas, fixed screen point or a per-frame screen source. Points are read every frame, so moving targets and moving cameras are followed. World points are projected into UI effects with the world camera, and UI or screen points are unprojected into world effects.
- `EffectFlightProfile` (prefab component) is the source for flight timing: legs with duration, ease curve, arc, end scale and hold. `EffectFlightRoute.legs` is used only when the prefab has no profile; without both one 0.5 s straight leg is used. Under a UI plane the effect takes the plane's layer during the flight and gets its layers back at the end (`matchUILayer`).
- Bounce legs (`EffectFlightLegKind.Bounce`, user 2026-11-20 "coin pops out"): the effect hops up from where the leg starts and bounces `bounceCount` times before landing beside it (`bounceForce` first hop x/y, `bounceDamping`, `randomBounceSide`, `bounceJitter`; plane px under a UI plane, world units in the world). The landing is where the next leg starts, so `[Bounce (holdAfter), Move]` on the prefab gives pop out, pause, fly to target, arrival event. `EffectFlightLeg.Bounce(...)` builds one from code. The hop is the parabola of `JumpPopBehaviour`/`UIJumpPopBehaviour`.
- `PlayFlightBurst(request, count, interval, routeFor, token)` launches several flights at an interval (scaled or unscaled as the request) and returns the number that arrived.
- Existing behaviours (`MoveToTargetBehaviour`, `MoveCurveBehaviour`) are unchanged.

## 0.1.0-pre.4 - 2026-11-12

- Spawners: the GameObject pools, prefab cache, settle queue and playback pipeline moved from `EffectManager` into the internal `GameObjectEffectSpawner` without changing what they do. `EffectManager` keeps its serialized fields and public API and now drives a list of spawners: `Update` and `LateUpdate` every frame, `DespawnAll` when disabled, `Resume` when enabled and `Shutdown` when destroyed.
- New public `IEffectSpawner`, `EffectManager.AddSpawner` and `EffectManager.GetSpawner<T>()` for spawners of other render kinds (`com.jjevol.effects.uitoolkit` adds the VisualElement spawner). An added spawner that throws is logged and the others go on.
- New public `IEffectInstance` (`EffectType`, `IsPlaying`, `IsLoop`, `Pause`, `Resume`, `Stop`, `Despawn`). `EffectHandle` implements it and gains `Despawn()`, the same as `EffectManager.Despawn(handle)`. `Play` still returns `EffectHandle` (UI Toolkit plan G6).

## 0.1.0-pre.3 - 2026-11-10

- The asset menu `jjevol/Effect/Pool Profiles` is now `JJEvol/Effects/Pool Profiles`. Framework menus are grouped by feature under one `JJEvol/` root (Editor menus), `Assets/Create/JJEvol/` (asset menus) and `GameObject/UI/JJEvol/` (UI objects). Only the menu path changed; class names, serialized fields and GUIDs are unchanged, so existing assets keep working.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.2 - 2026-11-06

- `EffectHandle` has one lifetime state and every ending uses one path, so `callBack` runs exactly once.
- `Play` and `PlayAsync` share one pipeline. `EffectPrefabCache` keeps one record per key and failed loads retry.
- Handles under an inactive parent end or wait safely, with deferred reparenting.
- Fixed code attached `FollowTargetBehaviour`, Pause and Sorting leaking through the pool, and prefabs with child-only ParticleSystems.
- Added optional `IEffectRendererStateRestore` and `EffectSortingSnapshot`.
- Added public `EffectEndReason`, `IEffectPlayer` (implemented by `EffectManager`) and `EffectRequest.onEnded`, a new trailing optional constructor parameter. `onEnded` runs once for every end, after `callBack` and `OnComplete`.
- `callBack`, `OnComplete` and `onEnded` run before the handle returns to the pool, so a `Play` inside them takes another handle.
- Behaviour change: a non-loop handle ended by a deactivated hierarchy or a destroyed parent now ends as `Interrupted` and no longer raises `OnComplete`. `callBack` still runs once.
- `EffectManager` is split into internal `EffectPool`, `EffectPlaybackPipeline`, `EffectInstanceBinder` and `EffectSettleQueue`, built by constructor. `EffectHandle` depends only on `IEffectHandleHost`.

Unity tests for this candidate are NOT_RUN.

# 0.1.0-pre.1 — 2026-10-31

Local extraction candidate. Existing request/renderer/behaviour contracts retained. Core prefab-provider seam, completion and idle identity guards, duplicate return protection and external-parent ownership added. Vendor/UI sources preserved but not validated. Overall PARTIAL.

STEP 6 local candidate corrections (same unpublished version): pause now suspends behaviour and renderer timeout progression; particle simulation observes unscaled timing. Disabled Play/PlayAsync cannot consume pool slots. GameObject re-enable restarts idle eviction. Scene-destroyed handles retire pool ownership and release the final prefab lease. Added 23 Editor PlayMode feature/lifetime tests. Basic Core validation passed; full Vendor/UI/content/Player transfer remains PARTIAL. No snapshot or publication.
