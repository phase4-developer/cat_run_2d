#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Effect.Tests
{
    // FW-FX-ARRIVE: 이펙트가 어디로 날아가 도착하면 알리고 사라지는지. 독립 fixture만 쓴다.
    public sealed class EffectsFlightTests
    {
        sealed class Provider : IEffectPrefabProvider
        {
            public GameObject Prefab;
            public UniTask<EffectPrefabLease> LoadAsync(string key, CancellationToken token)
                => UniTask.FromResult(new EffectPrefabLease(Prefab, () => { }));
        }

        EffectManager manager;
        GameObject prefab;
        readonly List<GameObject> extras = new();

        static IEnumerator Until(Func<bool> predicate, string message, float seconds = 3f)
        {
            float end = Time.realtimeSinceStartup + seconds;
            while (!predicate() && Time.realtimeSinceStartup < end) yield return null;
            Assert.IsTrue(predicate(), message);
        }

        GameObject Extra(string name, params Type[] components)
        {
            var go = new GameObject(name, components); extras.Add(go); return go;
        }

        // 루프 파티클이 아닌 고정 fixture: Renderer가 스스로 끝나지 않게 ControlledEffectRenderer를 쓴다.
        static EffectRequest Request(Transform parent = null) => new EffectRequest("flight", loop: true, unscaledTime: true, parent: parent);

        static EffectFlightLeg[] Legs(params float[] seconds)
        {
            var legs = new EffectFlightLeg[seconds.Length];
            for (int i = 0; i < seconds.Length; i++) legs[i] = new EffectFlightLeg(seconds[i]);
            return legs;
        }

        [UnitySetUp] public IEnumerator Setup()
        {
            Time.timeScale = 1;
            prefab = new GameObject("flight-fixture");
            prefab.AddComponent<ControlledEffectRenderer>();
            manager = new GameObject("flight-manager").AddComponent<EffectManager>();
            manager.SetPrefabProvider(new Provider { Prefab = prefab });
            yield return null;
        }

        [UnityTearDown] public IEnumerator Cleanup()
        {
            if (manager) Object.Destroy(manager.gameObject);
            foreach (var go in extras) if (go) Object.Destroy(go);
            if (prefab) Object.Destroy(prefab);
            extras.Clear();
            yield return null; yield return null;
        }

        [UnityTest] public IEnumerator WorldFlightArrivesThenEndsCompleted()
        {
            Vector3? arrivedAt = null; bool? ended = null; EffectEndReason? reason = null;
            var req = Request(); req.onEnded = r => reason = r;
            var route = new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(new Vector3(4, 0, 0)),
                p => arrivedAt = p, ok => ended = ok) { legs = Legs(0.2f) };

            var handle = manager.PlayFlight(req, route);
            Assert.IsNotNull(handle);
            Assert.AreEqual(Vector3.zero, handle.transform.position, "starts at the from point before playback");
            yield return Until(() => ended.HasValue, "flight must end");

            Assert.IsTrue(ended.Value, "arrived");
            Assert.IsTrue(arrivedAt.HasValue);
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(4, 0, 0)), Is.LessThan(1e-3f));
            Assert.AreEqual(EffectEndReason.Completed, reason, "arrival ends the request as Completed");
            Assert.IsFalse(handle.gameObject.activeSelf, "handle returned to the pool");
        }

        [UnityTest] public IEnumerator FollowsMovingTargetUntilArrival()
        {
            var target = Extra("moving-target").transform;
            target.position = new Vector3(2, 0, 0);
            Vector3? arrivedAt = null;
            var route = new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.Follow(target), p => arrivedAt = p) { legs = Legs(0.3f) };
            manager.PlayFlight(Request(), route);
            yield return null; yield return null;
            target.position = new Vector3(0, 5, 0);
            yield return Until(() => arrivedAt.HasValue, "must arrive");
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(0, 5, 0)), Is.LessThan(1e-3f), "arrives where the target is now");
        }

        [UnityTest] public IEnumerator ViaHoldAndProfileComeFromPrefab()
        {
            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg> { new EffectFlightLeg(0.1f, holdAfter: 0.2f), new EffectFlightLeg(0.1f, scale: 0.5f) };
            var times = new List<float>(); float start = Time.realtimeSinceStartup;
            Vector3? arrivedAt = null;
            var route = new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(new Vector3(0, 3, 0)), p => arrivedAt = p)
            {
                via = new[] { EffectPoint.World(new Vector3(1, 0, 0)) },
                legs = Legs(5f) // 프리팹 값이 먼저다
            };
            var handle = manager.PlayFlight(Request(), route);
            yield return Until(() => arrivedAt.HasValue, "must arrive", 2f);
            float took = Time.realtimeSinceStartup - start;
            Assert.That(took, Is.GreaterThanOrEqualTo(0.35f), "rise + hold + fly");
            Assert.That(took, Is.LessThan(2f), "prefab legs win over route.legs");
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(0, 3, 0)), Is.LessThan(1e-3f));
            Assert.IsFalse(handle.gameObject.activeSelf);
        }

        [UnityTest] public IEnumerator FlightToUIAnchorOnOverlayCanvas()
        {
            var canvasGo = Extra("flight-canvas", typeof(Canvas));
            var canvas = canvasGo.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvasGo.layer = LayerMask.NameToLayer("UI");
            var plane = new GameObject("effect-root", typeof(RectTransform)).GetComponent<RectTransform>();
            plane.SetParent(canvas.transform, false); plane.gameObject.layer = canvasGo.layer;
            var anchor = new GameObject("hud-anchor", typeof(RectTransform)).GetComponent<RectTransform>();
            anchor.SetParent(canvas.transform, false);
            anchor.position = new Vector3(120, 80, 0);

            Vector3? arrivedAt = null; int layerDuring = -1; EffectHandle handle = null;
            var route = new EffectFlightRoute(EffectPoint.Screen(new Vector2(10, 10)), EffectPoint.Anchor(anchor), p =>
            {
                arrivedAt = p;
                layerDuring = handle.gameObject.layer;
            }) { legs = Legs(0.15f) };
            handle = manager.PlayFlight(Request(plane), route);
            yield return Until(() => arrivedAt.HasValue, "must arrive at the HUD anchor");
            Assert.That(Vector2.Distance(arrivedAt.Value, new Vector2(120, 80)), Is.LessThan(0.5f));
            Assert.AreEqual(plane.gameObject.layer, layerDuring, "flies on the UI layer");
        }

        [UnityTest] public IEnumerator InterruptedFlightEndsOnceWithoutArrival()
        {
            int arrivals = 0, ends = 0; bool? ok = null;
            var route = new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(Vector3.right * 10),
                _ => arrivals++, r => { ends++; ok = r; }) { legs = Legs(5f) };
            var handle = manager.PlayFlight(Request(), route);
            yield return null; yield return null;
            handle.Despawn();
            yield return null;
            Assert.AreEqual(0, arrivals);
            Assert.AreEqual(1, ends);
            Assert.IsFalse(ok.Value);
        }

        [UnityTest] public IEnumerator RejectedPlayReportsEndedFalse()
        {
            bool? ok = null;
            var handle = manager.PlayFlight(new EffectRequest(""), new EffectFlightRoute(default, EffectPoint.World(Vector3.one), onEnded: r => ok = r));
            Assert.IsNull(handle);
            Assert.IsFalse(ok.Value);
            yield break;
        }

        // 튕김(사용자 2026-11-20 「나올때 코인 튕기듯이 나오는것」): 첫 튐 가로 2, 감쇠 0.5, 2번 → 2 + 1 = 3에 내려앉는다.
        [UnityTest] public IEnumerator WorldBounceHopsAndLandsBesideStart()
        {
            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg> { EffectFlightLeg.Bounce(0.3f, new Vector2(2f, 3f), count: 2, damping: 0.5f) };
            Vector3? arrivedAt = null; float peak = 0f; float minY = 0f;
            var handle = manager.PlayFlight(Request(), new EffectFlightRoute(EffectPoint.World(Vector3.zero), default, p => arrivedAt = p));
            Assert.IsNotNull(handle);
            float end = Time.realtimeSinceStartup + 3f;
            while (!arrivedAt.HasValue && Time.realtimeSinceStartup < end)
            {
                if (handle.gameObject.activeSelf) { peak = Mathf.Max(peak, handle.transform.position.y); minY = Mathf.Min(minY, handle.transform.position.y); }
                yield return null;
            }
            Assert.IsTrue(arrivedAt.HasValue, "a bounce-only flight arrives where it lands");
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(3f, 0f, 0f)), Is.LessThan(1e-3f), "lands at first hop + damped second hop");
            Assert.That(peak, Is.GreaterThan(1f), "hops up");
            Assert.That(peak, Is.LessThanOrEqualTo(3f + 1e-3f), "first hop height is the vertical force");
            Assert.That(minY, Is.GreaterThanOrEqualTo(-1e-3f), "never sinks below the start");
        }

        // 「튕겨 나옴 → 멈춤 → 대상으로 비행 → 도착 이벤트」를 Prefab 설정만으로.
        [UnityTest] public IEnumerator BounceHoldThenFlyToTarget()
        {
            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg>
            {
                EffectFlightLeg.Bounce(0.15f, new Vector2(2f, 1f), count: 1, holdAfter: 0.25f),
                new EffectFlightLeg(0.15f),
            };
            Vector3? arrivedAt = null; bool restedOnLanding = false;
            float start = Time.realtimeSinceStartup;
            var handle = manager.PlayFlight(Request(), new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(new Vector3(0f, 5f, 0f)), p => arrivedAt = p));
            float end = start + 3f;
            while (!arrivedAt.HasValue && Time.realtimeSinceStartup < end)
            {
                if (handle.gameObject.activeSelf && Vector3.Distance(handle.transform.position, new Vector3(2f, 0f, 0f)) < 1e-3f) restedOnLanding = true;
                yield return null;
            }
            Assert.IsTrue(arrivedAt.HasValue, "must arrive");
            Assert.IsTrue(restedOnLanding, "rests where it landed during the hold");
            Assert.That(Time.realtimeSinceStartup - start, Is.GreaterThanOrEqualTo(0.5f), "bounce + hold + fly");
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(0f, 5f, 0f)), Is.LessThan(1e-3f), "arrives at the route target");
            Assert.IsFalse(handle.gameObject.activeSelf, "ended after arrival");
        }

        // UI 판 아래에서는 튕김 힘이 판 단위(px)다. 오버레이 Canvas(배율 1)면 화면 px와 같다.
        [UnityTest] public IEnumerator UIBounceUsesPlaneUnits()
        {
            var canvasGo = Extra("bounce-canvas", typeof(Canvas));
            canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var plane = new GameObject("effect-root", typeof(RectTransform)).GetComponent<RectTransform>();
            plane.SetParent(canvasGo.transform, false);

            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg> { EffectFlightLeg.Bounce(0.2f, new Vector2(-50f, 40f), count: 2, damping: 0.5f) };
            Vector3? arrivedAt = null;
            manager.PlayFlight(Request(plane), new EffectFlightRoute(EffectPoint.Screen(new Vector2(200f, 100f)), default, p => arrivedAt = p));
            yield return Until(() => arrivedAt.HasValue, "must land");
            Assert.That(Vector2.Distance(arrivedAt.Value, new Vector2(200f - 75f, 100f)), Is.LessThan(0.5f), "-50 px then -25 px to the left");
        }

        // 튕김의 떠난 자리·내려앉을 자리는 이펙트 부모 기준으로 고정된다: 떠난 대상이 움직여도 따라가지 않고, 부모가 움직이면 함께 간다.
        [UnityTest] public IEnumerator BounceIsFixedToTheEffectParent()
        {
            var parent = Extra("bounce-parent").transform;
            var source = Extra("bounce-source").transform;
            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg> { EffectFlightLeg.Bounce(0.4f, new Vector2(2f, 1f), count: 1) };
            Vector3? arrivedAt = null;
            manager.PlayFlight(Request(parent), new EffectFlightRoute(EffectPoint.Follow(source), default, p => arrivedAt = p));
            yield return null; yield return null;
            source.position = new Vector3(50f, 0f, 0f);
            parent.position = new Vector3(0f, 5f, 0f);
            yield return Until(() => arrivedAt.HasValue, "must land");
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(2f, 5f, 0f)), Is.LessThan(1e-3f), "moved with the parent, not with the source");
        }

        // 마지막 구간이 튕김이고 to가 없으면 endOnArrive=false로 머무는 자리도 부모 기준 착지 자리다: 부모가 움직이면 따라간다.
        [UnityTest] public IEnumerator StayAfterFinalBounceFollowsTheEffectParent()
        {
            var parent = Extra("stay-bounce-parent").transform;
            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg> { EffectFlightLeg.Bounce(0.15f, new Vector2(2f, 1f), count: 1) };
            int arrivals = 0; Vector3? arrivedAt = null; bool? ended = null;
            var handle = manager.PlayFlight(Request(parent), new EffectFlightRoute(EffectPoint.World(Vector3.zero), default,
                p => { arrivals++; arrivedAt = p; }, ok => ended = ok) { endOnArrive = false });
            yield return Until(() => arrivedAt.HasValue, "must land");
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(2f, 0f, 0f)), Is.LessThan(1e-3f));
            yield return null; yield return null;
            Assert.IsTrue(handle.gameObject.activeSelf, "stays after landing");
            parent.position = new Vector3(0f, 5f, 0f);
            yield return null; yield return null;
            Assert.That(Vector3.Distance(handle.transform.position, new Vector3(2f, 5f, 0f)), Is.LessThan(1e-3f), "stays on the landing and moves with the parent");

            handle.Despawn();
            yield return null;
            Assert.AreEqual(1, arrivals);
            Assert.IsTrue(ended.Value, "ended once, as arrived");
        }

        // 마지막 구간이 튕김이면 route.to가 있어도 튕김은 그 점을 쓰지 않는다. endOnArrive=false로 머무는 자리도 부모 기준 착지
        // 자리이며 to로 튀지 않는다(pre.6에서는 착지 뒤 to로 튀었다).
        [UnityTest] public IEnumerator StayAfterFinalBounceWithTargetStaysOnTheLanding()
        {
            var parent = Extra("stay-bounce-to-parent").transform;
            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg> { EffectFlightLeg.Bounce(0.15f, new Vector2(2f, 1f), count: 1) };
            int arrivals = 0; Vector3? arrivedAt = null; bool? ended = null;
            var handle = manager.PlayFlight(Request(parent), new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(new Vector3(0f, 0f, 9f)),
                p => { arrivals++; arrivedAt = p; }, ok => ended = ok) { endOnArrive = false });
            yield return Until(() => arrivedAt.HasValue, "must land");
            Assert.That(Vector3.Distance(arrivedAt.Value, new Vector3(2f, 0f, 0f)), Is.LessThan(1e-3f), "a final bounce arrives where it lands, not at route.to");
            yield return null; yield return null;
            Assert.IsTrue(handle.gameObject.activeSelf, "stays after landing");
            Assert.That(Vector3.Distance(handle.transform.position, new Vector3(2f, 0f, 0f)), Is.LessThan(1e-3f), "stays on the landing, does not jump to route.to");
            parent.position = new Vector3(0f, 5f, 0f);
            yield return null; yield return null;
            Assert.That(Vector3.Distance(handle.transform.position, new Vector3(2f, 5f, 0f)), Is.LessThan(1e-3f), "the landing moves with the parent");

            handle.Despawn();
            yield return null;
            Assert.AreEqual(1, arrivals);
            Assert.IsTrue(ended.Value, "ended once, as arrived");
        }

        // 같은 Handle을 풀에서 다시 써도 비행마다 도착은 한 번이고, 앞 비행의 상태(도착 뒤 머묾 포함)가 남지 않는다.
        // 범위: 머묾 상태가 초기화됐는지는 _arrived 기준으로 본다(두 번째 비행이 머물지 않고 날아가 한 번 도착한다).
        // 머무는 자리(_arrivedAt)의 초기화는 관찰하지 않는다. 마지막 구간이 끝날 때 늘 다시 쓰고 그 뒤에만 읽으므로
        // 남은 값이 동작에 드러나지 않는다.
        [UnityTest] public IEnumerator ReusedHandleFliesAgainAndArrivesOnce()
        {
            int first = 0, second = 0; Vector3? secondAt = null;
            var h1 = manager.PlayFlight(Request(), new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(Vector3.right * 3), _ => first++)
                { legs = Legs(0.1f), endOnArrive = false });
            yield return Until(() => first == 1, "first flight arrives");
            yield return null; yield return null;
            Assert.IsTrue(h1.gameObject.activeSelf, "first flight stays after arrival");
            h1.Despawn();
            yield return Until(() => !h1.gameObject.activeSelf, "first flight ends");
            var h2 = manager.PlayFlight(Request(), new EffectFlightRoute(EffectPoint.World(Vector3.up), EffectPoint.World(new Vector3(0f, 4f, 0f)), p => { second++; secondAt = p; }) { legs = Legs(0.1f) });
            Assert.AreSame(h1, h2, "pooled handle is reused");
            yield return Until(() => secondAt.HasValue, "second flight arrives");
            yield return null; yield return null;
            Assert.AreEqual(1, first);
            Assert.AreEqual(1, second);
            Assert.That(Vector3.Distance(secondAt.Value, new Vector3(0f, 4f, 0f)), Is.LessThan(1e-3f));
        }

        // endOnArrive=false: 도착 뒤에도 UI 레이어로 대상에 머물고, 게임이 끝낼 때 레이어를 되돌린다.
        [UnityTest] public IEnumerator StayAfterArrivalKeepsUILayerUntilTheGameEndsIt()
        {
            var canvasGo = Extra("stay-canvas", typeof(Canvas));
            canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            canvasGo.layer = LayerMask.NameToLayer("UI");
            var plane = new GameObject("effect-root", typeof(RectTransform)).GetComponent<RectTransform>();
            plane.SetParent(canvasGo.transform, false); plane.gameObject.layer = canvasGo.layer;
            var anchor = new GameObject("hud-anchor", typeof(RectTransform)).GetComponent<RectTransform>();
            anchor.SetParent(canvasGo.transform, false);
            anchor.position = new Vector3(100, 60, 0);

            int arrivals = 0; bool? ended = null;
            var route = new EffectFlightRoute(EffectPoint.Screen(new Vector2(10, 10)), EffectPoint.Anchor(anchor), _ => arrivals++, ok => ended = ok)
            { legs = Legs(0.1f), endOnArrive = false };
            var handle = manager.PlayFlight(Request(plane), route);
            int originalLayer = handle.gameObject.layer;
            Assert.AreNotEqual(plane.gameObject.layer, originalLayer, "fixture starts outside the UI layer");
            yield return Until(() => arrivals == 1, "must arrive");
            for (int i = 0; i < 5; i++) yield return null;
            Assert.IsTrue(handle.gameObject.activeSelf, "stays after arrival");
            Assert.IsFalse(ended.HasValue, "not ended yet");
            Assert.AreEqual(plane.gameObject.layer, handle.gameObject.layer, "keeps the UI layer after arrival");
            anchor.position = new Vector3(140, 90, 0);
            yield return null; yield return null;
            Assert.That(Vector2.Distance(handle.transform.position, new Vector2(140, 90)), Is.LessThan(0.5f), "stays on the moving target");

            handle.Despawn();
            yield return null;
            Assert.AreEqual(1, arrivals);
            Assert.IsTrue(ended.Value, "ended once, as arrived");
            Assert.AreEqual(originalLayer, handle.gameObject.layer, "layer restored when the request ends");
        }

        // 카메라 축 튕김: 내려다보는 카메라에서 화면 위(카메라 위)로 튀고 화면 오른쪽에 내려앉는다.
        [UnityTest] public IEnumerator CameraAxesBounceUsesTheRouteCamera()
        {
            var cam = Extra("top-down-camera", typeof(Camera)).GetComponent<Camera>();
            cam.transform.SetPositionAndRotation(new Vector3(0f, 10f, 0f), Quaternion.Euler(90f, 0f, 0f));
            var leg = EffectFlightLeg.Bounce(0.3f, new Vector2(2f, 1.5f), count: 1);
            leg.bounceAxes = EffectBounceAxes.Camera;
            var profile = prefab.AddComponent<EffectFlightProfile>();
            profile.legs = new List<EffectFlightLeg> { leg };
            Vector3? arrivedAt = null; float peakForward = 0f; float maxY = 0f;
            var handle = manager.PlayFlight(Request(), new EffectFlightRoute(EffectPoint.World(Vector3.zero), default, p => arrivedAt = p) { worldCamera = cam });
            float end = Time.realtimeSinceStartup + 3f;
            while (!arrivedAt.HasValue && Time.realtimeSinceStartup < end)
            {
                if (handle.gameObject.activeSelf)
                {
                    peakForward = Mathf.Max(peakForward, Vector3.Dot(handle.transform.position, cam.transform.up));
                    maxY = Mathf.Max(maxY, Mathf.Abs(handle.transform.position.y));
                }
                yield return null;
            }
            Assert.IsTrue(arrivedAt.HasValue, "must land");
            Assert.That(Vector3.Distance(arrivedAt.Value, cam.transform.right * 2f), Is.LessThan(1e-3f), "lands to the camera's right");
            Assert.That(peakForward, Is.GreaterThan(0.5f), "hops toward the top of the screen");
            Assert.That(maxY, Is.LessThan(1e-3f), "does not hop toward the camera");
        }

        // 취소하면 남은 비행은 내보내지 않고, 내보낸 것만 도착으로 세어 끝난다.
        [UnityTest] public IEnumerator CanceledBurstStopsLaunchingAndCountsOnlyArrivals()
        {
            int launched = 0, arrivals = 0;
            using var cts = new CancellationTokenSource();
            var task = manager.PlayFlightBurst(Request(), 5, 0.3f, i =>
            {
                launched++;
                return new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(Vector3.right), _ => arrivals++) { legs = Legs(0.05f) };
            }, cts.Token);
            int result = -1; bool done = false;
            task.ContinueWith(n => { result = n; done = true; }).Forget();
            yield return null;
            cts.Cancel();
            yield return Until(() => done, "burst must finish after cancel");
            Assert.AreEqual(1, launched, "only the first flight was launched");
            Assert.AreEqual(1, arrivals);
            Assert.AreEqual(1, result, "returns the arrived count");
        }

        [UnityTest] public IEnumerator BurstLaunchesAllAndCountsArrivals()
        {
            int arrivals = 0;
            var task = manager.PlayFlightBurst(Request(), 3, 0.05f,
                i => new EffectFlightRoute(EffectPoint.World(Vector3.zero), EffectPoint.World(new Vector3(i, 2, 0)), _ => arrivals++) { legs = Legs(0.1f) });
            int result = -1; bool done = false;
            task.ContinueWith(n => { result = n; done = true; }).Forget();
            yield return Until(() => done, "burst must finish");
            Assert.AreEqual(3, result);
            Assert.AreEqual(3, arrivals);
        }
    }
}
#endif
