using System;
using System.Collections.Generic;

namespace PlatformLibrary.Push
{
    /// <summary>
    /// One provider's push state. <see cref="PushManager"/> creates one per provider and closes it when the provider
    /// changes. Every member runs on the main thread. Provider answers come back through <see cref="IPushHost.Post"/>.
    /// <para>
    /// <see cref="SetEnabled"/> and <see cref="SetTopics"/> only record the wanted state. A pass then makes one SDK call
    /// at a time and re-reads the wanted state after each answer, so a late answer never wins over a newer setting.
    /// </para>
    /// </summary>
    internal sealed class PushSession
    {
        internal const float RetryDelaySeconds = 30f;
        internal const int MaxPendingMessages = 16;
        internal const string TopicsKeyPrefix = "PlatformLibrary.Push.Topics.";

        private readonly IPushProvider _provider;
        private readonly IPushHost _host;
        private readonly Action<string> _tokenChanged;
        private readonly Action<PushMessage> _messageReceived;
        private readonly Func<bool> _hasMessageListeners;
        private readonly Action<PushResult> _synchronized;

        private readonly List<string> _wantedTopics = new List<string>();
        private readonly List<string> _savedTopics = new List<string>();
        private readonly HashSet<string> _confirmedTopics = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _triedThisPass = new HashSet<string>(StringComparer.Ordinal);
        private readonly Queue<PushMessage> _pending = new Queue<PushMessage>();
        private readonly List<Action<PushResult>> _unanswered = new List<Action<PushResult>>();

        private bool? _enabled;
        private bool _closed;
        private bool _initializeRequested;
        private bool _initializing;
        private bool _permissionRequested;
        private bool _tokenDeleted;
        private bool _syncing;
        private bool _syncRequested;
        private bool _passFailed;
        private PushResult _passFailure;
        private Action _cancelRetry;
        private string _topicsKey;

        public PushSession(IPushProvider provider, IPushHost host, Action<string> tokenChanged,
            Action<PushMessage> messageReceived, Func<bool> hasMessageListeners, Action<PushResult> synchronized)
        {
            _provider = provider ?? throw new ArgumentNullException(nameof(provider));
            _host = host ?? throw new ArgumentNullException(nameof(host));
            _tokenChanged = tokenChanged;
            _messageReceived = messageReceived;
            _hasMessageListeners = hasMessageListeners;
            _synchronized = synchronized;

            _provider.TokenReceived += OnTokenReceived;
            _provider.MessageReceived += OnMessageReceived;
            _host.Resumed += OnResumed;
        }

        public IPushProvider Provider => _provider;
        public bool IsInitialized { get; private set; }
        public string Token { get; private set; } = string.Empty;

        internal IReadOnlyCollection<string> SavedTopics => _savedTopics;
        internal int PendingMessageCount => _pending.Count;
        internal bool IsRetryScheduled => _cancelRetry != null;

        public void Initialize()
        {
            if (_closed || IsInitialized || _initializing) return;
            _initializeRequested = true;
            _initializing = true;

            Call(_provider.Initialize, result =>
            {
                _initializing = false;
                if (!result.Success)
                {
                    _host.LogWarning("Initialize failed. Retry in " + RetryDelaySeconds + "s. " + result);
                    ScheduleRetry();
                    Raise(_synchronized, result);
                    return;
                }

                IsInitialized = true;
                _topicsKey = TopicsKeyPrefix + ReadScopeId();
                LoadSavedTopics();
                RequestSync();
            });
        }

        public void SetEnabled(bool enabled)
        {
            if (_closed || _enabled == enabled) return;
            _enabled = enabled;

            if (enabled)
            {
                _tokenDeleted = false;
                FlushPending();
            }
            else
            {
                _pending.Clear();
                SetToken(string.Empty);
            }

            if (IsInitialized) SetAutoRegistration(enabled);
            RequestSync();
        }

        public void SetTopics(IReadOnlyList<string> topics)
        {
            if (_closed || SameTopics(topics)) return;
            _wantedTopics.Clear();
            _wantedTopics.AddRange(topics);
            RequestSync();
        }

        public void RequestPermission(Action<PushResult> callback)
        {
            if (_closed || !IsInitialized)
            {
                Raise(callback, PushResult.Failed(PushFailure.NotInitialized, 0, "NOT_INITIALIZED"));
                return;
            }

            // The player turned push off, so the OS is not asked. Before SetEnabled the game may still ask.
            if (_enabled == false)
            {
                Raise(callback, PushResult.Failed(PushFailure.Disabled, 0, "DISABLED"));
                return;
            }

            Action<PushResult> answer = null;
            answer = result =>
            {
                if (!_unanswered.Remove(answer)) return;
                Raise(callback, result);
            };
            _unanswered.Add(answer);

            Call(_provider.RequestPermission, result =>
            {
                if (result.Success) _permissionRequested = true;
                answer(result);
            });
        }

        public void FlushPending()
        {
            while (!_closed && _enabled == true && _pending.Count > 0 && HasListeners())
                Raise(_messageReceived, _pending.Dequeue());
        }

        public void Close()
        {
            if (_closed) return;
            _closed = true;
            CancelRetry();
            _pending.Clear();
            _provider.TokenReceived -= OnTokenReceived;
            _provider.MessageReceived -= OnMessageReceived;
            _host.Resumed -= OnResumed;

            // Calls still waiting would never hear back from a closed session.
            foreach (Action<PushResult> answer in _unanswered.ToArray())
                answer(PushResult.Failed(PushFailure.ProviderError, 0, "PROVIDER_CHANGED"));
        }

        private void RequestSync()
        {
            if (_closed || !IsInitialized || !_enabled.HasValue) return;
            _syncRequested = true;
            CancelRetry();
            if (!_syncing) StartPass();
        }

        private void StartPass()
        {
            _syncing = true;
            _syncRequested = false;
            _passFailed = false;
            _triedThisPass.Clear();
            SetAutoRegistration(_enabled == true);
            Advance();
        }

        private void Advance()
        {
            if (_closed) return;
            if (_enabled == true) AdvanceEnabled();
            else AdvanceDisabled();
        }

        private void AdvanceEnabled()
        {
            if (!_permissionRequested)
            {
                Call(_provider.RequestPermission, result =>
                {
                    if (!result.Success)
                    {
                        Fail(result);
                        return;
                    }

                    _permissionRequested = true;
                    Advance();
                });
                return;
            }

            if (Token.Length == 0)
            {
                CallToken(_provider.GetToken, (result, token) =>
                {
                    if (!result.Success)
                    {
                        Fail(result);
                        return;
                    }

                    if (_enabled == true)
                    {
                        if (string.IsNullOrEmpty(token))
                        {
                            Fail(PushResult.Failed(PushFailure.TokenUnavailable, 0, "EMPTY_TOKEN"));
                            return;
                        }

                        if (Token.Length == 0) SetToken(token);
                    }

                    Advance();
                });
                return;
            }

            string stale = FindFirst(_savedTopics, topic => !_wantedTopics.Contains(topic));
            if (stale != null)
            {
                Call(done => _provider.Unsubscribe(stale, done), result =>
                {
                    if (!result.Success)
                    {
                        Fail(result);
                        return;
                    }

                    ForgetTopic(stale);
                    Advance();
                });
                return;
            }

            string missing = FindFirst(_wantedTopics, topic => !_confirmedTopics.Contains(topic) && !_triedThisPass.Contains(topic));
            if (missing != null)
            {
                // Saved before sending: even a failed or interrupted request may have reached the SDK.
                if (!_savedTopics.Contains(missing))
                {
                    _savedTopics.Add(missing);
                    SaveTopics();
                }

                string token = Token;
                Call(done => _provider.Subscribe(missing, done), result =>
                {
                    if (result.Failure == PushFailure.InvalidTopic)
                    {
                        _triedThisPass.Add(missing);
                        _wantedTopics.Remove(missing);
                        ForgetTopic(missing);
                        _host.LogWarning("Topic dropped: " + missing + ". " + result);
                        Raise(_synchronized, result);
                        Advance();
                        return;
                    }

                    if (!result.Success)
                    {
                        Fail(result);
                        return;
                    }

                    if (token == Token) _confirmedTopics.Add(missing);
                    Advance();
                });
                return;
            }

            Finish();
        }

        private void AdvanceDisabled()
        {
            string topic = FindFirst(_savedTopics, saved => !_triedThisPass.Contains(saved));
            if (topic != null)
            {
                _triedThisPass.Add(topic);
                Call(done => _provider.Unsubscribe(topic, done), result =>
                {
                    // Keep going: deleting the token below also stops topic messages.
                    if (result.Success) ForgetTopic(topic);
                    else RecordFailure(result);
                    Advance();
                });
                return;
            }

            if (!_tokenDeleted)
            {
                Call(_provider.DeleteToken, result =>
                {
                    if (!result.Success)
                    {
                        Fail(result);
                        return;
                    }

                    // An answer that arrives after push was turned on again must not hide the next token.
                    if (_enabled != true) _tokenDeleted = true;
                    Advance();
                });
                return;
            }

            Finish();
        }

        private void Finish()
        {
            if (_passFailed)
            {
                Fail(_passFailure);
                return;
            }

            _syncing = false;
            if (_syncRequested)
            {
                StartPass();
                return;
            }

            Raise(_synchronized, PushResult.Succeeded);
        }

        private void Fail(PushResult result)
        {
            _syncing = false;
            if (_closed) return;

            _host.LogWarning("Sync failed. Retry in " + RetryDelaySeconds + "s. " + result);
            ScheduleRetry();
            Raise(_synchronized, result);
            if (_syncRequested && !_syncing) RequestSync();
        }

        private void RecordFailure(PushResult result)
        {
            if (_passFailed) return;
            _passFailed = true;
            _passFailure = result;
        }

        private void ScheduleRetry()
        {
            CancelRetry();
            _cancelRetry = _host.Schedule(RetryDelaySeconds, () =>
            {
                _cancelRetry = null;
                Retry();
            });
        }

        private void CancelRetry()
        {
            Action cancel = _cancelRetry;
            _cancelRetry = null;
            cancel?.Invoke();
        }

        private void Retry()
        {
            if (_closed) return;
            if (!IsInitialized)
            {
                if (_initializeRequested) Initialize();
                return;
            }

            RequestSync();
        }

        private void OnResumed()
        {
            if (_closed || _initializing) return;
            Retry();
        }

        private void OnTokenReceived(string token)
        {
            _host.Post(() =>
            {
                if (_closed || !IsInitialized || _enabled != true) return;
                if (!string.IsNullOrEmpty(token)) SetToken(token);
                RequestSync();
            });
        }

        private void OnMessageReceived(PushMessage message)
        {
            _host.Post(() =>
            {
                if (_closed || message == null) return;
                if (_enabled == false) return;

                if (_enabled == true && HasListeners())
                {
                    Raise(_messageReceived, message);
                    return;
                }

                if (_pending.Count == MaxPendingMessages) _pending.Dequeue();
                _pending.Enqueue(message);
            });
        }

        private void SetToken(string token)
        {
            if (Token == token) return;
            Token = token;
            if (token.Length > 0) _tokenDeleted = false;
            _confirmedTopics.Clear();
            Raise(_tokenChanged, token);
        }

        private void SetAutoRegistration(bool enabled)
        {
            try
            {
                _provider.SetAutoRegistration(enabled);
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }

        private void ForgetTopic(string topic)
        {
            _confirmedTopics.Remove(topic);
            if (_savedTopics.Remove(topic)) SaveTopics();
        }

        private void LoadSavedTopics()
        {
            _savedTopics.Clear();
            string saved;
            try
            {
                saved = _host.Load(_topicsKey);
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                return;
            }

            if (string.IsNullOrEmpty(saved)) return;
            foreach (string topic in saved.Split('\n'))
            {
                if (topic.Length > 0 && !_savedTopics.Contains(topic)) _savedTopics.Add(topic);
            }
        }

        private void SaveTopics()
        {
            try
            {
                _host.Save(_topicsKey, string.Join("\n", _savedTopics));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }

        private string ReadScopeId()
        {
            try
            {
                string scope = _provider.ScopeId;
                return string.IsNullOrEmpty(scope) ? "default" : scope;
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                return "default";
            }
        }

        private bool SameTopics(IReadOnlyList<string> topics)
        {
            if (topics.Count != _wantedTopics.Count) return false;
            for (int i = 0; i < topics.Count; i++)
            {
                if (!string.Equals(topics[i], _wantedTopics[i], StringComparison.Ordinal)) return false;
            }
            return true;
        }

        private bool HasListeners()
        {
            try
            {
                return _hasMessageListeners != null && _hasMessageListeners();
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                return false;
            }
        }

        private static string FindFirst(List<string> topics, Predicate<string> match)
        {
            foreach (string topic in topics)
            {
                if (match(topic)) return topic;
            }
            return null;
        }

        /// <summary>Calls the provider once. The answer runs on the main thread, once, and never after <see cref="Close"/>.</summary>
        private void Call(Action<Action<PushResult>> start, Action<PushResult> done)
        {
            bool answered = false;
            void Answer(PushResult result)
            {
                if (answered || _closed) return;
                answered = true;
                done(result);
            }

            try
            {
                start(result => _host.Post(() => Answer(result)));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                Answer(PushResult.Failed(PushFailure.ProviderError, 0, exception.GetType().Name + ": " + exception.Message));
            }
        }

        private void CallToken(Action<Action<PushResult, string>> start, Action<PushResult, string> done)
        {
            bool answered = false;
            void Answer(PushResult result, string token)
            {
                if (answered || _closed) return;
                answered = true;
                done(result, token);
            }

            try
            {
                start((result, token) => _host.Post(() => Answer(result, token)));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                Answer(PushResult.Failed(PushFailure.ProviderError, 0, exception.GetType().Name + ": " + exception.Message), null);
            }
        }

        private void Raise<T>(Action<T> handler, T value)
        {
            if (handler == null) return;
            try
            {
                handler(value);
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }
    }
}
