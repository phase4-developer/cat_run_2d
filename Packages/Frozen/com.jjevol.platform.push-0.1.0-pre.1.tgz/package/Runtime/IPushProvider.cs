using System;

namespace PlatformLibrary.Push
{
    /// <summary>
    /// Connects one push SDK to <see cref="PushManager"/>. Games do not call this.
    /// <para>
    /// The manager calls every member on the Unity main thread, one SDK call at a time, and handles the order of
    /// permission, token and topic calls, retries, the saved topic list and the disabled state. A provider only
    /// talks to its SDK and turns SDK errors into <see cref="PushFailure"/>.
    /// </para>
    /// <para>Callbacks and events may be used from any thread. Each callback must be called once.</para>
    /// </summary>
    public interface IPushProvider
    {
        /// <summary>Separates saved data between SDK projects, for example a Firebase App ID. Read after initialization.</summary>
        string ScopeId { get; }

        /// <summary>The SDK issued or refreshed a token.</summary>
        event Action<string> TokenReceived;

        event Action<PushMessage> MessageReceived;

        /// <summary>Connects to the SDK. The project has already started the SDK itself, for example Firebase.</summary>
        void Initialize(Action<PushResult> completed);

        /// <summary>Lets the SDK create a token by itself at the next start.</summary>
        void SetAutoRegistration(bool enabled);

        void RequestPermission(Action<PushResult> completed);

        void GetToken(Action<PushResult, string> completed);

        void DeleteToken(Action<PushResult> completed);

        void Subscribe(string topic, Action<PushResult> completed);

        void Unsubscribe(string topic, Action<PushResult> completed);
    }
}
