using System;

namespace PlatformLibrary.Push
{
    /// <summary>
    /// Result of a push call. Games branch on <see cref="Failure"/>. <see cref="ProviderCode"/> and
    /// <see cref="Detail"/> are the SDK's own values, kept for logs only.
    /// </summary>
    public readonly struct PushResult
    {
        private readonly string _detail;

        private PushResult(PushFailure failure, int providerCode, string detail)
        {
            Failure = failure;
            ProviderCode = providerCode;
            _detail = detail;
        }

        public static PushResult Succeeded => default;

        public static PushResult Failed(PushFailure failure, int providerCode = 0, string detail = null)
        {
            if (failure == PushFailure.None) throw new ArgumentException("A failure needs a reason.", nameof(failure));
            return new PushResult(failure, providerCode, detail);
        }

        public PushFailure Failure { get; }
        public bool Success => Failure == PushFailure.None;

        /// <summary>The SDK's code. Logs and investigation only.</summary>
        public int ProviderCode { get; }

        /// <summary>A description for logs. Never null.</summary>
        public string Detail => _detail ?? string.Empty;

        public override string ToString() => Success ? "Success" : $"{Failure} (code {ProviderCode}) {Detail}";
    }
}
