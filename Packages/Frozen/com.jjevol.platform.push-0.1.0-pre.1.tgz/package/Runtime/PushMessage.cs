using System.Collections.Generic;

namespace PlatformLibrary.Push
{
    /// <summary>A received push message. A data-only message has an empty title and body.</summary>
    public sealed class PushMessage
    {
        private static readonly IReadOnlyDictionary<string, string> Empty = new Dictionary<string, string>();

        public PushMessage(string messageId, string title, string body, IEnumerable<KeyValuePair<string, string>> data, bool opened)
        {
            MessageId = messageId ?? string.Empty;
            Title = title ?? string.Empty;
            Body = body ?? string.Empty;
            Opened = opened;

            if (data == null)
            {
                Data = Empty;
                return;
            }

            var copy = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> pair in data)
            {
                if (pair.Key != null) copy[pair.Key] = pair.Value ?? string.Empty;
            }
            Data = copy;
        }

        public string MessageId { get; }
        public string Title { get; }
        public string Body { get; }

        /// <summary>Key and value pairs the sender attached. A copy, never null.</summary>
        public IReadOnlyDictionary<string, string> Data { get; }

        /// <summary>True when the player tapped the notification and that opened the app.</summary>
        public bool Opened { get; }
    }
}
