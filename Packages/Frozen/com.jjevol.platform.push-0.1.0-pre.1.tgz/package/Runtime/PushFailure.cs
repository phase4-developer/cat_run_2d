namespace PlatformLibrary.Push
{
    /// <summary>
    /// Why a push call failed. Games branch on this, never on an SDK code.
    /// Shared names and order follow <c>NetworkFailure</c> in com.jjevol.platform.network.
    /// </summary>
    public enum PushFailure
    {
        None,
        Unsupported,
        NotInitialized,
        Disabled,
        NoConnection,
        Timeout,
        InvalidTopic,
        TokenUnavailable,
        ProviderError
    }
}
