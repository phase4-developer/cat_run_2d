using System;
using System.Collections.Generic;
using UnityEngine;

namespace PlatformLibrary.Push
{
    /// <summary>
    /// The only push API a game uses. Call it from the Unity main thread. Every callback and event runs on the main thread.
    /// With no provider set, nothing is sent and <see cref="RequestPermission"/> answers <see cref="PushFailure.Unsupported"/>.
    /// <para>
    /// <see cref="SetEnabled"/> and <see cref="SetTopics"/> record the wanted state. The manager then asks for permission
    /// once, gets the token and changes topic subscriptions one call at a time, retrying failures after
    /// 30 seconds and when the app comes back. Nothing is sent before the first <see cref="SetEnabled"/>.
    /// </para>
    /// </summary>
    public static class PushManager
    {
        private static PushSession _session;
        private static bool _initializedWithoutProvider;
        private static bool? _enabled;
        private static string[] _topics = Array.Empty<string>();
        private static Action<PushMessage> _messageReceived;

        /// <summary>The token changed or was removed. Send it to the game's server here if the game needs that.</summary>
        public static event Action<string> TokenChanged;

        /// <summary>
        /// A received message. Not raised while push is off. Messages that arrive before the first listener or before
        /// <see cref="SetEnabled"/>, such as the one that opened the app, wait and go to the first listener, up to 16.
        /// </summary>
        public static event Action<PushMessage> MessageReceived
        {
            add
            {
                _messageReceived += value;
                _session?.FlushPending();
            }
            remove => _messageReceived -= value;
        }

        /// <summary>A sync pass ended. For logs and tests. A failed pass is retried by the manager.</summary>
        public static event Action<PushResult> Synchronized;

        public static bool IsInitialized => _session != null ? _session.IsInitialized : _initializedWithoutProvider;

        /// <summary>True when a provider is set.</summary>
        public static bool IsSupported => _session != null;

        public static bool IsEnabled => _enabled == true;

        /// <summary>The current token. Empty while push is off or before the SDK issued one.</summary>
        public static string Token => _session != null ? _session.Token : string.Empty;

        /// <summary>
        /// Sets the provider, or removes it with null. Call <see cref="Initialize"/> after it.
        /// The enabled state and topics carry over to the new provider.
        /// </summary>
        public static void SetProvider(IPushProvider provider)
        {
            SetProvider(provider, provider == null ? null : UnityPushHost.Instance);
        }

        public static void Initialize()
        {
            if (_session != null) _session.Initialize();
            else _initializedWithoutProvider = true;
        }

        /// <summary>
        /// Turns push on or off, usually from the player's option. On asks for permission the first time, gets the token
        /// and subscribes the topics. Off unsubscribes the topics, deletes the token and drops incoming messages.
        /// </summary>
        public static void SetEnabled(bool enabled)
        {
            _enabled = enabled;
            _session?.SetEnabled(enabled);
        }

        /// <summary>The topics wanted. Only the difference is subscribed or unsubscribed. Blank names are ignored.</summary>
        public static void SetTopics(params string[] topics)
        {
            _topics = Normalize(topics);
            _session?.SetTopics(_topics);
        }

        /// <summary>Asks for permission now, for a game that wants to choose the moment.</summary>
        public static void RequestPermission(Action<PushResult> callback)
        {
            if (_session != null) _session.RequestPermission(callback);
            else callback?.Invoke(PushResult.Failed(PushFailure.Unsupported, 0, "NO_PUSH_PROVIDER"));
        }

        internal static PushSession Session => _session;

        internal static void SetProvider(IPushProvider provider, IPushHost host)
        {
            if (ReferenceEquals(_session?.Provider, provider)) return;

            PushSession previous = _session;
            string previousToken = previous?.Token ?? string.Empty;
            previous?.Close();

            _session = provider == null
                ? null
                : new PushSession(provider, host, RaiseTokenChanged, RaiseMessageReceived, HasMessageListeners, RaiseSynchronized);
            _initializedWithoutProvider = false;

            if (_session != null)
            {
                _session.SetTopics(_topics);
                if (_enabled.HasValue) _session.SetEnabled(_enabled.Value);
            }

            if (previousToken.Length > 0) RaiseTokenChanged(Token);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        internal static void ResetState()
        {
            _session?.Close();
            _session = null;
            _initializedWithoutProvider = false;
            _enabled = null;
            _topics = Array.Empty<string>();
            _messageReceived = null;
            TokenChanged = null;
            Synchronized = null;
        }

        private static string[] Normalize(string[] topics)
        {
            if (topics == null || topics.Length == 0) return Array.Empty<string>();
            var result = new List<string>(topics.Length);
            foreach (string topic in topics)
            {
                string trimmed = topic?.Trim();
                if (string.IsNullOrEmpty(trimmed) || result.Contains(trimmed)) continue;
                result.Add(trimmed);
            }
            return result.ToArray();
        }

        private static bool HasMessageListeners() => _messageReceived != null;

        private static void RaiseTokenChanged(string token) => TokenChanged?.Invoke(token);

        private static void RaiseMessageReceived(PushMessage message) => _messageReceived?.Invoke(message);

        private static void RaiseSynchronized(PushResult result) => Synchronized?.Invoke(result);
    }
}
