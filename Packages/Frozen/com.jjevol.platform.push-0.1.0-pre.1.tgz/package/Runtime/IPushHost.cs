using System;

namespace PlatformLibrary.Push
{
    /// <summary>What <see cref="PushSession"/> needs from Unity. Tests replace it to control time, threads and storage.</summary>
    internal interface IPushHost
    {
        /// <summary>The app came back to the foreground.</summary>
        event Action Resumed;

        /// <summary>Runs on the main thread, immediately when already on it.</summary>
        void Post(Action action);

        /// <summary>Runs on the main thread after real time passes. The returned action cancels it.</summary>
        Action Schedule(float seconds, Action action);

        string Load(string key);
        void Save(string key, string value);

        void LogWarning(string message);
        void LogException(Exception exception);
    }
}
