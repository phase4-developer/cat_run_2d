using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Push.Tests.Editor")]
[assembly: InternalsVisibleTo("PlatformLibrary.Push.Tests.Runtime")]
