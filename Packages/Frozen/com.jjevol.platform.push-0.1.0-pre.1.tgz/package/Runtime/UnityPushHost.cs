using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Threading;
using UnityEngine;

namespace PlatformLibrary.Push
{
    [AddComponentMenu("")]
    internal sealed class UnityPushHost : MonoBehaviour, IPushHost
    {
        private static UnityPushHost _instance;

        private readonly ConcurrentQueue<Action> _queue = new ConcurrentQueue<Action>();
        private int _mainThreadId;

        public event Action Resumed;

        public static UnityPushHost Instance
        {
            get
            {
                if (_instance != null) return _instance;
                var host = new GameObject(nameof(PushManager));
                if (Application.isPlaying) DontDestroyOnLoad(host);
                _instance = host.AddComponent<UnityPushHost>();
                return _instance;
            }
        }

        private void Awake()
        {
            _mainThreadId = Thread.CurrentThread.ManagedThreadId;
        }

        private void Update()
        {
            while (_queue.TryDequeue(out Action action))
                action();
        }

        private void OnApplicationPause(bool paused)
        {
            if (!paused) Resumed?.Invoke();
        }

        public void Post(Action action)
        {
            if (Thread.CurrentThread.ManagedThreadId == _mainThreadId) action();
            else _queue.Enqueue(action);
        }

        public Action Schedule(float seconds, Action action)
        {
            Coroutine coroutine = StartCoroutine(Run(seconds, action));
            return () =>
            {
                if (this != null) StopCoroutine(coroutine);
            };
        }

        public string Load(string key) => PlayerPrefs.GetString(key, string.Empty);

        public void Save(string key, string value)
        {
            if (string.IsNullOrEmpty(value)) PlayerPrefs.DeleteKey(key);
            else PlayerPrefs.SetString(key, value);
            PlayerPrefs.Save();
        }

        public void LogWarning(string message) => Debug.LogWarning("[PushManager] " + message);

        public void LogException(Exception exception) => Debug.LogException(exception);

        private static IEnumerator Run(float seconds, Action action)
        {
            yield return new WaitForSecondsRealtime(seconds);
            action();
        }
    }
}
