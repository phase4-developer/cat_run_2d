using System.Collections;
using System.Threading;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Push.Tests
{
    public sealed class UnityPushHostTests
    {
        private const string Key = "PlatformLibrary.Push.Tests.Key";

        [TearDown]
        public void TearDown()
        {
            PushManager.ResetState();
            PlayerPrefs.DeleteKey(Key);
        }

        [UnityTest]
        public IEnumerator PostFromAnotherThreadRunsOnTheMainThread()
        {
            UnityPushHost host = UnityPushHost.Instance;
            int mainThread = Thread.CurrentThread.ManagedThreadId;
            int ranOn = -1;

            var worker = new Thread(() => host.Post(() => ranOn = Thread.CurrentThread.ManagedThreadId));
            worker.Start();
            worker.Join();

            for (int frame = 0; frame < 10 && ranOn == -1; frame++)
                yield return null;

            Assert.AreEqual(mainThread, ranOn);
        }

        [UnityTest]
        public IEnumerator ScheduledActionRunsAfterTheDelay()
        {
            bool ran = false;
            UnityPushHost.Instance.Schedule(0.05f, () => ran = true);
            Assert.IsFalse(ran);

            yield return new WaitForSecondsRealtime(0.2f);

            Assert.IsTrue(ran);
        }

        [UnityTest]
        public IEnumerator CancelledScheduleDoesNotRun()
        {
            bool ran = false;
            System.Action cancel = UnityPushHost.Instance.Schedule(0.05f, () => ran = true);
            cancel();

            yield return new WaitForSecondsRealtime(0.2f);

            Assert.IsFalse(ran);
        }

        [Test]
        public void SaveAndLoadUsePlayerPrefs()
        {
            UnityPushHost host = UnityPushHost.Instance;
            host.Save(Key, "a\nb");
            Assert.AreEqual("a\nb", PlayerPrefs.GetString(Key));
            Assert.AreEqual("a\nb", host.Load(Key));

            host.Save(Key, string.Empty);
            Assert.IsFalse(PlayerPrefs.HasKey(Key));
            Assert.AreEqual(string.Empty, host.Load(Key));
        }

        [Test]
        public void SettingAProviderStartsTheManagerWithAFakeProvider()
        {
            var provider = new FakePushProvider();
            PushManager.SetProvider(provider);
            PushManager.SetTopics("a");
            PushManager.Initialize();
            PushManager.SetEnabled(true);

            Assert.IsTrue(PushManager.IsInitialized);
            Assert.AreEqual("token-1", PushManager.Token);
            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", "GetToken", "Subscribe:a" }, provider.Calls);
            PlayerPrefs.DeleteKey(PushSession.TopicsKeyPrefix + provider.ScopeIdValue);
        }
    }
}
