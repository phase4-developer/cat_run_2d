using System;
using System.Collections.Generic;

namespace PlatformLibrary.Push.Tests
{
    /// <summary>
    /// A provider that records each call. With <see cref="AutoAnswer"/> it answers at once with the configured results;
    /// without it, answers wait until <see cref="AnswerNext"/>.
    /// </summary>
    public sealed class FakePushProvider : IPushProvider
    {
        private readonly Queue<Action> _waiting = new Queue<Action>();

        public readonly List<string> Calls = new List<string>();
        public readonly Dictionary<string, PushResult> SubscribeResults = new Dictionary<string, PushResult>();
        public readonly Dictionary<string, PushResult> UnsubscribeResults = new Dictionary<string, PushResult>();

        public bool AutoAnswer = true;
        public bool AnswerTwice;
        public string ThrowOn;
        public string ScopeIdValue = "scope";
        public string NextToken = "token-1";
        public PushResult InitializeResult;
        public PushResult PermissionResult;
        public PushResult TokenResult;
        public PushResult DeleteResult;

        public bool? AutoRegistration { get; private set; }
        public int WaitingCount => _waiting.Count;

        public string ScopeId => ScopeIdValue;

        public event Action<string> TokenReceived;
        public event Action<PushMessage> MessageReceived;

        public int Count(string call) => Calls.FindAll(c => c == call).Count;

        public void AnswerNext() => _waiting.Dequeue()();

        public void RaiseToken(string token) => TokenReceived?.Invoke(token);

        public void RaiseMessage(PushMessage message) => MessageReceived?.Invoke(message);

        public void Initialize(Action<PushResult> completed) => Answer("Initialize", () => completed(InitializeResult));

        public void SetAutoRegistration(bool enabled) => AutoRegistration = enabled;

        public void RequestPermission(Action<PushResult> completed) => Answer("RequestPermission", () => completed(PermissionResult));

        public void GetToken(Action<PushResult, string> completed)
        {
            Answer("GetToken", () => completed(TokenResult, TokenResult.Success ? NextToken : null));
        }

        public void DeleteToken(Action<PushResult> completed) => Answer("DeleteToken", () => completed(DeleteResult));

        public void Subscribe(string topic, Action<PushResult> completed)
        {
            Answer("Subscribe:" + topic, () => completed(SubscribeResults.TryGetValue(topic, out PushResult result) ? result : PushResult.Succeeded));
        }

        public void Unsubscribe(string topic, Action<PushResult> completed)
        {
            Answer("Unsubscribe:" + topic, () => completed(UnsubscribeResults.TryGetValue(topic, out PushResult result) ? result : PushResult.Succeeded));
        }

        private void Answer(string call, Action answer)
        {
            Calls.Add(call);
            if (ThrowOn == call) throw new InvalidOperationException("fake failure in " + call);

            if (!AutoAnswer)
            {
                _waiting.Enqueue(answer);
                return;
            }

            answer();
            if (AnswerTwice) answer();
        }
    }
}
