using System;
using NUnit.Framework;

namespace PlatformLibrary.Push.Tests
{
    public sealed class PushResultTests
    {
        [Test]
        public void SucceededIsSuccess()
        {
            Assert.IsTrue(PushResult.Succeeded.Success);
            Assert.AreEqual(PushFailure.None, PushResult.Succeeded.Failure);
        }

        [Test]
        public void FailedNeedsAReason()
        {
            Assert.Throws<ArgumentException>(() => PushResult.Failed(PushFailure.None));
        }

        [Test]
        public void FailedKeepsTheSdkCodeAndDetail()
        {
            PushResult result = PushResult.Failed(PushFailure.NoConnection, 12, "offline");

            Assert.IsFalse(result.Success);
            Assert.AreEqual(12, result.ProviderCode);
            Assert.AreEqual("offline", result.Detail);
        }

        [Test]
        public void DetailIsNeverNull()
        {
            Assert.AreEqual(string.Empty, PushResult.Succeeded.Detail);
            Assert.AreEqual(string.Empty, PushResult.Failed(PushFailure.ProviderError).Detail);
        }
    }
}
