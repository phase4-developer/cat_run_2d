using NUnit.Framework;

namespace PlatformLibrary.Push.Tests
{
    public sealed class PushEnableTests : PushTestBase
    {
        [Test]
        public void NothingIsSentBeforeSetEnabled()
        {
            UseProvider();
            PushManager.SetTopics("a");
            PushManager.Initialize();

            CollectionAssert.AreEqual(new[] { "Initialize" }, Provider.Calls);
            Assert.IsNull(Provider.AutoRegistration);
            CollectionAssert.IsEmpty(Syncs);
        }

        [Test]
        public void EnablingAsksPermissionGetsTheTokenAndSubscribesInOrder()
        {
            StartEnabled("a", "b");

            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", "GetToken", "Subscribe:a", "Subscribe:b" }, Provider.Calls);
            Assert.AreEqual("token-1", PushManager.Token);
            CollectionAssert.AreEqual(new[] { "token-1" }, Tokens);
            Assert.IsTrue(LastSync.Success);
            Assert.AreEqual(true, Provider.AutoRegistration);
        }

        [Test]
        public void PermissionIsAskedOnlyOnce()
        {
            StartEnabled("a");
            PushManager.SetEnabled(false);
            PushManager.SetEnabled(true);

            Assert.AreEqual(1, Provider.Count("RequestPermission"));
        }

        [Test]
        public void DisablingUnsubscribesThenDeletesTheToken()
        {
            StartEnabled("a");
            Provider.Calls.Clear();

            PushManager.SetEnabled(false);

            CollectionAssert.AreEqual(new[] { "Unsubscribe:a", "DeleteToken" }, Provider.Calls);
            Assert.AreEqual(string.Empty, PushManager.Token);
            CollectionAssert.AreEqual(new[] { "token-1", string.Empty }, Tokens);
            Assert.AreEqual(false, Provider.AutoRegistration);
            Assert.AreEqual(string.Empty, Host.Store[TopicsKey]);
            Assert.IsTrue(LastSync.Success);
        }

        [Test]
        public void StartingDisabledDeletesTheTokenOnce()
        {
            UseProvider();
            PushManager.Initialize();
            PushManager.SetEnabled(false);
            Host.Resume();

            CollectionAssert.AreEqual(new[] { "Initialize", "DeleteToken" }, Provider.Calls);
        }

        [Test]
        public void UnsubscribeFailureStillDeletesTheTokenAndRetries()
        {
            StartEnabled("a");
            Provider.UnsubscribeResults["a"] = PushResult.Failed(PushFailure.NoConnection);
            Provider.Calls.Clear();

            PushManager.SetEnabled(false);

            CollectionAssert.AreEqual(new[] { "Unsubscribe:a", "DeleteToken" }, Provider.Calls);
            Assert.AreEqual(PushFailure.NoConnection, LastSync.Failure);
            Assert.AreEqual(1, Host.ActiveScheduleCount);

            Provider.UnsubscribeResults.Clear();
            Host.RunScheduled();

            CollectionAssert.AreEqual(new[] { "Unsubscribe:a", "DeleteToken", "Unsubscribe:a" }, Provider.Calls);
            Assert.AreEqual(string.Empty, Host.Store[TopicsKey]);
            Assert.IsTrue(LastSync.Success);
        }

        [Test]
        public void EnablingAgainGetsANewTokenAndSubscribesAgain()
        {
            StartEnabled("a");
            PushManager.SetEnabled(false);
            Provider.NextToken = "token-2";
            Provider.Calls.Clear();

            PushManager.SetEnabled(true);

            CollectionAssert.AreEqual(new[] { "GetToken", "Subscribe:a" }, Provider.Calls);
            Assert.AreEqual("token-2", PushManager.Token);
        }

        [Test]
        public void ExplicitPermissionRequestCountsAsTheFirstAsk()
        {
            UseProvider();
            PushManager.Initialize();
            PushResult? answer = null;
            PushManager.RequestPermission(result => answer = result);
            PushManager.SetEnabled(true);

            Assert.IsTrue(answer.Value.Success);
            Assert.AreEqual(1, Provider.Count("RequestPermission"));
        }

        [Test]
        public void ExplicitPermissionRequestBeforeInitializeAnswersNotInitialized()
        {
            UseProvider();
            PushResult? answer = null;
            PushManager.RequestPermission(result => answer = result);

            Assert.AreEqual(PushFailure.NotInitialized, answer.Value.Failure);
            CollectionAssert.IsEmpty(Provider.Calls);
        }

        [Test]
        public void PermissionRequestWhileOffAnswersDisabled()
        {
            UseProvider();
            PushManager.Initialize();
            PushManager.SetEnabled(false);
            Provider.Calls.Clear();
            PushResult? answer = null;

            PushManager.RequestPermission(result => answer = result);

            Assert.AreEqual(PushFailure.Disabled, answer.Value.Failure);
            CollectionAssert.IsEmpty(Provider.Calls);
        }

        [Test]
        public void PermissionRequestWaitingWhenTheProviderChangesAnswersProviderError()
        {
            UseProvider();
            PushManager.Initialize();
            Provider.AutoAnswer = false;
            var answers = new System.Collections.Generic.List<PushResult>();
            PushManager.RequestPermission(answers.Add);

            PushManager.SetProvider(new FakePushProvider(), Host);
            Provider.AnswerNext();

            Assert.AreEqual(1, answers.Count);
            Assert.AreEqual(PushFailure.ProviderError, answers[0].Failure);
            Assert.AreEqual("PROVIDER_CHANGED", answers[0].Detail);
        }
    }
}
