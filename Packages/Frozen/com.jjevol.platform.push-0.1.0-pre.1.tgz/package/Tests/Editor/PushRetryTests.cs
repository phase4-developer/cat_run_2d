using NUnit.Framework;

namespace PlatformLibrary.Push.Tests
{
    public sealed class PushRetryTests : PushTestBase
    {
        [Test]
        public void FailedSyncRetriesAfterThirtySeconds()
        {
            Provider.TokenResult = PushResult.Failed(PushFailure.NoConnection, 7, "offline");
            StartEnabled("a");

            Assert.AreEqual(PushFailure.NoConnection, LastSync.Failure);
            Assert.AreEqual(7, LastSync.ProviderCode);
            Assert.AreEqual(1, Host.ActiveScheduleCount);
            Assert.AreEqual(PushSession.RetryDelaySeconds, Host.ScheduledItems[0].Seconds);

            Provider.TokenResult = PushResult.Succeeded;
            Host.RunScheduled();

            Assert.AreEqual("Subscribe:a", Provider.Calls[Provider.Calls.Count - 1]);
            Assert.IsTrue(LastSync.Success);
        }

        [Test]
        public void NewSettingDuringTheWaitRunsAtOnce()
        {
            Provider.TokenResult = PushResult.Failed(PushFailure.NoConnection);
            StartEnabled("a");
            Provider.TokenResult = PushResult.Succeeded;

            PushManager.SetTopics("b");

            Assert.AreEqual(2, Provider.Count("GetToken"));
            Assert.AreEqual("Subscribe:b", Provider.Calls[Provider.Calls.Count - 1]);
            Assert.AreEqual(0, Host.ActiveScheduleCount);
        }

        [Test]
        public void ResumingTheAppSynchronizesAgain()
        {
            Provider.TokenResult = PushResult.Failed(PushFailure.NoConnection);
            StartEnabled("a");
            Provider.TokenResult = PushResult.Succeeded;

            Host.Resume();

            Assert.AreEqual("Subscribe:a", Provider.Calls[Provider.Calls.Count - 1]);
            Assert.AreEqual(0, Host.ActiveScheduleCount);
        }

        [Test]
        public void FailedInitializeIsRetried()
        {
            Provider.InitializeResult = PushResult.Failed(PushFailure.ProviderError);
            StartEnabled("a");

            CollectionAssert.AreEqual(new[] { "Initialize" }, Provider.Calls);
            Assert.IsFalse(PushManager.IsInitialized);
            Assert.AreEqual(PushFailure.ProviderError, LastSync.Failure);

            Provider.InitializeResult = PushResult.Succeeded;
            Host.RunScheduled();

            CollectionAssert.AreEqual(new[] { "Initialize", "Initialize", "RequestPermission", "GetToken", "Subscribe:a" }, Provider.Calls);
            Assert.IsTrue(PushManager.IsInitialized);
        }

        [Test]
        public void NewerSettingWinsOverALateAnswer()
        {
            Provider.AutoAnswer = false;
            UseProvider();
            PushManager.Initialize();
            Provider.AnswerNext();
            PushManager.SetEnabled(true);
            Provider.AnswerNext();

            PushManager.SetEnabled(false);
            Provider.AnswerNext();
            Provider.AnswerNext();

            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", "GetToken", "DeleteToken" }, Provider.Calls);
            Assert.AreEqual(string.Empty, PushManager.Token);
            CollectionAssert.DoesNotContain(Tokens, "token-1");
        }

        [Test]
        public void ProviderExceptionBecomesProviderError()
        {
            Provider.ThrowOn = "GetToken";
            StartEnabled("a");

            Assert.AreEqual(PushFailure.ProviderError, LastSync.Failure);
            Assert.AreEqual(1, Host.Exceptions.Count);
            Assert.AreEqual(1, Host.ActiveScheduleCount);
        }

        [Test]
        public void SecondAnswerToOneCallIsIgnored()
        {
            Provider.AnswerTwice = true;
            StartEnabled("a");

            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", "GetToken", "Subscribe:a" }, Provider.Calls);
        }

        [Test]
        public void AnswerAfterTheProviderChangedIsIgnored()
        {
            Provider.AutoAnswer = false;
            UseProvider();
            PushManager.Initialize();
            FakePushProvider first = Provider;

            PushManager.SetProvider(new FakePushProvider(), Host);
            first.AnswerNext();

            Assert.IsFalse(PushManager.IsInitialized);
            first.RaiseToken("late");
            Assert.AreEqual(string.Empty, PushManager.Token);
        }

        [Test]
        public void ThrowingListenerDoesNotStopTheSync()
        {
            PushManager.TokenChanged += token => throw new System.InvalidOperationException("listener");
            StartEnabled("a");

            Assert.AreEqual("Subscribe:a", Provider.Calls[Provider.Calls.Count - 1]);
            Assert.AreEqual(1, Host.Exceptions.Count);
        }

        [Test]
        public void EmptyTokenFailsWithTokenUnavailable()
        {
            Provider.NextToken = string.Empty;
            StartEnabled("a");

            Assert.AreEqual(PushFailure.TokenUnavailable, LastSync.Failure);
            Assert.AreEqual(0, Provider.Count("Subscribe:a"));
        }

        [Test]
        public void LateDeleteAnswerAfterTurningOnAgainStillDeletesTheNextToken()
        {
            StartEnabled();
            Provider.AutoAnswer = false;
            PushManager.SetEnabled(false);
            PushManager.SetEnabled(true);
            Provider.NextToken = "token-2";
            Provider.AnswerNext();
            Provider.AnswerNext();
            Assert.AreEqual("token-2", PushManager.Token);
            Provider.Calls.Clear();

            PushManager.SetEnabled(false);
            while (Provider.WaitingCount > 0) Provider.AnswerNext();

            CollectionAssert.AreEqual(new[] { "DeleteToken" }, Provider.Calls);
            Assert.AreEqual(string.Empty, PushManager.Token);
        }
    }
}
