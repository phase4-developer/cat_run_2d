using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Push.Tests
{
    public sealed class PushMessageTests : PushTestBase
    {
        [Test]
        public void MessageGoesToListenersWhileEnabled()
        {
            StartEnabled();
            Listen();

            Provider.RaiseMessage(Message("1"));

            Assert.AreEqual(1, Messages.Count);
            Assert.AreEqual("1", Messages[0].MessageId);
        }

        [Test]
        public void MessageWhileDisabledIsDropped()
        {
            StartEnabled();
            PushManager.SetEnabled(false);
            Listen();

            Provider.RaiseMessage(Message("1"));
            PushManager.SetEnabled(true);

            CollectionAssert.IsEmpty(Messages);
        }

        [Test]
        public void MessageBeforeTheFirstListenerGoesToItOnce()
        {
            StartEnabled();
            Provider.RaiseMessage(Message("1"));

            Listen();
            PushManager.MessageReceived += message => { };

            Assert.AreEqual(1, Messages.Count);
        }

        [Test]
        public void MessageBeforeSetEnabledWaitsUntilEnabled()
        {
            UseProvider();
            PushManager.Initialize();
            Listen();

            Provider.RaiseMessage(Message("1"));
            Assert.AreEqual(0, Messages.Count);

            PushManager.SetEnabled(true);
            Assert.AreEqual(1, Messages.Count);
        }

        [Test]
        public void WaitingMessagesKeepTheNewestSixteen()
        {
            StartEnabled();
            for (int i = 0; i < 20; i++)
                Provider.RaiseMessage(Message(i.ToString()));

            Listen();

            Assert.AreEqual(PushSession.MaxPendingMessages, Messages.Count);
            Assert.AreEqual("4", Messages[0].MessageId);
            Assert.AreEqual("19", Messages[15].MessageId);
        }

        [Test]
        public void MessageFromAnotherThreadWaitsForTheMainThread()
        {
            StartEnabled();
            Listen();
            Host.QueuePosts = true;

            Provider.RaiseMessage(Message("1"));
            Assert.AreEqual(0, Messages.Count);

            Host.RunPosted();
            Assert.AreEqual(1, Messages.Count);
        }

        [Test]
        public void MessageKeepsACopyOfItsData()
        {
            var data = new Dictionary<string, string> { ["screen"] = "shop", ["empty"] = null };
            var message = new PushMessage(null, null, null, data, true);
            data["screen"] = "changed";

            Assert.AreEqual("shop", message.Data["screen"]);
            Assert.AreEqual(string.Empty, message.Data["empty"]);
            Assert.AreEqual(string.Empty, message.MessageId);
            Assert.AreEqual(string.Empty, message.Title);
            Assert.AreEqual(string.Empty, message.Body);
            Assert.IsTrue(message.Opened);
        }

        [Test]
        public void MessageWithoutDataHasAnEmptyMap()
        {
            Assert.AreEqual(0, Message("1").Data.Count);
        }
    }
}
