using System;
using System.Collections.Generic;

namespace PlatformLibrary.Push.Tests
{
    /// <summary>Runs posts at once unless <see cref="QueuePosts"/>, keeps schedules until <see cref="RunScheduled"/>, stores in memory.</summary>
    internal sealed class FakePushHost : IPushHost
    {
        private readonly Queue<Action> _posted = new Queue<Action>();

        public readonly List<Scheduled> ScheduledItems = new List<Scheduled>();
        public readonly Dictionary<string, string> Store = new Dictionary<string, string>();
        public readonly List<string> Warnings = new List<string>();
        public readonly List<Exception> Exceptions = new List<Exception>();

        public bool QueuePosts;

        public event Action Resumed;

        public int ActiveScheduleCount => ScheduledItems.FindAll(item => item.IsActive).Count;

        public void Post(Action action)
        {
            if (QueuePosts) _posted.Enqueue(action);
            else action();
        }

        public void RunPosted()
        {
            while (_posted.Count > 0)
                _posted.Dequeue()();
        }

        public Action Schedule(float seconds, Action action)
        {
            var item = new Scheduled(seconds, action);
            ScheduledItems.Add(item);
            return () => item.Cancelled = true;
        }

        public void RunScheduled()
        {
            foreach (Scheduled item in ScheduledItems.ToArray())
            {
                if (!item.IsActive) continue;
                item.Ran = true;
                item.Action();
            }
        }

        public void Resume() => Resumed?.Invoke();

        public string Load(string key) => Store.TryGetValue(key, out string value) ? value : string.Empty;

        public void Save(string key, string value) => Store[key] = value ?? string.Empty;

        public void LogWarning(string message) => Warnings.Add(message);

        public void LogException(Exception exception) => Exceptions.Add(exception);

        internal sealed class Scheduled
        {
            public Scheduled(float seconds, Action action)
            {
                Seconds = seconds;
                Action = action;
            }

            public float Seconds { get; }
            public Action Action { get; }
            public bool Cancelled { get; set; }
            public bool Ran { get; set; }
            public bool IsActive => !Cancelled && !Ran;
        }
    }
}
