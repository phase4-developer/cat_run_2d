using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Push.Tests
{
    public abstract class PushTestBase
    {
        internal FakePushHost Host;
        protected FakePushProvider Provider;
        protected readonly List<PushResult> Syncs = new List<PushResult>();
        protected readonly List<string> Tokens = new List<string>();
        protected readonly List<PushMessage> Messages = new List<PushMessage>();

        protected string TopicsKey => PushSession.TopicsKeyPrefix + Provider.ScopeIdValue;
        protected PushResult LastSync => Syncs[Syncs.Count - 1];

        [SetUp]
        public void SetUpManager()
        {
            PushManager.ResetState();
            Provider = new FakePushProvider();
            Host = new FakePushHost();
            Syncs.Clear();
            Tokens.Clear();
            Messages.Clear();
            PushManager.Synchronized += Syncs.Add;
            PushManager.TokenChanged += Tokens.Add;
        }

        [TearDown]
        public void TearDownManager()
        {
            PushManager.ResetState();
        }

        protected void UseProvider()
        {
            PushManager.SetProvider(Provider, Host);
        }

        protected void StartEnabled(params string[] topics)
        {
            UseProvider();
            PushManager.SetTopics(topics);
            PushManager.Initialize();
            PushManager.SetEnabled(true);
        }

        protected void Listen()
        {
            PushManager.MessageReceived += Messages.Add;
        }

        protected static PushMessage Message(string id)
        {
            return new PushMessage(id, "title", "body", null, false);
        }
    }
}
