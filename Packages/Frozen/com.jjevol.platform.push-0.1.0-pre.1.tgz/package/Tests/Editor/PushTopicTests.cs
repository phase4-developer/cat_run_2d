using NUnit.Framework;

namespace PlatformLibrary.Push.Tests
{
    public sealed class PushTopicTests : PushTestBase
    {
        [Test]
        public void ChangingTopicsUnsubscribesTheOldOneFirst()
        {
            StartEnabled("ko");
            Provider.Calls.Clear();

            PushManager.SetTopics("en");

            CollectionAssert.AreEqual(new[] { "Unsubscribe:ko", "Subscribe:en" }, Provider.Calls);
            Assert.AreEqual("en", Host.Store[TopicsKey]);
        }

        [Test]
        public void SameTopicsSendNothing()
        {
            StartEnabled("a");
            Provider.Calls.Clear();

            PushManager.SetTopics("a");

            CollectionAssert.IsEmpty(Provider.Calls);
        }

        [Test]
        public void TopicIsSavedBeforeTheSubscribeAnswers()
        {
            Provider.AutoAnswer = false;
            UseProvider();
            PushManager.SetTopics("a");
            PushManager.Initialize();
            Provider.AnswerNext();
            PushManager.SetEnabled(true);
            Provider.AnswerNext();
            Provider.AnswerNext();

            Assert.AreEqual("Subscribe:a", Provider.Calls[Provider.Calls.Count - 1]);
            Assert.AreEqual(1, Provider.WaitingCount);
            Assert.AreEqual("a", Host.Store[TopicsKey]);
        }

        [Test]
        public void TopicSavedByAnEarlierRunIsUnsubscribed()
        {
            Host.Store[PushSession.TopicsKeyPrefix + "scope"] = "old";

            StartEnabled("new");

            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", "GetToken", "Unsubscribe:old", "Subscribe:new" }, Provider.Calls);
            Assert.AreEqual("new", Host.Store[TopicsKey]);
        }

        [Test]
        public void NewTokenSubscribesTheTopicsAgain()
        {
            StartEnabled("a");
            Provider.Calls.Clear();

            Provider.RaiseToken("token-2");

            Assert.AreEqual("token-2", PushManager.Token);
            CollectionAssert.AreEqual(new[] { "Subscribe:a" }, Provider.Calls);
            CollectionAssert.AreEqual(new[] { "token-1", "token-2" }, Tokens);
        }

        [Test]
        public void SameTokenAgainSendsNothing()
        {
            StartEnabled("a");
            Provider.Calls.Clear();

            Provider.RaiseToken("token-1");

            CollectionAssert.IsEmpty(Provider.Calls);
        }

        [Test]
        public void InvalidTopicIsDroppedWithoutRetry()
        {
            Provider.SubscribeResults["bad"] = PushResult.Failed(PushFailure.InvalidTopic);

            StartEnabled("bad", "good");

            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", "GetToken", "Subscribe:bad", "Subscribe:good" }, Provider.Calls);
            Assert.AreEqual("good", Host.Store[TopicsKey]);
            Assert.IsTrue(Syncs.Exists(result => result.Failure == PushFailure.InvalidTopic));
            Assert.IsTrue(LastSync.Success);
            Assert.AreEqual(0, Host.ActiveScheduleCount);
        }

        [Test]
        public void BlankAndRepeatedTopicsAreIgnored()
        {
            StartEnabled(" a ", "", null, "a");

            Assert.AreEqual(1, Provider.Count("Subscribe:a"));
            Assert.AreEqual(4, Provider.Calls.Count);
        }

        [Test]
        public void SavedTopicsAreKeptPerProviderScope()
        {
            Provider.ScopeIdValue = "app-1";
            StartEnabled("a");

            Assert.AreEqual("a", Host.Store["PlatformLibrary.Push.Topics.app-1"]);
        }

        [Test]
        public void EmptyScopeUsesTheDefaultKey()
        {
            Provider.ScopeIdValue = string.Empty;
            StartEnabled("a");

            Assert.AreEqual("a", Host.Store["PlatformLibrary.Push.Topics.default"]);
        }
    }
}
