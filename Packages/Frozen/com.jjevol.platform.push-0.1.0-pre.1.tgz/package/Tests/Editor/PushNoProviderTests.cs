using NUnit.Framework;

namespace PlatformLibrary.Push.Tests
{
    public sealed class PushNoProviderTests : PushTestBase
    {
        [Test]
        public void RequestPermissionAnswersUnsupported()
        {
            PushResult? answer = null;
            PushManager.RequestPermission(result => answer = result);

            Assert.AreEqual(PushFailure.Unsupported, answer.Value.Failure);
            Assert.IsFalse(PushManager.IsSupported);
        }

        [Test]
        public void InitializeWithoutProviderReportsInitialized()
        {
            PushManager.Initialize();
            PushManager.SetEnabled(true);
            PushManager.SetTopics("a");

            Assert.IsTrue(PushManager.IsInitialized);
            Assert.IsTrue(PushManager.IsEnabled);
            Assert.AreEqual(string.Empty, PushManager.Token);
            CollectionAssert.IsEmpty(Syncs);
        }

        [Test]
        public void SettingsMadeBeforeTheProviderCarryOver()
        {
            PushManager.SetEnabled(true);
            PushManager.SetTopics("a");
            UseProvider();
            PushManager.Initialize();

            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", "GetToken", "Subscribe:a" }, Provider.Calls);
            Assert.IsTrue(PushManager.IsSupported);
        }

        [Test]
        public void RemovingTheProviderClearsTheToken()
        {
            StartEnabled("a");
            PushManager.SetProvider(null);

            Assert.AreEqual(string.Empty, PushManager.Token);
            CollectionAssert.AreEqual(new[] { "token-1", string.Empty }, Tokens);
            Assert.IsFalse(PushManager.IsInitialized);
        }
    }
}
