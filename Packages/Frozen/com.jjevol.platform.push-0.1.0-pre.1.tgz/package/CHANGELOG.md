# Changelog

## 0.1.0-pre.1 - 2026-11-08

New design, per `Docs/PlatformPush/Design.md`. It replaces the mobile library's `FirebasePushManager`, `FirebasePushTopicSubscription` and Core `IPlatformPushProvider`. Class names and GUIDs are not kept, so a game moving over needs code changes.

- `PushManager` is the static entry point. Games need no SDK and no provider.
- Syncing, retries after 30 seconds and on resume, and saved topics moved from the game into the manager.
- `PushFailure` replaces exceptions and `NotSupportedException`. Names shared with the network package, such as `NoConnection` and `Timeout`, match `NetworkFailure`. The SDK code stays in `PushResult.ProviderCode` for logs.
- A topic list replaces the single language topic. One topic behaves as before.
- `RequestPermission` answers `Disabled` after `SetEnabled(false)`, and `ProviderError` when the provider changes before it answers.
- `PushMessage` adds `MessageId`, `Data` and `Opened`, and messages with only data are delivered.
- The saved topics key is now `PlatformLibrary.Push.Topics.{ScopeId}`. It was `FirebasePush.LanguageTopic.{appId}`.

Unity EditMode and PlayMode tests passed in `Hosts/PlatformPushValidationHost` on 2026-11-08. Player and device tests are NOT_RUN. See `Docs/PlatformPush/Report.md`.
