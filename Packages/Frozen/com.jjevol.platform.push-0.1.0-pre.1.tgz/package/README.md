# JJEvol Platform Push

Local validation candidate 0.1.0-pre.1. The push manager, the provider contract and the result types. Games call `PushManager` and never see an SDK.

The code is user-authored, confirmed by the user on 2026-11-08. This package has no SDK, configuration file, topic name or notification text in it.

## Use

The project's start code decides what runs. This is the only place that names a provider:

```csharp
#if UNITY_ANDROID || UNITY_IOS
PushManager.SetProvider(new FirebasePushProvider());
#endif
PushManager.Initialize();
PushManager.SetTopics("user-" + languageCode);
PushManager.SetEnabled(options.PushOn);
```

Game code knows only the manager:

```csharp
PushManager.MessageReceived += message =>
{
    if (message.Opened && message.Data.TryGetValue("screen", out string screen)) OpenScreen(screen);
};
```

Call `PushManager` from the Unity main thread. Every callback and event runs on the main thread. A listener that throws is logged and does not stop the manager.

## No provider

Nothing is required. With no provider, `Initialize` completes, `RequestPermission` answers `PushFailure.Unsupported`, `Token` stays empty and no message arrives. A platform with no push, such as a Windows or Steam build, simply registers none.

Choosing a provider belongs to the project: this package has no default provider, no selection define and no store branch. `SetProvider(null)` removes a provider. A new provider keeps the enabled state and topics, and needs `Initialize` again.

## Calls

| Call | Behavior |
|---|---|
| `Initialize()` | Starts the provider. Nothing syncs until `SetEnabled` is called once. |
| `SetEnabled(bool)` | On: asks for permission the first time, gets the token and subscribes the topics. Off: unsubscribes the topics, deletes the token and turns automatic registration off. |
| `SetTopics(params string[])` | The topics wanted. Blank and repeated names are dropped. Only the difference is sent. |
| `RequestPermission(callback)` | Asks for permission at a moment the game chooses. After `SetEnabled(false)` it answers `Disabled` without asking. Before the first `SetEnabled` it asks. |
| `Token` | The current token. Empty while off or before the provider has one. |
| `TokenChanged` | Fires when the token changes or is cleared. Send it to a server here if the project needs that, with its own request through `NetworkManager`. Push itself calls no server. |
| `MessageReceived` | A `PushMessage`. Not raised while off. |
| `Synchronized` | Fires once each time a sync ends, with its `PushResult`. For logs and tests. |

`SetEnabled` and `SetTopics` describe the wanted state. The manager sends one SDK call at a time and reads the wanted state again after each answer, so a late answer never wins over a newer setting. A failed sync retries after 30 seconds and when the app resumes. A topic the SDK rejects as `InvalidTopic` is dropped and not retried.

Topics that may be subscribed are saved before the request goes out, in `PlayerPrefs` under `PlatformLibrary.Push.Topics.{ScopeId}`, and removed once the unsubscribe is confirmed. A game that switches off or changes language while offline still unsubscribes later.

A message can arrive before the game listens, for example the one that opened the app. Up to 16 such messages are held and go to the first listener once. Turning push off drops them.

## Results

`PushResult.Failure` is the only value a game branches on. `ProviderCode` and `Detail` are for logs. Names shared with `com.jjevol.platform.network` match its `NetworkFailure`.

| `Failure` | Meaning |
|---|---|
| `None` | The call worked. |
| `Unsupported` | No provider, or the platform has no push. |
| `NotInitialized` | `Initialize` has not finished. |
| `Disabled` | Push is off: `RequestPermission` after `SetEnabled(false)`. |
| `NoConnection` | No network, or the SDK could not reach its service. |
| `Timeout` | The SDK call timed out. |
| `InvalidTopic` | The SDK rejected a topic name. |
| `TokenUnavailable` | The SDK gave no token. |
| `ProviderError` | Any other SDK error. A provider change ends a waiting `RequestPermission` with this and `Detail` `PROVIDER_CHANGED`. |

`PushMessage` carries `MessageId`, `Title`, `Body`, `Data` and `Opened`. `Opened` is true when the player tapped the notification to open the app. Messages with only data are delivered too.

## Writing a provider

Implement `IPushProvider`. The manager calls it on the main thread, and it may answer and raise events from any thread. The manager already handles the order of calls, retries, saved topics and the off state. A provider only talks to its SDK and turns SDK errors into `PushFailure`, keeping the SDK code in `PushResult.Failed`. `ScopeId` separates saved topics per app, for example by the Firebase App ID.

## Validation

Tests are in `Tests/Editor` and `Tests/Runtime`, in isolated assemblies, and need no SDK and no provider package. Run them from `Hosts/PlatformPushValidationHost`. `Tests/Editor` drives time, threads and storage by hand. `Tests/Runtime` uses the real Unity host. See `Docs/PlatformPush/Report.md` for what has run.
