# JJEvol Platform Login

Local validation candidate 0.1.0-pre.1. The login manager, the provider contracts and the result types. Games call `LoginManager` and never see an SDK.

The code is user-authored, confirmed by the user on 2026-11-08. This package has no SDK, client ID, key, configuration file or game policy in it.

## Use

The project's start code decides what runs. This is the only place that names providers:

```csharp
LoginManager.AddProvider(new GoogleLoginProvider(googleLoginSettings));
#if UNITY_IOS
LoginManager.AddProvider(new AppleLoginProvider());
#endif
LoginManager.SetAccountProvider(new FirebaseAccountProvider(FirebaseAuth.GetAuth(app), "live"));
```

Game code knows only the manager:

```csharp
appleButton.SetActive(LoginManager.IsAvailable(LoginMethod.Apple));

if (LoginManager.HasLoginHistory) LoginManager.RestoreSession(OnLogin);

LoginManager.SignIn(LoginMethod.Google, OnLogin);

void OnLogin(LoginResult result)
{
    if (result.Success) EnterLobby(result.Account.UserId);
    else if (result.Failure != LoginFailure.Cancelled) ShowLoginFailed(result.Failure);
}
```

Call `LoginManager` from the Unity main thread. Every callback runs once, on the main thread. A callback that throws is logged and does not stop the manager.

## Two kinds of provider

| Contract | What it does | How many |
|---|---|---|
| `ILoginProvider` | Gets a credential from a platform, such as a Google ID token or an Apple identity token. | Any number, one per `LoginMethod`. |
| `IAccountProvider` | Turns a credential into the game account, such as a Firebase user, and gives tokens for the game's server. Guest accounts belong here. | One at a time. |

`LoginMethod` is a value with a string ID. `Guest`, `Google` and `Apple` are built in. A new method needs no change here: a provider package declares `new LoginMethod("steam")`, the project registers it with `AddProvider`, and the account provider learns to accept its credential. IDs use `a-z`, `0-9`, `.`, `_`, `:` and `-`, at most 64 characters.

## Nothing registered

Nothing is required. With no provider and no account provider, every call answers `LoginFailure.NotConfigured` at once and the game keeps running. Choosing providers belongs to the project: this package has no default provider, no selection define and no store branch.

`SetAccountProvider` with another provider, for example when the project switches Firebase environments, ends a running call with `SessionChanged`, discards a link conflict, clears the account and reads saved state for the new environment. The previous provider is disposed when it is `IDisposable`. Changing providers never signs out. `SetAccountProvider(null)` removes it. `Clear()` removes everything.

## Calls

| Call | Behavior |
|---|---|
| `SignIn(method, callback)` | `Guest` uses the account provider's guest account or creates one. Any other method asks its provider for a credential with the login screen allowed, then signs into the account provider with it. |
| `RestoreSession(callback)` | Signs in again with `LastMethod` and no login screen. First the account provider's saved session. Only when there is none (`NoSavedLogin`), the method's silent login. Any other failure of the saved session, such as `NoConnection`, is the answer, without a silent login. Answers `NoSavedLogin` when neither has a session. A guest is only restored, never created. |
| `Link(method, callback)` | Links the method to the signed-in account. Always shows the login screen. An already linked method answers success with `Detail` `already_linked`. |
| `SwitchToLinkedAccount(callback)` | After a link conflict: signs into the account that owns the method. |
| `DiscardLinkConflict()` | After a link conflict: keeps the current account. |
| `Unlink(method, callback)` | Unlinks the method. The account's only linked method is refused with `Unsupported` and `Detail` `last_linked_method`. |
| `SignOut(keepLastMethod)` | Signs out of the account provider and ends a running call with `Cancelled`. By default also forgets `LastMethod` and saved platform user IDs. |
| `Cancel()` | Ends the running call with `Cancelled`. |
| `GetToken(forceRefresh, callback)`, `GetTokenAsync(forceRefresh)` | A token for the game's server. May overlap login calls. |

Only one login call runs at a time. A second answers `Busy`. A credential request that takes 150 seconds, and an account call that takes 60 seconds, answer `Timeout`. A late provider answer is never reported to the game. A late account answer may have changed the account provider's session, so the manager follows it: after `Cancel` or a timeout the manager takes the provider's user and raises `AccountChanged`, and after `SignOut` it signs the provider out again. A late link conflict is discarded. A result that arrives after the account changed answers `SessionChanged` and changes nothing. `GetToken` answers `SessionChanged` when the account provider holds another user than the manager.

`IsAvailable`, `GetAvailability` and `GetLinkAvailability` tell the title screen which buttons to show without calling anything.

Events run on the main thread:

| Event | When |
|---|---|
| `AccountChanged` | The signed-in account changed. Null after sign-out or an account provider change. |
| `BusyChanged` | A call started (true) or ended (false). The end comes before the callback. Use it for the loading indicator. |
| `CredentialRevoked` | The player withdrew the app's permission outside the game, for example in iOS settings. The method's saved user ID is forgotten, and `LastMethod` too when it was that method. |

## Link conflicts

A method already linked to another account answers `AlreadyLinkedToOtherAccount`, and `HasLinkConflict` turns true. The current account stays signed in. The game asks the player and then calls one of the two:

```csharp
LoginManager.Link(LoginMethod.Google, result =>
{
    if (result.Failure != LoginFailure.AlreadyLinkedToOtherAccount) return;
    AskSwitchAccount(yes =>
    {
        if (yes) LoginManager.SwitchToLinkedAccount(OnLogin);
        else LoginManager.DiscardLinkConflict();
    });
});
```

A new `Link`, a sign-out or an account provider change also discards the conflict.

## Saved state

The manager keeps three values per account provider `EnvironmentKey`, in `PlayerPrefs` by default. Use the same key as the network package's `NetworkManager.EnvironmentKey`, for example `live` or `stage`. `SetStateStore` replaces the store. An empty key keeps nothing.

| Key | Value |
|---|---|
| `jjevol.login.{env}.lastMethod` | `LoginMethod` ID of the last successful login. |
| `jjevol.login.{env}.history` | `1` once any login has worked. Sign-out keeps it. |
| `jjevol.login.{env}.subject.{methodId}` | The platform user ID, such as the Apple user ID, given to the provider for a silent login. |

A temporary failure (`NoConnection`, `Timeout`, `Busy`, `NotInitialized`, `SessionChanged`, `ProviderError`) keeps `LastMethod`, so the next start tries again. Other failures of `SignIn` and `RestoreSession` forget it. A guest stays protected: when the signed-in account is a guest, `LastMethod` falls back to `Guest` instead of being forgotten, and `AccountInvalid` does not sign a guest out.

These keys are new. Keys of the mobile library's login are not read.

## Results

`LoginResult.Failure` is the only value a game branches on. `ProviderCode` and `Detail` are for logs.

| `Failure` | Meaning |
|---|---|
| `None` | The call worked. |
| `NotConfigured` | No provider for the method, no account provider, or a required setting is empty. |
| `Unsupported` | The method does not work on this platform or device. |
| `NotInitialized` | The account provider is not ready yet. |
| `Busy` | Another login call is running. |
| `Cancelled` | The player cancelled, or the game called `Cancel` or `SignOut`. |
| `Timeout` | The provider did not answer in time. |
| `NoConnection` | No connection, or the connection failed. The same name as `NetworkFailure.NoConnection`. |
| `NoSavedLogin` | Nothing to restore without a login screen, or no Google account on the device. |
| `CredentialRejected` | The credential was missing, malformed or refused. |
| `CredentialRevoked` | The player withdrew the app's permission. |
| `NotSignedIn` | Link, unlink and token calls need a signed-in account. |
| `AlreadyLinkedToOtherAccount` | See link conflicts. |
| `AccountInvalid` | The account was deleted or disabled on the server. |
| `SessionChanged` | The account changed while the call ran. Its result was dropped. |
| `ProviderError` | Any other provider error. |

## The game's server

`GetToken` gives the account provider's token, for example a Firebase ID token. This package does not reference `com.jjevol.platform.network`, and the network packages do not reference this one. The project's start code connects them.

The HTTP provider of `com.jjevol.platform.network.http` takes a token source, `Func<bool, Task<string>>`. It puts the token in the `Authorization` header and, on 401 or 403, asks once more with a forced refresh:

```csharp
new HttpNetworkSettings()
    .SetAuthTokenSource(async force => (await LoginManager.GetTokenAsync(force)).Value);
```

A failed token has a null `Value`, and the network answers `Unauthorized`. Firebase Functions, through `com.jjevol.platform.network.firebase`, needs no token source: the SDK sends the signed-in user of the same Firebase app.

When the project switches environments with `NetworkManager.SwitchEnvironment`, it registers the account provider of that environment when `EnvironmentChanged` is raised:

```csharp
// key is the new NetworkManager.EnvironmentKey, for example "stage"
LoginManager.SetAccountProvider(new FirebaseAccountProvider(FirebaseAuth.GetAuth(GameFirebase.GetApp(key)), key));
```

The manager then reads the saved state of that environment. The game session (`NetworkManager.SetSession`, `ClearSession`) belongs to the project: it starts one after `AccountChanged` reports a signed-in account and ends it on sign-out.

## Trust boundary

The trust boundary in the `com.jjevol.platform.core` README applies here. A login callback is not proof of who the player is.

| Client value | What it means | What proves it |
|---|---|---|
| `LoginResult.Success`, `LoginAccount.UserId` | The account SDK told this client it signed in. | The game's server verifies the token from `GetToken` on every request, for example with Firebase Admin, and takes the user ID from it. |
| `LoginCredential.Subject` | A platform user ID the client read from an unverified token. | Nothing. Never use it to identify a player. |

Tokens, authorization codes and nonces are never logged or put in `Detail`. `LoginToken.ToString` hides the value.

## Writing a provider

Implement `ILoginProvider` for a login method, or `IAccountProvider` for an account system. The manager calls it on the main thread, and it may answer from any thread, once per call. The manager already handles one call at a time, timeouts, late answers, cancellation, the session check, saved state and guest protection. A provider only talks to its SDK and turns SDK codes into `LoginFailure`, keeping the SDK code in `ProviderCode`.

`LoginCredentialRequest.Prompt` says whether a login screen may show:

| `LoginPrompt` | Used by | A provider that needs a screen |
|---|---|---|
| `Silent` | `RestoreSession` | Answers `NoSavedLogin`. |
| `Allowed` | `SignIn` | Tries silently first when it can. |
| `Required` | `Link` | Always shows it. |

`SavedSubject` is the platform user ID kept from the last login, for example to check an Apple credential's state. A provider that finds it no longer valid sets `savedSubjectInvalid`, and the manager forgets it.

## Validation

Tests are in `Tests/Editor` and `Tests/Runtime`, in isolated assemblies, and need no SDK and no provider package. Run them from `Hosts/PlatformLoginValidationHost`. `Tests/Editor` drives time and threads by hand. `Tests/Runtime` uses the real Unity host for threads, real-time timeouts and scene survival. See `Docs/PlatformLogin/Report.md` for what has run.
