using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Login.Tests
{
    public sealed class UnityLoginHostTests
    {
        private sealed class MemoryStore : ILoginStateStore
        {
            private readonly Dictionary<string, string> _values = new Dictionary<string, string>();
            public string Get(string key) => _values.TryGetValue(key, out string value) ? value : null;
            public void Set(string key, string value) => _values[key] = value;
            public void Delete(string key) => _values.Remove(key);
        }

        // A method provider that never answers, so a timeout decides the call.
        private sealed class SilentProvider : ILoginProvider
        {
            public LoginMethod Method => LoginMethod.Google;
            public LoginFailure Availability => LoginFailure.None;
            public event Action CredentialRevoked { add { } remove { } }
            public void RequestCredential(LoginCredentialRequest request, Action<LoginCredentialResult> callback) { }
            public void Cancel() { }
        }

        // An account provider that answers from a worker thread.
        private sealed class WorkerAccountProvider : IAccountProvider
        {
            public string EnvironmentKey => "runtime-test";
            public LoginFailure Availability => LoginFailure.None;
            public LoginAccount Current { get; private set; }

            public void SignInGuest(Action<AccountResult> callback)
            {
                Task.Run(() =>
                {
                    Current = new LoginAccount("guest-1", true, linkedMethods: new[] { LoginMethod.Guest });
                    callback(AccountResult.Succeeded(Current));
                }).GetAwaiter().GetResult();
            }

            public void Restore(LoginMethod method, Action<AccountResult> callback) => callback(AccountResult.Failed(LoginFailure.NoSavedLogin));
            public void SignIn(LoginCredential credential, Action<AccountResult> callback) => callback(AccountResult.Failed(LoginFailure.Unsupported));
            public void Link(LoginCredential credential, Action<AccountResult> callback) => callback(AccountResult.Failed(LoginFailure.Unsupported));
            public void SwitchToLinkedAccount(string conflict, Action<AccountResult> callback) => callback(AccountResult.Failed(LoginFailure.Unsupported));
            public void DiscardConflict(string conflict) { }
            public void Unlink(LoginMethod method, Action<AccountResult> callback) => callback(AccountResult.Failed(LoginFailure.Unsupported));
            public void GetToken(bool forceRefresh, Action<LoginToken> callback) => callback(LoginToken.Failed(LoginFailure.Unsupported));
            public void Cancel() { }
            public void SignOut() => Current = null;
        }

        [SetUp]
        public void SetUp() => LoginManager.ResetState();

        [TearDown]
        public void TearDown()
        {
            LoginManager.Clear();
            LoginManager.ResetState();
        }

        [UnityTest]
        public IEnumerator WorkerThreadCallbackRunsOnTheMainThreadOnALaterUpdate()
        {
            int mainThread = Thread.CurrentThread.ManagedThreadId;
            int callbackThread = 0;
            ILoginHost host = UnityLoginHost.Instance;

            Task.Run(() => host.Post(() => callbackThread = Thread.CurrentThread.ManagedThreadId)).GetAwaiter().GetResult();
            Assert.That(callbackThread, Is.Zero);

            yield return null;
            yield return null;

            Assert.That(callbackThread, Is.EqualTo(mainThread));
        }

        [UnityTest]
        public IEnumerator ScheduledActionRunsAfterRealTimeAndCanBeCancelled()
        {
            ILoginHost host = UnityLoginHost.Instance;
            bool ran = false;
            bool cancelled = false;

            host.Schedule(0.01f, () => ran = true);
            host.Schedule(0.01f, () => cancelled = true)();

            yield return new WaitForSecondsRealtime(0.1f);

            Assert.That(ran, Is.True);
            Assert.That(cancelled, Is.False);
        }

        [Test]
        public void HostSurvivesSceneLoads()
        {
            Assert.That(UnityLoginHost.Instance.gameObject.scene.name, Is.EqualTo("DontDestroyOnLoad"));
        }

        [Test]
        public void GameWithNothingRegisteredKeepsRunning()
        {
            LoginResult? result = null;
            LoginToken? token = null;

            LoginManager.SignIn(LoginMethod.Google, value => result = value);
            LoginManager.GetToken(false, value => token = value);

            Assert.That(result?.Failure, Is.EqualTo(LoginFailure.NotConfigured));
            Assert.That(token?.Failure, Is.EqualTo(LoginFailure.NotConfigured));
            Assert.That(LoginManager.IsSignedIn, Is.False);
        }

        [UnityTest]
        public IEnumerator CredentialRequestTimesOutInRealTime()
        {
            LoginResult? result = null;
            LoginManager.Use(UnityLoginHost.Instance, new MemoryStore(), 0.05f, 0.05f);
            LoginManager.AddProvider(new SilentProvider());
            LoginManager.SetAccountProvider(new WorkerAccountProvider());

            LoginManager.SignIn(LoginMethod.Google, value => result = value);
            Assert.That(LoginManager.IsBusy, Is.True);

            yield return new WaitForSecondsRealtime(0.2f);

            Assert.That(result?.Failure, Is.EqualTo(LoginFailure.Timeout));
            Assert.That(LoginManager.IsBusy, Is.False);
        }

        [UnityTest]
        public IEnumerator AccountAnswerFromAWorkerThreadReachesTheCallbackOnTheMainThread()
        {
            int mainThread = Thread.CurrentThread.ManagedThreadId;
            int callbackThread = 0;
            LoginResult? result = null;
            LoginManager.Use(UnityLoginHost.Instance, new MemoryStore(), 1f, 1f);
            LoginManager.SetAccountProvider(new WorkerAccountProvider());

            LoginManager.SignIn(LoginMethod.Guest, value =>
            {
                callbackThread = Thread.CurrentThread.ManagedThreadId;
                result = value;
            });

            yield return new WaitForSecondsRealtime(0.1f);

            Assert.That(callbackThread, Is.EqualTo(mainThread));
            Assert.That(result?.Success, Is.True);
            Assert.That(LoginManager.Account?.UserId, Is.EqualTo("guest-1"));
        }
    }
}
