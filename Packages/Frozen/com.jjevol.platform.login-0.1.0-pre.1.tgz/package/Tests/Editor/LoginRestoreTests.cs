using NUnit.Framework;

namespace PlatformLibrary.Login.Tests
{
    public sealed class LoginRestoreTests
    {
        [Test]
        public void RestoreWithoutALastMethodAnswersNoSavedLogin()
        {
            var f = new LoginFixture();
            f.Session.RestoreSession(f.Record);
            Assert.AreEqual(LoginFailure.NoSavedLogin, f.Last.Failure);
            Assert.AreEqual(0, f.Account.Calls.Count);
            Assert.IsFalse(f.Session.HasLoginHistory);
        }

        [Test]
        public void RestoreUsesTheSavedSessionFirst()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "google");
            f.Session.RestoreSession(f.Record);

            Assert.AreEqual("restore:google", f.Account.Calls[0]);
            f.Account.Succeed("u", false, LoginMethod.Google);
            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual(LoginMethod.Google, f.Last.Method);
            Assert.AreEqual(0, f.Google.Requests.Count);
            Assert.AreEqual("1", f.State(LoginStateKeys.History("test")));
        }

        [Test]
        public void RestoreFallsBackToASilentCredential()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "apple");
            f.Store.Set(LoginStateKeys.Subject("test", LoginMethod.Apple), "apple-user");
            f.Session.RestoreSession(f.Record);
            f.Account.Fail(LoginFailure.NoSavedLogin);

            Assert.AreEqual(LoginPrompt.Silent, f.Apple.LastRequest.Prompt);
            Assert.AreEqual("apple-user", f.Apple.LastRequest.SavedSubject);
            f.Apple.Succeed("apple-user");
            Assert.AreEqual("signin:apple", f.Account.Calls[1]);
            f.Account.Succeed("u", false, LoginMethod.Apple);
            Assert.IsTrue(f.Last.Success);
        }

        [Test]
        public void SilentFailureEndsTheRestore()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "google");
            f.Session.RestoreSession(f.Record);
            f.Account.Fail(LoginFailure.NoSavedLogin);
            f.Google.Fail(LoginFailure.NoSavedLogin);
            Assert.AreEqual(LoginFailure.NoSavedLogin, f.Last.Failure);
            Assert.IsNull(f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void RestoringAGuestNeverCreatesAnAccount()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "guest");
            f.Session.RestoreSession(f.Record);
            Assert.AreEqual("restore:guest", f.Account.Calls[0]);
            f.Account.Fail(LoginFailure.NoSavedLogin);

            Assert.AreEqual(LoginFailure.NoSavedLogin, f.Last.Failure);
            Assert.AreEqual(1, f.Account.Calls.Count);
        }

        [Test]
        public void AnInvalidAccountDoesNotFallBack()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "google");
            f.Session.RestoreSession(f.Record);
            f.Account.Fail(LoginFailure.AccountInvalid, 14);
            Assert.AreEqual(LoginFailure.AccountInvalid, f.Last.Failure);
            Assert.AreEqual(0, f.Google.Requests.Count);
        }

        [Test]
        public void StateIsKeptPerEnvironment()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            Assert.AreEqual(LoginMethod.Google, f.Session.LastMethod);

            f.Session.SetAccountProvider(new FakeAccountProvider("dev"));
            Assert.IsTrue(f.Session.LastMethod.IsNone);
            Assert.IsFalse(f.Session.HasLoginHistory);

            f.Session.SetAccountProvider(new FakeAccountProvider("test"));
            Assert.AreEqual(LoginMethod.Google, f.Session.LastMethod);
            Assert.IsTrue(f.Session.HasLoginHistory);
        }

        [Test]
        public void AnEmptyEnvironmentKeepsNothing()
        {
            var f = new LoginFixture(withAccount: false);
            var account = new FakeAccountProvider("");
            f.Session.SetAccountProvider(account);
            f.Session.SignIn(LoginMethod.Guest, f.Record);
            account.Succeed("g", true);
            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual(0, f.Store.Values.Count);
        }

        [Test]
        public void AnOfflineRestoreKeepsTheLastMethodAndAsksNoPlatform()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "google");
            f.Session.RestoreSession(f.Record);
            f.Account.Fail(LoginFailure.NoConnection);

            Assert.AreEqual(LoginFailure.NoConnection, f.Last.Failure);
            Assert.AreEqual(0, f.Google.Requests.Count);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void AProviderErrorDuringRestoreKeepsTheLastMethod()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "apple");
            f.Session.RestoreSession(f.Record);
            f.Account.Fail(LoginFailure.ProviderError, 7);

            Assert.AreEqual(LoginFailure.ProviderError, f.Last.Failure);
            Assert.AreEqual(7, f.Last.ProviderCode);
            Assert.AreEqual(0, f.Apple.Requests.Count);
            Assert.AreEqual("apple", f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void ARestoreTimeoutKeepsTheLastMethod()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "google");
            f.Session.RestoreSession(f.Record);
            f.Host.Advance(60f);

            Assert.AreEqual(LoginFailure.Timeout, f.Last.Failure);
            Assert.AreEqual(0, f.Google.Requests.Count);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void AnOfflineSilentRequestKeepsTheLastMethod()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "google");
            f.Session.RestoreSession(f.Record);
            f.Account.Fail(LoginFailure.NoSavedLogin);
            f.Google.Fail(LoginFailure.NoConnection);

            Assert.AreEqual(LoginFailure.NoConnection, f.Last.Failure);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
        }
    }
}
