using NUnit.Framework;

namespace PlatformLibrary.Login.Tests
{
    public sealed class LoginLinkTests
    {
        [Test]
        public void LinkNeedsASignedInAccount()
        {
            var f = new LoginFixture();
            f.Session.Link(LoginMethod.Google, f.Record);
            Assert.AreEqual(LoginFailure.NotSignedIn, f.Last.Failure);
            Assert.AreEqual(LoginFailure.Unsupported, f.Session.GetLinkAvailability(LoginMethod.Guest));
        }

        [Test]
        public void LinkAlwaysPromptsAndUpdatesTheAccount()
        {
            var f = new LoginFixture();
            f.SignInAsGuest("guest-1");
            f.Session.Link(LoginMethod.Google, f.Record);

            Assert.AreEqual(LoginPrompt.Required, f.Google.LastRequest.Prompt);
            f.Google.Succeed("google-sub");
            Assert.AreEqual("link:google", f.Account.Calls[1]);
            f.Account.Succeed("guest-1", false, LoginMethod.Google);

            Assert.IsTrue(f.Last.Success);
            Assert.IsTrue(f.Session.IsLinked(LoginMethod.Google));
            Assert.AreEqual(LoginMethod.Google, f.Session.Account.Method);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
            Assert.AreEqual("google-sub", f.State(LoginStateKeys.Subject("test", LoginMethod.Google)));
        }

        [Test]
        public void AnAlreadyLinkedMethodAnswersSuccessWithoutAPrompt()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            int requests = f.Google.Requests.Count;
            f.Session.Link(LoginMethod.Google, f.Record);
            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual("already_linked", f.Last.Detail);
            Assert.AreEqual(requests, f.Google.Requests.Count);
        }

        [Test]
        public void AConflictWaitsForTheGame()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.Link(LoginMethod.Apple, f.Record);
            f.Apple.Succeed("apple-user");
            f.Account.Pending(AccountResult.LinkConflict("conflict-1", 10));

            Assert.AreEqual(LoginFailure.AlreadyLinkedToOtherAccount, f.Last.Failure);
            Assert.AreEqual(10, f.Last.ProviderCode);
            Assert.IsTrue(f.Session.HasLinkConflict);
            Assert.IsTrue(f.Session.IsSignedIn);
            Assert.IsTrue(f.Session.Account.IsGuest);
        }

        [Test]
        public void SwitchingSignsIntoTheOwnerOfTheMethod()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.Link(LoginMethod.Apple, f.Record);
            f.Apple.Succeed("apple-user");
            f.Account.Pending(AccountResult.LinkConflict("conflict-1"));

            f.Session.SwitchToLinkedAccount(f.Record);
            Assert.AreEqual("conflict-1", f.Account.LastConflict);
            Assert.IsFalse(f.Session.HasLinkConflict);
            f.Account.Succeed("owner", false, LoginMethod.Apple);

            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual("owner", f.Session.Account.UserId);
            Assert.AreEqual(LoginMethod.Apple, f.Session.Account.Method);
            Assert.AreEqual("apple", f.State(LoginStateKeys.LastMethod("test")));
            Assert.AreEqual("apple-user", f.State(LoginStateKeys.Subject("test", LoginMethod.Apple)));
        }

        [Test]
        public void DiscardingTellsTheAccountProvider()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.Link(LoginMethod.Apple, f.Record);
            f.Apple.Succeed();
            f.Account.Pending(AccountResult.LinkConflict("conflict-1"));

            f.Session.DiscardLinkConflict();
            CollectionAssert.AreEqual(new[] { "conflict-1" }, f.Account.Discarded);
            Assert.IsFalse(f.Session.HasLinkConflict);

            f.Session.SwitchToLinkedAccount(f.Record);
            Assert.AreEqual(LoginFailure.NoSavedLogin, f.Last.Failure);
        }

        [Test]
        public void ANewLinkDiscardsAnOldConflict()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.Link(LoginMethod.Apple, f.Record);
            f.Apple.Succeed();
            f.Account.Pending(AccountResult.LinkConflict("conflict-1"));

            f.Session.Link(LoginMethod.Google, f.Record);
            CollectionAssert.AreEqual(new[] { "conflict-1" }, f.Account.Discarded);
        }

        [Test]
        public void ALinkIsDroppedWhenTheUserChanged()
        {
            var f = new LoginFixture();
            f.SignInAsGuest("guest-1");
            f.Session.Link(LoginMethod.Google, f.Record);
            f.Account.Current = new LoginAccount("someone-else", true);
            f.Google.Succeed();
            Assert.AreEqual(LoginFailure.SessionChanged, f.Last.Failure);
            Assert.AreEqual(1, f.Account.Calls.Count);
        }

        [Test]
        public void ALinkAnsweredForAnotherUserIsDropped()
        {
            var f = new LoginFixture();
            f.SignInAsGuest("guest-1");
            f.Session.Link(LoginMethod.Google, f.Record);
            f.Google.Succeed();
            f.Account.Succeed("other", false, LoginMethod.Google);
            Assert.AreEqual(LoginFailure.SessionChanged, f.Last.Failure);
            Assert.AreEqual("guest-1", f.Session.Account.UserId);
        }

        [Test]
        public void UnlinkKeepsAtLeastOneMethod()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            f.Session.Unlink(LoginMethod.Google, f.Record);
            Assert.AreEqual(LoginFailure.Unsupported, f.Last.Failure);
            Assert.AreEqual("last_linked_method", f.Last.Detail);
        }

        [Test]
        public void UnlinkUpdatesTheAccountAndForgetsTheSubject()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Succeed("apple-user");
            f.Account.Succeed("u", false, LoginMethod.Apple, LoginMethod.Google);

            f.Session.Unlink(LoginMethod.Apple, f.Record);
            Assert.AreEqual("unlink:apple", f.Account.Calls[1]);
            f.Account.Succeed("u", false, LoginMethod.Google);

            Assert.IsTrue(f.Last.Success);
            Assert.IsFalse(f.Session.IsLinked(LoginMethod.Apple));
            Assert.AreEqual(LoginMethod.Google, f.Session.Account.Method);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
            Assert.IsNull(f.State(LoginStateKeys.Subject("test", LoginMethod.Apple)));
        }

        [Test]
        public void UnlinkingAnUnlinkedMethodAnswersSuccess()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            f.Session.Unlink(LoginMethod.Apple, f.Record);
            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual("not_linked", f.Last.Detail);
        }
    }
}
