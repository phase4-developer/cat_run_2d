using System;
using NUnit.Framework;

namespace PlatformLibrary.Login.Tests
{
    public sealed class LoginDataTests
    {
        [Test]
        public void KnownMethodsHaveStableIds()
        {
            Assert.AreEqual("guest", LoginMethod.Guest.Id);
            Assert.AreEqual("google", LoginMethod.Google.Id);
            Assert.AreEqual("apple", LoginMethod.Apple.Id);
            Assert.IsTrue(LoginMethod.None.IsNone);
            Assert.AreEqual(string.Empty, LoginMethod.None.Id);
        }

        [Test]
        public void CustomMethodEqualsTheSameId()
        {
            Assert.AreEqual(new LoginMethod("steam"), new LoginMethod("steam"));
            Assert.AreEqual(LoginMethod.Google, new LoginMethod("google"));
            Assert.AreNotEqual(LoginMethod.Google, LoginMethod.Apple);
        }

        [Test]
        public void InvalidIdIsRejected()
        {
            Assert.Throws<ArgumentException>(() => new LoginMethod("Google"));
            Assert.Throws<ArgumentException>(() => new LoginMethod(""));
            Assert.Throws<ArgumentException>(() => new LoginMethod("a b"));
            Assert.Throws<ArgumentException>(() => new LoginMethod(new string('a', 65)));
        }

        [Test]
        public void ParseOfAnInvalidIdIsNone()
        {
            Assert.AreEqual(LoginMethod.Google, LoginMethod.Parse("google"));
            Assert.IsTrue(LoginMethod.Parse(null).IsNone);
            Assert.IsTrue(LoginMethod.Parse("NOT VALID").IsNone);
        }

        [Test]
        public void FailedResultsNeverCarryNone()
        {
            Assert.AreEqual(LoginFailure.ProviderError, LoginCredentialResult.Failed(LoginFailure.None).Failure);
            Assert.AreEqual(LoginFailure.ProviderError, AccountResult.Failed(LoginFailure.None).Failure);
            Assert.AreEqual(LoginFailure.ProviderError, LoginToken.Failed(LoginFailure.None).Failure);
            Assert.AreEqual(LoginFailure.ProviderError, LoginToken.Succeeded("").Failure);
        }

        [Test]
        public void TokenTextNeverShowsTheValue()
        {
            LoginToken token = LoginToken.Succeeded("secret-value");
            Assert.AreEqual("secret-value", token.Value);
            Assert.IsFalse(token.ToString().Contains("secret"));
            Assert.IsFalse(new LoginCredential(LoginMethod.Google, "s", "secret-token").ToString().Contains("secret"));
            Assert.IsNull(LoginToken.Failed(LoginFailure.NoConnection).Value);
        }

        [Test]
        public void AccountKeepsDistinctLinkedMethods()
        {
            var account = new LoginAccount("u", false, null, new[] { LoginMethod.Google, LoginMethod.Google, LoginMethod.None, LoginMethod.Apple });
            Assert.AreEqual(2, account.LinkedMethods.Count);
            Assert.IsTrue(account.IsLinked(LoginMethod.Apple));
            Assert.AreEqual(string.Empty, account.Email);
            Assert.Throws<ArgumentException>(() => new LoginAccount(" ", false));
        }

        [Test]
        public void StateKeysUseTheEnvironmentAndMethodId()
        {
            Assert.AreEqual("jjevol.login.live.lastMethod", LoginStateKeys.LastMethod("live"));
            Assert.AreEqual("jjevol.login.live.history", LoginStateKeys.History("live"));
            Assert.AreEqual("jjevol.login.dev.subject.apple", LoginStateKeys.Subject("dev", LoginMethod.Apple));
        }

        [Test]
        public void ManagerWithoutSetupAnswersNotConfigured()
        {
            LoginManager.ResetState();
            LoginResult signIn = default, restore = default, link = default;
            LoginToken token = default;
            LoginManager.SignIn(LoginMethod.Google, r => signIn = r);
            LoginManager.RestoreSession(r => restore = r);
            LoginManager.Link(LoginMethod.Apple, r => link = r);
            LoginManager.GetToken(false, t => token = t);

            Assert.AreEqual(LoginFailure.NotConfigured, signIn.Failure);
            Assert.AreEqual(LoginFailure.NotConfigured, restore.Failure);
            Assert.AreEqual(LoginFailure.NotConfigured, link.Failure);
            Assert.AreEqual(LoginFailure.NotConfigured, token.Failure);
            Assert.IsFalse(LoginManager.IsSignedIn);
            Assert.IsFalse(LoginManager.IsAvailable(LoginMethod.Guest));
            Assert.IsTrue(LoginManager.LastMethod.IsNone);
            Assert.IsTrue(LoginManager.GetTokenAsync().IsCompleted);
            LoginManager.SignOut();
            LoginManager.Cancel();
            LoginManager.Clear();
        }

        [Test]
        public void ManagerRunsOverAControlledHost()
        {
            LoginManager.ResetState();
            var host = new FakeHost();
            var account = new FakeAccountProvider();
            var changes = 0;
            LoginManager.AccountChanged += _ => changes++;
            LoginManager.Use(host, new FakeStore(), 150f, 60f);
            LoginManager.SetAccountProvider(account);

            LoginResult result = default;
            LoginManager.SignIn(LoginMethod.Guest, r => result = r);
            Assert.IsTrue(LoginManager.IsBusy);
            account.Succeed("guest-9", true);

            Assert.IsTrue(result.Success);
            Assert.IsTrue(LoginManager.IsSignedIn);
            Assert.AreEqual(LoginMethod.Guest, LoginManager.LastMethod);
            Assert.AreEqual(1, changes);

            var tokenTask = LoginManager.GetTokenAsync(true);
            Assert.IsTrue(account.LastForceRefresh);
            account.PendingToken(LoginToken.Succeeded("t"));
            Assert.AreEqual("t", tokenTask.Result.Value);
            LoginManager.ResetState();
        }
    }
}
