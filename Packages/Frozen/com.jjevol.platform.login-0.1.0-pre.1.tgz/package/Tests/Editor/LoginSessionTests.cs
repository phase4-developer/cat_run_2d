using NUnit.Framework;

namespace PlatformLibrary.Login.Tests
{
    public sealed class LoginSessionTests
    {
        [Test]
        public void SignOutForgetsTheLastMethodAndSubjects()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            f.Session.SignOut(false);

            Assert.IsFalse(f.Session.IsSignedIn);
            Assert.AreEqual(1, f.Account.SignOutCount);
            Assert.IsNull(f.State(LoginStateKeys.LastMethod("test")));
            Assert.IsNull(f.State(LoginStateKeys.Subject("test", LoginMethod.Google)));
            Assert.AreEqual("1", f.State(LoginStateKeys.History("test")));
            Assert.IsNull(f.AccountChanges[f.AccountChanges.Count - 1]);
        }

        [Test]
        public void SignOutCanKeepTheLastMethod()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            f.Session.SignOut(true);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
            Assert.AreEqual("google-sub", f.State(LoginStateKeys.Subject("test", LoginMethod.Google)));
        }

        [Test]
        public void SignOutEndsARunningCall()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Session.SignOut(false);
            Assert.AreEqual(LoginFailure.Cancelled, f.Last.Failure);
            Assert.AreEqual(1, f.Google.CancelCount);
        }

        [Test]
        public void ChangingTheAccountProviderEndsTheCallAndClearsTheAccount()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Session.SetAccountProvider(new FakeAccountProvider("other"));

            Assert.AreEqual(LoginFailure.SessionChanged, f.Last.Failure);
            Assert.IsFalse(f.Session.IsSignedIn);
            Assert.IsTrue(f.Account.Disposed);
            Assert.AreEqual(0, f.Account.SignOutCount);

            f.Google.Succeed();
            Assert.AreEqual(0, ((FakeAccountProvider)f.Session.AccountProvider).Calls.Count);
        }

        [Test]
        public void AConflictBelongsToItsAccountProvider()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.Link(LoginMethod.Apple, f.Record);
            f.Apple.Succeed();
            f.Account.Pending(AccountResult.LinkConflict("conflict-1"));

            f.Session.SetAccountProvider(new FakeAccountProvider());
            Assert.IsFalse(f.Session.HasLinkConflict);
            CollectionAssert.AreEqual(new[] { "conflict-1" }, f.Account.Discarded);
        }

        [Test]
        public void ARevokedCredentialIsForgotten()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Succeed("apple-user");
            f.Account.Succeed("u", false, LoginMethod.Apple);

            f.Apple.Revoke();
            CollectionAssert.AreEqual(new[] { LoginMethod.Apple }, f.Revoked);
            Assert.IsNull(f.State(LoginStateKeys.Subject("test", LoginMethod.Apple)));
            Assert.IsNull(f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void ClearRemovesProvidersAndStopsRevocationEvents()
        {
            var f = new LoginFixture();
            f.Session.Clear();
            Assert.IsFalse(f.Session.HasProvider(LoginMethod.Google));
            Assert.IsNull(f.Session.AccountProvider);
            f.Apple.Revoke();
            Assert.AreEqual(0, f.Revoked.Count);
        }

        [Test]
        public void GetTokenNeedsASignedInAccount()
        {
            var f = new LoginFixture();
            LoginToken token = default;
            f.Session.GetToken(false, t => token = t);
            Assert.AreEqual(LoginFailure.NotSignedIn, token.Failure);
            Assert.AreEqual(0, f.Account.Calls.Count);
        }

        [Test]
        public void GetTokenPassesTheProviderToken()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            LoginToken token = default;
            f.Session.GetToken(true, t => token = t);
            Assert.IsTrue(f.Account.LastForceRefresh);
            f.Account.PendingToken(LoginToken.Succeeded("id-token"));
            Assert.AreEqual("id-token", token.Value);
            Assert.AreEqual(0, f.Host.ActiveTimers);
        }

        [Test]
        public void GetTokenDropsATokenForAnotherAccount()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            LoginToken token = default;
            f.Session.GetToken(false, t => token = t);
            var answer = f.Account.PendingToken;
            f.Session.SignOut(false);
            answer(LoginToken.Succeeded("stale"));
            Assert.AreEqual(LoginFailure.SessionChanged, token.Failure);
            Assert.IsNull(token.Value);
        }

        [Test]
        public void GetTokenTimesOut()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            int answers = 0;
            LoginToken token = default;
            f.Session.GetToken(false, t => { token = t; answers++; });
            f.Host.Advance(60f);
            f.Account.PendingToken(LoginToken.Succeeded("late"));
            Assert.AreEqual(LoginFailure.Timeout, token.Failure);
            Assert.AreEqual(1, answers);
        }

        [Test]
        public void GetTokenRefusesWhenTheProviderHoldsAnotherUser()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle("a");
            f.Account.Current = new LoginAccount("b", false, null, new[] { LoginMethod.Google });
            LoginToken token = default;
            f.Session.GetToken(false, t => token = t);

            Assert.AreEqual(LoginFailure.SessionChanged, token.Failure);
            Assert.IsFalse(f.Account.Calls.Contains("token"));
            Assert.AreEqual("b", f.Session.Account.UserId);
        }

        [Test]
        public void GetTokenDropsATokenWhenTheProviderUserChangesMeanwhile()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle("a");
            LoginToken token = default;
            f.Session.GetToken(false, t => token = t);
            f.Account.Current = new LoginAccount("b", false, null, new[] { LoginMethod.Google });
            f.Account.PendingToken(LoginToken.Succeeded("token-of-b"));
            Assert.AreEqual(LoginFailure.SessionChanged, token.Failure);
            Assert.IsNull(token.Value);
        }

        [Test]
        public void ASignInFinishedAfterCancelBecomesTheAccount()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle("a");
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Succeed("apple-sub");
            f.Session.Cancel();
            Assert.AreEqual(LoginFailure.Cancelled, f.Last.Failure);
            Assert.AreEqual("a", f.Session.Account.UserId);

            f.Account.Succeed("b", false, LoginMethod.Apple);
            Assert.AreEqual("b", f.Session.Account.UserId);
            Assert.AreEqual(LoginMethod.Apple, f.Session.Account.Method);
            Assert.AreEqual("apple", f.State(LoginStateKeys.LastMethod("test")));
            Assert.AreEqual("b", f.AccountChanges[f.AccountChanges.Count - 1].UserId);
            Assert.AreEqual(LoginFailure.Cancelled, f.Last.Failure);

            LoginToken token = default;
            f.Session.GetToken(false, t => token = t);
            f.Account.PendingToken(LoginToken.Succeeded("token-of-b"));
            Assert.AreEqual("token-of-b", token.Value);
        }

        [Test]
        public void ASwitchFinishedAfterTimeoutBecomesTheAccount()
        {
            var f = new LoginFixture();
            f.SignInAsGuest("g");
            f.Session.Link(LoginMethod.Google, f.Record);
            f.Google.Succeed("google-sub");
            f.Account.Pending(AccountResult.LinkConflict("conflict-1"));
            f.Session.SwitchToLinkedAccount(f.Record);
            f.Host.Advance(60f);
            Assert.AreEqual(LoginFailure.Timeout, f.Last.Failure);
            Assert.AreEqual("g", f.Session.Account.UserId);

            f.Account.Succeed("owner", false, LoginMethod.Google);
            Assert.AreEqual("owner", f.Session.Account.UserId);
            Assert.AreEqual(LoginMethod.Google, f.Session.Account.Method);
        }

        [Test]
        public void ASignInFinishedAfterSignOutIsSignedOutAgain()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle("a");
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Succeed("apple-sub");
            f.Session.SignOut(false);
            Assert.AreEqual(1, f.Account.SignOutCount);

            f.Account.Succeed("b", false, LoginMethod.Apple);
            Assert.AreEqual(2, f.Account.SignOutCount);
            Assert.IsNull(f.Account.Current);
            Assert.IsNull(f.Session.Account);
            Assert.IsNull(f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void ARestoreFinishedAfterCancelSignsNothingIn()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.LastMethod("test"), "google");
            f.Session.RestoreSession(f.Record);
            f.Session.Cancel();
            f.Account.Succeed("a", false, LoginMethod.Google);
            Assert.IsNull(f.Session.Account);
            Assert.AreEqual(0, f.AccountChanges.Count);
        }

        [Test]
        public void ALateLinkConflictIsDiscarded()
        {
            var f = new LoginFixture();
            f.SignInAsGuest("g");
            f.Session.Link(LoginMethod.Google, f.Record);
            f.Google.Succeed("google-sub");
            f.Session.Cancel();
            f.Account.Pending(AccountResult.LinkConflict("conflict-1"));
            CollectionAssert.AreEqual(new[] { "conflict-1" }, f.Account.Discarded);
            Assert.IsFalse(f.Session.HasLinkConflict);
            Assert.AreEqual("g", f.Session.Account.UserId);
        }
    }
}
