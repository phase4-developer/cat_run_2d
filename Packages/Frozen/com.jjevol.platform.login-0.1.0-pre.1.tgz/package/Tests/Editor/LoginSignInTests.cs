using System;
using NUnit.Framework;

namespace PlatformLibrary.Login.Tests
{
    public sealed class LoginSignInTests
    {
        [Test]
        public void GuestSignInUsesTheAccountProviderAndRemembersGuest()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();

            Assert.AreEqual(1, f.Results.Count);
            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual(LoginMethod.Guest, f.Last.Method);
            Assert.IsTrue(f.Last.Account.IsGuest);
            Assert.AreEqual(LoginMethod.Guest, f.Session.Account.Method);
            Assert.AreEqual("guest", f.State(LoginStateKeys.LastMethod("test")));
            Assert.AreEqual("1", f.State(LoginStateKeys.History("test")));
            Assert.AreEqual(0, f.Google.Requests.Count);
        }

        [Test]
        public void PlatformCredentialSignsIntoTheAccountProvider()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Google, f.Record);

            Assert.AreEqual(LoginPrompt.Allowed, f.Google.LastRequest.Prompt);
            f.Google.Succeed("google-sub", "google-id-token");
            Assert.AreEqual("signin:google", f.Account.Calls[0]);
            Assert.AreEqual("google-id-token", f.Account.LastCredential.Token);
            Assert.AreEqual(0, f.Results.Count);

            f.Account.Succeed("firebase-uid", false, LoginMethod.Google);
            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual("firebase-uid", f.Last.Account.UserId);
            Assert.AreEqual(LoginMethod.Google, f.Session.Account.Method);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
            Assert.AreEqual("google-sub", f.State(LoginStateKeys.Subject("test", LoginMethod.Google)));
            CollectionAssert.AreEqual(new[] { true, false }, f.BusyChanges);
            Assert.AreEqual(1, f.AccountChanges.Count);
        }

        [Test]
        public void BusyEndsBeforeTheCallback()
        {
            var f = new LoginFixture();
            bool busyAtCallback = true;
            f.Session.SignIn(LoginMethod.Guest, _ => busyAtCallback = f.Session.IsBusy);
            f.Account.Succeed("g", true);
            Assert.IsFalse(busyAtCallback);
            Assert.AreEqual(false, f.BusyChanges[f.BusyChanges.Count - 1]);
        }

        [Test]
        public void SeveralProvidersAndACustomMethodWork()
        {
            var f = new LoginFixture();
            var steam = new FakeLoginProvider(new LoginMethod("steam"));
            f.Session.AddProvider(steam);

            Assert.AreEqual(LoginFailure.None, f.Session.GetAvailability(LoginMethod.Google));
            Assert.AreEqual(LoginFailure.None, f.Session.GetAvailability(LoginMethod.Apple));
            Assert.AreEqual(LoginFailure.None, f.Session.GetAvailability(new LoginMethod("steam")));

            f.Session.SignIn(new LoginMethod("steam"), f.Record);
            steam.Succeed("steam-sub");
            f.Account.Succeed("u", false, new LoginMethod("steam"));
            Assert.IsTrue(f.Last.Success);
            Assert.AreEqual("steam", f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void RegisteringAMethodTwiceThrows()
        {
            var f = new LoginFixture();
            Assert.Throws<InvalidOperationException>(() => f.Session.AddProvider(new FakeLoginProvider(LoginMethod.Google)));
            Assert.Throws<ArgumentException>(() => f.Session.AddProvider(new FakeLoginProvider(LoginMethod.Guest)));
            Assert.Throws<ArgumentException>(() => f.Session.AddProvider(new FakeLoginProvider(LoginMethod.None)));
            Assert.Throws<ArgumentNullException>(() => f.Session.AddProvider(null));
        }

        [Test]
        public void MissingPiecesAnswerNotConfigured()
        {
            var noAccount = new LoginFixture(withAccount: false);
            noAccount.Session.SignIn(LoginMethod.Google, noAccount.Record);
            Assert.AreEqual(LoginFailure.NotConfigured, noAccount.Last.Failure);

            var noProvider = new LoginFixture(withProviders: false);
            noProvider.Session.SignIn(LoginMethod.Google, noProvider.Record);
            Assert.AreEqual(LoginFailure.NotConfigured, noProvider.Last.Failure);
            Assert.AreEqual(LoginFailure.None, noProvider.Session.GetAvailability(LoginMethod.Guest));
            Assert.AreEqual(0, noProvider.BusyChanges.Count);
        }

        [Test]
        public void ProviderAvailabilityIsPassedOn()
        {
            var f = new LoginFixture();
            f.Apple.Availability = LoginFailure.Unsupported;
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            Assert.AreEqual(LoginFailure.Unsupported, f.Last.Failure);
            Assert.AreEqual(0, f.Apple.Requests.Count);

            f.Account.Availability = LoginFailure.NotInitialized;
            Assert.AreEqual(LoginFailure.NotInitialized, f.Session.GetAvailability(LoginMethod.Google));
            Assert.AreEqual(LoginFailure.NotInitialized, f.Session.GetAvailability(LoginMethod.Guest));
        }

        [Test]
        public void ASecondCallWhileBusyAnswersBusy()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            Assert.AreEqual(LoginFailure.Busy, f.Last.Failure);
            Assert.AreEqual(LoginFailure.Busy, f.Session.GetAvailability(LoginMethod.Guest));
            Assert.AreEqual(0, f.Apple.Requests.Count);
        }

        [Test]
        public void CredentialFailureKeepsTheProviderCode()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Fail(LoginFailure.CredentialRejected, 1004);
            Assert.AreEqual(LoginFailure.CredentialRejected, f.Last.Failure);
            Assert.AreEqual(1004, f.Last.ProviderCode);
            Assert.AreEqual("fake", f.Last.Detail);
            Assert.IsNull(f.Last.Account);
            Assert.AreEqual(0, f.Account.Calls.Count);
        }

        [Test]
        public void ARejectedLoginForgetsTheLastMethod()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Fail(LoginFailure.Cancelled);
            Assert.AreEqual(LoginFailure.Cancelled, f.Last.Failure);
            Assert.IsNull(f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void AFailedLoginOnAGuestAccountKeepsGuestAsTheLastMethod()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Google.Fail(LoginFailure.Cancelled);
            Assert.AreEqual("guest", f.State(LoginStateKeys.LastMethod("test")));
            Assert.IsTrue(f.Session.IsSignedIn);
        }

        [Test]
        public void ATemporaryFailureKeepsTheLastMethod()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Google.Succeed();
            f.Account.Fail(LoginFailure.NoConnection, 19);
            Assert.AreEqual(LoginFailure.NoConnection, f.Last.Failure);
            Assert.AreEqual(19, f.Last.ProviderCode);
            Assert.AreEqual("google", f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void CredentialTimeoutCancelsTheProvider()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Host.Advance(149f);
            Assert.AreEqual(0, f.Results.Count);
            f.Host.Advance(1f);
            Assert.AreEqual(LoginFailure.Timeout, f.Last.Failure);
            Assert.AreEqual(1, f.Google.CancelCount);

            f.Google.Succeed();
            Assert.AreEqual(1, f.Results.Count);
            Assert.AreEqual(0, f.Account.Calls.Count);
            Assert.IsFalse(f.Session.IsBusy);
        }

        [Test]
        public void AccountTimeoutCancelsTheAccountProvider()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Guest, f.Record);
            f.Host.Advance(60f);
            Assert.AreEqual(LoginFailure.Timeout, f.Last.Failure);
            Assert.AreEqual(1, f.Account.CancelCount);

            f.Account.Succeed("late", true);
            Assert.AreEqual(1, f.Results.Count);
            Assert.IsFalse(f.Session.IsSignedIn);
        }

        [Test]
        public void TimersStopWhenACallEnds()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            Assert.AreEqual(0, f.Host.ActiveTimers);
        }

        [Test]
        public void AnswersFromAnotherThreadWaitForTheMainThread()
        {
            var f = new LoginFixture();
            f.Host.Deferred = true;
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Google.Succeed();
            Assert.AreEqual(0, f.Account.Calls.Count);
            f.Host.Pump();
            f.Account.Succeed();
            Assert.AreEqual(0, f.Results.Count);
            f.Host.Pump();
            Assert.IsTrue(f.Last.Success);
        }

        [Test]
        public void ARepeatedAnswerIsIgnored()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            var answer = f.Google.Pending;
            answer(LoginCredentialResult.Succeeded(new LoginCredential(LoginMethod.Google, "a", "t")));
            answer(LoginCredentialResult.Failed(LoginFailure.Cancelled));
            Assert.AreEqual(1, f.Account.Calls.Count);
            Assert.AreEqual(0, f.Results.Count);
        }

        [Test]
        public void ACredentialForAnotherMethodIsRejected()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Google.Pending(LoginCredentialResult.Succeeded(new LoginCredential(LoginMethod.Apple, "a", "t")));
            Assert.AreEqual(LoginFailure.CredentialRejected, f.Last.Failure);
        }

        [Test]
        public void AProviderThatThrowsAnswersProviderError()
        {
            var f = new LoginFixture();
            f.Google.ThrowOnRequest = true;
            f.Session.SignIn(LoginMethod.Google, f.Record);
            Assert.AreEqual(LoginFailure.ProviderError, f.Last.Failure);
            Assert.AreEqual(1, f.Host.Exceptions.Count);
            Assert.IsFalse(f.Session.IsBusy);
        }

        [Test]
        public void ACallbackThatThrowsIsLogged()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Guest, _ => throw new InvalidOperationException("game bug"));
            f.Account.Succeed("g", true);
            Assert.AreEqual(1, f.Host.Exceptions.Count);
            Assert.IsTrue(f.Session.IsSignedIn);
        }

        [Test]
        public void TheSavedSubjectIsPassedToTheProvider()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Succeed("apple-user");
            f.Account.Succeed("u", false, LoginMethod.Apple);

            f.Session.SignIn(LoginMethod.Apple, f.Record);
            Assert.AreEqual("apple-user", f.Apple.LastRequest.SavedSubject);
            Assert.IsNull(f.Google.LastRequest);
        }

        [Test]
        public void AnInvalidSavedSubjectIsForgotten()
        {
            var f = new LoginFixture();
            f.Store.Set(LoginStateKeys.Subject("test", LoginMethod.Apple), "old-user");
            f.Session.SignIn(LoginMethod.Apple, f.Record);
            f.Apple.Pending(LoginCredentialResult.Succeeded(new LoginCredential(LoginMethod.Apple, "", "t"), savedSubjectInvalid: true));
            Assert.IsNull(f.State(LoginStateKeys.Subject("test", LoginMethod.Apple)));
        }

        [Test]
        public void AnInvalidAccountIsSignedOut()
        {
            var f = new LoginFixture();
            f.SignInWithGoogle();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Google.Succeed();
            f.Account.Fail(LoginFailure.AccountInvalid, 14);

            Assert.AreEqual(LoginFailure.AccountInvalid, f.Last.Failure);
            Assert.AreEqual(1, f.Account.SignOutCount);
            Assert.IsFalse(f.Session.IsSignedIn);
            Assert.IsNull(f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void AGuestAccountIsNeverSignedOutAutomatically()
        {
            var f = new LoginFixture();
            f.SignInAsGuest();
            f.Session.SignIn(LoginMethod.Guest, f.Record);
            f.Account.Fail(LoginFailure.AccountInvalid, 14);

            Assert.AreEqual(LoginFailure.AccountInvalid, f.Last.Failure);
            Assert.AreEqual(0, f.Account.SignOutCount);
            Assert.AreEqual("guest", f.State(LoginStateKeys.LastMethod("test")));
        }

        [Test]
        public void CancelEndsTheCallAndCancelsTheProvider()
        {
            var f = new LoginFixture();
            f.Session.SignIn(LoginMethod.Google, f.Record);
            f.Session.Cancel();
            Assert.AreEqual(LoginFailure.Cancelled, f.Last.Failure);
            Assert.AreEqual(1, f.Google.CancelCount);
            Assert.IsFalse(f.Session.IsBusy);

            f.Session.SignIn(LoginMethod.Guest, f.Record);
            f.Session.Cancel();
            Assert.AreEqual(1, f.Account.CancelCount);
        }
    }
}
