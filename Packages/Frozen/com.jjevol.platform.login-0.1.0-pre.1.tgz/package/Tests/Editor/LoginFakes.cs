using System;
using System.Collections.Generic;

namespace PlatformLibrary.Login.Tests
{
    internal sealed class FakeHost : ILoginHost
    {
        private sealed class Timer
        {
            public float Due;
            public Action Action;
            public bool Cancelled;
        }

        private readonly List<Timer> _timers = new List<Timer>();
        private readonly Queue<Action> _queue = new Queue<Action>();
        private float _now;

        /// <summary>When true, Post queues work as if it came from another thread, until <see cref="Pump"/>.</summary>
        public bool Deferred;

        public readonly List<string> Warnings = new List<string>();
        public readonly List<Exception> Exceptions = new List<Exception>();

        public void Post(Action action)
        {
            if (Deferred) _queue.Enqueue(action);
            else action();
        }

        public Action Schedule(float seconds, Action action)
        {
            var timer = new Timer { Due = _now + seconds, Action = action };
            _timers.Add(timer);
            return () => timer.Cancelled = true;
        }

        public void LogWarning(string message) => Warnings.Add(message);
        public void LogException(Exception exception) => Exceptions.Add(exception);

        public void Pump()
        {
            while (_queue.Count > 0) _queue.Dequeue()();
        }

        public void Advance(float seconds)
        {
            _now += seconds;
            foreach (Timer timer in _timers.ToArray())
            {
                if (timer.Cancelled || timer.Due > _now) continue;
                timer.Cancelled = true;
                timer.Action();
            }
        }

        public int ActiveTimers
        {
            get
            {
                int count = 0;
                foreach (Timer timer in _timers) if (!timer.Cancelled) count++;
                return count;
            }
        }
    }

    internal sealed class FakeStore : ILoginStateStore
    {
        public readonly Dictionary<string, string> Values = new Dictionary<string, string>();

        public string Get(string key) => Values.TryGetValue(key, out string value) ? value : null;
        public void Set(string key, string value) => Values[key] = value;
        public void Delete(string key) => Values.Remove(key);
    }

    internal sealed class FakeLoginProvider : ILoginProvider
    {
        public FakeLoginProvider(LoginMethod method) { Method = method; }

        public LoginMethod Method { get; }
        public LoginFailure Availability { get; set; }
        public event Action CredentialRevoked;

        public readonly List<LoginCredentialRequest> Requests = new List<LoginCredentialRequest>();
        public Action<LoginCredentialResult> Pending;
        public int CancelCount;
        public bool ThrowOnRequest;

        public LoginCredentialRequest LastRequest => Requests.Count == 0 ? null : Requests[Requests.Count - 1];

        public void RequestCredential(LoginCredentialRequest request, Action<LoginCredentialResult> callback)
        {
            if (ThrowOnRequest) throw new InvalidOperationException("provider failure");
            Requests.Add(request);
            Pending = callback;
        }

        public void Cancel() => CancelCount++;

        public void Succeed(string subject = "subject-1", string token = "platform-token")
        {
            Pending(LoginCredentialResult.Succeeded(new LoginCredential(Method, subject, token)));
        }

        public void Fail(LoginFailure failure, int code = 0, bool savedSubjectInvalid = false)
        {
            Pending(LoginCredentialResult.Failed(failure, code, "fake", savedSubjectInvalid));
        }

        public void Revoke() => CredentialRevoked?.Invoke();
    }

    internal sealed class FakeAccountProvider : IAccountProvider, IDisposable
    {
        public FakeAccountProvider(string environmentKey = "test") { EnvironmentKey = environmentKey; }

        public string EnvironmentKey { get; }
        public LoginFailure Availability { get; set; }
        public LoginAccount Current { get; set; }

        public readonly List<string> Calls = new List<string>();
        public LoginCredential LastCredential;
        public LoginMethod LastMethod;
        public string LastConflict;
        public readonly List<string> Discarded = new List<string>();
        public Action<AccountResult> Pending;
        public Action<LoginToken> PendingToken;
        public bool LastForceRefresh;
        public int CancelCount;
        public int SignOutCount;
        public bool Disposed;

        public void SignInGuest(Action<AccountResult> callback) { Calls.Add("guest"); Pending = callback; }
        public void Restore(LoginMethod method, Action<AccountResult> callback) { Calls.Add("restore:" + method.Id); LastMethod = method; Pending = callback; }
        public void SignIn(LoginCredential credential, Action<AccountResult> callback) { Calls.Add("signin:" + credential.Method.Id); LastCredential = credential; Pending = callback; }
        public void Link(LoginCredential credential, Action<AccountResult> callback) { Calls.Add("link:" + credential.Method.Id); LastCredential = credential; Pending = callback; }
        public void SwitchToLinkedAccount(string conflict, Action<AccountResult> callback) { Calls.Add("switch"); LastConflict = conflict; Pending = callback; }
        public void DiscardConflict(string conflict) => Discarded.Add(conflict);
        public void Unlink(LoginMethod method, Action<AccountResult> callback) { Calls.Add("unlink:" + method.Id); LastMethod = method; Pending = callback; }
        public void GetToken(bool forceRefresh, Action<LoginToken> callback) { Calls.Add("token"); LastForceRefresh = forceRefresh; PendingToken = callback; }
        public void Cancel() => CancelCount++;
        public void SignOut() { SignOutCount++; Current = null; }
        public void Dispose() => Disposed = true;

        /// <summary>Answers the pending call with an account and makes it current.</summary>
        public LoginAccount Succeed(string userId = "user-1", bool guest = false, params LoginMethod[] linked)
        {
            var account = new LoginAccount(userId, guest, null, linked);
            Current = account;
            Pending(AccountResult.Succeeded(account));
            return account;
        }

        public void Fail(LoginFailure failure, int code = 0) => Pending(AccountResult.Failed(failure, code, "fake"));
    }

    /// <summary>A session over fakes, with everything a test reads.</summary>
    internal sealed class LoginFixture
    {
        public readonly FakeHost Host = new FakeHost();
        public readonly FakeStore Store = new FakeStore();
        public readonly FakeAccountProvider Account = new FakeAccountProvider();
        public readonly FakeLoginProvider Google = new FakeLoginProvider(LoginMethod.Google);
        public readonly FakeLoginProvider Apple = new FakeLoginProvider(LoginMethod.Apple);
        public readonly List<LoginAccount> AccountChanges = new List<LoginAccount>();
        public readonly List<bool> BusyChanges = new List<bool>();
        public readonly List<LoginMethod> Revoked = new List<LoginMethod>();
        public readonly List<LoginResult> Results = new List<LoginResult>();
        public readonly LoginSession Session;

        public LoginFixture(bool withAccount = true, bool withProviders = true)
        {
            Session = new LoginSession(Host, Store, AccountChanges.Add, BusyChanges.Add, Revoked.Add, 150f, 60f);
            if (withProviders)
            {
                Session.AddProvider(Google);
                Session.AddProvider(Apple);
            }
            if (withAccount) Session.SetAccountProvider(Account);
        }

        public Action<LoginResult> Record => Results.Add;

        public LoginResult Last => Results[Results.Count - 1];

        public string State(string key) => Store.Get(key);

        public LoginAccount SignInWithGoogle(string userId = "user-1", string subject = "google-sub")
        {
            Session.SignIn(LoginMethod.Google, Record);
            Google.Succeed(subject);
            return Account.Succeed(userId, false, LoginMethod.Google);
        }

        public LoginAccount SignInAsGuest(string userId = "guest-1")
        {
            Session.SignIn(LoginMethod.Guest, Record);
            return Account.Succeed(userId, true);
        }
    }
}
