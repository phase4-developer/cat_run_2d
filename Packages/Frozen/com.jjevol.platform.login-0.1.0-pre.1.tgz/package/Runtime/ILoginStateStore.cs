namespace PlatformLibrary.Login
{
    /// <summary>
    /// Where the manager keeps the last login method, the login history and platform user IDs.
    /// The default is <see cref="PlayerPrefsLoginStateStore"/>. Nothing secret is stored.
    /// </summary>
    public interface ILoginStateStore
    {
        /// <summary>The stored value, or null.</summary>
        string Get(string key);

        void Set(string key, string value);
        void Delete(string key);
    }

    /// <summary>The keys the manager uses. <c>{env}</c> is the account provider's environment.</summary>
    public static class LoginStateKeys
    {
        public const string Prefix = "jjevol.login.";

        /// <summary>The last login method ID.</summary>
        public static string LastMethod(string environment) => Prefix + environment + ".lastMethod";

        /// <summary>"1" once any login has worked.</summary>
        public static string History(string environment) => Prefix + environment + ".history";

        /// <summary>The platform user ID from the last login with the method.</summary>
        public static string Subject(string environment, LoginMethod method) => Prefix + environment + ".subject." + method.Id;
    }
}
