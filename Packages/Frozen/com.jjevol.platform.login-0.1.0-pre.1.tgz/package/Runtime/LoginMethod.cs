using System;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// A way to sign in, such as Google or Apple. It is a value with a text ID, not an enum,
    /// so a project or a later provider package can add one without changing this package:
    /// <c>new LoginMethod("steam")</c>.
    /// </summary>
    public readonly struct LoginMethod : IEquatable<LoginMethod>
    {
        public static readonly LoginMethod None = default;
        public static readonly LoginMethod Guest = new LoginMethod("guest");
        public static readonly LoginMethod Google = new LoginMethod("google");
        public static readonly LoginMethod Apple = new LoginMethod("apple");

        private readonly string _id;

        /// <param name="id">Lower case letters, digits and <c>. _ - :</c>, at most 64 characters.</param>
        public LoginMethod(string id)
        {
            if (!IsValidId(id)) throw new ArgumentException("A login method ID uses lower case letters, digits and . _ - : only, at most 64 characters.", nameof(id));
            _id = id;
        }

        public string Id => _id ?? string.Empty;
        public bool IsNone => string.IsNullOrEmpty(_id);

        public static bool IsValidId(string id)
        {
            if (string.IsNullOrEmpty(id) || id.Length > 64) return false;
            foreach (char c in id)
            {
                bool valid = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-' || c == ':';
                if (!valid) return false;
            }
            return true;
        }

        /// <summary>Reads a stored ID. An empty or invalid ID gives <see cref="None"/>.</summary>
        public static LoginMethod Parse(string id) => IsValidId(id) ? new LoginMethod(id) : None;

        public bool Equals(LoginMethod other) => string.Equals(Id, other.Id, StringComparison.Ordinal);
        public override bool Equals(object obj) => obj is LoginMethod other && Equals(other);
        public override int GetHashCode() => StringComparer.Ordinal.GetHashCode(Id);
        public override string ToString() => IsNone ? "none" : Id;

        public static bool operator ==(LoginMethod left, LoginMethod right) => left.Equals(right);
        public static bool operator !=(LoginMethod left, LoginMethod right) => !left.Equals(right);
    }
}
