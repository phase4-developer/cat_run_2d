namespace PlatformLibrary.Login
{
    /// <summary>Why a login call did not work. The only value a game branches on.</summary>
    public enum LoginFailure
    {
        None,

        /// <summary>No provider is registered for the method, no account provider is set, or a required setting such as a client ID is empty.</summary>
        NotConfigured,

        /// <summary>The method cannot be used on this platform or device.</summary>
        Unsupported,

        /// <summary>The account provider is not ready yet.</summary>
        NotInitialized,

        /// <summary>Another login call is running.</summary>
        Busy,

        /// <summary>The player cancelled, the game called <c>Cancel</c>, or the call was replaced.</summary>
        Cancelled,

        /// <summary>The provider did not answer in time.</summary>
        Timeout,

        /// <summary>No connection, or the connection failed. Same name as <c>NetworkFailure.NoConnection</c>.</summary>
        NoConnection,

        /// <summary>No saved session or usable account for a login without a prompt, or no Google account on the device.</summary>
        NoSavedLogin,

        /// <summary>The credential was missing, malformed or refused by the account provider.</summary>
        CredentialRejected,

        /// <summary>The player withdrew the app's permission, for example by stopping Sign in with Apple for it.</summary>
        CredentialRevoked,

        /// <summary>Link, unlink or token calls need a signed-in account.</summary>
        NotSignedIn,

        /// <summary>The method is already linked to a different account. <c>SwitchToLinkedAccount</c> or <c>DiscardLinkConflict</c> decides.</summary>
        AlreadyLinkedToOtherAccount,

        /// <summary>The account was deleted or disabled on the server.</summary>
        AccountInvalid,

        /// <summary>The account changed while the call was running, so its result was dropped.</summary>
        SessionChanged,

        /// <summary>Any other provider error. See <c>ProviderCode</c> and <c>Detail</c> in logs.</summary>
        ProviderError
    }
}
