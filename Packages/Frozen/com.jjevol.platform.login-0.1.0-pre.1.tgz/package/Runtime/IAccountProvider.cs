using System;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// The game account system, such as Firebase Auth. One is set at a time.
    /// The manager calls it on the main thread, one call at a time except <see cref="GetToken"/>.
    /// It may answer from any thread, once per call.
    /// </summary>
    public interface IAccountProvider
    {
        /// <summary>Separates saved login state. The same key as <c>NetworkManager.EnvironmentKey</c>, for example "live" or "stage".</summary>
        string EnvironmentKey { get; }

        /// <summary><see cref="LoginFailure.None"/> when usable, usually <see cref="LoginFailure.NotInitialized"/> otherwise.</summary>
        LoginFailure Availability { get; }

        /// <summary>The session the provider holds now, including one cached from a previous run. Null when none.</summary>
        LoginAccount Current { get; }

        /// <summary>Uses the current guest account when there is one, and creates one otherwise. Never signs into a social account.</summary>
        void SignInGuest(Action<AccountResult> callback);

        /// <summary>
        /// Uses the cached session when it belongs to <paramref name="method"/>.
        /// Answers <see cref="LoginFailure.NoSavedLogin"/> when there is none and never creates an account.
        /// </summary>
        void Restore(LoginMethod method, Action<AccountResult> callback);

        void SignIn(LoginCredential credential, Action<AccountResult> callback);

        /// <summary>Links to the current account. A credential owned by another account answers <see cref="AccountResult.LinkConflict"/>.</summary>
        void Link(LoginCredential credential, Action<AccountResult> callback);

        /// <summary>Signs into the account that owns the credential of a link conflict.</summary>
        void SwitchToLinkedAccount(string conflict, Action<AccountResult> callback);

        void DiscardConflict(string conflict);

        void Unlink(LoginMethod method, Action<AccountResult> callback);

        void GetToken(bool forceRefresh, Action<LoginToken> callback);

        /// <summary>
        /// Stops the running call if it can. A call that cannot be stopped should still answer: the manager does not report
        /// a late answer to the game, but follows the session it left, or signs it out again after <see cref="SignOut"/>.
        /// </summary>
        void Cancel();

        void SignOut();
    }
}
