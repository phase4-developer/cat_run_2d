using System;
using System.Collections.Generic;
using System.Threading;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// The login flow behind <see cref="LoginManager"/>. One call at a time. Every answer is checked against
    /// the call, the stage and the account provider it started with, so a late or repeated answer is ignored.
    /// </summary>
    internal sealed class LoginSession
    {
        internal const float DefaultCredentialTimeoutSeconds = 150f;
        internal const float DefaultAccountTimeoutSeconds = 60f;

        private enum Kind { SignIn, Restore, Link, Switch, Unlink }

        private sealed class Operation
        {
            public Kind Kind;
            public LoginMethod Method;
            public Action<LoginResult> Callback;
            public int Stage;
            public Action CancelTimeout;
            public ILoginProvider ActiveProvider;
            public IAccountProvider ActiveAccount;
            public IAccountProvider Owner;
            public string TargetUserId;
            public string EndDetail;
        }

        private readonly ILoginHost _host;
        private readonly float _credentialTimeoutSeconds;
        private readonly float _accountTimeoutSeconds;
        private readonly Dictionary<LoginMethod, ILoginProvider> _providers = new Dictionary<LoginMethod, ILoginProvider>();
        private readonly Dictionary<LoginMethod, Action> _revokedHandlers = new Dictionary<LoginMethod, Action>();
        private readonly Action<LoginAccount> _accountChanged;
        private readonly Action<bool> _busyChanged;
        private readonly Action<LoginMethod> _credentialRevoked;

        private ILoginStateStore _store;
        private IAccountProvider _account;
        private LoginAccount _current;
        private Operation _operation;
        private int _requestCounter;

        private string _conflict;
        private LoginMethod _conflictMethod;
        private string _conflictSubject;
        private IAccountProvider _conflictOwner;

        public LoginSession(ILoginHost host, ILoginStateStore store, Action<LoginAccount> accountChanged, Action<bool> busyChanged, Action<LoginMethod> credentialRevoked,
            float credentialTimeoutSeconds = DefaultCredentialTimeoutSeconds, float accountTimeoutSeconds = DefaultAccountTimeoutSeconds)
        {
            _host = host ?? throw new ArgumentNullException(nameof(host));
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _accountChanged = accountChanged;
            _busyChanged = busyChanged;
            _credentialRevoked = credentialRevoked;
            _credentialTimeoutSeconds = credentialTimeoutSeconds;
            _accountTimeoutSeconds = accountTimeoutSeconds;
        }

        public IAccountProvider AccountProvider => _account;
        public LoginAccount Account => _current;
        public bool IsSignedIn => _current != null;
        public bool IsBusy => _operation != null;
        public bool HasLinkConflict => _conflict != null && ReferenceEquals(_conflictOwner, _account);

        private string EnvironmentKey
        {
            get
            {
                string environment = _account?.EnvironmentKey;
                return string.IsNullOrEmpty(environment) ? null : environment;
            }
        }

        public LoginMethod LastMethod
        {
            get
            {
                string environment = EnvironmentKey;
                return environment == null ? LoginMethod.None : LoginMethod.Parse(ReadState(LoginStateKeys.LastMethod(environment)));
            }
        }

        public bool HasLoginHistory
        {
            get
            {
                string environment = EnvironmentKey;
                return environment != null && ReadState(LoginStateKeys.History(environment)) == "1";
            }
        }

        // ---- Setup ----

        public void SetStore(ILoginStateStore store)
        {
            _store = store ?? throw new ArgumentNullException(nameof(store));
        }

        public void AddProvider(ILoginProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            LoginMethod method = provider.Method;
            if (method.IsNone) throw new ArgumentException("The provider has no login method.", nameof(provider));
            if (method == LoginMethod.Guest) throw new ArgumentException("Guest login belongs to the account provider.", nameof(provider));
            if (_providers.ContainsKey(method)) throw new InvalidOperationException("A provider is already registered for " + method + ".");
            Action handler = () => _host.Post(() => OnCredentialRevoked(provider, method));
            _providers.Add(method, provider);
            _revokedHandlers.Add(method, handler);
            provider.CredentialRevoked += handler;
        }

        public bool HasProvider(LoginMethod method) => _providers.ContainsKey(method);

        public void SetAccountProvider(IAccountProvider provider)
        {
            if (ReferenceEquals(_account, provider)) return;
            EndOperation(LoginFailure.SessionChanged, "account_provider_changed");
            DiscardLinkConflict();
            IAccountProvider previous = _account;
            _account = provider;
            SetCurrent(null);
            if (previous is IDisposable disposable)
            {
                try { disposable.Dispose(); }
                catch (Exception exception) { _host.LogException(exception); }
            }
        }

        public void Clear()
        {
            EndOperation(LoginFailure.Cancelled, "cleared");
            foreach (KeyValuePair<LoginMethod, ILoginProvider> pair in _providers)
                pair.Value.CredentialRevoked -= _revokedHandlers[pair.Key];
            _providers.Clear();
            _revokedHandlers.Clear();
            SetAccountProvider(null);
        }

        // ---- Availability ----

        public LoginFailure GetAvailability(LoginMethod method)
        {
            if (method.IsNone || _account == null) return LoginFailure.NotConfigured;
            LoginFailure account = Availability(_account);
            if (account != LoginFailure.None) return account;
            if (_operation != null) return LoginFailure.Busy;
            if (method == LoginMethod.Guest) return LoginFailure.None;
            return _providers.TryGetValue(method, out ILoginProvider provider) ? Availability(provider) : LoginFailure.NotConfigured;
        }

        public LoginFailure GetLinkAvailability(LoginMethod method)
        {
            if (method == LoginMethod.Guest) return LoginFailure.Unsupported;
            LoginFailure failure = GetAvailability(method);
            if (failure != LoginFailure.None) return failure;
            return _current == null ? LoginFailure.NotSignedIn : LoginFailure.None;
        }

        public bool IsLinked(LoginMethod method) => _current != null && _current.IsLinked(method);

        // ---- Calls ----

        public void SignIn(LoginMethod method, Action<LoginResult> callback)
        {
            LoginFailure failure = GetAvailability(method);
            if (failure != LoginFailure.None)
            {
                Reply(callback, LoginResult.Failed(failure, method));
                return;
            }

            Operation operation = Begin(Kind.SignIn, method, callback);
            if (method == LoginMethod.Guest)
            {
                CallAccount(operation, (account, done) => account.SignInGuest(done), result => CompleteSignIn(operation, result, null));
                return;
            }

            RequestCredential(operation, LoginPrompt.Allowed, credential =>
                CallAccount(operation, (account, done) => account.SignIn(credential, done), result => CompleteSignIn(operation, result, credential.Subject)));
        }

        public void RestoreSession(Action<LoginResult> callback)
        {
            LoginMethod method = LastMethod;
            if (_account == null)
            {
                Reply(callback, LoginResult.Failed(LoginFailure.NotConfigured, method));
                return;
            }
            if (method.IsNone)
            {
                Reply(callback, LoginResult.Failed(LoginFailure.NoSavedLogin, method, 0, "no_last_method"));
                return;
            }

            LoginFailure failure = GetAvailability(method);
            if (failure != LoginFailure.None)
            {
                Reply(callback, LoginResult.Failed(failure, method));
                return;
            }

            Operation operation = Begin(Kind.Restore, method, callback);
            CallAccount(operation, (account, done) => account.Restore(method, done), result =>
            {
                if (result.Success)
                {
                    CompleteSignIn(operation, result, null);
                    return;
                }

                // Only a missing session falls back to the platform. Any other failure, such as no connection,
                // is the answer: a silent request would hide it and its NoSavedLogin would forget the last method.
                bool fallBack = method != LoginMethod.Guest && result.Failure == LoginFailure.NoSavedLogin;
                if (!fallBack)
                {
                    Fail(operation, result.Failure, result.ProviderCode, result.Detail);
                    return;
                }

                RequestCredential(operation, LoginPrompt.Silent, credential =>
                    CallAccount(operation, (account, done) => account.SignIn(credential, done), signIn => CompleteSignIn(operation, signIn, credential.Subject)));
            });
        }

        public void Link(LoginMethod method, Action<LoginResult> callback)
        {
            LoginFailure failure = GetLinkAvailability(method);
            if (failure != LoginFailure.None)
            {
                Reply(callback, LoginResult.Failed(failure, method));
                return;
            }
            if (_current.IsLinked(method))
            {
                Reply(callback, LoginResult.Succeeded(method, _current, "already_linked"));
                return;
            }

            DiscardLinkConflict();
            Operation operation = Begin(Kind.Link, method, callback);
            operation.TargetUserId = _current.UserId;
            RequestCredential(operation, LoginPrompt.Required, credential =>
            {
                if (!SameUser(_account, operation.TargetUserId))
                {
                    Fail(operation, LoginFailure.SessionChanged, 0, "session_changed_before_link");
                    return;
                }

                CallAccount(operation, (account, done) => account.Link(credential, done), result => CompleteLink(operation, result, credential.Subject));
            });
        }

        public void SwitchToLinkedAccount(Action<LoginResult> callback)
        {
            if (!HasLinkConflict)
            {
                Reply(callback, LoginResult.Failed(LoginFailure.NoSavedLogin, _conflictMethod, 0, "no_link_conflict"));
                return;
            }

            LoginMethod method = _conflictMethod;
            LoginFailure failure = _account == null ? LoginFailure.NotConfigured : Availability(_account);
            if (failure == LoginFailure.None && _operation != null) failure = LoginFailure.Busy;
            if (failure != LoginFailure.None)
            {
                Reply(callback, LoginResult.Failed(failure, method));
                return;
            }

            string conflict = _conflict;
            string subject = _conflictSubject;
            ForgetConflict();
            Operation operation = Begin(Kind.Switch, method, callback);
            CallAccount(operation, (account, done) => account.SwitchToLinkedAccount(conflict, done), result => CompleteSignIn(operation, result, subject));
        }

        public void DiscardLinkConflict()
        {
            if (_conflict == null) return;
            string conflict = _conflict;
            IAccountProvider owner = _conflictOwner;
            ForgetConflict();
            try { owner?.DiscardConflict(conflict); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        public void Unlink(LoginMethod method, Action<LoginResult> callback)
        {
            LoginFailure failure = GetLinkAvailability(method);
            if (failure != LoginFailure.None)
            {
                Reply(callback, LoginResult.Failed(failure, method));
                return;
            }
            if (!_current.IsLinked(method))
            {
                Reply(callback, LoginResult.Succeeded(method, _current, "not_linked"));
                return;
            }
            if (_current.LinkedMethods.Count <= 1)
            {
                // Unlinking the only method would leave an account nobody can sign into again.
                Reply(callback, LoginResult.Failed(LoginFailure.Unsupported, method, 0, "last_linked_method"));
                return;
            }

            Operation operation = Begin(Kind.Unlink, method, callback);
            operation.TargetUserId = _current.UserId;
            CallAccount(operation, (account, done) => account.Unlink(method, done), result =>
            {
                if (!result.Success)
                {
                    Fail(operation, result.Failure, result.ProviderCode, result.Detail);
                    return;
                }
                if (result.Account.UserId != operation.TargetUserId)
                {
                    Fail(operation, LoginFailure.SessionChanged, 0, "session_changed_after_unlink");
                    return;
                }

                string environment = EnvironmentKey;
                LoginMethod sessionMethod = _current != null && _current.Method != method ? _current.Method : FirstLinked(result.Account);
                if (environment != null)
                {
                    DeleteState(LoginStateKeys.Subject(environment, method));
                    if (LastMethod == method) WriteMethod(environment, sessionMethod);
                }

                LoginAccount account = result.Account.WithMethod(sessionMethod);
                SetCurrent(account);
                Finish(operation, LoginResult.Succeeded(method, account, result.Detail));
            });
        }

        public void GetToken(bool forceRefresh, Action<LoginToken> callback)
        {
            if (_account == null)
            {
                ReplyToken(callback, LoginToken.Failed(LoginFailure.NotConfigured));
                return;
            }
            if (_current == null)
            {
                ReplyToken(callback, LoginToken.Failed(LoginFailure.NotSignedIn));
                return;
            }

            IAccountProvider owner = _account;
            string userId = _current.UserId;
            if (ProviderUserId(owner) != userId)
            {
                // The provider holds another session, for example after a call that finished late. Its token is not this account's.
                FollowProvider(owner, LoginMethod.None);
                ReplyToken(callback, LoginToken.Failed(LoginFailure.SessionChanged, 0, "session_changed"));
                return;
            }

            int answered = 0;
            Action cancelTimeout = null;
            Action<LoginToken> answer = token =>
            {
                if (Interlocked.Exchange(ref answered, 1) != 0) return;
                cancelTimeout?.Invoke();
                if (!ReferenceEquals(owner, _account) || _current == null || _current.UserId != userId || ProviderUserId(owner) != userId)
                    token = LoginToken.Failed(LoginFailure.SessionChanged, 0, "session_changed");
                ReplyToken(callback, token);
            };

            cancelTimeout = _host.Schedule(_accountTimeoutSeconds, () => answer(LoginToken.Failed(LoginFailure.Timeout)));
            try
            {
                owner.GetToken(forceRefresh, token => _host.Post(() => answer(token)));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                answer(LoginToken.Failed(LoginFailure.ProviderError, 0, exception.GetType().Name));
            }
        }

        public void SignOut(bool keepLastMethod)
        {
            EndOperation(LoginFailure.Cancelled, "signed_out");
            DiscardLinkConflict();
            string environment = EnvironmentKey;
            if (environment != null && !keepLastMethod)
            {
                DeleteState(LoginStateKeys.LastMethod(environment));
                foreach (LoginMethod method in _providers.Keys)
                    DeleteState(LoginStateKeys.Subject(environment, method));
            }

            try { _account?.SignOut(); }
            catch (Exception exception) { _host.LogException(exception); }
            SetCurrent(null);
        }

        public void Cancel() => EndOperation(LoginFailure.Cancelled, "cancelled");

        // ---- Flow ----

        private Operation Begin(Kind kind, LoginMethod method, Action<LoginResult> callback)
        {
            var operation = new Operation { Kind = kind, Method = method, Callback = callback, Owner = _account };
            _operation = operation;
            RaiseBusy(true);
            return operation;
        }

        private void RequestCredential(Operation operation, LoginPrompt prompt, Action<LoginCredential> next)
        {
            if (!_providers.TryGetValue(operation.Method, out ILoginProvider provider))
            {
                Fail(operation, LoginFailure.NotConfigured, 0, "no_provider");
                return;
            }

            int stage = ++operation.Stage;
            operation.ActiveProvider = provider;
            operation.ActiveAccount = null;
            operation.CancelTimeout = _host.Schedule(_credentialTimeoutSeconds, () =>
            {
                if (!IsCurrent(operation, stage)) return;
                CancelQuietly(provider);
                Fail(operation, LoginFailure.Timeout, 0, "credential_timeout");
            });

            string environment = EnvironmentKey;
            string subject = environment == null ? null : ReadState(LoginStateKeys.Subject(environment, operation.Method));
            var request = new LoginCredentialRequest("login-" + (++_requestCounter).ToString(System.Globalization.CultureInfo.InvariantCulture), prompt, subject);
            int answered = 0;
            try
            {
                provider.RequestCredential(request, result =>
                {
                    if (Interlocked.Exchange(ref answered, 1) != 0) return;
                    _host.Post(() => OnCredential(operation, stage, provider, result, next));
                });
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                if (IsCurrent(operation, stage)) Fail(operation, LoginFailure.ProviderError, 0, exception.GetType().Name);
            }
        }

        private void OnCredential(Operation operation, int stage, ILoginProvider provider, LoginCredentialResult result, Action<LoginCredential> next)
        {
            if (!IsCurrent(operation, stage)) return;
            ClearStage(operation);
            if (!ReferenceEquals(operation.Owner, _account))
            {
                Fail(operation, LoginFailure.SessionChanged, 0, "account_provider_changed");
                return;
            }

            if (result == null)
            {
                Fail(operation, LoginFailure.ProviderError, 0, "no_result");
                return;
            }

            string environment = EnvironmentKey;
            if (environment != null && (result.SavedSubjectInvalid || result.Failure == LoginFailure.CredentialRevoked))
                DeleteState(LoginStateKeys.Subject(environment, operation.Method));

            if (!result.Success || result.Credential == null)
            {
                Fail(operation, result.Success ? LoginFailure.ProviderError : result.Failure, result.ProviderCode, result.Detail);
                return;
            }
            if (result.Credential.Method != operation.Method)
            {
                Fail(operation, LoginFailure.CredentialRejected, 0, "method_mismatch");
                return;
            }

            next(result.Credential);
        }

        private void CallAccount(Operation operation, Action<IAccountProvider, Action<AccountResult>> call, Action<AccountResult> next)
        {
            IAccountProvider account = _account;
            if (account == null || !ReferenceEquals(account, operation.Owner))
            {
                Fail(operation, LoginFailure.SessionChanged, 0, "account_provider_changed");
                return;
            }

            int stage = ++operation.Stage;
            operation.ActiveProvider = null;
            operation.ActiveAccount = account;
            operation.CancelTimeout = _host.Schedule(_accountTimeoutSeconds, () =>
            {
                if (!IsCurrent(operation, stage)) return;
                CancelQuietly(account);
                Fail(operation, LoginFailure.Timeout, 0, "account_timeout");
            });

            int answered = 0;
            try
            {
                call(account, result =>
                {
                    if (Interlocked.Exchange(ref answered, 1) != 0) return;
                    _host.Post(() =>
                    {
                        if (!IsCurrent(operation, stage))
                        {
                            OnLateAnswer(operation, account, result);
                            return;
                        }
                        ClearStage(operation);
                        if (!ReferenceEquals(account, _account))
                        {
                            Fail(operation, LoginFailure.SessionChanged, 0, "account_provider_changed");
                            return;
                        }
                        next(result ?? AccountResult.Failed(LoginFailure.ProviderError, 0, "no_result"));
                    });
                });
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                if (IsCurrent(operation, stage)) Fail(operation, LoginFailure.ProviderError, 0, exception.GetType().Name);
            }
        }

        private void CompleteSignIn(Operation operation, AccountResult result, string subject)
        {
            if (!result.Success || result.Account == null)
            {
                Fail(operation, result.Success ? LoginFailure.ProviderError : result.Failure, result.ProviderCode, result.Detail);
                return;
            }

            LoginMethod method = result.Account.IsGuest ? LoginMethod.Guest : operation.Method;
            LoginAccount account = result.Account.WithMethod(method);
            Remember(method, subject);
            SetCurrent(account);
            Finish(operation, LoginResult.Succeeded(method, account, result.Detail));
        }

        private void CompleteLink(Operation operation, AccountResult result, string subject)
        {
            if (result.Failure == LoginFailure.AlreadyLinkedToOtherAccount && !string.IsNullOrEmpty(result.Conflict))
            {
                _conflict = result.Conflict;
                _conflictMethod = operation.Method;
                _conflictSubject = subject;
                _conflictOwner = _account;
                Finish(operation, LoginResult.Failed(LoginFailure.AlreadyLinkedToOtherAccount, operation.Method, result.ProviderCode, result.Detail));
                return;
            }
            if (!result.Success || result.Account == null)
            {
                Fail(operation, result.Success ? LoginFailure.ProviderError : result.Failure, result.ProviderCode, result.Detail);
                return;
            }
            if (result.Account.UserId != operation.TargetUserId)
            {
                Fail(operation, LoginFailure.SessionChanged, 0, "session_changed_after_link");
                return;
            }

            LoginAccount account = result.Account.WithMethod(operation.Method);
            Remember(operation.Method, subject);
            SetCurrent(account);
            Finish(operation, LoginResult.Succeeded(operation.Method, account, result.Detail));
        }

        private void Fail(Operation operation, LoginFailure failure, int providerCode, string detail)
        {
            if (!ReferenceEquals(_operation, operation)) return;
            if (failure == LoginFailure.None) failure = LoginFailure.ProviderError;
            string environment = EnvironmentKey;

            if (failure == LoginFailure.AccountInvalid && ReferenceEquals(operation.Owner, _account))
            {
                // A guest account cannot be recovered once signed out, so it is never signed out automatically.
                bool guest = (_account?.Current?.IsGuest ?? false) || (_current?.IsGuest ?? false);
                if (!guest)
                {
                    try { _account?.SignOut(); }
                    catch (Exception exception) { _host.LogException(exception); }
                    SetCurrent(null);
                }
                if (environment != null) WriteMethod(environment, guest ? LoginMethod.Guest : LoginMethod.None);
            }
            else if (environment != null && (operation.Kind == Kind.SignIn || operation.Kind == Kind.Restore || operation.Kind == Kind.Switch) && ForgetsLastMethod(failure))
            {
                bool guest = _account?.Current?.IsGuest ?? false;
                WriteMethod(environment, guest ? LoginMethod.Guest : LoginMethod.None);
            }
            else if (environment != null && operation.Kind == Kind.Link && failure != LoginFailure.AlreadyLinkedToOtherAccount && (_current == null || !_current.IsLinked(operation.Method)))
            {
                DeleteState(LoginStateKeys.Subject(environment, operation.Method));
            }

            Finish(operation, LoginResult.Failed(failure, operation.Method, providerCode, detail));
        }

        private static bool ForgetsLastMethod(LoginFailure failure)
        {
            switch (failure)
            {
                case LoginFailure.NoConnection:
                case LoginFailure.Timeout:
                case LoginFailure.Busy:
                case LoginFailure.NotInitialized:
                case LoginFailure.SessionChanged:
                case LoginFailure.ProviderError:
                    return false;
                default:
                    return true;
            }
        }

        private void Finish(Operation operation, LoginResult result)
        {
            if (!ReferenceEquals(_operation, operation)) return;
            ClearStage(operation);
            operation.Stage = int.MinValue;
            _operation = null;
            RaiseBusy(false);
            Reply(operation.Callback, result);
        }

        private void EndOperation(LoginFailure failure, string detail)
        {
            Operation operation = _operation;
            if (operation == null) return;
            ILoginProvider provider = operation.ActiveProvider;
            IAccountProvider account = operation.ActiveAccount;
            ClearStage(operation);
            operation.EndDetail = detail;
            if (provider != null) CancelQuietly(provider);
            if (account != null) CancelQuietly(account);
            Finish(operation, LoginResult.Failed(failure, operation.Method, 0, detail));
        }

        /// <summary>
        /// An account call answered after its call ended by cancel, timeout or sign-out. The game was told it failed,
        /// but the provider may have finished anyway and now hold another session. The manager follows the provider,
        /// or signs it out again when the game had signed out.
        /// </summary>
        private void OnLateAnswer(Operation operation, IAccountProvider account, AccountResult result)
        {
            if (!ReferenceEquals(account, _account)) return;
            if (result?.Conflict != null)
            {
                try { account.DiscardConflict(result.Conflict); }
                catch (Exception exception) { _host.LogException(exception); }
            }
            if (_operation != null) return; // The running call sets the account when it ends.

            if (operation.EndDetail == "signed_out")
            {
                if (ProviderUserId(account) == null) return;
                try { account.SignOut(); }
                catch (Exception exception) { _host.LogException(exception); }
                return;
            }
            FollowProvider(account, operation.Method);
        }

        /// <summary>
        /// Makes the manager's account the provider's when they hold different users. A provider without a session while
        /// the manager has none is the normal state before a restore, so nothing is adopted then.
        /// </summary>
        private void FollowProvider(IAccountProvider account, LoginMethod preferred)
        {
            if (_current == null || _operation != null || !ReferenceEquals(account, _account)) return;
            LoginAccount held = ProviderAccount(account);
            if (held != null && held.UserId == _current.UserId) return;

            string environment = EnvironmentKey;
            if (held == null)
            {
                SetCurrent(null);
                return;
            }

            LoginMethod method = held.IsGuest ? LoginMethod.Guest : !preferred.IsNone && held.IsLinked(preferred) ? preferred : FirstLinked(held);
            if (environment != null) WriteMethod(environment, method);
            SetCurrent(held.WithMethod(method));
        }

        private bool IsCurrent(Operation operation, int stage) => ReferenceEquals(_operation, operation) && operation.Stage == stage;

        private static void ClearStage(Operation operation)
        {
            Action cancel = operation.CancelTimeout;
            operation.CancelTimeout = null;
            operation.ActiveProvider = null;
            operation.ActiveAccount = null;
            cancel?.Invoke();
        }

        // ---- State ----

        private void Remember(LoginMethod method, string subject)
        {
            string environment = EnvironmentKey;
            if (environment == null) return;
            WriteMethod(environment, method);
            WriteState(LoginStateKeys.History(environment), "1");
            if (!string.IsNullOrEmpty(subject) && method != LoginMethod.Guest)
                WriteState(LoginStateKeys.Subject(environment, method), subject);
        }

        private void WriteMethod(string environment, LoginMethod method)
        {
            if (method.IsNone) DeleteState(LoginStateKeys.LastMethod(environment));
            else WriteState(LoginStateKeys.LastMethod(environment), method.Id);
        }

        private void OnCredentialRevoked(ILoginProvider provider, LoginMethod method)
        {
            if (!_providers.TryGetValue(method, out ILoginProvider registered) || !ReferenceEquals(registered, provider)) return;
            string environment = EnvironmentKey;
            if (environment != null)
            {
                DeleteState(LoginStateKeys.Subject(environment, method));
                if (LastMethod == method) WriteMethod(environment, LoginMethod.None);
            }
            try { _credentialRevoked?.Invoke(method); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void SetCurrent(LoginAccount account)
        {
            if (ReferenceEquals(_current, account)) return;
            _current = account;
            try { _accountChanged?.Invoke(account); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void ForgetConflict()
        {
            _conflict = null;
            _conflictMethod = LoginMethod.None;
            _conflictSubject = null;
            _conflictOwner = null;
        }

        private static LoginMethod FirstLinked(LoginAccount account)
        {
            return account.LinkedMethods.Count > 0 ? account.LinkedMethods[0] : account.IsGuest ? LoginMethod.Guest : LoginMethod.None;
        }

        private LoginAccount ProviderAccount(IAccountProvider account)
        {
            try { return account?.Current; }
            catch (Exception exception) { _host.LogException(exception); return null; }
        }

        private string ProviderUserId(IAccountProvider account) => ProviderAccount(account)?.UserId;

        private static bool SameUser(IAccountProvider account, string userId)
        {
            LoginAccount current = account?.Current;
            return current != null && current.UserId == userId;
        }

        private string ReadState(string key)
        {
            try { return _store.Get(key); }
            catch (Exception exception) { _host.LogException(exception); return null; }
        }

        private void WriteState(string key, string value)
        {
            try { _store.Set(key, value); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void DeleteState(string key)
        {
            try { _store.Delete(key); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        // ---- Safety ----

        private LoginFailure Availability(ILoginProvider provider)
        {
            try { return provider.Availability; }
            catch (Exception exception) { _host.LogException(exception); return LoginFailure.ProviderError; }
        }

        private LoginFailure Availability(IAccountProvider provider)
        {
            try { return provider.Availability; }
            catch (Exception exception) { _host.LogException(exception); return LoginFailure.ProviderError; }
        }

        private void CancelQuietly(ILoginProvider provider)
        {
            try { provider.Cancel(); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void CancelQuietly(IAccountProvider provider)
        {
            try { provider.Cancel(); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void RaiseBusy(bool busy)
        {
            try { _busyChanged?.Invoke(busy); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void Reply(Action<LoginResult> callback, LoginResult result)
        {
            if (callback == null) return;
            try { callback(result); }
            catch (Exception exception) { _host.LogException(exception); }
        }

        private void ReplyToken(Action<LoginToken> callback, LoginToken token)
        {
            if (callback == null) return;
            try { callback(token); }
            catch (Exception exception) { _host.LogException(exception); }
        }
    }
}
