using UnityEngine;

namespace PlatformLibrary.Login
{
    /// <summary>The default store. Writes are saved at once.</summary>
    public sealed class PlayerPrefsLoginStateStore : ILoginStateStore
    {
        public string Get(string key) => PlayerPrefs.HasKey(key) ? PlayerPrefs.GetString(key) : null;

        public void Set(string key, string value)
        {
            PlayerPrefs.SetString(key, value ?? string.Empty);
            PlayerPrefs.Save();
        }

        public void Delete(string key)
        {
            if (!PlayerPrefs.HasKey(key)) return;
            PlayerPrefs.DeleteKey(key);
            PlayerPrefs.Save();
        }
    }
}
