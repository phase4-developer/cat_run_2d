using System;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// A login method, such as Google or Apple. It only gets a credential from its platform.
    /// The account provider turns that credential into a game account.
    /// The manager calls it on the main thread. It may answer from any thread, once per request.
    /// </summary>
    public interface ILoginProvider
    {
        LoginMethod Method { get; }

        /// <summary>
        /// <see cref="LoginFailure.None"/> when usable. Otherwise why not, usually
        /// <see cref="LoginFailure.NotConfigured"/> or <see cref="LoginFailure.Unsupported"/>.
        /// </summary>
        LoginFailure Availability { get; }

        /// <summary>The player withdrew the app's permission outside the game.</summary>
        event Action CredentialRevoked;

        void RequestCredential(LoginCredentialRequest request, Action<LoginCredentialResult> callback);

        /// <summary>Stops the running request. Its late answer is ignored by the manager.</summary>
        void Cancel();
    }
}
