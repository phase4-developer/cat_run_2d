using System;
using System.Collections.Generic;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// The signed-in game account. It holds no token: ask <c>LoginManager.GetToken</c> when one is needed,
    /// so a stale token is never kept.
    /// </summary>
    public sealed class LoginAccount
    {
        private static readonly LoginMethod[] NoMethods = new LoginMethod[0];

        public LoginAccount(string userId, bool isGuest, string email = null, IEnumerable<LoginMethod> linkedMethods = null, LoginMethod method = default)
        {
            if (string.IsNullOrWhiteSpace(userId)) throw new ArgumentException("A user ID is required.", nameof(userId));
            UserId = userId;
            IsGuest = isGuest;
            Email = email ?? string.Empty;
            var methods = new List<LoginMethod>();
            if (linkedMethods != null)
                foreach (LoginMethod value in linkedMethods)
                    if (!value.IsNone && !methods.Contains(value)) methods.Add(value);
            LinkedMethods = methods.Count == 0 ? (IReadOnlyList<LoginMethod>)NoMethods : methods.AsReadOnly();
            Method = method;
        }

        /// <summary>The account provider's user ID, for example the Firebase UID. Not a platform ID.</summary>
        public string UserId { get; }

        /// <summary>How this session signed in. <see cref="LoginMethod.Guest"/> for a guest account.</summary>
        public LoginMethod Method { get; }

        public bool IsGuest { get; }
        public string Email { get; }

        /// <summary>Methods linked to this account. A guest account has none.</summary>
        public IReadOnlyList<LoginMethod> LinkedMethods { get; }

        public bool IsLinked(LoginMethod method)
        {
            foreach (LoginMethod value in LinkedMethods)
                if (value == method) return true;
            return false;
        }

        internal LoginAccount WithMethod(LoginMethod method)
        {
            return method == Method ? this : new LoginAccount(UserId, IsGuest, Email, LinkedMethods, method);
        }
    }
}
