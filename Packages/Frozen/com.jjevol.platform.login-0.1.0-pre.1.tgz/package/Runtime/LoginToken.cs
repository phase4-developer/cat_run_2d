using System;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// An account token for the game's server, for example a Firebase ID token.
    /// The server must verify it. Never write <see cref="Value"/> to logs.
    /// </summary>
    public readonly struct LoginToken
    {
        private readonly string _value;
        private readonly string _detail;

        private LoginToken(LoginFailure failure, string value, DateTimeOffset? expiresAt, int providerCode, string detail)
        {
            Failure = failure;
            _value = value;
            ExpiresAt = expiresAt;
            ProviderCode = providerCode;
            _detail = detail;
        }

        public LoginFailure Failure { get; }
        public bool Success => Failure == LoginFailure.None;

        /// <summary>The token, or null on failure.</summary>
        public string Value => Success ? _value : null;

        /// <summary>When the provider says it expires. Null when the provider does not say.</summary>
        public DateTimeOffset? ExpiresAt { get; }

        public int ProviderCode { get; }
        public string Detail => _detail ?? string.Empty;

        /// <summary>For account providers. An empty token becomes <see cref="LoginFailure.ProviderError"/>.</summary>
        public static LoginToken Succeeded(string value, DateTimeOffset? expiresAt = null)
        {
            if (string.IsNullOrEmpty(value)) return Failed(LoginFailure.ProviderError, 0, "token_missing");
            return new LoginToken(LoginFailure.None, value, expiresAt, 0, null);
        }

        /// <summary>For account providers. <see cref="LoginFailure.None"/> becomes <see cref="LoginFailure.ProviderError"/>.</summary>
        public static LoginToken Failed(LoginFailure failure, int providerCode = 0, string detail = null)
        {
            if (failure == LoginFailure.None) failure = LoginFailure.ProviderError;
            return new LoginToken(failure, null, null, providerCode, detail);
        }

        public override string ToString() => Success ? "LoginToken(ok)" : "LoginToken(" + Failure + ")";
    }
}
