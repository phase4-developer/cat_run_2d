using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Login.Tests.Editor")]
[assembly: InternalsVisibleTo("PlatformLibrary.Login.Tests.Runtime")]
[assembly: InternalsVisibleTo("PlatformLibrary.Login.Firebase.Tests.Editor")]
