using System;
using System.Threading.Tasks;
using UnityEngine;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// The only login API a game uses. Call it from the Unity main thread. Every callback runs once, on the main thread.
    /// The project registers login method providers and one account provider in its start code.
    /// With nothing registered, calls answer <see cref="LoginFailure.NotConfigured"/> and the game keeps running.
    /// </summary>
    public static class LoginManager
    {
        private static LoginSession _session;
        private static ILoginStateStore _store;

        /// <summary>The signed-in account changed. Null after sign-out or an account provider change.</summary>
        public static event Action<LoginAccount> AccountChanged;

        /// <summary>A login call started (true) or ended (false), so the project can show its loading indicator. The end comes before the callback.</summary>
        public static event Action<bool> BusyChanged;

        /// <summary>The player withdrew the app's permission for a method outside the game, for example in iOS settings.</summary>
        public static event Action<LoginMethod> CredentialRevoked;

        public static bool IsSignedIn => _session != null && _session.IsSignedIn;

        /// <summary>The signed-in account, or null.</summary>
        public static LoginAccount Account => _session?.Account;

        /// <summary>The method of the last successful login in this environment, kept across runs.</summary>
        public static LoginMethod LastMethod => _session?.LastMethod ?? LoginMethod.None;

        /// <summary>True once any login has worked in this environment, kept across runs.</summary>
        public static bool HasLoginHistory => _session != null && _session.HasLoginHistory;

        public static bool IsBusy => _session != null && _session.IsBusy;

        /// <summary>A link answered <see cref="LoginFailure.AlreadyLinkedToOtherAccount"/> and waits for <see cref="SwitchToLinkedAccount"/> or <see cref="DiscardLinkConflict"/>.</summary>
        public static bool HasLinkConflict => _session != null && _session.HasLinkConflict;

        // ---- Setup ----

        /// <summary>Registers a login method. Each method can be registered once.</summary>
        public static void AddProvider(ILoginProvider provider) => Session.AddProvider(provider);

        /// <summary>
        /// Sets the account provider, or removes it with null. A running call ends with <see cref="LoginFailure.SessionChanged"/>,
        /// the account is cleared and saved state is read for the new environment. The previous provider is disposed when it is
        /// <see cref="IDisposable"/>. Disposing never signs out.
        /// </summary>
        public static void SetAccountProvider(IAccountProvider provider)
        {
            if (provider == null && _session == null) return;
            Session.SetAccountProvider(provider);
        }

        /// <summary>Replaces where login state is kept. The default is <see cref="PlayerPrefsLoginStateStore"/>.</summary>
        public static void SetStateStore(ILoginStateStore store)
        {
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _session?.SetStore(store);
        }

        /// <summary>Removes every provider. A running call ends with <see cref="LoginFailure.Cancelled"/>.</summary>
        public static void Clear() => _session?.Clear();

        // ---- Availability ----

        public static bool IsAvailable(LoginMethod method) => GetAvailability(method) == LoginFailure.None;

        /// <summary><see cref="LoginFailure.None"/> when <see cref="SignIn"/> can run now, otherwise why not.</summary>
        public static LoginFailure GetAvailability(LoginMethod method) => _session?.GetAvailability(method) ?? LoginFailure.NotConfigured;

        /// <summary><see cref="LoginFailure.None"/> when <see cref="Link"/> can run now, otherwise why not.</summary>
        public static LoginFailure GetLinkAvailability(LoginMethod method) => _session?.GetLinkAvailability(method) ?? LoginFailure.NotConfigured;

        public static bool IsLinked(LoginMethod method) => _session != null && _session.IsLinked(method);

        // ---- Calls ----

        /// <summary>
        /// Signs in with the method and its login screen when needed. <see cref="LoginMethod.Guest"/> uses or creates a guest account.
        /// Any other method gets a credential from its provider and signs into the account provider with it.
        /// </summary>
        public static void SignIn(LoginMethod method, Action<LoginResult> callback)
        {
            if (_session == null) Reply(callback, LoginResult.Failed(LoginFailure.NotConfigured, method));
            else _session.SignIn(method, callback);
        }

        /// <summary>
        /// Signs in again without a login screen, with <see cref="LastMethod"/>: first the account provider's saved session,
        /// then the method's silent login. Answers <see cref="LoginFailure.NoSavedLogin"/> when neither works.
        /// </summary>
        public static void RestoreSession(Action<LoginResult> callback)
        {
            if (_session == null) Reply(callback, LoginResult.Failed(LoginFailure.NotConfigured, LoginMethod.None));
            else _session.RestoreSession(callback);
        }

        /// <summary>
        /// Links the method to the signed-in account, with its login screen. An already linked method answers success.
        /// A method owned by another account answers <see cref="LoginFailure.AlreadyLinkedToOtherAccount"/>.
        /// </summary>
        public static void Link(LoginMethod method, Action<LoginResult> callback)
        {
            if (_session == null) Reply(callback, LoginResult.Failed(LoginFailure.NotConfigured, method));
            else _session.Link(method, callback);
        }

        /// <summary>After a link conflict: signs into the account that owns the method. The current account is left.</summary>
        public static void SwitchToLinkedAccount(Action<LoginResult> callback)
        {
            if (_session == null) Reply(callback, LoginResult.Failed(LoginFailure.NotConfigured, LoginMethod.None));
            else _session.SwitchToLinkedAccount(callback);
        }

        /// <summary>After a link conflict: keeps the current account and forgets the conflict.</summary>
        public static void DiscardLinkConflict() => _session?.DiscardLinkConflict();

        /// <summary>Unlinks the method. The only linked method of an account cannot be unlinked.</summary>
        public static void Unlink(LoginMethod method, Action<LoginResult> callback)
        {
            if (_session == null) Reply(callback, LoginResult.Failed(LoginFailure.NotConfigured, method));
            else _session.Unlink(method, callback);
        }

        /// <summary>
        /// Signs out of the account provider. Unless <paramref name="keepLastMethod"/>, also forgets the last method and
        /// saved platform user IDs, so <see cref="RestoreSession"/> has nothing to restore. <see cref="HasLoginHistory"/> stays.
        /// </summary>
        public static void SignOut(bool keepLastMethod = false) => _session?.SignOut(keepLastMethod);

        /// <summary>Ends the running call with <see cref="LoginFailure.Cancelled"/>.</summary>
        public static void Cancel() => _session?.Cancel();

        /// <summary>
        /// An account token for the game's server, for example a Firebase ID token. Calls may overlap with login calls.
        /// Pass <paramref name="forceRefresh"/> after the server refused the token.
        /// </summary>
        public static void GetToken(bool forceRefresh, Action<LoginToken> callback)
        {
            if (_session == null)
            {
                if (callback == null) return;
                try { callback(LoginToken.Failed(LoginFailure.NotConfigured)); }
                catch (Exception exception) { Debug.LogException(exception); }
            }
            else _session.GetToken(forceRefresh, callback);
        }

        /// <summary>The same as <see cref="GetToken(bool, Action{LoginToken})"/>, for code that awaits, such as a network token source.</summary>
        public static Task<LoginToken> GetTokenAsync(bool forceRefresh = false)
        {
            var completion = new TaskCompletionSource<LoginToken>();
            GetToken(forceRefresh, token => completion.TrySetResult(token));
            return completion.Task;
        }

        // ---- Internal ----

        private static LoginSession Session
        {
            get
            {
                if (_session == null) Use(UnityLoginHost.Instance, _store ?? new PlayerPrefsLoginStateStore(), LoginSession.DefaultCredentialTimeoutSeconds, LoginSession.DefaultAccountTimeoutSeconds);
                return _session;
            }
        }

        /// <summary>For tests: a manager over a controlled host and store.</summary>
        internal static void Use(ILoginHost host, ILoginStateStore store, float credentialTimeoutSeconds, float accountTimeoutSeconds)
        {
            _session?.Clear();
            _session = new LoginSession(host, store, RaiseAccountChanged, RaiseBusyChanged, RaiseCredentialRevoked, credentialTimeoutSeconds, accountTimeoutSeconds);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        internal static void ResetState()
        {
            _session = null;
            _store = null;
            AccountChanged = null;
            BusyChanged = null;
            CredentialRevoked = null;
        }

        private static void Reply(Action<LoginResult> callback, LoginResult result)
        {
            if (callback == null) return;
            try { callback(result); }
            catch (Exception exception) { Debug.LogException(exception); }
        }

        private static void RaiseAccountChanged(LoginAccount account) => AccountChanged?.Invoke(account);

        private static void RaiseBusyChanged(bool busy) => BusyChanged?.Invoke(busy);

        private static void RaiseCredentialRevoked(LoginMethod method) => CredentialRevoked?.Invoke(method);
    }
}
