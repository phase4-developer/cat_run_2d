using System;

namespace PlatformLibrary.Login
{
    /// <summary>
    /// What a login method provider got from its platform, handed to the account provider.
    /// The manager drops it once the call ends. <see cref="Subject"/> is not verified and is never proof of identity.
    /// </summary>
    public sealed class LoginCredential
    {
        public LoginCredential(LoginMethod method, string subject, string token, string authorizationCode = null, string rawNonce = null)
        {
            if (method.IsNone) throw new ArgumentException("A login method is required.", nameof(method));
            if (string.IsNullOrWhiteSpace(token)) throw new ArgumentException("A credential token is required.", nameof(token));
            Method = method;
            Subject = subject ?? string.Empty;
            Token = token;
            AuthorizationCode = authorizationCode;
            RawNonce = rawNonce;
        }

        public LoginMethod Method { get; }

        /// <summary>The platform user ID, read without verification. Used to find the saved login next time.</summary>
        public string Subject { get; }

        /// <summary>For example a Google or Apple ID token.</summary>
        public string Token { get; }

        public string AuthorizationCode { get; }

        /// <summary>The nonce before hashing, when the platform needs it, as Apple does.</summary>
        public string RawNonce { get; }

        public override string ToString() => "LoginCredential(" + Method + ")";
    }

    /// <summary>Whether a login method may show its login screen.</summary>
    public enum LoginPrompt
    {
        /// <summary>Never show a screen. Answer <see cref="LoginFailure.NoSavedLogin"/> when that would be needed.</summary>
        Silent,

        /// <summary>Use a saved login when it works, and show a screen otherwise.</summary>
        Allowed,

        /// <summary>Always show a screen, as for linking.</summary>
        Required
    }

    public sealed class LoginCredentialRequest
    {
        public LoginCredentialRequest(string requestId, LoginPrompt prompt, string savedSubject = null)
        {
            if (string.IsNullOrWhiteSpace(requestId)) throw new ArgumentException("A request ID is required.", nameof(requestId));
            RequestId = requestId;
            Prompt = prompt;
            SavedSubject = string.IsNullOrEmpty(savedSubject) ? null : savedSubject;
        }

        public string RequestId { get; }
        public LoginPrompt Prompt { get; }

        /// <summary>The platform user ID from the last successful login with this method, or null.</summary>
        public string SavedSubject { get; }
    }

    public sealed class LoginCredentialResult
    {
        private LoginCredentialResult(LoginFailure failure, LoginCredential credential, int providerCode, string detail, bool savedSubjectInvalid)
        {
            Failure = failure;
            Credential = credential;
            ProviderCode = providerCode;
            Detail = detail ?? string.Empty;
            SavedSubjectInvalid = savedSubjectInvalid;
        }

        public LoginFailure Failure { get; }
        public bool Success => Failure == LoginFailure.None;
        public LoginCredential Credential { get; }
        public int ProviderCode { get; }
        public string Detail { get; }

        /// <summary>The saved platform user ID no longer works, so the manager forgets it.</summary>
        public bool SavedSubjectInvalid { get; }

        public static LoginCredentialResult Succeeded(LoginCredential credential, bool savedSubjectInvalid = false)
        {
            if (credential == null) throw new ArgumentNullException(nameof(credential));
            return new LoginCredentialResult(LoginFailure.None, credential, 0, null, savedSubjectInvalid);
        }

        /// <summary><see cref="LoginFailure.None"/> becomes <see cref="LoginFailure.ProviderError"/>.</summary>
        public static LoginCredentialResult Failed(LoginFailure failure, int providerCode = 0, string detail = null, bool savedSubjectInvalid = false)
        {
            if (failure == LoginFailure.None) failure = LoginFailure.ProviderError;
            return new LoginCredentialResult(failure, null, providerCode, detail, savedSubjectInvalid);
        }
    }

    /// <summary>What an account provider answers.</summary>
    public sealed class AccountResult
    {
        private AccountResult(LoginFailure failure, LoginAccount account, int providerCode, string detail, string conflict)
        {
            Failure = failure;
            Account = account;
            ProviderCode = providerCode;
            Detail = detail ?? string.Empty;
            Conflict = conflict;
        }

        public LoginFailure Failure { get; }
        public bool Success => Failure == LoginFailure.None;
        public LoginAccount Account { get; }
        public int ProviderCode { get; }
        public string Detail { get; }

        /// <summary>
        /// With <see cref="LoginFailure.AlreadyLinkedToOtherAccount"/>: a handle the provider keeps,
        /// passed back to <see cref="IAccountProvider.SwitchToLinkedAccount"/> or <see cref="IAccountProvider.DiscardConflict"/>.
        /// </summary>
        public string Conflict { get; }

        public static AccountResult Succeeded(LoginAccount account, string detail = null)
        {
            if (account == null) throw new ArgumentNullException(nameof(account));
            return new AccountResult(LoginFailure.None, account, 0, detail, null);
        }

        /// <summary><see cref="LoginFailure.None"/> becomes <see cref="LoginFailure.ProviderError"/>.</summary>
        public static AccountResult Failed(LoginFailure failure, int providerCode = 0, string detail = null)
        {
            if (failure == LoginFailure.None) failure = LoginFailure.ProviderError;
            return new AccountResult(failure, null, providerCode, detail, null);
        }

        public static AccountResult LinkConflict(string conflict, int providerCode = 0, string detail = null)
        {
            if (string.IsNullOrEmpty(conflict)) throw new ArgumentException("A conflict handle is required.", nameof(conflict));
            return new AccountResult(LoginFailure.AlreadyLinkedToOtherAccount, null, providerCode, detail, conflict);
        }
    }
}
