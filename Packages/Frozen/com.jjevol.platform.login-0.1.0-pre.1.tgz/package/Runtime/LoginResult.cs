namespace PlatformLibrary.Login
{
    /// <summary>Result of a login call. Branch on <see cref="Failure"/> only.</summary>
    public readonly struct LoginResult
    {
        private readonly string _detail;

        internal LoginResult(LoginFailure failure, LoginMethod method, LoginAccount account, int providerCode, string detail)
        {
            Failure = failure;
            Method = method;
            Account = failure == LoginFailure.None ? account : null;
            ProviderCode = providerCode;
            _detail = detail;
        }

        public LoginFailure Failure { get; }
        public bool Success => Failure == LoginFailure.None;
        public LoginMethod Method { get; }

        /// <summary>The account after a successful call. Null on failure.</summary>
        public LoginAccount Account { get; }

        /// <summary>The SDK's own code, for logs and investigation. Do not branch on it.</summary>
        public int ProviderCode { get; }

        /// <summary>Log text. It never holds a token. Do not show it to players or branch on it.</summary>
        public string Detail => _detail ?? string.Empty;

        internal static LoginResult Failed(LoginFailure failure, LoginMethod method, int providerCode = 0, string detail = null)
        {
            if (failure == LoginFailure.None) failure = LoginFailure.ProviderError;
            return new LoginResult(failure, method, null, providerCode, detail);
        }

        internal static LoginResult Succeeded(LoginMethod method, LoginAccount account, string detail = null)
        {
            return new LoginResult(LoginFailure.None, method, account, 0, detail);
        }
    }
}
