using System;

namespace PlatformLibrary.Login
{
    /// <summary>What <see cref="LoginSession"/> needs from Unity. Tests replace it to control time and threads.</summary>
    internal interface ILoginHost
    {
        /// <summary>Runs on the main thread, immediately when already on it.</summary>
        void Post(Action action);

        /// <summary>Runs on the main thread after real time passes. The returned action cancels it.</summary>
        Action Schedule(float seconds, Action action);

        void LogWarning(string message);
        void LogException(Exception exception);
    }
}
