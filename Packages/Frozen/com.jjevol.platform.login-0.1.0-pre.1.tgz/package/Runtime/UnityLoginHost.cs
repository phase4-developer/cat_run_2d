using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Threading;
using UnityEngine;

namespace PlatformLibrary.Login
{
    [AddComponentMenu("")]
    internal sealed class UnityLoginHost : MonoBehaviour, ILoginHost
    {
        private static UnityLoginHost _instance;

        private readonly ConcurrentQueue<Action> _queue = new ConcurrentQueue<Action>();
        private int _mainThreadId;

        public static UnityLoginHost Instance
        {
            get
            {
                if (_instance != null) return _instance;
                var host = new GameObject(nameof(LoginManager));
                if (Application.isPlaying) DontDestroyOnLoad(host);
                _instance = host.AddComponent<UnityLoginHost>();
                return _instance;
            }
        }

        private void Awake()
        {
            _mainThreadId = Thread.CurrentThread.ManagedThreadId;
        }

        private void Update()
        {
            while (_queue.TryDequeue(out Action action))
            {
                try { action(); }
                catch (Exception exception) { Debug.LogException(exception); }
            }
        }

        public void Post(Action action)
        {
            if (Thread.CurrentThread.ManagedThreadId == _mainThreadId) action();
            else _queue.Enqueue(action);
        }

        public Action Schedule(float seconds, Action action)
        {
            Coroutine coroutine = StartCoroutine(Run(seconds, action));
            return () =>
            {
                if (this != null) StopCoroutine(coroutine);
            };
        }

        public void LogWarning(string message) => Debug.LogWarning("[LoginManager] " + message);

        public void LogException(Exception exception) => Debug.LogException(exception);

        private static IEnumerator Run(float seconds, Action action)
        {
            yield return new WaitForSecondsRealtime(seconds);
            action();
        }
    }
}
