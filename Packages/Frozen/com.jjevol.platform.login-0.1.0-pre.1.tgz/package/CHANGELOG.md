# Changelog

## 0.1.0-pre.1 - 2026-11-08

New design, per `Docs/PlatformLogin/Design.md`. It replaces the mobile library's `IPlatformAuthProvider`, `IBackendAuthProvider`, `LoginService` and the common flow of the game's `LoginManager`. Class names, GUIDs and saved keys are not kept, so a game moving over needs code changes and its players sign in once more.

- `LoginManager` is the static entry point. Games need no SDK and no provider.
- Login methods (`ILoginProvider`) and the account system (`IAccountProvider`) are separate. Any number of methods can be registered, and a new one needs no change to this package.
- `LoginMethod`, a value with a string ID, replaces the `LoginType` enum.
- `LoginFailure` replaces error strings. The SDK code stays in `ProviderCode` for logs.
- Silent restore, link conflicts, login history, saved platform user IDs, guest protection and the session check moved from the game into the manager.
- Saved state uses new keys per environment key (`IAccountProvider.EnvironmentKey`, the same key as the network package). Old keys are not read.
- Names follow the network package: `EnvironmentKey`, and `LoginFailure.NoConnection` like `NetworkFailure.NoConnection`. Login and network never reference each other.
- Only one login call runs at a time, with timeouts, and a late answer is ignored.
- The account no longer carries an ID token. `GetToken` gives one, for the game's server.
- Removed: `ConvertGuestLogin`, debug logins and the update pump.
- `RestoreSession` falls back to the silent login only when the account provider has no saved session. A temporary failure, such as `NoConnection`, is the answer and keeps `LastMethod`.
- A late account answer is not reported, but the manager follows the session it left: it takes the provider's user after a cancel or timeout, and signs the provider out again after `SignOut`. A late link conflict is discarded.
- `GetToken` answers `SessionChanged` when the account provider holds another user than the manager.

Not yet run in Unity. See `Docs/PlatformLogin/Report.md`.
