# Changelog

## 0.1.0-pre.3 - 2026-11-19

- `NumberFormatProfile`에 직렬화 옵션 `Rounding`(`NumberRounding.Truncate` 기본, `HalfUp`)과 `KeepTrailingZeros`(기본 false)를 더했다. 생성자 끝에 같은 이름의 선택 인자가 있다. 기본값에서는 표시가 그대로다. `HalfUp`은 마지막으로 쓰는 단위를 0.5에서 올리고(음수는 절댓값 기준), 단위는 반올림 전에 고르므로 999,950은 소수 1자리에서 `1000.0K`다. `KeepTrailingZeros`는 `12.0K`처럼 소수 자릿수만큼 0을 남긴다.
- 소수 자릿수가 0이고 `HalfUp`이면 마지막 단위를 정수로 반올림한다(12,500은 `13K`). `Truncate`는 예전처럼 버린다.
- `HalfUp`은 값 전체를 마지막 단위에서 반올림한 뒤 단위로 나눈다. 여러 단위를 쓰면 올림이 위 단위로 넘어가고(2단위 한국어 199,995,000은 `2억`, `1억 10000만`이 아님), 1의 자리까지 쓰면 1의 자리도 반올림한다. 올림 결과가 decimal 범위를 넘으면 버린 값을 쓴다.
- 아주 큰 decimal(약 3.6e19 이상, long 범위 밖)에서 decimal에 들어가지 않아 소수 자릿수를 줄이는 기준이 값 전체로 바뀌어, `Truncate`에서도 여러 단위일 때 소수가 한 자리쯤 덜 나올 수 있다. long 값의 표시는 그대로다.

## 0.1.0-pre.2 - 2026-11-19

- 새 숫자 표기 API `NumberFormat.Format(value, profile, culture)`, `NumberFormatProfile`, `NumberFormatSettings`(중앙 요청 7eee4387e98c). 단위 간격(1000·10000 등), 기호 목록, 축약 시작 값, 소수 자릿수(버림), 표시할 최대 단위 수, 단위 구분자, 자릿수 구분 여부, 언어별 프로필 선택을 정한다. 기본 `NumberFormatProfile.Full`은 `ToString("N0")`과 같다. 미리 만든 `CreateThousands`(K·M·B·T), `CreateKorean`(만·억·조·경, 기본 2단위). `Copy()`로 프로필을 복제한다. uGUI와 UI Toolkit 라벨이 같이 쓴다.

## 0.1.0-pre.1 - 2026-11-11

- New package. UI system neutral contracts moved here unchanged so uGUI and UI Toolkit share one copy (UI Toolkit plan decision G1, 2026-11-11): `UIAddress` and `UIAddressIdAttribute` with its Inspector drawer (from ui.addressables), `IUILoadingProgressView` (from ui), `IScreenData` and `IPopupData` (from ui.addressables `UIScreen.cs`/`UIPopup.cs`), and the `JJEvol/UI/Generate UI ID Constants` generator `UIIdConstants` with its tests. Namespace `jjevol`, type names and the GUIDs of moved files are unchanged.
- No uGUI, TextMeshPro or UniTask dependency. The Editor assembly uses Addressables to read registered addresses.
