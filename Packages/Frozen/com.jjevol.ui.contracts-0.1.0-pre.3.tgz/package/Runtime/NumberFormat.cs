using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;

namespace jjevol
{
    public enum NumberNotation
    {
        // Every digit with the culture's group separator, the same as ToString("N0").
        Full,
        // Large values are shortened to unit symbols such as 1.2K or 1억 2000만.
        Abbreviated
    }

    public enum NumberRounding
    {
        // Drop digits past the decimal places: 12,350 with one decimal is 12.3K.
        Truncate,
        // Round half away from zero, like JavaScript toFixed on exact decimals: 12,350 with one decimal is 12.4K.
        HalfUp
    }

    /// <summary>
    /// How one game shows numbers. Serializable so a label can keep its own profile in the Inspector; the
    /// constructor is the code path. Values out of range are clamped when formatting instead of throwing.
    /// </summary>
    [Serializable]
    public sealed class NumberFormatProfile
    {
        public const int MaxDecimalPlaces = 10;

        [SerializeField] private NumberNotation notation;
        [Tooltip("Each symbol is this many times the previous one, for example 1000 (K, M, B) or 10000 (만, 억, 조).")]
        [SerializeField] private int unitBase = 1000;
        [Tooltip("Symbol for unitBase^1, unitBase^2 and so on. Values past the last symbol keep the last symbol.")]
        [SerializeField] private string[] symbols = { "K", "M", "B", "T" };
        [Tooltip("Values below this are shown in full. 0 means unitBase.")]
        [SerializeField] private long abbreviateFrom;
        [Tooltip("Digits after the decimal point on the last unit shown. Truncated, trailing zeros are dropped.")]
        [SerializeField] private int decimalPlaces = 1;
        [Tooltip("How many units are written, for example 2 for 1억 2000만.")]
        [SerializeField] private int maxUnits = 1;
        [SerializeField] private string unitSeparator = " ";
        [Tooltip("Use the culture's group separator inside one unit, for example 1,234만.")]
        [SerializeField] private bool groupDigits = true;
        [Tooltip("How the last unit shown drops digits past decimalPlaces.")]
        [SerializeField] private NumberRounding rounding;
        [Tooltip("Keep zeros at the end of the decimals, for example 12.0K instead of 12K.")]
        [SerializeField] private bool keepTrailingZeros;

        // Full notation (N0). Unity uses this constructor before it reads serialized values.
        public NumberFormatProfile() { notation = NumberNotation.Full; }

        public NumberFormatProfile(NumberNotation notation, int unitBase = 1000, IEnumerable<string> symbols = null, long abbreviateFrom = 0,
            int decimalPlaces = 0, int maxUnits = 1, string unitSeparator = " ", bool groupDigits = true,
            NumberRounding rounding = NumberRounding.Truncate, bool keepTrailingZeros = false)
        {
            if (unitBase < 2) throw new ArgumentOutOfRangeException(nameof(unitBase), "Use 2 or more.");
            if (abbreviateFrom < 0) throw new ArgumentOutOfRangeException(nameof(abbreviateFrom));
            if (decimalPlaces < 0 || decimalPlaces > MaxDecimalPlaces) throw new ArgumentOutOfRangeException(nameof(decimalPlaces));
            if (maxUnits < 1) throw new ArgumentOutOfRangeException(nameof(maxUnits));
            string[] copy = symbols == null ? Array.Empty<string>() : new List<string>(symbols).ToArray();
            if (notation == NumberNotation.Abbreviated && copy.Length == 0) throw new ArgumentException("Abbreviated notation needs at least one symbol.", nameof(symbols));
            foreach (string symbol in copy) if (symbol == null) throw new ArgumentException("Symbols cannot be null.", nameof(symbols));
            this.notation = notation; this.unitBase = unitBase; this.symbols = copy; this.abbreviateFrom = abbreviateFrom;
            this.decimalPlaces = decimalPlaces; this.maxUnits = maxUnits; this.unitSeparator = unitSeparator ?? string.Empty; this.groupDigits = groupDigits;
            this.rounding = rounding; this.keepTrailingZeros = keepTrailingZeros;
        }

        public NumberNotation Notation => notation;
        public int UnitBase => unitBase;
        public IReadOnlyList<string> Symbols => symbols ?? Array.Empty<string>();
        public long AbbreviateFrom => abbreviateFrom;
        public int DecimalPlaces => decimalPlaces;
        public int MaxUnits => maxUnits;
        public string UnitSeparator => unitSeparator ?? string.Empty;
        public bool GroupDigits => groupDigits;
        public NumberRounding Rounding => rounding;
        public bool KeepTrailingZeros => keepTrailingZeros;

        /// <summary>
        /// A separate copy. Labels keep a copy in their serialized field so editing one label in the Inspector does not
        /// change a shared profile such as <see cref="Full"/>.
        /// </summary>
        public NumberFormatProfile Copy() => new NumberFormatProfile
        {
            notation = notation, unitBase = unitBase, symbols = symbols == null ? null : (string[])symbols.Clone(),
            abbreviateFrom = abbreviateFrom, decimalPlaces = decimalPlaces, maxUnits = maxUnits,
            unitSeparator = unitSeparator, groupDigits = groupDigits, rounding = rounding, keepTrailingZeros = keepTrailingZeros
        };

        /// <summary>Every digit, the same as ToString("N0"). This is the default when a game sets nothing.</summary>
        public static NumberFormatProfile Full { get; } = new NumberFormatProfile();

        /// <summary>K, M, B, T every 1000, for example 1.2K and 3.45M.</summary>
        public static NumberFormatProfile CreateThousands(int decimalPlaces = 2, long abbreviateFrom = 0) =>
            new NumberFormatProfile(NumberNotation.Abbreviated, 1000, new[] { "K", "M", "B", "T" }, abbreviateFrom, decimalPlaces);

        /// <summary>만, 억, 조, 경 every 10000, for example 1억 2000만.</summary>
        public static NumberFormatProfile CreateKorean(int maxUnits = 2, int decimalPlaces = 0, long abbreviateFrom = 0) =>
            new NumberFormatProfile(NumberNotation.Abbreviated, 10000, new[] { "만", "억", "조", "경" }, abbreviateFrom, decimalPlaces, maxUnits, " ", false);

        /// <summary>Built-in abbreviation for a language when the game has not set one: Korean for "ko", K/M/B/T otherwise.</summary>
        public static NumberFormatProfile CreateAbbreviatedFor(string language) =>
            NumberFormatSettings.Neutral(language) == "ko" ? CreateKorean() : CreateThousands();
    }

    /// <summary>
    /// The game's number profiles: one default and optional per-language profiles. A language matches exactly first
    /// ("ko-KR"), then by its neutral part ("ko"), then falls back to <see cref="Default"/>.
    /// </summary>
    public sealed class NumberFormatSettings
    {
        private readonly Dictionary<string, NumberFormatProfile> _languages = new Dictionary<string, NumberFormatProfile>(StringComparer.OrdinalIgnoreCase);
        private NumberFormatProfile _default = NumberFormatProfile.Full;

        public NumberFormatSettings() { }
        public NumberFormatSettings(NumberFormatProfile defaultProfile) { Default = defaultProfile; }

        public NumberFormatProfile Default
        {
            get => _default;
            set => _default = value ?? NumberFormatProfile.Full;
        }

        public IReadOnlyDictionary<string, NumberFormatProfile> Languages => _languages;

        public NumberFormatSettings SetLanguage(string language, NumberFormatProfile profile)
        {
            if (string.IsNullOrWhiteSpace(language)) throw new ArgumentException("Language is required.", nameof(language));
            if (profile == null) _languages.Remove(language.Trim());
            else _languages[language.Trim()] = profile;
            return this;
        }

        public NumberFormatProfile Resolve(string language)
        {
            if (!string.IsNullOrWhiteSpace(language))
            {
                string name = language.Trim();
                if (_languages.TryGetValue(name, out NumberFormatProfile exact)) return exact;
                string neutral = Neutral(name);
                if (neutral != name && _languages.TryGetValue(neutral, out NumberFormatProfile parent)) return parent;
            }
            return _default;
        }

        internal static string Neutral(string language)
        {
            if (string.IsNullOrWhiteSpace(language)) return string.Empty;
            string name = language.Trim();
            int dash = name.IndexOfAny(new[] { '-', '_' });
            return (dash > 0 ? name.Substring(0, dash) : name).ToLowerInvariant();
        }
    }

    /// <summary>Formats numbers with a <see cref="NumberFormatProfile"/>. Pure and thread safe.</summary>
    public static class NumberFormat
    {
        public static string Format(long value, NumberFormatProfile profile, IFormatProvider culture = null) => Format((decimal)value, profile, culture);

        public static string Format(decimal value, NumberFormatProfile profile, IFormatProvider culture = null)
        {
            culture ??= CultureInfo.CurrentCulture;
            profile ??= NumberFormatProfile.Full;
            IReadOnlyList<string> symbols = profile.Symbols;
            if (profile.Notation != NumberNotation.Abbreviated || profile.UnitBase < 2 || symbols.Count == 0) return value.ToString("N0", culture);

            decimal magnitude = Math.Abs(value);
            decimal threshold = profile.AbbreviateFrom > 0 ? profile.AbbreviateFrom : profile.UnitBase;
            if (magnitude < threshold || magnitude < profile.UnitBase) return value.ToString("N0", culture);

            // powers[k] is unitBase^k; level k uses symbols[k - 1] and level 0 is the part below the first unit.
            var powers = new List<decimal> { 1m };
            try { while (powers.Count <= symbols.Count) powers.Add(checked(powers[powers.Count - 1] * profile.UnitBase)); }
            catch (OverflowException) { }
            int top = powers.Count - 1;
            while (top > 1 && magnitude < powers[top]) top--;

            int decimals = Math.Max(0, Math.Min(NumberFormatProfile.MaxDecimalPlaces, profile.DecimalPlaces));
            int lowest = Math.Max(0, top - Math.Max(1, profile.MaxUnits) + 1);
            string digits = profile.GroupDigits ? "#,0" : "0";
            var parts = new List<string>();

            // Decimals on the lowest unit shown; fewer when the scaled value would not fit in decimal (very large decimal input).
            int places = 0;
            if (lowest > 0)
            {
                places = decimals;
                decimal lowestUnits = magnitude / powers[lowest];
                while (places > 0 && lowestUnits >= decimal.MaxValue / Pow10(places)) places--;
            }

            decimal rest = magnitude;
            if (profile.Rounding == NumberRounding.HalfUp)
            {
                // Round the whole value at the lowest unit shown, then split it, so a carry moves into the unit above
                // (1억 9999.5만 is 2억). The units were chosen before rounding, so 999,950 with one K decimal stays 1000.0K.
                decimal step = powers[lowest] / Pow10(places);
                try { rest = decimal.Round(magnitude / step, MidpointRounding.AwayFromZero) * step; }
                catch (OverflowException) { } // Too large to round up: keep the truncated value.
            }

            for (int level = top; level >= lowest; level--)
            {
                decimal amount;
                string format = digits;
                if (level == lowest && places > 0)
                {
                    decimal scale = Pow10(places);
                    amount = decimal.Floor(rest / powers[level] * scale) / scale;
                    format = digits + "." + new string(profile.KeepTrailingZeros ? '0' : '#', places);
                }
                else amount = decimal.Floor(rest / powers[level]);
                if (level != lowest) rest -= amount * powers[level];
                if (amount == 0 && level != top) continue;
                parts.Add(amount.ToString(format, culture) + (level == 0 ? string.Empty : symbols[level - 1]));
            }

            var text = new StringBuilder();
            if (value < 0) text.Append(NumberFormatInfo.GetInstance(culture).NegativeSign);
            text.Append(string.Join(profile.UnitSeparator, parts));
            return text.ToString();
        }

        private static decimal Pow10(int digits)
        {
            decimal result = 1m;
            for (int i = 0; i < digits; i++) result *= 10m;
            return result;
        }
    }
}
