# JJEvol Platform Core

Local validation candidate 0.1.0-pre.2. Existing class names and runtime behavior are preserved.

This package contains only the approved user-authored module and its focused regression tests. External SDK binaries, paid assets and company game content are excluded. Development authorship is user-confirmed on 2026-10-29; contract assignment and distribution terms are separate records in {workspace}/JJEvolAutomation/SourceOwnership.md.

## Login provider lifetime

`PlatformServiceResolver` owns auth registrations and can outlive a `LoginService`. A new service on the same resolver reuses the registered provider instead of building a second one. If the resolver was cleared, the service builds a new provider once. A provider the resolver rejects is disposed when it implements `IDisposable`.

## Trust boundary for purchases and rewards

Client callbacks are not proof of payment or of a completed ad. A modified client, a replayed event or a compromised device can fake or repeat them, so never grant value that matters from a callback alone.

| Client signal | What it means | What grants the value |
| --- | --- | --- |
| `IPlatformStoreProvider.PurchaseConfirmed`, `PlatformStoreOrderState.Confirmed` | The store SDK reported a purchase to this client. | A server validates `Receipt` or `VerificationData` with the store, records `TransactionId` once, then grants. |
| `ADRewardResult.rewardGranted` | The ad SDK reported a reward to this client. | A server receives the ad network's server-side verification callback for `requestId`, then grants. |
| `ADRewardResult.serverVerified` | The value the provider passed in. This package does not verify it. | The game's server, as above. |
| `ADRevenuePaidEventData` | Analytics data only. | Never a reason to grant anything. |

Call `ConfirmPurchase` only after the server has recorded the order, so an unconfirmed purchase stays pending and can be fetched again. Games without a server can only give locally stored, cheat-tolerant rewards, and must decide that deliberately. This package contains no server validation.

No license grant for third-party dependencies is made here. Resolve declared dependencies from Unity Package Manager. Enable this package in the validation Host manifest testables list to run its Editor tests. Installation in a consumer project is a separate task.

The Runtime assembly sets `noEngineReferences`, so the same Editor tests also run without Unity: `dotnet test Tests/DotNet~/Tests` (.NET SDK 8 or later, NUnit 3.14 from NuGet). `Tests/DotNet~` compiles `Runtime` as netstandard2.1 and `Tests/Editor` with C# 9, the language version of Unity 6. Unity ignores the folder. `Tools/Compare-DotNetEditMode.py` in the Framework repository compares the TRX result with a Unity EditMode XML.
