using System;
using System.Linq;
using NUnit.Framework;
using PlatformLibrary;

namespace PlatformLibrary.Tests
{
    public sealed class PlatformLibraryCoreTests
    {
        private sealed class IdentityProvider : IPlatformIdentityProvider
        {
            public string Provider => "steam";
            public string UserId;
            public bool Available = true;
            public bool TryGetUserId(out string userId) { userId = UserId; return Available; }
        }

        [Test]
        public void MissingIdentityDoesNotFabricateAnAccount()
        {
            Assert.That(new PlatformServiceResolver().TryGetIdentity("steam", out PlatformIdentity identity), Is.False);
            Assert.That(identity.UserId, Is.Null);
        }

        [TestCase(null, true)]
        [TestCase("", true)]
        [TestCase(" ", true)]
        [TestCase("123", false)]
        public void UnavailableOrEmptyIdentityCannotBindAProfile(string userId, bool available)
        {
            var resolver = new PlatformServiceResolver();
            resolver.RegisterIdentity(new IdentityProvider { UserId = userId, Available = available });
            Assert.That(resolver.TryGetIdentity("steam", out _), Is.False);
        }

        [Test]
        public void IdentityKeepsTheProviderNamespace()
        {
            var resolver = new PlatformServiceResolver();
            resolver.RegisterIdentity(new IdentityProvider { UserId = "76561198000000000" });
            Assert.That(resolver.TryGetIdentity("steam", out PlatformIdentity identity), Is.True);
            Assert.That(identity.Provider, Is.EqualTo("steam"));
            Assert.That(identity.UserId, Is.EqualTo("76561198000000000"));
            Assert.That(resolver.TryGetIdentity("google", out _), Is.False);
        }

        [Test]
        public void DuplicateRegistrationCannotSilentlyReplaceAnIdentity()
        {
            var resolver = new PlatformServiceResolver();
            resolver.RegisterIdentity(new IdentityProvider { UserId = "first" });
            Assert.Throws<InvalidOperationException>(() => resolver.RegisterIdentity(new IdentityProvider { UserId = "second" }));
            Assert.That(resolver.TryGetIdentity("steam", out PlatformIdentity identity), Is.True);
            Assert.That(identity.UserId, Is.EqualTo("first"));
        }

        [Test]
        public void CoreAssemblyHasNoGameUnityOrSdkDependency()
        {
            string[] dependencies = typeof(PlatformServiceResolver).Assembly.GetReferencedAssemblies().Select(reference => reference.Name).ToArray();
            Assert.That(dependencies.Any(name => name.Contains("Unity") || name.Contains("Firebase") || name.Contains("Assembly-CSharp") || name.Contains("Steamworks")), Is.False);
        }
    }
}
