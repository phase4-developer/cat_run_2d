using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using NUnit.Framework;

namespace PlatformLibrary.Tests
{
    public class AppleLoginNonceTests
    {
        [TestCase(1)]
        [TestCase(2)]
        [TestCase(3)]
        [TestCase(16)]
        [TestCase(32)]
        [TestCase(64)]
        public void NonceUsesUrlSafeAlphabetAndRetainsAllRandomBytes(int byteCount)
        {
            string nonce = GenerateNonce(byteCount);
            Assert.That(nonce, Does.Match(@"\A[A-Za-z0-9_-]+\z"));

            string base64 = nonce.Replace('-', '+').Replace('_', '/');
            base64 = base64.PadRight((base64.Length + 3) / 4 * 4, '=');
            Assert.That(Convert.FromBase64String(base64).Length, Is.EqualTo(byteCount));
        }

        [Test]
        public void DefaultNonceHas256BitsWithoutPadding()
        {
            MethodInfo method = GetNonceGenerator();
            Assert.That(method.GetParameters()[0].DefaultValue, Is.EqualTo(32));
            Assert.That(GenerateNonce(32).Length, Is.EqualTo(43));
        }

        [Test]
        public void RepeatedRequestsRemainDistinctAndSurviveFormUrlDecoding()
        {
            var seen = new HashSet<string>();
            for (int i = 0; i < 256; i++)
            {
                string nonce = GenerateNonce(32);
                Assert.That(seen.Add(nonce), Is.True);
                Assert.That(WebUtility.UrlDecode(nonce), Is.EqualTo(nonce));
                Assert.That(HashNonce(WebUtility.UrlDecode(nonce)), Is.EqualTo(HashNonce(nonce)));
            }
        }

        [Test]
        public void HashIsLowercaseSha256OfTheFinalRawNonce()
        {
            string nonce = GenerateNonce(32);
            string expected;
            using (var sha = SHA256.Create())
                expected = BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(nonce))).Replace("-", "").ToLowerInvariant();

            Assert.That(HashNonce(nonce), Is.EqualTo(expected));
            Assert.That(HashNonce(nonce), Does.Match(@"\A[0-9a-f]{64}\z"));
            Assert.That(HashNonce("abc"), Is.EqualTo("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));
        }

        [Test]
        public void LegacyBase64PlusChangesNonceHashWhenFormDecoded()
        {
            string legacyNonce = Convert.ToBase64String(new byte[] { 251, 239, 255 });
            Assert.That(legacyNonce, Does.Contain("+"));
            Assert.That(HashNonce(WebUtility.UrlDecode(legacyNonce)), Is.Not.EqualTo(HashNonce(legacyNonce)));

            string urlSafeNonce = legacyNonce.TrimEnd('=').Replace('+', '-').Replace('/', '_');
            Assert.That(WebUtility.UrlDecode(urlSafeNonce), Is.EqualTo(urlSafeNonce));
            Assert.That(HashNonce(WebUtility.UrlDecode(urlSafeNonce)), Is.EqualTo(HashNonce(urlSafeNonce)));
        }

        private static MethodInfo GetNonceGenerator()
        {
            MethodInfo method = typeof(PlatformAuthNonce).GetMethod("Generate", BindingFlags.Static | BindingFlags.Public);
            Assert.That(method, Is.Not.Null);
            return method;
        }

        private static string GenerateNonce(int byteCount)
        {
            return (string)GetNonceGenerator().Invoke(null, new object[] { byteCount });
        }

        private static string HashNonce(string nonce)
        {
            MethodInfo method = typeof(PlatformAuthNonce).GetMethod("HashSha256", BindingFlags.Static | BindingFlags.Public);
            Assert.That(method, Is.Not.Null);
            return (string)method.Invoke(null, new object[] { nonce });
        }
    }
}
