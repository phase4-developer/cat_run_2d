using System;
using NUnit.Framework;
using PlatformLibrary;

namespace PlatformLibrary.Tests
{
    public sealed class LoginServiceTests
    {
        private sealed class FakeProvider : IPlatformAuthProvider
        {
            public string Provider => "google";
            public bool IsSupported => true;
            public event Action CredentialsRevoked { add { } remove { } }
            public Action<PlatformAuthResult> Completed;
            public Action<PlatformAuthProgress> Progress;
            public int Calls, Updates, Cancels;
            public void SignIn(PlatformAuthRequest request, Action<PlatformAuthResult> callback, Action<PlatformAuthProgress> progress = null) { Calls++; Completed = callback; Progress = progress; }
            public void Cancel() { Cancels++; Completed?.Invoke(new PlatformAuthResult(null, "cancelled")); }
            public void Update() { Updates++; }
        }

        private sealed class OwnedProvider : IPlatformAuthProvider, IDisposable
        {
            public string Provider { get; set; } = "google";
            public bool IsSupported => true;
            public event Action CredentialsRevoked { add { } remove { } }
            public int Updates, Disposals;
            public Action OnUpdate;
            public void SignIn(PlatformAuthRequest request, Action<PlatformAuthResult> callback, Action<PlatformAuthProgress> progress = null) { }
            public void Cancel() { }
            public void Update() { Updates++; OnUpdate?.Invoke(); }
            public void Dispose() { Disposals++; }
        }

        [TestCase(false, false, false, false)]
        [TestCase(false, false, false, true)]
        [TestCase(false, false, true, false)]
        [TestCase(false, false, true, true)]
        [TestCase(false, true, false, true)]
        [TestCase(false, true, true, false)]
        [TestCase(false, true, true, true)]
        [TestCase(true, false, false, false)]
        [TestCase(true, false, false, true)]
        [TestCase(true, false, true, false)]
        [TestCase(true, false, true, true)]
        [TestCase(true, true, false, false)]
        [TestCase(true, true, false, true)]
        [TestCase(true, true, true, false)]
        [TestCase(true, true, true, true)]
        [TestCase(false, true, false, false)]
        public void SettingsDoNotEnableAnonymousWithoutBackend(bool google, bool apple, bool firebase, bool anonymous)
        {
            var settings = new PlatformLoginOptions(google, apple, firebase, anonymous);
            Assert.That(settings.GoogleEnabled, Is.EqualTo(google));
            Assert.That(settings.AppleEnabled, Is.EqualTo(apple));
            Assert.That(settings.AnonymousSignInEnabled, Is.EqualTo(firebase && anonymous));
        }

        [TestCase(LoginAvailability.UnsupportedPlatform)]
        [TestCase(LoginAvailability.MissingConfiguration)]
        [TestCase(LoginAvailability.MissingDependency)]
        [TestCase(LoginAvailability.Initializing)]
        [TestCase(LoginAvailability.TemporarilyUnavailable)]
        public void UnavailableProviderIsNotConstructedOrCalled(LoginAvailability state)
        {
            using (var resolver = new PlatformServiceResolver())
            using (var service = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver))
            {
                int constructed = 0;
                service.ConfigureProvider("google", () => state, () => { constructed++; return new FakeProvider(); });
                Assert.That(service.GetAvailability("google"), Is.EqualTo(state));
                string error = null;
                service.RequestCredential("google", new PlatformAuthRequest("request"), result => error = result.Error);
                Assert.That(error, Is.EqualTo(state.ToString()));
                service.Update();
                Assert.That(constructed, Is.Zero);
            }
        }

        [Test]
        public void DisabledAndMissingSettingsHaveDifferentReasons()
        {
            using (var resolver = new PlatformServiceResolver())
            using (var disabled = new LoginService(new PlatformLoginOptions(false, false, false, false), resolver))
            using (var missing = new LoginService(null, resolver))
            {
                disabled.ConfigureProvider("google", () => LoginAvailability.Available, () => throw new Exception("must not construct"));
                Assert.That(disabled.GetAvailability("google"), Is.EqualTo(LoginAvailability.Disabled));
                Assert.That(disabled.GetBackendAvailability(), Is.EqualTo(LoginAvailability.Disabled));
                Assert.That(missing.GetAvailability("google"), Is.EqualTo(LoginAvailability.MissingConfiguration));
            }
        }

        [Test]
        public void PlatformOnlyCredentialDoesNotRequireOrInitializeBackend()
        {
            var provider = new FakeProvider();
            using (var resolver = new PlatformServiceResolver())
            using (var service = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver))
            {
                service.ConfigureProvider("google", () => LoginAvailability.Available, () => provider);
                PlatformAuthCredential credential = null;
                service.RequestCredential("google", new PlatformAuthRequest("request"), result => credential = result.Credential);
                provider.Completed(new PlatformAuthResult(new PlatformAuthCredential("google", "platform-subject", "test-token")));
                Assert.That(credential.Subject, Is.EqualTo("platform-subject"));
                Assert.That(service.Backend, Is.Null);
                Assert.That(service.AuthenticateAsync(credential).Result.Error, Is.EqualTo("Disabled"));
            }
        }

        [Test]
        public void DuplicateRequestDoesNotReplaceCompletionAndLateResultCannotCompleteTheNextRequest()
        {
            var provider = new FakeProvider();
            using (var resolver = new PlatformServiceResolver())
            using (var service = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver))
            {
                service.ConfigureProvider("google", () => LoginAvailability.Available, () => provider);
                int first = 0, second = 0;
                service.RequestCredential("google", new PlatformAuthRequest("first"), _ => first++);
                var old = provider.Completed;
                service.RequestCredential("google", new PlatformAuthRequest("duplicate"), result => Assert.That(result.Error, Is.EqualTo("busy")));
                Assert.That(provider.Calls, Is.EqualTo(1));
                service.Cancel();
                Assert.That(first, Is.EqualTo(1));
                service.RequestCredential("google", new PlatformAuthRequest("second"), _ => second++);
                old(new PlatformAuthResult(new PlatformAuthCredential("google", "old", "old-token")));
                Assert.That(second, Is.Zero);
                provider.Completed(new PlatformAuthResult(new PlatformAuthCredential("google", "new", "new-token")));
                provider.Completed(new PlatformAuthResult(new PlatformAuthCredential("google", "new", "new-token")));
                Assert.That(second, Is.EqualTo(1));
            }
        }

        [Test]
        public void RepairedConfigurationRegistersOnceAndDisposeStopsUpdates()
        {
            var provider = new FakeProvider();
            var state = LoginAvailability.MissingConfiguration;
            using (var resolver = new PlatformServiceResolver())
            {
                var service = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver);
                int constructed = 0;
                service.ConfigureProvider("google", () => state, () => { constructed++; return provider; });
                state = LoginAvailability.Available;
                Assert.That(service.GetAvailability("google"), Is.EqualTo(LoginAvailability.Available));
                Assert.That(service.GetAvailability("google"), Is.EqualTo(LoginAvailability.Available));
                Assert.That(constructed, Is.EqualTo(1));
                service.Update(); service.Dispose(); service.Update();
                Assert.That(provider.Updates, Is.EqualTo(1));
            }
        }

        [Test]
        public void ReloginServiceReusesTheProviderTheResolverStillHolds()
        {
            var provider = new OwnedProvider();
            using (var resolver = new PlatformServiceResolver())
            {
                int constructed = 0;
                Func<IPlatformAuthProvider> factory = () => { constructed++; return new OwnedProvider(); };
                using (var signedOut = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver))
                {
                    signedOut.ConfigureProvider("google", () => LoginAvailability.Available, () => provider);
                    Assert.That(signedOut.GetAvailability("google"), Is.EqualTo(LoginAvailability.Available));
                }
                using (var relogin = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver))
                {
                    relogin.ConfigureProvider("google", () => LoginAvailability.Available, factory);
                    Assert.That(relogin.GetAvailability("google"), Is.EqualTo(LoginAvailability.Available));
                    relogin.Update();
                }
                Assert.That(constructed, Is.Zero, "The new service built a provider the resolver would have rejected");
                Assert.That(provider.Updates, Is.EqualTo(1));
            }
        }

        [Test]
        public void ClearedResolverRegistrationIsRebuiltOnce()
        {
            int constructed = 0;
            var resolver = new PlatformServiceResolver();
            using (var service = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver))
            {
                service.ConfigureProvider("google", () => LoginAvailability.Available, () => { constructed++; return new OwnedProvider(); });
                Assert.That(constructed, Is.EqualTo(1));
                resolver.Dispose();
                Assert.That(service.GetAvailability("google"), Is.EqualTo(LoginAvailability.Available));
                Assert.That(service.GetAvailability("google"), Is.EqualTo(LoginAvailability.Available));
                Assert.That(constructed, Is.EqualTo(2));
            }
            resolver.Dispose();
        }

        [Test]
        public void ProviderRejectedByTheResolverIsDisposed()
        {
            var taken = new OwnedProvider { Provider = "apple" };
            var rejected = new OwnedProvider { Provider = "apple" };
            using (var resolver = new PlatformServiceResolver())
            using (var service = new LoginService(new PlatformLoginOptions(true, false, false, false), resolver))
            {
                resolver.RegisterAuth(taken);
                service.ConfigureProvider("google", () => LoginAvailability.Available, () => rejected);
                Assert.That(service.GetAvailability("google"), Is.EqualTo(LoginAvailability.MissingDependency));
                Assert.That(rejected.Disposals, Is.GreaterThan(0));
                Assert.That(taken.Disposals, Is.Zero);
            }
        }

        [Test]
        public void ProviderUpdateMayRegisterAnotherProvider()
        {
            var late = new OwnedProvider { Provider = "apple" };
            using (var resolver = new PlatformServiceResolver())
            using (var service = new LoginService(new PlatformLoginOptions(true, true, false, false), resolver))
            {
                var first = new OwnedProvider { OnUpdate = () => service.GetAvailability("apple") };
                var appleState = LoginAvailability.MissingConfiguration;
                service.ConfigureProvider("google", () => LoginAvailability.Available, () => first);
                service.ConfigureProvider("apple", () => appleState, () => late);
                appleState = LoginAvailability.Available;
                Assert.DoesNotThrow(() => service.Update());
                Assert.That(first.Updates, Is.EqualTo(1));
                Assert.That(late.Updates, Is.Zero);
                service.Update();
                Assert.That(late.Updates, Is.EqualTo(1));
            }
        }

        [Test]
        public void ProviderUpdateMayDisposeTheService()
        {
            using (var resolver = new PlatformServiceResolver())
            {
                var service = new LoginService(new PlatformLoginOptions(true, true, false, false), resolver);
                var google = new OwnedProvider { OnUpdate = service.Dispose };
                var apple = new OwnedProvider { Provider = "apple", OnUpdate = service.Dispose };
                service.ConfigureProvider("google", () => LoginAvailability.Available, () => google);
                service.ConfigureProvider("apple", () => LoginAvailability.Available, () => apple);
                Assert.DoesNotThrow(() => service.Update());
                Assert.That(google.Updates + apple.Updates, Is.EqualTo(1));
            }
        }
    }
}
