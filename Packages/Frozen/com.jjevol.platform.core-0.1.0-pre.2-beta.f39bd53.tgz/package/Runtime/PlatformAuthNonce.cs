using System;
using System.Security.Cryptography;
using System.Text;

namespace PlatformLibrary
{
    public static class PlatformAuthNonce
    {
        public static string Generate(int byteCount = 32)
        {
            var bytes = new byte[byteCount];
            using (var random = RandomNumberGenerator.Create()) random.GetBytes(bytes);
            return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }

        public static string HashSha256(string rawNonce)
        {
            using (var sha = SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(Encoding.ASCII.GetBytes(rawNonce))).Replace("-", "").ToLowerInvariant();
        }
    }
}
