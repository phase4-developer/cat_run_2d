namespace PlatformLibrary
{
    public enum PlatformReviewResult { Completed, Failed, Unsupported }
}
