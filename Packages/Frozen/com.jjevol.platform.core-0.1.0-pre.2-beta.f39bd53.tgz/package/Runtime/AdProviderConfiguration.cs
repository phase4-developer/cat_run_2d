using System;

namespace PlatformLibrary
{
    public sealed class AdProviderConfiguration
    {
        public string AppId { get; }
        public Func<string> RewardedAdUnitId { get; }
        public Func<string> InterstitialAdUnitId { get; }
        public Func<string> BannerAdUnitId { get; }
        public Action<string, bool> LoadingChanged { get; }
        public AdProviderConfiguration(string appId, Func<string> rewardedAdUnitId, Func<string> interstitialAdUnitId = null, Func<string> bannerAdUnitId = null, Action<string, bool> loadingChanged = null)
        {
            AppId = appId ?? string.Empty;
            RewardedAdUnitId = rewardedAdUnitId ?? (() => string.Empty);
            InterstitialAdUnitId = interstitialAdUnitId ?? (() => string.Empty);
            BannerAdUnitId = bannerAdUnitId ?? (() => string.Empty);
            LoadingChanged = loadingChanged;
        }
    }
}
