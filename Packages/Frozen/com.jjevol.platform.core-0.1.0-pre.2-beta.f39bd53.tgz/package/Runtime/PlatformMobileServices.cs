using System;
using System.Threading.Tasks;

namespace PlatformLibrary
{
    public sealed class PlatformPushMessage
    {
        public string Title { get; }
        public string Body { get; }
        public PlatformPushMessage(string title, string body) { Title = title ?? string.Empty; Body = body ?? string.Empty; }
    }

    public interface IPlatformPushProvider : IDisposable
    {
        string Provider { get; }
        bool IsSupported { get; }
        string ApplicationId { get; }
        bool RegistrationEnabled { get; set; }
        event Action<string> TokenReceived;
        event Action<PlatformPushMessage> MessageReceived;
        void Initialize();
        Task RequestPermissionAsync();
        Task<string> GetTokenAsync();
        Task DeleteTokenAsync();
        Task SubscribeAsync(string topic);
        Task UnsubscribeAsync(string topic);
    }

    public sealed class UnsupportedPushProvider : IPlatformPushProvider
    {
        public string Provider { get; }
        public bool IsSupported => false;
        public string ApplicationId => string.Empty;
        public bool RegistrationEnabled { get => false; set => throw new NotSupportedException("unsupported"); }
        public event Action<string> TokenReceived { add { } remove { } }
        public event Action<PlatformPushMessage> MessageReceived { add { } remove { } }
        public UnsupportedPushProvider(string provider) { Provider = provider ?? throw new ArgumentNullException(nameof(provider)); }
        public void Initialize() => throw new NotSupportedException("unsupported");
        public Task RequestPermissionAsync() => Task.FromException(new NotSupportedException("unsupported"));
        public Task<string> GetTokenAsync() => Task.FromException<string>(new NotSupportedException("unsupported"));
        public Task DeleteTokenAsync() => Task.FromException(new NotSupportedException("unsupported"));
        public Task SubscribeAsync(string topic) => Task.FromException(new NotSupportedException("unsupported"));
        public Task UnsubscribeAsync(string topic) => Task.FromException(new NotSupportedException("unsupported"));
        public void Dispose() { }
    }

    public interface IPlatformHapticsProvider
    {
        bool IsSupported { get; }
        bool TryPulse(float lowFrequency, float highFrequency, float seconds);
    }

    public sealed class UnsupportedHapticsProvider : IPlatformHapticsProvider
    {
        public bool IsSupported => false;
        public bool TryPulse(float lowFrequency, float highFrequency, float seconds) => false;
    }

    public interface IPlatformDeepLinkProvider : IDisposable
    {
        bool IsSupported { get; }
        string CurrentUrl { get; }
        event Action<string> LinkActivated;
    }

    public sealed class UnsupportedDeepLinkProvider : IPlatformDeepLinkProvider
    {
        public bool IsSupported => false;
        public string CurrentUrl => string.Empty;
        public event Action<string> LinkActivated { add { } remove { } }
        public void Dispose() { }
    }
}
