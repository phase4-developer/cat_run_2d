using System;
using System.Collections;
using System.Collections.Generic;


namespace jjevol
{
    public sealed class ADRevenuePaidEventData
    {
        public string AdPlatform { get; private set; }
        public string AdSource { get; private set; }
        public string AdUnitId { get; private set; }
        public string AdFormat { get; private set; }
        public double Revenue { get; private set; }
        public string CurrencyCode { get; private set; }
        public string Placement { get; private set; }

        public ADRevenuePaidEventData(
            string adPlatform,
            string adSource,
            string adUnitId,
            string adFormat,
            double revenue,
            string currencyCode,
            string placement = "")
        {
            AdPlatform = adPlatform ?? string.Empty;
            AdSource = adSource ?? string.Empty;
            AdUnitId = adUnitId ?? string.Empty;
            AdFormat = adFormat ?? string.Empty;
            Revenue = revenue;
            CurrencyCode = currencyCode ?? string.Empty;
            Placement = placement ?? string.Empty;
        }
    }

    [Serializable]
    public struct ADRewardRequest
    {
        public string adUnitId;
        public string placement;
        public string userId;
        public string customData;
        public string requestId;
        public bool useServerSideVerification;

        public bool HasServerSideVerificationData =>
            useServerSideVerification ||
            !string.IsNullOrEmpty(userId) ||
            !string.IsNullOrEmpty(customData);

        public ADRewardRequest(
            string adUnitId,
            string placement = "",
            string userId = "",
            string customData = "",
            string requestId = "",
            bool useServerSideVerification = false)
        {
            this.adUnitId = adUnitId ?? string.Empty;
            this.placement = placement ?? string.Empty;
            this.userId = userId ?? string.Empty;
            this.customData = customData ?? string.Empty;
            this.requestId = requestId ?? string.Empty;
            this.useServerSideVerification = useServerSideVerification;
        }

        public static ADRewardRequest Default(string adUnitId = "")
        {
            return new ADRewardRequest(adUnitId);
        }
    }

    [Serializable]
    public struct ADRewardResult
    {
        public bool success;
        public int code;
        public string errorMessage;

        public string adUnitId;
        public string placement;
        public string userId;
        public string customData;
        public string requestId;

        public bool rewardGranted;
        public string rewardType;
        public double rewardAmount;

        public bool serverVerificationRequested;
        public bool serverVerified;
        public bool isSkipped;

        public ADRewardResult(
            bool success,
            int code,
            string errorMessage,
            string adUnitId,
            string placement,
            string userId,
            string customData,
            string requestId,
            bool rewardGranted,
            string rewardType,
            double rewardAmount,
            bool serverVerificationRequested,
            bool serverVerified,
            bool isSkipped = false)
        {
            this.success = success;
            this.code = code;
            this.errorMessage = errorMessage ?? string.Empty;

            this.adUnitId = adUnitId ?? string.Empty;
            this.placement = placement ?? string.Empty;
            this.userId = userId ?? string.Empty;
            this.customData = customData ?? string.Empty;
            this.requestId = requestId ?? string.Empty;

            this.rewardGranted = rewardGranted;
            this.rewardType = rewardType ?? string.Empty;
            this.rewardAmount = rewardAmount;

            this.serverVerificationRequested = serverVerificationRequested;
            this.serverVerified = serverVerified;
            this.isSkipped = isSkipped;
        }
    }

    public interface IADManager
    {
        public bool initComplete { get; }

        public bool IsRewardAdReady { get; }
        public bool IsRewardAdLoading { get; }

        event Action<ADRevenuePaidEventData> OnAdRevenuePaid;

        void ShowRewardAD(ADRewardRequest request, Action<ADRewardResult> callBack);

        void RequestRewardAD(string adUnitId = "", Action<ADRewardResult> callBack = null);

        void RequestRewardAD(ADRewardRequest request, Action<ADRewardResult> callBack = null);

        void Init();
    }
}
