using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlatformLibrary
{
    public enum PlatformStoreProductType { Consumable, NonConsumable, Subscription }
    public enum PlatformStoreOrderState { Pending, Confirmed, Failed, Deferred }

    public sealed class PlatformStoreProductDefinition
    {
        public string Id { get; }
        public string StoreSpecificId { get; }
        public PlatformStoreProductType Type { get; }
        public PlatformStoreProductDefinition(string id, string storeSpecificId, PlatformStoreProductType type)
        {
            if (string.IsNullOrWhiteSpace(id)) throw new ArgumentException("A product ID is required.", nameof(id));
            if (string.IsNullOrWhiteSpace(storeSpecificId)) throw new ArgumentException("A store product ID is required.", nameof(storeSpecificId));
            Id = id; StoreSpecificId = storeSpecificId; Type = type;
        }
    }

    public sealed class PlatformStoreProduct
    {
        public PlatformStoreProductDefinition Definition { get; }
        public bool AvailableToPurchase { get; }
        public string LocalizedPrice { get; }
        public decimal Price { get; }
        public string Currency { get; }
        public string Title { get; }
        public PlatformStoreProduct(PlatformStoreProductDefinition definition, bool availableToPurchase, string localizedPrice, decimal price, string currency, string title)
        {
            Definition = definition ?? throw new ArgumentNullException(nameof(definition));
            AvailableToPurchase = availableToPurchase; LocalizedPrice = localizedPrice ?? string.Empty;
            Price = price; Currency = currency ?? string.Empty; Title = title ?? string.Empty;
        }
    }

    public sealed class PlatformStoreOrder
    {
        public string Key { get; }
        public PlatformStoreProduct Product { get; }
        public string TransactionId { get; }
        public string Receipt { get; }
        public string VerificationData { get; }
        public PlatformStoreOrderState State { get; }
        public string Error { get; }
        public PlatformStoreOrder(string key, PlatformStoreProduct product, string transactionId, string receipt, string verificationData, PlatformStoreOrderState state, string error = null)
        {
            if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("An order key is required.", nameof(key));
            Key = key; Product = product; TransactionId = transactionId ?? string.Empty;
            Receipt = receipt ?? string.Empty; VerificationData = verificationData ?? string.Empty; State = state; Error = error ?? string.Empty;
        }
    }

    public sealed class PlatformStoreOrders
    {
        public IReadOnlyList<PlatformStoreOrder> PendingOrders { get; }
        public IReadOnlyList<PlatformStoreOrder> ConfirmedOrders { get; }
        public PlatformStoreOrders(IReadOnlyList<PlatformStoreOrder> pendingOrders, IReadOnlyList<PlatformStoreOrder> confirmedOrders)
        {
            PendingOrders = pendingOrders ?? Array.Empty<PlatformStoreOrder>();
            ConfirmedOrders = confirmedOrders ?? Array.Empty<PlatformStoreOrder>();
        }
    }

    public interface IPlatformStoreProvider : IDisposable
    {
        string Provider { get; }
        bool IsSupported { get; }
        bool IsConnected { get; }
        string StoreCode { get; }
        event Action<IReadOnlyList<PlatformStoreProduct>> ProductsFetched;
        event Action<int, string> ProductsFetchFailed;
        event Action<PlatformStoreOrder> PurchasePending;
        event Action<PlatformStoreOrder> PurchaseFailed;
        event Action<PlatformStoreOrder> PurchaseDeferred;
        event Action<PlatformStoreOrder> PurchaseConfirmed;
        event Action<PlatformStoreOrders> PurchasesFetched;
        event Action<string> PurchasesFetchFailed;
        event Action<string> StoreDisconnected;
        Task ConnectAsync();
        void FetchProducts(IReadOnlyList<PlatformStoreProductDefinition> products);
        PlatformStoreProduct GetProduct(string id);
        void PurchaseProduct(string id, string developerPayload = null);
        void FetchPurchases();
        void RestoreTransactions(Action<bool, string> callback);
        void ConfirmPurchase(PlatformStoreOrder order);
    }

    public sealed class UnsupportedStoreProvider : IPlatformStoreProvider
    {
        public string Provider { get; }
        public bool IsSupported => false;
        public bool IsConnected => false;
        public string StoreCode => string.Empty;
        public event Action<IReadOnlyList<PlatformStoreProduct>> ProductsFetched { add { } remove { } }
        public event Action<int, string> ProductsFetchFailed { add { } remove { } }
        public event Action<PlatformStoreOrder> PurchasePending { add { } remove { } }
        public event Action<PlatformStoreOrder> PurchaseFailed { add { } remove { } }
        public event Action<PlatformStoreOrder> PurchaseDeferred { add { } remove { } }
        public event Action<PlatformStoreOrder> PurchaseConfirmed { add { } remove { } }
        public event Action<PlatformStoreOrders> PurchasesFetched { add { } remove { } }
        public event Action<string> PurchasesFetchFailed { add { } remove { } }
        public event Action<string> StoreDisconnected { add { } remove { } }
        public UnsupportedStoreProvider(string provider)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            Provider = provider;
        }
        public Task ConnectAsync() => Task.FromException(new NotSupportedException("unsupported"));
        public void FetchProducts(IReadOnlyList<PlatformStoreProductDefinition> products) => throw new NotSupportedException("unsupported");
        public PlatformStoreProduct GetProduct(string id) => null;
        public void PurchaseProduct(string id, string developerPayload = null) => throw new NotSupportedException("unsupported");
        public void FetchPurchases() => throw new NotSupportedException("unsupported");
        public void RestoreTransactions(Action<bool, string> callback) => callback?.Invoke(false, "unsupported");
        public void ConfirmPurchase(PlatformStoreOrder order) => throw new NotSupportedException("unsupported");
        public void Dispose() { }
    }
}
