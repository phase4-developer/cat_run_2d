namespace PlatformLibrary
{
    public readonly struct PlatformIdentity
    {
        public string Provider { get; }
        public string UserId { get; }

        public PlatformIdentity(string provider, string userId)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new System.ArgumentException("A provider is required.", nameof(provider));
            if (string.IsNullOrWhiteSpace(userId)) throw new System.ArgumentException("A platform user ID is required.", nameof(userId));
            Provider = provider;
            UserId = userId;
        }
    }

    public interface IPlatformIdentityProvider
    {
        string Provider { get; }
        bool TryGetUserId(out string userId);
    }
}
