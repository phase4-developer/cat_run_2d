using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlatformLibrary
{
    public enum LoginAvailability { Disabled, UnsupportedPlatform, MissingConfiguration, MissingDependency, Initializing, TemporarilyUnavailable, Available }

    public sealed class PlatformLoginOptions
    {
        public bool GoogleEnabled { get; }
        public bool AppleEnabled { get; }
        public bool FirebaseAuthEnabled { get; }
        public bool AnonymousSignInEnabled { get; }
        public PlatformLoginOptions(bool google, bool apple, bool firebase, bool anonymous)
        {
            GoogleEnabled = google; AppleEnabled = apple; FirebaseAuthEnabled = firebase; AnonymousSignInEnabled = firebase && anonymous;
        }
        public bool IsEnabled(string provider) => provider == "google" ? GoogleEnabled : provider == "apple" ? AppleEnabled : provider == "anonymous" ? AnonymousSignInEnabled : false;
    }

    public enum BackendAuthStatus { Success, Failed, CredentialAlreadyInUse, NoCurrentUser, SessionChanged, Cancelled, Busy }

    public sealed class BackendAuthSession
    {
        public string UserId { get; }
        public string IdToken { get; }
        public string Email { get; }
        public bool IsAnonymous { get; }
        public IReadOnlyList<string> Providers { get; }
        public BackendAuthSession(string userId, string idToken, string email, bool anonymous, IEnumerable<string> providers)
        {
            UserId = userId; IdToken = idToken; Email = email ?? string.Empty; IsAnonymous = anonymous;
            Providers = new List<string>(providers ?? Array.Empty<string>()).AsReadOnly();
        }
    }

    public sealed class BackendAuthResult
    {
        public bool Success => Status == BackendAuthStatus.Success;
        public BackendAuthStatus Status { get; }
        public BackendAuthSession Session { get; }
        public string Error { get; }
        public string Phase { get; }
        public int ErrorCode { get; }
        public string ExceptionType { get; }
        public string Continuation { get; }
        public bool CredentialCreated { get; }
        public bool LinkAttempted { get; }
        public bool ProviderLinked { get; }
        public bool PostLinkFailed { get; }
        public BackendAuthResult(BackendAuthStatus status, BackendAuthSession session = null, string error = null, string phase = "firebase_session", int errorCode = 0, string exceptionType = null, string continuation = null, bool credentialCreated = false, bool linkAttempted = false, bool providerLinked = false, bool postLinkFailed = false)
        {
            Status = status; Session = session; Error = error ?? string.Empty; Phase = phase; ErrorCode = errorCode; ExceptionType = exceptionType ?? "None";
            Continuation = continuation; CredentialCreated = credentialCreated; LinkAttempted = linkAttempted; ProviderLinked = providerLinked; PostLinkFailed = postLinkFailed;
        }
    }

    public interface IBackendAuthProvider : IDisposable
    {
        LoginAvailability Availability { get; }
        string Environment { get; }
        BackendAuthSession CurrentSession { get; }
        Task<BackendAuthResult> SignInAnonymousAsync();
        Task<BackendAuthResult> RestoreAsync(string provider);
        Task<BackendAuthResult> SignInAsync(PlatformAuthCredential credential);
        Task<BackendAuthResult> LinkAsync(PlatformAuthCredential credential);
        Task<BackendAuthResult> ContinueAsync(string continuation);
        Task<BackendAuthResult> RefreshTokenAsync(bool forceRefresh);
        Task<BackendAuthResult> UnlinkAsync(string provider);
        void DiscardContinuation(string continuation);
        void Cancel();
        void SignOut();
    }
}
