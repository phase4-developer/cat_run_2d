using System;
using System.Collections.Generic;

namespace PlatformLibrary
{
    public sealed class PlatformServiceResolver : IDisposable
    {
        private readonly Dictionary<string, IPlatformIdentityProvider> _identityProviders = new Dictionary<string, IPlatformIdentityProvider>(StringComparer.Ordinal);

        private readonly Dictionary<string, IPlatformAuthProvider> _authProviders = new Dictionary<string, IPlatformAuthProvider>(StringComparer.Ordinal);

        private readonly Dictionary<string, IPlatformStoreProvider> _storeProviders = new Dictionary<string, IPlatformStoreProvider>(StringComparer.Ordinal);

        private readonly Dictionary<string, IPlatformPushProvider> _pushProviders = new Dictionary<string, IPlatformPushProvider>(StringComparer.Ordinal);
        private IPlatformHapticsProvider _haptics;
        private IPlatformDeepLinkProvider _deepLinks;
        public IPlatformHapticsProvider Haptics => _haptics ?? new UnsupportedHapticsProvider();
        public IPlatformDeepLinkProvider DeepLinks => _deepLinks ?? new UnsupportedDeepLinkProvider();

        public void RegisterPush(IPlatformPushProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            if (string.IsNullOrWhiteSpace(provider.Provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            if (_pushProviders.ContainsKey(provider.Provider)) throw new InvalidOperationException("The push provider is already registered: " + provider.Provider);
            _pushProviders.Add(provider.Provider, provider);
        }

        public IPlatformPushProvider GetPush(string provider)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            return _pushProviders.TryGetValue(provider, out IPlatformPushProvider implementation) ? implementation : new UnsupportedPushProvider(provider);
        }

        public void RegisterHaptics(IPlatformHapticsProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            if (_haptics != null) throw new InvalidOperationException("The haptics provider is already registered.");
            _haptics = provider;
        }

        public void RegisterDeepLinks(IPlatformDeepLinkProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            if (_deepLinks != null) throw new InvalidOperationException("The deep link provider is already registered.");
            _deepLinks = provider;
        }

        public void RegisterStore(IPlatformStoreProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            if (string.IsNullOrWhiteSpace(provider.Provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            if (_storeProviders.ContainsKey(provider.Provider)) throw new InvalidOperationException("The store provider is already registered: " + provider.Provider);
            _storeProviders.Add(provider.Provider, provider);
        }

        public IPlatformStoreProvider GetStore(string provider)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            return _storeProviders.TryGetValue(provider, out IPlatformStoreProvider implementation) ? implementation : new UnsupportedStoreProvider(provider);
        }

        public void RegisterIdentity(IPlatformIdentityProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            if (string.IsNullOrWhiteSpace(provider.Provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            if (_identityProviders.ContainsKey(provider.Provider)) throw new InvalidOperationException("The identity provider is already registered: " + provider.Provider);
            _identityProviders.Add(provider.Provider, provider);
        }

        public void RegisterAuth(IPlatformAuthProvider provider)
        {
            if (provider == null) throw new ArgumentNullException(nameof(provider));
            if (string.IsNullOrWhiteSpace(provider.Provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            if (_authProviders.ContainsKey(provider.Provider)) throw new InvalidOperationException("The auth provider is already registered: " + provider.Provider);
            _authProviders.Add(provider.Provider, provider);
        }

        /// <summary>Find a registered provider. Unlike GetAuth, this tells a missing registration from an unsupported provider.</summary>
        public bool TryGetAuth(string provider, out IPlatformAuthProvider implementation)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            return _authProviders.TryGetValue(provider, out implementation);
        }

        public IPlatformAuthProvider GetAuth(string provider)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            return _authProviders.TryGetValue(provider, out IPlatformAuthProvider implementation) ? implementation : new UnsupportedAuthProvider(provider);
        }

        public void Dispose()
        {
            foreach (var provider in _storeProviders.Values) provider.Dispose();
            foreach (var provider in _authProviders.Values) provider.Cancel();
            foreach (var provider in _pushProviders.Values) provider.Dispose();
            _deepLinks?.Dispose();
            _storeProviders.Clear(); _authProviders.Clear(); _identityProviders.Clear(); _pushProviders.Clear();
            _haptics = null; _deepLinks = null;
        }

        public bool TryGetIdentity(string provider, out PlatformIdentity identity)
        {
            identity = default;
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            if (!_identityProviders.TryGetValue(provider, out IPlatformIdentityProvider implementation) || !implementation.TryGetUserId(out string userId) || string.IsNullOrWhiteSpace(userId))
                return false;
            identity = new PlatformIdentity(provider, userId);
            return true;
        }
    }
}
