using System;

namespace PlatformLibrary
{
    public sealed class PlatformAuthRequest
    {
        public string RequestId { get; }
        public bool Silent { get; }
        public string CachedUserId { get; }
        public bool ForceInteractive { get; }

        public PlatformAuthRequest(string requestId, bool silent = false, string cachedUserId = null, bool forceInteractive = false)
        {
            if (string.IsNullOrWhiteSpace(requestId)) throw new ArgumentException("A request ID is required.", nameof(requestId));
            RequestId = requestId;
            Silent = silent;
            CachedUserId = cachedUserId;
            ForceInteractive = forceInteractive;
        }
    }

    public sealed class PlatformAuthCredential
    {
        public string Provider { get; }
        public string Subject { get; }
        public string Token { get; }
        public string AuthorizationCode { get; }
        public string RawNonce { get; }
        public string LoginMethod { get; }

        public PlatformAuthCredential(string provider, string subject, string token, string authorizationCode = null, string rawNonce = null, string loginMethod = null)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            if (string.IsNullOrWhiteSpace(token)) throw new ArgumentException("A credential token is required.", nameof(token));
            Provider = provider;
            Subject = subject ?? string.Empty;
            Token = token;
            AuthorizationCode = authorizationCode;
            RawNonce = rawNonce;
            LoginMethod = loginMethod;
        }
    }

    public sealed class PlatformAuthProgress
    {
        public string Code { get; }
        public string ExceptionType { get; }
        public string CredentialType { get; }
        public bool RequestStarted { get; }
        public bool CredentialReceived { get; }

        public PlatformAuthProgress(string code, string exceptionType = "None", string credentialType = "none", bool requestStarted = false, bool credentialReceived = false)
        {
            Code = code;
            ExceptionType = exceptionType;
            CredentialType = credentialType;
            RequestStarted = requestStarted;
            CredentialReceived = credentialReceived;
        }
    }

    public sealed class PlatformAuthResult
    {
        public bool Success => Credential != null;
        public PlatformAuthCredential Credential { get; }
        public string Error { get; }
        public PlatformAuthProgress Progress { get; }
        public bool CachedIdentityInvalidated { get; }

        public PlatformAuthResult(PlatformAuthCredential credential, string error = null, PlatformAuthProgress progress = null, bool cachedIdentityInvalidated = false)
        {
            if (credential == null && string.IsNullOrWhiteSpace(error)) throw new ArgumentException("A failed authentication requires an error.", nameof(error));
            if (credential != null && !string.IsNullOrEmpty(error)) throw new ArgumentException("A successful authentication cannot contain an error.", nameof(error));
            Credential = credential;
            Error = error ?? string.Empty;
            Progress = progress;
            CachedIdentityInvalidated = cachedIdentityInvalidated;
        }
    }

    public interface IPlatformAuthProvider
    {
        string Provider { get; }
        bool IsSupported { get; }
        event Action CredentialsRevoked;
        void SignIn(PlatformAuthRequest request, Action<PlatformAuthResult> callback, Action<PlatformAuthProgress> progress = null);
        void Cancel();
        void Update();
    }

    public sealed class UnsupportedAuthProvider : IPlatformAuthProvider
    {
        public string Provider { get; }
        public bool IsSupported => false;
        public event Action CredentialsRevoked { add { } remove { } }

        public UnsupportedAuthProvider(string provider)
        {
            if (string.IsNullOrWhiteSpace(provider)) throw new ArgumentException("A provider is required.", nameof(provider));
            Provider = provider;
        }

        public void SignIn(PlatformAuthRequest request, Action<PlatformAuthResult> callback, Action<PlatformAuthProgress> progress = null)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            callback?.Invoke(new PlatformAuthResult(null, "unsupported"));
        }

        public void Cancel() { }
        public void Update() { }
    }
}
