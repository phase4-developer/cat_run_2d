using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlatformLibrary
{
    public sealed class LoginService : IDisposable
    {
        private readonly PlatformLoginOptions _options;
        private readonly PlatformServiceResolver _resolver;
        private readonly Dictionary<string, Func<LoginAvailability>> _availability = new Dictionary<string, Func<LoginAvailability>>();
        private readonly Dictionary<string, Func<IPlatformAuthProvider>> _factories = new Dictionary<string, Func<IPlatformAuthProvider>>();
        private readonly HashSet<string> _registered = new HashSet<string>();
        private string[] _updateTargets = Array.Empty<string>();
        private IBackendAuthProvider _backend;
        private Action<PlatformAuthResult> _completion;
        private string _activeProvider;
        private int _generation;
        private bool _disposed;
        private bool _backendPending;
        private readonly LoginAvailability _backendUnavailable;
        public IBackendAuthProvider Backend => _backend;

        public LoginService(PlatformLoginOptions options, PlatformServiceResolver resolver, LoginAvailability backendUnavailable = LoginAvailability.Initializing)
        {
            _options = options;
            _backendUnavailable = backendUnavailable;
            _resolver = resolver ?? throw new ArgumentNullException(nameof(resolver));
        }

        public void ConfigureProvider(string provider, Func<LoginAvailability> availability, Func<IPlatformAuthProvider> factory)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(LoginService));
            if (_availability.ContainsKey(provider)) throw new InvalidOperationException("Provider already configured.");
            _availability.Add(provider, availability ?? throw new ArgumentNullException(nameof(availability)));
            _factories.Add(provider, factory);
            GetAvailability(provider);
        }

        public LoginAvailability GetAvailability(string provider)
        {
            if (_disposed) return LoginAvailability.TemporarilyUnavailable;
            if (_options == null) return LoginAvailability.MissingConfiguration;
            if (!_options.IsEnabled(provider)) return LoginAvailability.Disabled;
            if (provider == "anonymous") return GetBackendAvailability();
            if (!_availability.TryGetValue(provider, out var check)) return LoginAvailability.MissingDependency;
            LoginAvailability state = check();
            if (state != LoginAvailability.Available) return state;
            if (!EnsureRegistered(provider)) return LoginAvailability.MissingDependency;
            if (!_resolver.GetAuth(provider).IsSupported) return LoginAvailability.MissingDependency;
            return _completion != null || _backendPending ? LoginAvailability.TemporarilyUnavailable : LoginAvailability.Available;
        }

        // The resolver owns registrations and can outlive this service (relogin) or be cleared while it lives.
        // Reuse what it holds, and build a provider only when it holds none.
        private bool EnsureRegistered(string provider)
        {
            if (_resolver.TryGetAuth(provider, out _))
            {
                TrackUpdates(provider, true);
                return true;
            }
            TrackUpdates(provider, false);
            if (_factories[provider] == null) return false;

            IPlatformAuthProvider created = null;
            try
            {
                created = _factories[provider]();
                _resolver.RegisterAuth(created);
            }
            catch
            {
                (created as IDisposable)?.Dispose();
                return false;
            }
            TrackUpdates(provider, true);
            return true;
        }

        private void TrackUpdates(string provider, bool active)
        {
            if (active ? !_registered.Add(provider) : !_registered.Remove(provider)) return;
            var targets = new string[_registered.Count];
            _registered.CopyTo(targets);
            _updateTargets = targets;
        }

        public LoginAvailability GetBackendAvailability()
        {
            if (_disposed) return LoginAvailability.TemporarilyUnavailable;
            if (_options == null) return LoginAvailability.MissingConfiguration;
            if (!_options.FirebaseAuthEnabled) return LoginAvailability.Disabled;
            return _backendPending || _completion != null ? LoginAvailability.TemporarilyUnavailable : _backend?.Availability ?? _backendUnavailable;
        }

        public void SetBackend(IBackendAuthProvider backend)
        {
            if (backend != null && (_options == null || !_options.FirebaseAuthEnabled)) throw new InvalidOperationException("Backend authentication is disabled.");
            if (ReferenceEquals(_backend, backend)) return;
            Cancel();
            _backend?.Dispose();
            _backend = backend;
        }

        public void RequestCredential(string provider, PlatformAuthRequest request, Action<PlatformAuthResult> completed, Action<PlatformAuthProgress> progress = null)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (_completion != null) { completed?.Invoke(new PlatformAuthResult(null, "busy")); return; }
            var available = GetAvailability(provider);
            if (available != LoginAvailability.Available) { completed?.Invoke(new PlatformAuthResult(null, available.ToString())); return; }
            int generation = ++_generation;
            _activeProvider = provider;
            _completion = completed ?? (_ => { });
            try
            {
                _resolver.GetAuth(provider).SignIn(request, result =>
                {
                    if (_disposed || generation != _generation || _completion == null) return;
                    var callback = _completion;
                    _completion = null; _activeProvider = null;
                    ++_generation;
                    callback(result);
                }, value => { if (!_disposed && generation == _generation && _completion != null) progress?.Invoke(value); });
            }
            catch
            {
                if (generation != _generation || _completion == null) throw;
                var callback = _completion;
                _completion = null; _activeProvider = null; ++_generation;
                callback(new PlatformAuthResult(null, "provider_error"));
            }
        }

        public Task<BackendAuthResult> AuthenticateAsync(PlatformAuthCredential credential)
        {
            if (credential == null) throw new ArgumentNullException(nameof(credential));
            var available = GetAvailability(credential.Provider);
            if (available != LoginAvailability.Available) return Failure(available);
            return GetBackendAvailability() == LoginAvailability.Available ? RunBackend(() => _backend.SignInAsync(credential)) : Failure(GetBackendAvailability());
        }

        public Task<BackendAuthResult> SignInAnonymousAsync() => GetAvailability("anonymous") == LoginAvailability.Available ? RunBackend(() => _backend.SignInAnonymousAsync()) : Failure(GetAvailability("anonymous"));
        public Task<BackendAuthResult> RestoreAsync(string provider) => GetBackendAvailability() == LoginAvailability.Available ? RunBackend(() => _backend.RestoreAsync(provider)) : Failure(GetBackendAvailability());
        public Task<BackendAuthResult> ContinueAsync(string continuation) => GetBackendAvailability() == LoginAvailability.Available ? RunBackend(() => _backend.ContinueAsync(continuation)) : Failure(GetBackendAvailability());
        public Task<BackendAuthResult> LinkAsync(PlatformAuthCredential credential) => GetAvailability(credential.Provider) == LoginAvailability.Available && GetBackendAvailability() == LoginAvailability.Available ? RunBackend(() => _backend.LinkAsync(credential)) : Failure(GetAvailability(credential.Provider) != LoginAvailability.Available ? GetAvailability(credential.Provider) : GetBackendAvailability());
        private async Task<BackendAuthResult> RunBackend(Func<Task<BackendAuthResult>> action)
        {
            int generation = _generation;
            var backend = _backend;
            _backendPending = true;
            try
            {
                var result = await action();
                return !_disposed && generation == _generation && ReferenceEquals(backend, _backend) ? result : new BackendAuthResult(BackendAuthStatus.SessionChanged, error: "session_changed", providerLinked: result.ProviderLinked, postLinkFailed: result.PostLinkFailed);
            }
            finally { _backendPending = false; }
        }
        private static Task<BackendAuthResult> Failure(LoginAvailability state) => Task.FromResult(new BackendAuthResult(BackendAuthStatus.Failed, error: state.ToString()));

        public void Update()
        {
            if (_disposed) return;
            // A provider callback may register another provider, so iterate an array that is replaced, never mutated.
            foreach (var provider in _updateTargets)
            {
                if (_disposed) return;
                _resolver.GetAuth(provider).Update();
            }
        }

        public void Cancel()
        {
            ++_generation;
            var callback = _completion;
            string provider = _activeProvider;
            _completion = null; _activeProvider = null;
            try { if (provider != null) _resolver.GetAuth(provider).Cancel(); }
            finally { _backend?.Cancel(); callback?.Invoke(new PlatformAuthResult(null, "cancelled")); }
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            Cancel();
            _backend?.Dispose(); _backend = null;
        }
    }
}
