# Third party dependencies

No third-party source, SDK binary or paid asset is bundled. Unity engine/package dependencies retain their own terms. See package.json and the consumer lock file for exact dependencies. Newtonsoft, Input System and uGUI are resolved separately where declared; their upstream notices are not removed or replaced.
