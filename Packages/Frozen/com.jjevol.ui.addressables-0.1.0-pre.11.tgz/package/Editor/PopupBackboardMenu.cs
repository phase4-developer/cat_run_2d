using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    /// <summary>
    /// Creates the popup backboard <see cref="UIPopupManager"/> looks for: a direct child of popupRoot named exactly "Backboard",
    /// full stretch, a translucent Image with Raycast Target on, saved inactive. Colour and click behaviour stay game-owned.
    /// </summary>
    internal static class PopupBackboardMenu
    {
        internal const string BackboardName = "Backboard";
        internal static readonly Color DefaultColor = new Color(0f, 0f, 0f, 0.6f);

        [MenuItem("GameObject/UI/JJEvol/Popup Backboard", false, 14)]
        private static void CreateMenu(MenuCommand command)
        {
            var selected = command.context as GameObject ?? Selection.activeGameObject;
            var backboard = Create(selected ? selected.transform : null, out var problem);
            if (backboard == null)
            {
                Debug.LogWarning(problem, selected);
                return;
            }
            Selection.activeGameObject = backboard;
        }

        /// <summary>Returns the new backboard, or null with the reason when popupRoot is not a RectTransform or already has one.</summary>
        internal static GameObject Create(Transform popupRoot, out string problem)
        {
            problem = null;
            if (!(popupRoot is RectTransform))
            {
                problem = "[PopupBackboard] Select the UIManager's popupRoot (a RectTransform) and run GameObject/UI/JJEvol/Popup Backboard again.";
                return null;
            }
            if (popupRoot.Find(BackboardName) != null)
            {
                problem = $"[PopupBackboard] '{popupRoot.name}' already has a direct child named \"{BackboardName}\".";
                return null;
            }

            var go = new GameObject(BackboardName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.layer = popupRoot.gameObject.layer;
            var rect = (RectTransform)go.transform;
            rect.SetParent(popupRoot, false);
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            rect.SetAsFirstSibling(); // UIPopupManager moves it behind the top popup at run time.
            var image = go.GetComponent<Image>();
            image.color = DefaultColor;
            image.raycastTarget = true;
            go.SetActive(false);
            Undo.RegisterCreatedObjectUndo(go, "Create Popup Backboard");
            return go;
        }
    }
}
