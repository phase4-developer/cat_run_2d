using System.Collections.Generic;
using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// Layout rule for the root RectTransform of a screen or popup Prefab instantiated by the UI managers.
    /// A full-stretch root (anchorMin 0,0 and anchorMax 1,1) is fitted to its parent. Any other root keeps the
    /// position, size and scale authored in the Prefab.
    /// </summary>
    public static class UIRootLayout
    {
        /// <summary>True when the root stretches to the whole parent (anchorMin 0,0 and anchorMax 1,1).</summary>
        public static bool IsFullStretch(RectTransform root) =>
            root != null && root.anchorMin == Vector2.zero && root.anchorMax == Vector2.one;

        /// <summary>Fits a full-stretch root to its parent (position 0, scale 1, size offsets 0). Returns false and changes nothing otherwise.</summary>
        public static bool FitToParentIfStretched(RectTransform root)
        {
            if (!IsFullStretch(root)) return false;
            root.localPosition = Vector3.zero;
            root.localScale = Vector3.one;
            root.sizeDelta = Vector2.zero;
            return true;
        }

        /// <summary>
        /// True when the instance root itself has a Canvas with Override Sorting on. Such a root draws by its own
        /// Sort Order instead of its layer's sibling order (README "화면 층"). Children are not checked.
        /// </summary>
        internal static bool HasOverrideSortingCanvas(GameObject root) =>
            root != null && root.TryGetComponent<Canvas>(out var canvas) && canvas.overrideSorting;

        /// <summary>
        /// Logs one warning per Prefab key in <paramref name="warnedKeys"/> when <see cref="HasOverrideSortingCanvas"/> is true.
        /// Returns true only when it logged. Changes nothing on the instance.
        /// </summary>
        internal static bool WarnOverrideSortingOnce(string owner, string key, GameObject root, HashSet<string> warnedKeys)
        {
            if (!HasOverrideSortingCanvas(root) || warnedKeys == null || !warnedKeys.Add(key ?? string.Empty)) return false;
            Debug.LogWarning($"[{owner}] Prefab '{key}' root '{HierarchyPath(root.transform)}' has a Canvas with Override Sorting on; it draws by its own Sort Order instead of its layer's sibling order, so the popup Backboard can end up under it or it can hide under its layer. Remove that Canvas from the Prefab root, or move it to a child (com.jjevol.ui.addressables README \"화면 층\").", root);
            return true;
        }

        /// <summary>Slash-separated names from the scene root down to <paramref name="target"/>.</summary>
        internal static string HierarchyPath(Transform target)
        {
            var path = target.name;
            for (var parent = target.parent; parent != null; parent = parent.parent)
                path = parent.name + "/" + path;
            return path;
        }
    }
}
