using System.Reflection;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace jjevol.UI.Tests
{
    /// <summary>The Popup Backboard menu builds the child UIPopupManager finds, in the README's recommended setup.</summary>
    public sealed class PopupBackboardMenuEditTests
    {
        private GameObject _root;
        [SetUp]public void SetUp(){_root=new GameObject("popups",typeof(RectTransform));_root.layer=5;}
        [TearDown]public void TearDown(){if(_root)Object.DestroyImmediate(_root);}

        private static GameObject Create(Transform parent,out string problem)
        {
            var type=System.Type.GetType("jjevol.PopupBackboardMenu, JJEvol.UI.Addressables.Editor",true);
            var args=new object[]{parent,null};
            var go=(GameObject)type.GetMethod("Create",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,args);
            problem=(string)args[1];
            return go;
        }

        [Test]
        public void CreatesAnInactiveFullStretchRaycastBackboardAsADirectChild()
        {
            var go=Create(_root.transform,out var problem);
            Assert.That(go,Is.Not.Null,problem);
            Assert.That(_root.transform.Find("Backboard"),Is.EqualTo(go.transform),"UIPopupManager finds it by Transform.Find(\"Backboard\").");
            Assert.That(go.activeSelf,Is.False);
            Assert.That(go.layer,Is.EqualTo(5));
            var rect=(RectTransform)go.transform;
            Assert.That(UIRootLayout.IsFullStretch(rect),Is.True);
            Assert.That(rect.offsetMin,Is.EqualTo(Vector2.zero));Assert.That(rect.offsetMax,Is.EqualTo(Vector2.zero));
            var image=go.GetComponent<Image>();
            Assert.That(image.raycastTarget,Is.True);
            Assert.That(image.color.a,Is.InRange(0.01f,0.99f),"Translucent by default; the game owns the look.");
        }

        [Test]
        public void RefusesASecondBackboardAndANonRectParent()
        {
            Assert.That(Create(_root.transform,out _),Is.Not.Null);
            Assert.That(Create(_root.transform,out var twice),Is.Null);
            StringAssert.Contains("already has",twice);
            var plain=new GameObject("plain");
            try
            {
                Assert.That(Create(plain.transform,out var notRect),Is.Null);
                StringAssert.Contains("RectTransform",notRect);
                Assert.That(Create(null,out _),Is.Null);
            }
            finally{Object.DestroyImmediate(plain);}
        }
    }
}
