# Changelog

## 0.1.0-pre.3 - 2026-11-10

- The Spine runtime is public (only the editor tool is paid), so the usage-rights block is removed. Consumers install spine-csharp and spine-unity from the spine-runtimes Git repository; nothing is copied into this package.
- Added `JJEvol.Effects.Spine.Tests.Runtime` PlayMode tests on the real runtimes with a hand-written bones-only skeleton: adapter factory, non-loop completion once, loop never completes, animation and skin index clamping, pause and authored timeScale restore, StopAndClear.
- Added `Hosts/SpineValidationHost` (6000.3.9f1) with both runtimes pinned to spine-runtimes `b81e5a58ed38704aee4f866f0e0ac672623ce914`.

Unity 6000.3.9f1 on `Hosts/SpineValidationHost` with the public Spine runtime from its Git URL (commit `b81e5a58ed38704aee4f866f0e0ac672623ce914`): job `pkg1110-spine-02` compile, EditMode 5/5 and PlayMode 7/7 passed. The first run, `pkg1110-spine-01`, failed only because the runtime created `Assets/Editor/SpineSettings.asset` in the Host; that file is now committed. Real game skeletons, `SkeletonGraphic` in a game and Player are NOT_RUN.

## 0.1.0-pre.2 - 2026-11-06

- Implemented renderer state restore. Resume returns to the prefab timeScale. Vendor SDK compile and run are NOT_RUN.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.1 — unvalidated local candidate

- Move the original SpineEffectRenderer and its unchanged meta into a separate optional UPM.
- Prepare an optional factory registration and three Editor contract tests.
- Preserve original renderer behavior without speculative lifetime fixes.
- SDK execution blocked by unconfirmed Spine usage rights; no release, tarball, or snapshot produced.
