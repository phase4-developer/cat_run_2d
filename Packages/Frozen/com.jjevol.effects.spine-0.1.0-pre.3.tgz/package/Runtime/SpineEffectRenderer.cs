using System;
using Spine.Unity;
using UnityEngine;
using UnityEngine.Rendering;

namespace jjevol.Effect.Renderers
{
    public sealed class SpineEffectRenderer : MonoBehaviour, IEffectRenderer, IEffectRendererStateRestore
    {
        SkeletonAnimation _skel;
        SkeletonGraphic _graphic;
        SortingGroup _sortingGroup;
        Spine.TrackEntry _track;

        // Authored values. Pause and pool return go back to these instead of a fixed 1.
        float _skelTimeScale = 1f;
        float _graphicTimeScale = 1f;
        readonly EffectSortingSnapshot _sorting = new();

        public Transform Root => transform;

        void IEffectRendererStateRestore.CaptureState()
        {
            if (_skel) _skelTimeScale = _skel.timeScale;
            if (_graphic) _graphicTimeScale = _graphic.timeScale;
            _sorting.Capture(gameObject);
        }

        void IEffectRendererStateRestore.RestoreState()
        {
            if (_skel) _skel.timeScale = _skelTimeScale;
            if (_graphic) _graphic.timeScale = _graphicTimeScale;
            _sorting.Restore();
        }

        void Awake()
        {
            _skel = GetComponent<SkeletonAnimation>();
            _graphic = GetComponent<SkeletonGraphic>();
            _sortingGroup = GetComponent<SortingGroup>();
        }

        public void SetSorting(string layer, int order)
        {
            if (string.IsNullOrEmpty(layer)) return;

            if (_skel)
            {
                var mr = _skel.GetComponent<MeshRenderer>();
                if (mr) { mr.sortingLayerName = layer; mr.sortingOrder = order; }
            }
            if (_graphic)
            {
                _graphic.canvasRenderer.SetMaterial(_graphic.material, 0);
            }

            if (_sortingGroup) { _sortingGroup.sortingLayerName = layer; _sortingGroup.sortingOrder = order; }
        }

        public void SetPaused(bool paused)
        {
            if (_skel) _skel.timeScale = paused ? 0f : _skelTimeScale;
            if (_graphic) _graphic.timeScale = paused ? 0f : _graphicTimeScale;
        }

        public void SetUnscaledTime(bool unscaled)
        {
            if (_skel) _skel.UnscaledTime = unscaled;
            if (_graphic) _graphic.UnscaledTime = unscaled;
        }

        public void SetSkin(int skinIndex)
        {
            var data = _skel ? _skel.SkeletonDataAsset : _graphic?.SkeletonDataAsset;
            if (!data) return;

            var sd = data.GetSkeletonData(true);
            var skins = sd.Skins;
            skinIndex = Mathf.Clamp(skinIndex, 0, skins.Count - 1);
            var skinName = skins.Items[skinIndex].Name;
            Debug.Log($"[SpineEffectRenderer] SetSkin: {skinName} (index: {skinIndex})");
            if (_skel)
            {
                _skel.Skeleton.SetSkin(skinName);
                _skel.Skeleton.SetSlotsToSetupPose();
                _skel.AnimationState.Apply(_skel.Skeleton);
            }
            if (_graphic)
            {
                _graphic.Skeleton.SetSkin(skinName);
                _graphic.Skeleton.SetSlotsToSetupPose();
                _graphic.AnimationState.Apply(_graphic.Skeleton);
            }
        }

        public void Play(int animationIndex, bool loop, Action onComplete)
        {
            var data = _skel ? _skel.SkeletonDataAsset : _graphic?.SkeletonDataAsset;
            if (!data)
            {
                // Core waits for this callback; a request without data must still end.
                if (!loop) onComplete?.Invoke();
                return;
            }

            var sd = data.GetSkeletonData(true);
            var anims = sd.Animations;
            animationIndex = Mathf.Clamp(animationIndex, 0, anims.Count - 1);
            string name = anims.Items[animationIndex].Name;

            if (_skel)
            {
                _track = _skel.AnimationState.SetAnimation(0, name, loop);
                if (!loop) _track.Complete += _ => onComplete?.Invoke();
            }
            else if (_graphic)
            {
                _track = _graphic.AnimationState.SetAnimation(0, name, loop);
                if (!loop) _track.Complete += _ => onComplete?.Invoke();
            }
        }

        public void StopAndClear()
        {
            if (_skel) _skel.ClearState();
            if (_graphic) _graphic.Clear();
        }
    }
}
