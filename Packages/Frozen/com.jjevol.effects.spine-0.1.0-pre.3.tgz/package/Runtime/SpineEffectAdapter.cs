//추가
using System;
using Spine.Unity;
using UnityEngine;

namespace jjevol.Effect.Renderers
{
    /// <summary>Retains the original root SkeletonAnimation/SkeletonGraphic fallback.</summary>
    public static class SpineEffectAdapter
    {
        static readonly Func<GameObject, IEffectRenderer> Factory = TryCreate;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        public static void Register()
        {
            EffectRendererAdapters.Factories.Remove(Factory);
            EffectRendererAdapters.Factories.Add(Factory);
        }

        static IEffectRenderer TryCreate(GameObject root)
            => root && (root.GetComponent<SkeletonAnimation>() || root.GetComponent<SkeletonGraphic>())
                ? root.AddComponent<SpineEffectRenderer>() : null;
    }
}
//추가 종료
