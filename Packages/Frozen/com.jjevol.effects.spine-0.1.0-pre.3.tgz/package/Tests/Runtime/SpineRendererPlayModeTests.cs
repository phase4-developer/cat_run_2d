using System.Collections;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using Spine.Unity;
using UnityEngine;
using UnityEngine.TestTools;

namespace jjevol.Effect.Spine.Tests
{
    // Runs against the real spine-csharp / spine-unity runtimes, installed by the validation Host from
    // the public spine-runtimes Git repository. The skeleton is a hand-written JSON with bones only
    // (no attachments, no atlas), so no game or vendor art is involved.
    public sealed class SpineRendererPlayModeTests
    {
        const string SkeletonJson = @"{
  ""skeleton"": { ""hash"": ""jjevol-fixture"", ""spine"": ""4.2.37"" },
  ""bones"": [ { ""name"": ""root"" } ],
  ""slots"": [ { ""name"": ""slot"", ""bone"": ""root"" } ],
  ""skins"": [ { ""name"": ""default"" }, { ""name"": ""alt"" } ],
  ""animations"": {
    ""short"": { ""bones"": { ""root"": { ""rotate"": [ { ""value"": 0 }, { ""time"": 0.1, ""value"": 15 } ] } } },
    ""long"": { ""bones"": { ""root"": { ""rotate"": [ { ""value"": 0 }, { ""time"": 5, ""value"": 90 } ] } } }
  }
}";

        GameObject _go;
        TextAsset _json;
        SkeletonDataAsset _data;

        [SetUp]
        public void SetUp()
        {
            _json = new TextAsset(SkeletonJson) { name = "jjevol-spine-fixture" };
            _data = SkeletonDataAsset.CreateRuntimeInstance(_json, new AtlasAssetBase[0], true);
            Assert.That(_data.GetSkeletonData(true), Is.Not.Null, "The fixture skeleton did not load.");
        }

        [TearDown]
        public void TearDown()
        {
            if (_go) Object.Destroy(_go);
            if (_data) Object.Destroy(_data);
            if (_json) Object.Destroy(_json);
        }

        SpineEffectRenderer CreateAnimationRenderer()
        {
            _go = new GameObject("spine-fixture");
            SkeletonAnimation.AddToGameObject(_go, _data, true);
            return _go.AddComponent<SpineEffectRenderer>();
        }

        [Test]
        public void AdapterFactoryAttachesTheRendererToARootSkeletonAnimation()
        {
            SpineEffectAdapter.Register();
            _go = new GameObject("spine-factory");
            SkeletonAnimation.AddToGameObject(_go, _data, true);
            IEffectRenderer created = null;
            foreach (var factory in EffectRendererAdapters.Factories)
            {
                created = factory(_go);
                if (created != null) break;
            }
            Assert.That(created, Is.InstanceOf<SpineEffectRenderer>());

            var plain = new GameObject("no-spine");
            try
            {
                foreach (var factory in EffectRendererAdapters.Factories)
                    Assert.That(factory(plain), Is.Not.InstanceOf<SpineEffectRenderer>());
            }
            finally { Object.Destroy(plain); }
        }

        [UnityTest]
        public IEnumerator NonLoopPlayCompletesOnce()
        {
            var renderer = CreateAnimationRenderer();
            int completed = 0;
            renderer.Play(0, false, () => completed++);
            float started = Time.realtimeSinceStartup;
            while (completed == 0 && Time.realtimeSinceStartup - started < 3f) yield return null;
            Assert.That(completed, Is.EqualTo(1), "The short animation did not complete.");
            for (int i = 0; i < 10; i++) yield return null;
            Assert.That(completed, Is.EqualTo(1), "Completion fired more than once.");
        }

        [UnityTest]
        public IEnumerator LoopPlayNeverCompletes()
        {
            var renderer = CreateAnimationRenderer();
            int completed = 0;
            renderer.Play(0, true, () => completed++);
            float started = Time.realtimeSinceStartup;
            while (Time.realtimeSinceStartup - started < 0.4f) yield return null;
            Assert.That(completed, Is.EqualTo(0));
        }

        [Test]
        public void PlayClampsTheAnimationIndex()
        {
            var renderer = CreateAnimationRenderer();
            var animation = _go.GetComponent<SkeletonAnimation>();
            renderer.Play(99, true, null);
            Assert.That(animation.AnimationState.GetCurrent(0).Animation.Name, Is.EqualTo("long"));
            renderer.Play(-5, true, null);
            Assert.That(animation.AnimationState.GetCurrent(0).Animation.Name, Is.EqualTo("short"));
        }

        [UnityTest]
        public IEnumerator PauseHoldsTheTrackAndResumeRestoresTheAuthoredTimeScale()
        {
            var renderer = CreateAnimationRenderer();
            var animation = _go.GetComponent<SkeletonAnimation>();
            animation.timeScale = 0.5f;
            ((IEffectRendererStateRestore)renderer).CaptureState();
            renderer.Play(1, false, null);
            renderer.SetPaused(true);
            Assert.That(animation.timeScale, Is.EqualTo(0f));
            float before = animation.AnimationState.GetCurrent(0).TrackTime;
            for (int i = 0; i < 5; i++) yield return null;
            Assert.That(animation.AnimationState.GetCurrent(0).TrackTime, Is.EqualTo(before));
            renderer.SetPaused(false);
            Assert.That(animation.timeScale, Is.EqualTo(0.5f));

            renderer.SetPaused(true);
            ((IEffectRendererStateRestore)renderer).RestoreState();
            Assert.That(animation.timeScale, Is.EqualTo(0.5f), "Pool return keeps the authored timeScale.");
        }

        [Test]
        public void SetSkinClampsToTheSkinList()
        {
            var renderer = CreateAnimationRenderer();
            var animation = _go.GetComponent<SkeletonAnimation>();
            renderer.SetSkin(1);
            Assert.That(animation.Skeleton.Skin.Name, Is.EqualTo("alt"));
            renderer.SetSkin(99);
            Assert.That(animation.Skeleton.Skin.Name, Is.EqualTo("alt"));
            renderer.SetSkin(-1);
            Assert.That(animation.Skeleton.Skin.Name, Is.EqualTo("default"));
        }

        [Test]
        public void StopAndClearEmptiesTheTrack()
        {
            var renderer = CreateAnimationRenderer();
            var animation = _go.GetComponent<SkeletonAnimation>();
            renderer.Play(1, true, null);
            Assert.That(animation.AnimationState.GetCurrent(0), Is.Not.Null);
            renderer.StopAndClear();
            Assert.That(animation.AnimationState.GetCurrent(0), Is.Null);
        }
    }
}
