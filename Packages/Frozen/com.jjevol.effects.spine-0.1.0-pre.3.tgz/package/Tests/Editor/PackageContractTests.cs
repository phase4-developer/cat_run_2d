//추가
using System;
using System.Linq;
using System.Reflection;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace jjevol.Effect.Spine.Tests
{
    // Compiled and run in Hosts/SpineValidationHost against the public spine-runtimes Git packages.
    public sealed class PackageContractTests
    {
        [Test]
        public void OriginalPublicRendererContractAndSerializedFieldsArePreserved()
        {
            var type = typeof(SpineEffectRenderer);
            Assert.That(type.FullName, Is.EqualTo("jjevol.Effect.Renderers.SpineEffectRenderer"));
            Assert.That(typeof(IEffectRenderer).IsAssignableFrom(type), Is.True);
            Assert.That(type.GetProperty("Root").PropertyType, Is.EqualTo(typeof(Transform)));
            var methods = type.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                .Where(x => !x.IsSpecialName).Select(x => x.Name).OrderBy(x => x).ToArray();
            Assert.That(methods, Is.EqualTo(new[] { "Play", "SetPaused", "SetSkin", "SetSorting", "SetUnscaledTime", "StopAndClear" }));
            Assert.That(type.GetMethod("Play", new[] { typeof(int), typeof(bool), typeof(Action) }), Is.Not.Null);
            var serialized = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                .Where(x => !x.IsStatic && !x.IsNotSerialized && (x.IsPublic || x.GetCustomAttribute<SerializeField>() != null));
            Assert.That(serialized, Is.Empty);
        }

        [Test]
        public void RendererRestoresPoolStateThroughTheOptionalInterface()
        {
            Assert.That(typeof(IEffectRendererStateRestore).IsAssignableFrom(typeof(SpineEffectRenderer)), Is.True);
        }

        [Test]
        public void PlayWithoutSkeletonDataStillEndsANonLoopRequest()
        {
            var go = new GameObject("spine-no-data");
            try
            {
                var renderer = go.AddComponent<SpineEffectRenderer>();
                int completed = 0;
                renderer.Play(0, false, () => completed++);
                Assert.That(completed, Is.EqualTo(1));
                renderer.Play(0, true, () => completed++);
                Assert.That(completed, Is.EqualTo(1), "A loop has no completion.");
            }
            finally { UnityEngine.Object.DestroyImmediate(go); }
        }

        [Test]
        public void OriginalScriptGuidResolvesToTheActiveAdapter()
        {
            Assert.That(AssetDatabase.GUIDToAssetPath("7d7a4dabf925e2a46ad30b99cdb73bd8"),
                Is.EqualTo("Packages/com.jjevol.effects.spine/Runtime/SpineEffectRenderer.cs"));
        }

        [Test]
        public void ActualSpineAssembliesAreReferencedOnlyFromTheOptionalAdapter()
        {
            var adapter = typeof(SpineEffectRenderer).Assembly.GetReferencedAssemblies().Select(x => x.Name).ToArray();
            Assert.That(adapter, Does.Contain("spine-csharp"));
            Assert.That(adapter, Does.Contain("spine-unity"));
            var core = typeof(EffectHandle).Assembly.GetReferencedAssemblies().Select(x => x.Name).ToArray();
            Assert.That(core, Does.Not.Contain("spine-csharp"));
            Assert.That(core, Does.Not.Contain("spine-unity"));
            Assert.That(core, Does.Not.Contain("JJEvol.Effects.Spine.Runtime"));
        }
    }
}
//추가 종료
