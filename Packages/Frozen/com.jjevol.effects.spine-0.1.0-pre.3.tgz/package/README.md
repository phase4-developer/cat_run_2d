# JJEvol Effects Spine Adapter — development candidate

**0.1.0-pre.3: compile, EditMode 5/5 and PlayMode 7/7 passed in `Hosts/SpineValidationHost` (queue runner job `pkg1110-spine-02`, 2026-11-10). Not pinned for distribution yet.**

`jjevol.Effect.Renderers.SpineEffectRenderer` plays Effects requests on a root `SkeletonAnimation` or `SkeletonGraphic`. Its Script GUID is `7d7a4dabf925e2a46ad30b99cdb73bd8`. It declares no serialized fields.

## Installing the Spine runtime

The Spine runtime is public; only the Spine editor is a paid tool. This package bundles and copies no runtime source. The consumer adds both runtimes from the public spine-runtimes Git repository to `Packages/manifest.json`:

```json
"com.esotericsoftware.spine.spine-csharp": "https://github.com/EsotericSoftware/spine-runtimes.git?path=spine-csharp/src#b81e5a58ed38704aee4f866f0e0ac672623ce914",
"com.esotericsoftware.spine.spine-unity": "https://github.com/EsotericSoftware/spine-runtimes.git?path=spine-unity/Assets/Spine#b81e5a58ed38704aee4f866f0e0ac672623ce914"
```

That commit is spine-csharp 4.2.37 and spine-unity 4.2.120, the versions this package declares. A game that already follows the `#4.2` branch keeps its own lock; the adapter only uses API that exists across 4.2. The package dependencies name these versions but Unity's registry does not serve them, so without the Git lines the Package Manager reports them as missing.

## Behavior

The optional assembly `JJEvol.Effects.Spine.Runtime` references Effects Core, `spine-csharp`, `spine-unity`, and uGUI. Core has no reverse dependency.

`SpineEffectAdapter.Register()` adds a factory to `EffectRendererAdapters.Factories` for root `SkeletonAnimation`/`SkeletonGraphic` components, and is also called at Unity subsystem registration. An explicit `IEffectRenderer` and the Animator path keep Core's precedence. Multiple optional factories follow registration order; a prefab combining several vendor root components needs an explicit renderer.

- `Play(int animationIndex, bool loop, Action onComplete)` clamps the index to `SkeletonData.Animations`, plays track 0, and calls `onComplete` once when a non-loop animation completes. A loop never calls it. A non-loop request with no skeleton data calls it at once, because Core waits for that call.
- `SetSkin(int)` clamps against `SkeletonData.Skins`, sets the named skin, resets slots, and applies the current AnimationState.
- `SetPaused(true)` sets the component timeScale to 0. `SetPaused(false)` returns to the timeScale captured from the prefab (1 outside EffectManager). `SetUnscaledTime(bool)` sets the runtime flag.
- MeshRenderer/SortingGroup take layer and order. The SkeletonGraphic path only reapplies its material; it does not set Canvas sorting.
- `StopAndClear()` calls `SkeletonAnimation.ClearState()` / `SkeletonGraphic.Clear()`.
- Pool reuse: the renderer implements Core's optional `IEffectRendererStateRestore`, so a paused request cannot freeze the next one and sorting returns to the prefab values.

The TrackEntry completion delegate is not detached and there is no per-play generation; EffectHandle's RequestVersion keeps a stale completion from ending a newer request.

## Tests

- `Tests/Editor` (`JJEvol.Effects.Spine.Tests.Editor`): public contract, serialized fields, state-restore interface, no-data completion.
- `Tests/Runtime` (`JJEvol.Effects.Spine.Tests.Runtime`): PlayMode tests on the real runtimes with a hand-written bones-only skeleton JSON and no atlas, so no game or vendor art is involved. They cover the adapter factory, non-loop completion once, loop without completion, animation and skin clamping, pause and timeScale restore, and StopAndClear.

Both run in `Hosts/SpineValidationHost` (6000.3.9f1), which installs the runtimes from the Git lines above.

Installation is in the Framework `Docs/Guide/Installation.md` and validation scope in `Docs/Guide/Verification.md`.
