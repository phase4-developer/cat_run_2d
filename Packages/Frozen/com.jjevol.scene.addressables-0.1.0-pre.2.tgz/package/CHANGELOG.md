# Changelog

## 0.1.0-pre.2 - 2026-11-07

- The test fixture no longer clears a Host's default Addressables Settings when several fixtures run together. All fixtures share one saved value, the first save is kept, and a deleted asset is never restored.
- The saved runtime data path follows the same rules, so a chained run cannot restore a deleted Settings GUID.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.1 - 2026-11-06

Addressable `ISceneSource` for `com.jjevol.scene`, written against `improve/runtime-hardening` fe7f5fb0f4d4efb2d4116235817686e464d1764f. Replaces the direct `AddressablesManager` calls in the mobile `CustomSceneManager`.

Registers itself at `BeforeSceneLoad`. Failed handles stay with `AddressablesManager`, so the source's own `Addressables.Release` is gone.

PlayMode tests pass 7/7 in the Windows Editor with Addressables FastMode against fe7f5fb. Built Addressables content, Player and device tests are NOT_RUN.
