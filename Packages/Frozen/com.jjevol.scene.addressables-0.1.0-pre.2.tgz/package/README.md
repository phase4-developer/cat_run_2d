# JJEvol Scene Addressables — local candidate

Unity 6000.3.9f1. 로컬 소스 후보이며 공식 릴리스나 고정 tarball이 아니다.

`com.jjevol.scene`에 Addressable 씬을 추가한다. 설치하면 시작할 때 자동 등록되고, 설정이나 코드 변경 없이 같은 호출로 동작한다.

~~~csharp
await CustomSceneManager.Instance.LoadSceneAsync("Battle");
~~~

- 키는 씬의 Address다. 같은 키가 빌드 포함 씬에도 있으면 Addressables가 먼저다. 빌드 씬을 강제하려면 `option.sourceId = BuildSceneSource.SourceId`를 쓴다.
- 씬이 없는 키는 화면이 바뀌기 전에 실패한다.
- 로드 수명은 `AddressablesManager`가 소유한다. 실패한 Handle을 이 패키지에서 해제하지 않는다.
- Addressables는 시작한 로드를 멈출 수 없다. Single 로드는 취소해도 끝까지 진행하고, Additive 로드는 씬을 활성화한 뒤 내린다.

`com.jjevol.resources.addressables` 0.1.0-pre.3이 필요하다(package.json 기준). 실패 Handle 처리 규칙은 pre.2부터 적용된다.

## 시험

`Tests/Runtime`은 임시 Addressables 설정과 씬을 만드는 PlayMode 시험이다.
