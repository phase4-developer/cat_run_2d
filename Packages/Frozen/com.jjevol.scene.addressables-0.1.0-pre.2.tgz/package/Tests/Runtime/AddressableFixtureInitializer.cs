using Cysharp.Threading.Tasks;
using jjevol;

namespace JJEvolSceneAddressablesTests
{
    // Saved inside a scene asset, so it needs a file of its own for Unity to keep the script reference.
    public sealed class AddressableFixtureInitializer : SceneInitializerBase
    {
        public static int Runs;

        public override UniTask OnInitializeAsync()
        {
            Runs++;
            return UniTask.CompletedTask;
        }
    }
}
