using System;
using System.Collections;
using System.Text.RegularExpressions;
using System.Threading;
using Cysharp.Threading.Tasks;
using jjevol;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace JJEvolSceneAddressablesTests
{
    [PrebuildSetup("JJEvolSceneAddressablesTests.AddressableSceneFixture")]
    [PostBuildCleanup("JJEvolSceneAddressablesTests.AddressableSceneFixture")]
    public sealed class AddressableSceneSourceTests
    {
        const string Address = "JJEvolSceneTests/Fixture";
        const string SceneName = "JJEvolAddressableFixture";

        static SceneLoadOption Direct => new SceneLoadOption { loadType = SceneLoadType.None, unloadUnusedAssets = false };

        [SetUp]
        public void SetUp() => AddressableFixtureInitializer.Runs = 0;

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            var fixture = SceneManager.GetSceneByName(SceneName);
            if (fixture.IsValid() && fixture.isLoaded)
            {
                // A Single load leaves the fixture as the only scene, and the last scene cannot be unloaded.
                if (SceneManager.sceneCount == 1) SceneManager.SetActiveScene(SceneManager.CreateScene("anchor-" + Guid.NewGuid().ToString("N")));
                yield return SceneManager.UnloadSceneAsync(fixture);
            }

            if (CustomSceneManager.HasInstance) UnityEngine.Object.Destroy(CustomSceneManager.Instance.gameObject);
            if (AddressablesManager.HasInstance) UnityEngine.Object.Destroy(AddressablesManager.Instance.gameObject);
            yield return null;
        }

        [UnityTest]
        public IEnumerator ContainsOnlyAddressableScenes() => UniTask.ToCoroutine(async () =>
        {
            var source = new AddressableSceneSource();

            Assert.That(await source.ContainsAsync(Address, default), Is.True);
            Assert.That(await source.ContainsAsync("JJEvolSceneTests/Missing", default), Is.False);
        });

        [UnityTest]
        public IEnumerator SourceIsRegisteredAutomatically() => UniTask.ToCoroutine(async () =>
        {
            var manager = CustomSceneManager.Instance;

            var loaded = await manager.LoadAdditiveAsync(Address);
            var unloaded = await manager.UnloadAdditiveAsync(Address);

            Assert.That(loaded.IsSuccess, Is.True);
            Assert.That(unloaded.IsSuccess, Is.True);
            Assert.That(AddressableFixtureInitializer.Runs, Is.EqualTo(1));
            Assert.That(SceneManager.GetSceneByName(SceneName).isLoaded, Is.False);
        });

        [UnityTest]
        public IEnumerator SingleLoadActivatesAndInitializes() => UniTask.ToCoroutine(async () =>
        {
            var result = await CustomSceneManager.Instance.LoadSceneAsync(Address, Direct);

            Assert.That(result.IsSuccess, Is.True);
            Assert.That(SceneManager.GetActiveScene().name, Is.EqualTo(SceneName));
            Assert.That(AddressableFixtureInitializer.Runs, Is.EqualTo(1));
        });

        [UnityTest]
        public IEnumerator MissingAddressFailsBeforeAnyLoadStarts() => UniTask.ToCoroutine(async () =>
        {
            var active = SceneManager.GetActiveScene();
            LogAssert.Expect(LogType.Error, new Regex(@"^\[CustomSceneManager\] Load Failed:"));

            var result = await CustomSceneManager.Instance.LoadSceneAsync("JJEvolSceneTests/Missing", Direct);

            Assert.That(result.Status, Is.EqualTo(SceneLoadStatus.Failed));
            Assert.That(result.Stage, Is.EqualTo(SceneLoadStage.Validate));
            Assert.That(result.Exception.Message, Does.Contain(AddressableSceneSource.SourceId));
            Assert.That(SceneManager.GetActiveScene(), Is.EqualTo(active));
        });

        [UnityTest]
        public IEnumerator AbandoningAnAdditiveLoadRemovesTheScene() => UniTask.ToCoroutine(async () =>
        {
            // Started directly, so the cancel cannot land earlier, while the key is still being looked up.
            var operation = new AddressableSceneSource().BeginLoad(Address, LoadSceneMode.Additive);
            using var cancellation = new CancellationTokenSource();
            cancellation.Cancel();

            await operation.WaitUntilReadyAsync(null, cancellation.Token).SuppressCancellationThrow();
            await operation.AbandonAsync();

            Assert.That(operation.CanAbandon, Is.True);
            Assert.That(SceneManager.GetSceneByName(SceneName).isLoaded, Is.False);
            Assert.That(AddressableFixtureInitializer.Runs, Is.Zero);
        });

        [UnityTest]
        public IEnumerator SingleLoadCannotBeAbandonedAndReportsItsFailure() => UniTask.ToCoroutine(async () =>
        {
            LogAssert.Expect(LogType.Error, new Regex("^UnityEngine.AddressableAssets.InvalidKeyException"));
            LogAssert.Expect(LogType.Error, new Regex("^Failed to load scene: JJEvolSceneTests/Missing"));
            var operation = new AddressableSceneSource().BeginLoad("JJEvolSceneTests/Missing", LoadSceneMode.Single);

            Exception thrown = null;
            try { await operation.WaitUntilReadyAsync(null, default); }
            catch (Exception exception) { thrown = exception; }

            Assert.That(operation.CanAbandon, Is.False);
            Assert.That(thrown, Is.Not.Null);
        });

        [UnityTest]
        public IEnumerator FailedLoadReachesTheCallerAfterAnotherLoadReleasesItsHandle() => UniTask.ToCoroutine(async () =>
        {
            LogAssert.ignoreFailingMessages = true;
            try
            {
                var failed = new AddressableSceneSource().BeginLoad("JJEvolSceneTests/Missing", LoadSceneMode.Additive);
                await UniTask.Delay(TimeSpan.FromSeconds(0.2f), DelayType.UnscaledDeltaTime);

                // AddressablesManager releases the failed handle here.
                var second = new AddressableSceneSource().BeginLoad(Address, LoadSceneMode.Additive);

                Exception thrown = null;
                try { await failed.WaitUntilReadyAsync(null, default); }
                catch (Exception exception) { thrown = exception; }

                await second.WaitUntilReadyAsync(null, default);
                await second.ActivateAsync();
                await second.UnloadAsync();

                Assert.That(thrown, Is.Not.Null);
            }
            finally
            {
                LogAssert.ignoreFailingMessages = false;
            }
        });
    }
}
