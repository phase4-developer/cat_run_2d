using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace JJEvolSceneAddressablesTests
{
    /// <summary>Creates a throwaway Addressables setup with one scene for the duration of the run.</summary>
    public sealed class AddressableSceneFixture : IPrebuildSetup, IPostBuildCleanup
    {
        const string Root = "Assets/JJEvolSceneAddressableTests";
        const string ScenePath = Root + "/JJEvolAddressableFixture.unity";
        const string Address = "JJEvolSceneTests/Fixture";
        internal const string PreviousPathKey = "JJEvolTestsPreviousRuntimeDataPath";
        const string NothingSaved = "nothing-saved";
        internal const string PreviousDefaultKey = "JJEvolTestsPreviousDefaultSettings";

        public void Setup()
        {
            if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", "JJEvolSceneAddressableTests");

            var settings = AddressableAssetSettings.Create(Root, "Settings", true, true);
            for (int i = 0; i < settings.DataBuilders.Count; i++)
                if (settings.DataBuilders[i] is BuildScriptFastMode)
                    settings.ActivePlayModeDataBuilderIndex = i;

            // Unity refuses to add a scene next to an untitled one.
            var prior = SceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(prior.path)) EditorSceneManager.SaveScene(prior, Root + "/Anchor.unity");

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            var host = new GameObject("addressable-fixture-initializer", typeof(AddressableFixtureInitializer));
            SceneManager.MoveGameObjectToScene(host, scene);
            EditorSceneManager.SaveScene(scene, ScenePath);
            if (prior.IsValid()) SceneManager.SetActiveScene(prior);
            EditorSceneManager.CloseScene(scene, true);

            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(ScenePath), settings.DefaultGroup).address = Address;
            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets();

            SavePreviousPath();
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:" + AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));

            // Entering PlayMode rebuilds the default Settings and overwrites the runtime path, so a Host that has
            // default Settings must use this fixture's Settings for the run. A Host without them is left unchanged.
            if (AddressableAssetSettingsDefaultObject.SettingsExists)
            {
                SavePreviousDefault();
                AddressableAssetSettingsDefaultObject.Settings = settings;
            }
        }

        public void Cleanup()
        {
            RestorePreviousPath();
            RestorePreviousDefault();

            AssetDatabase.DeleteAsset(Root);
        }

        // Every fixture uses this key, so in a chained run the first one's save, the Host's own Settings, is the one kept.
        internal static void SavePreviousDefault()
        {
            if (SessionState.GetString(PreviousDefaultKey, "") != "") return;
            SessionState.SetString(PreviousDefaultKey, AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(AddressableAssetSettingsDefaultObject.Settings)));
        }

        // Setting a deleted asset would clear the Host's default Settings GUID.
        internal static void RestorePreviousDefault()
        {
            string previous = SessionState.GetString(PreviousDefaultKey, "");
            SessionState.EraseString(PreviousDefaultKey);
            if (previous == "") return;
            var settings = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(AssetDatabase.GUIDToAssetPath(previous));
            if (settings != null) AddressableAssetSettingsDefaultObject.Settings = settings;
        }

        // An empty path is a real previous value, so "nothing saved" needs its own marker. The first fixture's save is
        // kept, and the later Cleanup in a chain finds nothing to restore instead of erasing what the first one put back.
        internal static void SavePreviousPath()
        {
            if (SessionState.GetString(PreviousPathKey, NothingSaved) != NothingSaved) return;
            SessionState.SetString(PreviousPathKey, SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, ""));
        }

        internal static void RestorePreviousPath()
        {
            string previous = SessionState.GetString(PreviousPathKey, NothingSaved);
            if (previous == NothingSaved) return;
            SessionState.EraseString(PreviousPathKey);
            bool deleted = previous.StartsWith("GUID:") && AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(AssetDatabase.GUIDToAssetPath(previous.Substring(5))) == null;
            if (previous == "" || deleted) SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            else SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, previous);
        }
    }
}
