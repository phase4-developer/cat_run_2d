using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEngine.AddressableAssets;

namespace JJEvolSceneAddressablesTests
{
    public sealed class AddressableSceneFixtureDefaultSettingsTests
    {
        const string Deleted = "0123456789abcdef0123456789abcdef";
        const string Unset = "unset";
        string _saved, _savedPathKey, _savedPath;

        static string RuntimePath => SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, Unset);
        static string SavedPath => SessionState.GetString(AddressableSceneFixture.PreviousPathKey, Unset);
        static void Put(string key, string value) { if (value == Unset) SessionState.EraseString(key); else SessionState.SetString(key, value); }

        [SetUp] public void SetUp()
        {
            _saved = SessionState.GetString(AddressableSceneFixture.PreviousDefaultKey, ""); SessionState.EraseString(AddressableSceneFixture.PreviousDefaultKey);
            _savedPathKey = SavedPath; _savedPath = RuntimePath; SessionState.EraseString(AddressableSceneFixture.PreviousPathKey);
        }
        [TearDown] public void TearDown()
        {
            if (_saved == "") SessionState.EraseString(AddressableSceneFixture.PreviousDefaultKey);
            else SessionState.SetString(AddressableSceneFixture.PreviousDefaultKey, _saved);
            Put(AddressableSceneFixture.PreviousPathKey, _savedPathKey); Put(Addressables.kAddressablesRuntimeDataPath, _savedPath);
        }

        [Test] public void ASavedPreviousValueSurvivesAChainedFixture()
        {
            SessionState.SetString(AddressableSceneFixture.PreviousDefaultKey, "first-fixture-saved-this");
            AddressableSceneFixture.SavePreviousDefault();
            Assert.That(SessionState.GetString(AddressableSceneFixture.PreviousDefaultKey, ""), Is.EqualTo("first-fixture-saved-this"));
        }
        [Test] public void TheFirstFixtureSavesTheDefaultSettings()
        {
            Assume.That(AddressableAssetSettingsDefaultObject.SettingsExists, "Needs a Host with default Settings.");
            AddressableSceneFixture.SavePreviousDefault();
            Assert.That(SessionState.GetString(AddressableSceneFixture.PreviousDefaultKey, ""), Is.EqualTo(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(AddressableAssetSettingsDefaultObject.Settings))));
        }
        [Test] public void ADeletedPreviousAssetIsNeverRestored()
        {
            var current = AddressableAssetSettingsDefaultObject.GetSettings(false);
            SessionState.SetString(AddressableSceneFixture.PreviousDefaultKey, Deleted);
            AddressableSceneFixture.RestorePreviousDefault();
            Assert.That(AddressableAssetSettingsDefaultObject.GetSettings(false), Is.SameAs(current));
            Assert.That(SessionState.GetString(AddressableSceneFixture.PreviousDefaultKey, ""), Is.Empty);
        }
        [Test] public void AnEmptySavedPathSurvivesAChainedFixture()
        {
            SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            AddressableSceneFixture.SavePreviousPath();
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:" + Deleted);
            AddressableSceneFixture.SavePreviousPath();
            Assert.That(SavedPath, Is.Empty);
            AddressableSceneFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo(Unset));
        }
        [Test] public void ADeletedPreviousPathIsNeverRestored()
        {
            SessionState.SetString(AddressableSceneFixture.PreviousPathKey, "GUID:" + Deleted);
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:fixture-being-removed");
            AddressableSceneFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo(Unset));
            Assert.That(SavedPath, Is.EqualTo(Unset));
        }
        [Test] public void TheLaterCleanupInAChainLeavesTheRestoredPathAlone()
        {
            SessionState.SetString(AddressableSceneFixture.PreviousPathKey, "Host/Path");
            AddressableSceneFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo("Host/Path"));
            AddressableSceneFixture.RestorePreviousPath();
            Assert.That(RuntimePath, Is.EqualTo("Host/Path"));
        }
    }
}
