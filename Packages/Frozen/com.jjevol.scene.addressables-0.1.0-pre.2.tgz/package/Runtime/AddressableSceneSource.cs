using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.SceneManagement;

namespace jjevol
{
    /// <summary>Addressable scenes. Installing this package registers the source, ahead of Build Settings scenes.</summary>
    public sealed class AddressableSceneSource : ISceneSource
    {
        public const string SourceId = "addressables";

        public string Id => SourceId;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void RegisterOnStartup() => SceneSources.Register(new AddressableSceneSource());

        public async UniTask<bool> ContainsAsync(string key, CancellationToken cancellationToken)
        {
            AsyncOperationHandle<IList<IResourceLocation>> locations = Addressables.LoadResourceLocationsAsync(key, typeof(SceneInstance));

            try
            {
                var found = await locations.ToUniTask(cancellationToken: cancellationToken);
                return found != null && found.Count > 0;
            }
            finally
            {
                if (locations.IsValid()) Addressables.Release(locations);
            }
        }

        public ISceneLoadOperation BeginLoad(string key, LoadSceneMode mode) => new Operation(key, mode);

        sealed class Operation : ISceneLoadOperation
        {
            readonly string _key;
            SceneInstance _instance;
            Exception _failure;
            bool _done;

            public Operation(string key, LoadSceneMode mode)
            {
                _key = key;

                // A Single load replaces the current scene the moment it activates, so it has no way back.
                CanAbandon = mode == LoadSceneMode.Additive;

                // AddressablesManager owns the handle and may release a failed one on the next load,
                // so everything needed from it is read here, as it completes.
                Handle = AddressablesManager.Instance.LoadSceneAsync(key, mode, false);
                Handle.Completed += OnCompleted;
            }

            AsyncOperationHandle<SceneInstance> Handle { get; }

            public bool CanAbandon { get; }

            void OnCompleted(AsyncOperationHandle<SceneInstance> completed)
            {
                if (completed.Status == AsyncOperationStatus.Succeeded) _instance = completed.Result;
                else _failure = completed.OperationException ?? new InvalidOperationException($"Addressable scene '{_key}' failed to load.");

                _done = true;
            }

            public async UniTask WaitUntilReadyAsync(IProgress<float> progress, CancellationToken cancellationToken)
            {
                while (!_done)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (Handle.IsValid()) progress?.Report(Handle.PercentComplete);
                    await UniTask.Yield();
                }

                if (_failure != null) throw _failure;
                progress?.Report(1f);
            }

            public async UniTask<Scene> ActivateAsync()
            {
                await _instance.ActivateAsync().ToUniTask();
                return _instance.Scene;
            }

            // Addressables cannot stop a started load, so the scene has to activate before it can go.
            public async UniTask AbandonAsync()
            {
                while (!_done) await UniTask.Yield();
                if (_failure != null) return;

                await ActivateAsync();
                await UnloadAsync();
            }

            public async UniTask UnloadAsync()
            {
                // The game may already have closed it directly.
                if (!_instance.Scene.IsValid() || !_instance.Scene.isLoaded) return;

                var unload = AddressablesManager.Instance.UnloadSceneAsync(_instance);
                if (!unload.IsValid()) throw new InvalidOperationException($"Addressable scene '{_key}' could not be unloaded.");
                await unload.ToUniTask();
            }
        }
    }
}
