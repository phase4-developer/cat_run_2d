# JJEvol Effects DOTween Pro Adapter — local validation candidate

`com.jjevol.effects.dotween-pro@0.1.0-pre.2`, Unity 6000.3.9f1,
DOTween 1.2.765 / Pro 1.0.381. Original
`jjevol.Effect.Renderers.DOTweenEffectRenderer` implements IEffectRenderer.
Script GUID 6e7b7a4af53e4d64d95552d9f1ed8edf and all 10 serialized fields
are preserved. Assembly identity is JJEvol.Effects.DOTweenPro.Runtime.

Supply licensed DOTween.dll / DOTweenPro.dll / DOTween.Modules /
DOTweenPro.Scripts separately. No Vendor sources, binaries or licenses are
included. Effects Core and uGUI/TMP 2.0.0 are package dependencies; the tested
existing Pro.Scripts configuration enables TMP. SDK Modules also have built-in
Unity Physics/Physics2D/Audio/UI requirements according to their existing
enabled markers. Core packages acquire no new DOTween dependency.

An explicit renderer on the Prefab keeps the original selection contract.
DOTweenEffectAdapter.Register is also registered at SubsystemRegistration
and idempotently connects the original root DOTweenAnimation fallback to the
existing EffectRendererAdapters.Factories list. Animator-first selection in
Effect Core is unchanged. There is no UITransition/URP/Audio/Economy/Runner
dependency in this production adapter.

Existing CreateTween, DOPause, DOPlayForward, DORewind, DOKill and child
ParticleSystem behavior is retained. A run version retires old completion
waiters. Disable/Destroy stop owned work; SetUnscaledTime applies to already
created native Tweens as well as future ones and particle time settings.
StopAndClear's kill/rewind/particle-clear flags keep their original meaning.
With killTweenOnStop=false, a paused, rewound native Tween is intentionally
retained for reuse until its Pro component is destroyed; this is not a zero-
active-Tween policy. Default kill=true returns to zero.

The original loop argument suppresses Renderer completion and sets Particle
looping; it does not overwrite the consumer's DOTweenAnimation.loops setting.
Completion remains the original estimated-duration/particle/fallback contract,
not an assertion that an invalid SDK configuration rendered successfully.
Invalid/missing animation configuration keeps the SDK warning and existing
fallback termination behavior.

The renderer implements Core's optional IEffectRendererStateRestore, so sorting
returns to the prefab values between pooled requests. It is an explicit
interface implementation: the public method set and serialized fields are
unchanged.

Original SetSorting covers Canvas, SortingGroup, SpriteRenderer and
ParticleSystemRenderer. SetSkin is the original unsupported empty method;
animationIndex is not used. This renderer does not own an Animator controller
or trigger; it does not acquire another renderer's Animator/skin features.
No functionality was deleted to make compilation pass.

Use the existing EffectManager Play/PlayAsync/Despawn APIs and existing
Prefab lease provider. The adapter does not replace the SDK provider or
ordinary resource loader. Do not retain and operate a returned EffectHandle;
game-owned Pro UnityEvent subscriptions have their own lifetime policy.

Actual SDK unit/Prefab/Particle/20-reuse/Scene/Manager tests are under Tests.
Player/device/product assets, IL2CPP, remote bundles and new fixed tarballs
were not validated. See the Framework Docs/Guide/Installation.md and
Docs/Guide/Verification.md. Do not install alongside the original mobile source.
