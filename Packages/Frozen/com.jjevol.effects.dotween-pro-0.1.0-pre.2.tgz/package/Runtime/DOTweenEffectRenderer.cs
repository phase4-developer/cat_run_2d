//�߰�
using DG.Tweening;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace jjevol.Effect.Renderers
{
    /// <summary>
    /// DOTweenAnimation + ���� ParticleSystem�� �Բ� ����ϴ� ����Ʈ ������.
    /// Effect_LevelUpó�� DOTween���� �̵�/���ĸ� ó���ϰ�, ���� UIParticle/ParticleSystem�� ���� ����ϴ� ������ ������.
    /// </summary>
    public sealed class DOTweenEffectRenderer : MonoBehaviour, IEffectRenderer, IEffectRendererStateRestore
    {
        [Header("Collect")]
        [SerializeField] private bool collectChildrenOnPlay = true;

        [Header("DOTween")]
        [SerializeField] private bool recreateTweenOnPlay = true;
        [SerializeField] private bool rewindBeforePlay = true;
        [SerializeField] private bool killTweenOnStop = true;

        [Header("Particle")]
        [SerializeField] private bool playChildParticles = true;
        [SerializeField] private bool clearParticlesOnPlay = true;
        [SerializeField] private bool clearParticlesOnStop = true;

        [Header("Safety")]
        [SerializeField] private float fallbackCompleteSeconds = 5f;

        [SerializeField] private List<DOTweenAnimation> dotweenAnimations = new();
        [SerializeField] private List<ParticleSystem> particleSystems = new();

        private bool _useUnscaledTime;
        private bool _isPaused;
        private Coroutine _waitCoroutine;

        private readonly EffectSortingSnapshot _sorting = new();
        void IEffectRendererStateRestore.CaptureState() => _sorting.Capture(gameObject);
        void IEffectRendererStateRestore.RestoreState() => _sorting.Restore();
        //�߰�
        private int _playVersion;
        private bool _stopping;
        private void OnDisable() => StopAndClear();
        private void OnDestroy() => StopAndClear();
        //�߰� ����

        public Transform Root => transform;

        private void Awake()
        {
            CollectComponents();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            CollectComponents();
        }
#endif

        [ContextMenu("Collect Components")]
        private void CollectComponents()
        {
            dotweenAnimations.Clear();
            particleSystems.Clear();

            DOTweenAnimation[] tweens = GetComponentsInChildren<DOTweenAnimation>(true);
            if (tweens != null)
            {
                for (int i = 0; i < tweens.Length; i++)
                {
                    if (tweens[i] == null) continue;
                    if (!dotweenAnimations.Contains(tweens[i]))
                        dotweenAnimations.Add(tweens[i]);
                }
            }

            ParticleSystem[] particles = GetComponentsInChildren<ParticleSystem>(true);
            if (particles != null)
            {
                for (int i = 0; i < particles.Length; i++)
                {
                    if (particles[i] == null) continue;
                    if (!particleSystems.Contains(particles[i]))
                        particleSystems.Add(particles[i]);
                }
            }
        }

        public void SetSorting(string layer, int order)
        {
            if (string.IsNullOrEmpty(layer)) return;

            Canvas[] canvases = GetComponentsInChildren<Canvas>(true);
            for (int i = 0; i < canvases.Length; i++)
            {
                if (canvases[i] == null) continue;

                canvases[i].overrideSorting = true;
                canvases[i].sortingLayerName = layer;
                canvases[i].sortingOrder = order;
            }

            SortingGroup[] sortingGroups = GetComponentsInChildren<SortingGroup>(true);
            for (int i = 0; i < sortingGroups.Length; i++)
            {
                if (sortingGroups[i] == null) continue;

                sortingGroups[i].sortingLayerName = layer;
                sortingGroups[i].sortingOrder = order;
            }

            SpriteRenderer[] spriteRenderers = GetComponentsInChildren<SpriteRenderer>(true);
            for (int i = 0; i < spriteRenderers.Length; i++)
            {
                if (spriteRenderers[i] == null) continue;

                spriteRenderers[i].sortingLayerName = layer;
                spriteRenderers[i].sortingOrder = order;
            }

            ParticleSystemRenderer[] particleRenderers = GetComponentsInChildren<ParticleSystemRenderer>(true);
            for (int i = 0; i < particleRenderers.Length; i++)
            {
                if (particleRenderers[i] == null) continue;

                particleRenderers[i].sortingLayerName = layer;
                particleRenderers[i].sortingOrder = order;
            }
        }

        public void SetPaused(bool paused)
        {
            _isPaused = paused;

            for (int i = 0; i < dotweenAnimations.Count; i++)
            {
                DOTweenAnimation animation = dotweenAnimations[i];
                if (animation == null) continue;

                if (paused)
                    animation.DOPause();
                else
                    animation.DOPlayForward();
            }

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;

                if (paused)
                    ps.Pause(true);
                else
                    ps.Play(true);
            }
        }

        public void SetUnscaledTime(bool unscaled)
        {
            _useUnscaledTime = unscaled;

            for (int i = 0; i < dotweenAnimations.Count; i++)
            {
                DOTweenAnimation animation = dotweenAnimations[i];
                if (animation == null) continue;

                //����
                animation.isIndependentUpdate = unscaled;
                if (animation.tween != null && animation.tween.IsActive()) animation.tween.SetUpdate(unscaled);
                //���� ����
            }

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;

                var main = ps.main;
                main.useUnscaledTime = unscaled;
            }
        }

        public void SetSkin(int skinIndex)
        {
        }

        public void Play(int animationIndex, bool loop, Action onComplete)
        {
            //�߰�
            if (_stopping) return;
            int version = ++_playVersion;
            //�߰� ����
            StopWaitCoroutine();

            if (collectChildrenOnPlay)
                CollectComponents();

            _isPaused = false;

            PrepareDOTweenAnimations();
            //�߰�
            if (version != _playVersion) return;
            //�߰� ����
            PrepareParticles(loop);

            if (!gameObject.activeSelf)
                gameObject.SetActive(true);

            PlayDOTweenAnimations();
            //�߰�
            if (version != _playVersion) return;
            //�߰� ����
            PlayParticles();

            if (!loop)
            {
                float completeTime = CalculateCompleteTime();
                //����
                _waitCoroutine = StartCoroutine(Co_WaitComplete(completeTime, onComplete, version));
                //���� ����
            }
        }

        public void StopAndClear()
        {
            //����
            if (_stopping) return;
            _stopping = true;
            ++_playVersion;
            try
            {
                StopWaitCoroutine();
                _isPaused = false;
                StopDOTweenAnimations();
                StopParticles();
            }
            finally { _stopping = false; }
            //���� ����
        }

        private void PrepareDOTweenAnimations()
        {
            for (int i = 0; i < dotweenAnimations.Count; i++)
            {
                DOTweenAnimation animation = dotweenAnimations[i];
                if (animation == null) continue;
                if (!animation.isActive) continue;

                animation.isIndependentUpdate = _useUnscaledTime;

                if (killTweenOnStop)
                    animation.DOKill();

                if (recreateTweenOnPlay)
                    animation.CreateTween(true, false);

                if (rewindBeforePlay)
                    animation.DORewind();
            }
        }

        private void PlayDOTweenAnimations()
        {
            for (int i = 0; i < dotweenAnimations.Count; i++)
            {
                DOTweenAnimation animation = dotweenAnimations[i];
                if (animation == null) continue;
                if (!animation.isActive) continue;

                animation.DOPlayForward();
            }
        }

        private void StopDOTweenAnimations()
        {
            for (int i = 0; i < dotweenAnimations.Count; i++)
            {
                DOTweenAnimation animation = dotweenAnimations[i];
                if (animation == null) continue;

                animation.DOPause();

                if (rewindBeforePlay)
                    animation.DORewind();

                if (killTweenOnStop)
                    animation.DOKill();
            }
        }

        private void PrepareParticles(bool loop)
        {
            if (!playChildParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;

                var main = ps.main;
                main.loop = loop;
                main.useUnscaledTime = _useUnscaledTime;

                if (clearParticlesOnPlay)
                    ps.Clear(true);
            }
        }

        private void PlayParticles()
        {
            if (!playChildParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;

                ps.gameObject.SetActive(true);
                ps.Play(true);
            }
        }

        private void StopParticles()
        {
            if (!playChildParticles) return;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;

                ps.Stop(true, clearParticlesOnStop
                    ? ParticleSystemStopBehavior.StopEmittingAndClear
                    : ParticleSystemStopBehavior.StopEmitting);
            }
        }

        private float CalculateCompleteTime()
        {
            float maxTime = 0f;

            for (int i = 0; i < dotweenAnimations.Count; i++)
            {
                DOTweenAnimation animation = dotweenAnimations[i];
                if (animation == null) continue;
                if (!animation.isActive) continue;

                maxTime = Mathf.Max(maxTime, GetDOTweenDuration(animation));
            }

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;

                maxTime = Mathf.Max(maxTime, GetParticleDuration(ps));
            }

            if (maxTime <= 0f)
                maxTime = fallbackCompleteSeconds;

            return maxTime;
        }

        private float GetDOTweenDuration(DOTweenAnimation animation)
        {
            if (animation == null) return 0f;

            if (animation.loops < 0)
                return fallbackCompleteSeconds;

            float duration = Mathf.Max(0f, animation.duration);
            float delay = Mathf.Max(0f, animation.delay);
            int loops = Mathf.Max(1, animation.loops);

            return delay + duration * loops;
        }

        private float GetParticleDuration(ParticleSystem ps)
        {
            if (ps == null) return 0f;

            var main = ps.main;

            if (main.loop)
                return fallbackCompleteSeconds;

            float simSpeed = Mathf.Max(0.0001f, main.simulationSpeed);
            float duration = main.duration / simSpeed;
            float delay = main.startDelayMultiplier;
            float lifetime = main.startLifetimeMultiplier;

            return delay + duration + lifetime + 0.05f;
        }

        //����
        private IEnumerator Co_WaitComplete(float completeTime, Action onComplete, int version)
        //���� ����
        {
            float elapsed = 0f;
            float timeout = Mathf.Max(completeTime, fallbackCompleteSeconds);

            yield return null;

            while (elapsed < timeout)
            {
                //�߰�
                if (version != _playVersion) yield break;
                //�߰� ����
                if (!_isPaused)
                {
                    elapsed += _useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
                }

                if (elapsed >= completeTime && !AnyParticleAlive())
                    break;

                yield return null;
            }

            //�߰�
            if (version != _playVersion) yield break;
            //�߰� ����
            _waitCoroutine = null;
            onComplete?.Invoke();
        }

        private bool AnyParticleAlive()
        {
            if (!playChildParticles) return false;

            for (int i = 0; i < particleSystems.Count; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;

                if (ps.IsAlive(true))
                    return true;
            }

            return false;
        }

        private void StopWaitCoroutine()
        {
            if (_waitCoroutine == null) return;

            StopCoroutine(_waitCoroutine);
            _waitCoroutine = null;
        }
    }
}
//�߰� ����