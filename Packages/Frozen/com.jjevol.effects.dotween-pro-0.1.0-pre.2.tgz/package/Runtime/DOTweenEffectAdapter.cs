//추가
using System;
using DG.Tweening;
using UnityEngine;

namespace jjevol.Effect.Renderers
{
    /// <summary>Connects the original root DOTweenAnimation fallback to the existing optional factory list.</summary>
    public static class DOTweenEffectAdapter
    {
        static readonly Func<GameObject,IEffectRenderer> Factory=TryCreate;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        public static void Register()
        {
            EffectRendererAdapters.Factories.Remove(Factory);
            EffectRendererAdapters.Factories.Add(Factory);
        }
        static IEffectRenderer TryCreate(GameObject root)=>root&&root.GetComponent<DOTweenAnimation>()?root.AddComponent<DOTweenEffectRenderer>():null;
    }
}
//추가 종료
