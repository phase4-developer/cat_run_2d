//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using DG.Tweening;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.Effect.DOTweenPro.Tests
{
    public sealed class RendererTests
    {
        readonly List<GameObject> _objects=new();DOTweenEffectRenderer _renderer;DOTweenAnimation _animation;Transform _target;
        static void Set(object o,string n,object v)=>o.GetType().GetField(n,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(o,v);
        static IEnumerator Until(Func<bool> p){float end=Time.realtimeSinceStartup+7;while(!p()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(p(),Is.True);}
        GameObject New(string name,params Type[] types){var go=new GameObject(name,types);_objects.Add(go);return go;}
        [UnitySetUp]public IEnumerator Setup()
        {
            Time.timeScale=1;DOTween.Init(false,true,LogBehaviour.ErrorsOnly);DOTween.KillAll(false);
            var root=New("independent renderer");root.SetActive(false);var target=New("native animation target");target.transform.SetParent(root.transform,false);target.SetActive(false);_target=target.transform;
            _animation=target.AddComponent<DOTweenAnimation>();_animation.autoGenerate=false;_animation.autoPlay=false;_animation.autoKill=false;_animation.isValid=true;_animation.isActive=true;_animation.animationType=DOTweenAnimation.AnimationType.LocalMove;_animation.targetType=DOTweenAnimation.TargetType.Transform;_animation.target=target.transform;_animation.duration=.2f;_animation.endValueV3=new Vector3(2,0,0);_animation.easeType=Ease.Linear;
            _renderer=root.AddComponent<DOTweenEffectRenderer>();target.SetActive(true);root.SetActive(true);yield return null;
        }
        [UnityTearDown]public IEnumerator Cleanup(){Time.timeScale=1;foreach(var go in _objects)if(go)Object.Destroy(go);_objects.Clear();yield return null;yield return null;int remaining=DOTween.TotalActiveTweens();DOTween.KillAll(false);Assert.That(remaining,Is.Zero);}
        [UnityTest]public IEnumerator DisableStopsTheNativeAnimationAndItsWaiter()
        {
            int completed=0;_renderer.Play(0,false,()=>completed++);yield return null;_renderer.enabled=false;yield return new WaitForSecondsRealtime(.35f);
            Assert.That(completed,Is.Zero);Assert.That(_animation.tween==null||!_animation.tween.IsActive(),Is.True);
        }
        [UnityTest]public IEnumerator SwitchingUnscaledTimeUpdatesAnAlreadyCreatedNativeTween()
        {
            _renderer.Play(0,true,()=>{});yield return null;_renderer.SetUnscaledTime(true);Time.timeScale=0;yield return new WaitForSecondsRealtime(.32f);
            Assert.That(_target.localPosition.x,Is.EqualTo(2).Within(.03f));_renderer.StopAndClear();
        }
        [UnityTest]public IEnumerator NativeMotionCompletesOnceAndStopKillsRewindsAndClears()
        {
            int completed=0;_renderer.Play(7,false,()=>completed++);yield return Until(()=>completed==1);Assert.That(_target.localPosition.x,Is.EqualTo(2).Within(.03f));yield return null;Assert.That(completed,Is.EqualTo(1));
            _renderer.StopAndClear();Assert.That(_target.localPosition,Is.EqualTo(Vector3.zero));Assert.That(_animation.tween==null||!_animation.tween.IsActive(),Is.True);
        }
        [UnityTest]public IEnumerator PausedPlaybackResumesAndLoopDefersRendererCompletion()
        {
            int done=0;_renderer.Play(0,false,()=>done++);yield return null;_renderer.SetPaused(true);var position=_target.localPosition;yield return new WaitForSecondsRealtime(.3f);Assert.That(_target.localPosition,Is.EqualTo(position));Assert.That(done,Is.Zero);
            _renderer.SetPaused(false);yield return Until(()=>done==1);_renderer.Play(0,true,()=>done++);yield return new WaitForSecondsRealtime(.35f);Assert.That(done,Is.EqualTo(1));_renderer.StopAndClear();
        }
        [UnityTest]public IEnumerator ReuseCancelsThePreviousCompletionAndRecreatesNativeTween()
        {
            int old=0,current=0;_renderer.Play(0,false,()=>old++);var previous=_animation.tween;yield return new WaitForSecondsRealtime(.06f);_renderer.StopAndClear();_renderer.Play(0,false,()=>current++);
            Assert.That(_animation.tween,Is.Not.SameAs(previous));yield return Until(()=>current==1);Assert.That(old,Is.Zero);
        }
        [UnityTest]public IEnumerator OriginalRetainedTweenFlagsKeepAPausedRewindUntilDestroy()
        {
            Set(_renderer,"killTweenOnStop",false);Set(_renderer,"recreateTweenOnPlay",false);_animation.CreateTween(true,false);var original=_animation.tween;_renderer.Play(0,true,()=>{});yield return null;_renderer.StopAndClear();Assert.That(original.IsActive(),Is.True);Assert.That(original.IsPlaying(),Is.False);Assert.That(_target.localPosition,Is.EqualTo(Vector3.zero));_renderer.Play(0,true,()=>{});Assert.That(_animation.tween,Is.SameAs(original));_renderer.StopAndClear();
        }
        [UnityTest]public IEnumerator OriginalSortingCoversCanvasGroupSpriteAndParticleRenderers()
        {
            var rootCanvas=New("root canvas",typeof(Canvas));rootCanvas.transform.SetParent(_renderer.transform);var canvas=New("nested canvas",typeof(Canvas)).GetComponent<Canvas>();canvas.transform.SetParent(rootCanvas.transform);var group=New("sorting group",typeof(UnityEngine.Rendering.SortingGroup)).GetComponent<UnityEngine.Rendering.SortingGroup>();group.transform.SetParent(_renderer.transform);var sprite=New("sprite",typeof(SpriteRenderer)).GetComponent<SpriteRenderer>();sprite.transform.SetParent(_renderer.transform);var particles=New("particles",typeof(ParticleSystem));particles.transform.SetParent(_renderer.transform);_renderer.SetSorting("Default",42);
            Assert.That(canvas.overrideSorting,Is.True);Assert.That(canvas.sortingOrder,Is.EqualTo(42));Assert.That(group.sortingOrder,Is.EqualTo(42));Assert.That(sprite.sortingOrder,Is.EqualTo(42));Assert.That(particles.GetComponent<ParticleSystemRenderer>().sortingOrder,Is.EqualTo(42));yield return null;
        }
        [UnityTest]public IEnumerator RestoreStateReturnsAuthoredSortingForTheNextRequest()
        {
            var sprite=New("sprite",typeof(SpriteRenderer)).GetComponent<SpriteRenderer>();sprite.transform.SetParent(_renderer.transform);sprite.sortingOrder=3;
            var restore=(IEffectRendererStateRestore)_renderer;restore.CaptureState();_renderer.SetSorting("Default",42);Assert.That(sprite.sortingOrder,Is.EqualTo(42));
            _renderer.StopAndClear();restore.RestoreState();Assert.That(sprite.sortingOrder,Is.EqualTo(3));_renderer.SetSorting("",99);Assert.That(sprite.sortingOrder,Is.EqualTo(3));yield return null;
        }
        [UnityTest]public IEnumerator InvalidProConfigurationWarnsAndUsesOriginalCompletionFallback()
        {
            _animation.isValid=false;LogAssert.Expect(LogType.Warning,new System.Text.RegularExpressions.Regex("DOTweenAnimation isn't valid"));int complete=0;_renderer.Play(0,false,()=>complete++);Assert.That(_animation.tween,Is.Null);yield return Until(()=>complete==1);Assert.That(_target.localPosition,Is.EqualTo(Vector3.zero),"Fallback completion does not mean the invalid animation rendered successfully");
        }
    }
}
//추가 종료
