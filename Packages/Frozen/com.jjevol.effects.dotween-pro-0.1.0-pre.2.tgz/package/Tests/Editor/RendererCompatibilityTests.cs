//추가
using System;
using System.Linq;
using System.Reflection;
using DG.Tweening;
using jjevol.Effect.Renderers;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;
namespace jjevol.Effect.DOTweenPro.Tests
{
    public sealed class RendererCompatibilityTests
    {
        [Test]public void OriginalGuidRendererContractAndTenSerializedFieldsArePreserved()
        {
            string path=AssetDatabase.GUIDToAssetPath("6e7b7a4af53e4d64d95552d9f1ed8edf");StringAssert.EndsWith("com.jjevol.effects.dotween-pro/Runtime/DOTweenEffectRenderer.cs",path);Assert.That(AssetDatabase.LoadAssetAtPath<MonoScript>(path).GetClass(),Is.EqualTo(typeof(DOTweenEffectRenderer)));Assert.That(typeof(IEffectRenderer).IsAssignableFrom(typeof(DOTweenEffectRenderer)),Is.True);
            var fields=typeof(DOTweenEffectRenderer).GetFields(BindingFlags.DeclaredOnly|BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).Where(f=>f.IsPublic||f.IsDefined(typeof(SerializeField),true)).ToArray();Assert.That(fields.Length,Is.EqualTo(10));foreach(string name in new[]{"Play","StopAndClear","SetPaused","SetUnscaledTime","SetSorting","SetSkin"})Assert.That(typeof(DOTweenEffectRenderer).GetMethod(name),Is.Not.Null);
        }
        [Test]public void RealSdkAssemblyAndOriginalCollectionSerializationRemainAvailable()
        {
            Assert.That(DOTween.Version,Is.EqualTo("1.2.765"));Assert.That(typeof(DOTweenAnimation).BaseType.Assembly.GetType("DG.Tweening.DOTweenPro").GetField("Version",BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).GetValue(null),Is.EqualTo("1.0.381"));Assert.That(typeof(DOTweenEffectRenderer).Assembly.GetName().Name,Is.EqualTo("JJEvol.Effects.DOTweenPro.Runtime"));
            if(!System.IO.Path.GetFullPath(Application.dataPath).Replace('\\','/').Contains("/.local/dotween-validation/"))throw new InvalidOperationException("STEP16 Host only");const string path="Assets/Step16EffectSerialization.prefab";var go=new GameObject("serialization");go.SetActive(false);
            try{var a=go.AddComponent<DOTweenAnimation>();a.autoGenerate=false;var renderer=go.AddComponent<DOTweenEffectRenderer>();var so=new SerializedObject(renderer);so.FindProperty("fallbackCompleteSeconds").floatValue=7;var list=so.FindProperty("dotweenAnimations");list.arraySize=1;list.GetArrayElementAtIndex(0).objectReferenceValue=a;so.ApplyModifiedPropertiesWithoutUndo();PrefabUtility.SaveAsPrefabAsset(go,path);Object.DestroyImmediate(go);AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceUpdate);var restored=AssetDatabase.LoadAssetAtPath<GameObject>(path);var saved=new SerializedObject(restored.GetComponent<DOTweenEffectRenderer>());Assert.That(saved.FindProperty("fallbackCompleteSeconds").floatValue,Is.EqualTo(7));Assert.That(saved.FindProperty("dotweenAnimations").GetArrayElementAtIndex(0).objectReferenceValue,Is.SameAs(restored.GetComponent<DOTweenAnimation>()));}
            finally{if(go)Object.DestroyImmediate(go);AssetDatabase.DeleteAsset(path);}
        }
    }
}
//추가 종료
