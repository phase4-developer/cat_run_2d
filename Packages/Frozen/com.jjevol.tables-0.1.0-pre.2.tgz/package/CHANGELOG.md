# Changelog

## 0.1.0-pre.2 - 2026-11-06

- A failed reload read or parse leaves the previous rows. Added `CaptureData` and `RestoreData`.
- Integer lists parse with InvariantCulture. Keyed and Indexed `Datas` are read-only views.
- Reset `TableRepository` when Domain Reload is disabled.

Unity tests for this candidate are NOT_RUN.

# 0.1.0-pre.1 — 2026-10-31

Local extraction candidate of existing table containers, repository and TSV parser. GameTableSource configuration and Host-owned string localization/decryption/path contracts separate Common backend dependencies. Resources async loading uses the built-in completion event instead of UniTask. Fixed reproduced worker-thread Resources fallback in LoadStaticTableAsync. Typed Localization entry API and Firebase ServerTableSource remain outside active Core; full mobile feature transfer is PARTIAL. No publication/snapshot/game migration.
