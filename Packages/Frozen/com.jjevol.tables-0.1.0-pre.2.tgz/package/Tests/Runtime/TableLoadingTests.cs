using System;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using jjevol.Data;

namespace jjevol.Tables.Tests
{
    public sealed class TableLoadingTests
    {
        const string Plain = "JJEvolTablesStep7/plain";
        const string Encrypted = "JJEvolTablesStep7/encrypted";
        string directory;
        static IEnumerator Complete(Task task)
        {
            float end=Time.realtimeSinceStartup+5;
            while(!task.IsCompleted && Time.realtimeSinceStartup<end) yield return null;
            Assert.IsTrue(task.IsCompleted,"Table load timed out");
            if(task.IsFaulted) Assert.Fail(task.Exception.ToString());
        }
        [SetUp] public void Setup()
        {
            directory=Path.GetFullPath(Path.Combine(Application.dataPath,"../Temp/JJEvolStep7_"+Guid.NewGuid().ToString("N")));
            Directory.CreateDirectory(directory);TableRepository.Clear();TableRuntimeOptions.DecryptBytes=null;
            TableRuntimeOptions.StaticTablePath=null;TableRuntimeOptions.Localization=null;
        }
        [TearDown] public void Cleanup()
        {
            TableRepository.Clear();TableRuntimeOptions.DecryptBytes=null;TableRuntimeOptions.StaticTablePath=null;
            GameTableSource.Configure(new PackagedTableSource());
            var allowed=Path.GetFullPath(Path.Combine(Application.dataPath,"../Temp"))+Path.DirectorySeparatorChar;
            if(directory.StartsWith(allowed,StringComparison.OrdinalIgnoreCase) && Directory.Exists(directory)) Directory.Delete(directory,true);
        }
        [UnityTest] public IEnumerator RealResourcesSourceLoadsAndRepositoryQueriesSample()
        {
            var source=new PackagedTableSource(false);Assert.IsTrue(source.HasTable(Plain));Assert.IsFalse(source.RequiresRemoteUpdate);
            GameTableSource.Configure(source);var table=new FixtureIndexed(Plain);TableRepository.Register(table);
            var task=TableRepository.LoadAllAsync();yield return Complete(task);
            Assert.IsTrue(TableRepository.loaded);Assert.AreEqual(2,table.Datas.Count);
            Assert.AreEqual("sample_one",table.Get(123456001).key);Assert.AreEqual(123456002,table.Get(123456001).link);
            var sync=source.Load(Plain);Assert.AreEqual(2,sync.Count);Assert.IsFalse(source.HasTable("JJEvolTablesStep7/missing"));
        }
        [UnityTest] public IEnumerator OriginalEncryptedDefaultUsesExplicitRealAesDecoder()
        {
            TableRuntimeOptions.DecryptBytes=FixtureCrypto.Decrypt;
            var source=new PackagedTableSource();Assert.AreEqual(2,source.Load(Encrypted).Count);
            var task=source.LoadAsync(Encrypted);yield return Complete(task);Assert.AreEqual("sample_one",task.Result[0].GetString("key"));
        }
        [UnityTest] public IEnumerator MissingCryptoProviderFailsInsteadOfTreatingEncryptedTextAsPlaintext()
        {
            LogAssert.Expect(LogType.Error,new Regex("\\[TableUtil\\] Table load failed\\."));
            LogAssert.Expect(LogType.Exception,new Regex("InvalidOperationException: Configure TableRuntimeOptions.DecryptBytes"));
            var task=new PackagedTableSource().LoadAsync(Encrypted);
            float end=Time.realtimeSinceStartup+5;while(!task.IsCompleted && Time.realtimeSinceStartup<end)yield return null;
            Assert.IsTrue(task.IsFaulted);Assert.IsInstanceOf<InvalidOperationException>(task.Exception.InnerException);
        }
        [Test] public void MissingResourceRetainsLoggedFileNotFoundFailure()
        {
            LogAssert.Expect(LogType.Error,new Regex("Resources table is null"));
            LogAssert.Expect(LogType.Error,new Regex("Table load failed"));
            LogAssert.Expect(LogType.Exception,new Regex("FileNotFoundException"));
            Assert.Throws<FileNotFoundException>(()=>new PackagedTableSource(false).Load("JJEvolTablesStep7/missing"));
        }
        [Test] public void InvalidBase64AndFailedDecodeRetainErrorContract()
        {
            var path=Path.Combine(directory,"bad.txt");File.WriteAllText(path,"%invalid%");
            LogAssert.Expect(LogType.Error,new Regex("Table Base64 format error"));LogAssert.Expect(LogType.Error,new Regex("Table load failed"));
            LogAssert.Expect(LogType.Exception,new Regex("FormatException"));
            Assert.Throws<FormatException>(()=>TableUtil.LoadStaticTableWithExplicitPath(path,"unused"));
            File.WriteAllText(path,Convert.ToBase64String(new byte[]{1,2,3}));TableRuntimeOptions.DecryptBytes=_=>null;
            LogAssert.Expect(LogType.Error,new Regex("Table load failed"));LogAssert.Expect(LogType.Exception,new Regex("InvalidDataException"));
            Assert.Throws<InvalidDataException>(()=>TableUtil.LoadStaticTableWithExplicitPath(path,"unused"));
        }
        [UnityTest] public IEnumerator StaticFileAndResourcesFallbackLoadAsyncOnUnityThread()
        {
            var file=Path.Combine(directory,"sample.txt");File.WriteAllText(file,"id\tkey\n123456001\tfile");
            TableRuntimeOptions.StaticTablePath=_=>file;
            var task=TableUtil.LoadStaticTableAsync("ignored",false);yield return Complete(task);Assert.AreEqual("file",task.Result[0].GetString("key"));
            File.Delete(file);
            LogAssert.Expect(LogType.Warning,new Regex("Static file is not exist. Fallback to Resources"));
            task=TableUtil.LoadStaticTableAsync(Plain,false);yield return Complete(task);Assert.AreEqual(2,task.Result.Count);
        }
        [UnityTest] public IEnumerator LocalExplicitPathRemainsDiagnosticOnlyAndNoKeyRenameIsApplied()
        {
            var rows=TableUtil.LoadLocalTableWithExplicitPath("diagnostic-path",Plain,false);
            Assert.AreEqual(2,rows.Count);var task=TableUtil.LoadLocalFileAsync(Plain);yield return Complete(task);
            StringAssert.StartsWith("id\tkey",task.Result);
        }
    }
}
