using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace jjevol.Tables.Tests
{
    public sealed class FixtureRow : TableData
    {
        public string key;
        public int group;
        public int link;
        public FixtureRow(TSVRow row) : base(row)
        {
            key = row.GetString("key"); group = row.GetInt("group"); link = row.GetInt("link");
        }
    }
    public sealed class FixtureSource : ITableSource
    {
        public readonly Dictionary<string, string> Texts = new();
        public readonly List<string> Calls = new();
        public Exception Failure;
        public bool RequiresRemoteUpdate => false;
        public bool HasTable(string name) => Texts.ContainsKey(name);
        public List<TSVRow> Load(string name)
        {
            Calls.Add(name); if (Failure != null) throw Failure;
            return TSVRow.FromTsv(Texts[name]);
        }
        public Task<List<TSVRow>> LoadAsync(string name) => Task.FromResult(Load(name));
    }
    public sealed class FixtureIndexed : IndexedTable<FixtureRow>
    {
        public FixtureIndexed(string name = "fixture") : base(name) { }
        protected override FixtureRow ParseJson(TSVRow row) => new FixtureRow(row);
    }
    public sealed class FixtureKeyed : KeyedTable<string, FixtureRow>
    {
        public FixtureKeyed() : base("fixture") { }
        protected override FixtureRow ParseJson(TSVRow row) => new FixtureRow(row);
        protected override string GetKey(FixtureRow row) => row.key;
    }
    public sealed class FixtureGrouped : GroupedTable<int, FixtureRow>
    {
        public FixtureGrouped() : base("fixture") { }
        protected override FixtureRow ParseJson(TSVRow row) => new FixtureRow(row);
        protected override int GetKey(FixtureRow row) => row.group;
    }
    public sealed class FixtureList : ListTable<FixtureRow>
    {
        public FixtureList() : base("fixture") { }
        protected override FixtureRow ParseJson(TSVRow row) => new FixtureRow(row);
    }
    public static class FixtureCrypto
    {
        // Synthetic fixture key, not a mobile game key or a production encryption format.
        public static byte[] Decrypt(byte[] bytes)
        {
            using var aes = Aes.Create();
            using var sha = SHA256.Create();
            aes.Key = sha.ComputeHash(Encoding.UTF8.GetBytes("JJEvol-STEP7-test-only"));
            aes.IV = new byte[16];
            using var decoder = aes.CreateDecryptor();
            return decoder.TransformFinalBlock(bytes, 0, bytes.Length);
        }
    }
}
