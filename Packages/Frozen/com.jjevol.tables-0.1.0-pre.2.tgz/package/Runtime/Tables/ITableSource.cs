using System.Collections.Generic;
using System.Threading.Tasks;

namespace jjevol
{
    public interface ITableSource
    {
        bool RequiresRemoteUpdate { get; }
        bool HasTable(string tableName);
        List<TSVRow> Load(string tableName);
        Task<List<TSVRow>> LoadAsync(string tableName);
    }
}
