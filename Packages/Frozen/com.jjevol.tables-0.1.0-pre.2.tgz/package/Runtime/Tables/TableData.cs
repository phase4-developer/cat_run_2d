﻿// TableData.cs

namespace jjevol
{
    public abstract class TableData : ListDataBase
    {
        public const string NAME_COLLECTION = "name";
        public const string DESCRIPTION_COLLECTION = "description";

        public int id { get; protected set; }

        public int table => (id / 1000000) % 1000;
        public int category => (id / 1000) % 1000;
        public int index => id % 1000;

        public int sort { get; protected set; }

        public int grade {  get; protected set; }

        // {id}_name, {id}_description 키로 로컬라이즈된 문자열 반환
        public virtual string name => GetLoc(NAME_COLLECTION, nameKey);
        public virtual string description => GetLoc(DESCRIPTION_COLLECTION, descriptionKey); // 오타 키도 보조로 허용

        protected string nameKey;
        protected string descriptionKey;

        public TableData(TSVRow data = null)
        {
            if (data != null)
                Init(data);
        }

        public virtual void Init(TSVRow data)
        {
            _SetData(data);
        }

        private void _SetData(TSVRow data)
        {
            if (data != null)
            {
                if (data.Get("ID") != null)
                    this.id = data.GetInt("ID", 9999);
                else if (data.Get("id") != null)
                    this.id = data.GetInt("id", 9999);

                if (data.Get("grade") != null)
                    this.grade = data.GetInt("grade");

                if (data.Get("sort") != null)
                    this.sort = data.GetInt("sort");
                else
                    this.sort = id;

                if ( data.Get("nameKey") != null)
                    nameKey = data.GetString("nameKey");

                if (string.IsNullOrEmpty(nameKey))
                    nameKey = $"{id}";

                if (data.Get("descriptionKey") != null)
                    descriptionKey = data.GetString("descriptionKey");

                if (string.IsNullOrEmpty(descriptionKey))
                    descriptionKey = $"{id}";
            }
        }

        // --- helpers ---
        public  static string GetLoc(string collection, string key, bool returnDebugKey = true)
        {
            if (string.IsNullOrEmpty(key)) return string.Empty;
            var localization = TableRuntimeOptions.Localization;
            if (localization == null || !localization.IsReady || string.IsNullOrEmpty(collection))
                return key; // 설정 전이면 키를 그대로 반환(개발 중 확인용)

            var value = localization.GetString(collection, key);
            if (value == null)
                return returnDebugKey ? key : string.Empty; // 키가 없으면 키를 그대로 반환

            return value;
        }

        // 보조 키(오타 등)까지 시도
        public static string GetLocWithFallback(string collection, string primaryKey, string secondaryKey)
        {
            var s = GetLoc(collection,primaryKey);
            if (!string.IsNullOrEmpty(s) && s != primaryKey) return s;

            // 2차 키 시도
            s = GetLoc(collection,secondaryKey);
            return (!string.IsNullOrEmpty(s) && s != secondaryKey) ? s : primaryKey;
        }
    }
}
