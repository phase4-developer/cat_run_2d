using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace jjevol
{
    public interface ITable
    {
        Type RowType { get; }
        string TableName { get; }
    }

    public abstract class TableBase : ITable
    {
        public abstract Type RowType { get; }

        protected string _tableName;

        public string TableName => _tableName;

        protected TableBase(string tableName)
        {
            _tableName = tableName;
        }

        public virtual void LoadDatas()
        {
            _ClearAndLoadData(TableName);
        }

        public void LoadDatas(ITableSource source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            var rows = source.Load(TableName);
            ReplaceData(rows);
        }

        public virtual async Task LoadDatasAsync()
        {
            var tableDatas = await LoadTableDataAsync(TableName);
            ReplaceData(tableDatas);
        }

        protected void _ClearAndLoadData(string _tableName)
        {
            // Read before clearing, so a failed read leaves the current rows.
            ReplaceData(LoadTableData(_tableName));
        }

        private void ReplaceData(List<TSVRow> rows)
        {
            var previous = CaptureData();
            _DataClear();
            InsertOrRestore(rows, previous);
        }

        // The existing clear and insert hooks keep running in order; a parse failure puts the previous rows back.
        private void InsertOrRestore(List<TSVRow> rows, object previous)
        {
            try { InsertData(rows); }
            catch
            {
                _DataClear();
                RestoreData(previous);
                throw;
            }
        }

        /// <summary>Copy the current rows so a failed reload can put them back. Without an override a failed reload leaves the table empty.</summary>
        protected virtual object CaptureData() => null;

        /// <summary>Put back what CaptureData returned. Called on an empty table.</summary>
        protected virtual void RestoreData(object captured) { }

        protected List<TSVRow> LoadTableData(string tableName) => GameTableSource.Current.Load(tableName);

        protected Task<List<TSVRow>> LoadTableDataAsync(string tableName) => GameTableSource.Current.LoadAsync(tableName);

        protected abstract void _DataClear();
        protected abstract void InsertData(List<TSVRow> datas);
    }

    // One array per load replaces one copy per Datas access. Enumeration keeps the array it started with,
    // so a reload during a loop does not invalidate that loop.
    internal sealed class TableValuesView<TKey, TData> : IReadOnlyList<TData>
    {
        private readonly Dictionary<TKey, TData> _source;
        private TData[] _values;

        internal TableValuesView(Dictionary<TKey, TData> source)
        {
            _source = source;
        }

        public int Count => _source.Count;

        public TData this[int index]
        {
            get
            {
                TData[] values = Values();
                if (index < 0 || index >= values.Length) throw new ArgumentOutOfRangeException(nameof(index));
                return values[index];
            }
        }

        internal void Invalidate()
        {
            _values = null;
        }

        // Derived tables can write the dictionary directly, so a changed count also refreshes the array.
        private TData[] Values()
        {
            if (_values == null || _values.Length != _source.Count)
            {
                var values = new TData[_source.Count];
                _source.Values.CopyTo(values, 0);
                _values = values;
            }

            return _values;
        }

        public IEnumerator<TData> GetEnumerator() => ((IEnumerable<TData>)Values()).GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
