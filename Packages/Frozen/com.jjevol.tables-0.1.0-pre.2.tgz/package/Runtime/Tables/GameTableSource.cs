using System;
using UnityEngine;

namespace jjevol
{
    public static class GameTableSource
    {
        private static ITableSource _current;
        public static ITableSource Current => _current ??= new PackagedTableSource();

        public static void Configure(ITableSource source) => _current = source ?? throw new ArgumentNullException(nameof(source));

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            _current = null;
        }
    }
}
