
using System;
using System.Collections.Generic;

namespace jjevol
{
    public abstract class KeyedTable<TKey, TData> : TableBase
        where TKey : notnull
        where TData : TableData
    {
        protected KeyedTable(string tableName) : base(tableName)
        {
        }

        public override Type RowType => typeof(TData);

        protected readonly Dictionary<TKey, TData> _dict = new();
        public IReadOnlyDictionary<TKey, TData> Dict => _dict;

        private TableValuesView<TKey, TData> _datas;

        /// <summary>Read-only view of the rows. It stays valid across reloads and shows the current rows.</summary>
        public IReadOnlyList<TData> Datas => _datas ??= new TableValuesView<TKey, TData>(_dict);

        protected abstract TKey GetKey(TData data);
        protected abstract TData ParseJson(TSVRow json);

        protected override void InsertData(List<TSVRow> datas)
        {
            _dict.Clear();
            _datas?.Invalidate();
            if (datas == null) return;

            foreach (var json in datas)
            {
                var data = ParseJson(json);
                var key = GetKey(data);

                _InsertData(key, data);
            }

            _datas?.Invalidate();
        }

        protected virtual void _InsertData(TKey key, TData data)
        {
            _dict[key] = data;
            _datas?.Invalidate();
        }

        protected override void _DataClear()
        {
            _dict.Clear();
            _datas?.Invalidate();
        }

        protected override object CaptureData() => new Dictionary<TKey, TData>(_dict);

        protected override void RestoreData(object captured)
        {
            foreach (var pair in (Dictionary<TKey, TData>)captured)
                _InsertData(pair.Key, pair.Value);
        }

        public TData Get(TKey key)
        {
            _dict.TryGetValue(key, out var value);
            return value;
        }
    }
}