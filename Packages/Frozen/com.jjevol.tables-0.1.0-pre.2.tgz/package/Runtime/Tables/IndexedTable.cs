using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    public abstract class IndexedTable<TData> : TableBase where TData : TableData
    {
        public override Type RowType => typeof(TData);
        protected Dictionary<int, TData> _dict { get; } = new();
        private readonly List<(string name, Func<TSVRow, TData> parse)> _additionalSources = new();

        public IReadOnlyList<string> SourceTableNames => new[] { TableName }.Concat(_additionalSources.Select(source => source.name)).ToArray();

        protected IndexedTable(string tableName) : base(tableName)
        {
        }

        protected abstract TData ParseJson(TSVRow data);

        public void AddSource<TSource>(string tableName, Func<TSVRow, TSource> parse) where TSource : TData
        {
            if (string.IsNullOrWhiteSpace(tableName) || parse == null) throw new ArgumentException("Table source and parser are required.");
            if (SourceTableNames.Contains(tableName)) throw new ArgumentException($"Duplicate table source: {tableName}");
            _additionalSources.Add((tableName, row => parse(row)));
        }

        public override void LoadDatas()
        {
            if (_additionalSources.Count == 0) { base.LoadDatas(); return; }
            var parsed = LoadTableData(TableName).Select(ParseJson).ToList();
            foreach (var source in _additionalSources) parsed.AddRange(LoadTableData(source.name).Select(source.parse));
            ReplaceSourceData(parsed);
        }

        public override async Task LoadDatasAsync()
        {
            if (_additionalSources.Count == 0) { await base.LoadDatasAsync(); return; }
            var parsed = (await LoadTableDataAsync(TableName)).Select(ParseJson).ToList();
            foreach (var source in _additionalSources) parsed.AddRange((await LoadTableDataAsync(source.name)).Select(source.parse));
            ReplaceSourceData(parsed);
        }

        private void ReplaceSourceData(List<TData> records)
        {
            var next = new Dictionary<int, TData>();
            foreach (TData record in records)
                if (!next.TryAdd(record.id, record)) throw new InvalidDataException($"Duplicate ID in table sources: {TableName}, {record.id}");
            _DataClear();
            foreach (var record in next) _dict.Add(record.Key, record.Value);
            _datas?.Invalidate();
        }

        protected override void InsertData(List<TSVRow> datas)
        {
            _dict.Clear();
            _datas?.Invalidate();

            if (datas == null) return;

            foreach (var json in datas)
            {
                var data = ParseJson(json);

                if (_dict.ContainsKey(data.id))
                    _dict[data.id] = data; // 덮어쓰기
                else
                    _dict.Add(data.id, data);
            }

            _datas?.Invalidate();
        }

        protected override void _DataClear()
        {
            _dict.Clear();
            _datas?.Invalidate();
        }

        protected override object CaptureData() => new Dictionary<int, TData>(_dict);

        protected override void RestoreData(object captured)
        {
            foreach (var record in (Dictionary<int, TData>)captured)
                _dict.Add(record.Key, record.Value);

            _datas?.Invalidate();
        }

        public IReadOnlyDictionary<int, TData> Dict => _dict;

        private TableValuesView<int, TData> _datas;

        /// <summary>Read-only view of the rows. It stays valid across reloads and shows the current rows.</summary>
        public IReadOnlyList<TData> Datas => _datas ??= new TableValuesView<int, TData>(_dict);

        public TData Get(int id)
        {
            if (_dict.ContainsKey(id)) return _dict[id];

            return null;
        }
    }
}
