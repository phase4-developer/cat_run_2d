﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace jjevol.Data
{
    public static class TableRepository
    {
        private static readonly List<TableBase> _allTables = new();
        public static bool loaded { get; private set; } = false;

        // With Domain Reload disabled, registrations and the one-shot flag must not carry into the next Play session.
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetSession()
        {
            Clear();
        }

        public static void Register(TableBase table)
        {
            _allTables.Add(table);
        }

        public static void LoadAll()
        {
            if (loaded) return;

            foreach (var table in _allTables)
                table.LoadDatas();

            loaded = true;
        }

        public static async Task LoadAllAsync(Action<float> onProgress = null)
        {
            if (loaded)
            {
                onProgress?.Invoke(1f);
                return;
            }

            int totalCount = _allTables.Count;

            if (totalCount <= 0)
            {
                loaded = true;
                onProgress?.Invoke(1f);
                return;
            }

            onProgress?.Invoke(0f);

            for (int i = 0; i < totalCount; i++)
            {
                await _allTables[i].LoadDatasAsync();
                onProgress?.Invoke((i + 1f) / totalCount);
            }

            loaded = true;
        }

        public static void Clear()
        {
            _allTables.Clear();
            loaded = false;
        }
    }
}
