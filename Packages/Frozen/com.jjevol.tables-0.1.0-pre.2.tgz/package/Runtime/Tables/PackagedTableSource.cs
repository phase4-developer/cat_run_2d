using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace jjevol
{
    public sealed class PackagedTableSource : ITableSource
    {
        private readonly bool _useEncrypt;
        public PackagedTableSource() : this(true) { }
        public PackagedTableSource(bool useEncrypt) => _useEncrypt = useEncrypt;
        public bool RequiresRemoteUpdate => false;

        public bool HasTable(string tableName) => Resources.Load<TextAsset>(tableName) != null;
        public List<TSVRow> Load(string tableName) => TableUtil.LoadLocalTable(tableName, _useEncrypt);
        public Task<List<TSVRow>> LoadAsync(string tableName) => TableUtil.LoadLocalTableAsync(tableName, _useEncrypt);
    }
}
