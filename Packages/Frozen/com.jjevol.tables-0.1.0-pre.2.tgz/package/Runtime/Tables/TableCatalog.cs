using System;
using System.Collections.Generic;
using System.Linq;

namespace jjevol
{
    public sealed class TableCatalog<TData> where TData : TableData
    {
        private readonly List<Func<int, TData>> _lookups = new();
        private readonly List<Func<IEnumerable<TData>>> _sources = new();

        public TableCatalog<TData> Add<TSource>(Func<IndexedTable<TSource>> source) where TSource : TData
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            _lookups.Add(id => source()?.Get(id));
            _sources.Add(() => source()?.Datas.Cast<TData>() ?? Enumerable.Empty<TData>());
            return this;
        }

        public TData Get(int id)
        {
            foreach (var lookup in _lookups)
            {
                TData data = lookup(id);
                if (data != null) return data;
            }
            return null;
        }

        public TSource Get<TSource>(int id) where TSource : TData => Get(id) as TSource;
        public IEnumerable<TData> Datas => _sources.SelectMany(source => source());
    }
}
