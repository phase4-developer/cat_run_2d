using System;
using UnityEngine;

namespace jjevol
{
    /// <summary>Host-owned integrations; no backend, crypto key or Localization SDK is bundled.</summary>
    public static class TableRuntimeOptions
    {
        public static ITableLocalization Localization { get; set; }
        public static Func<byte[], byte[]> DecryptBytes { get; set; }
        public static Func<string, string> StaticTablePath { get; set; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState()
        {
            Localization = null;
            DecryptBytes = null;
            StaticTablePath = null;
        }
    }

    public interface ITableLocalization
    {
        bool IsReady { get; }
        // null means missing entry; empty string is an existing, empty localized value.
        string GetString(string collection, string key);
    }
}
