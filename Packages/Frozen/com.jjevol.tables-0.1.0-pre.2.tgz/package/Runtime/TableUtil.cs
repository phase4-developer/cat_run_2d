using System.Collections.Generic;
using UnityEngine;
using System.Collections;
using System;
using System.IO;
using System.Text;
using System.Reflection;
using System.Linq;
using System.Threading.Tasks;

namespace jjevol
{
    public class TableUtil
    {
        public static string GetTablePath(string tableName)
        {
            if (TableRuntimeOptions.StaticTablePath != null) return TableRuntimeOptions.StaticTablePath(tableName);
            string fileName = Path.GetFileName(tableName);
            if (!fileName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase)) fileName += ".txt";
            return Path.Combine(Application.persistentDataPath, "Assets", "Table", fileName);
        }


        /// <summary>
        /// window appdata
        /// android /storage/emulated/0/Android/data/<packagename>/files
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="useEncrypt"></param>
        /// <param name="debuglog"></param>
        public static List<TSVRow> LoadStaticTable(string tableName, bool useEncrypt = true, bool debuglog = false)
        {
            string fullPath = GetTablePath(tableName);

            return LoadStaticTableWithExplicitPath(fullPath, tableName, useEncrypt, debuglog);
        }

        public static List<TSVRow> LoadStaticTableWithExplicitPath(string fullPath, string tableName, bool useEncrypt = true, bool debuglog = false)
        {
            string tableData = string.Empty;
            string loadSource = "Static";

            try
            {
                if (!File.Exists(fullPath))
                {
                    Debug.LogWarning($"[TableUtil] Static file is not exist. Fallback to Resources. Table:{tableName}, Path:{fullPath}");

                    loadSource = "ResourcesFallback";
                    tableData = LoadLocalFile(tableName);
                }
                else
                {
                    tableData = LoadFile(fullPath);
                }

                if (useEncrypt)
                {
                    tableData = DecryptTableData(tableData, tableName, fullPath, loadSource);

                    if (debuglog)
                        WriteString(tableData, tableName);
                }

                return TSVRow.FromTsv(tableData);
            }
            catch (Exception e)
            {
                LogTableLoadError(e, tableName, fullPath, loadSource, tableData, useEncrypt);
                throw;
            }
        }

        public static async Task<List<TSVRow>> LoadStaticTableAsync(string tableName, bool useEncrypt = true, bool debuglog = false)
        {
            string fullPath = GetTablePath(tableName);
            string tableData = string.Empty;
            string loadSource = "Static";
            try
            {
                // Only file I/O runs on a worker; Resources must execute on Unity's caller context.
                string fileData = await Task.Run(() => File.Exists(fullPath) ? LoadFile(fullPath) : null);
                if (fileData == null)
                {
                    Debug.LogWarning($"[TableUtil] Static file is not exist. Fallback to Resources. Table:{tableName}, Path:{fullPath}");
                    loadSource = "ResourcesFallback";
                    tableData = await LoadLocalFileAsync(tableName);
                }
                else tableData = fileData;

                if (useEncrypt)
                {
                    tableData = DecryptTableData(tableData, tableName, fullPath, loadSource);
                    if (debuglog) WriteString(tableData, tableName);
                }
                return TSVRow.FromTsv(tableData);
            }
            catch (Exception e)
            {
                LogTableLoadError(e, tableName, fullPath, loadSource, tableData, useEncrypt);
                throw;
            }
        }

        public static List<TSVRow> LoadLocalTable(string tableName, bool useEncrypt = true, bool debuglog = false)
        {
            string fullPath = "Resources/" + tableName;

            return LoadLocalTableWithExplicitPath(fullPath, tableName, useEncrypt, debuglog);

        }

        public static List<TSVRow> LoadLocalTableWithExplicitPath(string fullPath, string tableName, bool useEncrypt = true, bool debuglog = false)
        {
            string tableData = string.Empty;
            string loadSource = "Resources";

            try
            {
                tableData = LoadLocalFile(tableName);

                if (useEncrypt)
                {
                    tableData = DecryptTableData(tableData, tableName, fullPath, loadSource);

                    if (debuglog)
                        WriteString(tableData, tableName);
                }

                return TSVRow.FromTsv(tableData);
            }
            catch (Exception e)
            {
                LogTableLoadError(e, tableName, fullPath, loadSource, tableData, useEncrypt);
                throw;
            }
        }

        public static async Task<List<TSVRow>> LoadLocalTableAsync(
            string tableName,
            bool useEncrypt = true,
            bool debuglog = false)
        {
            string fullPath = "Resources/" + tableName;
            string tableData = string.Empty;
            string loadSource = "Resources";

            try
            {
                tableData = await LoadLocalFileAsync(tableName);

                if (useEncrypt)
                {
                    tableData = DecryptTableData(
                        tableData,
                        tableName,
                        fullPath,
                        loadSource
                    );

                    if (debuglog)
                        WriteString(tableData, tableName);
                }

                return TSVRow.FromTsv(tableData);
            }
            catch (Exception e)
            {
                LogTableLoadError(
                    e,
                    tableName,
                    fullPath,
                    loadSource,
                    tableData,
                    useEncrypt
                );

                throw;
            }
        }

        public static async Task<string> LoadLocalFileAsync(string tableName)
        {
            string path = tableName;

            ResourceRequest request =
                Resources.LoadAsync<TextAsset>(path);

            if (!request.isDone)
            {
                var completion = new TaskCompletionSource<bool>();
                request.completed += _ => completion.TrySetResult(true);
                if (request.isDone) completion.TrySetResult(true);
                await completion.Task;
            }

            TextAsset textAsset =
                request.asset as TextAsset;

            if (textAsset == null)
            {
                string message =
                    $"[TableUtil] Resources table is null. " +
                    $"Table:{tableName}, ResourcesPath:{path}";

                Debug.LogError(message);

                throw new FileNotFoundException(
                    message,
                    path
                );
            }

            return textAsset.text;
        }

        /// <summary>
        /// project folder
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="useEncrypt"></param>
        public static string LoadFile(string fullPath)
        {
            using FileStream fileStreem = File.OpenRead(fullPath);
            using StreamReader sr = new StreamReader(fileStreem, Encoding.UTF8);
            return sr.ReadToEnd();
        }

        public static string LoadLocalFile(string tableName)
        {
            string path = tableName;
            TextAsset textAsset = Resources.Load(path, typeof(TextAsset)) as TextAsset;

            if (textAsset == null)
            {
                string message = $"[TableUtil] Resources table is null. Table:{tableName}, ResourcesPath:{path}";
                Debug.LogError(message);
                throw new FileNotFoundException(message, path);
            }

            return textAsset.text;
        }

        private static string DecryptTableData(string tableData, string tableName, string fullPath, string loadSource)
        {
            if (string.IsNullOrEmpty(tableData))
            {
                throw new InvalidDataException($"Table data is empty. Table:{tableName}, Source:{loadSource}, Path:{fullPath}");
            }

            byte[] encryptedBytes = null;

            try
            {
                encryptedBytes = Convert.FromBase64String(tableData);
            }
            catch (FormatException e)
            {
                Debug.LogError(
                    "[TableUtil] Table Base64 format error.\n" +
                    $"Table: {tableName}\n" +
                    $"Source: {loadSource}\n" +
                    $"Path: {fullPath}\n" +
                    $"Length: {tableData.Length}\n" +
                    $"Preview: {GetPreview(tableData)}\n" +
                    "Reason: 암호화된 Base64 테이블 파일이 아니거나, 잘못된 txt/tsv/html 파일을 읽고 있습니다."
                );

                throw new FormatException($"Invalid Base64 table data. Table:{tableName}, Source:{loadSource}, Path:{fullPath}", e);
            }

            byte[] decryptResult = null;

            var decrypt = TableRuntimeOptions.DecryptBytes;
            if (decrypt == null)
                throw new InvalidOperationException("Configure TableRuntimeOptions.DecryptBytes for encrypted tables, or explicitly select plaintext loading.");
            decryptResult = decrypt(encryptedBytes);
            bool decryptSuccess = decryptResult != null && decryptResult.Length > 0;

            if (!decryptSuccess || decryptResult == null || decryptResult.Length <= 0)
            {
                throw new InvalidDataException($"Table decrypt failed. Table:{tableName}, Source:{loadSource}, Path:{fullPath}");
            }

            return Encoding.UTF8.GetString(decryptResult);
        }

        private static void LogTableLoadError(Exception exception, string tableName, string fullPath, string loadSource, string tableData, bool useEncrypt)
        {
            Debug.LogError(
                "[TableUtil] Table load failed.\n" +
                $"Table: {tableName}\n" +
                $"Source: {loadSource}\n" +
                $"Path: {fullPath}\n" +
                $"UseEncrypt: {useEncrypt}\n" +
                $"DataLength: {(tableData != null ? tableData.Length : 0)}\n" +
                $"Preview: {GetPreview(tableData)}\n" +
                $"Exception: {exception.GetType().Name}\n" +
                $"Message: {exception.Message}"
            );

            Debug.LogException(exception);
        }

        private static string GetPreview(string text, int maxLength = 120)
        {
            if (string.IsNullOrEmpty(text))
                return string.Empty;

            string preview = text.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");

            if (preview.Length > maxLength)
                preview = preview.Substring(0, maxLength) + "...";

            return preview;
        }

        public static void ExportList<T>(List<T> list, string fileName)
        {
            if (list == null || list.Count == 0)
            {
                Debug.LogWarning("Export 대상 데이터가 없습니다.");
                return;
            }

            var exportOrder = new List<string> { "se_id", "id" };
            var type = typeof(T);
            var allFields = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

            var fields = new List<FieldInfo>();
            foreach (var name in exportOrder)
            {
                var field = allFields.FirstOrDefault(f => f.Name == name);
                if (field != null)
                    fields.Add(field);
            }
            fields.AddRange(allFields.Where(f => !exportOrder.Contains(f.Name))); // 기타 남은 필드는 뒤에

            var sb = new StringBuilder();

            // 1. 헤더 자동 추출
            for (int i = 0; i < fields.Count; i++)
            {
                sb.Append(fields[i].Name);
                if (i < fields.Count - 1) sb.Append('\t');
            }
            sb.AppendLine();

            // 2. 데이터 줄 만들기
            foreach (var item in list)
            {
                for (int i = 0; i < fields.Count; i++)
                {
                    var field = fields[i];
                    var value = field.GetValue(item);
                    string text = "";

                    if (value == null)
                    {
                        text = "";
                    }
                    // 커스텀 보안 타입일 때: CScureVar<T>
                    else if (field.FieldType.IsGenericType && field.FieldType.GetGenericTypeDefinition().Name.Contains("CScureVar"))
                    {
                        // Get() 메서드 리플렉션 호출
                        var getMethod = field.FieldType.GetMethod("Get");
                        var realValue = getMethod.Invoke(value, null);
                        text = realValue?.ToString() ?? "";
                    }
                    else
                    {
                        text = value.ToString();
                    }

                    sb.Append(text);
                    if (i < fields.Count - 1) sb.Append('\t');
                }
                sb.AppendLine();
            }

            // 3. 저장
            string path = Path.Combine(Application.persistentDataPath, "Table", fileName + "_temp.tsv");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);

            Debug.Log($"TSV Export 완료: {path}");
        }

        // Dictionary<int, T> 버전
        public static void ExportDict<T>(Dictionary<int, T> dict, string fileName)
        {
            ExportList(new List<T>(dict.Values), fileName);
        }

        public static void WriteString(string contents, string fileName = "logText", bool overwrite = true)
        {
            string path = Application.temporaryCachePath + $"/{fileName}.txt";

            //Write some text to the test.txt file
            StreamWriter writer = new StreamWriter(path, false);

            writer.WriteLine(contents);
            writer.Close();
            StreamReader reader = new StreamReader(path);
            //Print the text from the file
            //Debug.Log(reader.ReadToEnd());
            Debug.Log($"File Path  = {path}");
            reader.Close();
        }
    }
}
