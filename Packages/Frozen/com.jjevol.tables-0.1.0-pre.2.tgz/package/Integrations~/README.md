# Uncompiled source references

Unity excludes this folder. These are not working adapters and are not counted as migrated functionality.

- Server/ServerTableSource.cs retains the original class and meta. It requires FirebaseClientTableUpdater, ClientTableStorage, JObject/GetString helper, Application.version and TableUtil; Player checks valid remote cache, while Editor falls back to Resources. ServerTableSource.CurrentRevision is not available in Core.
- Localization/OriginalTableData.cs.txt preserves the original TableData source, including GetLocEntry(string,string) returning UnityEngine.Localization.Tables.TableEntry. Core keeps text APIs through ITableLocalization but cannot offer that typed API without a Localization assembly dependency. Do not compile both TableData definitions together.

Further work must verify actual SDK/package/assembly references and provider lifetime before implementing adapters. Do not copy all Common, SDK code, encryption keys, company assets or backend settings to bypass these boundaries.
