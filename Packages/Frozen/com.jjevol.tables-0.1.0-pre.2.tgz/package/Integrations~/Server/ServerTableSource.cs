using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace jjevol
{
    public sealed class ServerTableSource : ITableSource
    {
        public bool RequiresRemoteUpdate => true;
        public static string CurrentRevision
        {
            get
            {
                if (FirebaseClientTableUpdater.IsRemoteTableReady && File.Exists(ClientTableStorage.LocalManifestPath))
                {
                    JObject manifest = JObject.Parse(ClientTableStorage.ReadLocalManifestText());
                    return $"{Application.version}|{manifest.GetString("dataVersion")}|{manifest.GetString("tableRevisionId")}";
                }
                return "builtin|" + Application.version;
            }
        }
        public bool HasTable(string tableName)
        {
#if !UNITY_EDITOR
            if (FirebaseClientTableUpdater.HasValidCachedTable(tableName)) return true;
#endif
            return Resources.Load<TextAsset>(tableName) != null;
        }

        public List<TSVRow> Load(string tableName)
        {
#if !UNITY_EDITOR
            if (FirebaseClientTableUpdater.HasValidCachedTable(tableName))
            {
                try { return TableUtil.LoadStaticTable(tableName, true); }
                catch (Exception e) { Debug.LogWarning($"[Table] Remote cache load failed. Fallback to Resources. Table:{tableName}, Error:{e.Message}"); }
            }
#endif
            return TableUtil.LoadLocalTable(tableName, true);
        }

        public async Task<List<TSVRow>> LoadAsync(string tableName)
        {
#if !UNITY_EDITOR
            if (FirebaseClientTableUpdater.HasValidCachedTable(tableName))
            {
                try { return await TableUtil.LoadStaticTableAsync(tableName, true); }
                catch (Exception e) { Debug.LogWarning($"[Table] Remote cache async load failed. Fallback to Resources. Table:{tableName}, Error:{e.Message}"); }
            }
#endif
            return await TableUtil.LoadLocalTableAsync(tableName, true);
        }
    }
}
