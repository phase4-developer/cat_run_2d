# Changelog

## 0.1.0-pre.1 - 2026-11-08

New design, per `Docs/PlatformPush/Design.md`. It replaces the mobile library's `FirebaseMessagingProvider`, `PushNotificationBuildSettings` and `PushNotificationAndroidBuildProcessor`. Class names and GUIDs are not kept.

- `FirebasePushProvider` implements `IPushProvider` with callbacks instead of `Task`.
- `RegistrationEnabled` and `ApplicationId` became `SetAutoRegistration` and `ScopeId`.
- Messages carry `MessageId`, `Data` and `Opened`. Messages with only data are no longer dropped.
- Firebase errors become `PushFailure`. Topic names are checked before the SDK call.
- The Android icon build step keeps its behavior, now in the `PlatformLibrary.Push.Firebase.Editor` assembly.

Unity EditMode tests passed on 2026-11-08, and `Hosts/PushSdkValidationHost` compiled the iOS device code against the real SDK. Android device code, Player and device tests are NOT_RUN. See `Docs/PlatformPush/Report.md`.
