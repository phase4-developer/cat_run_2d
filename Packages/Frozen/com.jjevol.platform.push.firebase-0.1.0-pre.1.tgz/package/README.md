# JJEvol Platform Push Firebase

Local validation candidate 0.1.0-pre.1. Firebase Cloud Messaging provider for `com.jjevol.platform.push`, and the Android notification icon build step.

The code is user-authored, confirmed by the user on 2026-11-08. No Firebase SDK, `google-services.json`, `GoogleService-Info.plist`, topic name or icon is included.

## Install

The Firebase Unity SDK is required and is not a package dependency. Install Firebase Messaging in the consumer project; the provider was compiled against 13.17.0. The assembly builds for the Editor, Android, iOS and macOS.

The Editor never calls the SDK. It logs, allows every request and hands out the fixed token `editor-push-token`, so this package compiles and the game's push flow runs in the Editor without Firebase. A Player build for those platforms needs the SDK. A Windows Player build leaves this assembly out, so guard the project's start code:

```csharp
#if UNITY_ANDROID || UNITY_IOS
PushManager.SetProvider(new FirebasePushProvider());
#endif
PushManager.Initialize();
```

Register the provider after the project has finished initializing Firebase. This package does not initialize Firebase.

## Behavior

`SetEnabled(false)` turns Firebase's registration on start off, so the SDK does not fetch a token by itself.

Topic names are checked against Firebase's rule before the SDK is called. A bad name answers `InvalidTopic` without a request.

| `PushFailure` | Firebase |
|---|---|
| `InvalidTopic` | Error 2, or a name that breaks the topic rule |
| `TokenUnavailable` | Error 3. The manager also treats an empty token this way. |
| `Unsupported` | `NotSupportedException`, `PlatformNotSupportedException` |
| `Timeout` | `TimeoutException`, or a message with `TIMEOUT` |
| `NoConnection` | I/O, or a network message such as `SERVICE_NOT_AVAILABLE` |
| `ProviderError` | Others |

The Firebase error code stays in `ProviderCode`. `ScopeId` is the Firebase App ID, so saved topics are kept per app.

## Android notification icon

Create one `FirebasePushBuildSettings` asset with **Create > Platform Library > Firebase Push Build Settings** and set the small icon PNG. On an Android build the icon is copied to `res/drawable` under the resource name and Firebase's default notification icon entry is added to the manifest.

The asset and the PNG belong to the project. With no asset the step logs a warning and skips. With more than one asset the build stops. A bad resource name or a non-PNG icon logs a warning, and fails the build only when `FailBuildWhenInvalid` is on.

## Validation

Tests are in `Tests/Editor`. They use a fake client and need no SDK. Run them from `Hosts/PlatformPushValidationHost`. `Hosts/PushSdkValidationHost` compiles the iOS device code against the real SDK inside Unity; Android was compiled only outside Unity. See `Docs/PlatformPush/Report.md` for what has run. Real pushes on a device are NOT_RUN.
