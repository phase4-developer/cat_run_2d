using UnityEngine;

namespace PlatformLibrary.Push.Firebase.Editor
{
    /// <summary>
    /// The project's Android notification icon for Firebase pushes. Keep one asset in the project.
    /// The icon PNG and this asset belong to the project, not to the package.
    /// </summary>
    [CreateAssetMenu(fileName = "FirebasePushBuildSettings", menuName = "Platform Library/Firebase Push Build Settings")]
    public sealed class FirebasePushBuildSettings : ScriptableObject
    {
        [Header("Android")]
        [SerializeField] private bool androidEnabled = true;
        [SerializeField] private Texture2D androidSmallIcon;
        [SerializeField] private string androidResourceName = "ic_stat_notification";
        [SerializeField] private bool failBuildWhenInvalid;

        public bool AndroidEnabled => androidEnabled;
        public Texture2D AndroidSmallIcon => androidSmallIcon;
        public string AndroidResourceName => androidResourceName;
        public bool FailBuildWhenInvalid => failBuildWhenInvalid;
    }
}
