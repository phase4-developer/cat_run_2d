//수정
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using DG.Tweening;

public class UITransition : MonoBehaviour, jjevol.IUITransition
{
    UnityEvent jjevol.IUITransition.ShowCompleted => onShowComplete;
    UnityEvent jjevol.IUITransition.HideCompleted => onHideComplete;
    bool jjevol.IUITransition.IsTransitioning => tweenState != TweenState.Stop;
    public enum TweenState
    {
        Stop,
        Add,
        Remove
    }

    public TweenState tweenState { get; private set; } = TweenState.Stop;

    public bool IsTransitioning => seq != null;

    [SerializeField] private float fadeDuration = 0.25f;
    [SerializeField] private CanvasGroup canvasGroup;
    [SerializeField] private RectTransform contentTransform;

    public CanvasGroup TargetCanvasGroup
    {
        get
        {
            if (canvasGroup == null)
                canvasGroup = GetComponent<CanvasGroup>();

            return canvasGroup;
        }
    }

    [Header("이펙트 설정")]
    public bool useFade = true;
    public bool useScale = true;
    public bool useMove = false;

    [Header("Animator 설정")]
    [SerializeField] private bool useAnimator = false;
    [SerializeField] private Animator animator;
    [SerializeField] private string animatorTriggerName = "Play";
    [SerializeField] private string animatorStateName = "Play";
    [SerializeField] private bool waitAnimatorStateLength = true;
    [SerializeField] private bool syncAnimatorUpdateMode = true;

    [Header("DOTweenAnimation 설정")]
    [SerializeField] private bool useDOTweenAnimations = false;
    [SerializeField] private List<DOTweenAnimation> dotweenAnimations = new List<DOTweenAnimation>();
    [SerializeField] private bool playDOTweenAnimationsOnShow = true;
    [SerializeField] private bool playDOTweenAnimationsOnHide = false;
    [SerializeField] private bool recreateDOTweenAnimationsOnShow = true;
    [SerializeField] private bool syncDOTweenAnimationUpdateMode = true;
    [SerializeField] private bool waitDOTweenAnimationLength = true;

    [Header("Ease 설정")]
    [SerializeField] private Ease fadeEase = Ease.OutQuad;
    [SerializeField] private Ease scaleEase = Ease.OutBack;
    [SerializeField] private Ease moveEase = Ease.OutCubic;

    [Header("시간 설정")]
    [SerializeField] private bool ignoreTimeScale = true;

    public Vector3 startScale = new Vector3(0.8f, 0.8f, 1);
    public Vector3 startPosition = new Vector3(0, -100f, 0);

    public Vector3 targetScale = new Vector3(1, 1, 1);
    public Vector3 targetPosition = new Vector3(0, 0, 0);

    [Header("이벤트")]
    public UnityEvent onShowStart;
    public UnityEvent onShowComplete;
    public UnityEvent onHideStart;
    public UnityEvent onHideComplete;

    private Sequence seq;
    //추가
    private int _runVersion;
    private bool _stopping;
    private void OnDisable() => ForceStopTransition();
    private void OnDestroy() => ForceStopTransition();
    //추가 종료

    /// <summary>
    /// 컴포넌트 기본 참조를 초기화한다.
    /// </summary>
    private void Awake()
    {
        if (canvasGroup == null)
            canvasGroup = GetComponent<CanvasGroup>();

        if (contentTransform == null)
            contentTransform = GetComponent<RectTransform>();

        if (animator == null)
            animator = GetComponent<Animator>();

        ApplyAnimatorUpdateMode();
    }

#if UNITY_EDITOR
    /// <summary>
    /// 인스펙터 값 변경 시 참조와 updateMode를 보정한다.
    /// </summary>
    private void OnValidate()
    {
        if (canvasGroup == null)
            canvasGroup = GetComponent<CanvasGroup>();

        if (contentTransform == null)
            contentTransform = GetComponent<RectTransform>();

        if (animator == null)
            animator = GetComponent<Animator>();

        ApplyAnimatorUpdateMode();
    }
#endif

    /// <summary>
    /// 진행 중인 트랜지션을 취소한다.
    /// </summary>
    public void CancelTween(bool invokeCompleteEvents = false)
    {
        //수정
        var previous = seq;
        if (previous == null) { ++_runVersion; tweenState = TweenState.Stop; return; }
        if (!invokeCompleteEvents)
        {
            ++_runVersion;
            seq = null;
            tweenState = TweenState.Stop;
            previous.Kill(false);
            return;
        }
        // Kill(true) may invoke a completion listener that starts the next transition.
        previous.Kill(true);
        if (ReferenceEquals(seq, previous)) { ++_runVersion; seq = null; tweenState = TweenState.Stop; }
        //수정 종료
    }

    /// <summary>
    /// 진행 중인 Transition과 DOTweenAnimation을 완료 이벤트 없이 즉시 중단한다.
    /// 화면 전환, 씬 이동, 즉시 파괴처럼 강제 정리가 필요한 상황에서 사용한다.
    /// </summary>
    public void ForceStopTransition()
    {
        //수정
        if (_stopping) return;
        _stopping = true;
        try { CancelTween(false); StopDOTweenAnimations(); }
        finally { _stopping = false; }
        //수정 종료
    }

    /// <summary>
    /// 트랜지션 완료 상태로 변경한다.
    /// </summary>
    private void _CompleteTween()
    {
        seq = null;
        tweenState = TweenState.Stop;
    }

    /// <summary>
    /// 창이 추가될 때 Show 트랜지션을 실행한다.
    /// Animator는 Play Trigger/State 기준으로 처리한다.
    /// DOTweenAnimation 리스트는 동시에 실행되고, 가장 긴 애니메이션 시간에 맞춰 완료 처리된다.
    /// </summary>
    public void OnWindowAdded()
    {
        //수정
        if (_stopping || !isActiveAndEnabled || tweenState == TweenState.Add) return;
        int expected = _runVersion + 1;
        CancelTween();
        if (_runVersion != expected || seq != null) return;
        int version = _runVersion;
        tweenState = TweenState.Add;
        onShowStart?.Invoke();
        if (version != _runVersion || !isActiveAndEnabled) return;
        //수정 종료

        seq = DOTween.Sequence().SetUpdate(UpdateType.Normal, ignoreTimeScale);

        bool hasTween = false;

        if (canvasGroup != null)
            canvasGroup.interactable = true;

        if (PlayAnimator())
            hasTween |= JoinAnimatorStateWait(seq);

        hasTween |= PlayDOTweenAnimations(seq, true);

        if (useFade && canvasGroup != null)
        {
            canvasGroup.alpha = 0;
            JoinTween(seq, canvasGroup.DOFade(1f, fadeDuration).SetEase(fadeEase), ref hasTween);
        }

        if (useScale && contentTransform != null)
        {
            contentTransform.localScale = startScale;
            JoinTween(seq, contentTransform.DOScale(targetScale, fadeDuration).SetEase(scaleEase), ref hasTween);
        }

        if (useMove && contentTransform != null)
        {
            contentTransform.anchoredPosition = startPosition;
            JoinTween(seq, contentTransform.DOAnchorPos(targetPosition, fadeDuration).SetEase(moveEase), ref hasTween);
        }

        if (!hasTween)
            seq.AppendInterval(0f);

        //수정
        var current = seq;
        seq.OnComplete(() =>
        {
            if (version != _runVersion || !ReferenceEquals(seq, current)) return;
            ++_runVersion;
            _CompleteTween();
            onShowComplete?.Invoke();
        });
        seq.OnKill(() =>
        {
            if (version != _runVersion || !ReferenceEquals(seq, current)) return;
            ++_runVersion;
            _CompleteTween();
        });
        //수정 종료
    }

    /// <summary>
    /// 창이 제거될 때 Hide 트랜지션을 실행한다.
    /// DOTweenAnimation Hide 사용 시 리스트 애니메이션을 역재생한다.
    /// </summary>
    public void OnWindowRemove()
    {
        //수정
        if (_stopping || !isActiveAndEnabled || tweenState == TweenState.Remove) return;
        int expected = _runVersion + 1;
        CancelTween();
        if (_runVersion != expected || seq != null) return;
        int version = _runVersion;
        tweenState = TweenState.Remove;
        onHideStart?.Invoke();
        if (version != _runVersion || !isActiveAndEnabled) return;
        //수정 종료

        seq = DOTween.Sequence().SetUpdate(UpdateType.Normal, ignoreTimeScale);

        bool hasTween = false;

        if (canvasGroup != null)
            canvasGroup.interactable = false;

        hasTween |= PlayDOTweenAnimations(seq, false);

        if (useFade && canvasGroup != null)
        {
            JoinTween(seq, canvasGroup.DOFade(0f, fadeDuration).SetEase(fadeEase), ref hasTween);
        }

        if (useScale && contentTransform != null)
        {
            JoinTween(seq, contentTransform.DOScale(startScale, fadeDuration).SetEase(scaleEase), ref hasTween);
        }

        if (useMove && contentTransform != null)
        {
            JoinTween(seq, contentTransform.DOAnchorPos(startPosition, fadeDuration).SetEase(moveEase), ref hasTween);
        }

        if (!hasTween)
            seq.AppendInterval(0f);

        //수정
        var current = seq;
        seq.OnComplete(() =>
        {
            if (version != _runVersion || !ReferenceEquals(seq, current)) return;
            ++_runVersion;
            _CompleteTween();
            onHideComplete?.Invoke();
        });
        seq.OnKill(() =>
        {
            if (version != _runVersion || !ReferenceEquals(seq, current)) return;
            ++_runVersion;
            _CompleteTween();
        });
        //수정 종료
    }

    /// <summary>
    /// Sequence에 Tween을 Join하고, 실제 Tween이 추가되었는지 기록한다.
    /// </summary>
    private void JoinTween(Sequence sequence, Tween tween, ref bool hasTween)
    {
        if (sequence == null)
            return;

        if (tween == null)
            return;

        sequence.Join(tween);
        hasTween = true;
    }

    /// <summary>
    /// Animator Trigger를 실행한다.
    /// 기본 Trigger 이름은 Play다.
    /// </summary>
    private bool PlayAnimator()
    {
        if (!useAnimator)
            return false;

        if (animator == null)
            return false;

        if (string.IsNullOrEmpty(animatorTriggerName))
            return false;

        animator.ResetTrigger(animatorTriggerName);
        animator.SetTrigger(animatorTriggerName);

        return true;
    }

    /// <summary>
    /// Animator의 Play State 길이만큼 Sequence에 대기 시간을 추가한다.
    /// </summary>
    private bool JoinAnimatorStateWait(Sequence sequence)
    {
        if (!waitAnimatorStateLength)
            return false;

        if (sequence == null)
            return false;

        float duration = GetAnimatorPlayDuration();

        if (duration <= 0f)
            return false;

        sequence.Join(CreateWaitTween(duration));
        return true;
    }

    /// <summary>
    /// Animator 런타임 상태 또는 AnimationClip에서 Play 길이를 가져온다.
    /// </summary>
    private float GetAnimatorPlayDuration()
    {
        if (animator == null)
            return 0f;

        if (animator.runtimeAnimatorController == null)
            return 0f;

        if (string.IsNullOrEmpty(animatorStateName))
            return 0f;

        animator.Update(0f);

        const int layerIndex = 0;

        if (animator.IsInTransition(layerIndex))
        {
            AnimatorStateInfo nextState = animator.GetNextAnimatorStateInfo(layerIndex);

            if (IsTargetAnimatorState(nextState))
                return nextState.length;
        }

        AnimatorStateInfo currentState = animator.GetCurrentAnimatorStateInfo(layerIndex);

        if (IsTargetAnimatorState(currentState))
            return currentState.length;

        return GetAnimationClipLength(animatorStateName);
    }

    /// <summary>
    /// AnimatorStateInfo가 지정한 State 이름과 일치하는지 확인한다.
    /// </summary>
    private bool IsTargetAnimatorState(AnimatorStateInfo stateInfo)
    {
        if (string.IsNullOrEmpty(animatorStateName))
            return false;

        int stateNameHash = Animator.StringToHash(animatorStateName);

        if (stateInfo.shortNameHash == stateNameHash)
            return true;

        return stateInfo.IsName(animatorStateName);
    }

    /// <summary>
    /// RuntimeAnimatorController에 등록된 Clip 이름 기준으로 길이를 찾는다.
    /// StateInfo에서 길이를 얻지 못했을 때 fallback으로 사용한다.
    /// </summary>
    private float GetAnimationClipLength(string clipName)
    {
        if (animator == null)
            return 0f;

        RuntimeAnimatorController controller = animator.runtimeAnimatorController;

        if (controller == null)
            return 0f;

        AnimationClip[] clips = controller.animationClips;

        if (clips == null)
            return 0f;

        foreach (AnimationClip clip in clips)
        {
            if (clip == null)
                continue;

            if (clip.name == clipName)
                return clip.length;
        }

#if UNITY_EDITOR || DEBUG_BUILD
        Debug.LogWarning($"[UITransition] Animator State/Clip not found. State:{clipName}, Object:{name}");
#endif

        return 0f;
    }

    /// <summary>
    /// DOTweenAnimation 리스트를 실행하고 가장 긴 시간만큼 Sequence에 대기 시간을 추가한다.
    /// Show에서는 DOPlayForward, Hide에서는 DOPlayBackwards를 사용한다.
    /// </summary>
    private bool PlayDOTweenAnimations(Sequence sequence, bool isShow)
    {
        if (!useDOTweenAnimations)
            return false;

        if (dotweenAnimations == null || dotweenAnimations.Count <= 0)
            return false;

        if (isShow && !playDOTweenAnimationsOnShow)
            return false;

        if (!isShow && !playDOTweenAnimationsOnHide)
            return false;

        float maxDuration = 0f;
        bool played = false;

        foreach (DOTweenAnimation animation in dotweenAnimations)
        {
            if (animation == null)
                continue;

            if (!animation.isActive)
                continue;

            //수정
            if (syncDOTweenAnimationUpdateMode)
            {
                animation.isIndependentUpdate = ignoreTimeScale;
                if (animation.tween != null && animation.tween.IsActive()) animation.tween.SetUpdate(ignoreTimeScale);
            }
            //수정 종료

            if (isShow)
            {
                if (recreateDOTweenAnimationsOnShow)
                    animation.CreateTween(true, false);

                animation.DOPlayForward();
            }
            else
            {
                animation.DOPlayBackwards();
            }

            maxDuration = Mathf.Max(maxDuration, GetDOTweenAnimationDuration(animation));
            played = true;
        }

        if (!played)
            return false;

        if (waitDOTweenAnimationLength && sequence != null && maxDuration > 0f)
            sequence.Join(CreateWaitTween(maxDuration));

        return waitDOTweenAnimationLength && maxDuration > 0f;
    }

    /// <summary>
    /// DOTweenAnimation의 총 재생 시간을 계산한다.
    /// 여러 애니메이션이 동시에 실행되므로 리스트 중 가장 긴 값을 사용한다.
    /// </summary>
    private float GetDOTweenAnimationDuration(DOTweenAnimation animation)
    {
        if (animation == null)
            return 0f;

        float duration = Mathf.Max(0f, animation.duration);
        float delay = Mathf.Max(0f, animation.delay);
        int loops = animation.loops;

        if (loops <= 0)
            loops = 1;

        return delay + duration * loops;
    }

    /// <summary>
    /// UITransition에서 실행한 DOTweenAnimation들을 즉시 중단한다.
    /// 강제 닫기/즉시 파괴 시 파괴된 오브젝트를 대상으로 Tween이 계속 돌지 않게 한다.
    /// </summary>
    private void StopDOTweenAnimations()
    {
        if (dotweenAnimations == null)
            return;

        foreach (DOTweenAnimation animation in dotweenAnimations)
        {
            if (animation == null)
                continue;

            animation.DOKill();
        }
    }

    /// <summary>
    /// Sequence 대기용 Tween을 생성한다.
    /// </summary>
    private Tween CreateWaitTween(float duration)
    {
        return DOTween.To(() => 0f, _ => { }, 1f, duration).SetEase(Ease.Linear);
    }

    /// <summary>
    /// ignoreTimeScale 설정에 맞춰 Animator updateMode를 보정한다.
    /// </summary>
    private void ApplyAnimatorUpdateMode()
    {
        if (!syncAnimatorUpdateMode)
            return;

        if (animator == null)
            return;

        animator.updateMode = ignoreTimeScale
            ? AnimatorUpdateMode.UnscaledTime
            : AnimatorUpdateMode.Normal;
    }
}
//수정 종료