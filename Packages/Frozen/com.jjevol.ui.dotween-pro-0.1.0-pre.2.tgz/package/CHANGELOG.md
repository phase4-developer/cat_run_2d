# Changelog

## 0.1.0-pre.2 - 2026-11-06

- Updated internal dependency versions. No source change.

Unity tests for this candidate are NOT_RUN.
