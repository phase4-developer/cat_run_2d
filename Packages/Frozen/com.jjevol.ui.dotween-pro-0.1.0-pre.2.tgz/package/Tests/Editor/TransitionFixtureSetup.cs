//추가
using System;
using System.Collections.Generic;
using System.IO;
using DG.Tweening;
using TMPro;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace jjevol.UI.DOTweenPro.Tests
{
    public sealed class TransitionFixtureSetup:IPrebuildSetup
    {
        public const string Root="Assets/Step16DOTweenFixtures";
        static void Guard(){string p=Path.GetFullPath(Path.Combine(Application.dataPath,".." )).Replace('\\','/');if(!p.EndsWith("/.local/dotween-validation/UIHost")&&!p.EndsWith("/.local/dotween-validation/IntegrationHost"))throw new InvalidOperationException("Only new STEP16 UI/Integration Host may be authored");}
        public static void ImportTMP()
        {
            Guard();if(Shader.Find("TextMeshPro/Mobile/Distance Field")){EditorApplication.Exit(0);return;}
            var package=UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TMP_Text).Assembly);AssetDatabase.ImportPackage(Path.Combine(package.resolvedPath,"Package Resources","TMP Essential Resources.unitypackage"),false);
            double end=EditorApplication.timeSinceStartup+120;EditorApplication.CallbackFunction done=null;done=()=>{if(Shader.Find("TextMeshPro/Mobile/Distance Field")&&!EditorApplication.isUpdating&&!EditorApplication.isCompiling){EditorApplication.update-=done;EditorApplication.Exit(0);}else if(EditorApplication.timeSinceStartup>end){EditorApplication.update-=done;EditorApplication.Exit(1);}};EditorApplication.update+=done;
        }
        public void Setup()
        {
            Guard();if(!Shader.Find("TextMeshPro/Mobile/Distance Field"))throw new InvalidOperationException("Import installed TMP essentials before running native fixtures");
            if(!AssetDatabase.IsValidFolder(Root))AssetDatabase.CreateFolder("Assets",Path.GetFileName(Root));
            var settings=AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(Root+"/Settings.asset")??AddressableAssetSettings.Create(Root,"Settings",true,true);AddressableAssetSettingsDefaultObject.Settings=settings;
            for(int i=0;i<settings.DataBuilders.Count;i++)if(settings.DataBuilders[i] is BuildScriptFastMode)settings.ActivePlayModeDataBuilderIndex=i;
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath,"GUID:"+AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
            if(File.Exists(Root+"/Popup.prefab"))return;
            void Register(string path,string key)=>settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path),settings.DefaultGroup).address=key;
            void Field(Object o,string n,Object v){var so=new SerializedObject(o);so.FindProperty(n).objectReferenceValue=v;so.ApplyModifiedPropertiesWithoutUndo();}
            GameObject Rect(string name,Transform parent=null){var go=new GameObject(name,typeof(RectTransform));go.layer=5;if(parent)go.transform.SetParent(parent,false);var r=(RectTransform)go.transform;r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.sizeDelta=Vector2.zero;return go;}
            var clip=new AnimationClip{name="Play"};clip.SetCurve("",typeof(Transform),"localPosition.y",AnimationCurve.Linear(0,0,.28f,.1f));AssetDatabase.CreateAsset(clip,Root+"/UI.anim");
            var controller=AnimatorController.CreateAnimatorControllerAtPath(Root+"/UI.controller");controller.AddParameter("Play",AnimatorControllerParameterType.Trigger);var machine=controller.layers[0].stateMachine;machine.AddState("Idle").motion=clip;var state=machine.AddState("Play");state.motion=clip;var jump=machine.AddAnyStateTransition(state);jump.hasExitTime=false;jump.duration=0;jump.AddCondition(AnimatorConditionMode.If,0,"Play");
            var popup=Rect("Popup");popup.SetActive(false);popup.AddComponent<CanvasGroup>();var transition=popup.AddComponent<UITransition>();popup.AddComponent<UIPopup>();
            transition.onShowStart=new UnityEngine.Events.UnityEvent();transition.onHideStart=new UnityEngine.Events.UnityEvent();transition.onShowComplete=new UnityEngine.Events.UnityEvent();transition.onHideComplete=new UnityEngine.Events.UnityEvent();transition.useMove=true;
            var text=Rect("actual TMP",popup.transform).AddComponent<TextMeshProUGUI>();text.text="STEP16 actual Tween popup";
            var target=Rect("Pro motion",popup.transform);target.SetActive(false);var animation=target.AddComponent<DOTweenAnimation>();animation.autoGenerate=false;animation.autoPlay=false;animation.autoKill=false;animation.isValid=true;animation.target=target.transform;animation.targetType=DOTweenAnimation.TargetType.RectTransform;animation.animationType=DOTweenAnimation.AnimationType.LocalMove;animation.duration=.18f;animation.endValueV3=new Vector3(2,0,0);target.SetActive(true);
            var animator=Rect("Animator",popup.transform).AddComponent<Animator>();animator.runtimeAnimatorController=controller;animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
            var ts=new SerializedObject(transition);ts.FindProperty("fadeDuration").floatValue=.1f;ts.FindProperty("useAnimator").boolValue=true;ts.FindProperty("animator").objectReferenceValue=animator;ts.FindProperty("useDOTweenAnimations").boolValue=true;ts.FindProperty("playDOTweenAnimationsOnHide").boolValue=true;var list=ts.FindProperty("dotweenAnimations");list.arraySize=1;list.GetArrayElementAtIndex(0).objectReferenceValue=animation;ts.ApplyModifiedPropertiesWithoutUndo();
            popup.SetActive(true);PrefabUtility.SaveAsPrefabAsset(popup,Root+"/Popup.prefab");Object.DestroyImmediate(popup);Register(Root+"/Popup.prefab","UIPopup_YesNoPopup");
            var screen=Rect("Intro");screen.AddComponent<UIScreen>().ScreenType="IntroScreen";PrefabUtility.SaveAsPrefabAsset(screen,Root+"/Screen.prefab");Object.DestroyImmediate(screen);Register(Root+"/Screen.prefab","UIScreen_IntroScreen");
            var manager=new GameObject("UIManager");manager.SetActive(false);var ui=manager.AddComponent<UIManager>();var cam=new GameObject("UI Camera",typeof(Camera));cam.transform.SetParent(manager.transform,false);cam.transform.localPosition=new Vector3(0,0,-10);var camera=cam.GetComponent<Camera>();camera.orthographic=true;camera.nearClipPlane=.1f;camera.farClipPlane=50;camera.cullingMask=1<<5;
            var canvas=Rect("UI Canvas",manager.transform).AddComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceCamera;canvas.worldCamera=camera;canvas.planeDistance=1;
            var screens=Rect("screens",canvas.transform);var popups=Rect("popups",canvas.transform);Rect("Backboard",popups.transform).AddComponent<Image>();var huds=Rect("huds",canvas.transform);huds.AddComponent<Canvas>();var effects=Rect("effects",canvas.transform);var loading=Rect("loading",canvas.transform);
            foreach(var pair in new[]{("uiCamera",(Object)camera),("screenRoot",screens.transform),("popupRoot",popups.transform),("hudRoot",huds.transform),("effectRoot",effects.transform),("loadingRoot",loading.transform)})Field(ui,pair.Item1,pair.Item2);
            manager.SetActive(true);PrefabUtility.SaveAsPrefabAsset(manager,Root+"/UIManager.prefab");Object.DestroyImmediate(manager);Register(Root+"/UIManager.prefab","UIManager");
            var active=SceneManager.GetActiveScene();if(string.IsNullOrEmpty(active.path))EditorSceneManager.SaveScene(active,Root+"/Authoring.unity");var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);var main=new GameObject("new Scene Base",typeof(Camera));main.tag="MainCamera";SceneManager.MoveGameObjectToScene(main,scene);EditorSceneManager.SaveScene(scene,Root+"/Scene.unity");EditorSceneManager.CloseScene(scene,true);Register(Root+"/Scene.unity","Step16/Scene");
            EditorUtility.SetDirty(settings);AssetDatabase.SaveAssets();AssetDatabase.Refresh();
        }
    }
}
//추가 종료
