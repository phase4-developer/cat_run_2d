//추가
using System;
using System.Linq;
using System.Reflection;
using DG.Tweening;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;
namespace jjevol.UI.DOTweenPro.Tests
{
    public sealed class TransitionCompatibilityTests
    {
        [Test]public void OriginalScriptGuidInterfaceAndSerializedFieldsArePreserved()
        {
            string path=AssetDatabase.GUIDToAssetPath("e82c7575b4495a346af214f86a481f99");StringAssert.EndsWith("com.jjevol.ui.dotween-pro/Runtime/UITransition.cs",path);Assert.That(AssetDatabase.LoadAssetAtPath<MonoScript>(path).GetClass(),Is.EqualTo(typeof(UITransition)));Assert.That(typeof(IUITransition).IsAssignableFrom(typeof(UITransition)),Is.True);
            var fields=typeof(UITransition).GetFields(BindingFlags.DeclaredOnly|BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).Where(f=>f.IsPublic||f.IsDefined(typeof(SerializeField),true)).ToArray();Assert.That(fields.Length,Is.EqualTo(31));Assert.That(fields.Single(f=>f.Name=="dotweenAnimations").FieldType,Is.EqualTo(typeof(System.Collections.Generic.List<DOTweenAnimation>)));
            foreach(string name in new[]{"OnWindowAdded","OnWindowRemove","ForceStopTransition","CancelTween"})Assert.That(typeof(UITransition).GetMethod(name),Is.Not.Null);
        }
        [Test]public void RealSdkAndAssemblyMatchTheLocalValidatedVersions()
        {
            Assert.That(DOTween.Version,Is.EqualTo("1.2.765"));Assert.That(typeof(DOTweenAnimation).BaseType.Assembly.GetType("DG.Tweening.DOTweenPro").GetField("Version",BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).GetValue(null),Is.EqualTo("1.0.381"));Assert.That(typeof(DOTweenAnimation).Assembly.GetName().Name,Is.EqualTo("DOTweenPro.Scripts"));Assert.That(typeof(UITransition).Assembly.GetName().Name,Is.EqualTo("JJEvol.UI.DOTweenPro.Runtime"));
        }
        [Test]public void NativePrefabReloadRetainsTransitionAndProComponentReferences()
        {
            string project=System.IO.Path.GetFullPath(Application.dataPath).Replace('\\','/');if(!project.Contains("/.local/dotween-validation/"))throw new InvalidOperationException("Isolated STEP16 Host only");
            const string path="Assets/Step16UISerialization.prefab";var go=new GameObject("serialized fixture",typeof(RectTransform),typeof(CanvasGroup));go.SetActive(false);
            try
            {
                var t=go.AddComponent<UITransition>();var a=go.AddComponent<DOTweenAnimation>();a.autoGenerate=false;t.useMove=true;t.startPosition=new Vector3(5,6,0);var so=new SerializedObject(t);var list=so.FindProperty("dotweenAnimations");list.arraySize=1;list.GetArrayElementAtIndex(0).objectReferenceValue=a;so.FindProperty("useDOTweenAnimations").boolValue=true;so.ApplyModifiedPropertiesWithoutUndo();PrefabUtility.SaveAsPrefabAsset(go,path);Object.DestroyImmediate(go);AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceUpdate);
                var restored=AssetDatabase.LoadAssetAtPath<GameObject>(path);var component=restored.GetComponent<UITransition>();Assert.That(component.useMove,Is.True);Assert.That(component.startPosition,Is.EqualTo(new Vector3(5,6,0)));Assert.That(new SerializedObject(component).FindProperty("dotweenAnimations").GetArrayElementAtIndex(0).objectReferenceValue,Is.SameAs(restored.GetComponent<DOTweenAnimation>()));Assert.That(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(MonoScript.FromMonoBehaviour(component))),Is.EqualTo("e82c7575b4495a346af214f86a481f99"));
            }
            finally{if(go)Object.DestroyImmediate(go);AssetDatabase.DeleteAsset(path);}
        }
    }
}
//추가 종료
