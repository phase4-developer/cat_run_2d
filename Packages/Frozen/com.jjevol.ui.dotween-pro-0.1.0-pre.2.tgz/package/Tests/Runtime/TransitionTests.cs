//추가
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using DG.Tweening;
using jjevol;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.TestTools;
using Object=UnityEngine.Object;

namespace jjevol.UI.DOTweenPro.Tests
{
    public sealed class TransitionTests
    {
        readonly List<GameObject> _objects=new();UITransition _transition;CanvasGroup _group;RectTransform _rect;
        static void Set(object o,string field,object value)=>o.GetType().GetField(field,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(o,value);
        static T Get<T>(object o,string field)=>(T)o.GetType().GetField(field,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(o);
        static IEnumerator Until(Func<bool> p){float end=Time.realtimeSinceStartup+6;while(!p()&&Time.realtimeSinceStartup<end)yield return null;Assert.That(p(),Is.True);}
        GameObject New(string name,params Type[] types){var go=new GameObject(name,types);_objects.Add(go);return go;}
        [UnitySetUp]public IEnumerator Setup()
        {
            Time.timeScale=1;DOTween.Init(false,true,LogBehaviour.ErrorsOnly);DOTween.KillAll(false);
            var go=New("independent transition",typeof(RectTransform),typeof(CanvasGroup));_rect=(RectTransform)go.transform;_group=go.GetComponent<CanvasGroup>();_transition=go.AddComponent<UITransition>();
            _transition.onShowStart=new UnityEvent();_transition.onHideStart=new UnityEvent();_transition.onShowComplete=new UnityEvent();_transition.onHideComplete=new UnityEvent();Set(_transition,"fadeDuration",.12f);yield return null;
        }
        [UnityTearDown]public IEnumerator Cleanup(){Time.timeScale=1;foreach(var go in _objects)if(go)Object.Destroy(go);_objects.Clear();yield return null;yield return null;int remaining=DOTween.TotalActiveTweens();DOTween.KillAll(false);Assert.That(remaining,Is.Zero,"Transition owns every native Tween it leaves running");}
        [UnityTest]public IEnumerator DisableStopsSequenceAndSuppressesLateCompletion()
        {
            int done=0;_transition.onShowComplete.AddListener(()=>done++);_transition.OnWindowAdded();yield return null;_transition.enabled=false;yield return new WaitForSecondsRealtime(.3f);
            Assert.That(done,Is.Zero);Assert.That(_transition.IsTransitioning,Is.False);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
        }
        [UnityTest]public IEnumerator CompletionDuringCancelCanStartANewTransitionWithoutLosingIt()
        {
            _transition.onShowComplete.AddListener(()=>_transition.OnWindowRemove());_transition.OnWindowAdded();yield return null;_transition.CancelTween(true);
            Assert.That(_transition.tweenState,Is.EqualTo(UITransition.TweenState.Remove));Assert.That(_transition.IsTransitioning,Is.True);_transition.ForceStopTransition();
        }
        [UnityTest]public IEnumerator CapturedOldNativeCompletionCannotFinishTheNewSequence()
        {
            int show=0,hide=0;_transition.onShowComplete.AddListener(()=>show++);_transition.onHideComplete.AddListener(()=>hide++);
            _transition.OnWindowAdded();var old=Get<Sequence>(_transition,"seq").onComplete;_transition.OnWindowRemove();old();
            Assert.That(show,Is.Zero);Assert.That(hide,Is.Zero);Assert.That(_transition.tweenState,Is.EqualTo(UITransition.TweenState.Remove));Assert.That(_transition.IsTransitioning,Is.True);
            yield return Until(()=>hide==1);Assert.That(_group.alpha,Is.EqualTo(0).Within(.01f));
        }
        [UnityTest]public IEnumerator StartEventReentryLeavesOnlyTheNewestTransition()
        {
            bool first=true;_transition.onShowStart.AddListener(()=>{if(first){first=false;_transition.OnWindowRemove();}});_transition.OnWindowAdded();
            Assert.That(_transition.tweenState,Is.EqualTo(UITransition.TweenState.Remove));_transition.ForceStopTransition();Assert.That(DOTween.TotalActiveTweens(),Is.Zero);
            yield break;
        }
        [UnityTest]public IEnumerator FadeScaleMoveAndShowHideEventsUseTheOriginalPublicContract()
        {
            _transition.useMove=true;int starts=0,shown=0,hidden=0;_transition.onShowStart.AddListener(()=>starts++);_transition.onShowComplete.AddListener(()=>shown++);_transition.onHideComplete.AddListener(()=>hidden++);
            ((IUITransition)_transition).OnWindowAdded();Assert.That(((IUITransition)_transition).IsTransitioning,Is.True);_transition.OnWindowAdded();
            yield return Until(()=>shown==1);Assert.That(starts,Is.EqualTo(1));Assert.That(_group.alpha,Is.EqualTo(1).Within(.01f));Assert.That(Vector3.Distance(_rect.localScale,_transition.targetScale),Is.LessThan(.01f));Assert.That(Vector2.Distance(_rect.anchoredPosition,_transition.targetPosition),Is.LessThan(.01f));
            _transition.OnWindowRemove();yield return Until(()=>hidden==1);Assert.That(_group.alpha,Is.EqualTo(0).Within(.01f));Assert.That(Vector3.Distance(_rect.localScale,_transition.startScale),Is.LessThan(.01f));
        }
        [UnityTest]public IEnumerator OriginalUnscaledDefaultRunsWhileScaledPolicyWaitsAtTimeScaleZero()
        {
            Time.timeScale=0;int done=0;_transition.onShowComplete.AddListener(()=>done++);_transition.OnWindowAdded();yield return Until(()=>done==1);
            Set(_transition,"ignoreTimeScale",false);_transition.OnWindowRemove();yield return new WaitForSecondsRealtime(.25f);Assert.That(_transition.IsTransitioning,Is.True);Time.timeScale=1;yield return Until(()=>!_transition.IsTransitioning);
        }
        [UnityTest]public IEnumerator ProAnimationReusedWithoutRecreateStillReceivesTheUnscaledPolicy()
        {
            var child=New("configured Pro child");child.SetActive(false);child.transform.SetParent(_rect,false);var animation=child.AddComponent<DOTweenAnimation>();animation.autoGenerate=false;animation.autoPlay=false;animation.autoKill=false;animation.isValid=true;animation.animationType=DOTweenAnimation.AnimationType.LocalMove;animation.targetType=DOTweenAnimation.TargetType.Transform;animation.target=child.transform;animation.duration=.16f;animation.endValueV3=new Vector3(2,0,0);child.SetActive(true);animation.CreateTween(true,false);
            Set(_transition,"useDOTweenAnimations",true);Set(_transition,"dotweenAnimations",new List<DOTweenAnimation>{animation});Set(_transition,"recreateDOTweenAnimationsOnShow",false);Time.timeScale=0;
            _transition.OnWindowAdded();yield return new WaitForSecondsRealtime(.3f);Assert.That(child.transform.localPosition.x,Is.EqualTo(2).Within(.03f));_transition.ForceStopTransition();
        }
        [UnityTest]public IEnumerator RealPopupForceCloseStopsTransitionBeforePoolReuse()
        {
            var popup=_transition.gameObject.AddComponent<UIPopup>();popup.Initialize(new PoolReturn());popup.ShowUI();yield return null;popup.ForceClosePopup();yield return null;
            Assert.That(popup.gameObject.activeSelf,Is.False);Assert.That(DOTween.TotalActiveTweens(),Is.Zero);popup.ShowUI();yield return Until(()=>!popup.IsTransitioning);Assert.That(_group.alpha,Is.EqualTo(1).Within(.01f));popup.ForceClosePopup();
        }
        sealed class PoolReturn:IUIReleaseHandle{public void Release(UIBase ui)=>ui.gameObject.SetActive(false);}
    }
}
//추가 종료
