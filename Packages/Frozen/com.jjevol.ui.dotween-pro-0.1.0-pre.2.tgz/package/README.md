# JJEvol UI DOTween Pro Adapter — local validation candidate

`com.jjevol.ui.dotween-pro@0.1.0-pre.2` activates the original global
`UITransition : MonoBehaviour, jjevol.IUITransition`. Unity 6000.3.9f1 was
validated with existing local DOTween 1.2.765 / DOTween Pro 1.0.381.

The original serialized `List<DOTweenAnimation>` and its Show/Hide options need
Pro even when the basic fade/scale/move options alone use free Core APIs.
This package therefore does not claim free-Core-only compatibility.

Supply a licensed SDK separately in the consumer project: DOTween.dll,
DOTweenPro.dll, DOTween.Modules and DOTweenPro.Scripts, with the original
SDK's enabled uGUI/TMP modules. No Vendor code or binaries are bundled.
Package dependency is UI Core; the adapter references the real SDK assemblies,
Unity.ugui and Unity.TextMeshPro. Installing only Core does not require DOTween.

Attach UITransition to the existing Popup and assign UIPopup.transition (or
allow its existing IUITransition discovery). Preserve the original CanvasGroup,
content RectTransform, Animator controller/Trigger/State and Pro list settings.
Use the original OnWindowAdded/OnWindowRemove/CancelTween/ForceStopTransition.
ShowCompleted/HideCompleted remain UnityEvents through IUITransition.

The original GUID e82c7575b4495a346af214f86a481f99 and 31 serialized fields
are preserved. Assembly identity is now JJEvol.UI.DOTweenPro.Runtime.
Actual product Prefab/assembly-qualified references still need migration QA;
do not install beside the original mobile class.

The adapter owns its Sequence and listed Pro animations. Disable/Destroy and
ForceStopTransition cancel without completion. CancelTween(true) still invokes
native completion and preserves a transition started by that callback. A run
generation/Sequence identity rejects retired callbacks and reentrant starts.
Start events now observe the reserved Add/Remove state. The existing unscaled
option also updates a live, non-recreated Pro Tween. Animator time policy and
its existing duration lookup are preserved.

**Known protected integration gap:** STEP15 UIManagerCreater uses ordinary
CloseAllPopups during scene initialization. Existing UIPopup refuses ordinary
ClosePopup while a transition is running. A persistent Popup can therefore
survive that automatic path. This package does not change the protected
Bootstrap or Navigation API. The consuming game's existing Scene policy must
call UIManager.Instance.popupManager.ForceCloseAllPopups() before switching
Scenes when those Popups must be retired. The unmodified automatic-path
failure remains in the isolated coexist harness and is reported as unresolved.

Pro reverse playback requires an available native Tween (for example the
consumer's original autoKill=false setting); the adapter does not silently
replace the SDK's autoKill/loop policy. Game-owned listeners on Pro components
retain their own subscription lifetime responsibilities.

Runtime/EditMode tests are under Tests. Full-combination harness source is in
Tests/Coexist~ and is copied only into the dedicated isolated IntegrationHost;
it needs both new adapters plus STEP14/15 and SDK providers. The archived
automatic Scene-policy reproduction intentionally still fails; use the
documented explicit-policy cases for supported integration validation.
See Docs/Guide/Installation.md and Docs/Guide/Verification.md in the
Framework checkout. No Player/device/visual-quality or fixed-release claim.
