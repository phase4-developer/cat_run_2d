using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UIElements;

namespace jjevol.Step23.Tests
{
    // LocalizedTextBinding on a runtime panel with the Step23 tables (en "EN fixture", ko "KO fixture").
    public sealed class UIToolkitLocalizationTests : LocalizationTestFixture
    {
        const string ProbePath = "Assets/Step23Fixture/UitkBindingProbe.uxml";
        PanelSettings _settings;
        GameObject _panel;

        VisualElement MakePanel()
        {
            _settings = ScriptableObject.CreateInstance<PanelSettings>();
            var go = new GameObject("UIToolkitLocalization");
            _panel = go;
            go.SetActive(false);
            var document = go.AddComponent<UIDocument>();
            document.panelSettings = _settings;
            go.SetActive(true);
            return document.rootVisualElement;
        }

        static IEnumerator Frames(int count = 3)
        {
            for (int i = 0; i < count; i++) yield return null;
        }

        // Runs before the base TearDown: the document goes before its PanelSettings.
        [UnityTearDown]
        public IEnumerator DestroyPanel()
        {
            if (_panel != null) Object.Destroy(_panel);
            yield return null;
            if (_settings != null) Object.Destroy(_settings);
            DeleteProbe();
        }

        static void DeleteProbe()
        {
#if UNITY_EDITOR
            if (System.IO.File.Exists(ProbePath)) UnityEditor.AssetDatabase.DeleteAsset(ProbePath);
#endif
        }

        [UnityTest]
        public IEnumerator LabelFollowsTheLocale()
        {
            var root = MakePanel();
            var label = new Label("authored");
            root.Add(label);
            label.Localize("step23", "hello");
            yield return Frames();
            Assert.AreEqual("EN fixture", label.text);

            yield return Await(Manager.SetLanguage("ko"));
            yield return Frames();
            Assert.AreEqual("KO fixture", label.text, "the label did not follow the Locale change");

            yield return Await(Manager.SetLanguage("en"));
            yield return Frames();
            Assert.AreEqual("EN fixture", label.text);
        }

        [UnityTest]
        public IEnumerator MissingEntryShowsTheKeyOrNothing()
        {
            var root = MakePanel();
            var shown = new Label("authored");
            var hidden = new Label("authored");
            root.Add(shown);
            root.Add(hidden);
            shown.Localize("step23", "missing");
            hidden.Localize("step23", "missing").showDebugKeyWhenMissing = false;
            yield return Frames();
            Assert.AreEqual("step23/missing", shown.text);
            Assert.AreEqual("", hidden.text);
        }

        [UnityTest]
        public IEnumerator BeforeInitializationKeepsTheTextThenResolves()
        {
            yield return Await(Manager.PrepareForContentUpdateAsync(default));
            Assert.IsFalse(Manager.IsInitialized);
            var root = MakePanel();
            var label = new Label("authored");
            root.Add(label);
            label.Localize("step23", "hello");
            yield return Frames();
            Assert.AreEqual("authored", label.text, "resolved before Localization was ready");
            yield return Await(Manager.ReloadLocalization());
            yield return Frames();
            Assert.AreEqual("EN fixture", label.text);
        }

        [UnityTest]
        public IEnumerator DetachedLabelIsUpdatedWhenItComesBack()
        {
            var root = MakePanel();
            var label = new Label("authored");
            root.Add(label);
            label.Localize("step23", "hello");
            yield return Frames();
            label.RemoveFromHierarchy();
            yield return Await(Manager.SetLanguage("ko"));
            yield return Frames();
            Assert.AreEqual("EN fixture", label.text, "a detached label is not updated");
            root.Add(label);
            yield return Frames();
            Assert.AreEqual("KO fixture", label.text, "the label was not refreshed when attached again");
        }

        [UnityTest]
        public IEnumerator UxmlBindingResolves()
        {
            var root = MakePanel();
            // The UXML form documented in the README, imported as a real asset. It is deleted in TearDown after the panel is
            // gone: deleting it now makes the Editor live-reload the UIDocument and rebuild its tree.
            const string uxml = "<ui:UXML xmlns:ui=\"UnityEngine.UIElements\">"
                + "<ui:Label name=\"title\" text=\"authored\"><Bindings><jjevol.LocalizedTextBinding property=\"text\" table=\"step23\" entry=\"hello\" /></Bindings></ui:Label>"
                + "<ui:Label name=\"quiet\" text=\"authored\"><Bindings><jjevol.LocalizedTextBinding property=\"text\" table=\"step23\" entry=\"missing\" show-debug-key-when-missing=\"false\" /></Bindings></ui:Label>"
                + "</ui:UXML>";
#if !UNITY_EDITOR
            Assert.Ignore("UXML text import needs the Editor.");
#endif
            if (!TryImportUxml(uxml, root)) Assert.Fail("the UXML did not import");
            yield return Frames();
            Assert.AreEqual("EN fixture", root.Q<Label>("title").text);
            Assert.AreEqual("", root.Q<Label>("quiet").text, "show-debug-key-when-missing was not read from the UXML");
        }

        static bool TryImportUxml(string uxml, VisualElement root)
        {
#if UNITY_EDITOR
            DeleteProbe();
            try
            {
                System.IO.File.WriteAllText(ProbePath, uxml);
                UnityEditor.AssetDatabase.ImportAsset(ProbePath, UnityEditor.ImportAssetOptions.ForceSynchronousImport);
                var asset = UnityEditor.AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(ProbePath);
                if (asset == null) return false;
                asset.CloneTree(root);
                return true;
            }
            catch
            {
                DeleteProbe();
                throw;
            }
#else
            return false;
#endif
        }
    }
}
