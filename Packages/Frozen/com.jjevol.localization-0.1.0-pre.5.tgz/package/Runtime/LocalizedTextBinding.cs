using Unity.Properties;
using UnityEngine.Localization.Settings;
using UnityEngine.UIElements;

namespace jjevol
{
    // UI Toolkit counterpart of LocalizeTmpTextEvent in ManualKey mode: writes the text of table/entry to the bound
    // property and writes it again when the Locale changes. In UXML:
    //   <ui:Label><Bindings><jjevol.LocalizedTextBinding property="text" table="ui" entry="Shop_Title" /></Bindings></ui:Label>
    // In code: label.Localize("ui", "Shop_Title").
    // A missing entry shows "table/entry" (like the TMP component) unless show-debug-key-when-missing="false".
    // Before Localization is initialized, and in edit mode, it leaves the element as it is.
    [UxmlObject]
    public partial class LocalizedTextBinding : CustomBinding
    {
        [UxmlAttribute] public string table { get; set; } = string.Empty;
        [UxmlAttribute] public string entry { get; set; } = string.Empty;
        [UxmlAttribute] public bool showDebugKeyWhenMissing { get; set; } = true;

        public LocalizedTextBinding() => updateTrigger = BindingUpdateTrigger.WhenDirty;

        public LocalizedTextBinding(string table, string entry) : this()
        {
            this.table = table;
            this.entry = entry;
        }

        protected override void OnActivated(in BindingActivationContext context)
        {
            LocalizationSettings.SelectedLocaleChanged += OnLocaleChanged;
            LocalizationEvent.Published += OnLocalizationEvent;
            MarkDirty();
        }

        protected override void OnDeactivated(in BindingActivationContext context)
        {
            LocalizationSettings.SelectedLocaleChanged -= OnLocaleChanged;
            LocalizationEvent.Published -= OnLocalizationEvent;
        }

        void OnLocaleChanged(UnityEngine.Localization.Locale locale) => MarkDirty();
        void OnLocalizationEvent(LocalizationEvent value) => MarkDirty();

        // True once Localization can answer without waiting. With a LocalizationManager only its initialization counts:
        // reading LocalizationSettings.InitializationOperation starts a new SDK initialization when the manager has let the
        // old one go (PrepareForContentUpdateAsync), which must not happen while it swaps the catalog.
        public static bool IsReady
        {
            get
            {
                if (!UnityEngine.Application.isPlaying || !LocalizationSettings.HasSettings) return false;
                bool initialized = LocalizationManager.HasInstance
                    ? LocalizationManager.Instance.IsInitialized
                    : LocalizationSettings.InitializationOperation.IsDone;
                return initialized && LocalizationSettings.SelectedLocale != null;
            }
        }

        // The text for the current Locale, or null while Localization is not ready.
        public string Resolve()
        {
            if (!IsReady) return null;
            string collection = table?.Trim();
            string key = entry?.Trim();
            string value = string.IsNullOrEmpty(collection) || string.IsNullOrEmpty(key) ? null : LocalizationManager.GetLoc(collection, key, false);
            if (!string.IsNullOrEmpty(value)) return value;
            if (!showDebugKeyWhenMissing) return string.Empty;
            return (string.IsNullOrEmpty(collection) ? "<LOCALIZE_EMPTY>" : collection) + "/" + (string.IsNullOrEmpty(key) ? "<KEY>" : key);
        }

        protected override BindingResult Update(in BindingContext context)
        {
            // Edit mode (UI Builder) keeps the text written in the UXML and does not poll.
            if (!UnityEngine.Application.isPlaying) return new BindingResult(BindingStatus.Success);
            string text = Resolve();
            if (text == null)
            {
                // Not ready: keep checking each update until it is, then go back to updating on change only.
                updateTrigger = BindingUpdateTrigger.EveryUpdate;
                return new BindingResult(BindingStatus.Pending);
            }
            updateTrigger = BindingUpdateTrigger.WhenDirty;
            var element = context.targetElement;
            if (ConverterGroups.TrySetValueGlobal(ref element, context.bindingId, text, out VisitReturnCode code))
                return new BindingResult(BindingStatus.Success);
            return new BindingResult(BindingStatus.Failure, "[LocalizedTextBinding] Cannot set '" + context.bindingId + "' on " + element.GetType().Name + ": " + code);
        }
    }

    public static class LocalizedTextBindingExtensions
    {
        // Binds `property` (text by default) of the element to table/entry. Replaces any binding on that property.
        public static LocalizedTextBinding Localize(this VisualElement element, string table, string entry, string property = "text")
        {
            var binding = new LocalizedTextBinding(table, entry);
            element.SetBinding(property, binding);
            return binding;
        }
    }
}
