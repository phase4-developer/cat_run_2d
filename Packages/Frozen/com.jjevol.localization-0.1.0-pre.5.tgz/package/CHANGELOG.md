# Changelog

## 0.1.0-pre.5 - 2026-11-12

- Declares `com.cysharp.unitask` 2.5.11 as a direct dependency. The runtime assembly already used `UniTask` and `UniTask.Addressables`; they were only installed through `com.jjevol.resources.addressables`. No code change.
- The test assemblies compile only when `com.jjevol.localization.tmp` is installed (`versionDefines` → `JJEVOL_LOCALIZATION_TMP`). A Host that lists this package in `testables` without `com.jjevol.localization.tmp` now drops these test assemblies instead of failing to compile. This replaces the pre.4 note below.

## 0.1.0-pre.4 - 2026-11-11

- `LocalizeTmpTextEvent` moved to the new package `com.jjevol.localization.tmp` with the same script GUID (`5beb6f6c477480148a6eef02f804712b`), class name and fields. This package no longer references TextMeshPro or depends on `com.unity.ugui`. A uGUI game installs `com.jjevol.localization.tmp` as well; existing Prefabs keep their component.
- `LocalizedTextBinding` (UI Toolkit): binds a property, `text` by default, to table/entry and writes it again when the Locale changes. In UXML `<Bindings><jjevol.LocalizedTextBinding property="text" table="ui" entry="Shop_Title" /></Bindings>`, in code `label.Localize("ui", "Shop_Title")`. Same text rules as the TMP component's ManualKey mode.
- Tests keep their place; the test assemblies reference `JJEvol.Localization.Tmp.Runtime`, so a Host that lists this package in `testables` must also install `com.jjevol.localization.tmp` (the same holds for `com.jjevol.localization.authoring` tests).

## 0.1.0-pre.3 - 2026-11-08

- Removed `LocalizeTmpStyleEvent`. Per-locale font and material swapping is replaced by a font fallback chain that the game configures. See the README font section.
- Any Prefab that still carries the component (script GUID `4253a8bfbcb95b34fb5eb9b8940e93ec`) shows a missing script. No Prefab or Scene in the mobile baseline, the Steam library or the consumer game projects checked uses it.
- Test fixtures no longer create per-locale TMP font and material assets. A Host with an existing `Assets/Step23Fixture` must regenerate it.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.2 - 2026-11-06

- `RefreshText` waits outside ResourceManager callbacks before first initialization.

Unity tests for this candidate are NOT_RUN.
