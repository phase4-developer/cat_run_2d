# Changelog

## 0.1.0-pre.2 - 2026-11-06

- Login reuses a registered Provider, disposes rejected instances and iterates safely in Update. Added `PlatformServiceResolver.TryGetAuth`.
- Documented the trust boundary of payment and ad callbacks.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.1

Initial extraction from mobile ac18cfbdea56f03447a7d5927395d6bc88ddfd9f. Validation results are recorded outside the package.
