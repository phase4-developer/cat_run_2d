using System;

namespace PlatformLibrary.LocalNotifications
{
    /// <summary>
    /// One notification to show later. Scheduling the same <see cref="Key"/> again replaces the earlier one.
    /// Text, time and data belong to the project.
    /// </summary>
    public sealed class LocalNotification
    {
        /// <param name="key">The project's name for this notification, for example "energy_full". No line breaks.</param>
        /// <param name="fireTimeUtc">When to show it. A local time is converted to UTC.</param>
        /// <param name="data">Returned when the player opens the app from this notification.</param>
        public LocalNotification(string key, string title, string body, DateTime fireTimeUtc, string data = null)
        {
            if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("A key is required.", nameof(key));
            if (key.IndexOf('\n') >= 0 || key.IndexOf('\r') >= 0) throw new ArgumentException("A key cannot contain line breaks.", nameof(key));

            Key = key;
            Title = title ?? string.Empty;
            Body = body ?? string.Empty;
            FireTimeUtc = fireTimeUtc.Kind == DateTimeKind.Local ? fireTimeUtc.ToUniversalTime() : DateTime.SpecifyKind(fireTimeUtc, DateTimeKind.Utc);
            Data = data ?? string.Empty;
        }

        public string Key { get; }
        public string Title { get; }
        public string Body { get; }
        public DateTime FireTimeUtc { get; }
        public string Data { get; }
    }
}
