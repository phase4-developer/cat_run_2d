using System;

namespace PlatformLibrary.LocalNotifications
{
    /// <summary>
    /// Connects one notification SDK to <see cref="LocalNotificationManager"/>. Games do not call this.
    /// <para>
    /// The manager calls every member on the Unity main thread, turns keys into fixed ids, checks the time, asks for
    /// permission before scheduling and handles the disabled state. A provider only talks to its SDK.
    /// </para>
    /// <para>Callbacks and <see cref="Opened"/> may be used from any thread. Each callback must be called once.</para>
    /// </summary>
    public interface ILocalNotificationProvider
    {
        /// <summary>The player opened the app from a notification this provider scheduled.</summary>
        event Action<LocalNotificationOpened> Opened;

        void Initialize(Action<LocalNotificationResult> completed);

        /// <summary>Answers <see cref="LocalNotificationFailure.PermissionDenied"/> when the player said no.</summary>
        void RequestPermission(Action<LocalNotificationResult> completed);

        /// <summary>Schedules under <paramref name="id"/>, replacing any notification with the same id.</summary>
        void Schedule(int id, LocalNotification notification, Action<LocalNotificationResult> completed);

        void Cancel(int id);

        void CancelAll();
    }
}
