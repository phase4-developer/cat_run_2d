using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.LocalNotifications.Tests.Editor")]
[assembly: InternalsVisibleTo("PlatformLibrary.LocalNotifications.Tests.Runtime")]
