using System;
using System.Collections.Concurrent;
using System.Threading;
using UnityEngine;

namespace PlatformLibrary.LocalNotifications
{
    [AddComponentMenu("")]
    internal sealed class UnityLocalNotificationHost : MonoBehaviour, ILocalNotificationHost
    {
        private static UnityLocalNotificationHost _instance;

        private readonly ConcurrentQueue<Action> _queue = new ConcurrentQueue<Action>();
        private int _mainThreadId;

        public static UnityLocalNotificationHost Instance
        {
            get
            {
                if (_instance != null) return _instance;
                var host = new GameObject(nameof(LocalNotificationManager));
                if (Application.isPlaying) DontDestroyOnLoad(host);
                _instance = host.AddComponent<UnityLocalNotificationHost>();
                return _instance;
            }
        }

        public DateTime UtcNow => DateTime.UtcNow;

        private void Awake()
        {
            _mainThreadId = Thread.CurrentThread.ManagedThreadId;
        }

        private void Update()
        {
            while (_queue.TryDequeue(out Action action))
                action();
        }

        public void Post(Action action)
        {
            if (Thread.CurrentThread.ManagedThreadId == _mainThreadId) action();
            else _queue.Enqueue(action);
        }

        public void LogWarning(string message) => Debug.LogWarning("[LocalNotificationManager] " + message);

        public void LogException(Exception exception) => Debug.LogException(exception);
    }
}
