namespace PlatformLibrary.LocalNotifications
{
    /// <summary>
    /// Turns a key into the positive number SDKs use as an id. The same key always gives the same id, on every device
    /// and every run, so nothing has to be saved to cancel or replace a notification later.
    /// </summary>
    internal static class LocalNotificationIds
    {
        public static int FromKey(string key)
        {
            // FNV-1a over UTF-16 code units, kept positive and non-zero.
            unchecked
            {
                uint hash = 2166136261;
                foreach (char c in key)
                {
                    hash ^= c;
                    hash *= 16777619;
                }

                int id = (int)(hash & 0x7FFFFFFF);
                return id == 0 ? 1 : id;
            }
        }
    }
}
