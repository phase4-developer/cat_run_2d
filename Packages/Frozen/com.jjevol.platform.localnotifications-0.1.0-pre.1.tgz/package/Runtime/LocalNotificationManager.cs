using System;
using UnityEngine;

namespace PlatformLibrary.LocalNotifications
{
    /// <summary>
    /// The only local notification API a game uses. Call it from the Unity main thread. Every callback and event runs
    /// on the main thread, and every callback runs once. With no provider set, scheduling answers
    /// <see cref="LocalNotificationFailure.Unsupported"/> and the game keeps running.
    /// <para>
    /// Scheduling needs <see cref="Initialize"/> and <see cref="SetEnabled"/> with true. Permission is asked before each
    /// schedule; the system shows its prompt only the first time.
    /// </para>
    /// </summary>
    public static class LocalNotificationManager
    {
        private static LocalNotificationSession _session;
        private static bool _initializedWithoutProvider;
        private static bool? _enabled;
        private static Action<LocalNotificationOpened> _notificationOpened;

        /// <summary>
        /// The player opened the app from a local notification. Not raised while notifications are off. One that arrives
        /// before the first listener or before <see cref="SetEnabled"/> waits and goes to the first listener, up to 16.
        /// </summary>
        public static event Action<LocalNotificationOpened> NotificationOpened
        {
            add
            {
                _notificationOpened += value;
                _session?.FlushPending();
            }
            remove => _notificationOpened -= value;
        }

        public static bool IsInitialized => _session != null ? _session.IsInitialized : _initializedWithoutProvider;

        /// <summary>True when a provider is set.</summary>
        public static bool IsSupported => _session != null;

        public static bool IsEnabled => _enabled == true;

        /// <summary>
        /// Sets the provider, or removes it with null. Call <see cref="Initialize"/> after it. The enabled state carries over.
        /// Calls the old provider has not answered end with <see cref="LocalNotificationFailure.ProviderError"/>.
        /// </summary>
        public static void SetProvider(ILocalNotificationProvider provider)
        {
            SetProvider(provider, provider == null ? null : UnityLocalNotificationHost.Instance);
        }

        public static void Initialize()
        {
            if (_session != null) _session.Initialize();
            else _initializedWithoutProvider = true;
        }

        /// <summary>Turns local notifications on or off, usually from the player's option. Off cancels every scheduled one.</summary>
        public static void SetEnabled(bool enabled)
        {
            _enabled = enabled;
            _session?.SetEnabled(enabled);
        }

        /// <summary>Asks for permission now, for a game that wants to choose the moment.</summary>
        public static void RequestPermission(Action<LocalNotificationResult> callback)
        {
            if (_session != null) _session.RequestPermission(callback);
            else callback?.Invoke(Unsupported());
        }

        /// <summary>Schedules a notification. The same key replaces the earlier one.</summary>
        public static void Schedule(LocalNotification notification, Action<LocalNotificationResult> callback = null)
        {
            if (notification == null) throw new ArgumentNullException(nameof(notification));
            if (_session != null) _session.Schedule(notification, callback);
            else callback?.Invoke(Unsupported());
        }

        /// <summary>Cancels the notification scheduled under this key, including one still waiting for permission.</summary>
        public static void Cancel(string key) => _session?.Cancel(key);

        public static void CancelAll() => _session?.CancelAll();

        internal static LocalNotificationSession Session => _session;

        internal static void SetProvider(ILocalNotificationProvider provider, ILocalNotificationHost host)
        {
            if (ReferenceEquals(_session?.Provider, provider)) return;

            LocalNotificationSession previous = _session;
            _session = provider == null ? null : new LocalNotificationSession(provider, host, RaiseOpened, HasOpenedListeners);
            _initializedWithoutProvider = false;
            if (_session != null && _enabled.HasValue) _session.SetEnabled(_enabled.Value);
            previous?.Close();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        internal static void ResetState()
        {
            _session?.Close();
            _session = null;
            _initializedWithoutProvider = false;
            _enabled = null;
            _notificationOpened = null;
        }

        private static LocalNotificationResult Unsupported()
        {
            return LocalNotificationResult.Failed(LocalNotificationFailure.Unsupported, 0, "NO_LOCAL_NOTIFICATION_PROVIDER");
        }

        private static bool HasOpenedListeners() => _notificationOpened != null;

        private static void RaiseOpened(LocalNotificationOpened opened) => _notificationOpened?.Invoke(opened);
    }
}
