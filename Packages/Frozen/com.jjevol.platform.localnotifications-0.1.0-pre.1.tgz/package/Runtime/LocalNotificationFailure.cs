namespace PlatformLibrary.LocalNotifications
{
    /// <summary>Why a local notification call failed. Games branch on this, never on an SDK code.
    /// Shared names and order follow <c>NetworkFailure</c> in com.jjevol.platform.network.</summary>
    public enum LocalNotificationFailure
    {
        None,
        Unsupported,
        NotInitialized,
        Disabled,
        PermissionDenied,
        InvalidTime,
        ProviderError
    }
}
