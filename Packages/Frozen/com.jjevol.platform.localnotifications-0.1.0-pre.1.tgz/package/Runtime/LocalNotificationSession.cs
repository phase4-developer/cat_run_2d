using System;
using System.Collections.Generic;

namespace PlatformLibrary.LocalNotifications
{
    /// <summary>
    /// One provider's local notification state. <see cref="LocalNotificationManager"/> creates one per provider and closes
    /// it when the provider changes. Every member runs on the main thread. Provider answers come back through
    /// <see cref="ILocalNotificationHost.Post"/>.
    /// </summary>
    internal sealed class LocalNotificationSession
    {
        internal const int MaxPendingOpened = 16;

        private readonly ILocalNotificationProvider _provider;
        private readonly ILocalNotificationHost _host;
        private readonly Action<LocalNotificationOpened> _opened;
        private readonly Func<bool> _hasOpenedListeners;

        private readonly List<Action<LocalNotificationResult>> _permissionWaiters = new List<Action<LocalNotificationResult>>();
        private readonly List<Action<LocalNotificationResult>> _unanswered = new List<Action<LocalNotificationResult>>();
        private readonly Dictionary<string, int> _keyVersions = new Dictionary<string, int>(StringComparer.Ordinal);
        private readonly Queue<LocalNotificationOpened> _pending = new Queue<LocalNotificationOpened>();

        private bool? _enabled;
        private bool _closed;
        private bool _initializing;
        private bool _askingPermission;
        private int _generation;

        public LocalNotificationSession(ILocalNotificationProvider provider, ILocalNotificationHost host,
            Action<LocalNotificationOpened> opened, Func<bool> hasOpenedListeners)
        {
            _provider = provider ?? throw new ArgumentNullException(nameof(provider));
            _host = host ?? throw new ArgumentNullException(nameof(host));
            _opened = opened;
            _hasOpenedListeners = hasOpenedListeners;
            _provider.Opened += OnOpened;
        }

        public ILocalNotificationProvider Provider => _provider;
        public bool IsInitialized { get; private set; }
        internal int PendingOpenedCount => _pending.Count;

        public void Initialize()
        {
            if (_closed || IsInitialized || _initializing) return;
            _initializing = true;

            Call(_provider.Initialize, result =>
            {
                _initializing = false;
                if (!result.Success)
                {
                    _host.LogWarning("Initialize failed. Call Initialize again to retry. " + result);
                    return;
                }

                IsInitialized = true;
                if (_enabled == false) CancelAllNow();
            });
        }

        public void SetEnabled(bool enabled)
        {
            if (_closed || _enabled == enabled) return;
            _enabled = enabled;

            if (enabled)
            {
                FlushPending();
                return;
            }

            _generation++;
            _pending.Clear();
            if (IsInitialized) CancelAllNow();
        }

        public void RequestPermission(Action<LocalNotificationResult> callback)
        {
            Action<LocalNotificationResult> answer = Once(callback);
            if (_closed || !IsInitialized)
            {
                answer(LocalNotificationResult.Failed(LocalNotificationFailure.NotInitialized, 0, "NOT_INITIALIZED"));
                return;
            }

            AskPermission(answer);
        }

        public void Schedule(LocalNotification notification, Action<LocalNotificationResult> callback)
        {
            if (notification == null) throw new ArgumentNullException(nameof(notification));
            Action<LocalNotificationResult> answer = Once(callback);

            if (_closed || !IsInitialized)
            {
                answer(LocalNotificationResult.Failed(LocalNotificationFailure.NotInitialized, 0, "NOT_INITIALIZED"));
                return;
            }

            if (_enabled != true)
            {
                answer(LocalNotificationResult.Failed(LocalNotificationFailure.Disabled, 0, "DISABLED"));
                return;
            }

            if (notification.FireTimeUtc <= _host.UtcNow)
            {
                answer(LocalNotificationResult.Failed(LocalNotificationFailure.InvalidTime, 0, "FIRE_TIME_PASSED"));
                return;
            }

            int generation = _generation;
            int keyVersion = KeyVersion(notification.Key);
            int id = LocalNotificationIds.FromKey(notification.Key);

            AskPermission(permission =>
            {
                if (TryAnswerStale(answer, generation, notification.Key, keyVersion)) return;
                if (!permission.Success)
                {
                    answer(permission);
                    return;
                }

                Call(done => _provider.Schedule(id, notification, done), result =>
                {
                    if (result.Success && IsStale(generation, notification.Key, keyVersion))
                    {
                        CancelNow(id);
                        TryAnswerStale(answer, generation, notification.Key, keyVersion);
                        return;
                    }

                    answer(result);
                });
            });
        }

        public void Cancel(string key)
        {
            if (_closed || string.IsNullOrEmpty(key)) return;
            _keyVersions[key] = KeyVersion(key) + 1;
            if (IsInitialized) CancelNow(LocalNotificationIds.FromKey(key));
        }

        public void CancelAll()
        {
            if (_closed) return;
            _generation++;
            if (IsInitialized) CancelAllNow();
        }

        public void FlushPending()
        {
            while (!_closed && _enabled == true && _pending.Count > 0 && HasListeners())
                Raise(_opened, _pending.Dequeue());
        }

        public void Close()
        {
            if (_closed) return;
            _closed = true;
            _pending.Clear();
            _permissionWaiters.Clear();
            _provider.Opened -= OnOpened;

            foreach (Action<LocalNotificationResult> answer in _unanswered.ToArray())
                answer(LocalNotificationResult.Failed(LocalNotificationFailure.ProviderError, 0, "PROVIDER_CHANGED"));
        }

        private void AskPermission(Action<LocalNotificationResult> waiter)
        {
            _permissionWaiters.Add(waiter);
            if (_askingPermission) return;
            _askingPermission = true;

            Call(_provider.RequestPermission, result =>
            {
                _askingPermission = false;
                Action<LocalNotificationResult>[] waiters = _permissionWaiters.ToArray();
                _permissionWaiters.Clear();
                foreach (Action<LocalNotificationResult> each in waiters)
                    each(result);
            });
        }

        private bool IsStale(int generation, string key, int keyVersion)
        {
            return _enabled != true || generation != _generation || keyVersion != KeyVersion(key);
        }

        private bool TryAnswerStale(Action<LocalNotificationResult> answer, int generation, string key, int keyVersion)
        {
            if (!IsStale(generation, key, keyVersion)) return false;
            answer(_enabled != true
                ? LocalNotificationResult.Failed(LocalNotificationFailure.Disabled, 0, "DISABLED")
                : LocalNotificationResult.Failed(LocalNotificationFailure.ProviderError, 0, "CANCELED_BEFORE_SCHEDULED"));
            return true;
        }

        private int KeyVersion(string key) => _keyVersions.TryGetValue(key, out int version) ? version : 0;

        private void OnOpened(LocalNotificationOpened opened)
        {
            _host.Post(() =>
            {
                if (_closed || opened == null || _enabled == false) return;

                if (_enabled == true && HasListeners())
                {
                    Raise(_opened, opened);
                    return;
                }

                if (_pending.Count == MaxPendingOpened) _pending.Dequeue();
                _pending.Enqueue(opened);
            });
        }

        private void CancelNow(int id)
        {
            try
            {
                _provider.Cancel(id);
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }

        private void CancelAllNow()
        {
            try
            {
                _provider.CancelAll();
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }

        private bool HasListeners()
        {
            try
            {
                return _hasOpenedListeners != null && _hasOpenedListeners();
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                return false;
            }
        }

        /// <summary>Wraps a game callback so it runs once, and so <see cref="Close"/> can answer it if the provider never does.</summary>
        private Action<LocalNotificationResult> Once(Action<LocalNotificationResult> callback)
        {
            bool answered = false;
            Action<LocalNotificationResult> wrapper = null;
            wrapper = result =>
            {
                if (answered) return;
                answered = true;
                _unanswered.Remove(wrapper);
                Raise(callback, result);
            };
            _unanswered.Add(wrapper);
            return wrapper;
        }

        /// <summary>Calls the provider once. The answer runs on the main thread, once, and never after <see cref="Close"/>.</summary>
        private void Call(Action<Action<LocalNotificationResult>> start, Action<LocalNotificationResult> done)
        {
            bool answered = false;
            void Answer(LocalNotificationResult result)
            {
                if (answered || _closed) return;
                answered = true;
                done(result);
            }

            try
            {
                start(result => _host.Post(() => Answer(result)));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                Answer(LocalNotificationResult.Failed(LocalNotificationFailure.ProviderError, 0, exception.GetType().Name + ": " + exception.Message));
            }
        }

        private void Raise<T>(Action<T> handler, T value)
        {
            if (handler == null) return;
            try
            {
                handler(value);
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }
    }
}
