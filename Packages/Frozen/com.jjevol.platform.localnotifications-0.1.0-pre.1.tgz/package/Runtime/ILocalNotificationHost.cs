using System;

namespace PlatformLibrary.LocalNotifications
{
    /// <summary>What <see cref="LocalNotificationSession"/> needs from Unity. Tests replace it to control time and threads.</summary>
    internal interface ILocalNotificationHost
    {
        DateTime UtcNow { get; }

        /// <summary>Runs on the main thread, immediately when already on it.</summary>
        void Post(Action action);

        void LogWarning(string message);
        void LogException(Exception exception);
    }
}
