using System;

namespace PlatformLibrary.LocalNotifications
{
    /// <summary>
    /// Result of a local notification call. Games branch on <see cref="Failure"/>. <see cref="ProviderCode"/> and
    /// <see cref="Detail"/> are the SDK's own values, kept for logs only.
    /// </summary>
    public readonly struct LocalNotificationResult
    {
        private readonly string _detail;

        private LocalNotificationResult(LocalNotificationFailure failure, int providerCode, string detail)
        {
            Failure = failure;
            ProviderCode = providerCode;
            _detail = detail;
        }

        public static LocalNotificationResult Succeeded => default;

        public static LocalNotificationResult Failed(LocalNotificationFailure failure, int providerCode = 0, string detail = null)
        {
            if (failure == LocalNotificationFailure.None) throw new ArgumentException("A failure needs a reason.", nameof(failure));
            return new LocalNotificationResult(failure, providerCode, detail);
        }

        public LocalNotificationFailure Failure { get; }
        public bool Success => Failure == LocalNotificationFailure.None;

        /// <summary>The SDK's code. Logs and investigation only.</summary>
        public int ProviderCode { get; }

        /// <summary>A description for logs. Never null.</summary>
        public string Detail => _detail ?? string.Empty;

        public override string ToString() => Success ? "Success" : $"{Failure} (code {ProviderCode}) {Detail}";
    }
}
