namespace PlatformLibrary.LocalNotifications
{
    /// <summary>The player opened the app by tapping a local notification.</summary>
    public sealed class LocalNotificationOpened
    {
        public LocalNotificationOpened(string key, string data)
        {
            Key = key ?? string.Empty;
            Data = data ?? string.Empty;
        }

        /// <summary>The key given to <see cref="LocalNotification"/>. Empty when the notification was not scheduled by this package.</summary>
        public string Key { get; }

        public string Data { get; }
    }
}
