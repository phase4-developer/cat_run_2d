# Changelog

## 0.1.0-pre.1 - 2026-11-08

New package, per the local notification part of `Docs/PlatformPush/Design.md`. The mobile library had no local notifications.

- `LocalNotificationManager` is the static entry point. Games need no SDK and no provider.
- Schedules use a string key. The same key replaces the earlier notification, and the key's number needs no saving.
- `LocalNotificationFailure` reports why a call failed, with the SDK code in `ProviderCode` for logs. Shared names and order match `NetworkFailure`.
- Turning notifications off cancels every scheduled one.
- Opened notifications wait for the first listener.

Unity EditMode and PlayMode tests passed in `Hosts/PlatformPushValidationHost` on 2026-11-08. Player and device tests are NOT_RUN. See `Docs/PlatformPush/Report.md`.
