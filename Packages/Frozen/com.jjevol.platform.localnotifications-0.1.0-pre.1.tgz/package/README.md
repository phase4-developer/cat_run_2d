# JJEvol Platform Local Notifications

Local validation candidate 0.1.0-pre.1. The local notification manager, the provider contract and the result types. Games call `LocalNotificationManager` and never see an SDK.

The code is user-authored, confirmed by the user on 2026-11-08. This package has no SDK, notification text, channel name or icon in it.

## Use

The project's start code decides what runs. This is the only place that names a provider:

```csharp
#if UNITY_ANDROID || UNITY_IOS
LocalNotificationManager.SetProvider(new UnityLocalNotificationProvider(settings));
#endif
LocalNotificationManager.Initialize();
LocalNotificationManager.SetEnabled(options.NotificationsOn);
```

Game code knows only the manager:

```csharp
LocalNotificationManager.Schedule(
    new LocalNotification("energy_full", title, body, fireTimeUtc, data: "screen=energy"),
    result => { if (result.Failure == LocalNotificationFailure.PermissionDenied) ShowGuide(); });

LocalNotificationManager.Cancel("energy_full");
LocalNotificationManager.NotificationOpened += opened => OpenScreen(opened.Data);
```

Call `LocalNotificationManager` from the Unity main thread. Every callback and event runs on the main thread. A callback that throws is logged and does not stop the manager.

## No provider

Nothing is required. With no provider, `Initialize` completes, `Schedule` and `RequestPermission` answer `LocalNotificationFailure.Unsupported`, and `Cancel` does nothing. A platform with no notifications simply registers none.

Choosing a provider belongs to the project. `SetProvider(null)` removes a provider. Replacing one ends its pending calls with `ProviderError`, and the new one needs `Initialize` again.

## Calls

| Call | Behavior |
|---|---|
| `Initialize()` | Starts the provider. While off, it also clears the provider's scheduled notifications. |
| `SetEnabled(bool)` | Off cancels every scheduled notification, and later schedules answer `Disabled`. On does not bring cancelled ones back. |
| `RequestPermission(callback)` | Asks for permission at a moment the game chooses. |
| `Schedule(notification, callback)` | Schedules one notification. The first schedule asks for permission. The same key replaces the earlier one. |
| `Cancel(key)`, `CancelAll()` | Cancels scheduled notifications. |
| `NotificationOpened` | The player tapped a local notification to open the app. Up to 16 are held until the first listener. |

`Schedule` answers `Disabled` until `SetEnabled(true)` has been called, so the game's option decides from the start.

A key is turned into a fixed number for the SDK, so nothing is saved. Keys must not be empty and must not contain a line break. `FireTimeUtc` takes a `DateTime`; a local time is converted to UTC, and an unspecified kind is read as UTC. A time that has passed answers `InvalidTime`. Repeating notifications are not included.

A schedule that is still waiting for permission when the game cancels it, schedules the same key again or turns notifications off, ends with `ProviderError` or `Disabled` and is never shown.

## Results

`LocalNotificationResult.Failure` is the only value a game branches on. `ProviderCode` and `Detail` are for logs.

| `Failure` | Meaning |
|---|---|
| `None` | The call worked. |
| `Unsupported` | No provider. |
| `NotInitialized` | `Initialize` has not finished. |
| `Disabled` | Notifications are off. |
| `PermissionDenied` | The player did not allow notifications. |
| `InvalidTime` | The fire time has passed. |
| `ProviderError` | Any other SDK error, a cancelled pending schedule, or a provider change. |

## With push

`com.jjevol.platform.push` is a separate manager on purpose: a game may use only one of them. They share only the OS permission and the player's option, so the project passes the same option to both. The OS asks for permission once.

## Writing a provider

Implement `ILocalNotificationProvider`. The manager calls it on the main thread with the key's number, and it may answer and raise `Opened` from any thread. The manager already handles the off state, permission, stale schedules and keys. A provider only talks to its SDK and returns the key and data of an opened notification.

## Validation

Tests are in `Tests/Editor` and `Tests/Runtime`, in isolated assemblies, and need no SDK and no provider package. Run them from `Hosts/PlatformPushValidationHost`. See `Docs/PlatformPush/Report.md` for what has run.
