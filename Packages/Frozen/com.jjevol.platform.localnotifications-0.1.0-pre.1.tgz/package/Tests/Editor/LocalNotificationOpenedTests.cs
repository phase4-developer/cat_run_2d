using NUnit.Framework;

namespace PlatformLibrary.LocalNotifications.Tests
{
    public sealed class LocalNotificationOpenedTests : LocalNotificationTestBase
    {
        [Test]
        public void OpenedGoesToListeners()
        {
            StartEnabled();
            Listen();

            Provider.RaiseOpened(new LocalNotificationOpened("energy_full", "screen=energy"));

            Assert.AreEqual(1, Opened.Count);
            Assert.AreEqual("energy_full", Opened[0].Key);
            Assert.AreEqual("screen=energy", Opened[0].Data);
        }

        [Test]
        public void OpenedBeforeTheFirstListenerGoesToItOnce()
        {
            StartEnabled();
            Provider.RaiseOpened(new LocalNotificationOpened("a", null));

            Listen();
            LocalNotificationManager.NotificationOpened += opened => { };

            Assert.AreEqual(1, Opened.Count);
        }

        [Test]
        public void OpenedBeforeSetEnabledWaitsUntilEnabled()
        {
            UseProvider();
            LocalNotificationManager.Initialize();
            Listen();

            Provider.RaiseOpened(new LocalNotificationOpened("a", null));
            Assert.AreEqual(0, Opened.Count);

            LocalNotificationManager.SetEnabled(true);
            Assert.AreEqual(1, Opened.Count);
        }

        [Test]
        public void OpenedWhileDisabledIsDropped()
        {
            StartEnabled();
            LocalNotificationManager.SetEnabled(false);
            Listen();

            Provider.RaiseOpened(new LocalNotificationOpened("a", null));
            LocalNotificationManager.SetEnabled(true);

            Assert.AreEqual(0, Opened.Count);
        }

        [Test]
        public void OpenedFromAnotherThreadWaitsForTheMainThread()
        {
            StartEnabled();
            Listen();
            Host.QueuePosts = true;

            Provider.RaiseOpened(new LocalNotificationOpened("a", null));
            Assert.AreEqual(0, Opened.Count);

            Host.RunPosted();
            Assert.AreEqual(1, Opened.Count);
        }

        [Test]
        public void WaitingKeepsTheNewestSixteen()
        {
            StartEnabled();
            for (int i = 0; i < 20; i++)
                Provider.RaiseOpened(new LocalNotificationOpened(i.ToString(), null));

            Listen();

            Assert.AreEqual(LocalNotificationSession.MaxPendingOpened, Opened.Count);
            Assert.AreEqual("4", Opened[0].Key);
        }
    }
}
