using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.LocalNotifications.Tests
{
    public abstract class LocalNotificationTestBase
    {
        internal FakeLocalNotificationHost Host;
        protected FakeLocalNotificationProvider Provider;
        protected readonly List<LocalNotificationResult> Answers = new List<LocalNotificationResult>();
        protected readonly List<LocalNotificationOpened> Opened = new List<LocalNotificationOpened>();

        protected LocalNotificationResult LastAnswer => Answers[Answers.Count - 1];

        [SetUp]
        public void SetUpManager()
        {
            LocalNotificationManager.ResetState();
            Provider = new FakeLocalNotificationProvider();
            Host = new FakeLocalNotificationHost();
            Answers.Clear();
            Opened.Clear();
        }

        [TearDown]
        public void TearDownManager()
        {
            LocalNotificationManager.ResetState();
        }

        protected void UseProvider()
        {
            LocalNotificationManager.SetProvider(Provider, Host);
        }

        protected void StartEnabled()
        {
            UseProvider();
            LocalNotificationManager.Initialize();
            LocalNotificationManager.SetEnabled(true);
        }

        protected void Schedule(string key, double hoursFromNow = 1, string data = null)
        {
            LocalNotificationManager.Schedule(Notification(key, hoursFromNow, data), Answers.Add);
        }

        protected LocalNotification Notification(string key, double hoursFromNow = 1, string data = null)
        {
            return new LocalNotification(key, "title", "body", Host.UtcNow.AddHours(hoursFromNow), data);
        }

        protected void Listen()
        {
            LocalNotificationManager.NotificationOpened += Opened.Add;
        }

        protected static string ScheduleCall(string key) => "Schedule:" + LocalNotificationIds.FromKey(key);

        protected static string CancelCall(string key) => "Cancel:" + LocalNotificationIds.FromKey(key);

        protected static DateTime Utc(int hour) => new DateTime(2026, 11, 8, hour, 0, 0, DateTimeKind.Utc);
    }
}
