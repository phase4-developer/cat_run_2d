using NUnit.Framework;

namespace PlatformLibrary.LocalNotifications.Tests
{
    public sealed class LocalNotificationDisableTests : LocalNotificationTestBase
    {
        [Test]
        public void DisablingCancelsEverything()
        {
            StartEnabled();
            Schedule("a");

            LocalNotificationManager.SetEnabled(false);
            Schedule("b");

            Assert.AreEqual(0, Provider.Scheduled.Count);
            Assert.AreEqual(LocalNotificationFailure.Disabled, LastAnswer.Failure);
            Assert.AreEqual(1, Provider.Count("CancelAll"));
        }

        [Test]
        public void EnablingAgainDoesNotRestoreCancelledNotifications()
        {
            StartEnabled();
            Schedule("a");
            LocalNotificationManager.SetEnabled(false);
            LocalNotificationManager.SetEnabled(true);

            Assert.AreEqual(0, Provider.Scheduled.Count);
        }

        [Test]
        public void DisablingWhilePermissionIsPendingAnswersDisabled()
        {
            StartEnabled();
            Provider.AutoAnswer = false;
            Schedule("a");

            LocalNotificationManager.SetEnabled(false);
            Provider.AnswerNext();

            Assert.AreEqual(LocalNotificationFailure.Disabled, LastAnswer.Failure);
            Assert.AreEqual(0, Provider.Count(ScheduleCall("a")));
        }

        [Test]
        public void ScheduleFinishingAfterDisablingIsCancelled()
        {
            StartEnabled();
            Provider.AutoAnswer = false;
            Schedule("a");
            Provider.AnswerNext();

            LocalNotificationManager.SetEnabled(false);
            Provider.AnswerNext();

            Assert.AreEqual(LocalNotificationFailure.Disabled, LastAnswer.Failure);
            Assert.AreEqual(CancelCall("a"), Provider.Calls[Provider.Calls.Count - 1]);
            Assert.AreEqual(0, Provider.Scheduled.Count);
        }

        [Test]
        public void StartingDisabledCancelsAfterInitialize()
        {
            UseProvider();
            LocalNotificationManager.SetEnabled(false);
            LocalNotificationManager.Initialize();

            CollectionAssert.AreEqual(new[] { "Initialize", "CancelAll" }, Provider.Calls);
        }

        [Test]
        public void CancelAllFailureIsLogged()
        {
            StartEnabled();
            Provider.ThrowOn = "CancelAll";

            LocalNotificationManager.CancelAll();

            Assert.AreEqual(1, Host.Exceptions.Count);
        }
    }
}
