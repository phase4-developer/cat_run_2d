using System;
using NUnit.Framework;

namespace PlatformLibrary.LocalNotifications.Tests
{
    public sealed class LocalNotificationNoProviderTests : LocalNotificationTestBase
    {
        [Test]
        public void ScheduleAnswersUnsupported()
        {
            LocalNotificationManager.Initialize();
            LocalNotificationManager.SetEnabled(true);
            Schedule("a");

            Assert.AreEqual(LocalNotificationFailure.Unsupported, LastAnswer.Failure);
            Assert.IsTrue(LocalNotificationManager.IsInitialized);
            Assert.IsFalse(LocalNotificationManager.IsSupported);
        }

        [Test]
        public void RequestPermissionAnswersUnsupported()
        {
            LocalNotificationManager.RequestPermission(Answers.Add);

            Assert.AreEqual(LocalNotificationFailure.Unsupported, LastAnswer.Failure);
        }

        [Test]
        public void CancelWithoutProviderDoesNothing()
        {
            LocalNotificationManager.Cancel("a");
            LocalNotificationManager.CancelAll();

            CollectionAssert.IsEmpty(Answers);
        }

        [Test]
        public void ScheduleWithoutANotificationThrows()
        {
            Assert.Throws<ArgumentNullException>(() => LocalNotificationManager.Schedule(null));
        }

        [Test]
        public void EnabledStateCarriesOverToTheProvider()
        {
            LocalNotificationManager.SetEnabled(true);
            UseProvider();
            LocalNotificationManager.Initialize();
            Schedule("a");

            Assert.IsTrue(LastAnswer.Success);
        }
    }
}
