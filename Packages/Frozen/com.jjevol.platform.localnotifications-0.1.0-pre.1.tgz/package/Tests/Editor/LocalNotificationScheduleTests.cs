using NUnit.Framework;

namespace PlatformLibrary.LocalNotifications.Tests
{
    public sealed class LocalNotificationScheduleTests : LocalNotificationTestBase
    {
        [Test]
        public void ScheduleBeforeInitializeAnswersNotInitialized()
        {
            UseProvider();
            LocalNotificationManager.SetEnabled(true);
            Schedule("a");

            Assert.AreEqual(LocalNotificationFailure.NotInitialized, LastAnswer.Failure);
        }

        [Test]
        public void ScheduleBeforeSetEnabledAnswersDisabled()
        {
            UseProvider();
            LocalNotificationManager.Initialize();
            Schedule("a");

            Assert.AreEqual(LocalNotificationFailure.Disabled, LastAnswer.Failure);
            CollectionAssert.AreEqual(new[] { "Initialize" }, Provider.Calls);
        }

        [Test]
        public void ScheduleAsksPermissionThenSchedulesUnderTheKeyId()
        {
            StartEnabled();
            Schedule("energy_full", data: "screen=energy");

            Assert.IsTrue(LastAnswer.Success);
            CollectionAssert.AreEqual(new[] { "Initialize", "RequestPermission", ScheduleCall("energy_full") }, Provider.Calls);
            Assert.AreEqual("screen=energy", Provider.Scheduled[LocalNotificationIds.FromKey("energy_full")].Data);
        }

        [Test]
        public void PastTimeAnswersInvalidTime()
        {
            StartEnabled();
            Schedule("a", hoursFromNow: -1);
            Schedule("b", hoursFromNow: 0);

            Assert.AreEqual(LocalNotificationFailure.InvalidTime, Answers[0].Failure);
            Assert.AreEqual(LocalNotificationFailure.InvalidTime, Answers[1].Failure);
            Assert.AreEqual(0, Provider.Count("RequestPermission"));
        }

        [Test]
        public void DeniedPermissionAnswersPermissionDenied()
        {
            Provider.PermissionResult = LocalNotificationResult.Failed(LocalNotificationFailure.PermissionDenied);
            StartEnabled();
            Schedule("a");

            Assert.AreEqual(LocalNotificationFailure.PermissionDenied, LastAnswer.Failure);
            Assert.AreEqual(0, Provider.Scheduled.Count);
        }

        [Test]
        public void SchedulesWaitingTogetherShareOnePermissionRequest()
        {
            Provider.AutoAnswer = false;
            UseProvider();
            LocalNotificationManager.Initialize();
            Provider.AnswerNext();
            LocalNotificationManager.SetEnabled(true);

            Schedule("a");
            Schedule("b");
            Assert.AreEqual(1, Provider.Count("RequestPermission"));

            Provider.AnswerNext();
            Provider.AnswerNext();
            Provider.AnswerNext();

            Assert.AreEqual(2, Answers.Count);
            Assert.IsTrue(Answers.TrueForAll(answer => answer.Success));
        }

        [Test]
        public void CancelUsesTheSameId()
        {
            StartEnabled();
            Schedule("a");
            LocalNotificationManager.Cancel("a");

            Assert.AreEqual(CancelCall("a"), Provider.Calls[Provider.Calls.Count - 1]);
            Assert.AreEqual(0, Provider.Scheduled.Count);
        }

        [Test]
        public void CancelWhilePermissionIsPendingDropsTheSchedule()
        {
            StartEnabled();
            Provider.AutoAnswer = false;
            Schedule("a");

            LocalNotificationManager.Cancel("a");
            Provider.AnswerNext();

            Assert.AreEqual(LocalNotificationFailure.ProviderError, LastAnswer.Failure);
            Assert.AreEqual("CANCELED_BEFORE_SCHEDULED", LastAnswer.Detail);
            Assert.AreEqual(0, Provider.Count(ScheduleCall("a")));
        }

        [Test]
        public void ProviderExceptionBecomesProviderError()
        {
            Provider.ThrowOn = "Schedule";
            StartEnabled();
            Schedule("a");

            Assert.AreEqual(LocalNotificationFailure.ProviderError, LastAnswer.Failure);
            Assert.AreEqual(1, Host.Exceptions.Count);
        }

        [Test]
        public void ProviderChangeAnswersCallsStillWaiting()
        {
            StartEnabled();
            Provider.AutoAnswer = false;
            Schedule("a");

            LocalNotificationManager.SetProvider(new FakeLocalNotificationProvider(), Host);

            Assert.AreEqual(LocalNotificationFailure.ProviderError, LastAnswer.Failure);
            Provider.AnswerNext();
            Assert.AreEqual(1, Answers.Count);
        }

        [Test]
        public void ExplicitPermissionRequestAnswers()
        {
            UseProvider();
            LocalNotificationManager.RequestPermission(Answers.Add);
            Assert.AreEqual(LocalNotificationFailure.NotInitialized, LastAnswer.Failure);

            LocalNotificationManager.Initialize();
            LocalNotificationManager.RequestPermission(Answers.Add);
            Assert.IsTrue(LastAnswer.Success);
        }

        [Test]
        public void FailedInitializeCanBeCalledAgain()
        {
            Provider.InitializeResult = LocalNotificationResult.Failed(LocalNotificationFailure.ProviderError);
            UseProvider();
            LocalNotificationManager.Initialize();
            Assert.IsFalse(LocalNotificationManager.IsInitialized);

            Provider.InitializeResult = LocalNotificationResult.Succeeded;
            LocalNotificationManager.Initialize();
            Assert.IsTrue(LocalNotificationManager.IsInitialized);
        }
    }
}
