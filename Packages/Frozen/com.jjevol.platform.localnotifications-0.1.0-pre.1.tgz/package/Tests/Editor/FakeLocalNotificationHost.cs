using System;
using System.Collections.Generic;

namespace PlatformLibrary.LocalNotifications.Tests
{
    /// <summary>Runs posts at once unless <see cref="QueuePosts"/>. Time is fixed until a test moves it.</summary>
    internal sealed class FakeLocalNotificationHost : ILocalNotificationHost
    {
        private readonly Queue<Action> _posted = new Queue<Action>();

        public readonly List<string> Warnings = new List<string>();
        public readonly List<Exception> Exceptions = new List<Exception>();

        public bool QueuePosts;

        public DateTime UtcNow { get; set; } = new DateTime(2026, 11, 8, 0, 0, 0, DateTimeKind.Utc);

        public void Post(Action action)
        {
            if (QueuePosts) _posted.Enqueue(action);
            else action();
        }

        public void RunPosted()
        {
            while (_posted.Count > 0)
                _posted.Dequeue()();
        }

        public void LogWarning(string message) => Warnings.Add(message);

        public void LogException(Exception exception) => Exceptions.Add(exception);
    }
}
