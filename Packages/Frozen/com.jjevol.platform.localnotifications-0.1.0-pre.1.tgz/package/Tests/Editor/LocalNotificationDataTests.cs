using System;
using NUnit.Framework;

namespace PlatformLibrary.LocalNotifications.Tests
{
    public sealed class LocalNotificationDataTests
    {
        [Test]
        public void IdsAreStablePositiveAndDiffer()
        {
            int id = LocalNotificationIds.FromKey("energy_full");

            Assert.AreEqual(id, LocalNotificationIds.FromKey("energy_full"));
            Assert.Greater(id, 0);
            Assert.AreNotEqual(id, LocalNotificationIds.FromKey("energy_half"));
        }

        [Test]
        public void IdMatchesTheFixedHash()
        {
            // FNV-1a of "a" is 0xE40C292C; the top bit is cleared.
            Assert.AreEqual(0x640C292C, LocalNotificationIds.FromKey("a"));
        }

        [Test]
        public void KeyIsRequiredAndHasNoLineBreaks()
        {
            DateTime time = DateTime.UtcNow.AddHours(1);

            Assert.Throws<ArgumentException>(() => new LocalNotification("", "t", "b", time));
            Assert.Throws<ArgumentException>(() => new LocalNotification(null, "t", "b", time));
            Assert.Throws<ArgumentException>(() => new LocalNotification("a\nb", "t", "b", time));
        }

        [Test]
        public void LocalTimeIsConvertedToUtc()
        {
            var local = new DateTime(2026, 11, 8, 9, 0, 0, DateTimeKind.Local);
            var notification = new LocalNotification("a", null, null, local);

            Assert.AreEqual(DateTimeKind.Utc, notification.FireTimeUtc.Kind);
            Assert.AreEqual(local.ToUniversalTime(), notification.FireTimeUtc);
            Assert.AreEqual(string.Empty, notification.Title);
            Assert.AreEqual(string.Empty, notification.Data);
        }

        [Test]
        public void UnspecifiedTimeIsTakenAsUtc()
        {
            var unspecified = new DateTime(2026, 11, 8, 9, 0, 0, DateTimeKind.Unspecified);

            Assert.AreEqual(9, new LocalNotification("a", null, null, unspecified).FireTimeUtc.Hour);
        }

        [Test]
        public void ResultNeedsAReasonAndHasDetail()
        {
            Assert.Throws<ArgumentException>(() => LocalNotificationResult.Failed(LocalNotificationFailure.None));
            Assert.IsTrue(LocalNotificationResult.Succeeded.Success);
            Assert.AreEqual(string.Empty, LocalNotificationResult.Succeeded.Detail);
            Assert.AreEqual(5, LocalNotificationResult.Failed(LocalNotificationFailure.ProviderError, 5).ProviderCode);
        }

        [Test]
        public void OpenedNeverHasNullText()
        {
            var opened = new LocalNotificationOpened(null, null);

            Assert.AreEqual(string.Empty, opened.Key);
            Assert.AreEqual(string.Empty, opened.Data);
        }
    }
}
