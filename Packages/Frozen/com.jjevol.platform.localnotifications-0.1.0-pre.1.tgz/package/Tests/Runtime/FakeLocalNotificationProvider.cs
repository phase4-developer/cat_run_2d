using System;
using System.Collections.Generic;

namespace PlatformLibrary.LocalNotifications.Tests
{
    /// <summary>
    /// A provider that records each call. With <see cref="AutoAnswer"/> it answers at once; without it, answers wait
    /// until <see cref="AnswerNext"/>.
    /// </summary>
    public sealed class FakeLocalNotificationProvider : ILocalNotificationProvider
    {
        private readonly Queue<Action> _waiting = new Queue<Action>();

        public readonly List<string> Calls = new List<string>();
        public readonly Dictionary<int, LocalNotification> Scheduled = new Dictionary<int, LocalNotification>();

        public bool AutoAnswer = true;
        public string ThrowOn;
        public LocalNotificationResult InitializeResult;
        public LocalNotificationResult PermissionResult;
        public LocalNotificationResult ScheduleResult;

        public int WaitingCount => _waiting.Count;

        public event Action<LocalNotificationOpened> Opened;

        public int Count(string call) => Calls.FindAll(c => c == call).Count;

        public void AnswerNext() => _waiting.Dequeue()();

        public void RaiseOpened(LocalNotificationOpened opened) => Opened?.Invoke(opened);

        public void Initialize(Action<LocalNotificationResult> completed) => Answer("Initialize", () => completed(InitializeResult));

        public void RequestPermission(Action<LocalNotificationResult> completed) => Answer("RequestPermission", () => completed(PermissionResult));

        public void Schedule(int id, LocalNotification notification, Action<LocalNotificationResult> completed)
        {
            Answer("Schedule:" + id, () =>
            {
                if (ScheduleResult.Success) Scheduled[id] = notification;
                completed(ScheduleResult);
            });
        }

        public void Cancel(int id)
        {
            Calls.Add("Cancel:" + id);
            Scheduled.Remove(id);
        }

        public void CancelAll()
        {
            Calls.Add("CancelAll");
            if (ThrowOn == "CancelAll") throw new InvalidOperationException("fake failure in CancelAll");
            Scheduled.Clear();
        }

        private void Answer(string call, Action answer)
        {
            Calls.Add(call);
            if (ThrowOn == call || (ThrowOn == "Schedule" && call.StartsWith("Schedule:", StringComparison.Ordinal)))
                throw new InvalidOperationException("fake failure in " + call);

            if (AutoAnswer) answer();
            else _waiting.Enqueue(answer);
        }
    }
}
