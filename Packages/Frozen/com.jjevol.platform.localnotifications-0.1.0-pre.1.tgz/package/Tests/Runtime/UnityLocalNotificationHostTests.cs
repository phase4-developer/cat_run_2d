using System;
using System.Collections;
using System.Threading;
using NUnit.Framework;
using UnityEngine.TestTools;

namespace PlatformLibrary.LocalNotifications.Tests
{
    public sealed class UnityLocalNotificationHostTests
    {
        [TearDown]
        public void TearDown()
        {
            LocalNotificationManager.ResetState();
        }

        [UnityTest]
        public IEnumerator PostFromAnotherThreadRunsOnTheMainThread()
        {
            UnityLocalNotificationHost host = UnityLocalNotificationHost.Instance;
            int mainThread = Thread.CurrentThread.ManagedThreadId;
            int ranOn = -1;

            var worker = new Thread(() => host.Post(() => ranOn = Thread.CurrentThread.ManagedThreadId));
            worker.Start();
            worker.Join();

            for (int frame = 0; frame < 10 && ranOn == -1; frame++)
                yield return null;

            Assert.AreEqual(mainThread, ranOn);
        }

        [Test]
        public void SettingAProviderSchedulesWithAFakeProvider()
        {
            var provider = new FakeLocalNotificationProvider();
            LocalNotificationManager.SetProvider(provider);
            LocalNotificationManager.Initialize();
            LocalNotificationManager.SetEnabled(true);

            LocalNotificationResult? answer = null;
            LocalNotificationManager.Schedule(new LocalNotification("energy_full", "t", "b", DateTime.UtcNow.AddHours(1)), result => answer = result);

            Assert.IsTrue(answer.Value.Success);
            Assert.AreEqual(1, provider.Scheduled.Count);
        }
    }
}
