using System;
using System.Threading;
using UnityEngine;
namespace jjevol
{
    /// <summary>Game-owned price presentation; purchasing and receipts remain outside UI.</summary>
    public interface IProductPriceSource
    {
        ConsumeData GetPrice(int productId);
        event Action<int> Changed;
    }

    /// <summary>Optional non-owning scene connector. Initialization, storage and profile lifetime belong to the game.</summary>
    [DisallowMultipleComponent]
    public class LocalEconomyUIContext : MonoBehaviour
    {
        private int _threadId;
        private IProductPriceSource _productPrices;
        private Action<int> _productHandler;
        private object _productToken;
        public ResourceService Resources { get; private set; }
        public bool IsBound => Resources != null && !Resources.IsDisposed && !Resources.Repository.IsDisposed;
        public string Identity => Resources?.Repository.ProfileId;
        public IProductPriceSource ProductPrices => _productPrices;
        public IConsumePresentationProvider Presentation { get; private set; }
        public event Action BindingChanged;
        public event Action<int> ProductPriceChanged;
        private void Awake() => _threadId = Thread.CurrentThread.ManagedThreadId;
        private void OnDestroy()
        {
            ReplaceProductPrices(null); Resources = null; Presentation = null;
            Notify(); BindingChanged = null; ProductPriceChanged = null;
        }
        public void Bind(ResourceService resources, IConsumePresentationProvider presentation = null)
        {
            CheckThread();
            if (resources == null) throw new ArgumentNullException(nameof(resources));
            if (resources.IsDisposed) throw new ObjectDisposedException(nameof(resources));
            _ = resources.Repository.Revision;
            if (Resources != null && !ReferenceEquals(Resources, resources)) ReplaceProductPrices(null);
            Resources = resources; Presentation = presentation; Notify();
        }
        public void SetProductPrices(IProductPriceSource source)
        {
            CheckThread();
            ReplaceProductPrices(source); Notify();
        }
        private void ReplaceProductPrices(IProductPriceSource source)
        {
            _productToken = null;
            if (_productPrices != null) _productPrices.Changed -= _productHandler;
            _productPrices = source;
            _productHandler = null;
            if (source == null) return;
            object token = _productToken = new object();
            _productHandler = id => { if (ReferenceEquals(_productToken, token)) OnProductPriceChanged(id); };
            source.Changed += _productHandler;
        }
        private void OnProductPriceChanged(int id)
        {
            CheckThread();
            var subscribers = ProductPriceChanged;
            if (subscribers == null) return;
            foreach (Action<int> subscriber in subscribers.GetInvocationList())
                try { subscriber(id); } catch (Exception exception) { Debug.LogException(exception); }
        }
        public void Unbind() { CheckThread(); ReplaceProductPrices(null); Resources = null; Presentation = null; Notify(); }
        private void Notify()
        {
            var subscribers = BindingChanged;
            if (subscribers == null) return;
            foreach (Action callback in subscribers.GetInvocationList())
                try { callback(); } catch (Exception exception) { Debug.LogException(exception); }
        }
        private void CheckThread()
        {
            if (_threadId == 0) _threadId = Thread.CurrentThread.ManagedThreadId;
            if (_threadId != Thread.CurrentThread.ManagedThreadId) throw new InvalidOperationException("Bind and use UI on its creating thread.");
        }
    }
}
