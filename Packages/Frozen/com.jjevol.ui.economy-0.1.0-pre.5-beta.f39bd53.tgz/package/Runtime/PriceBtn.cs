using UnityEngine;
using UnityEngine.UI;

namespace jjevol
{
    // Input actions are connected by Inspector UnityEvents; this component only displays affordability.
    public class PriceBtn : PriceLabel
    {
        [SerializeField] private Button button;
        [Tooltip("Optional. When set, it owns the Button state and shows lockedState instead of a plain disable.")]
        [SerializeField] private UIButtonLock buttonLock;
        [SerializeField] private UIButtonLockState lockedState = UIButtonLockState.HardLock;
        public bool InputAllowed { get; private set; } = true;
        public void SetInputAllowed(bool allowed) { if (InputAllowed == allowed) return; InputAllowed = allowed; SetDirty(); }

        protected override void _DrawContents()
        {
            base._DrawContents();
            bool usable = CanAfford && InputAllowed;
            if (buttonLock != null) buttonLock.SetState(usable ? UIButtonLockState.Normal : lockedState);
            else if (button != null) button.interactable = usable;
        }
    }
}
