using System;
using System.Globalization;
using UnityEngine;
namespace jjevol
{
    /// <summary>Binding and invalidation lifecycle only. Never constructs/disposes game services.</summary>
    public abstract class LocalEconomyUI : UIBase
    {
        [SerializeField] protected LocalEconomyUIContext context;
        private ResourceService _direct, _subscribed;
        private IConsumePresentationProvider _presentation;
        private Action _contextHandler;
        private object _contextToken;
        protected IProductPriceSource DirectProductPrices { get; private set; }
        public LocalEconomyUIContext Context => context;
        public ResourceService Resources => context != null ? context.Resources : _direct;
        protected bool HasSource => IsLive(Resources);
        protected ConsumeTypeId BoundWealthType => Resources?.WealthTypeId ?? default;
        private static bool IsLive(ResourceService resources) => resources != null && !resources.IsDisposed && !resources.Repository.IsDisposed;
        protected void SetContext(LocalEconomyUIContext next)
        {
            DetachContext();
            context = next; _direct = null; _presentation = null; DirectProductPrices = null;
            SubscribeContext();
            SyncResources(); OnContextChanged();
        }
        protected void SetResources(ResourceService resources, IConsumePresentationProvider presentation = null, IProductPriceSource prices = null)
        {
            if (resources == null) throw new ArgumentNullException(nameof(resources));
            if (!IsLive(resources)) throw new ObjectDisposedException(nameof(resources));
            _ = resources.Repository.Revision;
            DetachContext();
            context = null; _direct = resources; _presentation = presentation; DirectProductPrices = prices;
            SyncResources(); OnContextChanged();
        }
        protected override void OnEnable() { base.OnEnable(); OnContextChanged(); SetDirty(); }
        protected virtual void LateUpdate()
        {
            if (_subscribed != null && !IsLive(_subscribed)) { SyncResources(); OnContextChanged(); SetDirty(); }
        }
        protected override bool SetSubscribe(bool subscribe)
        {
            if (!base.SetSubscribe(subscribe)) return false;
            if (subscribe)
            {
                SubscribeContext();
                UIRuntimeOptions.LocaleChanged += HandleLocaleChanged;
            }
            else
            {
                DetachContext();
                UIRuntimeOptions.LocaleChanged -= HandleLocaleChanged;
            }
            SyncResources();
            return true;
        }
        private void SyncResources()
        {
            if (_subscribed != null) _subscribed.Changed -= HandleResourceChanged;
            _subscribed = mSubscribe && HasSource ? Resources : null;
            if (_subscribed == null) return;
            _subscribed.Changed += HandleResourceChanged;
        }
        private void DetachContext()
        {
            _contextToken = null;
            if (context != null && _contextHandler != null) context.BindingChanged -= _contextHandler;
            _contextHandler = null;
        }
        private void SubscribeContext()
        {
            if (!mSubscribe || context == null) return;
            object token = _contextToken = new object();
            _contextHandler = () => { if (ReferenceEquals(_contextToken, token)) HandleBindingChanged(); };
            context.BindingChanged += _contextHandler;
        }
        private void HandleResourceChanged(ResourceChange change)
        {
            if (!mSubscribe || this == null) return;
            if (!HasSource || !ReferenceEquals(change.Service, Resources) || !ReferenceEquals(change.Repository, Resources.Repository) ||
                change.ProfileId != Resources.Repository.ProfileId || change.TypeId != BoundWealthType) return;
            OnResourcesChanged(change.ItemIds, change.RawChanged, change.AvailableChanged);
        }
        private void HandleBindingChanged() { SyncResources(); OnContextChanged(); SetDirty(); }
        private void HandleLocaleChanged() { if (mSubscribe && this != null) SetDirty(); }
        protected virtual void OnContextChanged() { }
        protected abstract void OnResourcesChanged(System.Collections.Generic.IReadOnlyList<int> ids, bool raw, bool available);
        protected long Read(ConsumeTypeId type, int id, bool raw = false)
            => raw ? Resources.GetRaw(type, id) : Resources.Get(type, id);
        protected ConsumePresentation Describe(ConsumeData value)
        {
            IConsumePresentationProvider provider = context != null ? context.Presentation : _presentation;
            if (provider != null) return value.Present(provider);
            WealthData row = Resources.Definitions.Get(value.ItemId);
            return new ConsumePresentation(row, row?.icon ?? "");
        }
        protected bool TryDescribe(ConsumeTypeId type, int itemId, out ConsumePresentation presentation)
        {
            IConsumePresentationProvider provider = context != null ? context.Presentation : _presentation;
            if (provider != null) return provider.TryResolve(type, itemId, out presentation);
            WealthData row = type == BoundWealthType ? Resources.Definitions.Get(itemId) : null;
            presentation = row == null ? default : new ConsumePresentation(row, row.icon);
            return row != null;
        }
        protected static CultureInfo DisplayCulture => UIRuntimeOptions.DisplayCulture;
    }
}
