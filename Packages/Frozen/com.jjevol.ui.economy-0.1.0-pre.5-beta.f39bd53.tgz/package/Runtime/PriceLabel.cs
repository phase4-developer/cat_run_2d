using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

namespace jjevol
{
    public class PriceLabel : LocalEconomyUI
    {
        [SerializeField] private AddressableImage icon;
        [SerializeField] private TMP_Text priceText;
        [SerializeField] private bool showOwnedCount;
        [SerializeField] private bool ownedCountFirst;
        [SerializeField] private Color normalColor = Color.white;
        [SerializeField] private Color insufficientColor = new Color(1f, 0.38f, 0.45f);
        private ConsumeData[] _prices;
        private int _productId, _quantity = 1;
        private bool _free;
        private string _freeText;
        private ConsumeData[] _displayCosts = Array.Empty<ConsumeData>();
        private LocalEconomyUIContext _priceContext;
        private IProductPriceSource _priceSource;
        private Action<int> _priceHandler;
        private object _priceToken;
        public bool HasData { get; private set; }
        public bool CanAfford { get; private set; }
        public bool IsFree { get; private set; }
        // A single resource total only; currencies are never summed into a meaningless scalar.
        public long Required { get; private set; }

        public void ShowUI(LocalEconomyUIContext source, ConsumeData price)
        { SetContext(source); SetPrice(price); base.ShowUI(); }
        public void ShowUI(ResourceService source, ConsumeData price, IConsumePresentationProvider presentation = null)
        { SetResources(source, presentation); SetPrice(price); base.ShowUI(); }
        private void SetPrice(ConsumeData price)
        { _prices = price == null ? null : new[] { price.Clone() }; _productId = 0; _quantity = 1; _free = false; }
        public void ShowCosts(ResourceService source, IEnumerable<ConsumeData> costs, IConsumePresentationProvider presentation = null)
        {
            if (costs == null) throw new ArgumentNullException(nameof(costs));
            ConsumeData[] copy = costs.Select(value => value?.Clone()).ToArray();
            if (copy.Length == 0) throw new ArgumentException("Use ShowFree with the game's localized text for a free offer.", nameof(costs));
            SetResources(source, presentation); _prices = copy; _productId = 0; _quantity = 1; _free = false; base.ShowUI();
        }
        public void ShowFree(ResourceService source, string localizedText)
        {
            if (string.IsNullOrWhiteSpace(localizedText)) throw new ArgumentException("Game-provided free text is required.", nameof(localizedText));
            SetResources(source); _free = true; _freeText = localizedText; _prices = Array.Empty<ConsumeData>(); _productId = 0; _quantity = 1; base.ShowUI();
        }
        public void ShowProduct(LocalEconomyUIContext source, int productId, int quantity = 1)
        {
            if (source != null && source.ProductPrices == null) throw new InvalidOperationException("Provide a game-owned IProductPriceSource before showing a product.");
            SetContext(source); _productId = productId; _quantity = quantity; _prices = null; _free = false; base.ShowUI();
        }
        public void ShowProduct(ResourceService source, IProductPriceSource prices, int productId, int quantity = 1, IConsumePresentationProvider presentation = null)
        {
            if (prices == null) throw new ArgumentNullException(nameof(prices));
            SetResources(source, presentation, prices); _productId = productId; _quantity = quantity; _prices = null; _free = false; base.ShowUI();
        }
        private ConsumeData[] ResolveCosts()
        {
            if (!HasSource || _quantity <= 0) return null;
            if (_free) return Array.Empty<ConsumeData>();
            ConsumeData[] prices = _productId != 0 ? new[] { (context != null ? context.ProductPrices : DirectProductPrices)?.GetPrice(_productId) } : _prices;
            if (prices == null || prices.Length == 0) return null;
            var totals = new Dictionary<(ConsumeTypeId, int), long>();
            foreach (ConsumeData value in prices)
            {
                if (value == null || value.IsRandomVal || value.Quantity < 0) return null;
                _ = Read(value.TypeId, value.ItemId);
                long quantity = checked(value.Quantity * (_productId != 0 ? _quantity : 1));
                totals.TryGetValue(value.Key, out long previous);
                totals[value.Key] = checked(previous + quantity);
            }
            return totals.OrderBy(pair => pair.Key.Item1.Value).ThenBy(pair => pair.Key.Item2)
                .Select(pair => new ConsumeData(pair.Key.Item1, pair.Key.Item2, pair.Value)).ToArray();
        }
        protected override bool SetSubscribe(bool subscribe)
        {
            if (!base.SetSubscribe(subscribe)) return false;
            SyncPrices(); return true;
        }
        protected override void OnContextChanged() { SyncPrices(); base.OnContextChanged(); }
        private void SyncPrices()
        {
            _priceToken = null;
            if (_priceContext != null) _priceContext.ProductPriceChanged -= _priceHandler;
            if (_priceSource != null) _priceSource.Changed -= _priceHandler;
            _priceContext = mSubscribe && HasSource ? context : null;
            _priceSource = mSubscribe && HasSource && context == null ? DirectProductPrices : null;
            _priceHandler = null;
            if (_priceContext == null && _priceSource == null) return;
            object token = _priceToken = new object();
            _priceHandler = id => { if (ReferenceEquals(_priceToken, token)) OnProductPriceChanged(id); };
            if (_priceContext != null) _priceContext.ProductPriceChanged += _priceHandler;
            if (_priceSource != null) _priceSource.Changed += _priceHandler;
        }
        private void OnProductPriceChanged(int id) { if (_productId != 0 && id == _productId) SetDirty(); }
        protected override void OnResourcesChanged(IReadOnlyList<int> ids, bool raw, bool available)
        {
            if (!available) return;
            foreach (ConsumeData price in _displayCosts)
                foreach (int id in ids) if (price.ItemId == id && price.TypeId == BoundWealthType) { SetDirty(); return; }
        }
        protected override void _DrawContents()
        {
            HasData = false; CanAfford = false; IsFree = false; Required = 0;
            _displayCosts = Array.Empty<ConsumeData>();
            string text = string.Empty; ConsumePresentation display = default;
            try
            {
                ConsumeData[] costs = ResolveCosts();
                if (costs != null)
                {
                    CanAfford = costs.Length == 0 || Resources.CheckSpend(costs);
                    HasData = true; IsFree = _free; _displayCosts = costs;
                    Required = costs.Length == 1 ? costs[0].Quantity : 0;
                    if (IsFree) text = _freeText;
                    else
                    {
                        display = costs.Length == 1 ? Describe(costs[0]) : default;
                        text = string.Join("\n", costs.Select(cost =>
                        {
                            string required = cost.Quantity.ToString("N0", DisplayCulture);
                            string amount = required;
                            if (showOwnedCount)
                            {
                                string owned = Read(cost.TypeId, cost.ItemId).ToString("N0", DisplayCulture);
                                amount = ownedCountFirst ? owned + " / " + required : required + " / " + owned;
                            }
                            string name = costs.Length > 1 ? Describe(cost).Name : string.Empty;
                            return string.IsNullOrEmpty(name) ? amount : name + ": " + amount;
                        }));
                    }
                }
            }
            catch (Exception exception) when (exception is ArgumentException || exception is NotSupportedException || exception is OverflowException || exception is ObjectDisposedException)
            { HasData = false; CanAfford = false; IsFree = false; Required = 0; text = string.Empty; _displayCosts = Array.Empty<ConsumeData>(); }
            if (priceText != null) { priceText.SetText(text); priceText.color = CanAfford ? normalColor : insufficientColor; }
            if (icon != null)
            {
                if (HasData && !IsFree && !string.IsNullOrEmpty(display.Atlas)) icon.SetAtlasSprite(display.Atlas, display.Icon);
                else icon.SetSprite(HasData && !IsFree ? display.Icon : string.Empty);
                icon.enabled = HasData && !IsFree && _displayCosts.Length == 1 && !string.IsNullOrEmpty(display.Icon);
            }
            base._DrawContents();
        }
    }
}
