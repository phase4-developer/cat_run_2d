using System;
using System.Collections.Generic;
using jjevol.UI;
using TMPro;
using UnityEngine;

namespace jjevol
{
    public enum ResourceQuantityView { Available, Confirmed }
    public class ResourceLabel : LocalEconomyUI
    {
        [SerializeField] private int resourceId;
        [SerializeField] private AddressableImage icon;
        [SerializeField] private NumberAnimator number;
        [SerializeField] private TMP_Text quantityText;
        [SerializeField] private string numberFormat = "N0";
        [SerializeField] private bool animateChanges;
        private ConsumeTypeId _type;
        private bool _explicitType, _rendered;
        private ResourceService _renderedService;
        public ResourceQuantityView QuantityView { get; private set; }
        public long Quantity { get; private set; }
        public bool HasData { get; private set; }

        public void ShowUI(LocalEconomyUIContext source, int id)
        { SetContext(source); resourceId = id; _explicitType = false; QuantityView = ResourceQuantityView.Available; _rendered = false; base.ShowUI(); }
        public void ShowUI(ResourceService source, ConsumeTypeId type, int id, ResourceQuantityView view = ResourceQuantityView.Available, IConsumePresentationProvider presentation = null)
        {
            if (view != ResourceQuantityView.Available && view != ResourceQuantityView.Confirmed) throw new ArgumentOutOfRangeException(nameof(view));
            SetResources(source, presentation); _type = type; _explicitType = true; resourceId = id; QuantityView = view; _rendered = false; base.ShowUI();
        }
        protected override void OnResourcesChanged(IReadOnlyList<int> ids, bool raw, bool available)
        {
            if (_explicitType && _type != BoundWealthType) return;
            if (QuantityView == ResourceQuantityView.Confirmed ? !raw : !available) return;
            foreach (int id in ids) if (id == resourceId) { SetDirty(); break; }
        }
        protected override void _DrawContents()
        {
            long previous = Quantity;
            HasData = false; Quantity = 0;
            ConsumePresentation display = default;
            if (HasSource)
                try
                {
                    ConsumeTypeId type = _explicitType ? _type : BoundWealthType;
                    Quantity = Read(type, resourceId, QuantityView == ResourceQuantityView.Confirmed);
                    if (!TryDescribe(type, resourceId, out display)) display = default;
                    HasData = true;
                }
                catch (Exception exception) when (exception is ArgumentException || exception is NotSupportedException || exception is ObjectDisposedException) { Quantity = 0; }
            if (number != null)
            {
                if (HasData && animateChanges && _rendered && ReferenceEquals(_renderedService, Resources) && previous != Quantity) number.AnimateTo(Quantity);
                else number.SetValueImmediate(Quantity);
            }
            else if (quantityText != null) quantityText.SetText(HasData ? Quantity.ToString(numberFormat, DisplayCulture) : string.Empty);
            if (icon != null)
            {
                if (HasData && !string.IsNullOrEmpty(display.Atlas)) icon.SetAtlasSprite(display.Atlas, display.Icon);
                else icon.SetSprite(HasData ? display.Icon : string.Empty);
                icon.enabled = HasData && !string.IsNullOrEmpty(display.Icon);
            }
            _rendered = HasData; _renderedService = Resources;
            base._DrawContents();
        }
    }
}
