using JJEvol.Save.Testing;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using jjevol.UI;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace jjevol.UI.Tests
{
    [PrebuildSetup("jjevol.UI.Tests.UITestTMPSetup")]
    public sealed class EconomyUIPlayTests
    {
        private const int Alpha=31001001,Beta=31001002;
        private string _root;
        private readonly List<GameObject> _objects=new();
        private WealthTable _table;
        private LocalSaveRepository _repository;
        private readonly LocalSaveCodec _codec=LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("test-v1",System.Text.Encoding.ASCII.GetBytes("0123456789abcdef0123456789abcdef")));
        private LocalEconomyUIContext _context;
        private DataRepository _data;
        private RepositoryStorageAdapter _storage;
        private readonly List<DataRepository> _users = new();
        private static readonly ConsumeTypeId Kind = new(812);
        private TMP_Settings _prior,_settings;
        private TMP_FontAsset _font;
        private Canvas _canvas;
        [SetUp]
        public void Setup()
        {
            _root=Path.GetFullPath(Path.Combine(Path.GetTempPath(),"JJEvolEconomyUITests",Guid.NewGuid().ToString("N")));
            _table=new WealthTable("31_fixture");_table.LoadDatas(new Source());
            _repository=PrefsFixture.Create("device:step11-ui", _root, _codec);
            _context=New("economy context").AddComponent<LocalEconomyUIContext>();
            BindPrimary(_repository);
            Assert.That(_context.IsBound,Is.True);
            Grant(_context.Resources,Alpha,100);Grant(_context.Resources,Beta,20);
            UIRuntimeOptions.Culture=()=>CultureInfo.GetCultureInfo("en-US");
            var field=typeof(TMP_Settings).GetField("s_Instance",BindingFlags.Static|BindingFlags.NonPublic);
            _prior=(TMP_Settings)field.GetValue(null);_settings=ScriptableObject.CreateInstance<TMP_Settings>();
            _font=TMP_FontAsset.CreateFontAsset("Arial","Regular",32);
            Assert.That(_font,Is.Not.Null,"The Windows validation host requires its installed Arial font.");
            typeof(TMP_Settings).GetField("m_defaultFontAsset",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(_settings,_font);field.SetValue(null,_settings);
            _canvas=New("actual Canvas",typeof(RectTransform),typeof(Canvas)).GetComponent<Canvas>();_canvas.renderMode=RenderMode.ScreenSpaceOverlay;
        }
        [UnityTearDown]
        public IEnumerator Cleanup()
        { PrefsFixture.Cleanup();
            for(int i=_objects.Count-1;i>=0;i--)if(_objects[i])Object.Destroy(_objects[i]);_objects.Clear();yield return null;
            typeof(TMP_Settings).GetField("s_Instance",BindingFlags.Static|BindingFlags.NonPublic).SetValue(null,_prior);
            if(_font){if(_font.material)Object.Destroy(_font.material);foreach(var texture in _font.atlasTextures)if(texture)Object.Destroy(texture);Object.Destroy(_font);}Object.Destroy(_settings);
            UIRuntimeOptions.Culture=null;
            foreach(var user in _users) user.Dispose(); _users.Clear();
            string allowed=Path.GetFullPath(Path.Combine(Path.GetTempPath(),"JJEvolEconomyUITests"))+Path.DirectorySeparatorChar;
            if(!_root.StartsWith(allowed,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Unsafe UI test fixture path");
            if(Directory.Exists(_root))Directory.Delete(_root,true);
            yield return null;
        }
        private GameObject New(string name,params Type[] components){var go=new GameObject(name,components);_objects.Add(go);return go;}
        private TextMeshProUGUI Text()
        {
            var go=New("actual TMP",typeof(RectTransform));go.transform.SetParent(_canvas.transform,false);
            ((RectTransform)go.transform).sizeDelta=new Vector2(1600,120);
            var text=go.AddComponent<TextMeshProUGUI>();text.fontSize=24;return text;
        }
        private static void Set(object target,string name,object value)
        { for(Type type=target.GetType();type!=null;type=type.BaseType){var field=type.GetField(name,BindingFlags.Instance|BindingFlags.NonPublic);if(field!=null){field.SetValue(target,value);return;}}throw new MissingFieldException(name); }
        private static bool Dirty(UIBase ui)=>(bool)typeof(UIBase).GetField("mDirty",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(ui);
        private ResourceLabel Resource(out TextMeshProUGUI text)
        { text=Text();var label=New("resource label",typeof(RectTransform)).AddComponent<ResourceLabel>();Set(label,"quantityText",text);label.ShowUI(_context,Alpha);return label; }
        private PriceLabel Price(out TextMeshProUGUI text)
        { text=Text();var label=New("price label",typeof(RectTransform)).AddComponent<PriceLabel>();Set(label,"priceText",text);return label; }
        private static ConsumeData Value(int id,long value)=>new(Kind,id,value);
        private static void Grant(ResourceService resources,int id,long value)
        { var storage=resources.Repository.Storage;LocalRewardService.Commit(storage,resources,LocalRewardService.PrepareMutation(storage,resources,Array.Empty<ConsumeData>(),new[]{Value(id,value)})); }
        private ResourceService OpenContainer(LocalSaveRepository files)
        {
            var data=new DataRepository(files.ProfileId);_users.Add(data);data.Register(new WealthContainer());
            RepositoryStorageAdapter.Open(data,files,"fixture:ui:v1",RepositoryStorageMode.LocalAuthority,()=>new JObject{["wealthInfos"]=new JArray()});
            return new ResourceService(data,_table,Kind);
        }
        private void BindPrimary(LocalSaveRepository files)
        { _data?.Dispose();var resources=OpenContainer(files);_data=resources.Repository;_storage=_data.Storage;_context.Bind(resources); }
        private static IEnumerator DrawFrame(){yield return null;yield return null;}

        [UnityTest] public IEnumerator PriceBtnDrivesItsButtonLock(){

            var native=New("locked button",typeof(RectTransform),typeof(Image),typeof(Button),typeof(UIButtonLock)).GetComponent<Button>();var buttonLock=native.GetComponent<UIButtonLock>();

            var label=New("locked price",typeof(RectTransform)).AddComponent<PriceBtn>();Set(label,"priceText",Text());Set(label,"button",native);Set(label,"buttonLock",buttonLock);Set(label,"lockedState",UIButtonLockState.SoftLock);

            label.ShowUI(_context,Value(Alpha,10));Assert.That(buttonLock.State,Is.EqualTo(UIButtonLockState.Normal));Assert.That(native.interactable,Is.True);

            label.SetInputAllowed(false);yield return DrawFrame();

            Assert.That(buttonLock.State,Is.EqualTo(UIButtonLockState.SoftLock));Assert.That(native.interactable,Is.False);

        }

        [UnityTest]
        public IEnumerator CommittedLongQuantityDefersDrawAndUsesRealTmpGeometry()
        {
            var label=Resource(out var text);Assert.That(text.text,Is.EqualTo("100"));
            Grant(_context.Resources,Alpha,1234567890123L);
            Assert.That(Dirty(label),Is.True);Assert.That(text.text,Is.EqualTo("100"));
            yield return DrawFrame();Assert.That(label.Quantity,Is.EqualTo(1234567890223L));Assert.That(text.text,Is.EqualTo("1,234,567,890,223"));
            text.ForceMeshUpdate();Assert.That(text.textInfo.characterCount,Is.GreaterThan(0));
        }
        [UnityTest]
        public IEnumerator DifferentCurrencyProfileAndOldRepositoryAreFiltered()
        {
            var label=Resource(out _);Grant(_context.Resources,Beta,1);Assert.That(Dirty(label),Is.False);
            var other=OpenContainer(PrefsFixture.Create("device:other", _root, _codec));
            Grant(other,Alpha,10);Assert.That(Dirty(label),Is.False);
            var old=_context.Resources;
            var late=(Action<ResourceChange>)typeof(ResourceService).GetField("Changed",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(old);
            BindPrimary(_repository);label.Refresh();
            var payload=(ResourceChange)Activator.CreateInstance(typeof(ResourceChange),BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{old,10L,10L,new[]{Alpha},true,true},null);
            late?.Invoke(payload);
            Assert.That(Dirty(label),Is.False);yield return null;
        }
        [UnityTest]
        public IEnumerator RepeatedEnableDisableHasExactlyOneTypedSubscriptionAndRefreshesOnReopen()
        {
            var label=Resource(out var text);
            int Count()=>((Delegate)typeof(ResourceService).GetField("Changed",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(_context.Resources))?.GetInvocationList().Length??0;
            int active=Count();
            for(int i=0;i<12;i++){label.ShowUI(_context,Alpha);Assert.That(Count(),Is.EqualTo(active));label.HideUI();Assert.That(Count(),Is.EqualTo(active-1));}
            Grant(_context.Resources,Alpha,5);Assert.That(text.text,Is.EqualTo("100"));
            label.ShowUI(_context,Alpha);Assert.That(text.text,Is.EqualTo("105"));yield return null;
        }
        [UnityTest]
        public IEnumerator PriceAndNativeButtonFollowAffordabilityAfterCommit()
        {
            var native=New("button",typeof(RectTransform),typeof(Image),typeof(Button)).GetComponent<Button>();
            var label=New("price button",typeof(RectTransform)).AddComponent<PriceBtn>();var text=Text();
            Set(label,"priceText",text);Set(label,"button",native);
            label.ShowUI(_context,Value(Alpha,10));Assert.That(label.CanAfford,Is.True);Assert.That(native.interactable,Is.True);
            LocalRewardService.Commit(_storage,_context.Resources,LocalRewardService.PrepareMutation(_storage,_context.Resources,new[]{Value(Alpha,95)},Array.Empty<ConsumeData>()));
            Assert.That(native.interactable,Is.True);yield return DrawFrame();
            Assert.That(label.Required,Is.EqualTo(10));Assert.That(label.CanAfford,Is.False);Assert.That(native.interactable,Is.False);
        }
        [UnityTest]
        public IEnumerator PlayerPrefsFailureKeepsDisplayAndBalanceAndRequiresNewBasis()
        {
            bool fail = true;
            var repository = PrefsFixture.Create("device:step11-ui", _root, _codec, (key, value) => { if (fail) throw new IOException("synthetic PlayerPrefs failure"); PlayerPrefs.SetString(key, value); });
            BindPrimary(repository); var label = Resource(out var text);
            var preparation = LocalRewardService.PrepareMutation(_storage, _context.Resources, Array.Empty<ConsumeData>(), new[] { Value(Alpha, 7) });
            Assert.Throws<LocalSaveWriteException>(() => LocalRewardService.Commit(_storage, _context.Resources, preparation));
            Assert.That(Dirty(label), Is.False); Assert.That(_context.Resources.Get(Alpha), Is.EqualTo(100)); yield return DrawFrame(); Assert.That(text.text, Is.EqualTo("100"));
            Assert.Throws<RepositoryRecoveryRequiredException>(() => LocalRewardService.Commit(_storage, _context.Resources, preparation));
            fail = false; BindPrimary(PrefsFixture.Create("device:step11-ui", _root, _codec));
            Assert.Throws<LocalSaveConflictException>(() => LocalRewardService.Commit(_storage, _context.Resources, preparation)); Grant(_context.Resources, Alpha, 7); label.Refresh(); yield return DrawFrame(); Assert.That(text.text, Is.EqualTo("107"));
        }
        [UnityTest]
        public IEnumerator LocaleBridgeMarksDirtyAndReformatsWithoutChangingSavedValue()
        {
            var label=Resource(out var text);Grant(_context.Resources,Alpha,1134);yield return DrawFrame();Assert.That(text.text,Is.EqualTo("1,234"));
            long revision=_storage.SavedRevision;
            UIRuntimeOptions.Culture=()=>CultureInfo.GetCultureInfo("de-DE");UIRuntimeOptions.NotifyLocaleChanged();Assert.That(Dirty(label),Is.True);
            yield return DrawFrame();Assert.That(text.text,Is.EqualTo("1.234"));Assert.That(_storage.SavedRevision,Is.EqualTo(revision));
        }
        [UnityTest]
        public IEnumerator MissingUnknownNegativeRandomAndOverflowPricesAreNotAffordable()
        {
            var label=Price(out var text);
            foreach(var price in new ConsumeData[]{null,Value(999,1),Value(Alpha,-1),new(new ConsumeTypeId(9001),Alpha,1),new(Kind,Alpha,1,3)})
            { label.ShowUI(_context,price);Assert.That(label.CanAfford,Is.False);Assert.That(text.text,Is.Empty); }
            label.ShowUI(_context,Value(Alpha,3000000000));Assert.That(label.Required,Is.EqualTo(3000000000));Assert.That(text.text,Is.EqualTo("3,000,000,000"));
            var products=new Prices{Price=Value(Alpha,long.MaxValue)};_context.SetProductPrices(products);label.ShowProduct(_context,7,2);Assert.That(label.CanAfford,Is.False);Assert.That(label.HasData,Is.False);
            yield return null;
        }
        [UnityTest]
        public IEnumerator ProductPriceAdapterKeepsDisplayApiWithoutImportingPurchasePolicies()
        {
            var label=Price(out var text);Assert.Throws<InvalidOperationException>(()=>label.ShowProduct(_context,7));
            var prices=new Prices{Price=Value(Alpha,3)};_context.SetProductPrices(prices);label.ShowProduct(_context,7,2);
            Assert.That(label.Required,Is.EqualTo(6));Assert.That(label.CanAfford,Is.True);
            prices.Price=Value(Alpha,75);prices.Signal(7);yield return DrawFrame();Assert.That(label.Required,Is.EqualTo(150));Assert.That(label.CanAfford,Is.False);
            var next=New("second context").AddComponent<LocalEconomyUIContext>();next.Bind(_context.Resources);var other=new Prices{Price=Value(Alpha,2)};next.SetProductPrices(other);
            label.ShowProduct(next,7);Assert.That(label.Required,Is.EqualTo(2));prices.Signal(7);Assert.That(Dirty(label),Is.False);
            other.Signal(7);Assert.That(Dirty(label),Is.True);yield return DrawFrame();Assert.That(text.text,Is.EqualTo("2"));
        }
        [UnityTest]
        public IEnumerator ContextArgumentFailureAndWorkerCallsCannotPartiallySwitchBinding()
        {
            string identity=_context.Identity;var source=_context.Resources;
            Assert.Throws<ArgumentNullException>(()=>_context.Bind((ResourceService)null));
            Assert.That(_context.Identity,Is.EqualTo(identity));Assert.That(_context.Resources,Is.SameAs(source));
            Assert.Throws<InvalidOperationException>(()=>Task.Run(()=>_context.Bind(_context.Resources)).GetAwaiter().GetResult());yield return null;
        }
        private sealed class Prices:IProductPriceSource
        {public ConsumeData Price;public ConsumeData GetPrice(int id)=>Price;public event Action<int> Changed;public void Signal(int id)=>Changed?.Invoke(id);}
        private sealed class Source:ITableSource
        {
            public bool RequiresRemoteUpdate=>false;public bool HasTable(string name)=>true;
            public List<TSVRow> Load(string name)=>TSVRow.FromTsv("id\ttype\tactive\n31001001\talpha\t1\n31001002\tbeta\t1");
            public Task<List<TSVRow>> LoadAsync(string name)=>Task.FromResult(Load(name));
        }
    }
}
