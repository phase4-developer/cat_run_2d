using JJEvol.Save.Testing;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using jjevol.UI;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace jjevol.UI.Tests
{
    [PrebuildSetup("jjevol.UI.Tests.UITestTMPSetup")]
    public sealed class ContainerEconomyUIPlayTests
    {
        private readonly List<GameObject> _objects = new();
        private readonly List<DataRepository> _users = new();
        private readonly ConsumeTypeId _kind = new(812);
        private string _root;
        private Scene _scene, _previous;
        private DataRepository _repository;
        private WealthContainer _wealth;
        private RepositoryStorageAdapter _storage;
        private ResourceService _resources;
        private WealthTable _definitions;
        private LocalSaveRepository _files;
        private readonly LocalSaveCodec _codec = LocalSaveCodec.CreateEncrypted(new LocalSaveEncryption("test-v1", System.Text.Encoding.ASCII.GetBytes("0123456789abcdef0123456789abcdef")));
        private LocalEconomyUIContext _context;
        private TMP_Settings _prior, _settings;
        private TMP_FontAsset _font;
        private Canvas _canvas;
        private bool _failWrite;
        private int _writes;
        [SetUp]
        public void SetUp()
        {
            _failWrite = false; _writes = 0;
            _root = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolContainerUITests", Guid.NewGuid().ToString("N")));
            _previous = SceneManager.GetActiveScene(); _scene = SceneManager.CreateScene("ContainerEconomyUI-" + Guid.NewGuid().ToString("N")); SceneManager.SetActiveScene(_scene);
            _definitions = new WealthTable("synthetic-ui"); _definitions.LoadDatas(new Source());
            string profile = "ui04:" + Guid.NewGuid().ToString("N");
            _repository = new DataRepository(profile); _users.Add(_repository); _wealth = new WealthContainer(); _repository.Register(_wealth);
            _files = PrefsFixture.Create(profile, _root, _codec, (key, value) => { _writes++; if (_failWrite) throw new IOException("synthetic UI PlayerPrefs failure"); PlayerPrefs.SetString(key, value); });
            _storage = RepositoryStorageAdapter.Open(_repository, _files, "synthetic:ui:v1", RepositoryStorageMode.LocalAuthority, () => Data(1000));
            _resources = new ResourceService(_repository, _definitions, _kind);
            _context = New("optional non-owning connector").AddComponent<LocalEconomyUIContext>(); _context.Bind(_resources);
            UIRuntimeOptions.Culture = () => CultureInfo.GetCultureInfo("en-US");
            var field = typeof(TMP_Settings).GetField("s_Instance", BindingFlags.Static | BindingFlags.NonPublic); _prior = (TMP_Settings)field.GetValue(null);
            _settings = ScriptableObject.CreateInstance<TMP_Settings>(); _font = TMP_FontAsset.CreateFontAsset("Arial", "Regular", 32);
            Assert.That(_font, Is.Not.Null);
            typeof(TMP_Settings).GetField("m_defaultFontAsset", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(_settings, _font); field.SetValue(null, _settings);
            _canvas = New("actual Canvas", typeof(RectTransform), typeof(Canvas)).GetComponent<Canvas>(); _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            PrefsFixture.Cleanup(); for (int i = _objects.Count - 1; i >= 0; i--) if (_objects[i]) Object.Destroy(_objects[i]); _objects.Clear(); yield return null;
            foreach (var user in _users) user.Dispose(); _users.Clear();
            typeof(TMP_Settings).GetField("s_Instance", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, _prior);
            if (_font) { if (_font.material) Object.Destroy(_font.material); foreach (var texture in _font.atlasTextures) if (texture) Object.Destroy(texture); Object.Destroy(_font); } Object.Destroy(_settings);
            UIRuntimeOptions.Culture = null;
            if (_previous.IsValid() && _previous.isLoaded) SceneManager.SetActiveScene(_previous);
            if (_scene.IsValid() && _scene.isLoaded) yield return SceneManager.UnloadSceneAsync(_scene);
            string parent = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "JJEvolContainerUITests")) + Path.DirectorySeparatorChar;
            if (!_root.StartsWith(parent, StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Unsafe synthetic UI save cleanup");
            if (Directory.Exists(_root)) Directory.Delete(_root, true);
        }
        private GameObject New(string name, params Type[] components)
        { var obj = new GameObject(name, components); SceneManager.MoveGameObjectToScene(obj, _scene); _objects.Add(obj); return obj; }
        private TextMeshProUGUI Text(string name = "actual TMP")
        {
            var obj = New(name, typeof(RectTransform)); obj.transform.SetParent(_canvas.transform, false); var rect = (RectTransform)obj.transform; rect.sizeDelta = new Vector2(1100, 100);
            var text = obj.AddComponent<TextMeshProUGUI>(); text.fontSize = 30; text.color = Color.white; return text;
        }
        private static void Set(object obj, string field, object value)
        { for (Type type = obj.GetType(); type != null; type = type.BaseType) { var info = type.GetField(field, BindingFlags.Instance | BindingFlags.NonPublic); if (info != null) { info.SetValue(obj, value); return; } } throw new MissingFieldException(field); }
        private static bool Dirty(UIBase label) => (bool)typeof(UIBase).GetField("mDirty", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(label);
        private static IEnumerator Frame() { yield return null; yield return null; }
        private static JObject Data(long alpha, long beta = 400) => new() { ["wealthInfos"] = new JArray(new JObject { ["wealthType"] = "alpha", ["quantity"] = alpha }, new JObject { ["wealthType"] = "beta", ["quantity"] = beta }) };
        private ConsumeData Cost(long quantity, int id = 11) => new(_kind, id, quantity);
        private ResourceLabel Label(out TextMeshProUGUI text, ResourceQuantityView view = ResourceQuantityView.Available)
        {
            text = Text(); var label = New("resource binding", typeof(RectTransform)).AddComponent<ResourceLabel>(); label.transform.SetParent(_canvas.transform, false); Set(label, "quantityText", text);
            label.ShowUI(_resources, _kind, 11, view); return label;
        }
        private PriceBtn PriceButton(out TextMeshProUGUI text, out Button native, long required = 900)
        {
            native = New("native Button", typeof(RectTransform), typeof(Image), typeof(Button)).GetComponent<Button>(); native.transform.SetParent(_canvas.transform, false);
            var label = native.gameObject.AddComponent<PriceBtn>(); text = Text(); Set(label, "priceText", text); Set(label, "button", native); label.ShowUI(_resources, Cost(required)); return label;
        }
        private void Commit(long cost, long reward)
        { var p = LocalRewardService.PrepareMutation(_storage, _resources, new[] { Cost(cost) }, new[] { Cost(reward) }); LocalRewardService.Commit(_storage, _resources, p); }
        private static int Subscriptions(ResourceService source, object target = null)
        { var list = ((Delegate)typeof(ResourceService).GetField("Changed", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(source))?.GetInvocationList(); return list?.Count(value => target == null || ReferenceEquals(value.Target, target)) ?? 0; }

        [UnityTest]
        public IEnumerator InitialBindingAndPendingCancelUseSameContainerAndOnlyInstanceEvents()
        {
            int subscribers = Subscriptions(_resources), writes = _writes;
            var label = Label(out var text); var confirmed = Label(out var rawText, ResourceQuantityView.Confirmed);
            Assert.That(Subscriptions(_resources), Is.EqualTo(subscribers + 2));
            Assert.That(text.text, Is.EqualTo("1,000")); Assert.That(label.Resources.Container, Is.SameAs(_wealth));
            _resources.Reserve(new[] { Cost(100) }); Assert.That(Dirty(label), Is.True); Assert.That(Dirty(confirmed), Is.False); Assert.That(text.text, Is.EqualTo("1,000"));
            yield return Frame(); Assert.That(text.text, Is.EqualTo("900")); Assert.That(rawText.text, Is.EqualTo("1,000"));
            _resources.Reserve(new[] { Cost(50) }); yield return Frame(); Assert.That(label.Quantity, Is.EqualTo(850));
            _resources.CancelPending(); yield return Frame(); Assert.That(text.text, Is.EqualTo("1,000"));
            Assert.That(_resources.GetRaw(11), Is.EqualTo(1000)); Assert.That(_writes, Is.EqualTo(writes)); Assert.That(Subscriptions(_resources), Is.EqualTo(subscribers + 2));
        }
        [UnityTest]
        public IEnumerator MockAuthoritativeResponseExposesOnlyFinal850DuringAllNotifications()
        {
            var label = Label(out var text); var raw = Label(out var rawText, ResourceQuantityView.Confirmed);
            _resources.Reserve(new[] { Cost(100) }); var request = _resources.BeginRequest(); _resources.Reserve(new[] { Cost(50) }); yield return Frame();
            Assert.That(text.text, Is.EqualTo("850")); int notices = 0;
            Action check = () => { notices++; Assert.That(_resources.Get(11), Is.EqualTo(850)); Assert.That(_resources.GetRaw(11), Is.EqualTo(900)); label.Refresh(); Assert.That(text.text, Is.EqualTo("850")); };
            _wealth.Changed += _ => check(); _repository.Changed += _ => check(); _resources.Changed += _ => check();
            _resources.ApplyServerResponse(request, Data(900), false, "wealthInfos"); Assert.That(notices, Is.EqualTo(3)); yield return Frame();
            Assert.That(text.text, Is.EqualTo("850")); Assert.That(rawText.text, Is.EqualTo("900")); Assert.That(_storage.IsDirty, Is.True);
        }
        [UnityTest]
        public IEnumerator DurableCostRewardReloadAndNativeButtonUseGameOwnedCommit()
        {
            var label = Label(out var text); var price = PriceButton(out _, out var button, 200);
            var eventSystem = New("synthetic pointer EventSystem").AddComponent<EventSystem>(); int clicks = 0;
            button.onClick.AddListener(() => { clicks++; Commit(200, 50); });
            _resources.Reserve(new[] { Cost(900) }); yield return Frame(); Assert.That(button.interactable, Is.False);
            var pointer = new PointerEventData(eventSystem) { button = PointerEventData.InputButton.Left };
            ExecuteEvents.Execute(button.gameObject, pointer, ExecuteEvents.pointerClickHandler); Assert.That(clicks, Is.Zero);
            _resources.CancelPending(); yield return Frame(); ExecuteEvents.Execute(button.gameObject, pointer, ExecuteEvents.pointerClickHandler);
            Assert.That(clicks, Is.EqualTo(1)); Assert.That(_resources.GetRaw(11), Is.EqualTo(850)); Assert.That(text.text, Is.EqualTo("1,000"));
            yield return Frame(); Assert.That(text.text, Is.EqualTo("850")); Assert.That(_files.Load().Document.Snapshot.Payload["wealthInfos"][0].Value<long>("quantity"), Is.EqualTo(850));
            _storage.Reload(); yield return Frame(); Assert.That(label.Quantity, Is.EqualTo(850)); Assert.That(price.CanAfford, Is.True);
        }
        [UnityTest]
        public IEnumerator FailedSaveNeverShowsAnUnconfirmedRewardOrAutomaticallyRetries()
        {
            var label = Label(out var text); _failWrite = true; int writes = _writes;
            Assert.Throws<LocalSaveWriteException>(() => Commit(0, 50)); Assert.That(Dirty(label), Is.False); yield return Frame(); yield return Frame();
            Assert.That(text.text, Is.EqualTo("1,000")); Assert.That(_writes, Is.EqualTo(writes + 1)); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
            _failWrite = false; Assert.Throws<RepositoryRecoveryRequiredException>(() => Commit(0, 50));
            Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.RecoveryRequired));
            yield return Frame(); Assert.That(text.text, Is.EqualTo("1,000")); Assert.That(_writes, Is.EqualTo(writes + 1));
        }
        [UnityTest]
        public IEnumerator PriceChangesReservationsAndMalformedCostsHaveDistinctDisplayContracts()
        {
            var label = PriceButton(out var text, out var button);
            Assert.That(label.CanAfford, Is.True); _resources.Reserve(new[] { Cost(150) }); yield return Frame(); Assert.That(button.interactable, Is.False);
            foreach (ConsumeData invalid in new[] { (ConsumeData)null, Cost(-1), new ConsumeData(_kind, 11, 1, 2), new ConsumeData(new ConsumeTypeId(1), 11, 1), Cost(1, 999) })
            { label.ShowUI(_resources, invalid); Assert.That(label.HasData, Is.False); Assert.That(text.text, Is.Empty); Assert.That(button.interactable, Is.False); }
            label.ShowUI(_resources, Cost(0)); Assert.That(label.IsFree, Is.False); Assert.That(label.Required, Is.Zero); Assert.That(button.interactable, Is.True);
            label.ShowFree(_resources, "FREE OFFER"); Assert.That(label.IsFree, Is.True); Assert.That(text.text, Is.EqualTo("FREE OFFER"));
            Assert.Throws<ArgumentException>(() => label.ShowCosts(_resources, Array.Empty<ConsumeData>()));
        }
        [UnityTest]
        public IEnumerator MultipleCostsAggregateDuplicatesAndCheckEachResourceWithoutSummingCurrencies()
        {
            var price = PriceButton(out var text, out var button); var display = new Presentation();
            price.ShowCosts(_resources, new[] { Cost(300), Cost(300), Cost(200, 22) }, display);
            Assert.That(price.CanAfford, Is.True); Assert.That(price.Required, Is.Zero); Assert.That(text.text, Is.EqualTo("Gold: 600\nTokens: 200"));
            _resources.Reserve(new[] { Cost(250, 22) }); yield return Frame(); Assert.That(button.interactable, Is.False);
            price.ShowCosts(_resources, new[] { Cost(long.MaxValue), Cost(1) }); Assert.That(price.HasData, Is.False);
        }
        [UnityTest]
        public IEnumerator ProductDefinitionAndLocaleChangesUseTheSameResourcesAndPresentation()
        {
            var price = PriceButton(out var text, out var button); var source = new Prices { Price = Cost(500) };
            _context.SetProductPrices(source); price.ShowProduct(_context, 7, 2); Assert.That(text.text, Is.EqualTo("1,000"));
            source.Price = Cost(501); source.Signal(7); yield return Frame(); Assert.That(button.interactable, Is.False); Assert.That(text.text, Is.EqualTo("1,002"));
            UIRuntimeOptions.Culture = () => CultureInfo.GetCultureInfo("de-DE"); UIRuntimeOptions.NotifyLocaleChanged(); yield return Frame(); Assert.That(text.text, Is.EqualTo("1.002"));
            source.Price = Cost(long.MaxValue); source.Signal(7); yield return Frame(); Assert.That(price.HasData, Is.False);
        }
        [UnityTest]
        public IEnumerator OtherItemsProfilesAndLateCapturedDelegatesCannotRefreshReboundUi()
        {
            var label = Label(out var text); label.ShowUI(_context, 11);
            _repository.UpdateJson(Data(1000, 450), "wealthInfos"); Assert.That(Dirty(label), Is.False);
            var late = (Action<ResourceChange>)typeof(ResourceService).GetField("Changed", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(_resources);
            var next = new DataRepository("ui04:" + Guid.NewGuid().ToString("N")); _users.Add(next); var wealth = new WealthContainer(); next.Register(wealth); wealth.ImportJson(Data(300));
            var service = new ResourceService(next, _definitions, _kind); _context.Bind(service); yield return Frame(); Assert.That(text.text, Is.EqualTo("300"));
            var oldNotice = (ResourceChange)Activator.CreateInstance(typeof(ResourceChange), BindingFlags.Instance | BindingFlags.NonPublic, null, new object[] { _resources, 99L, _repository.Revision, new[] { 11 }, true, true }, null);
            late?.Invoke(oldNotice); Assert.That(Dirty(label), Is.False); Assert.That(Subscriptions(_resources, label), Is.Zero); Assert.That(Subscriptions(service, label), Is.EqualTo(1));
        }
        [UnityTest]
        public IEnumerator EnableDisableDestroyAndServiceDisposalRespectUserLifetime()
        {
            var label = Label(out var text);
            for (int i = 0; i < 10; i++) { label.ShowUI(_resources, _kind, 11); Assert.That(Subscriptions(_resources, label), Is.EqualTo(1)); label.HideUI(); Assert.That(Subscriptions(_resources, label), Is.Zero); }
            Commit(0, 25); label.ShowUI(_resources, _kind, 11); Assert.That(text.text, Is.EqualTo("1,025"));
            var lateResource = (Action<ResourceChange>)typeof(ResourceService).GetField("Changed", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(_resources);
            var lateLocale = (Action)typeof(UIRuntimeOptions).GetField("LocaleChanged", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null);
            Object.Destroy(label.gameObject); yield return null; Assert.That(Subscriptions(_resources), Is.Zero); Assert.That(_repository.IsDisposed, Is.False);
            var notice = (ResourceChange)Activator.CreateInstance(typeof(ResourceChange), BindingFlags.Instance | BindingFlags.NonPublic, null, new object[] { _resources, 1L, _repository.Revision, new[] { 11 }, true, true }, null);
            Assert.DoesNotThrow(() => lateResource?.Invoke(notice)); Assert.DoesNotThrow(() => lateLocale?.Invoke());
            var next = Label(out var nextText); _repository.Dispose(); yield return Frame(); yield return Frame();
            Assert.That(next.HasData, Is.False); Assert.That(nextText.text, Is.Empty);
        }
        [UnityTest]
        public IEnumerator ObserverExceptionsAndContextProductExceptionsDoNotSkipUiInvalidation()
        {
            _resources.Changed += _ => throw new InvalidOperationException("UI resource observer fault"); var label = Label(out var text);
            LogAssert.Expect(LogType.Exception, new Regex("UI resource observer fault")); Commit(200, 50); yield return Frame(); Assert.That(text.text, Is.EqualTo("850"));
            var source = new Prices { Price = Cost(500) }; _context.SetProductPrices(source); _context.ProductPriceChanged += _ => throw new InvalidOperationException("UI product observer fault");
            var price = PriceButton(out _, out var native); price.ShowProduct(_context, 7);
            LogAssert.Expect(LogType.Exception, new Regex("UI product observer fault")); source.Price = Cost(900); source.Signal(7); yield return Frame(); Assert.That(native.interactable, Is.False);
        }
        [UnityTest]
        public IEnumerator ReadyDirtyConflictAndRecoveryAreControlledByGameNotPriceLabel()
        {
            var label = Label(out var text); var price = PriceButton(out _, out var button, 10);
            void Gate() => price.SetInputAllowed(_storage.Status == RepositoryStorageStatus.Ready && !_storage.IsDirty);
            Gate(); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Ready));
            _wealth.UpdateJson(Data(950)); Gate(); yield return Frame(); Assert.That(_storage.IsDirty, Is.True); Assert.That(button.interactable, Is.False); Assert.That(text.text, Is.EqualTo("950"));
            _storage.Save(); Gate(); yield return Frame(); Assert.That(button.interactable, Is.True);
            var basis = _files.Load().Document; var changed = basis.Snapshot.Payload; changed["wealthInfos"][0]["quantity"] = 900; _files.Save(new LocalSaveSnapshot(changed), basis);
            Assert.Throws<LocalSaveConflictException>(() => Commit(1, 0)); Gate(); yield return Frame(); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.Conflict)); Assert.That(button.interactable, Is.False);
            _storage.Reload(); Gate(); yield return Frame(); Assert.That(text.text, Is.EqualTo("900")); Assert.That(button.interactable, Is.True);
            typeof(RepositoryStorageAdapter).GetField("_failNextApplyForTesting", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(_storage, true);
            Assert.Throws<RepositoryRecoveryRequiredException>(() => Commit(100, 0)); Gate(); yield return Frame(); Assert.That(_storage.Status, Is.EqualTo(RepositoryStorageStatus.RecoveryRequired)); Assert.That(text.text, Is.EqualTo("900"));
            Assert.That(button.interactable, Is.False); _storage.Reload(); Gate(); yield return Frame(); Assert.That(text.text, Is.EqualTo("800"));
        }
        [UnityTest]
        public IEnumerator NumberAnimatorKeepsLongEndpointsAndLocaleAndLayoutSettings()
        {
            var label = Label(out var text); var animator = text.gameObject.AddComponent<NumberAnimator>(); animator.CurrentPrintType = NumberAnimator.PrintType.Number; animator.AnimationDuration = .02f;
            Set(label, "number", animator); Set(label, "animateChanges", true); label.Refresh();
            RectTransform rect = text.rectTransform; Vector2 size = rect.sizeDelta, pivot = rect.pivot, min = rect.anchorMin, max = rect.anchorMax;
            _storage.ApplyAndSave(Data(long.MaxValue), true, "wealthInfos"); yield return Frame();
            Assert.That(animator.TargetValue, Is.EqualTo((decimal)long.MaxValue)); float until = Time.realtimeSinceStartup + 3;
            while (animator.IsAnimating && Time.realtimeSinceStartup < until) yield return null;
            Assert.That(animator.IsAnimating, Is.False);
            Assert.That(animator.CurrentValue, Is.EqualTo((decimal)long.MaxValue)); Assert.That(text.text, Is.EqualTo("9,223,372,036,854,775,807"));
            UIRuntimeOptions.Culture = () => CultureInfo.GetCultureInfo("de-DE"); UIRuntimeOptions.NotifyLocaleChanged(); yield return Frame(); Assert.That(text.text, Is.EqualTo("9.223.372.036.854.775.807"));
            _storage.ApplyAndSave(Data(0), true, "wealthInfos"); yield return Frame(); until = Time.realtimeSinceStartup + 3;
            while (animator.IsAnimating && Time.realtimeSinceStartup < until) yield return null;
            Assert.That(animator.IsAnimating, Is.False);
            Assert.That(animator.CurrentValue, Is.Zero); Assert.That(rect.sizeDelta, Is.EqualTo(size)); Assert.That(rect.pivot, Is.EqualTo(pivot)); Assert.That(rect.anchorMin, Is.EqualTo(min)); Assert.That(rect.anchorMax, Is.EqualTo(max));
        }
        [UnityTest]
        public IEnumerator UnsupportedResourceKindNeverAliasesWealthOrRespondsToItsEvents()
        {
            var label = Label(out var text); label.ShowUI(_resources, new ConsumeTypeId(1), 11);
            Assert.That(label.HasData, Is.False); Assert.That(text.text, Is.Empty);
            _resources.Reserve(new[] { Cost(100) }); Assert.That(Dirty(label), Is.False);
            Assert.Throws<ArgumentOutOfRangeException>(() => label.ShowUI(_resources, _kind, 11, (ResourceQuantityView)99));
            yield return Frame(); Assert.That(text.text, Is.Empty);
        }
        [UnityTest]
        public IEnumerator SymbolicFormatterAlsoUsesTheConfiguredDisplayCulture()
        {
            _storage.ApplyAndSave(Data(1234567), true, "wealthInfos");
            var label = Label(out var text); var animator = text.gameObject.AddComponent<NumberAnimator>(); animator.CurrentPrintType = NumberAnimator.PrintType.Number; animator.UseSymbolic = true;
            Set(label, "number", animator); label.Refresh(); Assert.That(text.text, Is.EqualTo("1,234K"));
            long revision = _storage.SavedRevision;
            UIRuntimeOptions.Culture = () => CultureInfo.GetCultureInfo("de-DE"); UIRuntimeOptions.NotifyLocaleChanged(); yield return Frame();
            Assert.That(text.text, Is.EqualTo("1.234K")); Assert.That(_storage.SavedRevision, Is.EqualTo(revision));
        }
        [UnityTest]
        public IEnumerator EmptyConnectorAndInvalidRebindCannotConstructOrReplaceGameState()
        {
            int writes = _writes; var empty = New("unbound connector").AddComponent<LocalEconomyUIContext>();
            var label = Label(out var text); label.ShowUI(empty, 11);
            Assert.That(empty.IsBound, Is.False); Assert.That(empty.Resources, Is.Null); Assert.That(label.HasData, Is.False); Assert.That(text.text, Is.Empty);
            label.ShowUI(_context, 11); var temporary = new DataRepository("ui04:" + Guid.NewGuid().ToString("N")); var wealth = new WealthContainer(); temporary.Register(wealth); var dead = new ResourceService(temporary, _definitions, _kind); temporary.Dispose();
            Assert.Throws<ObjectDisposedException>(() => _context.Bind(dead)); Assert.That(_context.Resources, Is.SameAs(_resources));
            yield return Frame(); Assert.That(text.text, Is.EqualTo("1,000")); Assert.That(_writes, Is.EqualTo(writes));
        }
        [UnityTest]
        public IEnumerator DirectProductSubscriptionsDetachOnSwitchDisableAndDispose()
        {
            var price = PriceButton(out _, out _); var first = new Prices { Price = Cost(10) }; var next = new Prices { Price = Cost(20) };
            price.ShowProduct(_resources, first, 7); Assert.That(first.Listeners, Is.EqualTo(1)); var late = first.Snapshot;
            price.ShowProduct(_resources, next, 7); Assert.That(first.Listeners, Is.Zero); Assert.That(next.Listeners, Is.EqualTo(1));
            late?.Invoke(7); Assert.That(Dirty(price), Is.False);
            price.HideUI(); Assert.That(next.Listeners, Is.Zero); price.ShowProduct(_resources, next, 7); Assert.That(next.Listeners, Is.EqualTo(1));
            _repository.Dispose(); yield return Frame(); yield return Frame(); Assert.That(next.Listeners, Is.Zero); Assert.That(price.HasData, Is.False);
        }
        [UnityTest]
        public IEnumerator DestroyingConnectorUnbindsUiWithoutDisposingTheUser()
        {
            var label = Label(out var text); label.ShowUI(_context, 11); var prices = new Prices { Price = Cost(10) }; _context.SetProductPrices(prices);
            Assert.That(prices.Listeners, Is.EqualTo(1)); Object.Destroy(_context.gameObject); yield return Frame();
            Assert.That(prices.Listeners, Is.Zero); Assert.That(label.HasData, Is.False); Assert.That(text.text, Is.Empty); Assert.That(_repository.IsDisposed, Is.False); Assert.That(_resources.GetRaw(11), Is.EqualTo(1000));
        }
        [UnityTest]
        public IEnumerator LateProductAndContextCallbacksCannotDirtyAReboundScreen()
        {
            var first = new Prices { Price = Cost(10) }; _context.SetProductPrices(first); var price = PriceButton(out _, out _); price.ShowProduct(_context, 7);
            var oldProvider = first.Snapshot;
            var oldProduct = (Action<int>)typeof(LocalEconomyUIContext).GetField("ProductPriceChanged", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(_context);
            var oldBinding = (Action)typeof(LocalEconomyUIContext).GetField("BindingChanged", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(_context);
            var next = New("new user connector").AddComponent<LocalEconomyUIContext>(); next.Bind(_resources); var second = new Prices { Price = Cost(20) }; next.SetProductPrices(second);
            price.ShowProduct(next, 7); oldProvider?.Invoke(7); oldProduct?.Invoke(7); oldBinding?.Invoke(); Assert.That(Dirty(price), Is.False);
            var other = new DataRepository("ui04:" + Guid.NewGuid().ToString("N")); _users.Add(other); var wealth = new WealthContainer(); other.Register(wealth); wealth.ImportJson(Data(300));
            _context.Bind(new ResourceService(other, _definitions, _kind)); Assert.That(first.Listeners, Is.Zero); Assert.That(_context.ProductPrices, Is.Null);
            yield return Frame(); Assert.That(price.Required, Is.EqualTo(20));
            next.Unbind(); Assert.That(second.Listeners, Is.Zero);
        }
        [UnityTest]
        public IEnumerator RealCanvasAndTmpRenderAContainerReservationGreybox()
        {
            var camera = New("isolated UI camera", typeof(Camera)).GetComponent<Camera>(); camera.orthographic = true; camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(.04f, .065f, .1f); camera.transform.position = new Vector3(0, 0, -10);
            var target = new RenderTexture(1280, 720, 24); camera.targetTexture = target; _canvas.renderMode = RenderMode.ScreenSpaceCamera; _canvas.worldCamera = camera; _canvas.planeDistance = 1;
            var title = Text("title"); title.text = "CONTAINER ECONOMY / LIVE UNITY UI"; title.fontSize = 32; title.rectTransform.anchoredPosition = new Vector2(0, 260);
            var label = Label(out var available); available.rectTransform.anchoredPosition = new Vector2(0, 130); available.fontSize = 56;
            Label(out var confirmed, ResourceQuantityView.Confirmed); confirmed.rectTransform.anchoredPosition = new Vector2(0, 35); confirmed.fontSize = 34;
            var price = PriceButton(out var costText, out var native, 900); native.GetComponent<RectTransform>().sizeDelta = new Vector2(600, 80); native.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -120); native.GetComponent<Image>().color = new Color(.16f, .23f, .34f);
            costText.transform.SetParent(native.transform, false); costText.rectTransform.anchorMin = Vector2.zero; costText.rectTransform.anchorMax = Vector2.one;
            costText.rectTransform.offsetMin = Vector2.zero; costText.rectTransform.offsetMax = Vector2.zero; costText.alignment = TextAlignmentOptions.Center; costText.fontSize = 34;
            var help = Text("game supplied captions"); help.text = "Available above / Confirmed below\nCost 900 - reserved 150 - input unavailable"; help.fontSize = 24; help.rectTransform.anchoredPosition = new Vector2(0, -260);
            _resources.Reserve(new[] { Cost(150) }); yield return Frame(); Canvas.ForceUpdateCanvases(); available.ForceMeshUpdate(); confirmed.ForceMeshUpdate();
            Assert.That(available.text, Is.EqualTo("850")); Assert.That(confirmed.text, Is.EqualTo("1,000")); Assert.That(native.interactable, Is.False); Assert.That(available.textInfo.meshInfo.Sum(mesh => mesh.vertexCount), Is.GreaterThan(0));
            string artifacts = Environment.GetEnvironmentVariable("JJEvolUIValidationArtifacts"); if (string.IsNullOrWhiteSpace(artifacts)) artifacts = Path.Combine(Application.temporaryCachePath, "JJEvolUIValidationArtifacts"); Directory.CreateDirectory(artifacts);
            camera.Render(); var previous = RenderTexture.active; RenderTexture.active = target; var snapshot = new Texture2D(1280, 720, TextureFormat.RGB24, false); snapshot.ReadPixels(new Rect(0, 0, 1280, 720), 0, 0); snapshot.Apply();
            string path = Path.Combine(artifacts, "container-economy-ui.png"); File.WriteAllBytes(path, snapshot.EncodeToPNG()); RenderTexture.active = previous; camera.targetTexture = null; target.Release(); Object.Destroy(target); Object.Destroy(snapshot);
            TestContext.Out.WriteLine("Unity render: " + path);
        }
        private sealed class Prices : IProductPriceSource
        { public ConsumeData Price; public event Action<int> Changed; public int Listeners => Changed?.GetInvocationList().Length ?? 0; public Action<int> Snapshot => Changed; public ConsumeData GetPrice(int id) => Price; public void Signal(int id) => Changed?.Invoke(id); }
        private sealed class Presentation : IConsumePresentationProvider
        {
            public bool TryResolve(ConsumeTypeId typeId, int itemId, out ConsumePresentation presentation)
            { bool found = typeId == new ConsumeTypeId(812) && (itemId == 11 || itemId == 22); presentation = found ? new(name: itemId == 11 ? "Gold" : "Tokens") : default; return found; }
            public ConsumePresentation Resolve(ConsumeData data) => new(name: data.ItemId == 11 ? "Gold" : "Tokens");
        }
        private sealed class Source : ITableSource
        {
            public bool RequiresRemoteUpdate => false; public bool HasTable(string name) => true;
            public List<TSVRow> Load(string name) => TSVRow.FromTsv("id\ttype\tactive\n11\talpha\t1\n22\tbeta\t1");
            public System.Threading.Tasks.Task<List<TSVRow>> LoadAsync(string name) => System.Threading.Tasks.Task.FromResult(Load(name));
        }
    }
}
