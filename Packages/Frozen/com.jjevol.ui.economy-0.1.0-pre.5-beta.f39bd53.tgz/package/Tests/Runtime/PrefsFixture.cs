using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using jjevol;
using UnityEngine;

namespace JJEvol.Save.Testing
{
    internal static class PrefsFixture
    {
        private static readonly Dictionary<LocalSaveRepository, LocalSaveCodec> Codecs = new Dictionary<LocalSaveRepository, LocalSaveCodec>();
        public static LocalSaveRepository Create(string profile, string scope, LocalSaveCodec codec, Action<string, string> set = null)
        {
            using var hash = SHA256.Create();
            string prefix = "qa." + BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(scope))).Replace("-", "");
            var result = new LocalSaveRepository(profile, codec, prefix, set == null ? null : new Preferences(set));
            Codecs.Add(result, codec); return result;
        }
        private static string Latest(LocalSaveRepository repository)
        {
            string selected = repository.Slot0Key; long revision = -1;
            foreach (string key in new[] { repository.Slot0Key, repository.Slot1Key })
                if (PlayerPrefs.HasKey(key))
                {
                    try { var doc = Codecs[repository].Decode(Convert.FromBase64String(PlayerPrefs.GetString(key)), repository.ProfileId); if (doc.StateRevision > revision) { selected = key; revision = doc.StateRevision; } }
                    catch { return key; } // Preserve damaged bytes for assertions, not fallback.
                }
            return selected;
        }
        public static byte[] Read(LocalSaveRepository repository) => Convert.FromBase64String(PlayerPrefs.GetString(Latest(repository)));
        public static void Write(LocalSaveRepository repository, byte[] bytes) => PlayerPrefs.SetString(Latest(repository), Convert.ToBase64String(bytes));
        public static void Cleanup()
        {
            foreach (var repository in Codecs.Keys) { PlayerPrefs.DeleteKey(repository.Slot0Key); PlayerPrefs.DeleteKey(repository.Slot1Key); }
            Codecs.Clear(); PlayerPrefs.Save();
        }
        private sealed class Preferences : ILocalSavePreferences
        {
            private readonly Action<string, string> _set;
            public Preferences(Action<string, string> set) { _set = set; }
            public bool HasKey(string key) => PlayerPrefs.HasKey(key);
            public string GetString(string key) => PlayerPrefs.GetString(key);
            public void SetString(string key, string value) => _set(key, value);
            public void Save() => PlayerPrefs.Save();
        }
    }
}