// Explicit setup for the isolated STEP 05-E Host, never a product import/build hook.
using System;
using System.IO;
using jjevol;
using jjevol.Tables.Authoring.Tests;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.Localization;
using UnityEditor.U2D;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.TestTools;
using UnityEngine.U2D;
using Object = UnityEngine.Object;

namespace Step05E.Editor
{
    public sealed class PresentationFixtureSetup : IPrebuildSetup
    {
        private const string Root = "Assets/Step05EFixture";
        private const string Output = "Assets/Step05E/Resources/Step05E";
        public void Setup()
        {
            Guard();
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            if (!settings || !(settings.DataBuilders[settings.ActivePlayModeDataBuilderIndex] is BuildScriptPackedPlayMode)) throw new InvalidOperationException("Build the actual packed fixture before these tests.");
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "{UnityEngine.AddressableAssets.Addressables.RuntimePath}/settings.json");
        }
        private static void Guard()
        {
            if (!Path.GetFullPath(Application.dataPath).Replace('\\', '/').EndsWith("/.local/step05e-validation/Host/Assets", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Only the isolated STEP 05-E Host may author these fixtures.");
        }
        public static void TablesAndExit()
        {
            try
            {
                Guard();
                const string input = "Step05EInputs";
                if (Directory.Exists(input)) throw new InvalidOperationException("Preserve an existing fixture build.");
                Directory.CreateDirectory(input);
                File.WriteAllText(input + "/ConsumeTypes.tsv", "typeId\tcodeName\n137\tWealth\n-29\tItem\n0\tLore");
                File.WriteAllText(input + "/wealth.tsv", "id\ttype\tactive\ticon\tnameKey\tdescriptionKey\tgrade\n41\tcoins\t1\tcoin\twealth41\twealth41\t2");
                File.WriteAllText(input + "/item.tsv", "id\ticon\tatlas\tnameKey\tdescriptionKey\tgrade\n41\tpotion\tStep05E/ItemAtlas\titem41\titem41\t4\n42\t\t\tempty42\tempty42\t0");
                TableAuthoringOptions.EncryptBytes = LegacyFixture.Encrypt; TableRuntimeOptions.DecryptBytes = LegacyFixture.Decrypt;
                TableAuthoringOptions.CodecProfileVersion = "step05e-synthetic-legacy-1";
                TableAuthoringOptions.ValidationVersion = "step05e-game-schema-1";
                TableAuthoringOptions.ValidateTables = tables => { foreach (var table in tables) for (int i = 0; i < table.Document.Records.Count; i++)
                    if (table.TableName != "ConsumeTypes") { _ = checked((int)table.RequireInt64(i, "id")); _ = checked((int)table.RequireInt64(i, "grade")); } };
                var request = new TableBuildRequest(TableBuilder.ReadDirectory(input), Output, true, requireValidator: true,
                    catalogDirectory: input, consumeTypes: new ConsumeTypesGenerationSettings("Assets/Step05E/Game/Generated", "Step05E.Game", "GameConsumeType"));
                var plan = TableBuilder.Plan(request);
                if (!plan.IsValid) throw new InvalidDataException(string.Join("\n", plan.Diagnostics));
                var result = TableBuilder.Prepare(plan).Apply(); Debug.Log("[STEP05E] Combined tables/code: " + result.State);
                AssetDatabase.Refresh(); EditorApplication.Exit(0);
            }
            catch (Exception e) { Debug.LogException(e); EditorApplication.Exit(1); }
        }
        public static void PackAndExit()
        {
            try
            {
                Guard();
                if (TableBuilder.VerifyCompiledGeneration(Output).State != TableBuildState.Ready) throw new InvalidOperationException("Actual generated enum is not Ready.");
                if (Directory.Exists(Root)) throw new InvalidOperationException("Preserve previous packed fixture evidence.");
                Directory.CreateDirectory(Root + "/Tables"); AssetDatabase.Refresh();
                var settings = AddressableAssetSettings.Create(Root + "/Addressables", "Settings", true, true);
                AddressableAssetSettingsDefaultObject.Settings = settings;
                EditorSettings.spritePackerMode = SpritePackerMode.SpriteAtlasV2;
                Atlas(settings, "coin", "WealthAtlas", Color.yellow); Atlas(settings, "potion", "ItemAtlas", Color.cyan);
                var loc = ScriptableObject.CreateInstance<LocalizationSettings>(); AssetDatabase.CreateAsset(loc, Root + "/LocalizationSettings.asset");
                LocalizationSettings.Instance = loc; LocalizationEditorSettings.ActiveLocalizationSettings = loc;
                foreach (string code in new[] { "en", "ko" })
                { var locale = Locale.CreateLocale(code); AssetDatabase.CreateAsset(locale, Root + "/" + code + ".asset"); LocalizationEditorSettings.AddLocale(locale); }
                LocalizationSettings.StartupLocaleSelectors.Clear();
                LocalizationSettings.StartupLocaleSelectors.Add(new SpecificLocaleSelector { LocaleId = new LocaleIdentifier("en") });
                foreach (string collection in new[] { "name", "description", "appInfo" })
                {
                    var tables = LocalizationEditorSettings.CreateStringTableCollection(collection, Root + "/Tables");
                    foreach (var table in tables.StringTables)
                    {
                        string code = table.LocaleIdentifier.Code;
                        table.AddEntry("wealth41", code + " " + collection + " wealth"); table.AddEntry("item41", code + " " + collection + " item"); table.AddEntry("empty42", "");
                        table.AddEntry("LanguageDisplayName", code); EditorUtility.SetDirty(table);
                    }
                    tables.RefreshAddressables();
                }
                foreach (var group in settings.groups) if (group) foreach (var entry in group.entries) entry.SetLabel("Localization", true, true);
                EditorUtility.SetDirty(settings); EditorUtility.SetDirty(loc); AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
                AddressableAssetSettings.BuildPlayerContent(out UnityEditor.AddressableAssets.Build.AddressablesPlayerBuildResult result);
                if (!string.IsNullOrEmpty(result.Error)) throw new InvalidOperationException(result.Error);
                bool found = false;
                for (int i = 0; i < settings.DataBuilders.Count; i++) if (settings.DataBuilders[i] is BuildScriptPackedPlayMode) { settings.ActivePlayModeDataBuilderIndex = i; found = true; }
                if (!found) throw new InvalidOperationException("Packed PlayMode builder unavailable.");
                EditorUtility.SetDirty(settings); AssetDatabase.SaveAssets();
                Debug.Log("[STEP05E] Real packed Addressables content built; generated enum Ready."); EditorApplication.Exit(0);
            }
            catch (Exception e) { Debug.LogException(e); EditorApplication.Exit(1); }
        }
        private static void Atlas(AddressableAssetSettings settings, string sprite, string key, Color color)
        {
            string path = Root + "/" + sprite + ".png";
            var texture = new Texture2D(16, 16); var pixels = new Color[256]; Array.Fill(pixels, color); texture.SetPixels(pixels); texture.Apply(); File.WriteAllBytes(path, texture.EncodeToPNG()); Object.DestroyImmediate(texture);
            AssetDatabase.ImportAsset(path);
            var importer = (TextureImporter)AssetImporter.GetAtPath(path); importer.textureType = TextureImporterType.Sprite; importer.spriteImportMode = SpriteImportMode.Single; importer.textureCompression = TextureImporterCompression.Uncompressed; importer.isReadable = true; importer.SaveAndReimport();
            var asset = new SpriteAtlasAsset(); asset.Add(new Object[] { AssetDatabase.LoadAssetAtPath<Texture2D>(path) });
            string atlasPath = Root + "/" + key + ".spriteatlasv2"; SpriteAtlasAsset.Save(asset, atlasPath); AssetDatabase.ImportAsset(atlasPath);
            var atlasImporter = (SpriteAtlasImporter)AssetImporter.GetAtPath(atlasPath); var data = atlasImporter.textureSettings; data.readable = true; data.generateMipMaps = false; atlasImporter.textureSettings = data; atlasImporter.SaveAndReimport();
            if (!AssetDatabase.LoadAssetAtPath<SpriteAtlas>(atlasPath)) throw new InvalidOperationException("Actual SpriteAtlas import failed.");
            settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(atlasPath), settings.DefaultGroup).address = "Step05E/" + key;
        }
    }
}
