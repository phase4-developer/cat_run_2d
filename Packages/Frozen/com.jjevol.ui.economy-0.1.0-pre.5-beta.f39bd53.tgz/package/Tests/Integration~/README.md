# STEP 05-E isolated game presentation fixture

Opt-in test source, excluded from normal UPM import by `Integration~`. It is synthetic game code, not a common ItemTable, fixed game enum, or Runtime Registry. It authors no product assets and uses no product keys.

The intended layout is the guarded `.local/step05e-validation/Host`:

- `GamePresentationProvider.cs` → `Assets/Step05E/Game`, with a game asmdef referencing Data/Economy/Tables Runtime.
- `PresentationFixtureSetup.cs` → its own Editor test assembly referencing Tables.Authoring, Tables Runtime, its existing `LegacyFixture` runtime test helper, the read-only synthetic `Step8Fixture.Cipher` reference, and existing Addressables/Localization Editor assemblies.
- Run `Step05E.Editor.PresentationFixtureSetup.TablesAndExit` once before importing the game Provider/tests. This uses existing Authoring to generate `Step05E.Game.GameConsumeType` and conversions, plus encrypted Wealth/Item tables in the same frozen plan. No enum copy or hand-authored replacement is used.
- Import the Provider and `PresentationIntegrationTests.cs` into separate game/test assemblies, then run `PackAndExit` with graphics. This verifies the actual compiled generation and builds synthetic SpriteAtlas/Localization bundles with the installed SDK.
- Run `Step05E.Tests.PresentationIntegrationTests` in graphics PlayMode. Its prebuild setup requires existing Packed PlayMode content and does not silently switch to a fake provider/AssetDatabase mode.

The Host needs the Framework packages plus already-approved Unity Addressables 4.0.1, Localization 1.5.12, uGUI/TMP, Test Framework 1.6.0 and UniTask. No SDK is included here. Exact manifest, copied source hashes, runner, build logs and XML were recorded in the STEP05_E report, now in Git history (master `51d80c2`, removed 2026-11-09); use those instead of assuming a package cache or local path is a released version.

The game chooses Wealth=137, Item=-29 and Lore=0 in its synthetic ConsumeTypes.tsv. Both tables deliberately use item ID41. Lore is defined but has no presentation/execution handler. Provider routing is explicit; the game ItemTable adds only icon/atlas columns to TableData and reuses name/description localization keys. A successful empty metadata row differs from false/default. ResourceService still manages Wealth only.

Tests separate `Present`'s quantity/Source clone semantics from ID-only metadata; actual encrypted Resources loading; actual generated conversions; names/descriptions/keys/grade; real locale events; ResourceLabel Raw/Available, PriceBtn/ShowProduct, non-owning Context; built bundle loading, missing sprite/SDK key failure, Rebind/Disable/Destroy and real manager lease counts. Expected SDK failures are captured by scoped test observers with mandatory failure assertions and original log evidence; Production exceptions are not suppressed.

Normal file replacement/recovery remains the existing Authoring protocol. Existing fixture outputs are never overwritten by setup just to obtain a PASS. File.Replace 0x80070497 stays OPEN. These tests are Windows Unity Editor tests, not a Player/device/product/UI-art acceptance test.
