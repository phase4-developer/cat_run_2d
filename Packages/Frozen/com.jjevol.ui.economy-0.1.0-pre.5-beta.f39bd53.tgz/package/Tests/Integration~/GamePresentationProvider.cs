// Synthetic game example; imported only into the isolated STEP 05-E Host.
using System;
using jjevol;

namespace Step05E.Game
{
    public sealed class ItemData : TableData
    {
        public string Icon { get; private set; }
        public string Atlas { get; private set; }
        public ItemData(TSVRow row) : base(row) { }
        public override void Init(TSVRow row) { base.Init(row); Icon = row.GetString("icon", ""); Atlas = row.GetString("atlas", ""); }
    }
    public sealed class ItemTable : KeyedTable<int, ItemData>
    {
        public ItemTable(string name = "Step05E/item") : base(name) { }
        protected override ItemData ParseJson(TSVRow row) => new(row);
        protected override int GetKey(ItemData row) => row.id;
    }
    public sealed class GamePresentationProvider : IConsumePresentationProvider
    {
        public WealthTable Wealth { get; set; }
        public ItemTable Items { get; set; }
        public string WealthAtlas { get; set; } = "Step05E/WealthAtlas";
        public int StaticCalls { get; private set; }
        public int DataCalls { get; private set; }
        public ConsumeData LastData { get; private set; }
        public GamePresentationProvider(WealthTable wealth, ItemTable items) { Wealth = wealth; Items = items; }
        private static bool ValidKey(string value) => value != null && value.IndexOf('\r') < 0 && value.IndexOf('\n') < 0 && value.IndexOf('\t') < 0;
        public bool TryResolve(ConsumeTypeId typeId, int itemId, out ConsumePresentation presentation)
        {
            StaticCalls++; presentation = default;
            TableData row; string icon, atlas;
            // Exact game routing using the actually generated enum/conversions. No Runtime registry.
            if (typeId == GameConsumeType.Wealth.ToConsumeTypeId())
            { var wealth = Wealth?.Get(itemId); row = wealth; icon = wealth?.icon; atlas = WealthAtlas; }
            else if (typeId == GameConsumeType.Item.ToConsumeTypeId())
            { var item = Items?.Get(itemId); row = item; icon = item?.Icon; atlas = item?.Atlas; }
            else return false;
            if (row == null || row.grade < 0 || !ValidKey(icon) || !ValidKey(atlas)) return false;
            presentation = new ConsumePresentation(row, icon, atlas);
            return true; // Empty strings are valid metadata, not a failed lookup.
        }
        public ConsumePresentation Resolve(ConsumeData data)
        {
            DataCalls++; LastData = data;
            if (!TryResolve(data.TypeId, data.ItemId, out var common)) return default;
            // A game may add quantity/Source-dependent text without changing static ID lookup.
            return new ConsumePresentation(common.Table, common.Icon, common.Atlas, common.Name,
                common.Description + " [" + data.Quantity + ";source=" + (data.sourceData?.ItemId.ToString() ?? "none") + "]", common.Grade);
        }
    }
}
