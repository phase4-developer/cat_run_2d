using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using jjevol;
using jjevol.Tables.Authoring.Tests;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using Step05E.Game;
using TMPro;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Localization.Settings;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace Step05E.Tests
{
    public sealed class TableLocalization : ITableLocalization
    {
        public bool IsReady => LocalizationManager.HasInstance && LocalizationManager.Instance.IsInitialized;
        public string GetString(string collection, string key)
            => IsReady ? LocalizationSettings.StringDatabase.GetTable(collection, LocalizationSettings.SelectedLocale)?.GetEntry(key)?.LocalizedValue : null;
    }
    public sealed class MetadataLabel : LocalEconomyUI
    {
        public TMP_Text Text;
        public string Description;
        public int Draws;
        private ConsumeTypeId _type; private int _id;
        public void Bind(ResourceService resources, ConsumeTypeId type, int id, IConsumePresentationProvider provider)
        { SetResources(resources, provider); _type = type; _id = id; ShowUI(); }
        protected override void OnResourcesChanged(IReadOnlyList<int> ids, bool raw, bool available) { }
        protected override void _DrawContents()
        { Draws++; bool found = TryDescribe(_type, _id, out var metadata); Text.text = found ? metadata.Name : "missing"; Description = found ? metadata.Description : null; }
    }
    [PrebuildSetup("Step05E.Editor.PresentationFixtureSetup")]
    public sealed class PresentationIntegrationTests
    {
        private WealthTable _wealth;
        private ItemTable _items;
        private GamePresentationProvider _provider;
        private DataRepository _repository;
        private ResourceService _resources;
        private Action<LocalizationEvent> _bridge;
        private readonly List<GameObject> _objects = new();
        private readonly List<DataRepository> _repositories = new();
        private Canvas _canvas;
        private static ConsumeTypeId WealthKind => GameConsumeType.Wealth.ToConsumeTypeId();
        private static ConsumeTypeId ItemKind => GameConsumeType.Item.ToConsumeTypeId();
        [UnitySetUp] public IEnumerator Setup()
        {
            AddressablesManager.applicationIsQuitting = false;
            TableRuntimeOptions.DecryptBytes = LegacyFixture.Decrypt;
            var init = Addressables.InitializeAsync(); yield return Done(init.Task);
            LocalizationRuntimeOptions.ReadLanguage = () => "en";
            yield return Done(LocalizationManager.Instance.InitLocalization().AsTask());
            yield return Done(LocalizationManager.Instance.SetLanguage("en", false).AsTask());
            TableRuntimeOptions.Localization = new TableLocalization();
            _bridge = _ => UIRuntimeOptions.NotifyLocaleChanged(); LocalizationEvent.Published += _bridge;
            UIRuntimeOptions.Culture = () => CultureInfo.GetCultureInfo("en-US");
            _wealth = new WealthTable("Step05E/wealth"); _wealth.LoadDatas(new PackagedTableSource());
            _items = new ItemTable(); _items.LoadDatas(new PackagedTableSource());
            _provider = new GamePresentationProvider(_wealth, _items);
            _resources = Service(_wealth, 1000); _repository = _resources.Repository;
            _canvas = New("STEP05E actual Canvas", typeof(RectTransform), typeof(Canvas)).GetComponent<Canvas>(); _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        }
        [UnityTearDown] public IEnumerator Cleanup()
        {
            foreach (var go in _objects) if (go) Object.Destroy(go); _objects.Clear(); yield return null; yield return null;
            foreach (var repository in _repositories) repository.Dispose(); _repositories.Clear();
            LocalizationEvent.Published -= _bridge; TableRuntimeOptions.Localization = null; TableRuntimeOptions.DecryptBytes = null;
            UIRuntimeOptions.Culture = null; LocalizationRuntimeOptions.ReadLanguage = null;
            if (LocalizationManager.HasInstance) Object.Destroy(LocalizationManager.Instance.gameObject);
            if (AddressablesManager.HasInstance) Object.Destroy(AddressablesManager.Instance.gameObject);
            yield return null; yield return null;
        }
        private GameObject New(string name, params Type[] components)
        { var go = new GameObject(name, components); _objects.Add(go); return go; }
        private ResourceService Service(WealthTable definitions, long quantity)
        {
            var repository = new DataRepository("step05e:" + Guid.NewGuid().ToString("N")); _repositories.Add(repository); repository.Register(new WealthContainer());
            repository.ImportJson(new JObject { ["wealthInfos"] = new JArray(new JObject { ["wealthType"] = "coins", ["quantity"] = quantity }) }, "wealthInfos");
            return new ResourceService(repository, definitions, WealthKind);
        }
        private static void Set(object target, string field, object value)
        {
            for (var type = target.GetType(); type != null; type = type.BaseType)
            { var info = type.GetField(field, BindingFlags.NonPublic | BindingFlags.Instance); if (info != null) { info.SetValue(target, value); return; } }
            throw new MissingFieldException(field);
        }
        private TMP_Text Text()
        { var go = New("actual TMP", typeof(RectTransform)); go.transform.SetParent(_canvas.transform, false); return go.AddComponent<TextMeshProUGUI>(); }
        private ResourceLabel Label(out AddressableImage icon, out TMP_Text text, IConsumePresentationProvider provider = null, ResourceQuantityView view = ResourceQuantityView.Available)
        {
            icon = New("actual AddressableImage", typeof(RectTransform)).AddComponent<AddressableImage>(); icon.transform.SetParent(_canvas.transform, false);
            text = Text(); var label = New("resource label", typeof(RectTransform)).AddComponent<ResourceLabel>(); label.transform.SetParent(_canvas.transform, false);
            Set(label, "icon", icon); Set(label, "quantityText", text); label.ShowUI(_resources, WealthKind, 41, view, provider ?? _provider); return label;
        }
        private static IEnumerator Done(Task task)
        { float end = Time.realtimeSinceStartup + 30; while (!task.IsCompleted && Time.realtimeSinceStartup < end) yield return null; Assert.That(task.IsCompleted, Is.True, "SDK operation timed out"); if (task.IsFaulted) throw task.Exception.InnerException; if (task.IsCanceled) Assert.Fail("Unexpected cancellation"); }
        private static IEnumerator Until(Func<bool> condition)
        { float end = Time.realtimeSinceStartup + 15; while (!condition() && Time.realtimeSinceStartup < end) yield return null; Assert.That(condition(), Is.True, "Actual load/lifecycle condition timed out"); }
        private static IEnumerator Frames() { yield return null; yield return null; }
        private sealed class TextSource : ITableSource
        {
            private readonly string _text; public TextSource(string text) { _text = text; }
            public bool RequiresRemoteUpdate => false; public bool HasTable(string name) => true;
            public List<TSVRow> Load(string name) => TSVRow.FromTsv(_text);
            public Task<List<TSVRow>> LoadAsync(string name) => Task.FromResult(Load(name));
        }
        [Test] public void ActualGeneratedEnumsAndLongQuantitiesRoundTripServerJson()
        {
            foreach (var kind in new[] { GameConsumeType.Wealth, GameConsumeType.Item })
                foreach (long quantity in new[] { long.MinValue, long.MaxValue })
                {
                    var original = new ConsumeData(kind.ToConsumeTypeId(), 41, quantity);
                    var restored = new ConsumeData(JObject.Parse(original.ExportJson().ToString()));
                    Assert.That(restored.TypeId, Is.EqualTo(kind.ToConsumeTypeId()));
                    Assert.That(restored.ItemId, Is.EqualTo(41)); Assert.That(restored.Quantity, Is.EqualTo(quantity));
                }
        }

        [Test] public void ActualGeneratedEnumsRouteSameItemIdToDifferentLoadedTables()
        {
            Assert.That((int)GameConsumeType.Wealth, Is.EqualTo(137)); Assert.That((int)GameConsumeType.Item, Is.EqualTo(-29));
            Assert.That(WealthKind.TryToGameConsumeType(out var kind), Is.True); Assert.That(kind, Is.EqualTo(GameConsumeType.Wealth));
            Assert.That(_provider.TryResolve(WealthKind, 41, out var wealth), Is.True); Assert.That(_provider.TryResolve(ItemKind, 41, out var item), Is.True);
            Assert.That(wealth.Table, Is.SameAs(_wealth.Get(41))); Assert.That(item.Table, Is.SameAs(_items.Get(41)));
            Assert.That(wealth.Name, Is.EqualTo("en name wealth")); Assert.That(item.Name, Is.EqualTo("en name item"));
            Assert.That(item.Description, Is.EqualTo("en description item")); Assert.That(item.Icon, Is.EqualTo("potion")); Assert.That(item.Atlas, Is.EqualTo("Step05E/ItemAtlas")); Assert.That(item.Grade, Is.EqualTo(4));
            Assert.Throws<NotSupportedException>(() => _resources.Get(ItemKind, 41));
            Assert.Throws<NotSupportedException>(() => _resources.CheckSpend(new ConsumeData(ItemKind, 41, 1)));
            Assert.That(Resources.Load<TextAsset>("Step05E/wealth").text, Does.Not.Contain("wealth41"));
            Assert.That(Resources.Load<TextAsset>("Step05E/ConsumeTypes"), Is.Null);
        }
        [TestCase(int.MinValue, 41)][TestCase(int.MaxValue, 41)][TestCase(137, 999)][TestCase(-29, 999)][TestCase(0, 41)]
        public void MissingOrDefinedButUnpresentedIdsDoNotFallBack(int type, int item)
        { Assert.That(_provider.TryResolve(new(type), item, out var value), Is.False); Assert.That(value.Table, Is.Null); }
        [Test] public void NullUnloadedAndInvalidTablesFailWhileEmptyMetadataSucceeds()
        {
            _provider.Wealth = null; Assert.That(_provider.TryResolve(WealthKind, 41, out _), Is.False);
            _provider.Items = new ItemTable("unloaded"); Assert.That(_provider.TryResolve(ItemKind, 41, out _), Is.False);
            _provider.Items = _items; Assert.That(_provider.TryResolve(ItemKind, 42, out var empty), Is.True);
            Assert.That(empty.Name, Is.Empty); Assert.That(empty.Description, Is.Empty); Assert.That(empty.Icon, Is.Empty); Assert.That(empty.Atlas, Is.Empty); Assert.That(empty.Grade, Is.Zero);
            var invalid = new ItemTable("invalid"); invalid.LoadDatas(new TextSource("id\tgrade\ticon\tatlas\n41\t-1\tpotion\tStep05E/ItemAtlas")); _provider.Items = invalid;
            Assert.That(_provider.TryResolve(ItemKind, 41, out _), Is.False);
        }
        [Test] public void PresentRetainsCommonMetadataAndDataDependentQuantitySource()
        {
            var data = new ConsumeData(ItemKind, 41, 4000000000); data.SetRewardResult(new ConsumeData(WealthKind, 19, 2));
            var result = data.Present(_provider); Assert.That(_provider.TryResolve(ItemKind, 41, out var common), Is.True);
            Assert.That(result.Name, Is.EqualTo(common.Name)); Assert.That(result.Icon, Is.EqualTo(common.Icon)); Assert.That(result.Atlas, Is.EqualTo(common.Atlas)); Assert.That(result.Grade, Is.EqualTo(common.Grade));
            Assert.That(result.Description, Is.EqualTo("en description item [4000000000;source=19]")); Assert.That(_provider.LastData, Is.Not.SameAs(data));
        }
        [UnityTest] public IEnumerator LocaleRequeriesMetadataWithoutChangingQuantityOrOwningTables()
        {
            var metadata = New("ID-only item display", typeof(RectTransform)).AddComponent<MetadataLabel>(); metadata.Text = Text(); metadata.Bind(_resources, ItemKind, 41, _provider);
            Assert.That(metadata.Text.text, Is.EqualTo("en name item")); int draws = metadata.Draws;
            var before = _repository.Revision; _resources.Reserve(new[] { new ConsumeData(WealthKind, 41, 300) }); yield return Frames();
            Assert.That(metadata.Draws, Is.EqualTo(draws)); Assert.That(_resources.GetRaw(41), Is.EqualTo(1000)); Assert.That(_resources.Get(41), Is.EqualTo(700));
            yield return Done(LocalizationManager.Instance.SetLanguage("ko", false).AsTask()); yield return Frames();
            Assert.That(metadata.Text.text, Is.EqualTo("ko name item")); Assert.That(metadata.Description, Is.EqualTo("ko description item")); Assert.That(metadata.Draws, Is.GreaterThan(draws));
            Assert.That(_repository.Revision, Is.EqualTo(before)); Assert.That(_resources.Get(41), Is.EqualTo(700)); Assert.That(_provider.DataCalls, Is.Zero);
        }
        [UnityTest] public IEnumerator ResourceQuantitiesAndRealPackedAtlasLeaseSurviveViewsRebindDisableAndDestroy()
        {
            var label = Label(out var icon, out var text); yield return Until(() => icon.sprite != null);
            Assert.That(icon.atlasKey, Is.EqualTo("Step05E/WealthAtlas")); Assert.That(AddressablesManager.Instance.GetRefCount(icon.atlasKey), Is.EqualTo(1));
            Assert.That(text.text, Is.EqualTo("1,000")); Assert.That(_provider.DataCalls, Is.Zero);
            var raw = Label(out var rawIcon, out var rawText, view: ResourceQuantityView.Confirmed); yield return Until(() => rawIcon.sprite != null);
            _resources.Reserve(new[] { new ConsumeData(WealthKind, 41, 300) }); yield return Frames();
            Assert.That(label.Quantity, Is.EqualTo(700)); Assert.That(raw.Quantity, Is.EqualTo(1000)); Assert.That(rawText.text, Is.EqualTo("1,000"));
            Object.Destroy(raw.gameObject); Object.Destroy(rawIcon.gameObject); yield return Frames();
            icon.gameObject.SetActive(false); Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/WealthAtlas"), Is.EqualTo(1), "Default Disable retains the existing lease policy"); icon.gameObject.SetActive(true); yield return Frames();
            Set(icon, "m_ReleaseOnDisable", true); icon.gameObject.SetActive(false); yield return Frames(); Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/WealthAtlas"), Is.Zero);
            icon.gameObject.SetActive(true); yield return Until(() => icon.sprite != null);
            var otherWealth = new WealthTable("other"); otherWealth.LoadDatas(new TextSource("id\ttype\tactive\ticon\n41\tcoins\t1\tpotion"));
            var otherProvider = new GamePresentationProvider(otherWealth, _items) { WealthAtlas = "Step05E/ItemAtlas" };
            var other = Service(otherWealth, 2500); label.ShowUI(other, WealthKind, 41, presentation: otherProvider); yield return Until(() => icon.atlasKey == "Step05E/ItemAtlas" && icon.sprite != null);
            Assert.That(label.Quantity, Is.EqualTo(2500)); Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/WealthAtlas"), Is.Zero); Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/ItemAtlas"), Is.EqualTo(1));
            Assert.That(_resources.Get(41), Is.EqualTo(700)); Object.Destroy(label.gameObject); Object.Destroy(icon.gameObject); yield return Frames();
            Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/ItemAtlas"), Is.Zero);
            var locations = Addressables.LoadResourceLocationsAsync("Step05E/ItemAtlas"); yield return Done(locations.Task);
            Assert.That(locations.Result.Any(l => l.Dependencies != null && l.Dependencies.Any(d => d.ProviderId.Contains("AssetBundleProvider"))), Is.True, "Use actual built bundles, not a GateProvider/AssetDatabase mock"); Addressables.Release(locations);
        }
        [UnityTest] public IEnumerator MissingSpriteAndMissingMetadataKeepBalancesAndExistingLeasePolicy()
        {
            _provider.Wealth = new WealthTable("missing-icon"); _provider.Wealth.LoadDatas(new TextSource("id\ttype\tactive\ticon\n41\tcoins\t1\tdoes-not-exist"));
            var label = Label(out var icon, out var text); yield return Until(() => AddressablesManager.Instance.GetRefCount("Step05E/WealthAtlas") == 1); yield return Frames();
            Assert.That(icon.sprite, Is.Null); Assert.That(label.Quantity, Is.EqualTo(1000)); Assert.That(text.text, Is.EqualTo("1,000"));
            _provider.Wealth = null; label.Refresh(); yield return Frames(); Assert.That(label.HasData, Is.True); Assert.That(label.Quantity, Is.EqualTo(1000)); Assert.That(icon.enabled, Is.False); Assert.That(icon.sprite, Is.Null);
            Object.Destroy(icon.gameObject); yield return Frames(); Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/WealthAtlas"), Is.Zero);
        }
        [UnityTest] public IEnumerator OptionalContextForwardsIdsAndRebindsWithoutOwningEitherResourceService()
        {
            var context = New("non-owning context").AddComponent<LocalEconomyUIContext>(); context.Bind(_resources, _provider);
            var label = Label(out var icon, out _); label.ShowUI(context, 41); yield return Until(() => icon.sprite != null);
            Assert.That(context.Resources, Is.SameAs(_resources)); Assert.That(_provider.StaticCalls, Is.GreaterThan(0)); Assert.That(_provider.DataCalls, Is.Zero);
            var otherWealth = new WealthTable("other-context"); otherWealth.LoadDatas(new TextSource("id\ttype\tactive\ticon\n41\tcoins\t1\tpotion"));
            var other = Service(otherWealth, 2500); var otherProvider = new GamePresentationProvider(otherWealth, _items) { WealthAtlas = "Step05E/ItemAtlas" };
            context.Bind(other, otherProvider); yield return Until(() => icon.atlasKey == "Step05E/ItemAtlas" && icon.sprite != null); yield return Frames();
            Assert.That(label.Quantity, Is.EqualTo(2500)); Assert.That(otherProvider.DataCalls, Is.Zero); Assert.That(_repository.IsDisposed, Is.False); Assert.That(_resources.GetRaw(41), Is.EqualTo(1000));
            context.Unbind(); yield return Frames(); Assert.That(label.HasData, Is.False); Assert.That(icon.enabled, Is.False); Assert.That(other.IsDisposed, Is.False);
            Object.Destroy(context.gameObject); Object.Destroy(icon.gameObject); yield return Frames(); Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/ItemAtlas"), Is.Zero);
        }
        [UnityTest] public IEnumerator PriceAndProductButtonsKeepDataDependentPresentationAndAffordability()
        {
            var go = New("price button", typeof(RectTransform), typeof(Image), typeof(Button)); var button = go.GetComponent<Button>(); var label = go.AddComponent<PriceBtn>();
            Set(label, "priceText", Text()); Set(label, "button", button);
            label.ShowUI(_resources, new ConsumeData(WealthKind, 41, 900), _provider); Assert.That(button.interactable, Is.True); Assert.That(_provider.LastData.Quantity, Is.EqualTo(900));
            _resources.Reserve(new[] { new ConsumeData(WealthKind, 41, 300) }); yield return Frames(); Assert.That(button.interactable, Is.False); Assert.That(label.Required, Is.EqualTo(900));
            var prices = new Prices(); label.ShowProduct(_resources, prices, 88, 3, _provider); yield return Frames();
            Assert.That(label.Required, Is.EqualTo(30)); Assert.That(button.interactable, Is.True); Assert.That(_provider.LastData.Quantity, Is.EqualTo(30)); Assert.That(_provider.DataCalls, Is.GreaterThan(0));
        }
        [UnityTest] public IEnumerator MissingAddressableAtlasReportsActualSdkFailureWithoutChangingBalances()
        {
            var sdkErrors = new List<Exception>(); var unobserved = new List<Exception>();
            var prior = UnityEngine.ResourceManagement.ResourceManager.ExceptionHandler;
            Action<Exception> observe = e => unobserved.Add(e);
            UnityEngine.ResourceManagement.ResourceManager.ExceptionHandler = (handle, error) => sdkErrors.Add(error);
            UniTaskScheduler.UnobservedTaskException += observe;
            try
            {
                _provider.WealthAtlas = "Step05E/missing-atlas";
                var label = Label(out var icon, out var text);
                yield return Until(() => unobserved.Count > 0 || sdkErrors.Count > 0); yield return Frames();
                Assert.That(sdkErrors.Count + unobserved.Count, Is.GreaterThan(0));
                Assert.That(icon.atlasKey, Is.EqualTo("Step05E/missing-atlas")); Assert.That(icon.sprite, Is.Null);
                Assert.That(AddressablesManager.Instance.GetRefCount("Step05E/missing-atlas"), Is.Zero);
                Assert.That(label.Quantity, Is.EqualTo(1000)); Assert.That(text.text, Is.EqualTo("1,000")); Assert.That(_resources.GetRaw(41), Is.EqualTo(1000));
                Debug.Log("[STEP05E] Expected actual missing-atlas SDK failure: " + string.Join(",", sdkErrors.Concat(unobserved).Select(e => e.GetType().FullName)));
            }
            finally { UniTaskScheduler.UnobservedTaskException -= observe; UnityEngine.ResourceManagement.ResourceManager.ExceptionHandler = prior; }
        }
        private sealed class Prices : IProductPriceSource
        { public event Action<int> Changed { add { } remove { } } public ConsumeData GetPrice(int productId) => new(WealthKind, 41, 10); }
    }
}
