# Changelog

## 0.1.0-pre.2 - 2026-11-06

- No runtime change. Added Music replacement lease tests and README notes.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.1 — 2026-10-30

Optional Addressables Clip provider extracted from the mobile implementation, with explicit shared-handle/playback-lease ownership and integration tests. Local source only; no publication or frozen tarball.
