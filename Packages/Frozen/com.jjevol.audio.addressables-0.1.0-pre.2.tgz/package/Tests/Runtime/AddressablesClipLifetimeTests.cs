using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.ResourceManagement;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace jjevol.Audio.Tests
{
    [PrebuildSetup("jjevol.Audio.Tests.AudioAddressablesTestSetup")]
    [PostBuildCleanup("jjevol.Audio.Tests.AudioAddressablesTestSetup")]
    [Timeout(20000)]
    public sealed class AddressablesClipLifetimeTests
    {
        // A synthetic clip source inside the real Addressables ResourceManager; no fake Addressables implementation.
        private sealed class ClipResourceProvider : ResourceProviderBase
        {
            internal int Provided, Released;
            internal bool Delayed, Fail;
            internal readonly List<ProvideHandle> Pending = new();
            private readonly string _id = "JJEvol.Audio.TestProvider." + Guid.NewGuid().ToString("N");
            public override string ProviderId => _id;
            public override void Provide(ProvideHandle handle)
            {
                Provided++;
                if (Fail) { handle.Complete<AudioClip>(null, false, new InvalidOperationException("expected-audio-provider-failure")); return; }
                if (Delayed) Pending.Add(handle);
                else Complete(handle);
            }
            private static void Complete(ProvideHandle handle)
                => handle.Complete(AudioClip.Create("addressables-audio-test", 4410, 1, 44100, false), true, null);
            internal void CompletePending()
            {
                foreach (var handle in Pending) Complete(handle);
                Pending.Clear();
            }
            public override void Release(IResourceLocation location, object asset)
            {
                Released++;
                if (asset is AudioClip clip) Object.Destroy(clip);
            }
        }
        private ClipResourceProvider _resource;
        private ResourceLocationMap _locator;
        private AddressablesClipProvider _provider;
        private AudioManager _manager;
        private GameObject _listener;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            Debug.Log("[AudioValidation] Setup " + TestContext.CurrentContext.Test.Name);
            var initialized = Addressables.InitializeAsync(false);
            yield return initialized;
            Assert.AreEqual(UnityEngine.ResourceManagement.AsyncOperations.AsyncOperationStatus.Succeeded, initialized.Status);
            Addressables.Release(initialized);
            _resource = new ClipResourceProvider();
            Addressables.ResourceManager.ResourceProviders.Add(_resource);
            _locator = new ResourceLocationMap("JJEvol.Audio.TestLocator." + Guid.NewGuid().ToString("N"));
            var location = new ResourceLocationBase("clip-one", "audio-test-one", _resource.ProviderId, typeof(AudioClip));
            _locator.Add("clip-one", location);
            _locator.Add("alias", location);
            _locator.Add("clip-two", new ResourceLocationBase("clip-two", "audio-test-two", _resource.ProviderId, typeof(AudioClip)));
            Addressables.AddResourceLocator(_locator);
            _provider = new AddressablesClipProvider();
            if (!Object.FindAnyObjectByType<AudioListener>()) _listener = new GameObject("audio-addressables-listener", typeof(AudioListener));
        }
        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (_manager) Object.Destroy(_manager.gameObject);
            yield return null;
            _provider.Dispose();
            _resource.CompletePending();
            yield return null;
            yield return null;
            Assert.AreEqual(0, _provider.ActiveLeaseCount, "No playback lease may survive fixture teardown.");
            Assert.AreEqual(0, _provider.LoadedKeyCount, "No provider handle may survive fixture teardown.");
            Addressables.RemoveResourceLocator(_locator);
            Addressables.ResourceManager.ResourceProviders.Remove(_resource);
            if (_listener) Object.Destroy(_listener);
        }
        private AudioManager Manager(int poolSize = 1)
        {
            var root = new GameObject("audio-addressables-manager");
            root.SetActive(false);
            _manager = root.AddComponent<AudioManager>();
            _manager.initialPoolSize = poolSize; _manager.poolCanExpand = false;
            root.SetActive(true);
            _manager.SetProvider(_provider);
            return _manager;
        }
        [UnityTest]
        public IEnumerator ConcurrentLeasesShareOneOperationAndReleaseAtLastUser()
        {
            var first = _provider.AcquireAsync(AudioTrack.Sfx, "clip-one");
            var second = _provider.AcquireAsync(AudioTrack.UI, "clip-one");
            while (!first.IsCompleted || !second.IsCompleted) yield return null;
            Assert.AreEqual(1, _resource.Provided);
            Assert.AreSame(first.Result.Clip, second.Result.Clip);
            Assert.AreEqual(2, _provider.ActiveLeaseCount);
            first.Result.Dispose();
            Assert.AreEqual(0, _resource.Released);
            Assert.IsTrue(second.Result.Clip);
            second.Result.Dispose(); second.Result.Dispose();
            yield return null;
            Assert.AreEqual(1, _resource.Released);
            Assert.AreEqual(0, _provider.LoadedKeyCount);
        }
        [UnityTest]
        public IEnumerator ActualAddressableLoopKeepsClipUntilStop()
        {
            var manager = Manager();
            var task = manager.PlayAsync("clip-one", loop: true, debounce: 0);
            while (!task.IsCompleted) yield return null;
            yield return new WaitForSecondsRealtime(0.25f);
            Assert.IsTrue(task.Result.isPlaying);
            Assert.AreEqual(0, _resource.Released);
            manager.Stop(task.Result);
            yield return null;
            Assert.AreEqual(1, _resource.Released);
        }
        [UnityTest]
        public IEnumerator CanceledLoadReleasesTheRealHandleAfterOperationCompletes()
        {
            _resource.Delayed = true;
            using var cancellation = new CancellationTokenSource();
            var pending = _provider.AcquireAsync(AudioTrack.Sfx, "clip-one", cancellation.Token);
            while (_resource.Pending.Count == 0) yield return null;
            cancellation.Cancel();
            while (!pending.IsCompleted) yield return null;
            Assert.IsTrue(pending.IsCanceled);
            Assert.AreEqual(0, _provider.ActiveLeaseCount);
            _resource.CompletePending();
            yield return null;
            yield return null;
            Assert.AreEqual(1, _resource.Released);
            Assert.AreEqual(0, _provider.LoadedKeyCount);
        }
        [UnityTest]
        public IEnumerator ManagerStopAllDuringSdkLoadNeverStartsLatePlayback()
        {
            _resource.Delayed = true;
            var manager = Manager();
            var pending = manager.PlayAsync("clip-one", loop: true, debounce: 0);
            while (_resource.Pending.Count == 0) yield return null;
            manager.StopAll();
            while (!pending.IsCompleted) yield return null;
            Assert.IsNull(pending.Result);
            _resource.CompletePending();
            yield return null;
            yield return null;
            Assert.AreEqual(1, _resource.Released);
            Assert.AreEqual(0, manager.ActiveSourceCount);
        }
        [UnityTest]
        public IEnumerator AliasClipDebounceDoesNotLeakAnSdkReference()
        {
            var manager = Manager();
            var first = manager.PlayAsync("clip-one", loop: true, debounce: 1);
            while (!first.IsCompleted) yield return null;
            var duplicate = manager.PlayAsync("alias", loop: true, debounce: 1);
            while (!duplicate.IsCompleted) yield return null;
            Assert.IsNull(duplicate.Result);
            Assert.AreEqual(1, _resource.Provided);
            Assert.AreEqual(0, _resource.Released);
            manager.StopAll();
            yield return null;
            Assert.AreEqual(1, _resource.Released);
        }
        [UnityTest]
        public IEnumerator LegacyLoadCachesUntilExplicitRelease()
        {
            var first = _provider.LoadClipAsync(AudioTrack.Sfx, "clip-one");
            while (!first.IsCompleted) yield return null;
            var again = _provider.LoadClipAsync(AudioTrack.UI, "clip-one");
            while (!again.IsCompleted) yield return null;
            Assert.AreSame(first.Result, again.Result);
            Assert.AreEqual(1, _resource.Provided);
            _provider.ReleaseClip("clip-one");
            _provider.ClearCache();
            yield return null;
            Assert.AreEqual(1, _resource.Released);
        }
        [UnityTest]
        public IEnumerator DisposingProviderDoesNotInvalidateActivePlaybackLeases()
        {
            var task = _provider.AcquireAsync(AudioTrack.Sfx, "clip-one");
            while (!task.IsCompleted) yield return null;
            _provider.Dispose();
            Assert.IsTrue(task.Result.Clip);
            Assert.AreEqual(0, _resource.Released);
            task.Result.Dispose();
            yield return null;
            Assert.AreEqual(1, _resource.Released);
        }
        [UnityTest]
        public IEnumerator RepeatedLoadReleaseLeavesNoHandlesOrClips()
        {
            for (int i = 1; i <= 12; i++)
            {
                var task = _provider.AcquireAsync(AudioTrack.Sfx, "clip-one");
                while (!task.IsCompleted) yield return null;
                task.Result.Dispose();
                yield return null;
                Assert.AreEqual(i, _resource.Provided);
                Assert.AreEqual(i, _resource.Released);
                Assert.AreEqual(0, _provider.LoadedKeyCount);
            }
        }
        [UnityTest]
        public IEnumerator PoolReuseKeepsNewSdkClipAlivePastTheOldDuration()
        {
            var manager = Manager();
            var first = manager.PlayAsync("clip-one", debounce: 0);
            while (!first.IsCompleted) yield return null;
            var replacement = manager.PlayAsync("clip-two", loop: true, debounce: 0);
            while (!replacement.IsCompleted) yield return null;
            Assert.AreSame(first.Result, replacement.Result);
            yield return new WaitForSecondsRealtime(0.25f);
            Assert.IsTrue(replacement.Result.isPlaying);
            Assert.IsTrue(replacement.Result.clip);
            Assert.AreEqual(1, _resource.Released);
            manager.StopAll();
            yield return null;
            Assert.AreEqual(2, _resource.Released);
        }
        [UnityTest]
        public IEnumerator MusicRequestSupersededDuringSdkLoadReleasesItsHandleWithoutPlaying()
        {
            var manager = Manager();
            _resource.Delayed = true;
            AudioEvents.PlayMusic.Trigger("clip-one");
            while (_resource.Pending.Count == 0) yield return null;
            _resource.Delayed = false;
            AudioEvents.PlayMusic.Trigger("clip-two");
            while (!manager.CurrentMusic) yield return null;
            var winner = manager.CurrentMusic.clip;
            _resource.CompletePending();
            yield return null;
            yield return null;
            Assert.AreEqual(2, _resource.Provided);
            Assert.AreEqual(1, _resource.Released, "The superseded load must release its real handle.");
            Assert.AreEqual(1, manager.ActiveSourceCount);
            Assert.AreSame(winner, manager.CurrentMusic.clip);
            Assert.IsTrue(manager.CurrentMusic.clip);
        }
        [UnityTest]
        public IEnumerator MusicCrossfadeReleasesTheReplacedHandle()
        {
            // Two sources: with one, the new music steals it and releases the old lease before any fade runs.
            var manager = Manager(2);
            AudioEvents.PlayMusic.Trigger("clip-one");
            while (!manager.CurrentMusic) yield return null;
            var first = manager.CurrentMusic.clip;
            AudioEvents.PlayMusic.Trigger("clip-two", crossfade: 0.3f);
            while (manager.CurrentMusic.clip == first) yield return null;
            Assert.AreEqual(2, manager.ActiveSourceCount, "The replaced music keeps playing through the fade.");
            Assert.AreEqual(0, _resource.Released, "The fade owns the old lease until it ends.");
            while (manager.ActiveSourceCount > 1) yield return null;
            yield return null;
            Assert.AreEqual(1, _resource.Released);
            Assert.IsTrue(manager.CurrentMusic.isPlaying);
            Assert.AreEqual(1f, manager.CurrentMusic.volume, 0.0001f);
        }
        [UnityTest]
        public IEnumerator FailedLoadReturnsOwnershipAndCanRetry()
        {
            _resource.Fail = true;
            var previousHandler = ResourceManager.ExceptionHandler;
            var errors = new List<Exception>();
            ResourceManager.ExceptionHandler = (operation, error) => errors.Add(error);
            try
            {
                var failed = _provider.AcquireAsync(AudioTrack.Sfx, "clip-one");
                while (!failed.IsCompleted) yield return null;
                Assert.IsNull(failed.Result);
                Assert.IsNotEmpty(errors, "The real SDK failure must be observed.");
                foreach (var error in errors) StringAssert.Contains("expected-audio-provider-failure", error.ToString());
                Assert.AreEqual(0, _provider.ActiveLeaseCount);
                Assert.AreEqual(0, _provider.LoadedKeyCount);
            }
            finally { ResourceManager.ExceptionHandler = previousHandler; }
            _resource.Fail = false;
            var retry = _provider.AcquireAsync(AudioTrack.Sfx, "clip-one");
            while (!retry.IsCompleted) yield return null;
            Assert.IsTrue(retry.Result.Clip);
            retry.Result.Dispose();
            yield return null;
            Assert.AreEqual(2, _resource.Provided);
            Assert.AreEqual(1, _resource.Released); // Failed SDK operations have no asset to release.
        }
    }
}
