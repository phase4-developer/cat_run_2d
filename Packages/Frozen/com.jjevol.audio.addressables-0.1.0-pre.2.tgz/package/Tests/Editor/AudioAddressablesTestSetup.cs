using System;
using System.IO;
using UnityEditor;
using UnityEditor.AddressableAssets.Build.DataBuilders;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine.AddressableAssets;
using UnityEngine.TestTools;

namespace jjevol.Audio.Tests
{
    // Explicit Test Runner fixture setup only. Never runs on package installation.
    public sealed class AudioAddressablesTestSetup : IPrebuildSetup, IPostBuildCleanup
    {
        private const string RootKey = "JJEvol.Audio.TestRoot";
        private const string PreviousPathKey = "JJEvol.Audio.PreviousAddressablesPath";
        public void Setup()
        {
            string root = "Assets/JJEvolAudioTests_" + Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets", root.Substring("Assets/".Length));
            var settings = AddressableAssetSettings.Create(root, "Settings", true, true);
            for (int i = 0; i < settings.DataBuilders.Count; i++)
                if (settings.DataBuilders[i] is BuildScriptFastMode) settings.ActivePlayModeDataBuilderIndex = i;
            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets();
            SessionState.SetString(RootKey, root);
            SessionState.SetString(PreviousPathKey, SessionState.GetString(Addressables.kAddressablesRuntimeDataPath, ""));
            SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, "GUID:" + AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(settings)));
        }
        public void Cleanup()
        {
            string previousPath = SessionState.GetString(PreviousPathKey, "");
            if (string.IsNullOrEmpty(previousPath)) SessionState.EraseString(Addressables.kAddressablesRuntimeDataPath);
            else SessionState.SetString(Addressables.kAddressablesRuntimeDataPath, previousPath);
            string root = SessionState.GetString(RootKey, "");
            if (root.StartsWith("Assets/JJEvolAudioTests_", StringComparison.Ordinal) && AssetDatabase.IsValidFolder(root))
            {
                string absoluteRoot = Path.GetFullPath(root);
                string assetsRoot = Path.GetFullPath(UnityEngine.Application.dataPath);
                if (!string.Equals(Path.GetDirectoryName(absoluteRoot), assetsRoot, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Audio test cleanup must remain directly inside this Host's Assets folder.");
                AssetDatabase.DeleteAsset(root);
            }
            SessionState.EraseString(RootKey);
            SessionState.EraseString(PreviousPathKey);
        }
    }
}
