using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace jjevol.Audio
{
    /// <summary>Call on Unity's main thread. One actual handle per loaded key; one lease per playback.</summary>
    public class AddressablesClipProvider : IAudioClipLeaseProvider, IDisposable
    {
        private sealed class Entry
        {
            internal string Key;
            internal AsyncOperationHandle<AudioClip> Handle;
            internal Task<AudioClip> Loading;
            internal int References;
            internal bool Released, CleanupScheduled;
        }
        private readonly Dictionary<string, Entry> _entries = new(StringComparer.Ordinal);
        private readonly Dictionary<string, AudioClipLease> _legacyPins = new(StringComparer.Ordinal);
        private bool _disposed;
        public int LoadedKeyCount => _entries.Count;
        public int ActiveLeaseCount
        {
            get { int count = 0; foreach (var entry in _entries.Values) count += entry.References; return count; }
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        public static void Register() => AudioClipProviders.Register(ProviderKind.Addressables, () => new AddressablesClipProvider());

        public async Task<AudioClipLease> AcquireAsync(AudioTrack track, string key, CancellationToken cancellationToken = default)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(AddressablesClipProvider));
            if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("An Addressables key is required.", nameof(key));
            cancellationToken.ThrowIfCancellationRequested();
            if (!_entries.TryGetValue(key, out var entry))
            {
                var handle = Addressables.LoadAssetAsync<AudioClip>(key);
                entry = new Entry { Key = key, Handle = handle, Loading = handle.Task };
                _entries.Add(key, entry);
            }
            entry.References++;
            bool transferred = false;
            try
            {
                var clip = await WaitForLoad(entry.Loading, cancellationToken);
                cancellationToken.ThrowIfCancellationRequested();
                if (!clip) return null;
                var lease = new AudioClipLease(clip, () => ReleaseReference(entry));
                transferred = true;
                return lease;
            }
            finally
            {
                if (!transferred) ReleaseReference(entry);
            }
        }
        // Original interface is retained for direct consumers. Its cache ownership lasts until explicit release/disposal.
        public async Task<AudioClip> LoadClipAsync(AudioTrack track, string key)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(AddressablesClipProvider));
            if (_legacyPins.TryGetValue(key, out var existing)) return existing.Clip;
            var lease = await AcquireAsync(track, key);
            if (lease == null) return null;
            if (_disposed) { lease.Dispose(); throw new ObjectDisposedException(nameof(AddressablesClipProvider)); }
            if (_legacyPins.TryGetValue(key, out existing)) { lease.Dispose(); return existing.Clip; }
            _legacyPins.Add(key, lease);
            return lease.Clip;
        }
        public void ReleaseClip(string key)
        {
            if (!_legacyPins.TryGetValue(key, out var lease)) return;
            _legacyPins.Remove(key);
            lease.Dispose();
        }
        public void ClearCache()
        {
            var pins = new List<AudioClipLease>(_legacyPins.Values);
            _legacyPins.Clear();
            foreach (var lease in pins) lease.Dispose();
        }
        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            ClearCache();
            // Outstanding playback leases still own their handles. Their final Dispose releases the entry.
        }
        private void ReleaseReference(Entry entry)
        {
            if (entry.References <= 0) throw new InvalidOperationException("Audio clip reference underflow.");
            entry.References--;
            if (entry.References != 0) return;
            if (entry.Loading.IsCompleted) ReleaseEntry(entry);
            else if (!entry.CleanupScheduled) { entry.CleanupScheduled = true; _ = ReleaseWhenCompleted(entry); }
        }
        private async Task ReleaseWhenCompleted(Entry entry)
        {
            try { await entry.Loading; }
            catch { /* Failed operations must be released as well. AcquireAsync reports the failure. */ }
            entry.CleanupScheduled = false;
            if (entry.References == 0) ReleaseEntry(entry);
        }
        private void ReleaseEntry(Entry entry)
        {
            if (entry.Released) return;
            entry.Released = true;
            if (_entries.TryGetValue(entry.Key, out var current) && ReferenceEquals(current, entry)) _entries.Remove(entry.Key);
            if (entry.Handle.IsValid()) Addressables.Release(entry.Handle);
        }
        private static async Task<AudioClip> WaitForLoad(Task<AudioClip> loading, CancellationToken cancellationToken)
        {
            if (!cancellationToken.CanBeCanceled) return await loading;
            var canceled = new TaskCompletionSource<bool>();
            using (cancellationToken.Register(() => canceled.TrySetResult(true)))
            {
                if (await Task.WhenAny(loading, canceled.Task) != loading) cancellationToken.ThrowIfCancellationRequested();
                return await loading;
            }
        }
    }
}
