# Source and dependencies

The provider originates from the user's mobile AudioClipProviders implementation. The 2026-10-30 correction authorizes dependency/lifetime improvements. The original provider namespace/class and LoadClipAsync call shape remain; its original containing file GUID remains with Core's AudioClipProviders.cs.

Unity Addressables 4.0.1 is a separately resolved declared dependency. No Unity package cache, third-party event library, paid Vendor source, or product audio is copied into this package. This local candidate assigns no public redistribution license.
