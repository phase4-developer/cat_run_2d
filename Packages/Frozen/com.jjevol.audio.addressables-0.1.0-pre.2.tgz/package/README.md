# JJEvol Audio Addressables — local candidate

Optional integration for com.jjevol.audio and Unity Addressables 4.0.1, validated with Unity 6000.3.9f1. Core works without this package. No SDK source/cache is redistributed.

AddressablesClipProvider.Register runs BeforeSceneLoad. Then AudioManager.SetProvider(ProviderKind.Addressables) selects it. Explicit Register is also available to custom bootstraps.

For manager playback, AcquireAsync returns one AudioClipLease per request. Concurrent users of the same key share one Addressables load handle. The final playback lease releases that handle exactly once. A canceled request returns its reference; an unfinished operation is observed and released after completion if it has no remaining users. Disposal never invalidates active playback leases.

The original LoadClipAsync interface remains for direct consumers. That path pins one cached lease per key until ReleaseClip, ClearCache or Dispose. AudioManager uses AcquireAsync instead, so stopped playback does not leave an idle provider cache pin.

A music request superseded while loading follows the same path as a canceled request: it plays nothing and its handle is released once the operation completes.

All provider operations and lease disposal must occur on Unity's main thread. Cancellation does not claim to abort an SDK download/underlying operation. Failure, debounce rejection, canceled playback, pool steal and manager teardown must all return their acquired ownership.

The package does not configure Addressables Groups, build/deploy content, switch catalogs, or replace Managed Addressables. Use a single game bootstrap to coordinate catalog initialization before audio loading.

Tests use the real Addressables ResourceManager with generated AudioClip resources. They do not establish bundle/content-build correctness, remote download, Player/device behavior or actual audible quality. Test setup creates temporary Addressables settings explicitly through Test Runner setup, never automatically on installation.
