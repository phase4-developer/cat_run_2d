# JJEvol Platform Analytics Firebase

Local validation candidate 0.1.0-pre.1. Sends `AnalyticsManager` events to Firebase Analytics.

The code is user-authored, confirmed by the user on 2026-11-08. No Firebase SDK, configuration file, company content or product value is included.

## Install

The Firebase Unity SDK is required and is not a package dependency. Install Firebase Analytics in the consumer project; the provider was compiled against 13.17.0. The assembly builds for the Editor, Android, iOS and macOS.

The Editor never calls the SDK and only logs each event, so this package compiles in the Editor without Firebase. A Player build for those platforms needs the SDK. A Windows Player build leaves this assembly out, so guard the project's start code:

```csharp
#if UNITY_ANDROID || UNITY_IOS
AnalyticsManager.AddProvider(new FirebaseAnalyticsProvider());
#endif
```

## When to add it

Add the provider after the project has finished initializing Firebase. `AddProvider` turns Firebase collection on or off at that moment, and events logged before then go nowhere. This package does not initialize Firebase. That belongs with the rest of Firebase.

## Purchases

`logAppleTransactions` is the project's choice, because this package has no platform or store branch.

```csharp
#if UNITY_IOS
var provider = new FirebaseAnalyticsProvider(logAppleTransactions: true);
#else
var provider = new FirebaseAnalyticsProvider();
#endif
```

| Setting | A `Purchase` event |
| --- | --- |
| `false`, the default | Sends `in_app_purchase` with your parameters. The event's own name is not sent. |
| `true` | Sends the `transaction_id` as an Apple transaction record. Empty means one warning and nothing sent. |

Firebase collects Google Play purchases by itself. To avoid counting them twice, keep purchases out on those builds with a `filter`.

## What is sent

The event's own name is always sent, except for purchases above. Standard events add a second event.

| `AnalyticsStandardEvent` | Second event | Parameter added |
| --- | --- | --- |
| `TutorialComplete` | `tutorial_complete` | `tutorial_name` from `tutorial_name` or `tutorial_group_id` |
| `LevelAchieved` with `level_name`, `stage_id` or `stage` | `level_end` | `level_name` from the first of those |
| `LevelAchieved` without them | `level_up` | None. Pass `level`. |
| `AchievementUnlocked` | `unlock_achievement` | `achievement_id` from `achievement_id`, `quest_id` or `character_id` |
| `VirtualCurrencySpent` | `spend_virtual_currency` | `item_name` from `item_name` or `product_id`. `virtual_currency_name` from `virtual_currency_name` or `price_id`. `value` from `value` or `price_value` |
| `AdReward`, `AdRevenue` | None | None |

An event already named like the standard event is sent once. `AdRevenue` reaches Firebase only as the custom `ad_revenue_paid` event. The original library did not send it to Firebase, so keep it out with a `filter` to match.

Names and parameter keys are trimmed and cut to 40 characters. Values become long or double, a bool becomes 1 or 0, null becomes an empty string, and anything else becomes text in the invariant culture.

No license grant for third-party dependencies is made here. Installation in a consumer project is a separate task.
