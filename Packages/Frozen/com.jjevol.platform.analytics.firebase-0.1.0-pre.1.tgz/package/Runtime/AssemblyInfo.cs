using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Analytics.Firebase.Tests.Editor")]
