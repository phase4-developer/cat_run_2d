using System.Collections.Generic;
using UnityEngine;
#if !UNITY_EDITOR
using Firebase.Analytics;
using Firebase.Extensions;
#endif

namespace PlatformLibrary.Analytics.Firebase
{
    /// <summary>The only type that touches the Firebase SDK. The Editor logs instead, so it compiles without the SDK.</summary>
    internal sealed class FirebaseSdkClient : IFirebaseAnalyticsClient
    {
        public void SetCollectionEnabled(bool enabled)
        {
#if UNITY_EDITOR
            Debug.Log($"[FirebaseAnalyticsProvider][Editor] collection {enabled}");
#else
            FirebaseAnalytics.SetAnalyticsCollectionEnabled(enabled);
#endif
        }

        public void LogEvent(string name, IReadOnlyList<KeyValuePair<string, object>> parameters)
        {
#if UNITY_EDITOR
            Debug.Log($"[FirebaseAnalyticsProvider][Editor] {name}");
#else
            FirebaseAnalytics.LogEvent(name, ToSdkParameters(parameters));
#endif
        }

        public void LogAppleTransaction(string transactionId)
        {
#if UNITY_EDITOR
            Debug.Log($"[FirebaseAnalyticsProvider][Editor] Apple transaction {transactionId}");
#else
            FirebaseAnalytics.LogAppleTransactionAsync(transactionId).ContinueWithOnMainThread(task =>
            {
                if (task.IsFaulted || task.IsCanceled)
                    Debug.LogWarning($"[FirebaseAnalyticsProvider] Apple purchase log failed. Error:{task.Exception?.GetBaseException().Message ?? "Canceled"}");
            });
#endif
        }

#if !UNITY_EDITOR
        private static Parameter[] ToSdkParameters(IReadOnlyList<KeyValuePair<string, object>> parameters)
        {
            Parameter[] result = new Parameter[parameters.Count];

            for (int i = 0; i < parameters.Count; i++)
            {
                string key = parameters[i].Key;
                object value = parameters[i].Value;

                if (value is long longValue)
                    result[i] = new Parameter(key, longValue);
                else if (value is double doubleValue)
                    result[i] = new Parameter(key, doubleValue);
                else
                    result[i] = new Parameter(key, (string)value);
            }

            return result;
        }
#endif
    }
}
