using System.Collections.Generic;

namespace PlatformLibrary.Analytics.Firebase
{
    /// <summary>
    /// The calls <see cref="FirebaseAnalyticsProvider"/> makes on the SDK. Parameter values are string, long or double only.
    /// </summary>
    internal interface IFirebaseAnalyticsClient
    {
        void SetCollectionEnabled(bool enabled);
        void LogEvent(string name, IReadOnlyList<KeyValuePair<string, object>> parameters);
        void LogAppleTransaction(string transactionId);
    }
}
