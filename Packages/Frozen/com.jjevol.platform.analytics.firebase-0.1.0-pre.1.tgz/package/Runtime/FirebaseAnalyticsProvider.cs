using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace PlatformLibrary.Analytics.Firebase
{
    /// <summary>
    /// Sends events to Firebase Analytics. Add it after the project has finished initializing Firebase.
    /// Which events reach Firebase is the project's choice through the <see cref="AnalyticsManager.AddProvider"/> filter.
    /// </summary>
    public sealed class FirebaseAnalyticsProvider : IAnalyticsProvider
    {
        private const int MaxNameLength = 40;

        private const string StandardTutorialComplete = "tutorial_complete";
        private const string StandardLevelEnd = "level_end";
        private const string StandardLevelUp = "level_up";
        private const string StandardUnlockAchievement = "unlock_achievement";
        private const string StandardSpendVirtualCurrency = "spend_virtual_currency";
        private const string StandardInAppPurchase = "in_app_purchase";

        private static readonly string[] LevelEndKeys = { "level_name", "stage_id", "stage" };
        private static readonly string[] TutorialNameKeys = { "tutorial_name", "tutorial_group_id" };
        private static readonly string[] AchievementIdKeys = { "achievement_id", "quest_id", "character_id" };
        private static readonly string[] ItemNameKeys = { "item_name", "product_id" };
        private static readonly string[] VirtualCurrencyNameKeys = { "virtual_currency_name", "price_id" };
        private static readonly string[] SpentValueKeys = { "value", "price_value" };

        private readonly IFirebaseAnalyticsClient client;
        private readonly bool logAppleTransactions;

        public bool IsEnabled { get; private set; } = true;

        /// <param name="logAppleTransactions">
        /// True sends a purchase as an Apple transaction record instead of the in_app_purchase event. The project sets it
        /// on builds that sell through Apple's store.
        /// </param>
        public FirebaseAnalyticsProvider(bool logAppleTransactions = false)
            : this(new FirebaseSdkClient(), logAppleTransactions)
        {
        }

        internal FirebaseAnalyticsProvider(IFirebaseAnalyticsClient client, bool logAppleTransactions = false)
        {
            this.client = client;
            this.logAppleTransactions = logAppleTransactions;
        }

        public void SetCollectionEnabled(bool enabled)
        {
            IsEnabled = enabled;
            client.SetCollectionEnabled(enabled);
        }

        public void Log(AnalyticsEvent analyticsEvent)
        {
            if (analyticsEvent == null || string.IsNullOrEmpty(analyticsEvent.Name) || !IsEnabled)
                return;

            if (analyticsEvent.StandardEvent == AnalyticsStandardEvent.Purchase)
            {
                LogPurchase(analyticsEvent);
                return;
            }

            Send(analyticsEvent.Name, analyticsEvent.Parameters);

            string standardName = ResolveStandardName(analyticsEvent);

            if (!string.IsNullOrEmpty(standardName) && !string.Equals(standardName, analyticsEvent.Name, StringComparison.Ordinal))
                Send(standardName, CreateStandardParameters(analyticsEvent));
        }

        private void LogPurchase(AnalyticsEvent analyticsEvent)
        {
            if (!logAppleTransactions)
            {
                Send(StandardInAppPurchase, analyticsEvent.Parameters);
                return;
            }

            analyticsEvent.Parameters.TryGetValue("transaction_id", out object value);
            string transactionId = ToInvariantString(value);

            if (string.IsNullOrWhiteSpace(transactionId))
            {
                Debug.LogWarning("[FirebaseAnalyticsProvider] Apple purchase log skipped: transaction ID is missing.");
                return;
            }

            client.LogAppleTransaction(transactionId);
        }

        private void Send(string name, IReadOnlyDictionary<string, object> parameters)
        {
            client.LogEvent(NormalizeName(name), ToSdkValues(parameters));
        }

        private static string ResolveStandardName(AnalyticsEvent analyticsEvent)
        {
            switch (analyticsEvent.StandardEvent)
            {
                case AnalyticsStandardEvent.TutorialComplete:
                    return StandardTutorialComplete;

                case AnalyticsStandardEvent.LevelAchieved:
                    return IsLevelEnd(analyticsEvent.Parameters) ? StandardLevelEnd : StandardLevelUp;

                case AnalyticsStandardEvent.AchievementUnlocked:
                    return StandardUnlockAchievement;

                case AnalyticsStandardEvent.VirtualCurrencySpent:
                    return StandardSpendVirtualCurrency;

                default:
                    return string.Empty;
            }
        }

        // Firebase separates finishing a level from gaining one. The parameters tell which one this is.
        private static bool IsLevelEnd(IReadOnlyDictionary<string, object> parameters)
        {
            for (int i = 0; i < LevelEndKeys.Length; i++)
            {
                if (parameters.TryGetValue(LevelEndKeys[i], out object value) && value != null)
                    return true;
            }

            return false;
        }

        private static Dictionary<string, object> CreateStandardParameters(AnalyticsEvent analyticsEvent)
        {
            Dictionary<string, object> result = new Dictionary<string, object>();

            foreach (KeyValuePair<string, object> pair in analyticsEvent.Parameters)
                result[pair.Key] = pair.Value;

            switch (analyticsEvent.StandardEvent)
            {
                case AnalyticsStandardEvent.TutorialComplete:
                    SetFirstValue(result, "tutorial_name", analyticsEvent.Parameters, TutorialNameKeys);
                    break;

                case AnalyticsStandardEvent.LevelAchieved:
                    SetFirstValue(result, "level_name", analyticsEvent.Parameters, LevelEndKeys);
                    break;

                case AnalyticsStandardEvent.AchievementUnlocked:
                    SetFirstValue(result, "achievement_id", analyticsEvent.Parameters, AchievementIdKeys);
                    break;

                case AnalyticsStandardEvent.VirtualCurrencySpent:
                    SetFirstValue(result, "item_name", analyticsEvent.Parameters, ItemNameKeys);
                    SetFirstValue(result, "virtual_currency_name", analyticsEvent.Parameters, VirtualCurrencyNameKeys);
                    SetFirstValue(result, "value", analyticsEvent.Parameters, SpentValueKeys);
                    break;
            }

            return result;
        }

        private static void SetFirstValue(
            Dictionary<string, object> target,
            string targetKey,
            IReadOnlyDictionary<string, object> source,
            string[] sourceKeys)
        {
            for (int i = 0; i < sourceKeys.Length; i++)
            {
                if (source.TryGetValue(sourceKeys[i], out object value) && value != null)
                {
                    target[targetKey] = value;
                    return;
                }
            }
        }

        private static List<KeyValuePair<string, object>> ToSdkValues(IReadOnlyDictionary<string, object> parameters)
        {
            List<KeyValuePair<string, object>> result = new List<KeyValuePair<string, object>>(parameters.Count);

            foreach (KeyValuePair<string, object> pair in parameters)
            {
                string key = NormalizeName(pair.Key);

                if (!string.IsNullOrEmpty(key))
                    result.Add(new KeyValuePair<string, object>(key, ToSdkValue(pair.Value)));
            }

            return result;
        }

        private static object ToSdkValue(object value)
        {
            switch (value)
            {
                case null:
                    return string.Empty;
                case int intValue:
                    return (long)intValue;
                case long longValue:
                    return longValue;
                case float floatValue:
                    return (double)floatValue;
                case double doubleValue:
                    return doubleValue;
                case decimal decimalValue:
                    return (double)decimalValue;
                case bool boolValue:
                    return boolValue ? 1L : 0L;
                default:
                    return ToInvariantString(value);
            }
        }

        private static string NormalizeName(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            string result = value.Trim();
            return result.Length > MaxNameLength ? result.Substring(0, MaxNameLength) : result;
        }

        private static string ToInvariantString(object value)
        {
            if (value == null)
                return string.Empty;

            return value is IFormattable formattable
                ? formattable.ToString(null, CultureInfo.InvariantCulture)
                : value.ToString();
        }
    }
}
