# Changelog

## 0.1.0-pre.1 - 2026-11-08

Initial package, redesigned from the mobile library's `FirebaseAnalyticsSink`, `FirebaseTelemetryBridge` and `FirebaseAnalyticsManager`. SDK format conversion moved here. Crashlytics is not part of this package.

Changed from the source:

- Whether an event reaches Firebase is now the project's `filter`. Ad revenue and Google Play purchases are sent unless a filter keeps them out.
- `#if UNITY_IOS && !ONE_STORE` became the `logAppleTransactions` option, set by the project.
- `LevelAchieved` chooses `level_end` or `level_up` from its parameters.
- `FirebaseManager.IsInitialized` is no longer checked. The project adds the provider after Firebase is ready.
- The Editor logs and no longer calls the SDK, so the package compiles without Firebase.
- The separate `LogLegacyEvent` path is gone. All events use one conversion, so a bool is sent as 1 or 0 and names are trimmed.

Compiled against Firebase 13.17.0 outside Unity. Unity Host results, run without the SDK, are in `Docs/PlatformAdsAnalytics/AnalyticsReport.md`. A Player build is NOT_RUN.
