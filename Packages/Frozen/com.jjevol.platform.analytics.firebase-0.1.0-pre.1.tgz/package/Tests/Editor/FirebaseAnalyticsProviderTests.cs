using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Analytics.Firebase.Tests
{
    public sealed class FirebaseAnalyticsProviderTests
    {
        private sealed class RecordingClient : IFirebaseAnalyticsClient
        {
            public readonly List<string> Names = new List<string>();
            public readonly List<Dictionary<string, object>> Parameters = new List<Dictionary<string, object>>();
            public readonly List<string> AppleTransactions = new List<string>();
            public readonly List<bool> CollectionCalls = new List<bool>();

            public void SetCollectionEnabled(bool enabled) => CollectionCalls.Add(enabled);

            public void LogEvent(string name, IReadOnlyList<KeyValuePair<string, object>> parameters)
            {
                Names.Add(name);
                Dictionary<string, object> values = new Dictionary<string, object>();

                for (int i = 0; i < parameters.Count; i++)
                    values.Add(parameters[i].Key, parameters[i].Value);

                Parameters.Add(values);
            }

            public void LogAppleTransaction(string transactionId) => AppleTransactions.Add(transactionId);
        }

        private RecordingClient client;
        private FirebaseAnalyticsProvider provider;

        [SetUp]
        public void CreateProvider()
        {
            client = new RecordingClient();
            provider = new FirebaseAnalyticsProvider(client);
        }

        [TearDown]
        public void ResetManager()
        {
            AnalyticsManager.Clear();
            AnalyticsManager.SetCollectionEnabled(true);
        }

        private static AnalyticsEvent Event(string name, AnalyticsStandardEvent standardEvent, params (string Key, object Value)[] parameters)
        {
            Dictionary<string, object> values = new Dictionary<string, object>();

            foreach ((string key, object value) in parameters)
                values[key] = value;

            return new AnalyticsEvent(name, standardEvent, values);
        }

        [Test]
        public void PlainEventIsSentOnce()
        {
            provider.Log(Event("use_ticket", AnalyticsStandardEvent.None, ("season_id", 3)));

            Assert.That(client.Names, Is.EqualTo(new[] { "use_ticket" }));
            Assert.That(client.Parameters[0]["season_id"], Is.EqualTo(3L));
        }

        [Test]
        public void TutorialCompleteAddsTheStandardEvent()
        {
            provider.Log(Event("tuto_2", AnalyticsStandardEvent.TutorialComplete, ("tutorial_group_id", 2), ("success", 1)));

            Assert.That(client.Names, Is.EqualTo(new[] { "tuto_2", "tutorial_complete" }));
            Assert.That(client.Parameters[1]["tutorial_name"], Is.EqualTo(2L));
            Assert.That(client.Parameters[1]["success"], Is.EqualTo(1L));
            Assert.That(client.Parameters[0].ContainsKey("tutorial_name"), Is.False);
        }

        [Test]
        public void TutorialNameWinsOverTheGroupId()
        {
            provider.Log(Event("tuto_2", AnalyticsStandardEvent.TutorialComplete, ("tutorial_name", "group_2"), ("tutorial_group_id", 2)));

            Assert.That(client.Parameters[1]["tutorial_name"], Is.EqualTo("group_2"));
        }

        [Test]
        public void LevelAchievedWithStageParametersIsLevelEnd()
        {
            provider.Log(Event("stage_clear", AnalyticsStandardEvent.LevelAchieved, ("stage", 10), ("success", 1)));

            Assert.That(client.Names, Is.EqualTo(new[] { "stage_clear", "level_end" }));
            Assert.That(client.Parameters[1]["level_name"], Is.EqualTo(10L));
            Assert.That(client.Parameters[1]["success"], Is.EqualTo(1L));
        }

        [Test]
        public void LevelNameWinsOverStageIdAndStage()
        {
            provider.Log(Event("stage_1_2", AnalyticsStandardEvent.LevelAchieved, ("level_name", "stage_1_2"), ("stage_id", 100), ("stage", 2)));

            Assert.That(client.Parameters[1]["level_name"], Is.EqualTo("stage_1_2"));
        }

        [Test]
        public void StageIdWinsOverStage()
        {
            provider.Log(Event("clear", AnalyticsStandardEvent.LevelAchieved, ("stage_id", 100), ("stage", 2)));

            Assert.That(client.Parameters[1]["level_name"], Is.EqualTo(100L));
        }

        [Test]
        public void LevelAchievedWithLevelParameterIsLevelUp()
        {
            provider.Log(Event("lv_5", AnalyticsStandardEvent.LevelAchieved, ("level", 5), ("level_type", "account")));

            Assert.That(client.Names, Is.EqualTo(new[] { "lv_5", "level_up" }));
            Assert.That(client.Parameters[1]["level"], Is.EqualTo(5L));
            Assert.That(client.Parameters[1]["level_type"], Is.EqualTo("account"));
        }

        [Test]
        public void AchievementUnlockedAddsTheStandardEvent()
        {
            provider.Log(Event("startquest_3", AnalyticsStandardEvent.AchievementUnlocked, ("achievement_id", "startquest_3"), ("quest_id", 30)));

            Assert.That(client.Names, Is.EqualTo(new[] { "startquest_3", "unlock_achievement" }));
            Assert.That(client.Parameters[1]["achievement_id"], Is.EqualTo("startquest_3"));
        }

        [Test]
        public void AchievementIdFallsBackToQuestThenCharacter()
        {
            provider.Log(Event("quest", AnalyticsStandardEvent.AchievementUnlocked, ("quest_id", 30), ("character_id", 7)));
            provider.Log(Event("character", AnalyticsStandardEvent.AchievementUnlocked, ("character_id", 7)));

            Assert.That(client.Parameters[1]["achievement_id"], Is.EqualTo(30L));
            Assert.That(client.Parameters[3]["achievement_id"], Is.EqualTo(7L));
            Assert.That(client.Parameters[0].ContainsKey("achievement_id"), Is.False);
        }

        [Test]
        public void VirtualCurrencySpentAddsTheStandardEvent()
        {
            provider.Log(Event("buy_product_7", AnalyticsStandardEvent.VirtualCurrencySpent,
                ("item_name", "7"), ("virtual_currency_name", "gem"), ("value", 300)));

            Assert.That(client.Names, Is.EqualTo(new[] { "buy_product_7", "spend_virtual_currency" }));
            Assert.That(client.Parameters[1]["item_name"], Is.EqualTo("7"));
            Assert.That(client.Parameters[1]["virtual_currency_name"], Is.EqualTo("gem"));
            Assert.That(client.Parameters[1]["value"], Is.EqualTo(300L));
        }

        [Test]
        public void VirtualCurrencySpentFallsBackToProductAndPriceParameters()
        {
            provider.Log(Event("buy_product_7", AnalyticsStandardEvent.VirtualCurrencySpent, ("product_id", 7), ("price_id", 2), ("price_value", 300)));

            Assert.That(client.Parameters[1]["item_name"], Is.EqualTo(7L));
            Assert.That(client.Parameters[1]["virtual_currency_name"], Is.EqualTo(2L));
            Assert.That(client.Parameters[1]["value"], Is.EqualTo(300L));
        }

        [Test]
        public void EventAlreadyNamedLikeTheStandardEventIsSentOnce()
        {
            provider.Log(Event("level_up", AnalyticsStandardEvent.LevelAchieved, ("level", 5)));

            Assert.That(client.Names, Is.EqualTo(new[] { "level_up" }));
        }

        [Test]
        public void PurchaseIsSentAsInAppPurchaseOnly()
        {
            provider.Log(Event("buy_product_7", AnalyticsStandardEvent.Purchase, ("transaction_id", "order"), ("value", 4.99d), ("currency", "USD")));

            Assert.That(client.Names, Is.EqualTo(new[] { "in_app_purchase" }));
            Assert.That(client.Parameters[0]["transaction_id"], Is.EqualTo("order"));
            Assert.That(client.Parameters[0]["value"], Is.EqualTo(4.99d));
            Assert.That(client.AppleTransactions, Is.Empty);
        }

        [Test]
        public void AppleTransactionModeSendsTheTransactionInsteadOfAnEvent()
        {
            provider = new FirebaseAnalyticsProvider(client, logAppleTransactions: true);

            provider.Log(Event("buy_product_7", AnalyticsStandardEvent.Purchase, ("transaction_id", "order")));

            Assert.That(client.AppleTransactions, Is.EqualTo(new[] { "order" }));
            Assert.That(client.Names, Is.Empty);
        }

        [Test]
        public void AppleTransactionModeSkipsAMissingTransaction()
        {
            provider = new FirebaseAnalyticsProvider(client, logAppleTransactions: true);

            LogAssert.Expect(LogType.Warning, "[FirebaseAnalyticsProvider] Apple purchase log skipped: transaction ID is missing.");
            provider.Log(Event("buy_product_7", AnalyticsStandardEvent.Purchase, ("transaction_id", " ")));

            Assert.That(client.AppleTransactions, Is.Empty);
            Assert.That(client.Names, Is.Empty);
        }

        [Test]
        public void AppleTransactionModeLeavesOtherEventsAlone()
        {
            provider = new FirebaseAnalyticsProvider(client, logAppleTransactions: true);

            provider.Log(Event("use_ticket", AnalyticsStandardEvent.None));

            Assert.That(client.Names, Is.EqualTo(new[] { "use_ticket" }));
        }

        [Test]
        public void AdRewardAndAdRevenueHaveNoStandardEvent()
        {
            provider.Log(Event("ad_revive", AnalyticsStandardEvent.AdReward, ("placement", "revive")));
            provider.Log(Event("ad_revenue_paid", AnalyticsStandardEvent.AdRevenue, ("value", 0.1d)));

            Assert.That(client.Names, Is.EqualTo(new[] { "ad_revive", "ad_revenue_paid" }));
        }

        [Test]
        public void ParameterValuesBecomeStringLongOrDouble()
        {
            provider.Log(Event("types", AnalyticsStandardEvent.None,
                ("int", 1), ("long", 2L), ("float", 1.5f), ("double", 2.5d), ("decimal", 3.5m),
                ("true", true), ("false", false), ("null", null), ("short", (short)4), ("text", "value")));

            Dictionary<string, object> values = client.Parameters[0];
            Assert.That(values["int"], Is.EqualTo(1L).And.TypeOf<long>());
            Assert.That(values["long"], Is.EqualTo(2L).And.TypeOf<long>());
            Assert.That(values["float"], Is.EqualTo(1.5d).And.TypeOf<double>());
            Assert.That(values["double"], Is.EqualTo(2.5d).And.TypeOf<double>());
            Assert.That(values["decimal"], Is.EqualTo(3.5d).And.TypeOf<double>());
            Assert.That(values["true"], Is.EqualTo(1L).And.TypeOf<long>());
            Assert.That(values["false"], Is.EqualTo(0L).And.TypeOf<long>());
            Assert.That(values["null"], Is.EqualTo(string.Empty));
            Assert.That(values["short"], Is.EqualTo("4"));
            Assert.That(values["text"], Is.EqualTo("value"));
        }

        [Test]
        public void NamesAreTrimmedAndCutToFortyCharacters()
        {
            string longName = new string('a', 50);

            provider.Log(Event("  " + longName, AnalyticsStandardEvent.None, (" " + longName + " ", 1), ("   ", 2)));

            Assert.That(client.Names[0], Is.EqualTo(new string('a', 40)));
            Assert.That(client.Parameters[0].Count, Is.EqualTo(1));
            Assert.That(client.Parameters[0][new string('a', 40)], Is.EqualTo(1L));
        }

        [Test]
        public void EmptyNameIsIgnored()
        {
            provider.Log(Event(string.Empty, AnalyticsStandardEvent.TutorialComplete));
            provider.Log(null);

            Assert.That(client.Names, Is.Empty);
        }

        [Test]
        public void CollectionOffIsForwardedAndBlocksEvents()
        {
            provider.SetCollectionEnabled(false);
            provider.Log(Event("off", AnalyticsStandardEvent.None));
            provider.SetCollectionEnabled(true);
            provider.Log(Event("on", AnalyticsStandardEvent.None));

            Assert.That(provider.IsEnabled, Is.True);
            Assert.That(client.CollectionCalls, Is.EqualTo(new[] { false, true }));
            Assert.That(client.Names, Is.EqualTo(new[] { "on" }));
        }

        [Test]
        public void PublicConstructorRunsInTheEditorWithoutTheSdk()
        {
            FirebaseAnalyticsProvider sdkProvider = new FirebaseAnalyticsProvider(logAppleTransactions: true);

            sdkProvider.SetCollectionEnabled(true);
            sdkProvider.Log(Event("use_ticket", AnalyticsStandardEvent.None, ("season_id", 3)));
            sdkProvider.Log(Event("buy", AnalyticsStandardEvent.Purchase, ("transaction_id", "order")));

            Assert.That(sdkProvider.IsEnabled, Is.True);
        }

        [Test]
        public void AddProviderTurnsCollectionOnAndFilterKeepsPurchasesOut()
        {
            AnalyticsManager.AddProvider(provider, e => e.StandardEvent != AnalyticsStandardEvent.Purchase);

            AnalyticsManager.LogPurchase("buy", "order", 1d, "USD");
            AnalyticsManager.Log("stage_clear", AnalyticsStandardEvent.LevelAchieved, ("stage", 10));

            Assert.That(client.CollectionCalls, Is.EqualTo(new[] { true }));
            Assert.That(client.Names, Is.EqualTo(new[] { "stage_clear", "level_end" }));
        }
    }
}
