# Changelog

## 0.1.0-pre.7 - 2026-11-19

- `PriceLabel`·`PriceBtn`·`ResourceLabel`의 수량이 `UIRuntimeOptions.NumberFormat`을 따른다. 설정하지 않으면 지금처럼 N0다. 라벨별 덮어쓰기는 `SetNumberFormat(profile)`(null이면 게임 설정으로 돌아감)과 Inspector 필드(`overrideNumberFormat`, PriceLabel `numberFormat`, ResourceLabel `numberProfile`)다. `ResourceLabel.numberFormat`이 N0이 아닌 .NET 서식이면 그 서식이 게임 프로필보다 먼저다. ResourceLabel의 덮어쓰기는 연결한 `NumberAnimator`에도 넘긴다. `numberFormat`을 빈 문자열로 둔 ResourceLabel은 이제 `ToString("")`(구분자 없음)이 아니라 게임 프로필(기본 N0)로 쓴다. `SetNumberFormat`은 받은 프로필의 복사본을 저장한다.
- `com.jjevol.ui` 0.1.0-pre.4, `com.jjevol.ui.contracts` 0.1.0-pre.2에 의존한다. Runtime·시험 asmdef가 `JJEvol.UI.Contracts.Runtime`을 참조한다.

## 0.1.0-pre.6 - 2026-11-11

- Depends on UI Addressables 0.1.0-pre.6, which brings `com.jjevol.ui.contracts`. No source change.

## 0.1.0-pre.5 - 2026-11-08

- Depends on `com.jjevol.economy@0.1.0-pre.4`. The repository now comes from `com.jjevol.data`; the Runtime and test assemblies reference `JJEvol.Data.Runtime`. No UI source change.

Unity compile and the 29 PlayMode tests passed on Hosts/UiEconomyValidationHost (job ui-economy-1, candidate 68e3857).

## 0.1.0-pre.4 - 2026-11-07

- Breaking: removed the `PriceBtn` `commonButton` field. Assign the Unity `Button` to `button`, or a `UIButtonLock` to `buttonLock` with the `lockedState` to show.

## 0.1.0-pre.3 - 2026-11-06

- Updated internal dependency versions. No source change.

Unity tests for this candidate are NOT_RUN.
