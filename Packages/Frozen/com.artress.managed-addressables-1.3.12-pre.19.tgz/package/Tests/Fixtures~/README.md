# Revision Host

Unity does not compile this folder. It holds a small project template and one script that runs the checks a normal test Host cannot.

```powershell
powershell -ExecutionPolicy Bypass -File Tests/Fixtures~/Run-RevisionHost.ps1 -Package <candidate.tgz> -WorkRoot <short-new-folder>
```

Without `-Package` it uses this package folder. Without `-WorkRoot` it uses a new temp folder. Keep the work path short on Windows; SDK output hits the 260-character limit. Close other Unity Editors first.

The script makes `H` (the Host), `S` (the local host folder) and `R` (logs and results) in the work folder. The Players are not in the work folder: they are rebuilt over a fixed slot, `<PlayerRoot>/<slot>/Chain/ManagedChain.exe` and `<PlayerRoot>/<slot>/Batch/ManagedChainBatch.exe`, so Windows Firewall asks once per path instead of once per run. `-PlayerRoot` defaults to `.local/qa-player` in the main checkout, shared by its worktrees. There are two slots, `1` and `2`. A runner script job holds the whole machine, so it always gets slot `1`; slot `2` covers a second run started by hand. A run holds `<slot>.lock` open until it ends and takes the first free slot, and a third run at once is refused. The slot is emptied before the build; logs and results stay per run in `R`, and `R/summary.json` names the slot used.

It then runs:

| Step | What it proves |
|---|---|
| `editor` | All Editor tests except the restart case, with Localization and the Host marker present, so the real SDK cases run instead of skipping |
| `runtime` | All PlayMode tests |
| `chain` | `ManagedOfficialChainTests`: Sync, roles and release values, then App Build (`ManagedAppBuild.Build`) with its real Player step: sequence 2, Revision, packaged A and a Development Player, all from an empty project. Then Revision content changes to B, B is built with sequence 3 and published to `S` |
| `first` | A real Player starts offline, copies A to app storage and confirms it |
| `second` | The same Player starts again on the confirmed Revision |
| `remote` | `Serve-LocalHost.ps1` serves `S` on 127.0.0.1. The same Player reads the pointer, downloads B, applies and confirms it |
| `after-remote` | With the server stopped, the Player starts on B from app storage, not the older packaged A |
| `batch` | App Build through `-executeMethod Artress.ManagedAddressables.Editor.ManagedAppBuild.BuildFromCommandLine -managedAppOutput <slot>/Batch/ManagedChainBatch.exe -managedAppDevelopment`, as a build machine runs it. It must exit 0 and log the App Build success line; the step lines in `R/batch.log` show the sequence it took |
| `batch-first` | The batch Player starts on its own packaged A, which is newer than the stored B |

`R/summary.json` records the package SHA-256, the counts and the Player results. The work folder is disposable.

The remote steps use plain http on loopback, which only a Development Player with `allowDevelopmentHttp` accepts. Android, iOS, HTTPS and Vendor adapters are outside this run.

`Serve-LocalHost.ps1 -Root <folder> -Port <port>` also serves a folder for a manual device test. For an Android device, run `adb reverse tcp:<port> tcp:<port>` so the device's 127.0.0.1 reaches this PC.

`ManagedFrameworkRestartTests` needs two Unity processes and the Runner packages, so it stays on `Hosts/ManagedAddressablesValidationHost`.
