# Builds a disposable Unity project around one package and runs what needs a real SDK build or Player.
# Nothing here depends on this machine: pass -Unity and -WorkRoot where they differ.
param(
    [string]$Package = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),   # .tgz or package folder
    [string]$Unity = 'C:\Program Files\Unity\Hub\Editor\6000.3.9f1\Editor\Unity.exe',
    [string]$WorkRoot = (Join-Path ([IO.Path]::GetTempPath()) ('rh-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))),
    [int]$UnitySeconds = 1800,
    [int]$PlayerSeconds = 120,
    # Players are rebuilt at fixed paths so Windows Firewall asks once per path, not once per run.
    # Default: <main checkout>/.local/qa-player, shared by every worktree of this repository.
    [string]$PlayerRoot = ''
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (!(Test-Path -LiteralPath $Unity)) { throw "Unity not found: $Unity" }
if (!(Test-Path -LiteralPath $Package)) { throw "Package not found: $Package" }
if (Test-Path -LiteralPath $WorkRoot) { throw "Use a new work folder: $WorkRoot" }
if (Get-Process -Name Unity -ErrorAction SilentlyContinue) { throw 'Another Unity is running. Close it first.' }

$WorkRoot = [IO.Path]::GetFullPath($WorkRoot)
if (!$PlayerRoot) {
    $common = $null
    try { $common = & git -C $PSScriptRoot rev-parse --path-format=absolute --git-common-dir 2>$null; if ($LASTEXITCODE -ne 0) { $common = $null } } catch { $common = $null }
    $PlayerRoot = if ($common) { Join-Path (Split-Path -Parent ([IO.Path]::GetFullPath($common))) '.local/qa-player' }
        else { Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'JJEvol/qa-player' }
}
$PlayerRoot = [IO.Path]::GetFullPath($PlayerRoot)
New-Item -ItemType Directory -Path $PlayerRoot -Force | Out-Null

# Two slots, as many as the runner's Unity slots. A slot is held by an open lock file for the whole run;
# the OS lets it go when this process ends, however it ends.
$slotLock = $null
foreach ($candidate in '1', '2') {
    try { $slotLock = [IO.File]::Open((Join-Path $PlayerRoot "$candidate.lock"), 'OpenOrCreate', 'ReadWrite', 'None'); $slot = $candidate; break }
    catch [IO.IOException] { }
}
if (!$slotLock) { throw "Both Player slots are in use: $PlayerRoot" }
$slotRoot = Join-Path $PlayerRoot $slot
$exe = [IO.Path]::GetFullPath((Join-Path $slotRoot 'Chain/ManagedChain.exe'))
$batchExe = [IO.Path]::GetFullPath((Join-Path $slotRoot 'Batch/ManagedChainBatch.exe'))
# The previous run's Player files would read as stale output to App Build: empty the slot, keep the paths.
foreach ($path in $exe, $batchExe) {
    $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -eq $path } catch { $false } })
    if ($running.Count) { $slotLock.Dispose(); throw "A Player from an earlier run is still running: $path" }
    $folder = Split-Path -Parent $path
    if (Test-Path -LiteralPath $folder) { Remove-Item -LiteralPath $folder -Recurse -Force }
}
$hostRoot = Join-Path $WorkRoot 'H'
$results = Join-Path $WorkRoot 'R'
New-Item -ItemType Directory -Path $results -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'RevisionHost') -Destination $hostRoot -Recurse
New-Item -ItemType Directory -Path (Join-Path $hostRoot 'Packages') -Force | Out-Null
$packagePath = [IO.Path]::GetFullPath($Package).Replace('\', '/')
$manifest = [ordered]@{
    dependencies = [ordered]@{
        'com.unity.addressables'           = '4.0.1'
        'com.unity.localization'           = '1.5.12'
        'com.unity.test-framework'         = '1.6.0'
        'com.unity.nuget.newtonsoft-json'  = '3.2.2'
        'com.unity.modules.imgui'          = '1.0.0'
        'com.artress.managed-addressables' = "file:$packagePath"
    }
    testables = @('com.artress.managed-addressables')
}
[IO.File]::WriteAllText((Join-Path $hostRoot 'Packages/manifest.json'), ($manifest | ConvertTo-Json -Depth 4))

function Invoke-Unity([string]$Name, [string[]]$Arguments) {
    $log = Join-Path $results "$Name.log"
    $xml = Join-Path $results "$Name.xml"
    $all = @('-batchmode', '-nographics', '-job-worker-count', '2', '-buildTarget', 'Win64', '-projectPath', $hostRoot,
        '-logFile', $log, '-runTests', '-testResults', $xml) + $Arguments
    $process = Start-Process -FilePath $Unity -ArgumentList ($all | ForEach-Object { '"' + $_ + '"' }) -WindowStyle Hidden -PassThru
    if (!$process.WaitForExit($UnitySeconds * 1000)) { $process.Kill(); throw "Unity timed out: $log" }
    if (!(Test-Path -LiteralPath $xml)) { throw "No test results (exit $($process.ExitCode)): $log" }
    [xml]$report = Get-Content -LiteralPath $xml -Raw
    $run = $report.'test-run'
    $row = [ordered]@{ Name = $Name; Total = [int]$run.total; Passed = [int]$run.passed; Failed = [int]$run.failed; Skipped = [int]$run.skipped; Exit = $process.ExitCode
        NotPassed = @($report.SelectNodes('//test-case[@result!="Passed"]') | ForEach-Object { $_.result + ': ' + $_.fullname }) }
    Write-Host ("{0}: {1} passed, {2} failed, {3} skipped of {4}" -f $Name, $row.Passed, $row.Failed, $row.Skipped, $row.Total)
    return $row
}

# A build machine's call: -executeMethod with no test runner. The method exits Unity itself.
function Invoke-UnityMethod([string]$Name, [string]$Method, [string[]]$Arguments) {
    $log = Join-Path $results "$Name.log"
    $all = @('-batchmode', '-nographics', '-job-worker-count', '2', '-buildTarget', 'Win64', '-projectPath', $hostRoot,
        '-logFile', $log, '-executeMethod', $Method) + $Arguments
    $process = Start-Process -FilePath $Unity -ArgumentList ($all | ForEach-Object { '"' + $_ + '"' }) -WindowStyle Hidden -PassThru
    if (!$process.WaitForExit($UnitySeconds * 1000)) { $process.Kill(); throw "Unity timed out: $log" }
    $text = if (Test-Path -LiteralPath $log) { Get-Content -LiteralPath $log -Raw -Encoding UTF8 } else { '' }
    # The result line is in the Editor language the user chose.
    $succeeded = $text.Contains('[ManagedAppBuild] App Build succeeded') -or $text.Contains("[ManagedAppBuild] $([char]0xC571) $([char]0xBE4C)$([char]0xB4DC) $([char]0xC644)$([char]0xB8CC)")
    $row = [ordered]@{ Name = $Name; Exit = $process.ExitCode; Succeeded = $succeeded }
    Write-Host ("{0}: exit {1}" -f $Name, $row.Exit)
    return $row
}

function Invoke-Player([string]$Exe, [string]$Name, [string[]]$Extra = @()) {
    $json = Join-Path $results "$Name.json"
    $arguments = @('-batchmode', '-nographics', '-logFile', ('"' + (Join-Path $results "$Name.log") + '"'), '-chainResult', ('"' + $json + '"')) + $Extra
    $process = Start-Process -FilePath $Exe -ArgumentList $arguments -WindowStyle Hidden -PassThru
    if (!$process.WaitForExit($PlayerSeconds * 1000)) { $process.Kill(); throw "Player timed out: $Name" }
    if (!(Test-Path -LiteralPath $json)) { throw "Player wrote no result (exit $($process.ExitCode)): $Name" }
    $result = Get-Content -LiteralPath $json -Raw | ConvertFrom-Json
    if (!$result.success) { throw "Player failed: $Name / $($result.error)" }
    return $result
}

# The local host stands in for the game server: a folder (S) and a loopback static server over it.
$serveRoot = Join-Path $WorkRoot 'S'
New-Item -ItemType Directory -Path $serveRoot -Force | Out-Null
$probe = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0); $probe.Start(); $port = $probe.LocalEndpoint.Port; $probe.Stop()
$pointerFile = Join-Path $results 'pointer.txt'
$server = $null
function Start-LocalHost {
    $ready = Join-Path $results 'server.ready'
    if (Test-Path -LiteralPath $ready) { Remove-Item -LiteralPath $ready }
    $script:server = Start-Process -FilePath 'powershell' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"' + (Join-Path $PSScriptRoot 'Serve-LocalHost.ps1') + '"'),
        '-Root', ('"' + $serveRoot + '"'), '-Port', $port, '-ReadyFile', ('"' + $ready + '"')) -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput (Join-Path $results 'server.log') -RedirectStandardError (Join-Path $results 'server.err.log')
    for ($i = 0; $i -lt 100 -and !(Test-Path -LiteralPath $ready); $i++) { Start-Sleep -Milliseconds 100 }
    if (!(Test-Path -LiteralPath $ready)) { throw 'The local host server did not start.' }
}
function Stop-LocalHost { if ($script:server -and !$script:server.HasExited) { Stop-Process -Id $script:server.Id -Force; $script:server.WaitForExit() } }

$summary = [ordered]@{ Package = $packagePath; PackageSha256 = $null; Unity = (Get-Item -LiteralPath $Unity).VersionInfo.ProductVersion; Runs = @(); Player = $null
    PlayerSlot = [ordered]@{ Slot = $slot; Chain = $exe; Batch = $batchExe }; Status = 'FAIL' }
if (Test-Path -LiteralPath $Package -PathType Leaf) { $summary.PackageSha256 = (Get-FileHash -LiteralPath $Package -Algorithm SHA256).Hash }
$summaryPath = Join-Path $results 'summary.json'
try {
    $summary.Runs += Invoke-Unity 'editor' @('-testPlatform', 'EditMode', '-assemblyNames', 'Artress.ManagedAddressables.Editor.Tests', '-testFilter', '!Artress.ManagedAddressables.Editor.Tests.ManagedFrameworkRestartTests')
    $summary.Runs += Invoke-Unity 'runtime' @('-testPlatform', 'PlayMode', '-assemblyNames', 'Artress.ManagedAddressables.Runtime.Tests')

    $env:MANAGED_CHAIN_PLAYER = $exe
    $env:MANAGED_CHAIN_PRODUCT = 'ManagedChain-' + (Split-Path -Leaf $WorkRoot)
    $env:MANAGED_CHAIN_HOST_URL = "http://127.0.0.1:$port"
    $env:MANAGED_CHAIN_HOST_ROOT = $serveRoot
    $env:MANAGED_CHAIN_POINTER_FILE = $pointerFile
    $summary.Runs += Invoke-Unity 'chain' @('-testPlatform', 'EditMode', '-testFilter', 'Artress.ManagedAddressables.Editor.Tests.ManagedOfficialChainTests')
    if (@($summary.Runs | Where-Object { $_.Failed -ne 0 -or $_.Exit -ne 0 -or $_.Passed -eq 0 }).Count) { throw 'Unity runs failed.' }
    # Only the chain case may skip in the editor run: a skipped SDK case means the Host lost its fixture.
    $chainCase = 'Skipped: Artress.ManagedAddressables.Editor.Tests.ManagedOfficialChainTests.GuideStepsBuildAPlayerWithItsPackagedRevision'
    $allowed = @{ editor = @($chainCase); runtime = @(); chain = @() }
    foreach ($run in $summary.Runs) {
        $unexpected = @($run.NotPassed | Where-Object { $allowed[$run.Name] -notcontains $_ })
        if ($unexpected.Count) { throw "$($run.Name) did not run: $($unexpected -join '; ')" }
    }

    $first = Invoke-Player $exe 'first'
    if ($first.commitOutcome -ne 'Confirmed') { throw "First start did not confirm A: $($first.commitOutcome)" }
    $second = Invoke-Player $exe 'second'
    # A reinstall would report Confirmed again; only a reused Revision has no commit outcome.
    if ($second.revisionId -ne $first.revisionId -or $second.commitOutcome) { throw "Second start did not reuse the confirmed Revision: $($second.commitOutcome)" }

    # Remote B through the local host, on the same Player: download, apply, confirm.
    if (!(Test-Path -LiteralPath $pointerFile)) { throw 'The chain run published no Revision B.' }
    $pointerUrl = (Get-Content -LiteralPath $pointerFile -Raw).Trim()
    Start-LocalHost
    try { $remote = Invoke-Player $exe 'remote' @('-remotePointer', ('"' + $pointerUrl + '"'), '-expect', 'B') }
    finally { Stop-LocalHost }
    if ($remote.revisionId -ne $first.revisionId) { throw "Remote start did not begin on A: $($remote.revisionId)" }
    if ($remote.remoteCommitOutcome -ne 'Confirmed' -or !$remote.remoteRevisionId -or $remote.remoteRevisionId -eq $first.revisionId) { throw "B was not confirmed: $($remote.remoteCommitOutcome)" }
    if ($remote.remoteDownloadedBytes -le 0) { throw 'B downloaded nothing.' }
    # The server is stopped now: a restart must keep B from app storage, offline, over the older packaged A.
    $after = Invoke-Player $exe 'after-remote' @('-expect', 'B')
    if ($after.revisionId -ne $remote.remoteRevisionId -or $after.commitOutcome) { throw "Restart did not keep B: $($after.revisionId) / $($after.commitOutcome)" }
    $summary.Player = [ordered]@{ First = $first; Second = $second; Remote = $remote; AfterRemote = $after }

    # The batch entry on the same Host: App Build through -executeMethod, then that Player starts on its own packaged A.
    # The chain left this PC's sequence at B's, so this development build takes the next one and is a newer A than B.
    $batch = Invoke-UnityMethod 'batch' 'Artress.ManagedAddressables.Editor.ManagedAppBuild.BuildFromCommandLine' @('-managedAppOutput', $batchExe, '-managedAppDevelopment')
    $summary.Runs += $batch
    if ($batch.Exit -ne 0 -or !$batch.Succeeded) { throw "Batch App Build failed (exit $($batch.Exit)): $(Join-Path $results 'batch.log')" }
    if (!(Test-Path -LiteralPath $batchExe)) { throw "Batch App Build wrote no Player: $batchExe" }
    $batchFirst = Invoke-Player $batchExe 'batch-first' @('-expect', 'B')
    if ($batchFirst.commitOutcome -ne 'Confirmed' -or $batchFirst.revisionId -eq $remote.remoteRevisionId -or $batchFirst.revisionId -eq $first.revisionId) {
        throw "The batch Player did not start on its own packaged A: $($batchFirst.revisionId) / $($batchFirst.commitOutcome)"
    }
    $summary.Player.Batch = $batchFirst
    $summary.Status = 'PASS'
}
finally {
    Stop-LocalHost
    $slotLock.Dispose()
    [IO.File]::WriteAllText($summaryPath, ($summary | ConvertTo-Json -Depth 6))
}
Write-Host "PASS: $summaryPath"
