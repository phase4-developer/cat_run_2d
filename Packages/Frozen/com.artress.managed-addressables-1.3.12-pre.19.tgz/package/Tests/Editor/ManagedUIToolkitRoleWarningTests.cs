using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // UI Toolkit plan stage 3: Preview Build Roles reports, before any build, a ScriptableObject that both roles reach
    // and a Static font that still references its source file.
    public sealed class ManagedUIToolkitRoleWarningTests
    {
        const int Static = 0, Dynamic = 1;

        static string Probe(ManagedBootstrapSplitFixture f, string name, Object reference = null, int mode = Dynamic, Object source = null)
        {
            var probe = ScriptableObject.CreateInstance<ManagedRoleWarningProbe>();
            probe.reference = reference;
            probe.m_AtlasPopulationMode = mode;
            probe.m_SourceFontFile = source;
            string path = f.Root + "/Content/" + name;
            AssetDatabase.CreateAsset(probe, path);
            return path;
        }

        static void Register(ManagedBootstrapSplitFixture f, string path, bool boot, string address) =>
            f.Settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), boot ? f.Boot : f.Revision, false, false).SetAddress(address, false);

        static Object Load(string path) => AssetDatabase.LoadMainAssetAtPath(path);

        [Test]
        public void PreviewBuildRolesWarnsAboutAScriptableObjectBothRolesReach()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Assert.That(f.RolePlan().Warnings.Where(w => w.Contains(f.Root + "/Content/")), Is.Empty, "control: the fixture alone shares nothing");
                string theme = Probe(f, "Theme.asset");
                Register(f, Probe(f, "BootPanel.asset", Load(theme)), true, "qa.panel");
                Register(f, Probe(f, "RevisionScreen.asset", Load(theme)), false, "qa.screen");
                f.Save();

                var plan = f.RolePlan();
                Assert.That(plan.Warnings.Where(w => w.Contains(theme)).ToList(), Has.Count.EqualTo(1), string.Join("\n", plan.Warnings));
                Assert.IsTrue(plan.CanApply, "The early warning must not block the role plan.");

                // The warning predicts the split build's refusal.
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                Assert.That(report.Errors.Where(e => e.Contains(theme)), Is.Not.Empty, report.ToString());
            }
        }

        [Test]
        public void ScriptableObjectUsedByOneRoleOnlyIsNotReported()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                string theme = Probe(f, "Theme.asset");
                Register(f, Probe(f, "BootPanel.asset", Load(theme)), true, "qa.panel");
                Register(f, Probe(f, "BootHud.asset", Load(theme)), true, "qa.hud");
                f.Save();
                var plan = f.RolePlan();
                Assert.That(plan.Warnings.Where(w => w.Contains(theme)), Is.Empty, string.Join("\n", plan.Warnings));
            }
        }

        [Test]
        public void OnlyAStaticFontThatKeepsItsSourceFileIsReported()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var source = Load(f.Root + "/Content/Boot.txt");
                string staticWithSource = Probe(f, "TitleFont.asset", mode: Static, source: source);
                string dynamicWithSource = Probe(f, "BodyFont.asset", mode: Dynamic, source: source);
                string staticCleared = Probe(f, "FixedFont.asset", mode: Static);
                var found = ManagedAddressableBuildExporter.StaticFontsWithSourceFile(new[] { staticWithSource, dynamicWithSource, staticCleared, f.Root + "/Content/Boot.txt" }).ToList();
                Assert.That(found, Is.EqualTo(new[] { staticWithSource }));
            }
        }

        [Test]
        public void PreviewBuildRolesAndTheSplitBuildCheckReportAStaticFontWithItsSourceFile()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                string font = Probe(f, "TitleFont.asset", mode: Static, source: Load(f.Root + "/Content/Boot.txt"));
                Register(f, Probe(f, "BootPanel.asset", Load(font)), true, "qa.panel");
                f.Save();

                var plan = f.RolePlan();
                Assert.That(plan.Warnings.Where(w => w.Contains(font)).ToList(), Has.Count.EqualTo(1), string.Join("\n", plan.Warnings));
                Assert.IsTrue(plan.CanApply);

                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot);
                Assert.That(report.Warnings.Where(w => w.Contains(font)), Is.Not.Empty, report.ToString());
                Assert.That(report.Errors.Where(e => e.Contains(font)), Is.Empty, "A Static font with its source is a warning, not a refusal.");
            }
        }
    }
}
