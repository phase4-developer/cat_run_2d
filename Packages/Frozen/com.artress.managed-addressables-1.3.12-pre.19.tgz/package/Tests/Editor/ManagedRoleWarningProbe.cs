using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // Test-only asset. It holds a reference like a theme or style sheet does, and carries the two
    // font asset fields that the Static font check reads by name (TextCore and TextMesh Pro use the same names).
    public sealed class ManagedRoleWarningProbe : ScriptableObject
    {
        public Object reference;
        [SerializeField] internal int m_AtlasPopulationMode = 1;
        [SerializeField] internal Object m_SourceFontFile;
    }
}
