using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;

namespace Artress.ManagedAddressables.Editor
{
    public static class ManagedAddressNaming
    {
        // UI Toolkit style sheets keep their extension so a screen's UXML (Shop) and its USS (Shop.uss)
        // can sit side by side without the project-wide Include Extension option.
        static readonly string[] ExtensionKeptTypes = { ".uss", ".tss" };

        public static bool KeepsExtension(string assetPath) =>
            ExtensionKeptTypes.Contains(Path.GetExtension(assetPath ?? string.Empty), StringComparer.OrdinalIgnoreCase);

        public static string BuildAddress(string top, string afterTopWithExtension, string assetPath, bool includeExtension, string separator, IEnumerable<string> ignorePathPrefixes)
        {
            includeExtension = includeExtension || KeepsExtension(assetPath);
            string key = (afterTopWithExtension ?? string.Empty).Replace('\\', '/');

            if (ignorePathPrefixes != null)
            {
                string matchedPrefix = null;
                foreach (string ignorePath in ignorePathPrefixes)
                {
                    string normalizedIgnorePath = NormalizePath(ignorePath);
                    if (string.IsNullOrEmpty(normalizedIgnorePath))
                        continue;

                    if (normalizedIgnorePath.Equals(top, StringComparison.OrdinalIgnoreCase))
                        return includeExtension ? Path.GetFileName(assetPath) : Path.GetFileNameWithoutExtension(assetPath);

                    string keyPrefix = normalizedIgnorePath;
                    string topPrefix = NormalizePath(top) + "/";
                    if (normalizedIgnorePath.StartsWith(topPrefix, StringComparison.OrdinalIgnoreCase))
                        keyPrefix = normalizedIgnorePath.Substring(topPrefix.Length);

                    if (key.StartsWith(keyPrefix + "/", StringComparison.OrdinalIgnoreCase) && (matchedPrefix == null || keyPrefix.Length > matchedPrefix.Length))
                        matchedPrefix = keyPrefix;
                }

                if (!string.IsNullOrEmpty(matchedPrefix))
                    key = key.Substring(matchedPrefix.Length + 1);
            }

            if (!includeExtension)
            {
                string extension = Path.GetExtension(key);
                if (!string.IsNullOrEmpty(extension))
                    key = key.Substring(0, key.Length - extension.Length);
            }

            if (string.IsNullOrEmpty(key))
                key = includeExtension ? Path.GetFileName(assetPath) : Path.GetFileNameWithoutExtension(assetPath);

            if (string.IsNullOrEmpty(key))
                key = "Unnamed";

            string actualSeparator = string.IsNullOrEmpty(separator) ? "_" : separator;
            return key.Replace("/", actualSeparator).Replace("\\", actualSeparator);
        }

        public static string FindLongestMatchingPrefix(string assetPath, IEnumerable<string> ignorePathPrefixes)
        {
            if (ignorePathPrefixes == null || string.IsNullOrEmpty(assetPath))
                return string.Empty;

            string normalizedAssetPath = NormalizePath(assetPath);

            return ignorePathPrefixes
                .Select(NormalizePath)
                .Where(prefix => !string.IsNullOrEmpty(prefix) && (normalizedAssetPath.Equals(prefix, StringComparison.OrdinalIgnoreCase) || normalizedAssetPath.StartsWith(prefix + "/", StringComparison.OrdinalIgnoreCase)))
                .OrderByDescending(prefix => prefix.Length)
                .FirstOrDefault() ?? string.Empty;
        }

        public static string EnsureUnique(string address, string assetPath, ISet<string> usedAddresses)
        {
            if (usedAddresses.Add(address))
                return address;

            string suffix = ShortHash(assetPath);
            string candidate = address + "#" + suffix;
            int index = 2;

            while (!usedAddresses.Add(candidate))
                candidate = address + "#" + suffix + "_" + index++;

            return candidate;
        }

        public static string NormalizePath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return string.Empty;

            return string.Join("/", path.Trim().Replace("\\", "/").Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries));
        }

        private static string ShortHash(string value)
        {
            string guid = AssetDatabase.AssetPathToGUID(value ?? string.Empty);
            if (!string.IsNullOrEmpty(guid))
                return guid.Substring(0, Math.Min(8, guid.Length));

            using (MD5 md5 = MD5.Create())
            {
                byte[] hash = md5.ComputeHash(Encoding.UTF8.GetBytes(value ?? string.Empty));
                StringBuilder builder = new StringBuilder(8);
                for (int i = 0; i < 4; i++)
                    builder.Append(hash[i].ToString("x2"));
                return builder.ToString();
            }
        }
    }
}
