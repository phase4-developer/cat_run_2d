using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor
{
    // A draft for Preview Build Roles. It writes nothing.
    internal sealed class ManagedBuildRoleSuggestion
    {
        internal readonly List<ManagedGroupBuildRoleSetting> roles = new List<ManagedGroupBuildRoleSetting>();
        internal readonly List<string> bootKeys = new List<string>();
        internal readonly List<string> undecidedGroups = new List<string>();
    }

    internal static partial class ManagedAddressableSynchronizer
    {
        // Fills in what the content folders already say: Local is Boot, Remote is Revision.
        // Rows and keys already in the draft stay. A Group the folders cannot place stays undecided.
        internal static ManagedBuildRoleSuggestion SuggestBuildRoles(ManagedAddressableProjectConfig config,
            IEnumerable<ManagedGroupBuildRoleSetting> draft, IEnumerable<string> keys)
        {
            var settings = ReadSettingsWithoutMigration();
            if (settings == null) throw new InvalidOperationException("Run Sync first. There are no SDK Settings to suggest roles from.");
            string root = config.ContentRootPath.TrimEnd('/') + "/";
            ManagedGroupBuildRole FolderRole(string path)
            {
                if (path.StartsWith(root + "Local/", StringComparison.OrdinalIgnoreCase)) return ManagedGroupBuildRole.Boot;
                if (path.StartsWith(root + "Remote/", StringComparison.OrdinalIgnoreCase)) return ManagedGroupBuildRole.Revision;
                return ManagedGroupBuildRole.Unassigned;
            }
            var result = new ManagedBuildRoleSuggestion();
            result.roles.AddRange((draft ?? Enumerable.Empty<ManagedGroupBuildRoleSetting>()).Where(r => r != null).Select(r => r.Copy()));
            var known = new HashSet<string>(result.roles.Select(r => r.groupAssetGuid), StringComparer.OrdinalIgnoreCase);
            var groups = settings.groups.Where(g => g != null).OrderBy(g => g.Name, StringComparer.Ordinal)
                .ToDictionary(g => AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(g)), g => g, StringComparer.OrdinalIgnoreCase);
            foreach (var row in groups)
            {
                if (known.Contains(row.Key)) continue;
                var found = row.Value.entries.Select(entry => FolderRole(entry.AssetPath)).Distinct().ToList();
                var role = found.Count == 0 ? ManagedGroupBuildRole.Boot : found.Count == 1 ? found[0] : ManagedGroupBuildRole.Unassigned;
                if (row.Value.ReadOnly || role == ManagedGroupBuildRole.Unassigned) { result.undecidedGroups.Add(row.Value.Name); continue; }
                result.roles.Add(new ManagedGroupBuildRoleSetting { groupAssetGuid = row.Key, role = role });
            }
            foreach (var role in new[] { ManagedGroupBuildRole.Boot, ManagedGroupBuildRole.Revision })
            {
                var rows = result.roles.Where(r => r.role == role).ToList();
                if (rows.Count == 0 || rows.Any(r => r.useForSharedBundles)) continue;
                var target = rows.FirstOrDefault(r => groups.TryGetValue(r.groupAssetGuid, out var group) && group.entries.Count > 0) ?? rows[0];
                target.useForSharedBundles = true;
            }
            result.bootKeys.AddRange((keys ?? Enumerable.Empty<string>()).Where(k => !string.IsNullOrWhiteSpace(k)));
            if (result.bootKeys.Count == 0)
                result.bootKeys.AddRange(result.roles.Where(r => r.role == ManagedGroupBuildRole.Boot && groups.ContainsKey(r.groupAssetGuid))
                    .Select(r => groups[r.groupAssetGuid]).Where(g => g.GetSchema<BundledAssetGroupSchema>()?.IncludeAddressInCatalog != false)
                    .SelectMany(g => g.entries).Where(entry => !AssetDatabase.IsValidFolder(entry.AssetPath))
                    .Select(entry => entry.address).Distinct(StringComparer.Ordinal));
            return result;
        }

        // The form a build role plan saves: lowercase GUIDs in GUID order, and trimmed distinct keys in
        // ordinal order. A draft and the saved Config are the same roles when these forms are equal.
        internal static List<ManagedGroupBuildRoleSetting> NormalizeRoles(IEnumerable<ManagedGroupBuildRoleSetting> roles)
        {
            var result = (roles ?? Enumerable.Empty<ManagedGroupBuildRoleSetting>()).Where(r => r != null).Select(r => r.Copy()).ToList();
            foreach (var role in result) role.groupAssetGuid = (role.groupAssetGuid ?? "").Trim().ToLowerInvariant();
            return result.OrderBy(r => r.groupAssetGuid, StringComparer.Ordinal).ToList();
        }

        internal static List<string> NormalizeBootKeys(IEnumerable<string> keys) =>
            (keys ?? Enumerable.Empty<string>()).Where(k => !string.IsNullOrWhiteSpace(k)).Select(k => k.Trim()).Distinct(StringComparer.Ordinal).OrderBy(k => k, StringComparer.Ordinal).ToList();

        internal static bool SameBuildRoles(ManagedAddressableProjectConfig config, IEnumerable<ManagedGroupBuildRoleSetting> roles, IEnumerable<string> keys) =>
            JsonConvert.SerializeObject(NormalizeRoles(roles)) == JsonConvert.SerializeObject(NormalizeRoles(config.groupBuildRoles)) &&
            NormalizeBootKeys(keys).SequenceEqual(NormalizeBootKeys(config.requiredBootKeys), StringComparer.Ordinal);

        // adoptGroupGuids null adopts every Boot/Revision role Group; an empty list adopts none.
        public static ManagedAddressableSyncPlan CreateBuildRolePlan(ManagedAddressableProjectConfig config,
            IEnumerable<ManagedGroupBuildRoleSetting> roles, IEnumerable<string> keys, IEnumerable<string> adoptGroupGuids = null)
        {
            CheckSyncState(config);
            ValidateSyncPaths(config);
            var settings = ReadSettingsWithoutMigration();
            var blocked = new List<string>();
            var warnings = new List<string>();
            var changes = new List<ManagedAddressableSyncChange>();
            var after = NormalizeRoles(roles);
            var required = NormalizeBootKeys(keys);
            foreach (var role in after)
            {
                if (!Guid.TryParseExact(role.groupAssetGuid, "N", out _)) blocked.Add("Group role requires an explicit Group asset GUID: " + role.groupAssetGuid);
                if (!Enum.IsDefined(typeof(ManagedGroupBuildRole), role.role)) blocked.Add("Unknown role: " + role.groupAssetGuid);
                if (string.IsNullOrEmpty(AssetDatabase.GUIDToAssetPath(role.groupAssetGuid))) warnings.Add("Missing role GUID preserved; remove its row explicitly if no longer needed: " + role.groupAssetGuid);
            }
            if (after.GroupBy(r => r.groupAssetGuid, StringComparer.Ordinal).Any(g => g.Count() > 1)) blocked.Add("Each Group asset GUID can have only one role row.");
            void Diff(string field, string before, string value)
            {
                if (before != value) changes.Add(new ManagedAddressableSyncChange("Global", "Project Config", field, before, value));
            }
            Diff("groupBuildRoles (role is not ownership)", JsonConvert.SerializeObject((config.groupBuildRoles ?? new List<ManagedGroupBuildRoleSetting>()).OrderBy(r => r?.groupAssetGuid, StringComparer.Ordinal)), JsonConvert.SerializeObject(after));
            Diff("requiredBootKeys", JsonConvert.SerializeObject(config.requiredBootKeys ?? new List<string>()), JsonConvert.SerializeObject(required));
            if (settings == null) blocked.Add("Select an existing SDK Settings before assigning build roles.");
            else if (settings.BuildAddressablesWithPlayerBuild != AddressableAssetSettings.PlayerBuildOption.DoNotBuildWithPlayer)
                changes.Add(new ManagedAddressableSyncChange("Global", AssetDatabase.GetAssetPath(settings), "BuildAddressablesWithPlayerBuild", settings.BuildAddressablesWithPlayerBuild.ToString(), "DoNotBuildWithPlayer"));
            var ownership = new List<string>(config.ownedGroupGuids ?? new List<string>());
            var adopted = new HashSet<string>((adoptGroupGuids ?? after.Where(r => r.role != ManagedGroupBuildRole.Unassigned).Select(r => r.groupAssetGuid)).Where(g => !string.IsNullOrWhiteSpace(g)).Select(g => g.Trim()), StringComparer.OrdinalIgnoreCase);
            foreach (var role in after.Where(r => r.role == ManagedGroupBuildRole.Boot || r.role == ManagedGroupBuildRole.Revision))
            {
                var group = settings?.groups.FirstOrDefault(g => g != null && string.Equals(AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(g)), role.groupAssetGuid, StringComparison.OrdinalIgnoreCase));
                if (group == null) continue;
                string blockedBuilds = string.Join("/", new[] { ManagedGroupBuildRole.Boot, ManagedGroupBuildRole.Revision }.Where(purpose =>
                    group.IncludeInBuild != (role.role == purpose) || (purpose == ManagedGroupBuildRole.Revision && role.role == purpose && group.HasSchema<BundledAssetGroupSchema>())));
                if (group.ReadOnly) warnings.Add("ReadOnly temporary writes remain blocked in builds [" + blockedBuilds + "]: " + group.Name + " / " + role.groupAssetGuid);
                if (ownership.Any(g => string.Equals(g, role.groupAssetGuid, StringComparison.OrdinalIgnoreCase))) continue;
                if (!adopted.Contains(role.groupAssetGuid))
                {
                    warnings.Add("Adoption disabled; blocked builds [" + blockedBuilds + "] require temporary Include/path writes for " + group.Name + " / " + role.groupAssetGuid + ". Select its adoption checkbox and Preview again.");
                    continue;
                }
                if (group.ReadOnly) { blocked.Add("Cannot adopt a ReadOnly Group for temporary build writes: " + group.Name + " / " + role.groupAssetGuid); continue; }
                ownership.Add(role.groupAssetGuid);
                changes.Add(new ManagedAddressableSyncChange("Group", group.Name, "Config ownership (explicit build adoption)", "external: " + role.groupAssetGuid, "owned: " + role.groupAssetGuid));
            }
            // The early warnings only inform; a failure to compute them must not stop the role preview.
            try { warnings.AddRange(ManagedAddressableBuildExporter.EarlyRoleWarnings(after, settings)); }
            catch (Exception error) { warnings.Add("Early build role checks could not run: " + error.Message); }
            warnings.Add("Role and adoption changes are reviewed separately in this same plan. Adoption changes Config only; Group/Entry/schema/Profile values are preserved. Existing ownership release uses Preview Group Adoption.");
            var report = CustomPlanReport(changes, blocked, warnings);
            return new ManagedAddressableSyncPlan(SyncFingerprint(config, settings), false,
                new List<ManagedAddressableSyncPlan.GroupAddition>(), new List<ManagedAddressableSyncPlan.EntryChange>(), changes, blocked, report, warnings,
                ownedGroupGuidsAfter: ownership.SequenceEqual(config.ownedGroupGuids ?? new List<string>()) ? null : ownership,
                buildRoles: changes.Count == 0 ? null : new ManagedBuildRoleChange(after, required));
        }
    }
}
