using System.Collections.Generic;
using UnityEditor;
using UnityEngine.AddressableAssets;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedBuildExportResult
    {
        public bool success;
        public string outputDirectory;
        public string splitReceiptPath;
        public string error;
        public readonly List<string> warnings = new List<string>();
    }

    internal static partial class ManagedAddressableBuildExporter
    {
        // True while a purpose content build owns the SDK settings overlay.
        internal static bool BuildInProgress { get; set; }

        internal static string AddressablesVersion => UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(Addressables).Assembly)?.version ?? string.Empty;

        // BootstrapSplit relies on SDK internals (provider structs, SerializedType cache,
        // OnAfterDeserialize backfill, literal ProfileValueReference ids, excluded Group
        // layout rows). Each exact version below was compared at the source level; 4.1.0
        // and 4.1.1 were not, so this is a set of versions, not a range.
        internal static readonly string[] SplitVerifiedAddressablesVersions = { "4.0.1", "4.1.2" };
        internal static bool IsSplitVerifiedAddressablesVersion(string version) => System.Array.IndexOf(SplitVerifiedAddressablesVersions, version) >= 0;
        internal static bool SplitAdapterAvailable => IsSplitVerifiedAddressablesVersion(AddressablesVersion);

        internal static ManagedAddressableProjectConfig LoadConfig()
        {
            return AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ManagedAddressableProjectConfig.DefaultAssetPath);
        }

        private static string GetBuildOutputRoot(ManagedAddressableProjectConfig config)
        {
            return string.IsNullOrWhiteSpace(config.buildOutputRoot) ? "ServerData" : config.buildOutputRoot.Trim();
        }
    }
}
