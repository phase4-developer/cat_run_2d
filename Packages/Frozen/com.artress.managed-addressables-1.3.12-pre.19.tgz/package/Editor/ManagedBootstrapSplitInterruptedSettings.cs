﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;
using UnityEngine.ResourceManagement.Util;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedSplitSettingsRestorePlan
    {
        internal string pendingSha;
        internal readonly Dictionary<string, string> current = new Dictionary<string, string>(StringComparer.Ordinal);
        internal readonly List<string> changes = new List<string>(), conflicts = new List<string>();
        public bool CanRestore => pendingSha != null && conflicts.Count == 0;
        public IReadOnlyList<string> Changes => changes.AsReadOnly();
        public IReadOnlyList<string> Conflicts => conflicts.AsReadOnly();
        public override string ToString() => string.Join("\n", changes.Concat(conflicts.Select(c => "[Blocked] " + c)));
    }

    internal static partial class ManagedAddressableBuildExporter
    {
        internal static string PendingSplitSettingsPath => Path.Combine("Library", "ArtressManagedAddressablesSplit", "pending_split_settings.json");
        internal static bool HasPendingSplitSettings => File.Exists(PendingSplitSettingsPath) || File.Exists(PendingSplitSettingsPath + ".next");
        internal static void RequireNoPendingSplitSettings()
        {
            if (HasPendingSplitSettings) throw new InvalidOperationException(ManagedEditorText.L("중단된 Split 임시 설정 기록이 남았습니다: ", "An interrupted Split build left temporary settings: ") + PendingSplitSettingsPath + ManagedEditorText.L(". Control Center > 고급 > 중단 복구의 중단된 Split 설정 미리 보기 → 중단된 Split 설정 복원으로 대상을 검토하세요. Boot/Revision/Player 빌드를 시작하지 않았습니다.", ". Review it with Control Center > Advanced > Interrupted build recovery > Preview Interrupted Split Settings → Restore Interrupted Split Settings. No Boot/Revision/Player build was started."));
        }

        public static ManagedSplitSettingsRestorePlan CreateInterruptedSplitSettingsRestorePlan()
        {
            var plan = new ManagedSplitSettingsRestorePlan();
            try
            {
                if (!File.Exists(PendingSplitSettingsPath)) throw new InvalidOperationException("완료된 pending 설정 기록이 없습니다. .next만 남은 경우 원본/임시 기록을 소유자와 확인해야 하며 자동 대안은 실행하지 않습니다.");
                plan.pendingSha = SplitFileHash(PendingSplitSettingsPath);
                if (File.Exists(PendingSplitSettingsPath + ".next")) plan.conflicts.Add("미완료 atomic checkpoint .next가 남아 원문을 보존합니다. 소유자 확인 전 자동 복원하지 않습니다.");
                var snapshot = ManagedBootstrapSplitSettingsScope.ReadPendingSettings();
                snapshot.ValidateTargets();
                foreach (var row in snapshot.observed)
                {
                    string current = File.Exists(row.Key) ? SplitFileHash(row.Key) : "absent";
                    plan.current.Add(row.Key, current);
                    string allowed = snapshot.temporary.TryGetValue(row.Key, out var saved) ? saved : row.Value;
                    if (current != row.Value && current != allowed)
                        plan.conflicts.Add("사용자 변경 또는 기록되지 않은 쓰기와 충돌: " + row.Key + " / original=" + row.Value + " / recorded temporary=" + allowed + " / current=" + current + ". 자동 복원하지 않습니다.");
                    if (snapshot.raw.ContainsKey(row.Key))
                    {
                        var value = AssetDatabase.LoadMainAssetAtPath(row.Key);
                        if (value == null || EditorUtility.IsDirty(value)) plan.conflicts.Add("복원 대상이 없거나 미저장 편집이 있습니다: " + row.Key);
                        plan.changes.Add("[Restore exact bytes/effective] " + row.Key + " / " + current + " -> " + row.Value);
                    }
                }
                plan.changes.Add("[Preserve] 대상 밖 Group/Entry/Profile, 사용자 편집과 GUID를 수정하지 않습니다. raw/effective 확인 후에만 pending 기록을 삭제합니다.");
            }
            catch (Exception error) { plan.conflicts.Add(error.Message); }
            if (!plan.CanRestore && HasPendingSplitSettings)
                plan.changes.Add("[수동 해결] 충돌 또는 .next만 남아 자동 복원을 진행할 수 없으면 다음 순서를 따르세요. " +
                    "① pending 파일 백업: " + PendingSplitSettingsPath + " 및 " + PendingSplitSettingsPath + ".next 중 존재하는 파일을 별도 위치에 보존합니다. " +
                    "② 설정 직접 확인: 백업의 원본/기록된 임시 값과 현재 Settings/Group/schema/Profile을 소유자와 확인하고 필요한 설정을 직접 해결합니다. " +
                    "③ pending 파일 삭제: 설정 확인·수동 해결과 백업 보존을 마친 뒤 해당 pending 파일만 수동 삭제하고 다시 Preview합니다. 새 삭제 버튼이나 자동 폐기는 제공하지 않습니다.");
            return plan;
        }

        public static void RestoreInterruptedSplitBuildSettings(ManagedSplitSettingsRestorePlan plan)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating || UnityEditor.BuildPipeline.isBuildingPlayer || ManagedAddressableBuildExporter.BuildInProgress)
                throw new InvalidOperationException("Split 설정 복원은 다른 빌드/Play/import가 없는 Editor에서만 가능합니다.");
            if (plan == null || !plan.CanRestore || SplitFileHash(PendingSplitSettingsPath) != plan.pendingSha ||
                plan.current.Any(row => (File.Exists(row.Key) ? SplitFileHash(row.Key) : "absent") != row.Value))
                throw new InvalidOperationException("중단 설정 복원 계획이 차단되었거나 Preview 후 바뀌었습니다. 다시 Preview하세요. 쓰기를 시작하지 않았습니다.");
            var recheck = CreateInterruptedSplitSettingsRestorePlan();
            if (!recheck.CanRestore || recheck.pendingSha != plan.pendingSha) throw new InvalidOperationException(recheck.ToString());
            ManagedBootstrapSplitSettingsScope.RestorePendingSettings();
        }
    }

    internal sealed partial class ManagedBootstrapSplitSettingsScope
    {
        internal sealed class PendingSettings
        {
            public int schemaVersion = 1;
            public string token, settingsPath, settingsGuid, unity, sdk, effective, catalogProvider, bundledJson, bundleJson, bundledType, bundleType, entryJson, entryType;
            public bool generateBuildLayout;
            public Dictionary<string, byte[]> raw;
            public Dictionary<string, string> live, observed, temporary, guids;
            public Dictionary<string, Dictionary<string, string>> bundleIds;
            internal void ValidateTargets()
            {
                if (schemaVersion != 1 || !ManagedAddressableBuildExporter.IsSplitVerifiedAddressablesVersion(sdk) || ManagedAddressableBuildExporter.AddressablesVersion != sdk || unity != Application.unityVersion || string.IsNullOrEmpty(token) ||
                    raw == null || live == null || observed == null || temporary == null || guids == null || bundleIds == null || !raw.ContainsKey(settingsPath) || raw.Count != live.Count || raw.Count != temporary.Count || raw.Count != guids.Count)
                    throw new InvalidOperationException("지원하는 SDK/Unity의 한정 Split 설정 snapshot이 아닙니다.");
                var active = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration();
                if (active == null || AssetDatabase.GetAssetPath(active) != settingsPath || ManagedAddressableBuildExporter.SplitGuid(active) != settingsGuid)
                    throw new InvalidOperationException("원래 SDK Settings를 선택한 상태에서 복원하세요: " + settingsPath + " / " + settingsGuid);
                foreach (string path in raw.Keys)
                {
                    string absolute = Path.GetFullPath(path), assets = Path.GetFullPath("Assets") + Path.DirectorySeparatorChar;
                    if (!path.StartsWith("Assets/", StringComparison.Ordinal) || path.Split('/').Any(p => p == ".." || p == ".") || !absolute.StartsWith(assets, StringComparison.OrdinalIgnoreCase) ||
                        !guids.TryGetValue(path, out var guid) || string.IsNullOrEmpty(guid) || AssetDatabase.AssetPathToGUID(path) != guid || !live.ContainsKey(path) || !observed.ContainsKey(path) || !temporary.ContainsKey(path) || raw[path] == null || BytesSha(raw[path]) != observed[path])
                        throw new InvalidOperationException("복원 대상 경로/GUID가 원래 자산과 다릅니다: " + path);
                    var value = AssetDatabase.LoadMainAssetAtPath(path);
                    bool knownTarget = value == active || (value is AddressableAssetGroup group && active.groups.Contains(group)) ||
                        (value is UnityEditor.AddressableAssets.Settings.AddressableAssetGroupSchema schema && active.groups.Any(g => g != null && g.Schemas.Contains(schema)));
                    if (!knownTarget) throw new InvalidOperationException("선택 Settings의 한정 Group/schema 대상이 아닙니다: " + path);
                }
            }
        }
        private string recoveryToken;
        private string pendingWrittenSha;
        private PendingSettings recovery;

        internal void PersistBeforeTemporaryWrites()
        {
            ManagedAddressableBuildExporter.RequireNoPendingSplitSettings();
            recoveryToken = Guid.NewGuid().ToString("N");
            recovery = new PendingSettings
            {
                token = recoveryToken, settingsPath = settingsPath, settingsGuid = AssetDatabase.AssetPathToGUID(settingsPath), unity = Application.unityVersion,
                sdk = ManagedAddressableBuildExporter.AddressablesVersion, effective = before, catalogProvider = providerType,
                bundledJson = JsonUtility.ToJson(bundledProviderBefore), bundleJson = JsonUtility.ToJson(bundleProviderBefore),
                bundledType = ResolvedType(bundledProviderBefore), bundleType = ResolvedType(bundleProviderBefore),
                entryJson = entryProviderBefore.HasValue ? JsonUtility.ToJson(entryProviderBefore.Value) : null,
                entryType = entryProviderBefore.HasValue ? ResolvedType(entryProviderBefore.Value) : null,
                generateBuildLayout = ProjectConfigData.GenerateBuildLayout, raw = raw, live = live, observed = observedFiles, bundleIds = bundleIds,
                guids = raw.Keys.ToDictionary(path => path, AssetDatabase.AssetPathToGUID, StringComparer.Ordinal),
                temporary = raw.Keys.ToDictionary(path => path, ManagedAddressableBuildExporter.SplitFileHash, StringComparer.Ordinal)
            };
            WritePendingSettings(true);
        }

        internal void RecordSavedTemporarySettings()
        {
            if (recovery == null) throw new InvalidOperationException("Split 원본 pending 기록이 먼저 필요합니다.");
            foreach (string path in raw.Keys) recovery.temporary[path] = ManagedAddressableBuildExporter.SplitFileHash(path);
            WritePendingSettings(false);
        }

        private void WritePendingSettings(bool create)
        {
            string path = ManagedAddressableBuildExporter.PendingSplitSettingsPath, next = path + ".next";
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            byte[] bytes = new UTF8Encoding(false).GetBytes(JsonConvert.SerializeObject(recovery, Formatting.Indented));
            using (var stream = new FileStream(next, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { stream.Write(bytes, 0, bytes.Length); stream.Flush(true); }
            if (create) File.Move(next, path); else ManagedFileReplace.Replace(next, path);
            pendingWrittenSha = ManagedAddressableBuildExporter.SplitFileHash(path);
        }

        internal static PendingSettings ReadPendingSettings()
        {
            var value = JsonConvert.DeserializeObject<PendingSettings>(File.ReadAllText(ManagedAddressableBuildExporter.PendingSplitSettingsPath));
            if (value == null) throw new InvalidOperationException("Pending Split 설정 기록을 읽을 수 없습니다.");
            return value;
        }

        private ManagedBootstrapSplitSettingsScope(PendingSettings saved)
        {
            settingsPath = saved.settingsPath; providerType = saved.catalogProvider; before = saved.effective;
            bundledProviderBefore = JsonUtility.FromJson<SerializedType>(saved.bundledJson); bundleProviderBefore = JsonUtility.FromJson<SerializedType>(saved.bundleJson);
            if (saved.entryJson != null) entryProviderBefore = JsonUtility.FromJson<SerializedType>(saved.entryJson);
            if ((saved.entryJson != null) != (EntryProviderFieldInfo() != null))
                throw new InvalidOperationException("Pending Split 기록과 현재 SDK의 content-directory provider 필드 유무가 달라 복원하지 않습니다.");
            if (ResolvedType(bundledProviderBefore) != saved.bundledType || ResolvedType(bundleProviderBefore) != saved.bundleType ||
                (entryProviderBefore.HasValue && ResolvedType(entryProviderBefore.Value) != saved.entryType))
                throw new InvalidOperationException("원 Provider cache/type를 재구성할 수 없어 복원하지 않습니다. SDK adapter 검토가 필요합니다.");
            foreach (var row in saved.raw) raw.Add(row.Key, row.Value);
            foreach (var row in saved.live) live.Add(row.Key, row.Value);
            foreach (var row in saved.observed) observedFiles.Add(row.Key, row.Value);
            foreach (var row in saved.bundleIds) bundleIds.Add(row.Key, row.Value);
            recoveryToken = saved.token; recovery = saved;
            pendingWrittenSha = ManagedAddressableBuildExporter.SplitFileHash(ManagedAddressableBuildExporter.PendingSplitSettingsPath);
        }

        private static string ResolvedType(SerializedType value) => value.Value?.AssemblyQualifiedName;
        private static string BytesSha(byte[] bytes)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
        }
        internal static void RestorePendingSettings()
        {
            var saved = ReadPendingSettings(); saved.ValidateTargets();
            var scope = new ManagedBootstrapSplitSettingsScope(saved);
            scope.Restore(new ManagedSplitBuildReceipt());
        }

        private void CompletePendingSettings()
        {
            if (recoveryToken == null) return;
            if (!File.Exists(ManagedAddressableBuildExporter.PendingSplitSettingsPath) || ReadPendingSettings().token != recoveryToken || ManagedAddressableBuildExporter.SplitFileHash(ManagedAddressableBuildExporter.PendingSplitSettingsPath) != pendingWrittenSha)
                throw new InvalidOperationException("Pending Split 설정 소유 기록이 바뀌어 완료로 처리하지 않습니다.");
            ProjectConfigData.GenerateBuildLayout = recovery.generateBuildLayout;
            if (ProjectConfigData.GenerateBuildLayout != recovery.generateBuildLayout) throw new InvalidOperationException("SDK layout option 복원이 불확실합니다.");
            if (File.Exists(ManagedAddressableBuildExporter.PendingSplitSettingsPath + ".next"))
                throw new InvalidOperationException("미완료 pending checkpoint가 남았습니다. 원문을 보존하고 다음 빌드를 중단하세요.");
            File.Delete(ManagedAddressableBuildExporter.PendingSplitSettingsPath);
        }
    }
}
