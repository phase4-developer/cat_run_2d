using System;
using System.Collections.Generic;
using jjevol;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network.Data
{
    /// <summary>
    /// A container that loads itself from the server. <see cref="NetworkDataBinding.LoadAll"/> collects these requests.
    /// The requests name the container in DataKeys so the response is applied by the binding.
    /// </summary>
    public interface INetworkDataSource
    {
        /// <summary>Requests that load this container. Null or empty when there is nothing to load.</summary>
        IEnumerable<NetworkRequest> CreateLoadRequests();
    }

    /// <summary>
    /// Connects <see cref="NetworkManager"/> responses to a <see cref="DataRepository"/>. Every success, from a server
    /// provider or the local service, applies its data before the request callback: ImportJson when the request has
    /// ReplaceData, otherwise UpdateJson, with the request's DataKeys. Requests without DataKeys apply nothing.
    /// </summary>
    public static class NetworkDataBinding
    {
        public static DataRepository Repository { get; private set; }
        public static NetworkDataOptions Options { get; private set; }
        private static Action<NetworkRequest, NetworkResult> _applier;

        // With Domain Reload off, statics survive entering Play Mode; drop the previous session's repository.
        // NetworkManager clears its appliers at the same point.
        [UnityEngine.RuntimeInitializeOnLoadMethod(UnityEngine.RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetOnLoad()
        {
            Repository = null;
            Options = null;
            _applier = null;
        }

        /// <summary>
        /// Adds this binding's applier to the manager. A later Connect replaces only this binding's applier; appliers
        /// the game added with <see cref="NetworkManager.AddResponseApplier"/> stay and keep their order.
        /// </summary>
        public static void Connect(DataRepository repository, NetworkDataOptions options = null)
        {
            if (repository == null) throw new ArgumentNullException(nameof(repository));
            if (repository.IsDisposed) throw new ObjectDisposedException(nameof(DataRepository));
            if (_applier != null) NetworkManager.RemoveResponseApplier(_applier);
            Repository = repository;
            Options = options ?? new NetworkDataOptions();
            NetworkDataOptions connected = Options;
            _applier = (request, result) => Apply(repository, request, result, connected);
            NetworkManager.AddResponseApplier(_applier);
        }

        /// <summary>Removes this binding's applier when <paramref name="repository"/> (or any repository, when null) is connected.</summary>
        public static void Disconnect(DataRepository repository = null)
        {
            if (Repository == null || (repository != null && !ReferenceEquals(repository, Repository))) return;
            Repository = null;
            Options = null;
            if (_applier != null) NetworkManager.RemoveResponseApplier(_applier);
            _applier = null;
        }

        /// <summary>
        /// Applies one success result. The manager calls this through <see cref="Connect"/>; a project with its own
        /// applier can call it directly. Returns true when the repository changed. Throws on invalid data.
        /// </summary>
        public static bool Apply(DataRepository repository, NetworkRequest request, NetworkResult result, NetworkDataOptions options = null)
        {
            if (repository == null) throw new ArgumentNullException(nameof(repository));
            if (request == null) throw new ArgumentNullException(nameof(request));
            if (!result.Success) return false;
            options ??= new NetworkDataOptions();

            JObject data = SelectData(result.Data, options.UpdatedDataKey, out bool hasUpdatedData);
            string[] requested = request.DataKeys ?? Array.Empty<string>();
            var targets = new List<string>(requested.Length);
            var requestedSet = new HashSet<string>(StringComparer.Ordinal);
            var notRegistered = new List<string>();
            foreach (string key in requested)
            {
                if (string.IsNullOrWhiteSpace(key) || !requestedSet.Add(key)) continue;
                if (repository.Contains(key)) targets.Add(key);
                else notRegistered.Add(key);
            }

            // Requests that name no keys and responses without the updated-data object are plain replies, not data changes.
            if (requested.Length > 0 || hasUpdatedData)
            {
                var notRequested = new List<string>();
                foreach (JProperty property in data.Properties())
                    if (!requestedSet.Contains(property.Name) && !options.IgnoredKeys.Contains(property.Name)) notRequested.Add(property.Name);
                var unmatched = new NetworkDataUnmatchedKeys(request, notRequested.AsReadOnly(), notRegistered.AsReadOnly());
                if (!unmatched.IsEmpty) options.Report(unmatched);
            }

            var context = new NetworkDataApplyContext(repository, request, result, data, targets.ToArray(), request.ReplaceData);
            foreach (Func<NetworkDataApplyContext, bool> step in options.Steps)
                if (step(context)) return true;

            if (targets.Count == 0) return false;
            return request.ReplaceData ? repository.ImportJson(data, context.TargetKeys) : repository.UpdateJson(data, context.TargetKeys);
        }

        /// <summary>
        /// Sends the load requests of every registered <see cref="INetworkDataSource"/> container, in registration order,
        /// through the ordered queue. A request shared by several containers is sent once.
        /// </summary>
        public static NetworkBatch LoadAll(DataRepository repository, Action<NetworkBatch> completed = null)
        {
            if (repository == null) throw new ArgumentNullException(nameof(repository));
            var requests = new List<NetworkRequest>();
            var seen = new HashSet<NetworkRequest>();
            foreach (DataContainer container in repository.Containers.Values)
            {
                if (!(container is INetworkDataSource source)) continue;
                IEnumerable<NetworkRequest> created = source.CreateLoadRequests();
                if (created == null) continue;
                foreach (NetworkRequest request in created)
                    if (request != null && seen.Add(request)) requests.Add(request);
            }
            return new NetworkBatch(requests).PostQueue(completed);
        }

        private static JObject SelectData(JObject data, string updatedDataKey, out bool hasUpdatedData)
        {
            hasUpdatedData = false;
            if (data == null) return new JObject();
            if (!string.IsNullOrEmpty(updatedDataKey) && data.TryGetValue(updatedDataKey, StringComparison.Ordinal, out JToken updated))
            {
                if (updated.Type == JTokenType.Null) return new JObject();
                if (!(updated is JObject updatedObject)) throw new System.IO.InvalidDataException("Expected an object: " + updatedDataKey);
                hasUpdatedData = true;
                return updatedObject;
            }
            return data;
        }
    }
}
