# JJEvol Platform Network Data

`com.jjevol.platform.network.data@0.1.0-pre.1`은 `com.jjevol.platform.network`의 응답을 `com.jjevol.data` 저장소에 반영한다. 통신 패키지와 저장소 패키지는 서로 참조하지 않고, 이 패키지가 둘을 잇는다. Unity 6000.3.9f1 기준이다.

필수: `com.jjevol.platform.network@0.1.0-pre.1`, `com.jjevol.data@0.1.0-pre.1`, Unity Newtonsoft JSON 3.2.2.

## 연결

```csharp
var data = new DataRepository(profileId);
data.Register(new MailContainer(), saveLocal: false);   // 서버 데이터는 로컬 저장 제외
data.Register(new GameOptionContainer());                // 기본값 saveLocal: true
NetworkDataBinding.Connect(data);                        // NetworkManager.AddResponseApplier로 반영기를 더한다. 게임 반영기는 그대로
```

요청은 응답이 바꾸는 저장소 키를 `DataKeys`로 알린다.

```csharp
public sealed class ClaimMailRequest : NetworkRequest
{
    public override string Name => "claimMailCallable";
    public ClaimMailRequest(string mailId)
    {
        Add("mailId", mailId);
        DataKeys = new[] { MailContainer.Key, WealthContainer.PayloadKey };
    }
}
```

## 반영 규칙

서버 공급자와 로컬 서비스의 성공 결과가 같은 경로로, 요청 콜백보다 먼저 반영된다.

1. 반영 대상: 성공 데이터에 `updatedData`(`NetworkDataOptions.UpdatedDataKey`) 객체가 있으면 그것, 없으면 성공 데이터 전체.
2. `request.ReplaceData`면 `ImportJson(data, DataKeys)`(교체), 아니면 `UpdateJson(data, DataKeys)`(병합).
3. `DataKeys`가 비어 있으면 반영하지 않는다.
4. 저장소에 등록되지 않은 `DataKeys`는 반영에서 빼고 진단으로 알린다.
5. 반영이 실패하면(교체 대상 누락, 잘못된 데이터, 단계 예외) 아무것도 바뀌지 않고 요청은 `ApplyFailed`로 끝난다. 저장소의 원자 반영 규칙을 그대로 따른다.

## 응답 키 진단

응답 키와 요청·저장소가 맞지 않으면 `NetworkDataOptions.UnmatchedKeys`가 알린다.

- `NotRequested`: 반영 대상에 있지만 `DataKeys`에 없는 키. `IgnoredKeys`(기본 `rewards`, `timeStamp`)는 빼고 본다.
- `NotRegistered`: `DataKeys`에 있지만 저장소에 등록되지 않은 키.
- `DataKeys`가 없고 `updatedData`도 없는 응답은 데이터 변경이 아닌 일반 응답으로 보고 진단하지 않는다.
- Editor에서는 기본으로 경고 로그를 남긴다(`LogUnmatchedKeys`). 진단 구독자의 예외는 요청을 실패시키지 않는다.

```csharp
var options = new NetworkDataOptions();
options.IgnoredKeys.Add("serverNotice");
options.UnmatchedKeys += unmatched => GameLog.Warn(unmatched.ToString());
NetworkDataBinding.Connect(data, options);
```

## 반영 앞 단계

`options.AddStep(context => bool)`로 기본 반영 앞에 단계를 끼운다. 등록 순서대로 돌고, `true`를 돌려준 단계가 반영을 맡은 것으로 보고 기본 반영과 뒤 단계를 건너뛴다. 단계는 저장소, 요청, 결과, 반영 대상 데이터, 등록된 대상 키(`TargetKeys`), 교체 여부를 받는다.

재화 예약 중인 서버 거래는 일반 반영 대신 `ResourceService.ApplyServerResponse`로 확정해야 한다. 이 패키지는 재화를 모르므로 프로젝트가 단계를 등록한다.

```csharp
options.AddStep(context =>
{
    if (!(context.Request is GameResourceRequest resource)) return false;
    resources.ApplyServerResponse(resource.Reservation, context.Data, context.Replace, context.TargetKeys);
    return true;
});
```

`GameResourceRequest`와 `Reservation`은 프로젝트 형식이다.

## 서버 데이터 일괄 로드

서버에서 읽어 오는 Container는 `INetworkDataSource`를 구현해 자기 로드 요청을 낸다. `NetworkDataBinding.LoadAll(repository, completed)`가 등록 순서대로 모아 `NetworkBatch`로 대기열에 보낸다. 여러 Container가 같은 요청 인스턴스를 내면 한 번만 보낸다. 로드 요청도 `DataKeys`와 `ReplaceData`로 반영된다.

```csharp
public sealed class MailContainer : DataContainer, INetworkDataSource
{
    public IEnumerable<NetworkRequest> CreateLoadRequests() { yield return new LoadMailsRequest(); }
    // ...
}

NetworkDataBinding.LoadAll(data, batch => { if (!batch.Success) ShowRetry(batch.FirstFailure); });
```

## 직접 반영

자체 반영 함수를 쓰는 프로젝트는 `NetworkDataBinding.Apply(repository, request, result, options)`를 직접 부를 수 있다. `Disconnect(repository)`는 연결된 저장소일 때만 반영 함수를 뗀다. `NetworkManager.ClearAll()`도 반영 함수를 떼지만 `NetworkDataBinding.Repository`는 남으므로 함께 `Disconnect()`를 부른다. Play Mode 진입(`SubsystemRegistration`) 때는 Domain Reload를 꺼도 `Repository`와 `Options`가 비워진다.

## 시험

`Tests/Editor`(`PlatformLibrary.Network.Data.Tests.Editor`)에 병합·교체 반영, `updatedData` 우선, `DataKeys` 없음, 미등록 키, `ApplyFailed`, 반영 앞 단계, 일괄 로드, 연결 해제, Play Mode 진입 초기화 시험 10개가 있다. 시험 Container는 합성 데이터이고 로컬 저장을 쓰지 않는다. Unity EditMode 시험은 `Hosts/NetworkValidationHost`(잡 `network-host-2`, 후보 `abd61a5`)에서 모두 통과했다. 같은 시험을 Unity 없이 .NET 실행기로 돌려 통과했다.
