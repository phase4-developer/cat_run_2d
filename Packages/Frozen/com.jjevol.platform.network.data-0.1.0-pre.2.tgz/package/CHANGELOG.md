# Changelog

## 0.1.0-pre.2 - 2026-11-10

- `Connect` adds the binding's applier with `NetworkManager.AddResponseApplier` (network 0.1.0-pre.2) instead of replacing the manager's only applier, so a game's own appliers stay. A later `Connect` replaces only the binding's applier and adds it last; `Disconnect` removes only it.

Unity 6000.3.9f1, queue runner job `pkg1110-net-01` on `Hosts/NetworkValidationHost`: compile and EditMode 54/54 passed together with network. Player and a real server are NOT_RUN.

## 0.1.0-pre.1 - 2026-11-08

- First candidate. `NetworkDataBinding` (`Connect`, `Disconnect`, `Apply`, `LoadAll`), `NetworkDataOptions` (`UpdatedDataKey`, `IgnoredKeys`, `LogUnmatchedKeys`, `UnmatchedKeys`, `AddStep`), `NetworkDataApplyContext`, `NetworkDataUnmatchedKeys`, `INetworkDataSource`.
- Success data is applied before the request callback with `ImportJson` when the request has `ReplaceData`, otherwise `UpdateJson`, using the request's `DataKeys`. A failed apply ends the request as `ApplyFailed`.
- `Repository` and `Options` are cleared at `SubsystemRegistration`, so entering Play Mode with Domain Reload off does not keep a disposed repository.

Unity EditMode tests passed on Hosts/NetworkValidationHost (job network-host-2, candidate abd61a5). The Editor tests passed in an offline .NET runner.
