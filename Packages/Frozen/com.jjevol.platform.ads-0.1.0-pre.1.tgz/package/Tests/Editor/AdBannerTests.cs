using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdBannerTests : AdTestBase
    {
        [Test]
        public void ProviderWithoutBannersAnswersUnsupportedAndHideDoesNothing()
        {
            Provider.SupportsBanner = false;
            StartManagerWithRewardAd();

            AdManager.ShowBanner(Record);
            AdManager.HideBanner();

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Unsupported));
            Assert.That(Provider.BannerShowCount, Is.Zero);
            Assert.That(Provider.HideBannerCount, Is.Zero);
        }

        [Test]
        public void ChecksMatchTheOtherFormats()
        {
            UseProvider();
            AdManager.ShowBanner(Record);
            AdManager.Initialize();
            Provider.CompleteInitialize();

            Provider.CanRequestAds = false;
            AdManager.ShowBanner(Record);
            Provider.CanRequestAds = true;

            Provider.BannerAdUnitId = string.Empty;
            AdManager.ShowBanner(Record);

            Assert.That(Results[0].Failure, Is.EqualTo(AdFailure.NotInitialized));
            Assert.That(Results[1].Failure, Is.EqualTo(AdFailure.ConsentRequired));
            Assert.That(Results[2].Failure, Is.EqualTo(AdFailure.InvalidAdUnit));
            Assert.That(Provider.BannerShowCount, Is.Zero);
        }

        [Test]
        public void LoadedBannerAnswersOnceEvenWhenItRefreshes()
        {
            StartManagerWithRewardAd();

            AdManager.ShowBanner(new AdRequest("lobby"), Record);
            Provider.PendingBanner(AdResult.Succeeded());
            Provider.PendingBanner(AdResult.Succeeded());

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.Placement, Is.EqualTo("lobby"));
            Assert.That(Single.AdUnitId, Is.EqualTo("banner-unit"));
            Assert.That(Provider.BannerRequest.AdUnitId, Is.EqualTo("banner-unit"));
        }

        [Test]
        public void FailedBannerKeepsTheSdkCode()
        {
            StartManagerWithRewardAd();

            AdManager.ShowBanner(Record);
            Provider.PendingBanner(AdResult.Failed(AdFailure.NoFill, 3, "no ad"));

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.NoFill));
            Assert.That(Single.ProviderCode, Is.EqualTo(3));
        }

        [Test]
        public void SilentBannerTimesOutAndIsHidden()
        {
            StartManagerWithRewardAd();
            AdManager.ShowBanner(Record);
            var late = Provider.PendingBanner;

            Host.Advance(Timeout);
            late(AdResult.Succeeded());

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Timeout));
            Assert.That(Provider.HideBannerCount, Is.EqualTo(1));
        }

        [Test]
        public void NewBannerEndsThePendingOne()
        {
            StartManagerWithRewardAd();
            AdManager.ShowBanner(new AdRequest("first"), Record);
            var first = Provider.PendingBanner;

            AdManager.ShowBanner(new AdRequest("second"), Record);
            first(AdResult.Succeeded());
            Provider.PendingBanner(AdResult.Succeeded());

            Assert.That(Results, Has.Count.EqualTo(2));
            Assert.That(Results[0].Failure, Is.EqualTo(AdFailure.Busy));
            Assert.That(Results[0].Placement, Is.EqualTo("first"));
            Assert.That(Results[1].Success, Is.True);
            Assert.That(Results[1].Placement, Is.EqualTo("second"));
        }

        [Test]
        public void HideEndsAPendingBanner()
        {
            StartManagerWithRewardAd();
            AdManager.ShowBanner(Record);

            AdManager.HideBanner();
            Host.Advance(Timeout);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
            Assert.That(Provider.HideBannerCount, Is.EqualTo(1));
        }
    }
}
