using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdRewardShowTests : AdTestBase
    {
        [Test]
        public void EarnedRewardReachesTheCallback()
        {
            StartManagerWithRewardAd();
            var request = new AdRequest("revive", userId: "user", customData: "data", requestId: "request");

            AdManager.ShowRewardAd(request, Record);
            Provider.Listener.RewardEarned("coin", 5d);
            Provider.Listener.Closed();
            Assert.That(Results, Is.Empty);

            Host.Advance(ShowEnd);

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.RewardGranted, Is.True);
            Assert.That(Single.RewardType, Is.EqualTo("coin"));
            Assert.That(Single.RewardAmount, Is.EqualTo(5d));
            Assert.That(Single.IsSkipped, Is.False);
            Assert.That(Single.Placement, Is.EqualTo("revive"));
            Assert.That(Single.AdUnitId, Is.EqualTo("reward-unit"));
            Assert.That(Single.UserId, Is.EqualTo("user"));
            Assert.That(Single.CustomData, Is.EqualTo("data"));
            Assert.That(Single.RequestId, Is.EqualTo("request"));
            Assert.That(Single.ServerVerificationRequested, Is.True);
            Assert.That(Provider.ShownRequest.Placement, Is.EqualTo("revive"));
        }

        [Test]
        public void RewardReportedJustAfterTheCloseStillCounts()
        {
            StartManagerWithRewardAd();

            AdManager.ShowRewardAd(Record);
            Provider.Listener.Closed();
            Provider.Listener.RewardEarned("coin", 1d);
            Host.Advance(ShowEnd);

            Assert.That(Single.RewardGranted, Is.True);
        }

        [Test]
        public void ClosingWithoutARewardIsASkippedSuccess()
        {
            StartManagerWithRewardAd();

            AdManager.ShowRewardAd(Record);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.RewardGranted, Is.False);
            Assert.That(Single.IsSkipped, Is.True);
        }

        [Test]
        public void ShowFailureKeepsTheSdkCodeAndGrantsNothing()
        {
            StartManagerWithRewardAd();

            AdManager.ShowRewardAd(Record);
            Provider.Listener.RewardEarned("coin", 1d);
            Provider.Listener.Failed(AdFailure.ShowFailed, 7, "failed");
            Host.Advance(ShowEnd);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ShowFailed));
            Assert.That(Single.ProviderCode, Is.EqualTo(7));
            Assert.That(Single.Detail, Is.EqualTo("failed"));
            Assert.That(Single.RewardGranted, Is.False);
        }

        [Test]
        public void RepeatedEndsAnswerOnce()
        {
            StartManagerWithRewardAd();

            AdManager.ShowRewardAd(Record);
            Provider.Listener.Closed();
            Provider.Listener.Closed();
            Provider.Listener.Failed(AdFailure.ShowFailed, 1, "late");
            Host.Advance(ShowEnd);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(Single.Success, Is.True);
        }

        [Test]
        public void SecondShowWhileShowingAnswersBusy()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(_ => { });

            AdManager.ShowRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
        }

        [Test]
        public void ShowWithoutAnAdWaitsForTheLoad()
        {
            StartManager();

            AdManager.ShowRewardAd(new AdRequest("revive"), Record);
            Assert.That(Provider.Listener, Is.Null);

            Provider.CompleteRewardLoad();
            Assert.That(Provider.ShownRequest.Placement, Is.EqualTo("revive"));

            Provider.Listener.RewardEarned("coin", 1d);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(Single.RewardGranted, Is.True);
        }

        [Test]
        public void FailedLoadEndsAWaitingShowWithItsReason()
        {
            StartManager();

            AdManager.ShowRewardAd(new AdRequest("revive"), Record);
            Provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill, 3, "no ad"));

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.NoFill));
            Assert.That(Single.ProviderCode, Is.EqualTo(3));
            Assert.That(Single.Placement, Is.EqualTo("revive"));
            Assert.That(Provider.Listener, Is.Null);
        }

        [Test]
        public void TimedOutLoadEndsAWaitingShow()
        {
            StartManager();

            AdManager.ShowRewardAd(Record);
            Host.Advance(Timeout);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Timeout));
        }

        [Test]
        public void SecondShowWhileWaitingAnswersBusy()
        {
            StartManager();
            AdManager.ShowRewardAd(_ => { });

            AdManager.ShowRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
        }

        [Test]
        public void LoadAnswerWithNoReadyAdFailsTheShowInsteadOfLooping()
        {
            StartManager();

            AdManager.ShowRewardAd(Record);
            Provider.PendingRewardLoad(AdResult.Succeeded());

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ShowFailed));
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(1));
        }

        [Test]
        public void ThrowingProviderAnswersShowFailed()
        {
            StartManagerWithRewardAd();
            Provider.ThrowOnShow = true;

            AdManager.ShowRewardAd(Record);
            Host.Advance(ShowEnd);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ShowFailed));
            Assert.That(Host.Exceptions, Has.Count.EqualTo(1));
        }

        [Test]
        public void EndedShowDiscardsTheAdAndLoadsTheNext()
        {
            StartManagerWithRewardAd();
            int discards = Provider.RewardDiscardCount;

            AdManager.ShowRewardAd(new AdRequest("revive"), Record);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(Provider.RewardDiscardCount, Is.GreaterThan(discards));
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
            Assert.That(Provider.RewardLoads[1].Placement, Is.Empty);
            Assert.That(AdManager.IsRewardAdLoading, Is.True);
        }

        [Test]
        public void ShowFromTheCallbackLoadsOnce()
        {
            StartManagerWithRewardAd();

            AdManager.ShowRewardAd(_ => AdManager.ShowRewardAd(Record));
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
            Provider.CompleteRewardLoad();
            Assert.That(Provider.ShownRequest.AdUnitId, Is.EqualTo("reward-unit"));
        }

        [Test]
        public void ThrowingGameCallbackDoesNotStopTheNextLoad()
        {
            StartManagerWithRewardAd();
            int completed = 0;
            AdManager.RewardCompleted += _ => completed++;

            AdManager.ShowRewardAd(_ => throw new InvalidOperationException("game"));
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(completed, Is.EqualTo(1));
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
            Assert.That(Host.Exceptions, Has.Count.EqualTo(1));
        }

        [Test]
        public void RewardCompletedFiresOnceForEveryEndedShow()
        {
            StartManagerWithRewardAd();
            var completed = new List<AdResult>();
            AdManager.RewardCompleted += completed.Add;

            AdManager.ShowRewardAd(new AdRequest("revive"), Record);
            Provider.Listener.RewardEarned("coin", 1d);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);
            Provider.CompleteRewardLoad();

            AdManager.ShowRewardAd(new AdRequest("skip"), Record);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(completed, Has.Count.EqualTo(2));
            Assert.That(completed[0].RewardGranted, Is.True);
            Assert.That(completed[0].Placement, Is.EqualTo("revive"));
            Assert.That(completed[1].RewardGranted, Is.False);
        }

        [Test]
        public void RewardCompletedDoesNotFireForARejectedCall()
        {
            StartManager();
            Provider.CanRequestAds = false;
            int completed = 0;
            AdManager.RewardCompleted += _ => completed++;

            AdManager.ShowRewardAd(Record);

            Assert.That(completed, Is.Zero);
        }

        [Test]
        public void RevenueReachesTheEvent()
        {
            StartManagerWithRewardAd();
            AdRevenue paid = null;
            AdManager.AdRevenuePaid += revenue => paid = revenue;
            var sent = new AdRevenue("network", "source", "unit", "REWARDED", 0.5d, "USD", "revive");

            Provider.RaiseRevenue(sent);

            Assert.That(paid, Is.SameAs(sent));
        }

        [Test]
        public void WorkerThreadAnswersWaitForTheMainThread()
        {
            StartManagerWithRewardAd();
            AdRevenue paid = null;
            AdManager.AdRevenuePaid += revenue => paid = revenue;

            AdManager.ShowRewardAd(Record);
            Host.HoldPosts = true;
            Provider.RaiseRevenue(new AdRevenue("network", "source", "unit", "REWARDED", 0.5d, "USD"));
            Provider.Listener.RewardEarned("coin", 1d);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(paid, Is.Null);
            Assert.That(Results, Is.Empty);

            Host.RunHeldPosts();
            Host.Advance(ShowEnd);

            Assert.That(paid, Is.Not.Null);
            Assert.That(Single.RewardGranted, Is.True);
        }
    }
}
