using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdProviderFaultTests : AdTestBase
    {
        [Test]
        public void ThrowingDiscardAfterAShowStillFinishesIt()
        {
            StartManagerWithRewardAd();
            var loading = new List<string>();
            int completed = 0;
            AdManager.LoadingChanged += (kind, active) => loading.Add($"{kind} {active}");
            AdManager.RewardCompleted += _ => completed++;

            AdManager.ShowRewardAd(Record);
            Provider.Listener.RewardEarned("coin", 1d);
            Provider.Listener.Closed();
            Provider.ThrowOnDiscard = true;

            Assert.DoesNotThrow(() => Host.Advance(ShowEnd));

            Assert.That(loading, Is.EqualTo(new[] { "Showing True", "Showing False" }));
            Assert.That(Single.RewardGranted, Is.True);
            Assert.That(completed, Is.EqualTo(1));
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
            Assert.That(Host.Exceptions, Is.Not.Empty);
        }

        [Test]
        public void ThrowingDiscardAfterAFailedLoadStillAnswers()
        {
            StartManager();
            AdManager.LoadRewardAd(Record);
            Provider.ThrowOnDiscard = true;

            Assert.DoesNotThrow(() => Provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill)));

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.NoFill));
        }

        [Test]
        public void ThrowingDiscardBeforeALoadStillLoads()
        {
            StartManager();
            Provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill));
            Provider.ThrowOnDiscard = true;

            Assert.DoesNotThrow(() => AdManager.LoadRewardAd(Record));

            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
            Assert.That(AdManager.IsRewardAdLoading, Is.True);
        }

        [Test]
        public void ThrowingDiscardDuringAProviderChangeStillEndsPendingCalls()
        {
            StartManager();
            AdManager.LoadRewardAd(Record);
            Provider.ThrowOnDiscard = true;

            Assert.DoesNotThrow(() => AdManager.SetProvider(new FakeAdProvider(), new FakeAdHost(), Timeout));

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ProviderError));
        }

        [Test]
        public void ThrowingAdUnitFunctionAnswersInvalidAdUnit()
        {
            StartManagerWithRewardAd();
            Provider.IsRewardAdReady = false;
            Provider.ThrowOnAdUnit = true;

            Assert.DoesNotThrow(() =>
            {
                AdManager.ShowRewardAd(Record);
                AdManager.LoadRewardAd(Record);
                AdManager.ShowInterstitialAd(Record);
                AdManager.LoadInterstitialAd(Record);
                AdManager.ShowBanner(Record);
            });

            Assert.That(Results, Has.Count.EqualTo(5));
            foreach (AdResult result in Results)
                Assert.That(result.Failure, Is.EqualTo(AdFailure.InvalidAdUnit));
            Assert.That(Host.Exceptions, Has.Count.EqualTo(5));
        }

        [Test]
        public void RequestWithItsOwnUnitNeverReadsTheFunction()
        {
            StartManagerWithRewardAd();
            Provider.ThrowOnAdUnit = true;

            AdManager.LoadRewardAd(new AdRequest(adUnitId: "own-unit"), Record);

            Assert.That(Provider.RewardLoads[1].AdUnitId, Is.EqualTo("own-unit"));
            Assert.That(Host.Exceptions, Is.Empty);
        }

        [Test]
        public void ThrowingAdUnitFunctionAtFirstLoadLeavesItInitializedAndLoadableLater()
        {
            UseProvider();
            AdManager.Initialize();
            Provider.ThrowOnAdUnit = true;

            Assert.DoesNotThrow(Provider.CompleteInitialize);

            Assert.That(AdManager.IsInitialized, Is.True);
            Assert.That(Provider.RewardLoads, Is.Empty);

            Provider.ThrowOnAdUnit = false;
            AdManager.ShowRewardAd(Record);

            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(1));
            Assert.That(Provider.RewardLoads[0].AdUnitId, Is.EqualTo("reward-unit"));
        }

        [Test]
        public void ThrowingAdUnitFunctionAtTheNextLoadDoesNotBreakTheShow()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(new AdRequest("revive"), Record);
            Provider.Listener.Closed();
            Provider.ThrowOnAdUnit = true;

            Assert.DoesNotThrow(() => Host.Advance(ShowEnd));

            Assert.That(Single.Success, Is.True);
            Assert.That(AdManager.IsRewardAdLoading, Is.False);
        }

        [Test]
        public void ThrowingHideBannerStillEndsAPendingBanner()
        {
            StartManagerWithRewardAd();
            AdManager.ShowBanner(Record);
            Provider.ThrowOnHideBanner = true;

            Assert.DoesNotThrow(AdManager.HideBanner);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
        }

        [Test]
        public void ThrowingHideBannerStillAnswersATimeout()
        {
            StartManagerWithRewardAd();
            AdManager.ShowBanner(Record);
            Provider.ThrowOnHideBanner = true;

            Assert.DoesNotThrow(() => Host.Advance(Timeout));

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Timeout));
        }

        [Test]
        public void ThrowingHideBannerDuringAProviderChangeStillEndsThePendingBanner()
        {
            StartManagerWithRewardAd();
            AdManager.ShowBanner(Record);
            Provider.ThrowOnHideBanner = true;

            Assert.DoesNotThrow(() => AdManager.SetProvider(new FakeAdProvider(), new FakeAdHost(), Timeout));

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ProviderError));
        }
    }
}
