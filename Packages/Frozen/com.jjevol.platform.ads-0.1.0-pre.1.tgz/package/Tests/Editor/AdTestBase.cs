using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public abstract class AdTestBase
    {
        protected const float Timeout = 15f;
        protected const float ShowEnd = 0.1f;

        private protected FakeAdProvider Provider;
        private protected FakeAdHost Host;
        protected List<AdResult> Results;

        [SetUp]
        public void SetUpManager()
        {
            AdManager.ResetState();
            Provider = new FakeAdProvider();
            Host = new FakeAdHost();
            Results = new List<AdResult>();
        }

        [TearDown]
        public void TearDownManager() => AdManager.ResetState();

        protected AdResult Single
        {
            get
            {
                Assert.That(Results, Has.Count.EqualTo(1));
                return Results[0];
            }
        }

        protected void UseProvider() => AdManager.SetProvider(Provider, Host, Timeout);

        /// <summary>Provider set, SDK started, and the first automatic reward load left pending.</summary>
        protected void StartManager()
        {
            UseProvider();
            AdManager.Initialize();
            Provider.CompleteInitialize();
        }

        /// <summary>Started, with a reward ad loaded.</summary>
        protected void StartManagerWithRewardAd()
        {
            StartManager();
            Provider.CompleteRewardLoad();
        }

        protected void Record(AdResult result) => Results.Add(result);
    }
}
