using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdRewardLoadTests : AdTestBase
    {
        [Test]
        public void MissingConsentAnswersConsentRequiredWithoutLoading()
        {
            StartManager();
            Provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill));
            Provider.CanRequestAds = false;
            Provider.RewardLoads.Clear();

            AdManager.LoadRewardAd(Record);
            AdManager.ShowRewardAd(Record);

            Assert.That(Results[0].Failure, Is.EqualTo(AdFailure.ConsentRequired));
            Assert.That(Results[1].Failure, Is.EqualTo(AdFailure.ConsentRequired));
            Assert.That(Provider.RewardLoads, Is.Empty);
        }

        [Test]
        public void EmptyAdUnitAnswersInvalidAdUnit()
        {
            Provider.RewardAdUnitId = string.Empty;
            StartManager();
            Results.Clear();

            AdManager.LoadRewardAd(Record);
            AdManager.ShowRewardAd(Record);

            Assert.That(Results[0].Failure, Is.EqualTo(AdFailure.InvalidAdUnit));
            Assert.That(Results[1].Failure, Is.EqualTo(AdFailure.InvalidAdUnit));
            Assert.That(Provider.RewardLoads, Is.Empty);
        }

        [Test]
        public void NoNetworkAnswersNetworkWithoutLoading()
        {
            Host.IsNetworkReachable = false;
            StartManager();

            AdManager.LoadRewardAd(Record);
            AdManager.ShowRewardAd(Record);

            Assert.That(Results[0].Failure, Is.EqualTo(AdFailure.Network));
            Assert.That(Results[1].Failure, Is.EqualTo(AdFailure.Network));
            Assert.That(Provider.RewardLoads, Is.Empty);
        }

        [Test]
        public void ConfiguredUnitIsReadOnEveryRequest()
        {
            StartManagerWithRewardAd();
            Provider.RewardAdUnitId = "later-unit";

            AdManager.LoadRewardAd(Record);

            Assert.That(Provider.RewardLoads[1].AdUnitId, Is.EqualTo("later-unit"));
        }

        [Test]
        public void RequestUnitWinsOverTheConfiguredOne()
        {
            StartManagerWithRewardAd();

            AdManager.LoadRewardAd(new AdRequest(adUnitId: "own-unit"), Record);

            Assert.That(Provider.RewardLoads[1].AdUnitId, Is.EqualTo("own-unit"));
        }

        [Test]
        public void LoadedAdAnswersAtOnceWithoutAnotherLoad()
        {
            StartManagerWithRewardAd();

            AdManager.LoadRewardAd(Record);

            Assert.That(Single.Success, Is.True);
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(1));
        }

        [Test]
        public void ExpiredAdIsReplaced()
        {
            StartManagerWithRewardAd();
            Provider.IsRewardAdReady = false;

            AdManager.LoadRewardAd(Record);

            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
            Assert.That(Provider.RewardDiscardCount, Is.GreaterThanOrEqualTo(1));
        }

        [Test]
        public void SameRequestsShareOneLoadAndEachGetsItsOwnValues()
        {
            StartManager();

            AdManager.LoadRewardAd(new AdRequest("first"), Record);
            AdManager.LoadRewardAd(new AdRequest("second"), Record);
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(1));

            Provider.CompleteRewardLoad();

            Assert.That(Results, Has.Count.EqualTo(2));
            Assert.That(Results[0].Placement, Is.EqualTo("first"));
            Assert.That(Results[1].Placement, Is.EqualTo("second"));
            Assert.That(Results[0].Success, Is.True);
            Assert.That(Results[1].Success, Is.True);
        }

        [Test]
        public void DifferentUnitWhileLoadingAnswersBusy()
        {
            StartManager();

            AdManager.LoadRewardAd(new AdRequest(adUnitId: "other-unit"), Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(1));
        }

        [Test]
        public void ProviderFailureReachesEveryWaiterWithTheSdkCode()
        {
            StartManager();
            AdManager.LoadRewardAd(Record);
            AdManager.LoadRewardAd(Record);

            Provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill, 3, "no ad"));

            Assert.That(Results, Has.Count.EqualTo(2));
            Assert.That(Results[0].Failure, Is.EqualTo(AdFailure.NoFill));
            Assert.That(Results[0].ProviderCode, Is.EqualTo(3));
            Assert.That(AdManager.IsRewardAdLoading, Is.False);
            Assert.That(Provider.RewardDiscardCount, Is.GreaterThanOrEqualTo(1));
        }

        [Test]
        public void SilentProviderTimesOutOnce()
        {
            StartManager();
            AdManager.LoadRewardAd(Record);

            Host.Advance(Timeout - 1f);
            Assert.That(Results, Is.Empty);

            Host.Advance(1f);
            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Timeout));
            Assert.That(AdManager.IsRewardAdLoading, Is.False);

            Host.Advance(Timeout);
            Assert.That(Results, Has.Count.EqualTo(1));
        }

        [Test]
        public void TimeoutDiscardsTheLoadAndALateAnswerIsIgnored()
        {
            StartManager();
            AdManager.LoadRewardAd(Record);
            int discards = Provider.RewardDiscardCount;
            var late = Provider.PendingRewardLoad;

            Host.Advance(Timeout);
            late(AdResult.Succeeded());

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Timeout));
            Assert.That(Provider.RewardDiscardCount, Is.EqualTo(discards + 1));
            Assert.That(AdManager.IsRewardAdLoading, Is.False);

            Provider.IsRewardAdReady = true;
            AdManager.LoadRewardAd(_ => { });
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
        }

        [Test]
        public void AnsweredLoadCancelsTheTimeout()
        {
            StartManager();
            AdManager.LoadRewardAd(Record);
            Provider.CompleteRewardLoad();

            Host.Advance(Timeout * 2f);

            Assert.That(Single.Success, Is.True);
            Assert.That(AdManager.IsRewardAdReady, Is.True);
        }

        [Test]
        public void ThrowingProviderAnswersProviderError()
        {
            StartManager();
            Provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill));
            Provider.ThrowOnLoad = true;

            AdManager.LoadRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ProviderError));
            Assert.That(AdManager.IsRewardAdLoading, Is.False);
            Assert.That(Host.Exceptions, Has.Count.EqualTo(1));
        }

        [Test]
        public void LoadWhileShowingAnswersBusy()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(_ => { });

            AdManager.LoadRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
        }

        [Test]
        public void VerificationBoundAtLoadMakesADifferentUserLoadAgain()
        {
            Provider.BindsServerVerificationAtLoad = true;
            StartManagerWithRewardAd();

            AdManager.LoadRewardAd(new AdRequest(userId: "user"), Record);

            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(2));
            Assert.That(Provider.RewardLoads[1].UserId, Is.EqualTo("user"));
        }

        [Test]
        public void VerificationSetAtShowReusesTheLoadedAd()
        {
            StartManagerWithRewardAd();

            AdManager.LoadRewardAd(new AdRequest(userId: "user"), Record);

            Assert.That(Single.Success, Is.True);
            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(1));
        }
    }
}
