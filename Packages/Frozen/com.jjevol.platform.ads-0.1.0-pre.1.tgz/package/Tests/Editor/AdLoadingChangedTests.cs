using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdLoadingChangedTests : AdTestBase
    {
        private List<string> _log;

        [SetUp]
        public void SetUpLog()
        {
            _log = new List<string>();
            AdManager.LoadingChanged += (kind, active) => _log.Add($"{kind} {active}");
        }

        private void ShowRewardAd() => AdManager.ShowRewardAd(result => _log.Add("result " + result.Failure));

        [Test]
        public void LoadedAdReportsShowingUntilJustBeforeTheResult()
        {
            StartManagerWithRewardAd();

            ShowRewardAd();
            Assert.That(_log, Is.EqualTo(new[] { "Showing True" }));

            Provider.Listener.Closed();
            Assert.That(_log, Is.EqualTo(new[] { "Showing True" }));

            Host.Advance(ShowEnd);
            Assert.That(_log, Is.EqualTo(new[] { "Showing True", "Showing False", "result None" }));
        }

        [Test]
        public void WaitingShowReportsLoadingThenShowing()
        {
            StartManager();

            ShowRewardAd();
            Assert.That(_log, Is.EqualTo(new[] { "Loading True" }));

            Provider.CompleteRewardLoad();
            Assert.That(_log, Is.EqualTo(new[] { "Loading True", "Loading False", "Showing True" }));
        }

        [Test]
        public void FailedLoadEndsLoadingBeforeTheResult()
        {
            StartManager();

            ShowRewardAd();
            Provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill));

            Assert.That(_log, Is.EqualTo(new[] { "Loading True", "Loading False", "result NoFill" }));
        }

        [Test]
        public void TimedOutLoadEndsLoading()
        {
            StartManager();

            ShowRewardAd();
            Host.Advance(Timeout);

            Assert.That(_log, Is.EqualTo(new[] { "Loading True", "Loading False", "result Timeout" }));
        }

        [Test]
        public void FailedShowEndsShowing()
        {
            StartManagerWithRewardAd();

            ShowRewardAd();
            Provider.Listener.Failed(AdFailure.ShowFailed, 1, "failed");
            Host.Advance(ShowEnd);

            Assert.That(_log, Is.EqualTo(new[] { "Showing True", "Showing False", "result ShowFailed" }));
        }

        [Test]
        public void ThrowingProviderEndsShowing()
        {
            StartManagerWithRewardAd();
            Provider.ThrowOnShow = true;

            ShowRewardAd();
            Host.Advance(ShowEnd);

            Assert.That(_log, Is.EqualTo(new[] { "Showing True", "Showing False", "result ShowFailed" }));
        }

        [Test]
        public void RejectedShowReportsNothing()
        {
            StartManagerWithRewardAd();
            Provider.CanRequestAds = false;

            ShowRewardAd();

            Assert.That(_log, Is.EqualTo(new[] { "result ConsentRequired" }));
        }

        [Test]
        public void BackgroundLoadsReportNothing()
        {
            StartManager();
            AdManager.LoadRewardAd();
            Provider.CompleteRewardLoad();

            Assert.That(_log, Is.Empty);
        }

        [Test]
        public void InterstitialAdsReportNothing()
        {
            StartManagerWithRewardAd();
            AdManager.LoadInterstitialAd();
            Provider.CompleteInterstitialLoad();

            AdManager.ShowInterstitialAd();
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(_log, Is.Empty);
        }

        [Test]
        public void NoProviderReportsNothing()
        {
            ShowRewardAd();

            Assert.That(_log, Is.EqualTo(new[] { "result Unsupported" }));
        }

        [Test]
        public void ThrowingHandlerDoesNotStopTheShow()
        {
            StartManagerWithRewardAd();
            AdManager.LoadingChanged += (kind, active) => throw new InvalidOperationException("game");

            ShowRewardAd();
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(_log, Does.Contain("result None"));
            Assert.That(Host.Exceptions, Has.Count.EqualTo(2));
        }

        [Test]
        public void ReplacingTheProviderEndsShowing()
        {
            StartManagerWithRewardAd();
            ShowRewardAd();

            AdManager.SetProvider(new FakeAdProvider(), new FakeAdHost(), Timeout);

            Assert.That(_log, Is.EqualTo(new[] { "Showing True", "Showing False", "result ProviderError" }));
        }

        [Test]
        public void ReplacingTheProviderEndsLoading()
        {
            StartManager();
            ShowRewardAd();

            AdManager.SetProvider(new FakeAdProvider(), new FakeAdHost(), Timeout);

            Assert.That(_log, Is.EqualTo(new[] { "Loading True", "Loading False", "result ProviderError" }));
        }

        [Test]
        public void ResetRemovesHandlers()
        {
            AdManager.ResetState();
            StartManagerWithRewardAd();

            ShowRewardAd();

            Assert.That(_log, Is.EqualTo(new string[0]));
        }
    }
}
