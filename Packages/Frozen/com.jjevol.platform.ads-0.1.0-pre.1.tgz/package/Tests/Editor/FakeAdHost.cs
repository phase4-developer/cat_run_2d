using System;
using System.Collections.Generic;
using System.Linq;

namespace PlatformLibrary.Ads.Tests
{
    /// <summary>A host with a hand-driven clock. With <see cref="HoldPosts"/> it stands in for a callback from a worker thread.</summary>
    internal sealed class FakeAdHost : IAdHost
    {
        private sealed class Timer
        {
            public float Due;
            public Action Action;
        }

        private readonly List<Timer> _timers = new List<Timer>();
        private readonly Queue<Action> _held = new Queue<Action>();
        private float _now;

        public bool IsNetworkReachable { get; set; } = true;
        public bool HoldPosts { get; set; }
        public List<string> Warnings { get; } = new List<string>();
        public List<Exception> Exceptions { get; } = new List<Exception>();

        public void Post(Action action)
        {
            if (HoldPosts) _held.Enqueue(action);
            else action();
        }

        public void RunHeldPosts()
        {
            HoldPosts = false;
            while (_held.Count > 0) _held.Dequeue()();
        }

        public Action Schedule(float seconds, Action action)
        {
            var timer = new Timer { Due = _now + seconds, Action = action };
            _timers.Add(timer);
            return () => _timers.Remove(timer);
        }

        public void Advance(float seconds)
        {
            _now += seconds;
            while (true)
            {
                Timer next = _timers.Where(timer => timer.Due <= _now).OrderBy(timer => timer.Due).FirstOrDefault();
                if (next == null) return;
                _timers.Remove(next);
                next.Action();
            }
        }

        public void LogWarning(string message) => Warnings.Add(message);
        public void LogException(Exception exception) => Exceptions.Add(exception);
    }
}
