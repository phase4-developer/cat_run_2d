using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdInterstitialTests : AdTestBase
    {
        private void StartWithInterstitialAd()
        {
            StartManagerWithRewardAd();
            AdManager.LoadInterstitialAd();
            Provider.CompleteInterstitialLoad();
        }

        [Test]
        public void ProviderWithoutInterstitialsAnswersUnsupportedInEveryState()
        {
            Provider.SupportsInterstitialAd = false;
            Provider.InterstitialAdUnitId = string.Empty;
            UseProvider();

            AdManager.LoadInterstitialAd(Record);
            AdManager.ShowInterstitialAd(Record);
            AdManager.Initialize();
            Provider.CompleteInitialize();
            AdManager.LoadInterstitialAd(Record);
            AdManager.ShowInterstitialAd(Record);

            Assert.That(Results, Has.Count.EqualTo(4));
            foreach (AdResult result in Results)
                Assert.That(result.Failure, Is.EqualTo(AdFailure.Unsupported));
            Assert.That(Provider.InterstitialLoads, Is.Empty);
        }

        [Test]
        public void NothingLoadsUntilTheGameAsks()
        {
            StartManagerWithRewardAd();

            Assert.That(Provider.InterstitialLoads, Is.Empty);
        }

        [Test]
        public void ShowWithoutAnAdAnswersNoFillAtOnceAndLoadsForNextTime()
        {
            StartManagerWithRewardAd();

            AdManager.ShowInterstitialAd(new AdRequest("stage"), Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.NoFill));
            Assert.That(Provider.InterstitialLoads, Has.Count.EqualTo(1));
            Assert.That(Provider.InterstitialLoads[0].AdUnitId, Is.EqualTo("interstitial-unit"));
        }

        [Test]
        public void ShownAdAnswersOnCloseWithoutAReward()
        {
            StartWithInterstitialAd();

            AdManager.ShowInterstitialAd(new AdRequest("stage"), Record);
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.RewardGranted, Is.False);
            Assert.That(Single.IsSkipped, Is.False);
            Assert.That(Single.Placement, Is.EqualTo("stage"));
        }

        [Test]
        public void EndedShowLoadsTheNext()
        {
            StartWithInterstitialAd();

            AdManager.ShowInterstitialAd(Record);
            Provider.Listener.Failed(AdFailure.ShowFailed, 1, "failed");
            Host.Advance(ShowEnd);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ShowFailed));
            Assert.That(Provider.InterstitialLoads, Has.Count.EqualTo(2));
        }

        [Test]
        public void ShowDoesNotFireRewardCompleted()
        {
            StartWithInterstitialAd();
            int completed = 0;
            AdManager.RewardCompleted += _ => completed++;

            AdManager.ShowInterstitialAd();
            Provider.Listener.Closed();
            Host.Advance(ShowEnd);

            Assert.That(completed, Is.Zero);
        }

        [Test]
        public void SilentProviderTimesOut()
        {
            StartManagerWithRewardAd();

            AdManager.LoadInterstitialAd(Record);
            Host.Advance(Timeout);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Timeout));
        }

        [Test]
        public void SameRequestsShareOneLoad()
        {
            StartManagerWithRewardAd();

            AdManager.LoadInterstitialAd(Record);
            AdManager.LoadInterstitialAd(Record);
            Provider.CompleteInterstitialLoad();

            Assert.That(Results, Has.Count.EqualTo(2));
            Assert.That(Provider.InterstitialLoads, Has.Count.EqualTo(1));
        }

        [Test]
        public void ShowWhileARewardShowsAnswersBusy()
        {
            StartWithInterstitialAd();
            AdManager.ShowRewardAd(_ => { });

            AdManager.ShowInterstitialAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
        }

        [Test]
        public void RewardWhileAnInterstitialShowsAnswersBusy()
        {
            StartWithInterstitialAd();
            AdManager.ShowInterstitialAd();

            AdManager.ShowRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Busy));
        }
    }
}
