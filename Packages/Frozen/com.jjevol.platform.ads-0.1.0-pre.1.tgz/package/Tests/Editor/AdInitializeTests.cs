using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdInitializeTests : AdTestBase
    {
        [Test]
        public void InitializedOnlyAfterTheProviderFinishes()
        {
            UseProvider();

            AdManager.Initialize();
            Assert.That(AdManager.IsInitialized, Is.False);

            Provider.CompleteInitialize();
            Assert.That(AdManager.IsInitialized, Is.True);
        }

        [Test]
        public void RepeatedInitializeStartsTheSdkOnce()
        {
            UseProvider();

            AdManager.Initialize();
            AdManager.Initialize();
            Provider.CompleteInitialize();
            AdManager.Initialize();

            Assert.That(Provider.InitializeCount, Is.EqualTo(1));
        }

        [Test]
        public void FinishingStartsLoadingAReward()
        {
            StartManager();

            Assert.That(Provider.RewardLoads, Has.Count.EqualTo(1));
            Assert.That(Provider.RewardLoads[0].AdUnitId, Is.EqualTo("reward-unit"));
            Assert.That(AdManager.IsRewardAdLoading, Is.True);
        }

        [Test]
        public void FailureLeavesItUninitializedAndAllowsARetry()
        {
            UseProvider();
            AdManager.Initialize();

            Provider.PendingInitialize(AdResult.Failed(AdFailure.ConsentRequired));

            Assert.That(AdManager.IsInitialized, Is.False);
            Assert.That(Provider.RewardLoads, Is.Empty);
            Assert.That(Host.Warnings, Has.Count.EqualTo(1));

            AdManager.Initialize();
            Assert.That(Provider.InitializeCount, Is.EqualTo(2));
        }

        [Test]
        public void ThrowingProviderCountsAsAFailure()
        {
            UseProvider();
            Provider.ThrowOnInitialize = true;

            Assert.DoesNotThrow(AdManager.Initialize);

            Assert.That(AdManager.IsInitialized, Is.False);
            Assert.That(Host.Exceptions, Has.Count.EqualTo(1));

            Provider.ThrowOnInitialize = false;
            AdManager.Initialize();
            Provider.CompleteInitialize();
            Assert.That(AdManager.IsInitialized, Is.True);
        }

        [Test]
        public void ShowBeforeInitializeStartsItAndAnswersNotInitialized()
        {
            UseProvider();

            AdManager.ShowRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.NotInitialized));
            Assert.That(Provider.InitializeCount, Is.EqualTo(1));
        }

        [Test]
        public void LoadBeforeInitializeOnlyAnswersNotInitialized()
        {
            UseProvider();

            AdManager.LoadRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.NotInitialized));
            Assert.That(Provider.InitializeCount, Is.Zero);
        }

        [Test]
        public void ReadyNeedsInitialization()
        {
            UseProvider();
            Provider.IsRewardAdReady = true;

            Assert.That(AdManager.IsRewardAdReady, Is.False);
        }
    }
}
