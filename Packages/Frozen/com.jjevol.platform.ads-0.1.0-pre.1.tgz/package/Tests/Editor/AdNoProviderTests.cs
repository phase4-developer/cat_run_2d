using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdNoProviderTests : AdTestBase
    {
        [Test]
        public void EveryAdCallAnswersUnsupported()
        {
            var request = new AdRequest("revive");

            AdManager.LoadRewardAd(request, Record);
            AdManager.ShowRewardAd(request, Record);
            AdManager.LoadInterstitialAd(request, Record);
            AdManager.ShowInterstitialAd(request, Record);
            AdManager.ShowBanner(request, Record);

            Assert.That(Results, Has.Count.EqualTo(5));
            foreach (AdResult result in Results)
            {
                Assert.That(result.Failure, Is.EqualTo(AdFailure.Unsupported));
                Assert.That(result.Success, Is.False);
                Assert.That(result.RewardGranted, Is.False);
                Assert.That(result.Placement, Is.EqualTo("revive"));
            }
        }

        [Test]
        public void AnswerDoesNotDependOnInitialize()
        {
            AdManager.ShowRewardAd(Record);
            AdManager.Initialize();
            AdManager.ShowRewardAd(Record);

            Assert.That(Results[0].Failure, Is.EqualTo(AdFailure.Unsupported));
            Assert.That(Results[1].Failure, Is.EqualTo(AdFailure.Unsupported));
        }

        [Test]
        public void InitializeCompletesAtOnce()
        {
            Assert.That(AdManager.IsInitialized, Is.False);

            AdManager.Initialize();

            Assert.That(AdManager.IsInitialized, Is.True);
        }

        [Test]
        public void NoAdIsEverReadyOrLoading()
        {
            AdManager.Initialize();
            AdManager.LoadRewardAd();

            Assert.That(AdManager.IsRewardAdReady, Is.False);
            Assert.That(AdManager.IsRewardAdLoading, Is.False);
        }

        [Test]
        public void CallsWithoutCallbacksDoNothing()
        {
            Assert.DoesNotThrow(() =>
            {
                AdManager.LoadRewardAd();
                AdManager.ShowRewardAd(null);
                AdManager.LoadInterstitialAd();
                AdManager.ShowInterstitialAd();
                AdManager.ShowBanner();
                AdManager.HideBanner();
            });
        }

        [Test]
        public void RemovingTheProviderReturnsToUnsupported()
        {
            StartManagerWithRewardAd();

            AdManager.SetProvider(null);
            AdManager.ShowRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Unsupported));
            Assert.That(AdManager.IsInitialized, Is.False);
            Assert.That(AdManager.IsRewardAdReady, Is.False);
        }
    }
}
