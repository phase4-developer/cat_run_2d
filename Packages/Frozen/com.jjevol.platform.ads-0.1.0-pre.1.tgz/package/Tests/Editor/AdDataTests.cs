using System;
using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdDataTests
    {
        [Test]
        public void DefaultRequestHasEmptyValuesAndNoVerification()
        {
            AdRequest request = default;

            Assert.That(request.Placement, Is.Empty);
            Assert.That(request.AdUnitId, Is.Empty);
            Assert.That(request.UserId, Is.Empty);
            Assert.That(request.CustomData, Is.Empty);
            Assert.That(request.RequestId, Is.Empty);
            Assert.That(request.HasServerSideVerificationData, Is.False);
        }

        [Test]
        public void FirstRequestArgumentIsThePlacement()
        {
            Assert.That(new AdRequest("revive").Placement, Is.EqualTo("revive"));
        }

        [Test]
        public void NullRequestValuesReadAsEmpty()
        {
            var request = new AdRequest(null, null, null, null, null);

            Assert.That(request.Placement, Is.Empty);
            Assert.That(request.AdUnitId, Is.Empty);
            Assert.That(request.UserId, Is.Empty);
            Assert.That(request.CustomData, Is.Empty);
            Assert.That(request.RequestId, Is.Empty);
        }

        [Test]
        public void VerificationDataMeansARequestFlagUserOrCustomData()
        {
            Assert.That(new AdRequest(useServerSideVerification: true).HasServerSideVerificationData, Is.True);
            Assert.That(new AdRequest(userId: "user").HasServerSideVerificationData, Is.True);
            Assert.That(new AdRequest(customData: "data").HasServerSideVerificationData, Is.True);
            Assert.That(new AdRequest(requestId: "request").HasServerSideVerificationData, Is.False);
        }

        [Test]
        public void FailedResultKeepsTheSdkCodeAndDetail()
        {
            AdResult result = AdResult.Failed(AdFailure.NoFill, 3, "no ad");

            Assert.That(result.Failure, Is.EqualTo(AdFailure.NoFill));
            Assert.That(result.Success, Is.False);
            Assert.That(result.ProviderCode, Is.EqualTo(3));
            Assert.That(result.Detail, Is.EqualTo("no ad"));
        }

        [Test]
        public void ProviderCannotReportAFailureOfNone()
        {
            Assert.That(AdResult.Failed(AdFailure.None).Failure, Is.EqualTo(AdFailure.ProviderError));
        }

        [Test]
        public void SucceededResultHasNoFailureAndGrantsNothing()
        {
            AdResult result = AdResult.Succeeded();

            Assert.That(result.Success, Is.True);
            Assert.That(result.RewardGranted, Is.False);
            Assert.That(result.Detail, Is.Empty);
        }

        [Test]
        public void ResultCarriesTheRequestValues()
        {
            var request = new AdRequest("revive", "unit", "user", "data", "request");

            AdResult result = AdResult.Failed(AdFailure.Network).For(request);

            Assert.That(result.Placement, Is.EqualTo("revive"));
            Assert.That(result.AdUnitId, Is.EqualTo("unit"));
            Assert.That(result.UserId, Is.EqualTo("user"));
            Assert.That(result.CustomData, Is.EqualTo("data"));
            Assert.That(result.RequestId, Is.EqualTo("request"));
            Assert.That(result.ServerVerificationRequested, Is.True);
            Assert.That(result.ServerVerified, Is.False);
        }

        [Test]
        public void FailureNamesMatchTheDesign()
        {
            Assert.That(Enum.GetNames(typeof(AdFailure)), Is.EqualTo(new[]
            {
                "None", "NotInitialized", "ConsentRequired", "InvalidAdUnit", "Network",
                "NoFill", "Timeout", "Busy", "ShowFailed", "Unsupported", "ProviderError"
            }));
        }

        [Test]
        public void RevenueTurnsNullTextIntoEmpty()
        {
            var revenue = new AdRevenue(null, null, null, null, 1.5d, null, null);

            Assert.That(revenue.AdPlatform, Is.Empty);
            Assert.That(revenue.AdSource, Is.Empty);
            Assert.That(revenue.AdUnitId, Is.Empty);
            Assert.That(revenue.AdFormat, Is.Empty);
            Assert.That(revenue.CurrencyCode, Is.Empty);
            Assert.That(revenue.Placement, Is.Empty);
            Assert.That(revenue.Revenue, Is.EqualTo(1.5d));
        }
    }
}
