using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class AdProviderChangeTests : AdTestBase
    {
        private static void Replace() => AdManager.SetProvider(new FakeAdProvider(), new FakeAdHost(), Timeout);

        [Test]
        public void SettingTheSameProviderKeepsItsState()
        {
            StartManagerWithRewardAd();

            UseProvider();

            Assert.That(AdManager.IsInitialized, Is.True);
            Assert.That(AdManager.IsRewardAdReady, Is.True);
        }

        [Test]
        public void NewProviderStartsUninitialized()
        {
            StartManagerWithRewardAd();

            Replace();

            Assert.That(AdManager.IsInitialized, Is.False);
            Assert.That(AdManager.IsRewardAdReady, Is.False);
        }

        [Test]
        public void ReplacedProviderReleasesItsAds()
        {
            StartManagerWithRewardAd();
            int discards = Provider.RewardDiscardCount;

            Replace();

            Assert.That(Provider.RewardDiscardCount, Is.GreaterThan(discards));
            Assert.That(Provider.InterstitialDiscardCount, Is.GreaterThanOrEqualTo(1));
            Assert.That(Provider.HideBannerCount, Is.EqualTo(1));
        }

        [Test]
        public void PendingCallsEndWithProviderError()
        {
            StartManager();
            AdManager.LoadRewardAd(Record);
            AdManager.LoadInterstitialAd(Record);
            AdManager.ShowBanner(Record);

            Replace();

            Assert.That(Results, Has.Count.EqualTo(3));
            foreach (AdResult result in Results)
                Assert.That(result.Failure, Is.EqualTo(AdFailure.ProviderError));
        }

        [Test]
        public void ShowingAdWithNoRewardEndsWithProviderErrorAndRewardCompleted()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(new AdRequest("revive"), Record);
            var completed = new List<AdResult>();
            AdManager.RewardCompleted += completed.Add;

            Replace();

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ProviderError));
            Assert.That(Single.RewardGranted, Is.False);
            Assert.That(completed, Has.Count.EqualTo(1));
            Assert.That(completed[0].Failure, Is.EqualTo(AdFailure.ProviderError));
            Assert.That(completed[0].Placement, Is.EqualTo("revive"));
        }

        [Test]
        public void RewardEarnedBeforeTheChangeIsKept()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(new AdRequest("revive"), Record);
            var completed = new List<AdResult>();
            AdManager.RewardCompleted += completed.Add;
            Provider.Listener.RewardEarned("coin", 5d);

            Replace();

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.RewardGranted, Is.True);
            Assert.That(Single.RewardType, Is.EqualTo("coin"));
            Assert.That(Single.RewardAmount, Is.EqualTo(5d));
            Assert.That(Single.Placement, Is.EqualTo("revive"));
            Assert.That(completed, Has.Count.EqualTo(1));
            Assert.That(completed[0].RewardGranted, Is.True);
        }

        [Test]
        public void RewardWaitingOutTheCloseDelayIsKept()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(Record);
            Provider.Listener.RewardEarned("coin", 5d);
            Provider.Listener.Closed();

            Replace();
            Host.Advance(ShowEnd);

            Assert.That(Single.RewardGranted, Is.True);
        }

        [Test]
        public void ClosedAdKeepsItsOwnResult()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(Record);
            Provider.Listener.Closed();

            Replace();

            Assert.That(Single.Success, Is.True);
            Assert.That(Single.IsSkipped, Is.True);
        }

        [Test]
        public void FailedAdKeepsItsOwnResult()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(Record);
            Provider.Listener.Failed(AdFailure.ShowFailed, 7, "failed");

            Replace();

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ShowFailed));
            Assert.That(Single.ProviderCode, Is.EqualTo(7));
        }

        [Test]
        public void ShowingInterstitialDoesNotFireRewardCompleted()
        {
            StartManagerWithRewardAd();
            AdManager.LoadInterstitialAd();
            Provider.CompleteInterstitialLoad();
            AdManager.ShowInterstitialAd(Record);
            int completed = 0;
            AdManager.RewardCompleted += _ => completed++;

            Replace();

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.ProviderError));
            Assert.That(completed, Is.Zero);
        }

        [Test]
        public void LateAnswersFromTheOldProviderAreIgnored()
        {
            StartManagerWithRewardAd();
            AdManager.ShowRewardAd(Record);
            IAdShowListener listener = Provider.Listener;
            AdRevenue paid = null;
            AdManager.AdRevenuePaid += revenue => paid = revenue;

            Replace();
            listener.RewardEarned("coin", 1d);
            listener.Closed();
            Host.Advance(ShowEnd);
            Provider.RaiseRevenue(new AdRevenue("network", "source", "unit", "REWARDED", 1d, "USD"));

            Assert.That(Results, Has.Count.EqualTo(1));
            Assert.That(paid, Is.Null);
        }

        [Test]
        public void InitializeFinishingAfterTheChangeIsIgnored()
        {
            UseProvider();
            AdManager.Initialize();
            var late = Provider.PendingInitialize;

            Replace();
            late(AdResult.Succeeded());

            Assert.That(AdManager.IsInitialized, Is.False);
            Assert.That(Provider.RewardLoads, Is.Empty);
        }

        [Test]
        public void ResetClearsEventsAndProvider()
        {
            StartManagerWithRewardAd();
            int completed = 0;
            AdManager.RewardCompleted += _ => completed++;

            AdManager.ResetState();
            AdManager.ShowRewardAd(Record);

            Assert.That(Single.Failure, Is.EqualTo(AdFailure.Unsupported));
            Assert.That(completed, Is.Zero);
        }
    }
}
