using System;
using System.Collections.Generic;

namespace PlatformLibrary.Ads.Tests
{
    /// <summary>A provider whose SDK answers only when a test tells it to.</summary>
    public sealed class FakeAdProvider : IAdProvider
    {
        private string _rewardAdUnitId = "reward-unit";
        private string _interstitialAdUnitId = "interstitial-unit";
        private string _bannerAdUnitId = "banner-unit";

        public event Action<AdRevenue> RevenuePaid;

        public bool SupportsInterstitialAd { get; set; } = true;
        public bool SupportsBanner { get; set; } = true;
        public bool BindsServerVerificationAtLoad { get; set; }
        public bool CanRequestAds { get; set; } = true;
        public string RewardAdUnitId
        {
            get => ThrowOnAdUnit ? throw new InvalidOperationException("ad unit") : _rewardAdUnitId;
            set => _rewardAdUnitId = value;
        }

        public string InterstitialAdUnitId
        {
            get => ThrowOnAdUnit ? throw new InvalidOperationException("ad unit") : _interstitialAdUnitId;
            set => _interstitialAdUnitId = value;
        }

        public string BannerAdUnitId
        {
            get => ThrowOnAdUnit ? throw new InvalidOperationException("ad unit") : _bannerAdUnitId;
            set => _bannerAdUnitId = value;
        }

        public bool IsRewardAdReady { get; set; }
        public bool IsInterstitialAdReady { get; set; }

        public bool ThrowOnInitialize { get; set; }
        public bool ThrowOnLoad { get; set; }
        public bool ThrowOnShow { get; set; }
        public bool ThrowOnDiscard { get; set; }
        public bool ThrowOnHideBanner { get; set; }
        public bool ThrowOnAdUnit { get; set; }

        public int InitializeCount { get; private set; }
        public int RewardDiscardCount { get; private set; }
        public int InterstitialDiscardCount { get; private set; }
        public int HideBannerCount { get; private set; }
        public int BannerShowCount { get; private set; }

        public List<AdRequest> RewardLoads { get; } = new List<AdRequest>();
        public List<AdRequest> InterstitialLoads { get; } = new List<AdRequest>();
        public AdRequest BannerRequest { get; private set; }
        public AdRequest ShownRequest { get; private set; }
        public IAdShowListener Listener { get; private set; }

        public Action<AdResult> PendingInitialize { get; private set; }
        public Action<AdResult> PendingRewardLoad { get; private set; }
        public Action<AdResult> PendingInterstitialLoad { get; private set; }
        public Action<AdResult> PendingBanner { get; private set; }

        public void Initialize(Action<AdResult> completed)
        {
            if (ThrowOnInitialize) throw new InvalidOperationException("initialize");
            InitializeCount++;
            PendingInitialize = completed;
        }

        public void LoadRewardAd(AdRequest request, Action<AdResult> completed)
        {
            if (ThrowOnLoad) throw new InvalidOperationException("load");
            RewardLoads.Add(request);
            PendingRewardLoad = completed;
        }

        public void ShowRewardAd(AdRequest request, IAdShowListener listener)
        {
            if (ThrowOnShow) throw new InvalidOperationException("show");
            ShownRequest = request;
            Listener = listener;
        }

        public void DiscardRewardAd()
        {
            if (ThrowOnDiscard) throw new InvalidOperationException("discard");
            RewardDiscardCount++;
            IsRewardAdReady = false;
        }

        public void LoadInterstitialAd(AdRequest request, Action<AdResult> completed)
        {
            InterstitialLoads.Add(request);
            PendingInterstitialLoad = completed;
        }

        public void ShowInterstitialAd(AdRequest request, IAdShowListener listener)
        {
            ShownRequest = request;
            Listener = listener;
        }

        public void DiscardInterstitialAd()
        {
            if (ThrowOnDiscard) throw new InvalidOperationException("discard");
            InterstitialDiscardCount++;
            IsInterstitialAdReady = false;
        }

        public void ShowBanner(AdRequest request, Action<AdResult> completed)
        {
            BannerShowCount++;
            BannerRequest = request;
            PendingBanner = completed;
        }

        public void HideBanner()
        {
            if (ThrowOnHideBanner) throw new InvalidOperationException("hide banner");
            HideBannerCount++;
        }

        public void CompleteInitialize() => PendingInitialize(AdResult.Succeeded());

        public void CompleteRewardLoad()
        {
            IsRewardAdReady = true;
            PendingRewardLoad(AdResult.Succeeded());
        }

        public void CompleteInterstitialLoad()
        {
            IsInterstitialAdReady = true;
            PendingInterstitialLoad(AdResult.Succeeded());
        }

        public void RaiseRevenue(AdRevenue revenue) => RevenuePaid?.Invoke(revenue);
    }
}
