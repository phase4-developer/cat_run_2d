using System;
using System.Collections;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Ads.Tests
{
    public sealed class UnityAdHostTests
    {
        // The real host, except that the machine's network state does not decide the test.
        private sealed class ReachableHost : IAdHost
        {
            private readonly IAdHost _host = UnityAdHost.Instance;

            public bool IsNetworkReachable => true;
            public void Post(Action action) => _host.Post(action);
            public Action Schedule(float seconds, Action action) => _host.Schedule(seconds, action);
            public void LogWarning(string message) => Debug.Log(message);
            public void LogException(Exception exception) => _host.LogException(exception);
        }

        [SetUp]
        public void SetUp() => AdManager.ResetState();

        [TearDown]
        public void TearDown() => AdManager.ResetState();

        [UnityTest]
        public IEnumerator WorkerThreadCallbackRunsOnTheMainThreadOnALaterUpdate()
        {
            int mainThread = Thread.CurrentThread.ManagedThreadId;
            int callbackThread = 0;
            IAdHost host = UnityAdHost.Instance;

            Task.Run(() => host.Post(() => callbackThread = Thread.CurrentThread.ManagedThreadId)).GetAwaiter().GetResult();
            Assert.That(callbackThread, Is.Zero);

            yield return null;
            yield return null;

            Assert.That(callbackThread, Is.EqualTo(mainThread));
        }

        [UnityTest]
        public IEnumerator ScheduledActionRunsAfterRealTimeAndCanBeCancelled()
        {
            IAdHost host = UnityAdHost.Instance;
            bool ran = false;
            bool cancelled = false;

            host.Schedule(0.01f, () => ran = true);
            host.Schedule(0.01f, () => cancelled = true)();

            yield return new WaitForSecondsRealtime(0.1f);

            Assert.That(ran, Is.True);
            Assert.That(cancelled, Is.False);
        }

        [Test]
        public void HostSurvivesSceneLoads()
        {
            Assert.That(UnityAdHost.Instance.gameObject.scene.name, Is.EqualTo("DontDestroyOnLoad"));
        }

        [UnityTest]
        public IEnumerator GameWithNoProviderKeepsRunning()
        {
            AdResult? result = null;

            AdManager.Initialize();
            yield return null;
            AdManager.ShowRewardAd(new AdRequest("revive"), value => result = value);

            Assert.That(result?.Failure, Is.EqualTo(AdFailure.Unsupported));
            Assert.That(AdManager.IsInitialized, Is.True);
            Assert.That(AdManager.IsRewardAdReady, Is.False);
        }

        [UnityTest]
        public IEnumerator LoadTimesOutInRealTime()
        {
            var provider = new FakeAdProvider();
            AdResult? result = null;
            AdManager.SetProvider(provider, new ReachableHost(), 0.05f);
            AdManager.Initialize();
            provider.CompleteInitialize();
            provider.PendingRewardLoad(AdResult.Failed(AdFailure.NoFill));

            AdManager.LoadRewardAd(new AdRequest("revive"), value => result = value);
            Assert.That(AdManager.IsRewardAdLoading, Is.True);

            yield return new WaitForSecondsRealtime(0.2f);

            Assert.That(result?.Failure, Is.EqualTo(AdFailure.Timeout));
            Assert.That(AdManager.IsRewardAdLoading, Is.False);
        }

        [UnityTest]
        public IEnumerator RewardFromAWorkerThreadReachesTheCallbackOnTheMainThread()
        {
            var provider = new FakeAdProvider();
            int mainThread = Thread.CurrentThread.ManagedThreadId;
            int callbackThread = 0;
            AdResult? result = null;
            AdManager.SetProvider(provider, new ReachableHost(), 1f);
            AdManager.Initialize();
            provider.CompleteInitialize();
            provider.CompleteRewardLoad();

            AdManager.ShowRewardAd(new AdRequest("revive"), value =>
            {
                callbackThread = Thread.CurrentThread.ManagedThreadId;
                result = value;
            });

            Task.Run(() =>
            {
                provider.Listener.RewardEarned("coin", 3d);
                provider.Listener.Closed();
            }).GetAwaiter().GetResult();

            yield return new WaitForSecondsRealtime(0.2f);

            Assert.That(callbackThread, Is.EqualTo(mainThread));
            Assert.That(result?.RewardGranted, Is.True);
            Assert.That(result?.RewardAmount, Is.EqualTo(3d));
        }
    }
}
