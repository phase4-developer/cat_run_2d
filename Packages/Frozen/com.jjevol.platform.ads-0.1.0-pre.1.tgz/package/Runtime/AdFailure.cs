namespace PlatformLibrary.Ads
{
    /// <summary>Why an ad call failed. Games branch on this, never on an SDK code.</summary>
    public enum AdFailure
    {
        None,
        NotInitialized,
        ConsentRequired,
        InvalidAdUnit,
        Network,
        NoFill,
        Timeout,
        Busy,
        ShowFailed,
        Unsupported,
        ProviderError
    }
}
