using System;

namespace PlatformLibrary.Ads
{
    /// <summary>
    /// Connects one ad SDK to <see cref="AdManager"/>. Games do not call this.
    /// <para>
    /// The manager calls every member on the Unity main thread, and handles duplicate requests, load timeouts,
    /// network and readiness checks, reloads and result metadata. A provider only talks to its SDK and turns
    /// SDK codes into <see cref="AdFailure"/>.
    /// </para>
    /// <para>
    /// Callbacks, the listener and <see cref="RevenuePaid"/> may be used from any thread.
    /// Each load or banner callback must be called once, unless the ad was discarded or hidden first.
    /// </para>
    /// </summary>
    public interface IAdProvider
    {
        event Action<AdRevenue> RevenuePaid;

        bool SupportsInterstitialAd { get; }
        bool SupportsBanner { get; }

        /// <summary>
        /// True when server verification values are fixed at load. A loaded ad is then reused only for a
        /// request with the same values.
        /// </summary>
        bool BindsServerVerificationAtLoad { get; }

        /// <summary>False while the player's consent does not allow ad requests.</summary>
        bool CanRequestAds { get; }

        /// <summary>Unit used when a request names none. Read on every request, so it may change at runtime.</summary>
        string RewardAdUnitId { get; }
        string InterstitialAdUnitId { get; }
        string BannerAdUnitId { get; }

        bool IsRewardAdReady { get; }
        bool IsInterstitialAdReady { get; }

        /// <summary>Starts the SDK and asks for consent. After a failure the manager stays uninitialized and can retry.</summary>
        void Initialize(Action<AdResult> completed);

        void LoadRewardAd(AdRequest request, Action<AdResult> completed);
        void ShowRewardAd(AdRequest request, IAdShowListener listener);

        /// <summary>Destroys the loaded ad and ignores a load in progress. The manager calls this after every show, failed load and timeout.</summary>
        void DiscardRewardAd();

        void LoadInterstitialAd(AdRequest request, Action<AdResult> completed);
        void ShowInterstitialAd(AdRequest request, IAdShowListener listener);
        void DiscardInterstitialAd();

        /// <summary>Replaces any current banner. <paramref name="completed"/> reports its first load.</summary>
        void ShowBanner(AdRequest request, Action<AdResult> completed);
        void HideBanner();
    }

    /// <summary>How a provider reports a full-screen ad. Anything after the first Closed or Failed may be ignored.</summary>
    public interface IAdShowListener
    {
        void RewardEarned(string rewardType, double rewardAmount);
        void Closed();
        void Failed(AdFailure failure, int providerCode, string detail);
    }
}
