namespace PlatformLibrary.Ads
{
    /// <summary>What <see cref="AdManager.LoadingChanged"/> reports. Each kind starts and ends once per reward ad call.</summary>
    public enum AdLoadingKind
    {
        /// <summary>A reward ad is on screen, until its result is ready.</summary>
        Showing,

        /// <summary>A shown reward ad is waiting for its load.</summary>
        Loading
    }
}
