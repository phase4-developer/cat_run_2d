using System;

namespace PlatformLibrary.Ads
{
    /// <summary>One provider's state behind <see cref="AdManager"/>. Every member except the provider callbacks runs on the main thread.</summary>
    internal sealed class AdSession
    {
        internal const float DefaultLoadTimeoutSeconds = 15f;

        private readonly IAdHost _host;
        private readonly Action<AdRevenue> _revenuePaid;
        private readonly Action<AdLoadingKind, bool> _loadingChanged;
        private readonly AdSlot _rewardSlot;
        private readonly AdSlot _interstitialSlot;

        private bool _initializing;
        private bool _bannerPending;
        private int _bannerVersion;
        private AdRequest _bannerRequest;
        private Action<AdResult> _bannerCallback;
        private Action _cancelBannerTimeout;

        public AdSession(
            IAdProvider provider,
            IAdHost host,
            Action<AdRevenue> revenuePaid,
            Action<AdResult> rewardCompleted,
            Action<AdLoadingKind, bool> loadingChanged,
            float loadTimeoutSeconds)
        {
            Provider = provider;
            _host = host;
            _revenuePaid = revenuePaid;
            _loadingChanged = loadingChanged;
            LoadTimeoutSeconds = loadTimeoutSeconds;
            _rewardSlot = new RewardAdSlot(this, rewardCompleted);
            _interstitialSlot = new InterstitialAdSlot(this);
            Provider.RevenuePaid += OnRevenuePaid;
        }

        public IAdProvider Provider { get; }
        public IAdHost Host => _host;
        public float LoadTimeoutSeconds { get; }
        public bool IsClosed { get; private set; }
        public bool IsInitialized { get; private set; }
        public bool IsRewardAdReady => IsInitialized && Provider.IsRewardAdReady;
        public bool IsRewardAdLoading => _rewardSlot.IsLoading;
        public bool IsShowing => _rewardSlot.IsShowing || _interstitialSlot.IsShowing;

        public void Initialize()
        {
            if (IsInitialized || _initializing) return;

            _initializing = true;
            try
            {
                Provider.Initialize(result => _host.Post(() => OnInitialized(result)));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                OnInitialized(AdResult.Failed(AdFailure.ProviderError, 0, exception.Message));
            }
        }

        public void LoadRewardAd(AdRequest request, Action<AdResult> callback) => _rewardSlot.Load(request, callback);
        public void ShowRewardAd(AdRequest request, Action<AdResult> callback) => _rewardSlot.Show(request, callback);
        public void LoadInterstitialAd(AdRequest request, Action<AdResult> callback) => _interstitialSlot.Load(request, callback);
        public void ShowInterstitialAd(AdRequest request, Action<AdResult> callback) => _interstitialSlot.Show(request, callback);

        public void ShowBanner(AdRequest request, Action<AdResult> callback)
        {
            if (string.IsNullOrEmpty(request.AdUnitId)) request = request.WithAdUnitId(ReadAdUnit(() => Provider.BannerAdUnitId));

            AdFailure failure = Check(request, Provider.SupportsBanner);
            if (failure != AdFailure.None)
            {
                Invoke(callback, AdResult.Failed(failure).For(request));
                return;
            }

            EndBanner(AdResult.Failed(AdFailure.Busy, 0, "BANNER_REPLACED"));

            int version = ++_bannerVersion;
            _bannerPending = true;
            _bannerRequest = request;
            _bannerCallback = callback;
            _cancelBannerTimeout = _host.Schedule(LoadTimeoutSeconds, () => OnBannerTimeout(version));
            try
            {
                Provider.ShowBanner(request, result => _host.Post(() =>
                {
                    if (version == _bannerVersion) EndBanner(result);
                }));
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                EndBanner(AdResult.Failed(AdFailure.ProviderError, 0, exception.Message));
            }
        }

        public void HideBanner()
        {
            if (!Provider.SupportsBanner) return;
            HideProviderBanner();
            EndBanner(AdResult.Failed(AdFailure.Busy, 0, "BANNER_HIDDEN"));
        }

        /// <summary>An ad unit comes from the project's own code here, so one that throws counts as no ad unit and the call still answers.</summary>
        public string ReadAdUnit(Func<string> read)
        {
            try
            {
                return read();
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
                return string.Empty;
            }
        }

        /// <summary>The checks every ad call shares, in the order that reports the most useful reason.</summary>
        public AdFailure Check(AdRequest request, bool isSupported)
        {
            if (!isSupported) return AdFailure.Unsupported;
            if (!IsInitialized) return AdFailure.NotInitialized;
            if (!Provider.CanRequestAds) return AdFailure.ConsentRequired;
            if (string.IsNullOrEmpty(request.AdUnitId)) return AdFailure.InvalidAdUnit;
            if (!_host.IsNetworkReachable) return AdFailure.Network;
            return AdFailure.None;
        }

        /// <summary>A game callback that throws must not stop the manager's own cleanup.</summary>
        public void Invoke(Action<AdResult> callback, AdResult result)
        {
            if (callback == null) return;
            try
            {
                callback(result);
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }

        public void RaiseLoadingChanged(AdLoadingKind kind, bool active)
        {
            try
            {
                _loadingChanged(kind, active);
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }

        public void Close()
        {
            IsClosed = true;
            Provider.RevenuePaid -= OnRevenuePaid;
            _rewardSlot.Close();
            _interstitialSlot.Close();
            if (Provider.SupportsBanner) HideProviderBanner();
            _bannerVersion++;
            EndBanner(AdResult.Failed(AdFailure.ProviderError, 0, AdSlot.ProviderReplaced));
        }

        private void OnInitialized(AdResult result)
        {
            if (IsClosed || !_initializing) return;

            _initializing = false;
            if (!result.Success)
            {
                _host.LogWarning($"Initialize failed: {result.Failure} {result.ProviderCode} {result.Detail}");
                return;
            }

            IsInitialized = true;
            _rewardSlot.Load(default, null);
        }

        private void OnRevenuePaid(AdRevenue revenue)
        {
            if (revenue == null) return;
            _host.Post(() =>
            {
                if (IsClosed) return;
                try
                {
                    _revenuePaid(revenue);
                }
                catch (Exception exception)
                {
                    _host.LogException(exception);
                }
            });
        }

        private void OnBannerTimeout(int version)
        {
            if (version != _bannerVersion || !_bannerPending) return;
            _cancelBannerTimeout = null;
            HideProviderBanner();
            EndBanner(AdResult.Failed(AdFailure.Timeout, 0, "BANNER_LOAD_TIMEOUT"));
        }

        private void HideProviderBanner()
        {
            try
            {
                Provider.HideBanner();
            }
            catch (Exception exception)
            {
                _host.LogException(exception);
            }
        }

        private void EndBanner(AdResult result)
        {
            if (!_bannerPending) return;

            _bannerPending = false;
            _cancelBannerTimeout?.Invoke();
            _cancelBannerTimeout = null;
            Action<AdResult> callback = _bannerCallback;
            _bannerCallback = null;
            Invoke(callback, result.For(_bannerRequest));
        }
    }
}
