using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Threading;
using UnityEngine;

namespace PlatformLibrary.Ads
{
    [AddComponentMenu("")]
    internal sealed class UnityAdHost : MonoBehaviour, IAdHost
    {
        private static UnityAdHost _instance;

        private readonly ConcurrentQueue<Action> _queue = new ConcurrentQueue<Action>();
        private int _mainThreadId;

        public static UnityAdHost Instance
        {
            get
            {
                if (_instance != null) return _instance;
                var host = new GameObject(nameof(AdManager));
                if (Application.isPlaying) DontDestroyOnLoad(host);
                _instance = host.AddComponent<UnityAdHost>();
                return _instance;
            }
        }

        public bool IsNetworkReachable => Application.internetReachability != NetworkReachability.NotReachable;

        private void Awake()
        {
            _mainThreadId = Thread.CurrentThread.ManagedThreadId;
        }

        private void Update()
        {
            while (_queue.TryDequeue(out Action action))
                action();
        }

        public void Post(Action action)
        {
            if (Thread.CurrentThread.ManagedThreadId == _mainThreadId) action();
            else _queue.Enqueue(action);
        }

        public Action Schedule(float seconds, Action action)
        {
            Coroutine coroutine = StartCoroutine(Run(seconds, action));
            return () =>
            {
                if (this != null) StopCoroutine(coroutine);
            };
        }

        public void LogWarning(string message) => Debug.LogWarning("[AdManager] " + message);

        public void LogException(Exception exception) => Debug.LogException(exception);

        private static IEnumerator Run(float seconds, Action action)
        {
            yield return new WaitForSecondsRealtime(seconds);
            action();
        }
    }
}
