namespace PlatformLibrary.Ads
{
    /// <summary>Paid-impression data for analytics. Never a reason to grant anything.</summary>
    public sealed class AdRevenue
    {
        public AdRevenue(
            string adPlatform,
            string adSource,
            string adUnitId,
            string adFormat,
            double revenue,
            string currencyCode,
            string placement = "")
        {
            AdPlatform = adPlatform ?? string.Empty;
            AdSource = adSource ?? string.Empty;
            AdUnitId = adUnitId ?? string.Empty;
            AdFormat = adFormat ?? string.Empty;
            Revenue = revenue;
            CurrencyCode = currencyCode ?? string.Empty;
            Placement = placement ?? string.Empty;
        }

        public string AdPlatform { get; }
        public string AdSource { get; }
        public string AdUnitId { get; }
        public string AdFormat { get; }
        public double Revenue { get; }
        public string CurrencyCode { get; }
        public string Placement { get; }
    }
}
