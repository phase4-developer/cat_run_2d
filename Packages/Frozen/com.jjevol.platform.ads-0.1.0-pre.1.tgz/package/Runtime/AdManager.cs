using System;
using UnityEngine;

namespace PlatformLibrary.Ads
{
    /// <summary>
    /// The only ad API a game uses. Call it from the Unity main thread. Every callback runs once, on the main thread.
    /// With no provider set, ad calls answer <see cref="AdFailure.Unsupported"/> and the game keeps running.
    /// </summary>
    public static class AdManager
    {
        private static AdSession _session;
        private static bool _initializedWithoutProvider;

        /// <summary>A shown ad was paid. Analytics data only, never a reason to grant anything.</summary>
        public static event Action<AdRevenue> AdRevenuePaid;

        /// <summary>
        /// A reward ad that reached the SDK has ended, in any way, including its provider being replaced.
        /// Check <see cref="AdResult.RewardGranted"/> before reporting a watch to the game's server.
        /// </summary>
        public static event Action<AdResult> RewardCompleted;

        /// <summary>
        /// A reward ad call started or stopped covering the game, so the project can show its loading indicator.
        /// Connect it once in the start code. Every start is followed by an end, before the call's callback runs.
        /// </summary>
        public static event Action<AdLoadingKind, bool> LoadingChanged;

        public static bool IsInitialized => _session != null ? _session.IsInitialized : _initializedWithoutProvider;
        public static bool IsRewardAdReady => _session != null && _session.IsRewardAdReady;
        public static bool IsRewardAdLoading => _session != null && _session.IsRewardAdLoading;

        /// <summary>
        /// Sets the provider, or removes it with null. A replaced provider's pending calls end with <see cref="AdFailure.ProviderError"/>.
        /// An ad on screen keeps what the SDK reported so far, so a reward earned before the change is still granted.
        /// </summary>
        public static void SetProvider(IAdProvider provider)
        {
            SetProvider(provider, provider == null ? null : UnityAdHost.Instance, AdSession.DefaultLoadTimeoutSeconds);
        }

        public static void Initialize()
        {
            if (_session != null) _session.Initialize();
            else _initializedWithoutProvider = true;
        }

        public static void LoadRewardAd(Action<AdResult> callback = null) => LoadRewardAd(default, callback);

        public static void LoadRewardAd(AdRequest request, Action<AdResult> callback = null)
        {
            if (_session != null) _session.LoadRewardAd(request, callback);
            else ReplyUnsupported(request, callback);
        }

        public static void ShowRewardAd(Action<AdResult> callback) => ShowRewardAd(default, callback);

        public static void ShowRewardAd(AdRequest request, Action<AdResult> callback)
        {
            if (_session != null) _session.ShowRewardAd(request, callback);
            else ReplyUnsupported(request, callback);
        }

        public static void LoadInterstitialAd(Action<AdResult> callback = null) => LoadInterstitialAd(default, callback);

        public static void LoadInterstitialAd(AdRequest request, Action<AdResult> callback = null)
        {
            if (_session != null) _session.LoadInterstitialAd(request, callback);
            else ReplyUnsupported(request, callback);
        }

        public static void ShowInterstitialAd(Action<AdResult> callback = null) => ShowInterstitialAd(default, callback);

        public static void ShowInterstitialAd(AdRequest request, Action<AdResult> callback = null)
        {
            if (_session != null) _session.ShowInterstitialAd(request, callback);
            else ReplyUnsupported(request, callback);
        }

        public static void ShowBanner(Action<AdResult> callback = null) => ShowBanner(default, callback);

        public static void ShowBanner(AdRequest request, Action<AdResult> callback = null)
        {
            if (_session != null) _session.ShowBanner(request, callback);
            else ReplyUnsupported(request, callback);
        }

        public static void HideBanner() => _session?.HideBanner();

        internal static void SetProvider(IAdProvider provider, IAdHost host, float loadTimeoutSeconds)
        {
            if (ReferenceEquals(_session?.Provider, provider)) return;
            AdSession previous = _session;
            _session = provider == null ? null : new AdSession(provider, host, RaiseAdRevenuePaid, RaiseRewardCompleted, RaiseLoadingChanged, loadTimeoutSeconds);
            _initializedWithoutProvider = false;
            previous?.Close();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        internal static void ResetState()
        {
            _session = null;
            _initializedWithoutProvider = false;
            AdRevenuePaid = null;
            RewardCompleted = null;
            LoadingChanged = null;
        }

        private static void ReplyUnsupported(AdRequest request, Action<AdResult> callback)
        {
            callback?.Invoke(AdResult.Failed(AdFailure.Unsupported, 0, "NO_AD_PROVIDER").For(request));
        }

        private static void RaiseAdRevenuePaid(AdRevenue revenue) => AdRevenuePaid?.Invoke(revenue);

        private static void RaiseRewardCompleted(AdResult result) => RewardCompleted?.Invoke(result);

        private static void RaiseLoadingChanged(AdLoadingKind kind, bool active) => LoadingChanged?.Invoke(kind, active);
    }
}
