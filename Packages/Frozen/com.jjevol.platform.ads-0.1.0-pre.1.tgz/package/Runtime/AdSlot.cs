using System;
using System.Collections.Generic;

namespace PlatformLibrary.Ads
{
    /// <summary>Load, timeout, show and reload rules of one full-screen ad format.</summary>
    internal abstract class AdSlot
    {
        internal const string ProviderReplaced = "PROVIDER_REPLACED";

        // An SDK can report the reward just after the close, so the result waits this long.
        private const float ShowEndDelaySeconds = 0.03f;

        private readonly struct Waiter
        {
            public Waiter(AdRequest request, Action<AdResult> callback)
            {
                Request = request;
                Callback = callback;
            }

            public AdRequest Request { get; }
            public Action<AdResult> Callback { get; }
        }

        private readonly AdSession _session;
        private readonly List<Waiter> _waiters = new List<Waiter>();

        private bool _loading;
        private bool _hasLoadedAd;
        private bool _showWaitingForLoad;
        private int _loadVersion;
        private AdRequest _loadingRequest;
        private AdRequest _loadedRequest;
        private Action _cancelTimeout;
        private ShowRun _run;

        protected AdSlot(AdSession session)
        {
            _session = session;
        }

        public bool IsLoading => _loading;
        public bool IsShowing => _run != null;

        protected IAdProvider Provider => _session.Provider;
        protected abstract string Name { get; }
        protected abstract bool IsSupported { get; }
        protected abstract string DefaultAdUnitId { get; }
        protected abstract bool IsProviderReady { get; }
        protected abstract bool GrantsReward { get; }
        protected abstract bool ShowWaitsForLoad { get; }
        protected abstract bool ReportsLoading { get; }
        protected abstract void LoadFromProvider(AdRequest request, Action<AdResult> completed);
        protected abstract void ShowFromProvider(AdRequest request, IAdShowListener listener);
        protected abstract void DiscardFromProvider();

        protected virtual void OnShowEnded(AdResult result)
        {
        }

        protected void Invoke(Action<AdResult> callback, AdResult result) => _session.Invoke(callback, result);

        public void Load(AdRequest request, Action<AdResult> callback)
        {
            request = Normalize(request);

            AdFailure failure = _session.Check(request, IsSupported);
            if (failure != AdFailure.None)
            {
                Reply(callback, AdResult.Failed(failure), request);
                return;
            }

            if (IsShowing)
            {
                Reply(callback, AdResult.Failed(AdFailure.Busy, 0, "ALREADY_SHOWING"), request);
                return;
            }

            if (IsLoaded(request))
            {
                Reply(callback, AdResult.Succeeded(), request);
                return;
            }

            if (_loading)
            {
                if (IsSameAd(_loadingRequest, request)) _waiters.Add(new Waiter(request, callback));
                else Reply(callback, AdResult.Failed(AdFailure.Busy, 0, "ALREADY_LOADING_DIFFERENT_REQUEST"), request);
                return;
            }

            _waiters.Add(new Waiter(request, callback));
            Discard();

            _loading = true;
            _loadingRequest = request;
            int version = ++_loadVersion;
            _cancelTimeout = _session.Host.Schedule(_session.LoadTimeoutSeconds, () => OnLoadTimeout(version));
            try
            {
                LoadFromProvider(request, result => _session.Host.Post(() => OnLoaded(version, result)));
            }
            catch (Exception exception)
            {
                _session.Host.LogException(exception);
                OnLoaded(version, AdResult.Failed(AdFailure.ProviderError, 0, exception.Message));
            }
        }

        public void Show(AdRequest request, Action<AdResult> callback)
        {
            request = Normalize(request);

            AdFailure failure = _session.Check(request, IsSupported);
            if (failure == AdFailure.NotInitialized) _session.Initialize();
            if (failure != AdFailure.None)
            {
                Reply(callback, AdResult.Failed(failure), request);
                return;
            }

            if (_session.IsShowing)
            {
                Reply(callback, AdResult.Failed(AdFailure.Busy, 0, "ALREADY_SHOWING"), request);
                return;
            }

            if (IsLoaded(request))
            {
                ShowLoaded(request, callback);
                return;
            }

            if (!ShowWaitsForLoad)
            {
                Load(request, null);
                Reply(callback, AdResult.Failed(AdFailure.NoFill, 0, "AD_NOT_READY"), request);
                return;
            }

            if (_showWaitingForLoad)
            {
                Reply(callback, AdResult.Failed(AdFailure.Busy, 0, "ALREADY_REQUESTING"), request);
                return;
            }

            _showWaitingForLoad = true;
            SetLoading(AdLoadingKind.Loading, true);
            Load(request, result =>
            {
                _showWaitingForLoad = false;
                SetLoading(AdLoadingKind.Loading, false);
                if (result.Success) ShowLoaded(request, callback);
                else _session.Invoke(callback, result);
            });
        }

        public void Close()
        {
            _loadVersion++;
            CancelTimeout();
            _loading = false;

            AdResult replaced = AdResult.Failed(AdFailure.ProviderError, 0, ProviderReplaced);
            if (_run != null) ReportShowEnd(_run, _run.Abandon(replaced));
            else Discard();

            ReplyToWaiters(replaced);
        }

        private AdRequest Normalize(AdRequest request)
        {
            return string.IsNullOrEmpty(request.AdUnitId) ? request.WithAdUnitId(_session.ReadAdUnit(() => DefaultAdUnitId)) : request;
        }

        private bool IsLoaded(AdRequest request)
        {
            return _hasLoadedAd && IsProviderReady && IsSameAd(_loadedRequest, request);
        }

        private bool IsSameAd(AdRequest left, AdRequest right)
        {
            if (!string.Equals(left.AdUnitId, right.AdUnitId, StringComparison.Ordinal)) return false;
            if (!Provider.BindsServerVerificationAtLoad) return true;

            return string.Equals(left.UserId, right.UserId, StringComparison.Ordinal) &&
                   string.Equals(left.CustomData, right.CustomData, StringComparison.Ordinal) &&
                   left.UseServerSideVerification == right.UseServerSideVerification;
        }

        private void OnLoaded(int version, AdResult result)
        {
            if (version != _loadVersion || !_loading) return;

            CancelTimeout();
            EndLoad(result);
        }

        private void OnLoadTimeout(int version)
        {
            if (version != _loadVersion || !_loading) return;

            _cancelTimeout = null;
            EndLoad(AdResult.Failed(AdFailure.Timeout, 0, "LOAD_TIMEOUT"));
        }

        private void EndLoad(AdResult result)
        {
            _loading = false;
            _loadVersion++;

            if (result.Success)
            {
                _loadedRequest = _loadingRequest;
                _hasLoadedAd = true;
            }
            else
            {
                _session.Host.LogWarning($"{Name} load failed: {result.Failure} {result.ProviderCode} {result.Detail}");
                Discard();
            }

            ReplyToWaiters(result);
        }

        private void ShowLoaded(AdRequest request, Action<AdResult> callback)
        {
            if (_session.IsShowing)
            {
                Reply(callback, AdResult.Failed(AdFailure.Busy, 0, "ALREADY_SHOWING"), request);
                return;
            }

            if (!IsProviderReady)
            {
                Reply(callback, AdResult.Failed(AdFailure.ShowFailed, 0, "AD_NOT_READY"), request);
                return;
            }

            var run = new ShowRun(this, request, callback);
            _run = run;
            SetLoading(AdLoadingKind.Showing, true);
            try
            {
                ShowFromProvider(request, run);
            }
            catch (Exception exception)
            {
                _session.Host.LogException(exception);
                run.Failed(AdFailure.ShowFailed, 0, exception.Message);
            }
        }

        private void EndShow(ShowRun run, AdResult result)
        {
            ReportShowEnd(run, result);

            if (!_session.IsClosed && !_loading && !_session.IsShowing && !_showWaitingForLoad)
                Load(default, null);
        }

        private void ReportShowEnd(ShowRun run, AdResult result)
        {
            _run = null;
            Discard();
            SetLoading(AdLoadingKind.Showing, false);

            if (!result.Success)
                _session.Host.LogWarning($"{Name} show failed: {result.Failure} {result.ProviderCode} {result.Detail}");

            result = result.For(run.Request);
            _session.Invoke(run.Callback, result);
            OnShowEnded(result);
        }

        private void Discard()
        {
            _hasLoadedAd = false;
            try
            {
                DiscardFromProvider();
            }
            catch (Exception exception)
            {
                _session.Host.LogException(exception);
            }
        }

        private void SetLoading(AdLoadingKind kind, bool active)
        {
            if (ReportsLoading) _session.RaiseLoadingChanged(kind, active);
        }

        private void CancelTimeout()
        {
            _cancelTimeout?.Invoke();
            _cancelTimeout = null;
        }

        private void Reply(Action<AdResult> callback, AdResult result, AdRequest request)
        {
            _session.Invoke(callback, result.For(request));
        }

        private void ReplyToWaiters(AdResult result)
        {
            Waiter[] waiters = _waiters.ToArray();
            _waiters.Clear();
            foreach (Waiter waiter in waiters)
                Reply(waiter.Callback, result, waiter.Request);
        }

        private sealed class ShowRun : IAdShowListener
        {
            private readonly AdSlot _slot;
            private readonly IAdHost _host;
            private bool _ended;
            private bool _rewardEarned;
            private string _rewardType;
            private double _rewardAmount;
            private AdResult? _failure;
            private Action _cancelDelay;

            public ShowRun(AdSlot slot, AdRequest request, Action<AdResult> callback)
            {
                _slot = slot;
                _host = slot._session.Host;
                Request = request;
                Callback = callback;
            }

            public AdRequest Request { get; }
            public Action<AdResult> Callback { get; }

            public void RewardEarned(string rewardType, double rewardAmount)
            {
                _host.Post(() =>
                {
                    _rewardEarned = true;
                    _rewardType = rewardType;
                    _rewardAmount = rewardAmount;
                });
            }

            public void Closed() => _host.Post(() => End(null));

            public void Failed(AdFailure failure, int providerCode, string detail)
            {
                _host.Post(() => End(AdResult.Failed(failure, providerCode, detail)));
            }

            /// <summary>Stops the run now. What the SDK already reported stands, so a reward it earned is not lost.</summary>
            public AdResult Abandon(AdResult unfinished)
            {
                bool hasOutcome = _ended || _rewardEarned;
                _ended = true;
                _cancelDelay?.Invoke();
                return hasOutcome ? Result : unfinished;
            }

            private void End(AdResult? failure)
            {
                if (_ended) return;

                _ended = true;
                _failure = failure;
                _cancelDelay = _host.Schedule(ShowEndDelaySeconds, Finish);
            }

            private AdResult Result => _failure ?? AdResult.Closed(_rewardEarned, _rewardType, _rewardAmount, _slot.GrantsReward);

            private void Finish() => _slot.EndShow(this, Result);
        }
    }

    internal sealed class RewardAdSlot : AdSlot
    {
        private readonly Action<AdResult> _completed;

        public RewardAdSlot(AdSession session, Action<AdResult> completed) : base(session)
        {
            _completed = completed;
        }

        protected override string Name => "Reward ad";
        protected override bool IsSupported => true;
        protected override string DefaultAdUnitId => Provider.RewardAdUnitId;
        protected override bool IsProviderReady => Provider.IsRewardAdReady;
        protected override bool GrantsReward => true;
        protected override bool ShowWaitsForLoad => true;
        protected override bool ReportsLoading => true;

        protected override void LoadFromProvider(AdRequest request, Action<AdResult> completed) => Provider.LoadRewardAd(request, completed);
        protected override void ShowFromProvider(AdRequest request, IAdShowListener listener) => Provider.ShowRewardAd(request, listener);
        protected override void DiscardFromProvider() => Provider.DiscardRewardAd();

        protected override void OnShowEnded(AdResult result) => Invoke(_completed, result);
    }

    internal sealed class InterstitialAdSlot : AdSlot
    {
        public InterstitialAdSlot(AdSession session) : base(session)
        {
        }

        protected override string Name => "Interstitial ad";
        protected override bool IsSupported => Provider.SupportsInterstitialAd;
        protected override string DefaultAdUnitId => Provider.InterstitialAdUnitId;
        protected override bool IsProviderReady => Provider.IsInterstitialAdReady;
        protected override bool GrantsReward => false;

        // A wait here would interrupt play with a late ad, so a missing interstitial fails now and loads for next time.
        protected override bool ShowWaitsForLoad => false;
        protected override bool ReportsLoading => false;

        protected override void LoadFromProvider(AdRequest request, Action<AdResult> completed) => Provider.LoadInterstitialAd(request, completed);
        protected override void ShowFromProvider(AdRequest request, IAdShowListener listener) => Provider.ShowInterstitialAd(request, listener);
        protected override void DiscardFromProvider() => Provider.DiscardInterstitialAd();
    }
}
