namespace PlatformLibrary.Ads
{
    /// <summary>
    /// Result of an ad call. <see cref="Success"/> means the call worked, not that a reward was earned:
    /// a reward ad closed early is a success with <see cref="RewardGranted"/> false and
    /// <see cref="IsSkipped"/> true. <see cref="RewardGranted"/> is what the ad SDK told this client.
    /// It is not proof of a completed ad.
    /// </summary>
    public readonly struct AdResult
    {
        private readonly string _detail;
        private readonly string _adUnitId;
        private readonly string _placement;
        private readonly string _userId;
        private readonly string _customData;
        private readonly string _requestId;
        private readonly string _rewardType;

        private AdResult(AdFailure failure, int providerCode, string detail, AdRequest request,
            bool rewardGranted, string rewardType, double rewardAmount, bool isSkipped)
        {
            Failure = failure;
            ProviderCode = providerCode;
            _detail = detail;
            _adUnitId = request.AdUnitId;
            _placement = request.Placement;
            _userId = request.UserId;
            _customData = request.CustomData;
            _requestId = request.RequestId;
            ServerVerificationRequested = request.HasServerSideVerificationData;
            RewardGranted = rewardGranted;
            _rewardType = rewardType;
            RewardAmount = rewardAmount;
            IsSkipped = isSkipped;
        }

        public AdFailure Failure { get; }
        public bool Success => Failure == AdFailure.None;
        public bool RewardGranted { get; }

        /// <summary>The SDK's own code, for logs and investigation. Do not branch on it.</summary>
        public int ProviderCode { get; }

        /// <summary>Log text. Do not show it to players or branch on it.</summary>
        public string Detail => _detail ?? string.Empty;

        public string AdUnitId => _adUnitId ?? string.Empty;
        public string Placement => _placement ?? string.Empty;
        public string UserId => _userId ?? string.Empty;
        public string CustomData => _customData ?? string.Empty;
        public string RequestId => _requestId ?? string.Empty;
        public string RewardType => _rewardType ?? string.Empty;
        public double RewardAmount { get; }
        public bool ServerVerificationRequested { get; }

        /// <summary>Always false. Only the game's server can verify a reward, so nothing in the client sets this.</summary>
        public bool ServerVerified => false;

        public bool IsSkipped { get; }

        /// <summary>For providers: the call worked.</summary>
        public static AdResult Succeeded()
        {
            return new AdResult(AdFailure.None, 0, null, default, false, null, 0d, false);
        }

        /// <summary>For providers: the call failed. <see cref="AdFailure.None"/> becomes <see cref="AdFailure.ProviderError"/>.</summary>
        public static AdResult Failed(AdFailure failure, int providerCode = 0, string detail = "")
        {
            if (failure == AdFailure.None) failure = AdFailure.ProviderError;
            return new AdResult(failure, providerCode, detail, default, false, null, 0d, false);
        }

        internal static AdResult Closed(bool rewardGranted, string rewardType, double rewardAmount, bool isRewardAd)
        {
            return new AdResult(AdFailure.None, 0, null, default, rewardGranted, rewardType, rewardAmount, isRewardAd && !rewardGranted);
        }

        internal AdResult For(AdRequest request)
        {
            return new AdResult(Failure, ProviderCode, _detail, request, RewardGranted, _rewardType, RewardAmount, IsSkipped);
        }
    }
}
