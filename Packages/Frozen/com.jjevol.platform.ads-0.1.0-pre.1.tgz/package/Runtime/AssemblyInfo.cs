using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.Ads.Tests.Editor")]
[assembly: InternalsVisibleTo("PlatformLibrary.Ads.Tests.Runtime")]
