namespace PlatformLibrary.Ads
{
    /// <summary>
    /// One ad request. An empty ad unit uses the provider's configured unit.
    /// <c>default</c> is a valid request with no placement.
    /// </summary>
    public readonly struct AdRequest
    {
        private readonly string _placement;
        private readonly string _adUnitId;
        private readonly string _userId;
        private readonly string _customData;
        private readonly string _requestId;

        public AdRequest(
            string placement = "",
            string adUnitId = "",
            string userId = "",
            string customData = "",
            string requestId = "",
            bool useServerSideVerification = false)
        {
            _placement = placement;
            _adUnitId = adUnitId;
            _userId = userId;
            _customData = customData;
            _requestId = requestId;
            UseServerSideVerification = useServerSideVerification;
        }

        public string Placement => _placement ?? string.Empty;
        public string AdUnitId => _adUnitId ?? string.Empty;
        public string UserId => _userId ?? string.Empty;
        public string CustomData => _customData ?? string.Empty;
        public string RequestId => _requestId ?? string.Empty;
        public bool UseServerSideVerification { get; }

        public bool HasServerSideVerificationData =>
            UseServerSideVerification ||
            !string.IsNullOrEmpty(_userId) ||
            !string.IsNullOrEmpty(_customData);

        internal AdRequest WithAdUnitId(string adUnitId)
        {
            return new AdRequest(_placement, adUnitId, _userId, _customData, _requestId, UseServerSideVerification);
        }
    }
}
