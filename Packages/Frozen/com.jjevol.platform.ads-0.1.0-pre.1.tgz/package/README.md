# JJEvol Platform Ads

Local validation candidate 0.1.0-pre.1. The ad manager, the provider contract and the result types. Games call `AdManager` and never see an SDK.

The code is user-authored, confirmed by the user on 2026-11-08. This package has no SDK, App ID, ad unit or game policy in it.

## Use

The project's start code decides what runs. This is the only place that names a provider:

```csharp
AdManager.SetProvider(new AdMobAdProvider(adMobSettings));
AdManager.Initialize();
```

Game code knows only the manager:

```csharp
if (AdManager.IsRewardAdReady) { /* show the button */ }

AdManager.ShowRewardAd(new AdRequest("revive"), result =>
{
    if (result.RewardGranted) Revive();
    else if (result.Failure == AdFailure.NoFill) ShowNoAdPopup();
});
```

Call `AdManager` from the Unity main thread. Every callback runs once, on the main thread. A callback that throws is logged and does not stop the manager.

## No provider

Nothing is required. With no provider, every ad call answers `AdFailure.Unsupported` at once, `Initialize` completes, and `IsRewardAdReady` and `IsRewardAdLoading` stay false. A platform with no ads needs no special code.

Choosing a provider belongs to the project: this package has no default provider, no selection define and no store branch. `SetProvider(null)` removes a provider. Replacing one ends its pending calls with `AdFailure.ProviderError`, and the new one starts uninitialized. An ad on screen keeps what the SDK reported so far: a reward earned before the change is granted, while one the SDK reports after it cannot be received.

## Calls

| Call | Behavior |
|---|---|
| `Initialize()` | Starts the SDK and asks for consent, then loads a reward ad. Failure leaves it uninitialized and it can be called again. |
| `LoadRewardAd(request, callback)` | Same ad as one loaded or loading: joins it. A different ad while loading: `Busy`. |
| `ShowRewardAd(request, callback)` | Shows a loaded ad, or waits for the load. Before initialization it starts `Initialize` and answers `NotInitialized`. The next ad loads after the show ends. |
| `LoadInterstitialAd(request, callback)` | Same as reward. Nothing loads until the game asks. |
| `ShowInterstitialAd(request, callback)` | With no ad, answers `NoFill` at once and loads for next time, so a late ad never interrupts play. |
| `ShowBanner(request, callback)` | Answers once for the first load. A new banner replaces the old one and ends its pending call with `Busy`. |
| `HideBanner()` | Removes the banner and ends a pending call with `Busy`. |

Each call also has a form with no request. An empty `AdRequest.AdUnitId` uses the provider's configured unit. Only one full-screen ad shows at a time, and a second answers `Busy`. A load that takes 15 seconds answers `Timeout`, and a late SDK answer is ignored.

`RewardCompleted` fires once for every reward ad that reached the SDK, however it ended, including its provider being replaced. `AdRevenuePaid` fires for each paid impression. Both run on the main thread. While an ad covers the game, an SDK may pause Unity, so revenue can arrive when the game resumes.

`LoadingChanged` tells the project when to show its loading indicator during `ShowRewardAd`. Connect it once in the start code:

```csharp
AdManager.LoadingChanged += (kind, active) =>
{
    if (active) LoadingIndicator.Show(kind.ToString());
    else LoadingIndicator.Hide(kind.ToString());
};
```

| `AdLoadingKind` | Active |
|---|---|
| `Loading` | From a `ShowRewardAd` that has no ad, until its load ends. |
| `Showing` | From the moment the ad goes to the SDK, until just before the callback. |

Every start has an end, before the call's callback runs. Rejected calls, background loads and interstitial ads report nothing.

## Results

`AdResult.Failure` is the only value a game branches on. `ProviderCode` and `Detail` are for logs.

| `Failure` | Meaning |
|---|---|
| `None` | The call worked. |
| `NotInitialized` | `Initialize` has not finished. |
| `ConsentRequired` | The player's consent does not allow ads. |
| `InvalidAdUnit` | No ad unit, or the SDK rejected it. |
| `Network` | No network, or the SDK reported a network error. |
| `NoFill` | No ad available. |
| `Timeout` | The load took too long. |
| `Busy` | Another ad is showing, or a different load is running. |
| `ShowFailed` | The ad could not be shown. |
| `Unsupported` | No provider, or the provider has no such format. |
| `ProviderError` | Any other SDK error. The provider was also replaced with this. |

`Success` is not the same as a reward. A reward ad closed early has `Success` true, `RewardGranted` false and `IsSkipped` true.

## Trust boundary

The trust boundary in the `com.jjevol.platform.core` README applies here. A callback is not proof of a completed ad.

| Client value | What it means | What grants the value |
|---|---|---|
| `AdResult.RewardGranted` | The ad SDK told this client a reward was earned. | A server receives the ad network's server-side verification callback for `RequestId`, then grants. |
| `AdResult.ServerVerified` | Always false. Only a server can verify. | The game's server, as above. |
| `AdRevenue` | Analytics data only. | Never a reason to grant anything. |

Reporting a watch to a server belongs to the project. It listens to `RewardCompleted` and checks `RewardGranted`:

```csharp
AdManager.RewardCompleted += result =>
{
    if (result.RewardGranted) ReportAdWatch(result);
};
```

For server verification, pass `userId`, `customData`, `requestId` and `useServerSideVerification` in `AdRequest`. They return unchanged in `AdResult`.

## Writing a provider

Implement `IAdProvider`. The manager calls it on the main thread, and it may answer from any thread. The manager already handles duplicate requests, timeouts, network and consent checks, the delay for a reward that arrives after the close, reloads and result metadata. A provider only talks to its SDK and turns SDK codes into `AdFailure`, keeping the SDK code in `AdResult.Failed`.

To wrap a provider, for example to add a test-ad policy, implement `IAdProvider` in the project and pass the wrapper to `SetProvider`.

## Validation

Tests are in `Tests/Editor` and `Tests/Runtime`, in isolated assemblies, and need no SDK and no provider package. Run them from `Hosts/PlatformAdsValidationHost`. `Tests/Editor` drives time and threads by hand. `Tests/Runtime` uses the real Unity host for threads, real-time timeouts and scene survival. See `Docs/PlatformAdsAnalytics/AdsReport.md` for what has run.
