# Changelog

## 0.1.0-pre.1 - 2026-11-08

New design, per `Docs/PlatformAdsAnalytics/Design.md`. It replaces the mobile library's `ADController`, `IADManager` and `UnsupportedADManager`. Class names and GUIDs are not kept, so a game moving over needs code changes.

- `AdManager` is the static entry point. Games need no SDK and no provider.
- Duplicate requests, load timeouts, network and consent checks and reloads moved from each provider into the manager, for reward and interstitial ads alike.
- `AdFailure` replaces numeric error codes. The SDK code stays in `AdResult.ProviderCode` for logs.
- Interstitial ads and banners are common calls. A provider without them answers `AdFailure.Unsupported`.
- `AdManager.LoadingChanged` with `AdLoadingKind` replaces `AdProviderConfiguration.LoadingChanged` and its string keys. Both providers now report the wait for a load, which only ADX did.
- A provider or ad unit function that throws no longer stops a call. It is logged and the call still answers.
- A provider change keeps a reward already earned and fires `RewardCompleted`.

Unity tests passed in `Hosts/PlatformAdsValidationHost`: compile, EditMode and PlayMode. See `Docs/PlatformAdsAnalytics/AdsReport.md`.
