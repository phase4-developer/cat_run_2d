using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.TestTools;

namespace PlatformLibrary.Network.Tests
{
    public sealed class NetworkManagerTests
    {
        private SynchronizationContext _context;
        private FakeProvider _server;
        private FakeLocal _local;

        [SetUp]
        public void SetUp()
        {
            // Completed tasks continue inline so each test runs synchronously.
            _context = SynchronizationContext.Current;
            SynchronizationContext.SetSynchronizationContext(null);
            NetworkManager.ClearAll();
            NetworkManager.DelayAsync = (delay, token) => Task.CompletedTask;
            _server = new FakeProvider();
            _local = new FakeLocal();
            NetworkManager.SetServerProvider(_server);
            NetworkManager.SetLocalService(_local);
        }

        [TearDown]
        public void TearDown()
        {
            NetworkManager.ClearAll();
            SynchronizationContext.SetSynchronizationContext(_context);
        }

        private static NetworkResult Send(NetworkRequest request, bool queued = false)
        {
            NetworkResult? received = null;
            int calls = 0;
            Action<NetworkResult> callback = result => { received = result; calls++; };
            if (queued) NetworkManager.PostQueue(request, callback); else NetworkManager.Post(request, callback);
            Assert.AreEqual(1, calls, "The callback runs once.");
            return received.Value;
        }

        [Test]
        public void MissingProviderIsUnsupported()
        {
            NetworkManager.SetServerProvider(null);
            NetworkManager.SetServerProvider(NetworkTarget.Default, null);
            // A local service is set, so the first miss tells the project to switch the route. Only once.
            LogAssert.Expect(LogType.Warning, new Regex("no server provider for target .* while a local service is set"));
            NetworkResult result = Send(new TestRequest());
            Assert.AreEqual(NetworkFailure.Unsupported, result.Failure);
            Assert.AreEqual(NetworkFailure.Unsupported, Send(new TestRequest(target: "control")).Failure);
            LogAssert.NoUnexpectedReceived();

            NetworkManager.SetLocalService(null);
            NetworkManager.ClearAll();
            Assert.AreEqual(NetworkFailure.Unsupported, Send(new TestRequest()).Failure, "Without a local service there is nothing to warn about.");
            LogAssert.NoUnexpectedReceived();
        }

        [Test]
        public void RouteNoneFollowsTheGlobalRouteAndRequestRouteWins()
        {
            NetworkResult server = Send(new TestRequest());
            Assert.IsTrue(server.Success);
            Assert.AreEqual(NetworkRoute.Server, server.Route);
            Assert.AreEqual(1, _server.Calls.Count);

            NetworkManager.DefaultRoute = NetworkRoute.Local;
            NetworkResult local = Send(new TestRequest("claimMail"));
            Assert.AreEqual(NetworkRoute.Local, local.Route);
            Assert.AreEqual("claimMail", local.Data["local"].Value<string>());

            NetworkResult forced = Send(new TestRequest { Route = NetworkRoute.Server });
            Assert.AreEqual(NetworkRoute.Server, forced.Route);
            Assert.AreEqual(2, _server.Calls.Count);
            Assert.AreEqual(1, _local.Calls);
        }

        [Test]
        public void TargetsSelectProviders()
        {
            var control = new FakeProvider();
            NetworkManager.SetServerProvider("control", control);
            Assert.IsTrue(Send(new TestRequest("versionCheck", target: "control")).Success);
            Assert.AreEqual(1, control.Calls.Count);
            Assert.AreEqual(0, _server.Calls.Count);
        }

        [Test]
        public void LocalRejectionAndErrorsMapToFailures()
        {
            var request = new TestRequest { Route = NetworkRoute.Local };
            _local.Handle = _ => throw new NetworkRejection("NOT_ENOUGH_GOLD", "gold");
            NetworkResult rejected = Send(request);
            Assert.AreEqual(NetworkFailure.Rejected, rejected.Failure);
            Assert.AreEqual("NOT_ENOUGH_GOLD", rejected.ServerErrorCode);

            _local.Handle = _ => throw new InvalidOperationException("boom");
            Assert.AreEqual(NetworkFailure.ProviderError, Send(new TestRequest { Route = NetworkRoute.Local }).Failure);

            _local.Handles = _ => false;
            Assert.AreEqual(NetworkFailure.Unsupported, Send(new TestRequest { Route = NetworkRoute.Local }).Failure);
        }

        [Test]
        public void ParametersMergeDefaultsUnderRequestValues()
        {
            var request = new TestRequest();
            request.Defaults["version"] = "1.0";
            request.Defaults["lang"] = "en";
            request.Add("lang", "ko").Add("mailId", "m1");
            Send(request);
            Dictionary<string, object> sent = _server.Calls[0].Parameters;
            Assert.AreEqual("1.0", sent["version"]);
            Assert.AreEqual("ko", sent["lang"]);
            Assert.AreEqual("m1", sent["mailId"]);
        }

        [Test]
        public void ApplierRunsBeforeCallbackAndFailureEndsAsApplyFailed()
        {
            var order = new List<string>();
            Action<NetworkRequest, NetworkResult> record = (request, result) => order.Add("apply:" + string.Join(",", request.DataKeys));
            NetworkManager.AddResponseApplier(record);
            NetworkManager.Post(new TestRequest().WithKeys(false, "userMails"), _ => order.Add("callback"));
            CollectionAssert.AreEqual(new[] { "apply:userMails", "callback" }, order);

            Assert.IsTrue(NetworkManager.RemoveResponseApplier(record));
            NetworkManager.AddResponseApplier((request, result) => throw new InvalidOperationException("bad data"));
            LogAssert.Expect(LogType.Exception, new Regex("bad data"));
            NetworkResult failed = Send(new TestRequest { UseDefaultFailureHandling = false });
            Assert.AreEqual(NetworkFailure.ApplyFailed, failed.Failure);
            StringAssert.Contains("bad data", failed.Detail);
        }

        [Test]
        public void AppliersRunInOrderAndAThrowDoesNotSkipTheRest()
        {
            var order = new List<string>();
            Action<NetworkRequest, NetworkResult> first = (request, result) => order.Add("first");
            Action<NetworkRequest, NetworkResult> broken = (request, result) => { order.Add("broken"); throw new InvalidOperationException("broken applier"); };
            Action<NetworkRequest, NetworkResult> last = (request, result) => order.Add("last");
            NetworkManager.AddResponseApplier(first);
            NetworkManager.AddResponseApplier(broken);
            NetworkManager.AddResponseApplier(last);
            NetworkManager.AddResponseApplier(first);
            Assert.Throws<ArgumentNullException>(() => NetworkManager.AddResponseApplier(null));

            LogAssert.Expect(LogType.Exception, new Regex("broken applier"));
            NetworkResult failed = Send(new TestRequest { UseDefaultFailureHandling = false });
            CollectionAssert.AreEqual(new[] { "first", "broken", "last" }, order, "Registration order, no duplicate, the rest still run.");
            Assert.AreEqual(NetworkFailure.ApplyFailed, failed.Failure);
            StringAssert.Contains("broken applier", failed.Detail);

            Assert.IsTrue(NetworkManager.RemoveResponseApplier(broken));
            Assert.IsFalse(NetworkManager.RemoveResponseApplier(broken));
            Assert.IsFalse(NetworkManager.RemoveResponseApplier(null));
            order.Clear();
            Assert.IsTrue(Send(new TestRequest()).Success);
            CollectionAssert.AreEqual(new[] { "first", "last" }, order);
        }

        [Test]
        public void SessionInvalidInterruptsOnceAndBlocksSessionRequests()
        {
            NetworkManager.SetSession("s1");
            int interruptions = 0, restored = 0, handled = 0;
            NetworkManager.Interrupted += notice => { interruptions++; Assert.AreEqual(NetworkFailure.SessionInvalid, notice.Reason); };
            NetworkManager.AccessRestored += () => restored++;
            NetworkManager.SetDefaultFailureHandler(context => { handled++; context.Finish(); });
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.SessionInvalid, "SESSION_INVALID"));

            NetworkResult first = Send(new TestRequest(requiresSession: true));
            Assert.IsTrue(first.IsInterruption);
            Assert.IsTrue(NetworkManager.Session.IsSessionInvalid);
            NetworkResult blocked = Send(new TestRequest(requiresSession: true));
            Assert.AreEqual(NetworkFailure.SessionInvalid, blocked.Failure);
            Assert.AreEqual(1, _server.Calls.Count, "A blocked request is not sent.");
            Assert.AreEqual(1, interruptions);
            Assert.AreEqual(0, handled, "Interruptions skip the default failure handler.");

            NetworkManager.SetSession("s2");
            Assert.AreEqual(1, restored);
            Assert.IsTrue(Send(new TestRequest(requiresSession: true)).Success);
            Assert.AreEqual("s2", _server.Calls[1].SessionId);
        }

        [Test]
        public void SessionRequestWithoutSessionIsNotReady()
        {
            Assert.AreEqual(NetworkFailure.SessionNotReady, Send(new TestRequest(requiresSession: true) { UseDefaultFailureHandling = false }).Failure);
            Assert.AreEqual(0, _server.Calls.Count);
        }

        [Test]
        public void MaintenanceBlocksAndClearsBypass()
        {
            int interruptions = 0, restored = 0;
            NetworkManager.Interrupted += _ => interruptions++;
            NetworkManager.AccessRestored += () => restored++;
            NetworkManager.SetMaintenanceBypass(true);
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.Maintenance, "MAINTENANCE_MODE", "back soon"));

            Assert.AreEqual(NetworkFailure.Maintenance, Send(new TestRequest(blockedDuringMaintenance: true)).Failure);
            Assert.IsTrue(NetworkManager.Session.IsMaintenance);
            Assert.IsFalse(NetworkManager.Session.MaintenanceBypass);
            Assert.AreEqual("back soon", NetworkManager.Session.MaintenanceMessage);
            Assert.AreEqual(NetworkFailure.Maintenance, Send(new TestRequest(blockedDuringMaintenance: true)).Failure);
            Assert.IsTrue(Send(new TestRequest("versionCheck")).Success, "Requests not blocked during maintenance still go.");
            Assert.AreEqual(1, interruptions);

            NetworkManager.SetMaintenance(false);
            Assert.AreEqual(1, restored);
            Assert.IsTrue(Send(new TestRequest(blockedDuringMaintenance: true)).Success);
        }

        [Test]
        public void SwitchEnvironmentCancelsAndDropsLateResponses()
        {
            _server.Script.Enqueue(null);
            string changed = null;
            NetworkManager.EnvironmentChanged += key => changed = key;
            NetworkManager.SetSession("s1");
            var results = new List<NetworkResult>();
            NetworkManager.Post(new TestRequest(), results.Add);
            Assert.IsTrue(NetworkManager.IsWaitingForResponse);

            NetworkManager.SwitchEnvironment("stage");
            Assert.AreEqual(1, results.Count);
            Assert.AreEqual(NetworkFailure.Cancelled, results[0].Failure);
            Assert.AreEqual("stage", changed);
            Assert.IsFalse(NetworkManager.Session.HasSession);

            _server.Release(0, NetworkResult.Succeeded(new JObject()));
            Assert.AreEqual(1, results.Count, "A late response is dropped.");
            Send(new TestRequest());
            Assert.AreEqual("stage", _server.Calls[1].EnvironmentKey);
        }

        [Test]
        public void RequestsPostedFromCancelledCallbacksUseTheNewEnvironment()
        {
            NetworkManager.SetSession("s1");
            _server.Script.Enqueue(null);
            var followUps = new List<NetworkResult>();
            Action<NetworkResult> postFollowUp = result =>
            {
                Assert.AreEqual(NetworkFailure.Cancelled, result.Failure);
                NetworkManager.Post(new TestRequest("followUp"), followUps.Add);
            };
            NetworkManager.Post(new TestRequest("inFlight"), postFollowUp);
            NetworkManager.QueuePaused = true;
            NetworkManager.PostQueue(new TestRequest("queued"), postFollowUp);

            NetworkManager.SwitchEnvironment("stage");
            Assert.AreEqual(2, followUps.Count);
            Assert.IsTrue(followUps.TrueForAll(result => result.Success), "Follow-ups are not cancelled by the switch that started them.");
            Assert.AreEqual(3, _server.Calls.Count);
            for (int i = 1; i < _server.Calls.Count; i++)
            {
                Assert.AreEqual("followUp", _server.Calls[i].Request.Name);
                Assert.AreEqual("stage", _server.Calls[i].EnvironmentKey);
                Assert.IsNull(_server.Calls[i].SessionId);
            }
        }

        [Test]
        public void RequestsPostedFromCancelledCallbacksUseTheNewSession()
        {
            NetworkManager.SetSession("s1");
            _server.Script.Enqueue(null);
            var followUps = new List<NetworkResult>();
            NetworkManager.Post(new TestRequest("inFlight"), result =>
            {
                Assert.AreEqual(NetworkFailure.Cancelled, result.Failure);
                NetworkManager.Post(new TestRequest("followUp", requiresSession: true), followUps.Add);
            });

            NetworkManager.SetSession("s2");
            Assert.AreEqual(1, followUps.Count);
            Assert.IsTrue(followUps[0].Success);
            Assert.AreEqual("s2", _server.Calls[1].SessionId);
        }

        [Test]
        public void SessionChangesKeepQueuedRequests()
        {
            _server.Script.Enqueue(null);
            var loads = new List<NetworkResult>();
            NetworkManager.PostQueue(new TestRequest("startSession"), _ => NetworkManager.SetSession("s1"));
            NetworkManager.PostQueue(new TestRequest("loadUser", requiresSession: true), loads.Add);
            _server.Release(0, NetworkResult.Succeeded(new JObject()));
            Assert.AreEqual(1, loads.Count);
            Assert.IsTrue(loads[0].Success, "A request queued behind the session start is sent with the new session.");
            Assert.AreEqual("s1", _server.Calls[1].SessionId);

            NetworkManager.QueuePaused = true;
            var waiting = new List<NetworkResult>();
            NetworkManager.PostQueue(new TestRequest("waiting", requiresSession: true), waiting.Add);
            NetworkManager.ClearSession();
            NetworkManager.SetSession("s2");
            NetworkManager.ResetSession();
            NetworkManager.SetSession("s3");
            Assert.AreEqual(0, waiting.Count);
            Assert.AreEqual(1, NetworkManager.GetPendingCount("waiting"));
            NetworkManager.QueuePaused = false;
            Assert.IsTrue(waiting[0].Success);
            Assert.AreEqual("s3", _server.Calls[2].SessionId);
        }

        [Test]
        public void SessionChangesCancelSentRequests()
        {
            _server.Script.Enqueue(null);
            var results = new List<NetworkResult>();
            NetworkManager.Post(new TestRequest(), results.Add);
            NetworkManager.SetSession("s1");
            Assert.AreEqual(NetworkFailure.Cancelled, results[0].Failure);
            _server.Release(0, NetworkResult.Succeeded(new JObject()));
            Assert.AreEqual(1, results.Count, "A late response is dropped.");
        }

        [Test]
        public void ChangingTheGlobalRouteCancelsPendingRequests()
        {
            _server.Script.Enqueue(null);
            var results = new List<NetworkResult>();
            NetworkManager.Post(new TestRequest(), results.Add);
            NetworkManager.DefaultRoute = NetworkRoute.Local;
            Assert.AreEqual(NetworkFailure.Cancelled, results[0].Failure);
        }

        [Test]
        public void QueueSendsInOrder()
        {
            _server.Script.Enqueue(null);
            var order = new List<string>();
            NetworkManager.PostQueue(new TestRequest("first"), _ => order.Add("first"));
            NetworkManager.PostQueue(new TestRequest("second"), _ => order.Add("second"));
            Assert.AreEqual(1, _server.Calls.Count, "The second waits for the first.");
            Assert.AreEqual(2, NetworkManager.GetPendingCount("first") + NetworkManager.GetPendingCount("second"));

            _server.Release(0, NetworkResult.Succeeded(new JObject()));
            CollectionAssert.AreEqual(new[] { "first", "second" }, order);
            Assert.AreEqual(2, _server.Calls.Count);
        }

        [Test]
        public void PausedQueueWaits()
        {
            NetworkManager.QueuePaused = true;
            var results = new List<NetworkResult>();
            NetworkManager.PostQueue(new TestRequest(), results.Add);
            Assert.AreEqual(0, _server.Calls.Count);
            NetworkManager.QueuePaused = false;
            Assert.AreEqual(1, results.Count);
        }

        [Test]
        public void RetryPolicyRetriesOnlyRetryableFailures()
        {
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.NoConnection));
            var request = new TestRequest { Retry = new NetworkRetryPolicy(2, TimeSpan.FromMilliseconds(1)) };
            Assert.IsTrue(Send(request).Success);
            Assert.AreEqual(2, _server.Calls.Count);
            Assert.AreEqual(2, _server.Calls[1].Attempt);

            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.Rejected, "NO"));
            Assert.AreEqual(NetworkFailure.Rejected, Send(new TestRequest { Retry = new NetworkRetryPolicy(2, TimeSpan.Zero), UseDefaultFailureHandling = false }).Failure);
            Assert.AreEqual(3, _server.Calls.Count);

            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.Timeout));
            Assert.AreEqual(NetworkFailure.Timeout, Send(new TestRequest { UseDefaultFailureHandling = false }).Failure, "No policy means no retry.");
            Assert.AreEqual(4, _server.Calls.Count);
        }

        [Test]
        public void FailureHandlerDecidesBetweenRetryAndFinish()
        {
            NetworkFailureContext pending = null;
            NetworkManager.SetDefaultFailureHandler(context => pending = context);
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.ServerError));
            var results = new List<NetworkResult>();
            NetworkManager.Post(new TestRequest(), results.Add);
            Assert.IsNotNull(pending);
            Assert.AreEqual(0, results.Count, "The callback waits for the handler's decision.");

            pending.Retry();
            Assert.AreEqual(1, results.Count);
            Assert.IsTrue(results[0].Success);
            pending.Finish();
            Assert.AreEqual(1, results.Count, "A decision is taken once.");

            pending = null;
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.ServerError));
            NetworkManager.Post(new TestRequest(), results.Add);
            pending.Finish();
            Assert.AreEqual(NetworkFailure.ServerError, results[1].Failure);
        }

        [Test]
        public void CancelAllEndsUndecidedFailures()
        {
            NetworkManager.SetDefaultFailureHandler(_ => { });
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.ServerError));
            var results = new List<NetworkResult>();
            NetworkManager.Post(new TestRequest(), results.Add);
            NetworkManager.CancelAll();
            Assert.AreEqual(NetworkFailure.Cancelled, results[0].Failure);
        }

        [Test]
        public void LoadingFollowsPendingRequests()
        {
            var states = new List<bool>();
            NetworkManager.LoadingChanged += states.Add;
            _server.Script.Enqueue(null);
            NetworkManager.Post(new TestRequest());
            Assert.IsTrue(NetworkManager.IsLoading);
            NetworkManager.Post(new TestRequest { ShowLoading = false });
            _server.Release(0, NetworkResult.Succeeded(new JObject()));
            Assert.IsFalse(NetworkManager.IsLoading);
            CollectionAssert.AreEqual(new[] { true, false }, states);
        }

        [Test]
        public void ProviderThatNeverAnswersTimesOut()
        {
            _server.Script.Enqueue(null);
            Task<NetworkResult> task = NetworkManager.PostAsync(new TestRequest { Timeout = TimeSpan.FromMilliseconds(50), UseDefaultFailureHandling = false });
            Assert.IsTrue(task.Wait(5000));
            Assert.AreEqual(NetworkFailure.Timeout, task.Result.Failure);
        }

        [Test]
        public void ServerTimeoutAppliesToServerSendsOnly()
        {
            Assert.AreEqual(TimeSpan.FromSeconds(30), NetworkManager.ServerTimeout);
            Assert.IsNull(NetworkManager.LocalTimeout, "Local calls have no time limit by default.");
            NetworkManager.ServerTimeout = TimeSpan.FromMilliseconds(50);
            _server.Script.Enqueue(null);
            Task<NetworkResult> server = NetworkManager.PostAsync(new TestRequest { UseDefaultFailureHandling = false });
            Assert.IsTrue(server.Wait(5000));
            Assert.AreEqual(NetworkFailure.Timeout, server.Result.Failure);

            NetworkManager.DefaultRoute = NetworkRoute.Local;
            _local.Hold = new TaskCompletionSource<JObject>();
            Task<NetworkResult> local = NetworkManager.PostAsync(new TestRequest("slowLocal") { UseDefaultFailureHandling = false });
            Assert.IsFalse(local.Wait(300), "A slow local call (a breakpoint, say) is not ended by ServerTimeout.");
            _local.Hold.SetResult(new JObject { ["done"] = true });
            Assert.IsTrue(local.Wait(5000));
            Assert.IsTrue(local.Result.Success);
        }

        [Test]
        public void LocalTimeoutAndRequestTimeoutLimitLocalCalls()
        {
            NetworkManager.DefaultRoute = NetworkRoute.Local;
            NetworkManager.LocalTimeout = TimeSpan.FromMilliseconds(50);
            _local.Hold = new TaskCompletionSource<JObject>();
            Task<NetworkResult> limited = NetworkManager.PostAsync(new TestRequest { UseDefaultFailureHandling = false });
            Assert.IsTrue(limited.Wait(5000));
            Assert.AreEqual(NetworkFailure.Timeout, limited.Result.Failure);

            NetworkManager.LocalTimeout = null;
            Task<NetworkResult> own = NetworkManager.PostAsync(new TestRequest { Timeout = TimeSpan.FromMilliseconds(50), UseDefaultFailureHandling = false });
            Assert.IsTrue(own.Wait(5000));
            Assert.AreEqual(NetworkFailure.Timeout, own.Result.Failure, "The request's own Timeout wins on either route.");
        }

        [Test]
        public void LocalResponsesCarryTheTime()
        {
            long time = 0;
            NetworkManager.ServerTimeReceived += value => time = value;
            NetworkManager.ResponseFormat.LocalTime = () => 777L;
            NetworkManager.DefaultRoute = NetworkRoute.Local;
            NetworkResult result = Send(new TestRequest("claimMail"));
            Assert.IsTrue(result.Success);
            Assert.AreEqual(777L, result.Response["timeStamp"].Value<long>());
            Assert.AreEqual(777L, time, "ServerTimeReceived fires on the local route too.");
            Assert.AreEqual("claimMail", result.Data["local"].Value<string>());

            var whole = new NetworkResponseFormat { DataKey = null, LocalTime = () => 888L };
            NetworkManager.SetResponseFormat(whole);
            _local.Handle = call => new JObject { ["timeStamp"] = 5L, ["gold"] = 1 };
            NetworkResult own = Send(new TestRequest("ownTime"));
            Assert.AreEqual(5L, own.Response["timeStamp"].Value<long>(), "A time the local service set is kept.");

            whole.LocalTime = null;
            _local.Handle = call => new JObject { ["gold"] = 1 };
            Assert.IsFalse(Send(new TestRequest("noTime")).Response.ContainsKey("timeStamp"));
        }

        [Test]
        public void ServerTimeIsReported()
        {
            long time = 0;
            NetworkManager.ServerTimeReceived += value => time = value;
            var response = new JObject { ["timeStamp"] = 1234567L, ["data"] = new JObject() };
            _server.Script.Enqueue(NetworkManager.ResponseFormat.Interpret(response));
            Send(new TestRequest());
            Assert.AreEqual(1234567L, time);
        }

        [Test]
        public void RequestInstanceIsSentOnce()
        {
            var request = new TestRequest();
            Send(request);
            Assert.IsTrue(request.Completed);
            Assert.Throws<InvalidOperationException>(() => NetworkManager.Post(request));
        }

        [Test]
        public void InjectedFailuresApplyToBothRoutes()
        {
            NetworkTestFailures.Fail("claimMail", NetworkFailure.NoConnection, 2);
            Assert.AreEqual(NetworkFailure.NoConnection, Send(new TestRequest("claimMail") { UseDefaultFailureHandling = false }).Failure);
            Assert.AreEqual(NetworkFailure.NoConnection, Send(new TestRequest("claimMail") { Route = NetworkRoute.Local, UseDefaultFailureHandling = false }).Failure);
            Assert.IsTrue(Send(new TestRequest("claimMail")).Success);
            Assert.AreEqual(1, _server.Calls.Count);
        }

        [Test]
        public void ProviderNotReadyAndConnectivityCheck()
        {
            _server.Ready = false;
            Assert.AreEqual(NetworkFailure.NotInitialized, Send(new TestRequest { UseDefaultFailureHandling = false }).Failure);
            _server.Ready = true;
            NetworkManager.SetConnectivityCheck(() => false);
            Assert.AreEqual(NetworkFailure.NoConnection, Send(new TestRequest { UseDefaultFailureHandling = false }).Failure);
            Assert.AreEqual(0, _server.Calls.Count);
        }

        [Test]
        public void BatchCompletesAfterAllRequests()
        {
            NetworkBatch done = null;
            var batch = new NetworkBatch(new NetworkRequest[] { new TestRequest("a"), new TestRequest("b") }).PostQueue(b => done = b);
            Assert.AreSame(batch, done);
            Assert.IsTrue(batch.Success);
            Assert.IsNull(batch.FirstFailure);
        }

        [Test]
        public void PostAsyncHonoursCallerCancellation()
        {
            _server.Script.Enqueue(null);
            using (var cancel = new CancellationTokenSource())
            {
                Task<NetworkResult> task = NetworkManager.PostAsync(new TestRequest(), cancel.Token);
                cancel.Cancel();
                Assert.IsTrue(task.Wait(5000));
                Assert.AreEqual(NetworkFailure.Cancelled, task.Result.Failure);
            }
        }

        [Test]
        public void PostQueueAsyncHonoursCallerCancellationWhileWaiting()
        {
            NetworkManager.QueuePaused = true;
            using (var cancel = new CancellationTokenSource())
            {
                Task<NetworkResult> task = NetworkManager.PostQueueAsync(new TestRequest("paused"), cancel.Token);
                cancel.Cancel();
                Assert.IsTrue(task.IsCompleted, "A paused queue entry ends when its caller cancels.");
                Assert.AreEqual(NetworkFailure.Cancelled, task.Result.Failure);
                Assert.AreEqual(0, NetworkManager.GetPendingCount("paused"));
            }
            NetworkManager.QueuePaused = false;
            Assert.AreEqual(0, _server.Calls.Count);

            NetworkFailureContext undecided = null;
            NetworkManager.SetDefaultFailureHandler(context => undecided = context);
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.ServerError));
            var first = new List<NetworkResult>();
            NetworkManager.PostQueue(new TestRequest("first"), first.Add);
            Assert.IsNotNull(undecided);
            using (var cancel = new CancellationTokenSource())
            {
                Task<NetworkResult> behind = NetworkManager.PostQueueAsync(new TestRequest("behind"), cancel.Token);
                cancel.Cancel();
                Assert.IsTrue(behind.IsCompleted, "An entry behind an undecided request ends when its caller cancels.");
                Assert.AreEqual(NetworkFailure.Cancelled, behind.Result.Failure);
            }
            Assert.AreEqual(0, first.Count, "The undecided request still waits for its decision.");
            undecided.Finish();
            Assert.AreEqual(NetworkFailure.ServerError, first[0].Failure);
            Assert.AreEqual(1, _server.Calls.Count);
        }

        [Test]
        public void CallerCancellationEndsAnUndecidedRequest()
        {
            NetworkManager.SetDefaultFailureHandler(_ => { });
            _server.Script.Enqueue(NetworkResult.Failed(NetworkFailure.ServerError));
            using (var cancel = new CancellationTokenSource())
            {
                Task<NetworkResult> task = NetworkManager.PostQueueAsync(new TestRequest("undecided"), cancel.Token);
                Assert.IsFalse(task.IsCompleted);
                var next = new List<NetworkResult>();
                NetworkManager.PostQueue(new TestRequest("next"), next.Add);
                cancel.Cancel();
                Assert.IsTrue(task.IsCompleted, "An undecided request ends when its caller cancels.");
                Assert.AreEqual(NetworkFailure.Cancelled, task.Result.Failure);
                Assert.AreEqual(1, next.Count, "The queue continues after the cancelled request.");
                Assert.IsTrue(next[0].Success);
            }
        }
    }

    public sealed class NetworkResponseFormatTests
    {
        [Test]
        public void InterpretsDataErrorsAndSuccessFlag()
        {
            var format = new NetworkResponseFormat();
            NetworkResult ok = format.Interpret(new JObject { ["data"] = new JObject { ["a"] = 1 } }, 200);
            Assert.IsTrue(ok.Success);
            Assert.AreEqual(1, ok.Data["a"].Value<int>());
            Assert.AreEqual(200, ok.ProviderCode);

            Assert.AreEqual(NetworkFailure.Rejected, format.Interpret(new JObject { ["errorCode"] = "NO_MAIL" }).Failure);
            Assert.AreEqual(NetworkFailure.SessionInvalid, format.Interpret(new JObject { ["errorCode"] = "session_invalid" }).Failure);
            Assert.AreEqual(NetworkFailure.Maintenance, format.Interpret(new JObject { ["errorCode"] = "MAINTENANCE_MODE" }).Failure);
            Assert.AreEqual(NetworkFailure.InvalidResponse, format.Interpret(new JObject { ["data"] = new JArray() }).Failure);

            var http = new NetworkResponseFormat { SuccessKey = "success", ErrorCodeKey = "code", DataKey = "result" };
            Assert.AreEqual(NetworkFailure.Rejected, http.Interpret(new JObject { ["success"] = false, ["message"] = "denied" }).Failure);
            Assert.IsTrue(http.Interpret(new JObject { ["success"] = true, ["code"] = 0, ["result"] = new JObject() }).Success);
            NetworkResult refused = http.Interpret(new JObject { ["success"] = false, ["code"] = 4001 });
            Assert.AreEqual("4001", refused.ServerErrorCode);

            var whole = new NetworkResponseFormat { DataKey = null };
            Assert.AreEqual(5, whole.Interpret(new JObject { ["userMails"] = 5 }).Data["userMails"].Value<int>());
        }
    }

    public sealed class NetworkRequestCacheTests
    {
        private long _now;

        [SetUp]
        public void SetUp() { NetworkRequestCache.ResetAll(); _now = 1_000_000; NetworkRequestCache.SetClock(() => _now); }

        [TearDown]
        public void TearDown() => NetworkRequestCache.ResetAll();

        [Test]
        public void CooldownInFlightAndInvalidation()
        {
            Assert.IsTrue(NetworkRequestCache.TryBegin("userMails"));
            Assert.IsFalse(NetworkRequestCache.TryBegin("userMails"), "No duplicate while in flight.");
            NetworkRequestCache.End("userMails");
            Assert.IsFalse(NetworkRequestCache.CanRequest("userMails"));
            Assert.Greater(NetworkRequestCache.GetRemainingCooldown("userMails").TotalMinutes, 14);

            NetworkRequestCache.Invalidate("userMails");
            Assert.IsTrue(NetworkRequestCache.TryBegin("userMails"));
            NetworkRequestCache.End("userMails", success: false);
            Assert.IsTrue(NetworkRequestCache.CanRequest("userMails"), "A failure allows the next request.");

            Assert.IsTrue(NetworkRequestCache.TryBegin("userMails", group: 2));
            NetworkRequestCache.End("userMails", group: 2);
            _now += (long)NetworkRequestCache.DefaultCooldown.TotalMilliseconds;
            Assert.IsTrue(NetworkRequestCache.CanRequest("userMails", group: 2));
        }
    }
}
