using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network.Tests
{
    internal sealed class TestRequest : NetworkRequest
    {
        private readonly string _name, _target;
        private readonly bool _session, _maintenance;
        public Dictionary<string, object> Defaults = new Dictionary<string, object>();

        public TestRequest(string name = "testCallable", string target = null, bool requiresSession = false, bool blockedDuringMaintenance = false)
        { _name = name; _target = target; _session = requiresSession; _maintenance = blockedDuringMaintenance; }

        public override string Name => _name;
        public override string Target => _target ?? base.Target;
        public override bool RequiresSession => _session;
        public override bool BlockedDuringMaintenance => _maintenance;
        public TestRequest WithKeys(bool replace, params string[] keys) { DataKeys = keys; ReplaceData = replace; return this; }
        protected override Dictionary<string, object> CreateDefaultParams() => new Dictionary<string, object>(Defaults);
    }

    /// <summary>Returns scripted results. A null script entry leaves the call pending until Release.</summary>
    internal sealed class FakeProvider : INetworkProvider
    {
        public readonly List<NetworkCall> Calls = new List<NetworkCall>();
        public readonly Queue<NetworkResult?> Script = new Queue<NetworkResult?>();
        public readonly List<TaskCompletionSource<NetworkResult>> Pending = new List<TaskCompletionSource<NetworkResult>>();
        public bool Ready = true;

        public bool IsReady(string environmentKey) => Ready;

        public Task<NetworkResult> SendAsync(NetworkCall call, CancellationToken cancellationToken)
        {
            Calls.Add(call);
            NetworkResult? next = Script.Count > 0 ? Script.Dequeue() : NetworkResult.Succeeded(new JObject { ["ok"] = true });
            if (next.HasValue) return Task.FromResult(next.Value);
            var pending = new TaskCompletionSource<NetworkResult>();
            Pending.Add(pending);
            return pending.Task;
        }

        public void Release(int index, NetworkResult result) => Pending[index].TrySetResult(result);
    }

    internal sealed class FakeLocal : INetworkLocalService
    {
        public Func<NetworkRequest, bool> Handles = _ => true;
        public Func<NetworkCall, JObject> Handle = call => new JObject { ["local"] = call.Request.Name };
        /// <summary>When set, the call waits for this instead of answering at once.</summary>
        public TaskCompletionSource<JObject> Hold;
        public int Calls;

        public bool CanHandle(NetworkRequest request) => Handles(request);

        public Task<JObject> HandleAsync(NetworkCall call, CancellationToken cancellationToken)
        {
            Calls++;
            return Hold != null ? Hold.Task : Task.FromResult(Handle(call));
        }
    }
}
