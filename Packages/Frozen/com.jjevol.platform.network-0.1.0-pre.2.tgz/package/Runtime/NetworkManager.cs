using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace PlatformLibrary.Network
{
    /// <summary>
    /// The only network entry point games use. Decides the route (server provider or local service), keeps the
    /// game session and maintenance state, the queue, retries and loading, applies success data before the
    /// callback, and calls each callback once. Use from the Unity main thread.
    /// </summary>
    public static class NetworkManager
    {
        private sealed class Entry
        {
            public NetworkRequest Request;
            public Action<NetworkResult> Callback;
            public bool Queued;
            public bool AwaitingDecision;
            public bool Done;
            public CancellationToken External;
            public CancellationTokenRegistration CallerCancel;
        }

        private static readonly Dictionary<string, INetworkProvider> Providers = new Dictionary<string, INetworkProvider>(StringComparer.Ordinal);
        private static readonly List<Entry> Active = new List<Entry>();
        private static readonly LinkedList<Entry> Queue = new LinkedList<Entry>();
        private static readonly NetworkSession SessionState = new NetworkSession();
        private static INetworkLocalService _local;
        private static readonly List<Action<NetworkRequest, NetworkResult>> Appliers = new List<Action<NetworkRequest, NetworkResult>>();
        private static Action<NetworkFailureContext> _failureHandler;
        private static Func<bool> _connectivity;
        private static NetworkResponseFormat _format = new NetworkResponseFormat();
        private static NetworkRoute _defaultRoute = NetworkRoute.Server;
        private static CancellationTokenSource _generation = new CancellationTokenSource();
        private static Entry _queueRunning;
        private static bool _queuePaused, _loading, _warnedLocalWithoutProvider;
        internal static Func<TimeSpan, CancellationToken, Task> DelayAsync = (delay, token) => Task.Delay(delay, token);

        public static event Action<bool> LoadingChanged;
        public static event Action<long> ServerTimeReceived;
        public static event Action<NetworkInterruption> Interrupted;
        public static event Action AccessRestored;
        public static event Action SessionChanged;
        public static event Action<string> EnvironmentChanged;
        public static event Action<NetworkRequest> RequestCompleted;

        /// <summary>Time limit for one server attempt when the request sets none. Null means no limit.</summary>
        public static TimeSpan? ServerTimeout { get; set; } = TimeSpan.FromSeconds(30);
        /// <summary>
        /// Time limit for one local service call when the request sets none. Null (the default) means no limit, so a
        /// breakpoint in the local service does not end the request as Timeout.
        /// </summary>
        public static TimeSpan? LocalTimeout { get; set; }
        public static string EnvironmentKey { get; private set; } = string.Empty;
        public static NetworkSession Session => SessionState;
        public static NetworkResponseFormat ResponseFormat => _format;
        public static bool IsLoading => _loading;
        public static bool IsWaitingForResponse => Active.Any(entry => !entry.AwaitingDecision);

        // ---- Connections -------------------------------------------------------------------------------

        public static void SetServerProvider(INetworkProvider provider) => SetServerProvider(NetworkTarget.Default, provider);

        public static void SetServerProvider(string target, INetworkProvider provider)
        {
            if (string.IsNullOrEmpty(target)) throw new ArgumentException("A target key is required.", nameof(target));
            if (provider == null) Providers.Remove(target);
            else Providers[target] = provider;
        }

        public static void SetLocalService(INetworkLocalService service) => _local = service;
        /// <summary>
        /// Adds a function called for every success before the request callback. Appliers run in the order they were
        /// added; adding one that is already registered does nothing. A throw is logged, the remaining appliers still
        /// run, and the request ends as ApplyFailed with the first exception.
        /// </summary>
        public static void AddResponseApplier(Action<NetworkRequest, NetworkResult> applier)
        {
            if (applier == null) throw new ArgumentNullException(nameof(applier));
            if (!Appliers.Contains(applier)) Appliers.Add(applier);
        }

        /// <summary>Removes an applier added with <see cref="AddResponseApplier"/>. Returns false when it was not registered.</summary>
        public static bool RemoveResponseApplier(Action<NetworkRequest, NetworkResult> applier) => applier != null && Appliers.Remove(applier);
        /// <summary>Called for failures that are not interruptions when the request uses default handling.</summary>
        public static void SetDefaultFailureHandler(Action<NetworkFailureContext> handler) => _failureHandler = handler;
        /// <summary>Optional check before server sends. False ends the request as NoConnection without sending.</summary>
        public static void SetConnectivityCheck(Func<bool> check) => _connectivity = check;
        public static void SetResponseFormat(NetworkResponseFormat format) => _format = format ?? throw new ArgumentNullException(nameof(format));

        /// <summary>Cancels everything and removes every connection, setting and event subscriber.</summary>
        public static void ClearAll()
        {
            CancelAll();
            Providers.Clear();
            _local = null; _failureHandler = null; _connectivity = null;
            Appliers.Clear();
            _format = new NetworkResponseFormat();
            _defaultRoute = NetworkRoute.Server;
            ServerTimeout = TimeSpan.FromSeconds(30);
            LocalTimeout = null;
            _warnedLocalWithoutProvider = false;
            EnvironmentKey = string.Empty;
            SessionState.Reset();
            _queuePaused = false;
            _loading = false;
            LoadingChanged = null; ServerTimeReceived = null; Interrupted = null; AccessRestored = null;
            SessionChanged = null; EnvironmentChanged = null; RequestCompleted = null;
            DelayAsync = (delay, token) => Task.Delay(delay, token);
            NetworkRequestCache.ResetAll();
            NetworkTestFailures.Clear();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetOnLoad() => ClearAll();

        // ---- Route -------------------------------------------------------------------------------------

        /// <summary>Global route for requests whose Route is None. Changing it cancels pending requests.</summary>
        public static NetworkRoute DefaultRoute
        {
            get => _defaultRoute;
            set
            {
                if (value == NetworkRoute.None) value = NetworkRoute.Server;
                if (value == _defaultRoute) return;
                ChangeState(cancelQueued: true, () =>
                {
                    _defaultRoute = value;
                    NetworkRequestCache.ResetForSwitch();
                });
            }
        }

        public static NetworkRoute ResolveRoute(NetworkRequest request)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            return request.Route == NetworkRoute.None ? _defaultRoute : request.Route;
        }

        // ---- Environment -------------------------------------------------------------------------------

        /// <summary>
        /// Switches the server environment (for example "live" or "stage"). Resets the session and maintenance state
        /// and invalidates the request cache first, then ends in-flight, queued and undecided requests as Cancelled
        /// (late responses are dropped), then raises EnvironmentChanged. Requests posted from those callbacks use the
        /// new environment.
        /// </summary>
        public static void SwitchEnvironment(string environmentKey)
        {
            if (environmentKey == null) throw new ArgumentNullException(nameof(environmentKey));
            bool hadSession = SessionState.HasSession;
            ChangeState(cancelQueued: true, () =>
            {
                SessionState.Reset();
                NetworkRequestCache.ResetForSwitch();
                EnvironmentKey = environmentKey;
            });
            if (hadSession) Raise(SessionChanged);
            Raise(EnvironmentChanged, environmentKey);
        }

        // ---- Sending -----------------------------------------------------------------------------------

        public static void Post(NetworkRequest request, Action<NetworkResult> callback = null)
            => Start(request, callback, false, CancellationToken.None);

        /// <summary>Sends after every earlier queued request has finished, in order.</summary>
        public static void PostQueue(NetworkRequest request, Action<NetworkResult> callback = null)
            => Start(request, callback, true, CancellationToken.None);

        public static Task<NetworkResult> PostAsync(NetworkRequest request, CancellationToken cancellationToken = default)
        {
            var completion = new TaskCompletionSource<NetworkResult>();
            Start(request, result => completion.TrySetResult(result), false, cancellationToken);
            return completion.Task;
        }

        public static Task<NetworkResult> PostQueueAsync(NetworkRequest request, CancellationToken cancellationToken = default)
        {
            var completion = new TaskCompletionSource<NetworkResult>();
            Start(request, result => completion.TrySetResult(result), true, cancellationToken);
            return completion.Task;
        }

        // ---- Control -----------------------------------------------------------------------------------

        /// <summary>Ends every in-flight, queued and undecided request as Cancelled. Late responses are dropped.</summary>
        public static void CancelAll() => ChangeState(cancelQueued: true, null);

        /// <summary>
        /// Starts a new generation, applies <paramref name="change"/>, then ends the old generation's requests as
        /// Cancelled. Callbacks run after the change, so requests they post use the new state and generation.
        /// Queued requests are cancelled only when <paramref name="cancelQueued"/>; otherwise they stay and continue.
        /// </summary>
        private static void ChangeState(bool cancelQueued, Action change)
        {
            CancellationTokenSource old = _generation;
            _generation = new CancellationTokenSource();
            var ended = new List<KeyValuePair<Entry, NetworkResult>>();
            if (cancelQueued)
            {
                foreach (Entry entry in Queue) ended.Add(new KeyValuePair<Entry, NetworkResult>(entry, Cancelled(entry.Request)));
                Queue.Clear();
            }
            foreach (Entry entry in Active.Where(entry => entry.AwaitingDecision).ToList())
                ended.Add(new KeyValuePair<Entry, NetworkResult>(entry, Cancelled(entry.Request)));

            change?.Invoke();

            old.Cancel(); // Ends in-flight sends. Not disposed: retries and late continuations may still read its token.
            foreach (KeyValuePair<Entry, NetworkResult> pair in ended) Complete(pair.Key, pair.Value, pump: false);
            UpdateLoading();
            Pump();
        }

        /// <summary>While true, queued requests wait.</summary>
        public static bool QueuePaused
        {
            get => _queuePaused;
            set { _queuePaused = value; if (!value) Pump(); }
        }

        public static int GetPendingCount(string name)
            => Active.Count(entry => entry.Request.Name == name) + Queue.Count(entry => entry.Request.Name == name);

        // ---- Session -----------------------------------------------------------------------------------

        /// <summary>
        /// Starts a game session. Sent and undecided requests end as Cancelled; queued requests stay and are sent with
        /// the new session. Restores access after a session invalid notice.
        /// </summary>
        public static void SetSession(string sessionId)
        {
            if (string.IsNullOrEmpty(sessionId)) throw new ArgumentException("A session ID is required. Use ClearSession to end it.", nameof(sessionId));
            bool wasInvalid = SessionState.IsSessionInvalid;
            ChangeState(cancelQueued: false, () =>
            {
                SessionState.SessionId = sessionId;
                SessionState.IsSessionInvalid = false;
            });
            Raise(SessionChanged);
            if (wasInvalid) Raise(AccessRestored);
        }

        /// <summary>Ends the game session. Sent and undecided requests end as Cancelled; queued requests stay.</summary>
        public static void ClearSession()
        {
            ChangeState(cancelQueued: false, () => SessionState.SessionId = null);
            Raise(SessionChanged);
        }

        /// <summary>Clears the session, session invalid, maintenance and bypass state. Queued requests stay, as in ClearSession.</summary>
        public static void ResetSession()
        {
            ChangeState(cancelQueued: false, SessionState.Reset);
            Raise(SessionChanged);
        }

        /// <summary>Project's maintenance monitor. Entering raises Interrupted once; leaving raises AccessRestored.</summary>
        public static void SetMaintenance(bool maintenance, string message = null)
        {
            if (maintenance)
            {
                SessionState.MaintenanceMessage = message ?? string.Empty;
                if (SessionState.IsMaintenance) return;
                SessionState.IsMaintenance = true;
                Raise(Interrupted, new NetworkInterruption(NetworkFailure.Maintenance, _format.MaintenanceCode, message));
                FailBlockedQueue();
            }
            else if (SessionState.IsMaintenance)
            {
                SessionState.IsMaintenance = false;
                SessionState.MaintenanceMessage = string.Empty;
                Raise(AccessRestored);
                Pump();
            }
        }

        /// <summary>Lets maintenance-blocked requests through (for example a reviewer allowed by version check). A server maintenance rejection clears it.</summary>
        public static void SetMaintenanceBypass(bool bypass) => SessionState.MaintenanceBypass = bypass;

        // ---- Implementation ----------------------------------------------------------------------------

        private static void Start(NetworkRequest request, Action<NetworkResult> callback, bool queued, CancellationToken external)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            request.MarkPosting();
            var entry = new Entry { Request = request, Callback = callback, Queued = queued, External = external };
            if (queued)
            {
                Queue.AddLast(entry);
                UpdateLoading();
                Pump();
            }
            else
            {
                Active.Add(entry);
                UpdateLoading();
                _ = RunAsync(entry);
            }
            // A send is cancelled through its linked token; this ends a request still waiting in the queue or for a decision.
            if (!entry.Done && external.CanBeCanceled)
            {
                SynchronizationContext context = SynchronizationContext.Current;
                entry.CallerCancel = external.Register(() =>
                {
                    if (context == null || context == SynchronizationContext.Current) CancelWaiting(entry);
                    else context.Post(_ => CancelWaiting(entry), null);
                });
            }
        }

        private static void CancelWaiting(Entry entry)
        {
            if (entry.Done) return;
            if (Queue.Remove(entry)) Complete(entry, Cancelled(entry.Request), pump: false);
            else if (entry.AwaitingDecision) Complete(entry, Cancelled(entry.Request), pump: true);
        }

        private static void Pump()
        {
            while (_queueRunning == null && !_queuePaused && Queue.Count > 0)
            {
                Entry next = Queue.First.Value;
                Queue.RemoveFirst();
                if (next.Done) continue;
                _queueRunning = next;
                Active.Add(next);
                UpdateLoading();
                _ = RunAsync(next);
            }
        }

        private static async Task RunAsync(Entry entry)
        {
            NetworkResult result;
            try
            {
                CancellationToken generation = _generation.Token;
                using (CancellationTokenSource linked = CancellationTokenSource.CreateLinkedTokenSource(generation, entry.External))
                {
                    CancellationToken token = linked.Token;
                    int attempt = 0;
                    while (true)
                    {
                        attempt++;
                        result = await ExecuteOnceAsync(entry.Request, attempt, token);
                        NetworkRetryPolicy retry = entry.Request.Retry;
                        if (result.Success || token.IsCancellationRequested || retry == null || !retry.ShouldRetry(result.Failure, attempt)) break;
                        try { await DelayAsync(retry.GetDelay(attempt), token); }
                        catch (OperationCanceledException) { result = Cancelled(entry.Request); break; }
                    }
                    if (token.IsCancellationRequested) result = Cancelled(entry.Request);
                }
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                result = NetworkResult.Failed(NetworkFailure.ProviderError, detail: exception.Message).WithRoute(SafeRoute(entry.Request));
            }
            if (entry.Done) return; // Already ended by CancelAll; the late result is dropped.
            Finish(entry, result);
        }

        private static async Task<NetworkResult> ExecuteOnceAsync(NetworkRequest request, int attempt, CancellationToken token)
        {
            NetworkRoute route = ResolveRoute(request);
            if (token.IsCancellationRequested) return Cancelled(request);

            if (NetworkTestFailures.TryConsume(request.Name, out NetworkResult injected))
            {
                ApplyServerState(injected);
                return injected.WithRoute(route);
            }

            if (route == NetworkRoute.Local) return (await RunLocalAsync(request, attempt, token)).WithRoute(route);

            string target = string.IsNullOrEmpty(request.Target) ? NetworkTarget.Default : request.Target;
            if (!Providers.TryGetValue(target, out INetworkProvider provider))
            {
                if (_local != null && !_warnedLocalWithoutProvider)
                {
                    _warnedLocalWithoutProvider = true;
                    Debug.LogWarning("[Network] " + request.Name + " took the Server route, but there is no server provider for target " + target +
                        " while a local service is set. Set NetworkManager.DefaultRoute = NetworkRoute.Local or the request Route to use the local service. This warning is shown once.");
                }
                return NetworkResult.Failed(NetworkFailure.Unsupported, detail: "No server provider for target " + target + ".").WithRoute(route);
            }
            NetworkFailure blocked = GetBlockedFailure(request);
            if (blocked != NetworkFailure.None) return Blocked(blocked).WithRoute(route);
            if (_connectivity != null && !_connectivity())
                return NetworkResult.Failed(NetworkFailure.NoConnection, detail: "Connectivity check failed.").WithRoute(route);
            if (!provider.IsReady(EnvironmentKey))
                return NetworkResult.Failed(NetworkFailure.NotInitialized, detail: "Provider for " + target + " is not ready in environment " + EnvironmentKey + ".").WithRoute(route);

            var call = new NetworkCall(request, request.BuildParameters(), EnvironmentKey, SessionState.SessionId, attempt, route, _format);
            NetworkResult result = await WithTimeoutAsync(request, request.Timeout ?? ServerTimeout, token, timeoutToken => provider.SendAsync(call, timeoutToken));
            if (!token.IsCancellationRequested) ApplyServerState(result);
            return result.WithRoute(route);
        }

        private static async Task<NetworkResult> RunLocalAsync(NetworkRequest request, int attempt, CancellationToken token)
        {
            INetworkLocalService local = _local;
            if (local == null) return NetworkResult.Failed(NetworkFailure.Unsupported, detail: "No local service.");
            bool handles;
            try { handles = local.CanHandle(request); }
            catch (Exception exception) { return NetworkResult.Failed(NetworkFailure.ProviderError, detail: exception.Message); }
            if (!handles) return NetworkResult.Failed(NetworkFailure.Unsupported, detail: "The local service does not handle " + request.Name + ".");

            var call = new NetworkCall(request, request.BuildParameters(), EnvironmentKey, SessionState.SessionId, attempt, NetworkRoute.Local, _format);
            NetworkResponseFormat format = _format;
            return await WithTimeoutAsync(request, request.Timeout ?? LocalTimeout, token, async timeoutToken =>
            {
                JObject data = await local.HandleAsync(call, timeoutToken);
                data ??= new JObject();
                var response = new JObject();
                if (format.DataKey != null) response[format.DataKey] = data;
                else response = (JObject)data.DeepClone();
                // Same shape as a server response, so ServerTimeReceived also fires on the local route.
                if (format.TimeKey != null && format.LocalTime != null && !response.ContainsKey(format.TimeKey))
                    response[format.TimeKey] = format.LocalTime();
                return NetworkResult.Succeeded(data, response);
            });
        }

        private static async Task<NetworkResult> WithTimeoutAsync(NetworkRequest request, TimeSpan? timeout, CancellationToken token, Func<CancellationToken, Task<NetworkResult>> send)
        {
            using (CancellationTokenSource limit = CancellationTokenSource.CreateLinkedTokenSource(token))
            {
                if (timeout.HasValue && timeout.Value > TimeSpan.Zero) limit.CancelAfter(timeout.Value);
                var stopped = new TaskCompletionSource<bool>();
                using (limit.Token.Register(() => stopped.TrySetResult(true)))
                {
                    try
                    {
                        Task<NetworkResult> sending = send(limit.Token);
                        Task first = await Task.WhenAny(sending, stopped.Task);
                        if (first == sending) return await sending;
                        ObserveLater(sending);
                    }
                    catch (NetworkRejection rejection)
                    {
                        return NetworkResult.Failed(NetworkFailure.Rejected, rejection.Code, rejection.Message,
                            rejection.Details == null ? null : new JObject { ["details"] = rejection.Details });
                    }
                    catch (OperationCanceledException) when (limit.IsCancellationRequested) { }
                    catch (Exception exception)
                    {
                        Debug.LogWarning("[Network] " + request.Name + " failed: " + exception.Message);
                        return NetworkResult.Failed(NetworkFailure.ProviderError, detail: exception.GetType().Name + ": " + exception.Message);
                    }
                }
                return token.IsCancellationRequested ? Cancelled(request)
                    : NetworkResult.Failed(NetworkFailure.Timeout, detail: "No response within " + timeout + ".");
            }
        }

        private static void ObserveLater(Task task) => task.ContinueWith(t => { _ = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted);

        private static NetworkFailure GetBlockedFailure(NetworkRequest request)
        {
            if (request.RequiresSession && SessionState.IsSessionInvalid) return NetworkFailure.SessionInvalid;
            if (request.BlockedDuringMaintenance && SessionState.IsMaintenance && !SessionState.MaintenanceBypass) return NetworkFailure.Maintenance;
            if (request.RequiresSession && !SessionState.HasSession) return NetworkFailure.SessionNotReady;
            return NetworkFailure.None;
        }

        private static NetworkResult Blocked(NetworkFailure failure)
        {
            if (failure == NetworkFailure.SessionInvalid) return NetworkResult.Failed(failure, _format.SessionInvalidCode, detail: "The game session is invalid.");
            if (failure == NetworkFailure.Maintenance) return NetworkResult.Failed(failure, _format.MaintenanceCode, SessionState.MaintenanceMessage, detail: "The server is under maintenance.");
            return NetworkResult.Failed(failure, detail: "No game session.");
        }

        private static void ApplyServerState(NetworkResult result)
        {
            if (result.Failure == NetworkFailure.SessionInvalid)
            {
                if (SessionState.IsSessionInvalid) return;
                SessionState.IsSessionInvalid = true;
                Raise(Interrupted, new NetworkInterruption(NetworkFailure.SessionInvalid, result.ServerErrorCode, result.Message));
                FailBlockedQueue();
            }
            else if (result.Failure == NetworkFailure.Maintenance)
            {
                SessionState.MaintenanceBypass = false;
                if (SessionState.IsMaintenance) return;
                SessionState.IsMaintenance = true;
                SessionState.MaintenanceMessage = result.Message;
                Raise(Interrupted, new NetworkInterruption(NetworkFailure.Maintenance, result.ServerErrorCode, result.Message));
                FailBlockedQueue();
            }
        }

        private static void FailBlockedQueue()
        {
            foreach (Entry entry in Queue.ToList())
            {
                if (ResolveRoute(entry.Request) != NetworkRoute.Server) continue;
                NetworkFailure blocked = GetBlockedFailure(entry.Request);
                if (blocked != NetworkFailure.SessionInvalid && blocked != NetworkFailure.Maintenance) continue;
                Queue.Remove(entry);
                Complete(entry, Blocked(blocked).WithRoute(NetworkRoute.Server), pump: false);
            }
            UpdateLoading();
        }

        private static void Finish(Entry entry, NetworkResult result)
        {
            if (result.Response != null && _format.TryReadTime(result.Response, out long time)) Raise(ServerTimeReceived, time);
            if (result.Success && Appliers.Count > 0)
            {
                Exception first = null;
                // A copy: an applier may add or remove appliers.
                foreach (Action<NetworkRequest, NetworkResult> applier in Appliers.ToArray())
                {
                    try { applier(entry.Request, result); }
                    catch (Exception exception)
                    {
                        Debug.LogException(exception);
                        first ??= exception;
                    }
                }
                if (first != null) result = result.AsApplyFailed(first);
            }

            if (!result.Success && !result.IsInterruption && entry.Request.UseDefaultFailureHandling && _failureHandler != null)
            {
                entry.AwaitingDecision = true;
                UpdateLoading();
                NetworkResult failed = result;
                var context = new NetworkFailureContext(entry.Request, failed,
                    retry: () => { if (entry.Done) return; entry.AwaitingDecision = false; UpdateLoading(); _ = RunAsync(entry); },
                    finish: () => { if (!entry.Done) Complete(entry, failed, pump: true); });
                try { _failureHandler(context); }
                catch (Exception exception) { Debug.LogException(exception); context.Finish(); }
                return;
            }
            Complete(entry, result, pump: true);
        }

        private static void Complete(Entry entry, NetworkResult result, bool pump)
        {
            if (entry.Done) return;
            entry.Done = true;
            entry.AwaitingDecision = false;
            entry.CallerCancel.Dispose();
            Active.Remove(entry);
            if (ReferenceEquals(_queueRunning, entry)) _queueRunning = null;
            entry.Request.MarkCompleted(result);
            UpdateLoading();
            try { entry.Callback?.Invoke(result); }
            catch (Exception exception) { Debug.LogException(exception); }
            Raise(RequestCompleted, entry.Request);
            if (pump) Pump();
        }

        private static void UpdateLoading()
        {
            bool loading = Active.Any(entry => !entry.AwaitingDecision && entry.Request.ShowLoading) || Queue.Any(entry => entry.Request.ShowLoading);
            if (loading == _loading) return;
            _loading = loading;
            Raise(LoadingChanged, loading);
        }

        private static NetworkResult Cancelled(NetworkRequest request)
            => NetworkResult.Failed(NetworkFailure.Cancelled, detail: "Cancelled.").WithRoute(SafeRoute(request));

        private static NetworkRoute SafeRoute(NetworkRequest request) => request.Route == NetworkRoute.None ? _defaultRoute : request.Route;

        private static void Raise(Action handler)
        {
            if (handler == null) return;
            foreach (Action subscriber in handler.GetInvocationList())
                try { subscriber(); } catch (Exception exception) { Debug.LogException(exception); }
        }

        private static void Raise<T>(Action<T> handler, T value)
        {
            if (handler == null) return;
            foreach (Action<T> subscriber in handler.GetInvocationList())
                try { subscriber(value); } catch (Exception exception) { Debug.LogException(exception); }
        }
    }
}
