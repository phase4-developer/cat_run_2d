using System;
using System.Collections;
using System.Collections.Generic;

namespace PlatformLibrary.Network
{
    /// <summary>
    /// Parent of every game request. The project defines its own parent (common parameters, session needs)
    /// and one class per API. Send with <see cref="NetworkManager"/>. An instance is sent once;
    /// <c>yield return request</c> waits for it in a coroutine.
    /// </summary>
    public abstract class NetworkRequest : IEnumerator
    {
        private readonly Dictionary<string, object> _params = new Dictionary<string, object>(StringComparer.Ordinal);

        /// <summary>Function name or HTTP path.</summary>
        public abstract string Name { get; }
        /// <summary>Server provider key. See <see cref="NetworkManager.SetServerProvider(string, INetworkProvider)"/>.</summary>
        public virtual string Target => NetworkTarget.Default;
        /// <summary>None follows <see cref="NetworkManager.DefaultRoute"/>; Server or Local forces that route for this request.</summary>
        public NetworkRoute Route { get; set; }
        /// <summary>Request-specific values. Defaults from <see cref="CreateDefaultParams"/> are merged under them when sent.</summary>
        public IReadOnlyDictionary<string, object> Params => _params;
        /// <summary>Repository keys this response changes. Strings, so the network does not reference the repository.</summary>
        public string[] DataKeys { get; protected set; } = Array.Empty<string>();
        /// <summary>Apply success data as a replacement instead of a merge.</summary>
        public bool ReplaceData { get; protected set; }
        public virtual bool RequiresSession => false;
        public virtual bool BlockedDuringMaintenance => false;
        public bool ShowLoading { get; set; } = true;
        public bool UseDefaultFailureHandling { get; set; } = true;
        /// <summary>Automatic retry. Off unless set. Do not set it for requests the server does not deduplicate.</summary>
        public NetworkRetryPolicy Retry { get; set; }
        /// <summary>Time limit for one attempt. Null uses <see cref="NetworkManager.ServerTimeout"/> or <see cref="NetworkManager.LocalTimeout"/> by route.</summary>
        public TimeSpan? Timeout { get; set; }

        public NetworkResult Result { get; private set; }
        public bool Completed { get; private set; }
        public bool IsPosting { get; private set; }
        public DateTime PostedAtUtc { get; private set; }

        public NetworkRequest Add(string key, object value)
        {
            if (string.IsNullOrEmpty(key)) throw new ArgumentException("A parameter key is required.", nameof(key));
            if (IsPosting || Completed) throw new InvalidOperationException("Parameters cannot change after posting.");
            _params[key] = value;
            return this;
        }

        /// <summary>Common values for every request of a project parent class (version, language and so on). Evaluated at send time.</summary>
        protected virtual Dictionary<string, object> CreateDefaultParams() => new Dictionary<string, object>(StringComparer.Ordinal);

        internal Dictionary<string, object> BuildParameters()
        {
            Dictionary<string, object> merged = CreateDefaultParams() ?? new Dictionary<string, object>(StringComparer.Ordinal);
            var result = new Dictionary<string, object>(merged, StringComparer.Ordinal);
            foreach (var pair in _params) result[pair.Key] = pair.Value;
            return result;
        }

        internal void MarkPosting()
        {
            if (IsPosting || Completed) throw new InvalidOperationException("A request instance is sent once. Use NetworkFailureContext.Retry to send it again: " + Name);
            IsPosting = true;
            PostedAtUtc = DateTime.UtcNow;
        }

        internal void MarkCompleted(NetworkResult result)
        {
            Result = result;
            IsPosting = false;
            Completed = true;
        }

        object IEnumerator.Current => null;
        bool IEnumerator.MoveNext() => !Completed;
        void IEnumerator.Reset() { }

        public override string ToString() => GetType().Name + "(" + Name + ")";
    }
}
