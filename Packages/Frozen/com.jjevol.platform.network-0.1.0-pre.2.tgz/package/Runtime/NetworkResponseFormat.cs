using System;
using Newtonsoft.Json.Linq;

namespace PlatformLibrary.Network
{
    /// <summary>
    /// Response key names and the server strings for session invalid and maintenance.
    /// Defaults follow the original Firebase form; a project changes them for other servers.
    /// </summary>
    public sealed class NetworkResponseFormat
    {
        public string ErrorCodeKey { get; set; } = "errorCode";
        public string MessageKey { get; set; } = "message";
        /// <summary>Key of the success data. Null means the whole response is the data.</summary>
        public string DataKey { get; set; } = "data";
        public string TimeKey { get; set; } = "timeStamp";
        /// <summary>
        /// Value the manager puts under <see cref="TimeKey"/> in local service responses that do not set it. Defaults to
        /// Unix time in milliseconds, the original server's unit. Null leaves local responses without a time.
        /// </summary>
        public Func<long> LocalTime { get; set; } = () => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        /// <summary>Optional boolean success flag (for example the original HTTP form "success"). Null when not used.</summary>
        public string SuccessKey { get; set; }
        public string SessionInvalidCode { get; set; } = "SESSION_INVALID";
        public string MaintenanceCode { get; set; } = "MAINTENANCE_MODE";
        /// <summary>Parameter name that carries the session ID for providers that send it in the body.</summary>
        public string SessionParameter { get; set; } = "sessionId";

        /// <summary>Maps a game error string to a failure: session invalid, maintenance or rejected.</summary>
        public NetworkFailure Classify(string errorCode)
        {
            if (string.IsNullOrEmpty(errorCode)) return NetworkFailure.None;
            if (string.Equals(errorCode, SessionInvalidCode, StringComparison.OrdinalIgnoreCase)) return NetworkFailure.SessionInvalid;
            if (string.Equals(errorCode, MaintenanceCode, StringComparison.OrdinalIgnoreCase)) return NetworkFailure.Maintenance;
            return NetworkFailure.Rejected;
        }

        /// <summary>Interprets a decoded response object. Providers call this after transport success.</summary>
        public NetworkResult Interpret(JObject response, int providerCode = 0)
        {
            if (response == null) return NetworkResult.Failed(NetworkFailure.InvalidResponse, providerCode: providerCode, detail: "Empty response.");
            string errorCode = ReadString(response, ErrorCodeKey);
            string message = ReadString(response, MessageKey);
            // With a success flag, the flag decides; the error code key may then hold a status such as 0.
            if (SuccessKey != null && response.TryGetValue(SuccessKey, out JToken flag) && flag.Type == JTokenType.Boolean)
            {
                if (flag.Value<bool>()) errorCode = string.Empty;
                else if (string.IsNullOrEmpty(errorCode)) errorCode = string.IsNullOrEmpty(message) ? "UNKNOWN" : message;
            }
            NetworkFailure failure = Classify(errorCode);
            if (failure != NetworkFailure.None)
                return NetworkResult.Failed(failure, errorCode, message, response, providerCode);

            if (DataKey == null) return NetworkResult.Succeeded((JObject)response.DeepClone(), response, providerCode);
            if (!response.TryGetValue(DataKey, out JToken data) || data.Type == JTokenType.Null)
                return NetworkResult.Succeeded(new JObject(), response, providerCode);
            if (data is JObject objectData) return NetworkResult.Succeeded(objectData, response, providerCode);
            return NetworkResult.Failed(NetworkFailure.InvalidResponse, message: message, response: response, providerCode: providerCode,
                detail: "Expected an object under " + DataKey + ".");
        }

        public bool TryReadTime(JObject response, out long time)
        {
            time = 0;
            if (response == null || TimeKey == null || !response.TryGetValue(TimeKey, out JToken token)) return false;
            if (token.Type != JTokenType.Integer && token.Type != JTokenType.Float) return false;
            try { time = token.Value<long>(); return true; }
            catch (Exception) { return false; }
        }

        private static string ReadString(JObject response, string key)
        {
            if (key == null || !response.TryGetValue(key, out JToken token) || token.Type == JTokenType.Null) return string.Empty;
            return token.Type == JTokenType.String ? token.Value<string>() : token.ToString();
        }
    }
}
