# JJEvol Platform Network

`com.jjevol.platform.network@0.1.0-pre.2`은 게임 서버 요청의 관리자다. 게임은 `NetworkManager`와 자기 요청 클래스만 안다. 요청을 서버 공급자(HTTP, Firebase)가 처리할지 프로젝트 로컬 서비스가 처리할지는 전역 설정과 요청별 설정으로 정한다. Unity 6000.3.9f1 기준이다. 설계는 Framework 저장소의 `Docs/PlatformNetwork/Design.md`다.

필수: Unity Newtonsoft JSON 3.2.2. 서버 공급자는 별도 패키지다.

| 패키지 | 내용 |
|---|---|
| `com.jjevol.platform.network.http` | `HttpNetworkProvider` (UnityWebRequest) |
| `com.jjevol.platform.network.firebase` | `FirebaseNetworkProvider` (Firebase Functions, 소비 프로젝트가 SDK 설치) |
| `com.jjevol.platform.network.data` | 성공 응답을 `com.jjevol.data` 저장소에 반영 |

로그인(`com.jjevol.platform.core`)은 참조하지 않는다. HTTP 토큰은 프로젝트가 공급자 설정으로 잇는다.

## 시작 코드

```csharp
NetworkManager.SetServerProvider(gameProvider);                 // 기본 대상
NetworkManager.SetServerProvider("control", controlProvider);   // 버전 확인처럼 환경과 무관한 대상
NetworkManager.SetLocalService(new GameLocalService());         // 로컬 처리 구현은 프로젝트
NetworkManager.DefaultRoute = NetworkRoute.Server;              // 전역: Server 또는 Local
NetworkManager.AddResponseApplier(GameData.Apply);              // 콜백 전에 반영. 여러 개면 등록 순서
NetworkManager.SetDefaultFailureHandler(GameNetworkPopup.Show);
NetworkManager.LoadingChanged += GameLoadingUI.SetVisible;
NetworkManager.ServerTimeReceived += GameClock.SetServerTime;
NetworkManager.Interrupted += GameNetworkPopup.ShowInterruption;
```

공급자나 로컬 서비스가 없어도 게임은 돈다. 요청은 `NetworkFailure.Unsupported`로 끝난다.

## 요청 정의

```csharp
public abstract class GamePrivateRequest : NetworkRequest
{
    public override bool RequiresSession => true;
    public override bool BlockedDuringMaintenance => true;
    protected override Dictionary<string, object> CreateDefaultParams()
        => new Dictionary<string, object> { ["version"] = Application.version };
}

public sealed class ClaimMailRequest : GamePrivateRequest
{
    public override string Name => "claimMailCallable";
    public ClaimMailRequest(string mailId)
    {
        Add("mailId", mailId);
        DataKeys = new[] { "userMails", "wealthInfos" };   // 응답이 바꾸는 저장소 키
    }
}
```

| 항목 | 뜻 | 기본 |
|---|---|---|
| `Name` | 함수 이름 또는 HTTP 경로 | 필수 |
| `Target` | 서버 공급자 키 | `NetworkTarget.Default` |
| `Route` | `None`(전역 따름), `Server`, `Local` | `None` |
| `Add`, `CreateDefaultParams` | 보낼 값. 기본값은 보낼 때 계산되고 요청 값이 덮어쓴다 | |
| `DataKeys`, `ReplaceData` | 응답 반영 대상 키, 교체 여부 | 빈 배열, 병합 |
| `RequiresSession`, `BlockedDuringMaintenance` | 세션 필요, 점검 중 차단 | `false` |
| `ShowLoading`, `UseDefaultFailureHandling` | 로딩 표시, 기본 실패 처리 | `true` |
| `Retry`, `Timeout` | 자동 재시도, 한 번 시도의 시간 제한 | 없음, 서버 경로는 `NetworkManager.ServerTimeout`(30초), 로컬 경로는 `NetworkManager.LocalTimeout`(기본 없음) |
| `Result`, `Completed`, `IsPosting` | 결과. `yield return request`로 기다린다 | |

요청 인스턴스는 한 번만 보낸다.

## 보내기

```csharp
NetworkManager.Post(new ClaimMailRequest(id), result =>
{
    if (result.Success) ShowRewards(result.Data);           // 저장소는 이미 반영됨
    else if (result.Failure == NetworkFailure.Rejected) ShowMessage(result.ServerErrorCode);
});
NetworkManager.PostQueue(new ChapterEndRequest(battle), OnEnd);   // 앞 요청이 끝나야 보냄
NetworkResult check = await NetworkManager.PostAsync(new VersionCheckRequest());
yield return new NetworkBatch(requests).PostQueue();
var claim = new ClaimMailRequest(id) { Route = NetworkRoute.Local };  // 이 요청만 로컬로
```

- 콜백은 요청마다 한 번 불린다. 세션 무효, 점검, 취소로 끝나도 불리고 `result.IsInterruption`이 참이다.
- 성공이면 응답 반영 함수(`AddResponseApplier`)가 등록 순서대로 먼저 돌고 그다음 콜백이다. 반영 함수 하나가 예외를 던져도 나머지는 돌고, 요청은 첫 예외로 `ApplyFailed`가 된다. `RemoveResponseApplier`로 뺀다.
- 기본 실패 처리기는 중단이 아닌 실패에서만 불린다. 처리기는 `context.Retry()`(같은 요청 다시 보냄) 또는 `context.Finish()`(실패를 콜백에 전달) 중 하나를 불러야 하고, 그때까지 콜백은 기다린다. 처리기가 예외를 던지면 `Finish`로 본다. `CancelAll`은 결정을 기다리는 요청도 `Cancelled`로 끝낸다.
- `PostAsync`·`PostQueueAsync`의 `cancellationToken`은 보내는 중, 대기열에서 차례를 기다리는 중(`QueuePaused`, 앞 요청의 결정 대기 포함), 실패 처리 결정을 기다리는 중 언제든 요청을 `Cancelled`로 끝낸다. 대기열은 다음 요청으로 넘어간다.
- `QueuePaused`가 참이면 대기열이 멈춘다. 세션 무효·점검 상태가 되면 대기열에서 차단 대상만 바로 실패시킨다.
- `Retry`(`NetworkRetryPolicy`)는 `NoConnection`, `Timeout`, `ServerError`에서만 다시 보낸다. 서버가 중복을 막지 않는 결제 검증·보상 지급에는 켜지 않는다.
- 콜백은 보낸 스레드의 SynchronizationContext로 돌아온다. Unity 주 스레드에서 보낸다.

## 처리 경로

`Route`가 `None`이면 `DefaultRoute`를 따른다. `DefaultRoute`를 바꾸면 진행 중·대기 중 요청이 `Cancelled`로 끝난다. 서버 공급자 없이 로컬 서비스만 연결한 상태에서 Server 경로 요청이 나가면 `Unsupported`로 끝나고 경고를 한 번 남긴다.

로컬 응답에도 서버 응답처럼 `TimeKey`(기본 `timeStamp`)를 넣는다. 값은 `ResponseFormat.LocalTime`(기본 Unix 밀리초)이고, 로컬 서비스가 이미 넣은 값은 그대로 둔다. 그래서 `ServerTimeReceived`가 로컬 경로에서도 불린다.

```csharp
public sealed class GameLocalService : INetworkLocalService
{
    public bool CanHandle(NetworkRequest request) => request is ClaimMailRequest;
    public Task<JObject> HandleAsync(NetworkCall call, CancellationToken token)
    {
        // 로컬 정산. 게임 오류는 throw new NetworkRejection("NO_MAIL");
        return Task.FromResult(new JObject { ["userMails"] = ... });
    }
}
```

로컬 처리에는 세션·점검 검사를 하지 않는다. `NetworkRejection`은 `Rejected`, 그 밖의 예외는 `ProviderError`다.

## 환경, 세션, 점검

- `SwitchEnvironment("live" | "stage")`: 세션·점검 초기화, 요청 간격 캐시 무효화, 환경 키 변경을 먼저 하고, 진행 중·대기 중 요청 취소(늦은 응답 폐기) 뒤 `EnvironmentChanged`. 취소 콜백에서 새로 보낸 요청은 새 환경으로 간다. 공급자는 매 시도에 `NetworkCall.EnvironmentKey`를 받는다.
- `SetSession(id)`, `ClearSession()`, `ResetSession()`은 세션을 먼저 바꾸고, 보낸 요청과 실패 처리 결정을 기다리는 요청을 `Cancelled`로 끝낸다. 대기열 요청은 취소하지 않고 새 세션으로 보낸다. 예: `PostQueue(startSession, r => SetSession(id))` 뒤에 넣은 `PostQueue(loadUser)`는 새 세션으로 간다. 세션 ID는 저장하지 않는다.
- 서버가 세션 무효나 점검을 알리면 상태를 바꾸고 `Interrupted`를 상태 변경마다 한 번 알린다. `SetSession`이 세션 무효를, `SetMaintenance(false)`가 점검을 풀 때 `AccessRestored`.
- `SetMaintenanceBypass(true)`는 점검 중 차단 요청을 통과시킨다. 서버가 점검으로 거절하면 풀린다.
- 응답의 키 이름과 세션 무효·점검 문자열은 `NetworkResponseFormat`(`SetResponseFormat`)이다. 기본값은 원본 Firebase 형식(`errorCode`, `message`, `data`, `timeStamp`, `SESSION_INVALID`, `MAINTENANCE_MODE`)이다.

## 서버 공급자 계약

```csharp
public interface INetworkProvider
{
    bool IsReady(string environmentKey);
    Task<NetworkResult> SendAsync(NetworkCall call, CancellationToken cancellationToken);
}
```

공급자는 전송 오류를 `NetworkFailure`로 바꾸고 응답 해석에는 `call.Format.Interpret(response, providerCode)`를 쓴다. 세션 상태는 갖지 않는다. `call.SessionId`를 붙이는 방법(파라미터, 헤더)은 공급자 설정이 정한다.

## 그 밖의 도구

- `NetworkRequestCache`: 서버 데이터 요청의 진행 중 중복 방지, 성공 후 쿨타임(기본 15분), 무효화. `SetClock`으로 서버 보정 시계를 넣는다.
- `NetworkTestFailures.Fail(name, failure, count)`: Editor와 Development 빌드에서 지정 요청을 지정 횟수 실패시킨다. 서버·로컬 경로 모두.
- `SetConnectivityCheck(func)`: 프로젝트가 준 확인 함수가 거짓이면 보내지 않고 `NoConnection`.
- `ClearAll()`: 연결·설정·이벤트 구독을 모두 지운다. Domain Reload를 끈 Editor에서는 Play 시작 때 자동으로 부른다.

## 시험

`Tests/Editor`(`PlatformLibrary.Network.Tests.Editor`)에 가짜 공급자·로컬 서비스로 경로, 세션, 점검, 환경 전환, 대기열, 재시도, 실패 처리, 로딩, 시간 제한, 응답 형식, 요청 간격 시험 26개가 있다.

Unity EditMode 시험은 `Hosts/NetworkValidationHost`(잡 `network-host-2`, 후보 `abd61a5`)에서 모두 통과했다. 같은 시험을 Unity 없이 .NET 실행기(`UnityEngine.Debug` 대역)로 돌려 통과했다.
