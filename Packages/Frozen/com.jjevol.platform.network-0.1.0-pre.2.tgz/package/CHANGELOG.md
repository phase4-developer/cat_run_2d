# Changelog

## 0.1.0-pre.2 - 2026-11-10

- Breaking: `SetResponseApplier` is replaced by `AddResponseApplier` and `RemoveResponseApplier`. Appliers run in the order added; one that throws is logged, the rest still run, and the request ends as `ApplyFailed` with the first exception. Adding the same applier twice does nothing. Before this, `NetworkDataBinding.Connect` silently replaced a game's own applier.
- Breaking: `DefaultTimeout` is replaced by `ServerTimeout` (30 seconds) and `LocalTimeout` (no limit by default). A request's own `Timeout` still wins on either route. Before this, a local service stopped at a breakpoint ended as `Timeout` after 30 seconds.
- Local service responses now carry the time under `ResponseFormat.TimeKey` when the service did not set it, from `NetworkResponseFormat.LocalTime` (Unix milliseconds by default, the original server's unit; null leaves it out). `ServerTimeReceived` now fires on the local route too.
- A request that takes the Server route with no server provider for its target while a local service is set logs one warning that names `DefaultRoute` and `Route`.

Unity 6000.3.9f1, queue runner job `pkg1110-net-01` on `Hosts/NetworkValidationHost`: compile and EditMode 54/54 passed (network, network.http, network.data, data, economy). Compiling `network.firebase` against the Firebase SDK, Player and a real server are NOT_RUN.

## 0.1.0-pre.1 - 2026-11-08

- First candidate. `NetworkManager`, `NetworkRequest`, `NetworkResult`, `NetworkFailure`, `NetworkRoute`, `INetworkProvider`, `INetworkLocalService`, `NetworkRejection`, `NetworkResponseFormat`, `NetworkRetryPolicy`, `NetworkFailureContext`, `NetworkSession`, `NetworkBatch`, `NetworkRequestCache`, `NetworkTestFailures`.
- Environment, route and session changes update the state before cancelled callbacks run, so requests posted from those callbacks use the new environment and session.
- `SetSession`, `ClearSession` and `ResetSession` cancel sent and undecided requests only. Queued requests stay and are sent with the new session.
- The `PostAsync` and `PostQueueAsync` cancellation token also ends a request waiting in the queue or for a failure decision.
- Design: `Docs/PlatformNetwork/Design.md`.

Unity EditMode tests passed on Hosts/NetworkValidationHost (job network-host-2, candidate abd61a5). The Editor tests passed in an offline .NET runner with a stand-in for `UnityEngine.Debug`.
