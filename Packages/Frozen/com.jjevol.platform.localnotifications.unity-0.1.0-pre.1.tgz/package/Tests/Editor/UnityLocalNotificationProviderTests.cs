using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace PlatformLibrary.LocalNotifications.Unity.Tests
{
    public sealed class UnityLocalNotificationProviderTests
    {
        private static readonly DateTime Now = new DateTime(2026, 11, 8, 0, 0, 0, DateTimeKind.Utc);

        private FakeClient _client;
        private UnityLocalNotificationSettings _settings;
        private UnityLocalNotificationProvider _provider;
        private readonly List<LocalNotificationOpened> _opened = new List<LocalNotificationOpened>();

        [SetUp]
        public void SetUp()
        {
            _client = new FakeClient();
            _settings = new UnityLocalNotificationSettings("game", "Game", "Game notices");
            _provider = new UnityLocalNotificationProvider(_settings, _client, () => Now);
            _opened.Clear();
            _provider.Opened += _opened.Add;
        }

        [Test]
        public void InitializeStartsTheSdkAndListensForOpened()
        {
            Assert.IsTrue(Answer(_provider.Initialize).Success);
            CollectionAssert.AreEqual(new[] { "Initialize:game", "ListenForOpened" }, _client.Calls);
        }

        [Test]
        public void FailedInitializeIsAProviderError()
        {
            _client.ThrowOnInitialize = true;

            Assert.AreEqual(LocalNotificationFailure.ProviderError, Answer(_provider.Initialize).Failure);
        }

        [Test]
        public void DeniedPermissionAnswersPermissionDenied()
        {
            _client.Granted = false;

            Assert.AreEqual(LocalNotificationFailure.PermissionDenied, Answer(_provider.RequestPermission).Failure);
        }

        [Test]
        public void ScheduleReplacesTheIdAndPacksTheKey()
        {
            var notification = new LocalNotification("energy_full", "Full", "Come back", Now.AddMinutes(10), "screen=energy");

            Assert.IsTrue(Answer(done => _provider.Schedule(7, notification, done)).Success);

            CollectionAssert.AreEqual(new[] { "Cancel:7", "Schedule:7" }, _client.Calls);
            Assert.AreEqual(TimeSpan.FromMinutes(10), _client.LastDelay);
            LocalNotificationOpened packed = LocalNotificationPayload.Unpack(_client.LastPacked);
            Assert.AreEqual("energy_full", packed.Key);
            Assert.AreEqual("screen=energy", packed.Data);
        }

        [Test]
        public void PastTimeAnswersInvalidTime()
        {
            var notification = new LocalNotification("a", null, null, Now.AddSeconds(-1));

            Assert.AreEqual(LocalNotificationFailure.InvalidTime, Answer(done => _provider.Schedule(1, notification, done)).Failure);
            CollectionAssert.IsEmpty(_client.Calls);
        }

        [Test]
        public void VeryShortDelayIsRaisedToOneSecond()
        {
            var notification = new LocalNotification("a", null, null, Now.AddMilliseconds(200));

            Answer(done => _provider.Schedule(1, notification, done));

            Assert.AreEqual(TimeSpan.FromSeconds(1), _client.LastDelay);
        }

        [Test]
        public void OpenedNotificationReportsItsKeyAndDataOnce()
        {
            Answer(_provider.Initialize);

            string packed = ScheduleEnergyFull();

            _client.OpenedListener(7, packed);
            _client.OpenedListener(7, packed);

            Assert.AreEqual(1, _opened.Count);
            Assert.AreEqual("energy_full", _opened[0].Key);
            Assert.AreEqual("screen=energy", _opened[0].Data);
        }

        [Test]
        public void RescheduledNotificationOpensAgain()
        {
            Answer(_provider.Initialize);
            string first = ScheduleEnergyFull();
            _client.OpenedListener(7, first);

            string second = ScheduleEnergyFull();
            _client.OpenedListener(7, second);
            _client.OpenedListener(7, second);

            Assert.AreNotEqual(first, second);
            Assert.AreEqual(2, _opened.Count);
            Assert.AreEqual("energy_full", _opened[1].Key);
            Assert.AreEqual("screen=energy", _opened[1].Data);
        }

        [Test]
        public void NotificationFromElsewhereHasNoKey()
        {
            LocalNotificationOpened opened = LocalNotificationPayload.Unpack("plain");

            Assert.AreEqual(string.Empty, opened.Key);
            Assert.AreEqual("plain", opened.Data);

            opened = LocalNotificationPayload.Unpack("key\nvalue");
            Assert.AreEqual(string.Empty, opened.Key);
            Assert.AreEqual("key\nvalue", opened.Data);
        }

        [Test]
        public void DataMayContainLineBreaks()
        {
            LocalNotificationOpened opened = LocalNotificationPayload.Unpack(LocalNotificationPayload.Pack("1.1", "key", "a\nb"));

            Assert.AreEqual("key", opened.Key);
            Assert.AreEqual("a\nb", opened.Data);
        }

        [Test]
        public void SettingsNeedAChannelId()
        {
            Assert.Throws<ArgumentException>(() => new UnityLocalNotificationSettings(" ", "n", "d"));
            Assert.AreEqual("id", new UnityLocalNotificationSettings("id", null, null).AndroidChannelName);
        }

        private string ScheduleEnergyFull()
        {
            var notification = new LocalNotification("energy_full", "Full", "Come back", Now.AddMinutes(10), "screen=energy");
            Answer(done => _provider.Schedule(7, notification, done));
            return _client.LastPacked;
        }

        private static LocalNotificationResult Answer(Action<Action<LocalNotificationResult>> call)
        {
            LocalNotificationResult? result = null;
            call(value => result = value);
            Assert.IsTrue(result.HasValue, "No answer.");
            return result.Value;
        }

        private sealed class FakeClient : IUnityNotificationClient
        {
            public readonly List<string> Calls = new List<string>();
            public Action<int, string> OpenedListener;
            public bool Granted = true;
            public bool ThrowOnInitialize;
            public TimeSpan LastDelay;
            public string LastPacked;

            public void Initialize(UnityLocalNotificationSettings settings)
            {
                Calls.Add("Initialize:" + settings.AndroidChannelId);
                if (ThrowOnInitialize) throw new InvalidOperationException("AndroidChannel not provided");
            }

            public void ListenForOpened(Action<int, string> opened)
            {
                Calls.Add("ListenForOpened");
                OpenedListener = opened;
            }

            public void RequestPermission(Action<bool> answered) => answered(Granted);

            public void Schedule(int id, string title, string body, string packedData, TimeSpan delay, UnityLocalNotificationSettings settings)
            {
                Calls.Add("Schedule:" + id);
                LastDelay = delay;
                LastPacked = packedData;
            }

            public void Cancel(int id) => Calls.Add("Cancel:" + id);

            public void CancelAll() => Calls.Add("CancelAll");
        }
    }
}
