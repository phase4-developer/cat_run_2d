# Changelog

## 0.1.0-pre.1 - 2026-11-08

New package, per the local notification part of `Docs/PlatformPush/Design.md`.

- `UnityLocalNotificationProvider` implements `ILocalNotificationProvider` with the shared `NotificationCenter` API of Unity Mobile Notifications 2.4.0.
- Android channel, icons and foreground display come from `UnityLocalNotificationSettings`.
- A schedule stamp, the key and the data travel in the notification's data string. An opened notification is reported once per schedule, so a key scheduled again opens again.

Unity EditMode tests passed on 2026-11-08, and `Hosts/PushSdkValidationHost` compiled the iOS device code against the real SDK. Android device code, Player and device tests are NOT_RUN. See `Docs/PlatformPush/Report.md`.
