# JJEvol Platform Local Notifications Unity

Local validation candidate 0.1.0-pre.1. Unity Mobile Notifications provider for `com.jjevol.platform.localnotifications`, on Android and iOS.

The code is user-authored, confirmed by the user on 2026-11-08. No channel name, notification text or icon is included.

## Install

This package depends on Unity's `com.unity.mobile.notifications` 2.4.0, which the Package Manager installs with it. The assembly builds for the Editor, Android and iOS. A project that also targets another platform guards its start code:

```csharp
#if UNITY_ANDROID || UNITY_IOS
var settings = new UnityLocalNotificationSettings("game", channelName, channelDescription)
{
    AndroidSmallIcon = "icon_small",
};
LocalNotificationManager.SetProvider(new UnityLocalNotificationProvider(settings));
#endif
LocalNotificationManager.Initialize();
```

The Editor never calls the SDK. It logs each schedule and allows every request, so the game's notification flow runs in the Editor.

## Settings

| Value | Default | Note |
|---|---|---|
| Android channel ID | Required | The channel every notification uses. |
| Android channel name, description | The ID, empty | Shown in the Android system settings. |
| `AndroidSmallIcon`, `AndroidLargeIcon` | Empty | Resource IDs registered in **Project Settings > Mobile Notifications**. An empty small icon uses the app icon; an empty large icon shows none. |
| `ShowInForeground` | `true` | Shows the notification while the game is open. |

Icons and the Mobile Notifications project settings belong to the project.

## Behavior

A schedule first cancels the same number, then schedules it, so the same key replaces the earlier notification. A fire time less than one second away is moved to one second, because iOS needs a positive interval.

A stamp for the schedule, the key and the data travel in the SDK's single data string. An opened notification is read on start and on each resume. The SDK reports the last tapped one again after each resume, so the same schedule is reported only once. The stamp differs per schedule, so a key scheduled again with the same data opens again. A notification from elsewhere, with no key, is reported with an empty key and its data.

With push on iOS, keep remote notification registration off in the Mobile Notifications settings and leave it to the push provider. Check on a device that a tapped push reaches `PushManager`.

## Validation

Tests are in `Tests/Editor`. They use a fake client and need no device. Run them from `Hosts/PlatformPushValidationHost`. `Hosts/PushSdkValidationHost` compiles the iOS device code inside Unity; Android was compiled only outside Unity. See `Docs/PlatformPush/Report.md` for what has run. Real notifications on a device are NOT_RUN.
