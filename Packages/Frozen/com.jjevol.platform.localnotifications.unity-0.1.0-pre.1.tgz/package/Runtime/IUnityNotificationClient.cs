using System;

namespace PlatformLibrary.LocalNotifications.Unity
{
    /// <summary>The calls <see cref="UnityLocalNotificationProvider"/> makes on Unity Mobile Notifications. Tests replace it.</summary>
    internal interface IUnityNotificationClient
    {
        void Initialize(UnityLocalNotificationSettings settings);

        /// <summary>Reports the notification that opened the app, now and each time the app comes back.</summary>
        void ListenForOpened(Action<int, string> opened);

        /// <summary>Answers true when the player allows notifications. May answer on a later frame.</summary>
        void RequestPermission(Action<bool> answered);

        void Schedule(int id, string title, string body, string packedData, TimeSpan delay, UnityLocalNotificationSettings settings);

        void Cancel(int id);

        void CancelAll();
    }
}
