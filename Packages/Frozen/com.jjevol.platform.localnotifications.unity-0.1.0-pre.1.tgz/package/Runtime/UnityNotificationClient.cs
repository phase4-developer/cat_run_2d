using System;
using UnityEngine;
#if !UNITY_EDITOR
using System.Collections;
using Unity.Notifications;
#if UNITY_ANDROID
using Unity.Notifications.Android;
#endif
#endif

namespace PlatformLibrary.LocalNotifications.Unity
{
    /// <summary>
    /// The only type that touches Unity Mobile Notifications. The Editor logs instead and allows every request,
    /// so the game's notification flow runs in the Editor.
    /// </summary>
    internal sealed class UnityNotificationClient : IUnityNotificationClient
    {
#if UNITY_EDITOR
        public void Initialize(UnityLocalNotificationSettings settings)
        {
            Debug.Log("[UnityLocalNotificationProvider][Editor] initialize, channel " + settings.AndroidChannelId);
        }

        public void ListenForOpened(Action<int, string> opened)
        {
        }

        public void RequestPermission(Action<bool> answered) => answered(true);

        public void Schedule(int id, string title, string body, string packedData, TimeSpan delay, UnityLocalNotificationSettings settings)
        {
            Debug.Log($"[UnityLocalNotificationProvider][Editor] schedule {id} in {delay.TotalSeconds:0}s: {title}");
        }

        public void Cancel(int id) => Debug.Log("[UnityLocalNotificationProvider][Editor] cancel " + id);

        public void CancelAll() => Debug.Log("[UnityLocalNotificationProvider][Editor] cancel all");
#else
        private Runner _runner;
        private Action<int, string> _opened;

        public void Initialize(UnityLocalNotificationSettings settings)
        {
            NotificationCenterArgs args = NotificationCenterArgs.Default;
            args.PresentationOptions = NotificationPresentation.Alert | NotificationPresentation.Badge | NotificationPresentation.Sound;
            args.AndroidChannelId = settings.AndroidChannelId;
            args.AndroidChannelName = settings.AndroidChannelName;
            args.AndroidChannelDescription = settings.AndroidChannelDescription;
            NotificationCenter.Initialize(args);
        }

        public void ListenForOpened(Action<int, string> opened)
        {
            _opened = opened;
            Runner runner = GetRunner();
            runner.Resumed = () => runner.StartCoroutine(QueryOpened());
            runner.StartCoroutine(QueryOpened());
        }

        public void RequestPermission(Action<bool> answered)
        {
            GetRunner().StartCoroutine(WaitForPermission(NotificationCenter.RequestPermission(), answered));
        }

        public void Schedule(int id, string title, string body, string packedData, TimeSpan delay, UnityLocalNotificationSettings settings)
        {
            var notification = new Notification
            {
                Identifier = id,
                Title = title,
                Text = body,
                Data = packedData,
                ShowInForeground = settings.ShowInForeground,
            };

#if UNITY_ANDROID
            var android = (AndroidNotification)notification;
            android.FireTime = DateTime.Now + delay;
            if (!string.IsNullOrEmpty(settings.AndroidSmallIcon)) android.SmallIcon = settings.AndroidSmallIcon;
            if (!string.IsNullOrEmpty(settings.AndroidLargeIcon)) android.LargeIcon = settings.AndroidLargeIcon;
            AndroidNotificationCenter.SendNotificationWithExplicitID(android, settings.AndroidChannelId, id);
#else
            NotificationCenter.ScheduleNotification(notification, new NotificationIntervalSchedule(delay));
#endif
        }

        public void Cancel(int id) => NotificationCenter.CancelScheduledNotification(id);

        public void CancelAll() => NotificationCenter.CancelAllScheduledNotifications();

        private Runner GetRunner()
        {
            if (_runner != null) return _runner;
            var host = new GameObject(nameof(UnityLocalNotificationProvider));
            UnityEngine.Object.DontDestroyOnLoad(host);
            _runner = host.AddComponent<Runner>();
            return _runner;
        }

        private IEnumerator QueryOpened()
        {
            QueryLastRespondedNotificationOp query = NotificationCenter.QueryLastRespondedNotification();
            yield return query;
            if (query.State != QueryLastRespondedNotificationState.HaveRespondedNotification) yield break;

            Notification notification = query.Notification;
            _opened?.Invoke(notification.Identifier ?? 0, notification.Data);
        }

        private static IEnumerator WaitForPermission(NotificationsPermissionRequest request, Action<bool> answered)
        {
            yield return request;
            answered(request.Status == NotificationsPermissionStatus.Granted);
        }

        [AddComponentMenu("")]
        private sealed class Runner : MonoBehaviour
        {
            public Action Resumed;

            private void OnApplicationPause(bool paused)
            {
                if (!paused) Resumed?.Invoke();
            }
        }
#endif
    }
}
