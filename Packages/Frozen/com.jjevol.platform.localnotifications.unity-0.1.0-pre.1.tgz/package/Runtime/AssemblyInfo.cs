using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PlatformLibrary.LocalNotifications.Unity.Tests.Editor")]
