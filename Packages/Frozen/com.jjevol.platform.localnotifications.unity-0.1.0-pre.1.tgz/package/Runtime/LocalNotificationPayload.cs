namespace PlatformLibrary.LocalNotifications.Unity
{
    /// <summary>
    /// Puts a schedule stamp and the key next to the game's data in the SDK's single data string, so an opened
    /// notification can report its key and each schedule can be told apart. Neither the stamp nor the key contains a
    /// line break, so the first two separate the three parts. Data without both is from elsewhere and has no key.
    /// </summary>
    internal static class LocalNotificationPayload
    {
        private const char Separator = '\n';

        public static string Pack(string stamp, string key, string data) => stamp + Separator + key + Separator + (data ?? string.Empty);

        public static LocalNotificationOpened Unpack(string packed)
        {
            if (string.IsNullOrEmpty(packed)) return new LocalNotificationOpened(string.Empty, string.Empty);
            int first = packed.IndexOf(Separator);
            int second = first < 0 ? -1 : packed.IndexOf(Separator, first + 1);
            return second < 0
                ? new LocalNotificationOpened(string.Empty, packed)
                : new LocalNotificationOpened(packed.Substring(first + 1, second - first - 1), packed.Substring(second + 1));
        }
    }
}
