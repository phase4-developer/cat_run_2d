using System;
using System.Globalization;

namespace PlatformLibrary.LocalNotifications.Unity
{
    /// <summary>
    /// Unity Mobile Notifications for <see cref="LocalNotificationManager"/>, on Android and iOS.
    /// In the Editor it logs instead of showing notifications.
    /// </summary>
    public sealed class UnityLocalNotificationProvider : ILocalNotificationProvider
    {
        // iOS needs a positive interval and counts whole seconds.
        private static readonly TimeSpan MinimumDelay = TimeSpan.FromSeconds(1);

        private readonly UnityLocalNotificationSettings _settings;
        private readonly IUnityNotificationClient _client;
        private readonly Func<DateTime> _utcNow;
        private string _lastOpened;
        private int _scheduleCount;

        public UnityLocalNotificationProvider(UnityLocalNotificationSettings settings)
            : this(settings, new UnityNotificationClient(), () => DateTime.UtcNow)
        {
        }

        internal UnityLocalNotificationProvider(UnityLocalNotificationSettings settings, IUnityNotificationClient client, Func<DateTime> utcNow)
        {
            _settings = settings ?? throw new ArgumentNullException(nameof(settings));
            _client = client ?? throw new ArgumentNullException(nameof(client));
            _utcNow = utcNow ?? throw new ArgumentNullException(nameof(utcNow));
        }

        public event Action<LocalNotificationOpened> Opened;

        public void Initialize(Action<LocalNotificationResult> completed)
        {
            try
            {
                _client.Initialize(_settings);
                _client.ListenForOpened(OnOpened);
            }
            catch (Exception exception)
            {
                completed(Error(exception));
                return;
            }

            completed(LocalNotificationResult.Succeeded);
        }

        public void RequestPermission(Action<LocalNotificationResult> completed)
        {
            try
            {
                _client.RequestPermission(granted => completed(granted
                    ? LocalNotificationResult.Succeeded
                    : LocalNotificationResult.Failed(LocalNotificationFailure.PermissionDenied, 0, "DENIED")));
            }
            catch (Exception exception)
            {
                completed(Error(exception));
            }
        }

        public void Schedule(int id, LocalNotification notification, Action<LocalNotificationResult> completed)
        {
            TimeSpan delay = notification.FireTimeUtc - _utcNow();
            if (delay <= TimeSpan.Zero)
            {
                completed(LocalNotificationResult.Failed(LocalNotificationFailure.InvalidTime, 0, "FIRE_TIME_PASSED"));
                return;
            }

            if (delay < MinimumDelay) delay = MinimumDelay;

            try
            {
                _client.Cancel(id);
                _client.Schedule(id, notification.Title, notification.Body, LocalNotificationPayload.Pack(NextStamp(), notification.Key, notification.Data), delay, _settings);
            }
            catch (Exception exception)
            {
                completed(Error(exception));
                return;
            }

            completed(LocalNotificationResult.Succeeded);
        }

        public void Cancel(int id) => _client.Cancel(id);

        public void CancelAll() => _client.CancelAll();

        private void OnOpened(int id, string packedData)
        {
            // The SDK reports the same last notification again after each resume until another one is tapped.
            // The stamp in the data differs per schedule, so the same key scheduled again opens again.
            string seen = id + ":" + packedData;
            if (seen == _lastOpened) return;
            _lastOpened = seen;

            Opened?.Invoke(LocalNotificationPayload.Unpack(packedData));
        }

        private string NextStamp()
        {
            _scheduleCount++;
            return _utcNow().Ticks.ToString("x", CultureInfo.InvariantCulture) + "." + _scheduleCount.ToString(CultureInfo.InvariantCulture);
        }

        private static LocalNotificationResult Error(Exception exception)
        {
            return LocalNotificationResult.Failed(LocalNotificationFailure.ProviderError, 0, exception.GetType().Name + ": " + exception.Message);
        }
    }
}
