using System;

namespace PlatformLibrary.LocalNotifications.Unity
{
    /// <summary>
    /// The project's values for Unity Mobile Notifications. Channel text and icon names belong to the project.
    /// Icons are registered in Project Settings &gt; Mobile Notifications by the project.
    /// </summary>
    public sealed class UnityLocalNotificationSettings
    {
        /// <param name="androidChannelId">The Android channel every notification goes to. Required.</param>
        /// <param name="androidChannelName">Shown to the player in Android settings.</param>
        /// <param name="androidChannelDescription">Shown to the player in Android settings.</param>
        public UnityLocalNotificationSettings(string androidChannelId, string androidChannelName, string androidChannelDescription)
        {
            if (string.IsNullOrWhiteSpace(androidChannelId)) throw new ArgumentException("An Android channel id is required.", nameof(androidChannelId));
            AndroidChannelId = androidChannelId;
            AndroidChannelName = androidChannelName ?? androidChannelId;
            AndroidChannelDescription = androidChannelDescription ?? string.Empty;
        }

        public string AndroidChannelId { get; }
        public string AndroidChannelName { get; }
        public string AndroidChannelDescription { get; }

        /// <summary>Icon identifier from the Mobile Notifications settings. Empty uses the app icon.</summary>
        public string AndroidSmallIcon { get; set; } = string.Empty;

        /// <summary>Icon identifier from the Mobile Notifications settings. Empty shows none.</summary>
        public string AndroidLargeIcon { get; set; } = string.Empty;

        /// <summary>Show the notification while the game is in front.</summary>
        public bool ShowInForeground { get; set; } = true;
    }
}
