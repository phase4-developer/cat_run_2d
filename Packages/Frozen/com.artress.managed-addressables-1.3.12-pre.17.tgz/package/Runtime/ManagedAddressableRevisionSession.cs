using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.Initialization;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.ResourceManagement.Util;

namespace Artress.ManagedAddressables
{
    /// <summary>
    /// SDK composition for JSON revisions, called on Unity's main thread. The owned
    /// path receives the caller's already initialized Boot locator and preserves Boot/
    /// Localization consumers. It owns only its Revision locator/typed catalog data
    /// and scoped transform; game leases, instances and scenes remain caller-owned.
    /// Do not run SDK catalog updates concurrently.
    /// </summary>
    public sealed partial class ManagedAddressableRevisionSession
    {
        private sealed class CatalogLease
        {
            public ManagedAddressableRevision Revision;
            public AsyncOperationHandle<JsonContentCatalogData> Handle;
            public IResourceLocator Locator;
            public IList<IResourceLocation> Locations;
            public ManagedRevisionFiles Files;
            public JsonContentCatalogData Data;

            public void Release()
            {
                if (Handle.IsValid()) Addressables.Release(Handle);
                Handle = default;
                Data = null;
                Files = null;
            }
        }

        private static ManagedAddressableRevisionSession owner;
        private readonly int mainThreadId = Thread.CurrentThread.ManagedThreadId;
        private CatalogLease active;
        private CatalogLease prepared;
        private bool busy;
        private ManagedAddressableRevisionStorage ownedStorage;
        private IResourceLocator bootLocator;
        private bool ownedFlow;
        private bool revisionConsumersSuspended;
        private Func<IResourceLocation, string> previousTransform;
        private Func<IResourceLocation, string> ownedTransform;

        public ManagedRevisionState State { get; private set; } = ManagedRevisionState.Created;
        public ManagedAddressableRevision LastConfirmedRevision { get; private set; }
        public ManagedAddressableRevision ActiveRevision => active?.Revision;
        public ManagedAddressableRevision PreparedRevision => prepared?.Revision;
        public bool CanStartConsumers => !revisionConsumersSuspended && (State == ManagedRevisionState.Ready ||
            State == ManagedRevisionState.Preparing || State == ManagedRevisionState.Prepared);

        public ManagedAddressableRevisionSession() { }

        public ManagedAddressableRevisionSession(ManagedAddressableRevisionStorage storage)
        {
            ownedStorage = storage ?? throw new ArgumentNullException(nameof(storage));
        }

        private async Task<Exception> RevalidateFailedOpenAsync(ManagedRevisionFiles confirmedFiles, Exception original)
        {
            State = ManagedRevisionState.RecoveryRequired;
            revisionConsumersSuspended = true;
            // ReadConfirmed established this local metadata's trust. Include failures
            // before an active lease exists (e.g. SDK JSON parse failure). Never use an
            // untrusted/missing pointer as a fallback selection or fetch remote bytes.
            if (confirmedFiles == null) return original;
            try { await ownedStorage.VerifyAsync(confirmedFiles, true, CancellationToken.None); }
            catch (Exception verify) { return new AggregateException(original, verify); }
            return original;
        }

        /// <summary>
        /// Runs only in the loading boundary. Incomplete Revision cleanup leaves A's
        /// locator/pointer and prepared B unchanged; gameplay remains suspended until
        /// retry, ResumeCurrentRevision or Close. Success means B validation and pointer ACK completed. Resume
        /// gameplay only after this result; validation is not a game-entry callback.
        /// </summary>
        public async Task<ManagedRevisionResult> ApplyAsync(ManagedRevisionApplyCallbacks callbacks,
            CancellationToken cancellationToken = default)
        {
            EnterOperation();
            bool boundaryStarted = false, boundaryComplete = false, commitInvoked = false;
            CatalogLease previous = active, candidate = prepared;
            ManagedRevisionCommitOutcome? outcome = null;
            try
            {
                if (!ownedFlow) throw new InvalidOperationException("OwnedRevisionOpenRequired");
                RequireState(ManagedRevisionState.Prepared);
                if (callbacks == null) throw new ArgumentNullException(nameof(callbacks));
                cancellationToken.ThrowIfCancellationRequested();
                RequireOwnedRegistry();
                RequireOwnedNoConflicts(candidate, previous.Locator);
                RequireSupportedBundleNameAdapter();
                State = ManagedRevisionState.Applying;
                revisionConsumersSuspended = true;
                boundaryStarted = true;
                var boundary = await callbacks.StopRevisionConsumers(cancellationToken);
                if (boundary == null || !boundary.IsReady)
                {
                    State = ManagedRevisionState.Prepared;
                    return new ManagedRevisionResult(false, "RevisionBoundaryNotReady", false, false, 0, null, true);
                }
                boundaryComplete = true;
                cancellationToken.ThrowIfCancellationRequested();
                RequireOwnedRegistry();
                string[] remaining = await WaitForPreviousBundlesAsync(previous.Files, candidate.Files, cancellationToken);
                if (remaining.Length != 0)
                {
                    State = ManagedRevisionState.Prepared;
                    return new ManagedRevisionResult(remaining);
                }
                // The wait yields to the player loop; recheck object ownership before swapping.
                RequireOwnedRegistry();
                RequireOwnedNoConflicts(candidate, previous.Locator);
                Addressables.RemoveResourceLocator(previous.Locator);
                Addressables.AddResourceLocator(candidate.Locator);
                if (!await callbacks.ValidateRevision(candidate.Revision, cancellationToken))
                    throw new InvalidOperationException("CandidateLocalValidationFailed");
                if (!IsRegistered(bootLocator) || !IsRegistered(candidate.Locator) ||
                    !ReferenceEquals(Addressables.InternalIdTransformFunc, ownedTransform))
                    throw new InvalidOperationException("OwnedRevisionRegistryChangedDuringValidation");
                RequireOwnedNoConflicts(candidate, previous.Locator);
                cancellationToken.ThrowIfCancellationRequested();
                commitInvoked = true;
                var commit = await ownedStorage.CommitConfirmedAsync(candidate.Files, cancellationToken);
                outcome = commit.Outcome;
                if (outcome == ManagedRevisionCommitOutcome.Uncertain)
                {
                    State = ManagedRevisionState.RecoveryRequired;
                    Addressables.RemoveResourceLocator(candidate.Locator);
                    // Persisted A/B is unknown. Do not rewrite or re-enter A automatically.
                    return new ManagedRevisionResult(false, "ConfirmedPointerWriteUncertain:" + commit.Error,
                        recoveryRequired: true, commitOutcome: outcome);
                }
                if (outcome != ManagedRevisionCommitOutcome.Confirmed)
                    throw new InvalidOperationException("ConfirmedPointerUnchanged:" + commit.Error);

                // Cancellation cannot turn an acknowledged B into an A rollback.
                active = candidate;
                prepared = null;
                LastConfirmedRevision = candidate.Revision;
                previous.Release();
                State = ManagedRevisionState.Ready;
                revisionConsumersSuspended = false;
                return new ManagedRevisionResult(true, commitOutcome: outcome);
            }
            catch (Exception error)
            {
                if (outcome == ManagedRevisionCommitOutcome.Confirmed)
                    return FailAfterConfirmedCommit(candidate, error);
                if (commitInvoked && !outcome.HasValue)
                {
                    State = ManagedRevisionState.RecoveryRequired;
                    if (candidate != null) Addressables.RemoveResourceLocator(candidate.Locator);
                    return new ManagedRevisionResult(false, "ConfirmedPointerResultUnknown:" + Describe(error),
                        recoveryRequired: true, commitOutcome: ManagedRevisionCommitOutcome.Uncertain);
                }
                if (!boundaryComplete)
                {
                    if (boundaryStarted)
                    {
                        State = ManagedRevisionState.Prepared;
                        return new ManagedRevisionResult(false, Describe(error), false, false, 0, null, true);
                    }
                    return Failure(error);
                }
                State = ManagedRevisionState.RecoveryRequired;
                try
                {
                    RequireBoundary(await callbacks.StopRevisionConsumers(CancellationToken.None));
                    Addressables.RemoveResourceLocator(candidate.Locator);
                    Addressables.RemoveResourceLocator(previous.Locator);
                    await ownedStorage.VerifyAsync(previous.Files, true, CancellationToken.None);
                    if (!IsRegistered(bootLocator) || !ReferenceEquals(Addressables.InternalIdTransformFunc, ownedTransform))
                        throw new InvalidOperationException("BootOrTransformChangedDuringRecovery");
                    RequireOwnedNoConflicts(previous);
                    Addressables.AddResourceLocator(previous.Locator);
                    if (!await callbacks.ValidateRevision(previous.Revision, CancellationToken.None))
                        throw new InvalidOperationException("LastConfirmedReentryValidationFailed");
                    candidate.Release();
                    prepared = null;
                    active = previous;
                    State = ManagedRevisionState.Ready;
                    revisionConsumersSuspended = false;
                    return new ManagedRevisionResult(false, Describe(error), recovered: true, commitOutcome: outcome);
                }
                catch (Exception recovery)
                {
                    if (candidate != null) Addressables.RemoveResourceLocator(candidate.Locator);
                    if (previous != null) Addressables.RemoveResourceLocator(previous.Locator);
                    return new ManagedRevisionResult(false, Describe(error) + " | RecoveryFailed:" + Describe(recovery),
                        recoveryRequired: true, commitOutcome: outcome);
                }
            }
            finally { busy = false; }
        }

        // The official BundledAssetSchemaBuilder strips '.bundle' from options.BundleName;
        // actual Windows general/Mono names include it. Addressables 4.0.1 and 4.1.2 build
        // names, hashes and InternalIds with the same code (2026-11-10 source comparison);
        // the Revision Host chain checks every loaded Revision bundle name against that stem.
        // A remote Group bundle loads as sdkBundleName + ".bundle_" + a 32-character suffix
        // (2026-11-10 chain on 6000.3 with 4.0.1), so a loaded name matches the stem exactly
        // or the stem followed by '_'. The asmdef versionDefine is required even in a Player,
        // where the public Addressables.Version returns an empty string. A version outside
        // the checked closed range is refused; there is no heuristic fallback.
        private static void RequireSupportedBundleNameAdapter()
        {
#if !ARTRESS_ADDRESSABLES_REVISION_BUNDLE_NAMES
            throw new NotSupportedException("RevisionBundleNameAdapterRequiresAddressables4.0.1To4.1.2");
#endif
        }

        // R0 Windows Mono observed 2.1964ms/one frame after release. 100ms allows
        // scheduling headroom; a slower unload is deferred, never presumed complete.
        // This is an observation budget, not a worst-case/platform latency guarantee.
        private const int PreviousBundleUnloadWaitMilliseconds = 100;

        private static string[] PreviousExclusiveBundleNames(ManagedRevisionFiles previous, ManagedRevisionFiles candidate)
        {
            var nextHashes = new HashSet<string>(candidate.Publisher.bundles.Select(row => row.fileSha256), StringComparer.OrdinalIgnoreCase);
            return previous.Publisher.bundles.Where(row => !nextHashes.Contains(row.fileSha256))
                .Select(row => row.sdkBundleName + ".bundle").Distinct(StringComparer.Ordinal).OrderBy(name => name, StringComparer.Ordinal).ToArray();
        }

        private static bool IsLoadedNameOf(string loaded, string stem)
            => loaded != null && (string.Equals(loaded, stem, StringComparison.Ordinal)
                || loaded.Length > stem.Length + 1 && loaded.StartsWith(stem, StringComparison.Ordinal) && loaded[stem.Length] == '_');

        private static async Task<string[]> WaitForPreviousBundlesAsync(ManagedRevisionFiles previous,
            ManagedRevisionFiles candidate, CancellationToken token)
        {
            string[] names = PreviousExclusiveBundleNames(previous, candidate);
            if (names.Length == 0) return Array.Empty<string>();
            var clock = System.Diagnostics.Stopwatch.StartNew();
            while (true)
            {
                token.ThrowIfCancellationRequested();
                var remaining = AssetBundle.GetAllLoadedAssetBundles().Where(bundle => bundle != null && names.Any(stem => IsLoadedNameOf(bundle.name, stem)))
                    .Select(bundle => bundle.name).Distinct(StringComparer.Ordinal).OrderBy(name => name, StringComparer.Ordinal).ToArray();
                if (remaining.Length == 0 || clock.ElapsedMilliseconds >= PreviousBundleUnloadWaitMilliseconds) return remaining;
                await Task.Delay(10, token);
            }
        }

        private ManagedRevisionResult FailAfterConfirmedCommit(CatalogLease candidate, Exception error)
        {
            // B is already the persistent canonical revision. A cleanup/return error
            // cannot undo that ACK or route into the pre-commit A recovery branch.
            active = candidate;
            prepared = null;
            LastConfirmedRevision = candidate.Revision;
            revisionConsumersSuspended = true;
            State = ManagedRevisionState.RecoveryRequired;
            return new ManagedRevisionResult(false, "ConfirmedRevisionPostCommitFailure:" + Describe(error),
                recoveryRequired: true, commitOutcome: ManagedRevisionCommitOutcome.Confirmed);
        }


        /// <summary>Prepares verified owned files without exposing the candidate locator or using the SDK bundle cache.</summary>
        public Task<ManagedRevisionResult> PrepareAsync(ManagedAddressableRevision candidate,
            CancellationToken cancellationToken = default) => PrepareOwnedAsync(candidate, cancellationToken);

        /// <summary>
        /// Leaves a deferred boundary without replacing A, prepared B, or confirmation.
        /// The caller rebuilds any game state it already stopped. Boot is unchanged.
        /// </summary>
        public ManagedRevisionResult ResumeCurrentRevision()
        {
            EnterOperation();
            try
            {
                RequireState(ManagedRevisionState.Prepared);
                if (!revisionConsumersSuspended || active == null || prepared == null)
                    throw new InvalidOperationException("RevisionIsNotDeferred");
                RequireOwnedRegistry();
                if (IsRegistered(prepared.Locator)) throw new InvalidOperationException("PreparedRevisionAlreadyRegistered");
                revisionConsumersSuspended = false;
                return new ManagedRevisionResult(true);
            }
            catch (Exception error) { return Failure(error); }
            finally { busy = false; }
        }

        /// <summary>
        /// Repairs only the pointer's exact trusted publisher, while in Boot recovery.
        /// Does not write the pointer, register a locator, or resume consumers. After
        /// success Close, create a new Session, and open normally for typed validation.
        /// </summary>
        public async Task<ManagedRevisionResult> RepairConfirmedAsync(ManagedAddressableRevision trustedRevision,
            CancellationToken cancellationToken = default)
        {
            EnterOperation(); CatalogLease repair = null;
            try
            {
                RequireState(ManagedRevisionState.RecoveryRequired);
                if (!ownedFlow || ownedStorage == null) throw new InvalidOperationException("OwnedRevisionOpenRequired");
                if (active != null && IsRegistered(active.Locator) || prepared != null && IsRegistered(prepared.Locator))
                    throw new InvalidOperationException("RecoveryRevisionLocatorStillRegistered");
                var files = await ownedStorage.PrepareConfirmedRepairAsync(trustedRevision, cancellationToken);
                repair = await LoadOwnedCatalogAsync(files, true, cancellationToken);
                await ownedStorage.VerifyAsync(files, true, cancellationToken);
                ownedStorage.RequireRepairPointerUnchanged(files);
                return new ManagedRevisionResult(true, downloadedBytes: ownedStorage.LastDownloadedBytes);
            }
            catch (Exception error) { return new ManagedRevisionResult(false, error.ToString(), recoveryRequired: true); }
            finally { repair?.Release(); busy = false; }
        }

        public void DiscardPrepared()
        {
            EnterOperation();
            try
            {
                RequireState(ManagedRevisionState.Prepared);
                if (revisionConsumersSuspended) throw new InvalidOperationException("RevisionBoundaryPendingCannotDiscard");
                prepared.Release();
                prepared = null;
                State = ManagedRevisionState.Ready;
            }
            finally { busy = false; }
        }

        /// <summary>Drain only Revision consumers; Boot, Localization and foreign locators remain untouched.</summary>
        public Task<ManagedRevisionResult> CloseAsync(Func<CancellationToken, Task<ManagedRevisionBoundary>> stopConsumers)
            => CloseOwnedAsync(stopConsumers);

        private async Task<ManagedRevisionResult> PrepareOwnedAsync(ManagedAddressableRevision revision, CancellationToken token)
        {
            EnterOperation();
            CatalogLease candidate = null;
            try
            {
                RequireState(ManagedRevisionState.Ready);
                if (revision == null) throw new ArgumentNullException(nameof(revision));
                if (!revision.HasTrustedPublisher) throw new InvalidOperationException("TrustedPublisherRequired");
                if (applicationContext != null)
                {
                    if (revision.PackagedBundleRoot.Length != 0)
                        throw new InvalidOperationException("PackagedRevisionRequiresApplicationStartup");
                    var publisher = await ownedStorage.ReadPublisherAsync(revision, token);
                    applicationContext.RequireRemoteCandidate(publisher, active.Files.Publisher, applicationPublisher);
                }
                if (string.Equals(revision.ExpectedPublisherSha256, LastConfirmedRevision.ExpectedPublisherSha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("CandidateMustHaveADifferentPublisher");
                RequireOwnedRegistry();
                State = ManagedRevisionState.Preparing;
                var files = await ownedStorage.PrepareCatalogAsync(revision, token);
                candidate = await LoadOwnedCatalogAsync(files, true, token);
                RequireOwnedRegistry();
                RequireOwnedNoConflicts(candidate, active.Locator);
                prepared = candidate;
                candidate = null;
                State = ManagedRevisionState.Prepared;
                return new ManagedRevisionResult(true, downloadedBytes: ownedStorage.LastDownloadedBytes);
            }
            catch (Exception error)
            {
                if (State == ManagedRevisionState.Preparing) State = ManagedRevisionState.Ready;
                return new ManagedRevisionResult(false, error.ToString(),
                    recoveryRequired: State == ManagedRevisionState.RecoveryRequired);
            }
            finally { candidate?.Release(); busy = false; }
        }

        private async Task<ManagedRevisionResult> CloseOwnedAsync(Func<CancellationToken, Task<ManagedRevisionBoundary>> stopConsumers)
        {
            EnterOperation();
            try
            {
                if (State == ManagedRevisionState.Closed) return new ManagedRevisionResult(true);
                if (owner == this)
                {
                    revisionConsumersSuspended = true;
                    if (stopConsumers == null) throw new ArgumentNullException(nameof(stopConsumers));
                    RequireBoundary(await stopConsumers(CancellationToken.None));
                    if (active != null) Addressables.RemoveResourceLocator(active.Locator);
                    if (prepared != null) Addressables.RemoveResourceLocator(prepared.Locator);
                    if (ownedTransform != null && !ReferenceEquals(Addressables.InternalIdTransformFunc, ownedTransform))
                        throw new InvalidOperationException("RevisionTransformChangedOutsideSession");
                    if (ownedTransform != null) Addressables.InternalIdTransformFunc = previousTransform;
                    active?.Release();
                    prepared?.Release();
                    active = prepared = null;
                    bootLocator = null;
                    ownedTransform = previousTransform = null;
                    owner = null;
                }
                State = ManagedRevisionState.Closed;
                return new ManagedRevisionResult(true);
            }
            catch (Exception error) { State = ManagedRevisionState.RecoveryRequired; return Failure(error); }
            finally { busy = false; }
        }

        private async Task<CatalogLease> LoadOwnedCatalogAsync(ManagedRevisionFiles files, bool allowDownload, CancellationToken token)
        {
            // The SDK parses the stored catalog exactly once. Do not call the public
            // auto-registering catalog helper and then parse the same JSON again.
            var parseSource = new ManagedAddressableRevision(files.Revision.RevisionId,
                new Uri(Path.GetFullPath(files.CatalogLocalPath)).AbsoluteUri, files.Revision.ExpectedBuildResultHash);
            var lease = await LoadPrivateAsync(parseSource, token);
            try
            {
                lease.Revision = files.Revision;
                lease.Files = files;
                lease.Data = lease.Handle.Result;
                var bindings = new List<ManagedRevisionBundleBinding>();
                var seen = new HashSet<IResourceLocation>();
                var queue = new Queue<IResourceLocation>(lease.Locations);
                while (queue.Count != 0)
                {
                    var location = queue.Dequeue();
                    if (!seen.Add(location)) continue;
                    if (location.HasDependencies)
                        foreach (var dependency in location.Dependencies) queue.Enqueue(dependency);
                    if (!(location.Data is AssetBundleRequestOptions options)) continue;
                    string uri = CanonicalUri(Addressables.ResourceManager.TransformInternalId(location));
                    string name = Path.GetFileName(Uri.UnescapeDataString(new Uri(uri).AbsolutePath));
                    bool windowsFile = new Uri(uri).IsFile && (Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.WindowsEditor);
                    var matches = files.Publisher.bundles.Where(row => string.Equals(row.fileName, name,
                        windowsFile ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal) &&
                        row.sdkBundleName == options.BundleName && string.Equals(row.sdkHash, options.Hash, StringComparison.OrdinalIgnoreCase) &&
                        row.crc == options.Crc && (options.BundleSize == 0 || row.bytes == options.BundleSize)).ToArray();
                    if (matches.Length != 1) throw new InvalidOperationException("PublisherDoesNotMatchExactSdkBundle:" + name);
                    if (bindings.Any(binding => ReferenceEquals(binding.Bundle, matches[0])))
                        throw new InvalidOperationException("AmbiguousPublisherBundleLocation:" + name);
                    bindings.Add(new ManagedRevisionBundleBinding { Location = location, CanonicalUri = uri, Bundle = matches[0] });
                }
                if (bindings.Count != files.Publisher.bundles.Length)
                    throw new InvalidOperationException("PublisherDoesNotExactlyCoverSdkGraph");
                foreach (var binding in bindings)
                    foreach (var existing in active?.Files?.Bindings ?? Array.Empty<ManagedRevisionBundleBinding>())
                        if (string.Equals(binding.Bundle.fileSha256, existing.Bundle.fileSha256, StringComparison.OrdinalIgnoreCase) &&
                            (binding.Bundle.sdkBundleName != existing.Bundle.sdkBundleName ||
                             !string.Equals(binding.Bundle.sdkHash, existing.Bundle.sdkHash, StringComparison.OrdinalIgnoreCase) ||
                             binding.Bundle.crc != existing.Bundle.crc || binding.Bundle.bytes != existing.Bundle.bytes))
                            throw new InvalidOperationException("SameShaDifferentSdkIdentityUnverified");
                files.Bindings = await ownedStorage.PrepareBundlesAsync(files, bindings.ToArray(), allowDownload, token);
                // The locator, locations and typed catalog data stay strongly owned by
                // this lease. The SDK read operation itself no longer needs retention.
                Addressables.Release(lease.Handle);
                lease.Handle = default;
                return lease;
            }
            catch { lease.Release(); throw; }
        }

        private void InstallOwnedTransform()
        {
            if (ownedTransform != null) return;
            previousTransform = Addressables.InternalIdTransformFunc;
            ownedTransform = location =>
            {
                string prior = previousTransform == null ? location.InternalId : previousTransform(location);
                foreach (var lease in new[] { active, prepared })
                {
                    if (lease?.Files?.Bindings == null) continue;
                    foreach (var binding in lease.Files.Bindings)
                    {
                        if (!ReferenceEquals(location, binding.Location)) continue;
                        if (!string.Equals(CanonicalUri(prior), binding.CanonicalUri, StringComparison.Ordinal))
                            throw new InvalidOperationException("RevisionTransformInputChanged");
                        if (string.IsNullOrEmpty(binding.LocalPath) || !File.Exists(binding.LocalPath) ||
                            new FileInfo(binding.LocalPath).Length != binding.Bundle.bytes)
                            throw new IOException("OwnedRevisionBundleMissingOrChangedNoRemoteFallback:" + binding.Bundle.fileName);
                        return binding.LocalPath;
                    }
                }
                return prior;
            };
            Addressables.InternalIdTransformFunc = ownedTransform;
        }

        private static string CanonicalUri(string value)
        {
            string evaluated = AddressablesRuntimeProperties.EvaluateString(value);
            var uri = new Uri(evaluated, UriKind.Absolute);
            if (!uri.IsFile) return uri.AbsoluteUri;
            string file = new Uri(Path.GetFullPath(uri.LocalPath)).AbsoluteUri;
            return Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.WindowsEditor
                ? file.ToUpperInvariant() : file;
        }

        private static bool IsRegistered(IResourceLocator locator) => Addressables.ResourceLocators.Any(item => ReferenceEquals(item, locator));

        private void RequireOwnedNoConflicts(CatalogLease revision, params IResourceLocator[] excluded)
        {
            // Boot's address/GUID/Locale separation is checked by the split producer.
            // Common labels do not invalidate Boot. Unknown locators remain untouched
            // and enumerated key overlap is rejected. SDK dynamic/subasset keys that
            // are absent from Keys are outside this enumeration's observation range.
            var keys = new HashSet<object>(revision.Locator.Keys ?? Array.Empty<object>());
            foreach (var locator in Addressables.ResourceLocators)
            {
                if (ReferenceEquals(locator, bootLocator) || ReferenceEquals(locator, revision.Locator) ||
                    excluded.Any(item => ReferenceEquals(item, locator))) continue;
                if ((locator.Keys ?? Array.Empty<object>()).Any(keys.Contains))
                    throw new InvalidOperationException("RevisionKeyConflictsWithUnownedLocator:" + locator.LocatorId);
            }
        }

        private void RequireOwnedRegistry()
        {
            if (active == null || !IsRegistered(active.Locator) || !IsRegistered(bootLocator) ||
                !ReferenceEquals(Addressables.InternalIdTransformFunc, ownedTransform))
            {
                State = ManagedRevisionState.RecoveryRequired;
                throw new InvalidOperationException("OwnedRevisionRegistryChangedOutsideSession");
            }
            RequireOwnedNoConflicts(active);
        }

        private static async Task<CatalogLease> LoadPrivateAsync(ManagedAddressableRevision revision, CancellationToken token)
        {
            // Use the same public inner provider as JsonCatalogProvider. The outer
            // ContentCatalogProvider assumes hash dependencies in its failure path.
            // This SDK provider reads/parses the exact source without catalog-cache
            // selection, provider registration, or an application catalog parser.
            token.ThrowIfCancellationRequested();
            var location = new ResourceLocationBase(revision.CatalogPath, revision.CatalogPath,
                typeof(JsonAssetProvider).FullName, typeof(JsonContentCatalogData));
            var handle = Addressables.ResourceManager.ProvideResource<JsonContentCatalogData>(location);
            var lease = new CatalogLease { Revision = revision, Handle = handle };
            try
            {
                await CompleteAsync(handle, token);
                var data = handle.Result;
                if (data == null) throw new InvalidOperationException("SdkJsonCatalogRequired");
                if (revision.ExpectedBuildResultHash.Length != 0 &&
                    !string.Equals(revision.ExpectedBuildResultHash, data.BuildResultHash, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("CatalogBuildResultHashMismatch");
                lease.Locator = data.CreateLocator();
                lease.Locations = lease.Locator.AllLocations.Distinct().ToArray();
                if (lease.Locations.Count == 0) throw new InvalidOperationException("RevisionCatalogEmpty");
                ValidateLocations(lease.Locations);
                return lease;
            }
            catch
            {
                lease.Release();
                throw;
            }
        }

        private static void ValidateLocations(IList<IResourceLocation> locations)
        {
            var queue = new Queue<IResourceLocation>(locations);
            var visited = new HashSet<IResourceLocation>();
            while (queue.Count != 0)
            {
                var location = queue.Dequeue();
                if (!visited.Add(location)) continue;
                if (Addressables.ResourceManager.GetResourceProvider(location.ResourceType, location) == null)
                    throw new InvalidOperationException("RevisionProviderMissing:" + location.ProviderId);
                if (location.HasDependencies)
                    foreach (var dependency in location.Dependencies) queue.Enqueue(dependency);
            }
        }

        private static void RequireBoundary(ManagedRevisionBoundary boundary)
        {
            if (boundary == null || !boundary.IsReady) throw new InvalidOperationException("ConsumerBoundaryNotReady");
        }

        private void RequireState(ManagedRevisionState expected)
        {
            if (State != expected || owner != this) throw new InvalidOperationException("RevisionStateInvalid:" + State);
        }

        private void EnterOperation()
        {
            if (Thread.CurrentThread.ManagedThreadId != mainThreadId) throw new InvalidOperationException("UnityMainThreadRequired");
            if (busy) throw new InvalidOperationException("RevisionOperationAlreadyInProgress");
            busy = true;
        }

        private static async Task CompleteAsync(AsyncOperationHandle handle, CancellationToken token)
        {
            if (!handle.IsValid()) throw new InvalidOperationException("SdkOperationHandleInvalid");
            // Release is not cancellation. Drain before returning a cancellation result
            // so no session-owned request can race the next cleanup/activation boundary.
            while (!handle.IsDone) await Task.Yield();
            token.ThrowIfCancellationRequested();
            if (handle.Status != AsyncOperationStatus.Succeeded)
                throw new InvalidOperationException("SdkOperationFailed", handle.OperationException);
        }

        private ManagedRevisionResult Failure(Exception ex) => new ManagedRevisionResult(false,
            Describe(ex), recoveryRequired: State == ManagedRevisionState.RecoveryRequired);

        private void LogStartupCleanupWarning()
        {
            if (!string.IsNullOrEmpty(ownedStorage.LastCleanupWarning))
                Debug.LogWarning("Managed Revision startup cleanup: " + ownedStorage.LastCleanupWarning);
        }

        private static string Describe(Exception ex) => ex.GetType().Name + ":" + ex.Message;
    }
}
