using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

namespace Artress.ManagedAddressables
{
    public sealed partial class ManagedAddressableRevisionStorage
    {
        private static string RuntimeTarget()
        {
            switch (Application.platform)
            {
                case RuntimePlatform.WindowsEditor:
                case RuntimePlatform.WindowsPlayer: return "StandaloneWindows64";
                case RuntimePlatform.Android: return "Android";
                case RuntimePlatform.IPhonePlayer: return "iOS";
                default: throw new PlatformNotSupportedException("Owned Revision storage has not been validated for " + Application.platform);
            }
        }

        private static string ApplicationStorageBase()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
            using (var context = activity.Call<AndroidJavaObject>("getApplicationContext"))
            using (var directory = context.Call<AndroidJavaObject>("getFilesDir"))
                return directory.Call<string>("getAbsolutePath");
#elif UNITY_IOS && !UNITY_EDITOR
            IntPtr value = ManagedRevisionApplicationSupportPath();
            if (value == IntPtr.Zero) throw new IOException("iOS Application Support could not be obtained.");
            try
            {
                int length = 0;
                while (Marshal.ReadByte(value, length) != 0) length++;
                var bytes = new byte[length]; Marshal.Copy(value, bytes, 0, length);
                return Encoding.UTF8.GetString(bytes);
            }
            finally { ManagedRevisionFreePath(value); }
#else
            if (Application.platform != RuntimePlatform.WindowsEditor && Application.platform != RuntimePlatform.WindowsPlayer)
                throw new PlatformNotSupportedException("A native owned-storage path is required on this platform.");
            return Application.persistentDataPath;
#endif
        }

        private static void ExcludeFromBackup(string path)
        {
#if UNITY_IOS && !UNITY_EDITOR
            // Unity uses NSURLIsExcludedFromBackupKey. Apply again after each new file write.
            UnityEngine.iOS.Device.SetNoBackupFlag(path);
#endif
        }

        private long AvailableSpace()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            using (var directory = new AndroidJavaObject("java.io.File", root)) return directory.Call<long>("getUsableSpace");
#else
            // Use the owned path, not '/' on mobile systems with a separate data volume.
            return new DriveInfo(root).AvailableFreeSpace;
#endif
        }

        private static void RejectReparse(string path)
        {
            if ((File.Exists(path) || Directory.Exists(path)) && (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Owned Revision paths cannot be symbolic links/reparse points: " + path);
        }

#if UNITY_IOS && !UNITY_EDITOR
        [DllImport("__Internal")] private static extern IntPtr ManagedRevisionApplicationSupportPath();
        [DllImport("__Internal")] private static extern void ManagedRevisionFreePath(IntPtr value);
#endif
    }
}
