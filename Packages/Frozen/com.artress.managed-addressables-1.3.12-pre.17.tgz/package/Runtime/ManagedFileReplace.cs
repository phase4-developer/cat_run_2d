using System;
using System.IO;
using System.Threading;

namespace Artress.ManagedAddressables
{
    /// <summary>
    /// Atomic file replacement that survives a brief hold on the destination. On Windows,
    /// <see cref="File.Replace(string, string, string)"/> fails with "unable to remove the
    /// file to be replaced" while another process (an indexer, antivirus, the Editor's file
    /// watcher) still has the destination open. Nothing has changed at that point, so the
    /// same replacement is tried again. A retry happens only while both the source and the
    /// destination still exist, which rules out the cases where Windows already moved the
    /// destination away.
    /// </summary>
    internal static class ManagedFileReplace
    {
        internal const int Attempts = 10;
        private const int DelayStepMilliseconds = 25;

        internal static void Replace(string source, string destination)
        {
            for (int attempt = 1; ; attempt++)
            {
                try { File.Replace(source, destination, null); return; }
                catch (IOException) when (CanRetry(attempt, source, destination)) { }
                catch (UnauthorizedAccessException) when (CanRetry(attempt, source, destination)) { }
                Thread.Sleep(DelayStepMilliseconds * attempt);
            }
        }

        // Replaces an existing destination, or moves the source into place when there is none.
        internal static void ReplaceOrMove(string source, string destination)
        {
            if (File.Exists(destination)) Replace(source, destination);
            else File.Move(source, destination);
        }

        private static bool CanRetry(int attempt, string source, string destination) =>
            attempt < Attempts && File.Exists(source) && File.Exists(destination);
    }
}
