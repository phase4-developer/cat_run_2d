#import <Foundation/Foundation.h>
#include <stdlib.h>
#include <string.h>

// The caller owns the returned UTF-8 allocation and must release it with ManagedRevisionFreePath.
extern "C" char* ManagedRevisionApplicationSupportPath()
{
    @autoreleasepool
    {
        NSError* error = nil;
        NSURL* directory = [[NSFileManager defaultManager] URLForDirectory:NSApplicationSupportDirectory
            inDomain:NSUserDomainMask appropriateForURL:nil create:YES error:&error];
        if (directory == nil || error != nil) return nullptr;
        const char* value = directory.path.UTF8String;
        return value == nullptr ? nullptr : strdup(value);
    }
}

extern "C" void ManagedRevisionFreePath(char* value) { free(value); }
