﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace Artress.ManagedAddressables
{
    /// <summary>
    /// App-owned immutable Revision files. Session supplies the official SDK graph; this class
    /// neither parses Catalogs nor owns SDK locators/handles. Construct on Unity's main thread.
    /// This store is separate from the SDK bundle cache.
    /// </summary>
    public sealed partial class ManagedAddressableRevisionStorage
    {
        private readonly string root;
        private readonly string target;
        private readonly int retries;
        private readonly int stallTimeout;
        private byte[] confirmedPointer;
        private bool busy;
        private readonly Dictionary<string, ManagedRevisionFiles> known = new Dictionary<string, ManagedRevisionFiles>(StringComparer.OrdinalIgnoreCase);
        internal string RootDirectory => root;
        internal string Target => target;
        internal long LastDownloadedBytes { get; private set; }
        internal long LastReusedBytes { get; private set; }
        internal long LastCopiedBytes { get; private set; }
        internal int LastBundleShaChecks { get; private set; }
        internal int LastCatalogShaChecks { get; private set; }
        internal string LastCleanupWarning { get; private set; } = string.Empty;
        private string PointerPath => Path.Combine(root, "confirmed.json");

        public ManagedAddressableRevisionStorage(string storageName = "ManagedRevisions", int retryCount = 2, int stallTimeoutSeconds = 30)
        {
            if (string.IsNullOrWhiteSpace(storageName) || storageName.Length > 80 || !storageName.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_'))
                throw new ArgumentException("A single owned storage namespace is required; absolute/relative paths are not accepted.", nameof(storageName));
            if (retryCount < 0 || stallTimeoutSeconds < 0) throw new ArgumentOutOfRangeException(nameof(retryCount));
            target = RuntimeTarget(); retries = retryCount; stallTimeout = stallTimeoutSeconds;
            string app = Path.GetFullPath(ApplicationStorageBase()).TrimEnd('/', '\\');
            root = Path.GetFullPath(Path.Combine(app, "Artress.ManagedAddressables", storageName));
            Require(root.StartsWith(app + Path.DirectorySeparatorChar, StringComparison.Ordinal), "OwnedStorageEscapedApplication");
            if (Path.IsPathRooted(Application.streamingAssetsPath))
                Require(!root.StartsWith(Path.GetFullPath(Application.streamingAssetsPath).TrimEnd('/', '\\') + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase), "StreamingAssetsIsNeverOwnedCleanup");
            RejectReparse(Path.Combine(app, "Artress.ManagedAddressables")); EnsureDirectories();
        }

        internal Task<ManagedRevisionFiles> ReadConfirmedAsync(CancellationToken token)
            => ReadConfirmedPointerAsync(token, false);

        // Startup chooses from trusted metadata before considering file availability.
        // Missing B files must never be interpreted as permission to select packaged A.
        internal Task<ManagedRevisionFiles> ReadConfirmedMetadataAsync(CancellationToken token)
            => ReadConfirmedPointerAsync(token, true);

        private async Task<ManagedRevisionFiles> ReadConfirmedPointerAsync(CancellationToken token, bool metadataOnly)
        {
            Enter();
            try
            {
                LastBundleShaChecks = 0;
                LastCatalogShaChecks = 0;
                LastCleanupWarning = string.Empty;
                token.ThrowIfCancellationRequested(); RejectReparse(PointerPath);
                if (File.Exists(PointerPath)) RemoveInitialInstallMarker();
                if (!File.Exists(PointerPath))
                {
                    if (metadataOnly) { confirmedPointer = null; return null; }
                    throw new FileNotFoundException("ConfirmedRevisionPointerMissing: remain in Boot recovery; no automatic A fallback.", PointerPath);
                }
                var pointer = ReadPointerIfPresent(out byte[] bytes);
                var files = await ReadMetadataAsync(pointer.publisherSha256, pointer.revisionId, token, metadataOnly: metadataOnly);
                Require(SameSha(pointer.catalogSha256, files.Publisher.catalogSha256), "ConfirmedPointerCatalogMismatch");
                files.ConfirmedPointerSha256 = Sha(bytes);
                if (!metadataOnly) VerifyFilesLight(files, token);
                confirmedPointer = bytes;
                return files;
            }
            finally { busy = false; }
        }

        internal Task<ManagedRevisionFiles> PrepareCatalogAsync(ManagedAddressableRevision revision, CancellationToken token)
            => PrepareCatalogCoreAsync(revision, false, token);

        internal Task<ManagedRevisionFiles> PrepareConfirmedRepairAsync(ManagedAddressableRevision revision, CancellationToken token)
            => PrepareCatalogCoreAsync(revision, true, token);

        private async Task<ManagedRevisionFiles> PrepareCatalogCoreAsync(ManagedAddressableRevision revision, bool repair, CancellationToken token)
        {
            Enter(); string publisherTemp = null, catalogTemp = null;
            try
            {
                Require(revision != null && !string.IsNullOrWhiteSpace(revision.PublisherPath) && IsSha(revision.ExpectedPublisherSha256) && revision.Target == target, "TrustedRevisionPublisherAnchorRequired");
                ValidatePackagedSources(revision);
                token.ThrowIfCancellationRequested();
                var pointer = ReadPointerIfPresent(out byte[] pointerBytes);
                bool confirmedMetadata = pointer != null && SameSha(pointer.publisherSha256, revision.ExpectedPublisherSha256);
                if (repair)
                    Require(confirmedMetadata && pointer.revisionId == revision.RevisionId, "RepairMustMatchConfirmedPublisher");
                string directory = MetadataDirectory(revision.ExpectedPublisherSha256); RejectReparse(directory);
                if (File.Exists(Path.Combine(directory, "publisher.json")) && File.Exists(Path.Combine(directory, "catalog.json")))
                {
                    try
                    {
                        var existing = await ReadVerifiedMetadataAsync(revision.ExpectedPublisherSha256, revision.RevisionId, token, revision, true);
                        existing.RepairConfirmed = repair;
                        if (repair) existing.ConfirmedPointerSha256 = Sha(pointerBytes);
                        return existing;
                    }
                    catch (Exception error) when (error is IOException || error is InvalidDataException || error is ArgumentException)
                    { if (confirmedMetadata && !repair) throw; }
                }
                Require(!confirmedMetadata || repair, "ConfirmedMetadataRequiresRepair");
                EnsureSpace(4096); publisherTemp = NewTemporary();
                string storedPublisher = Path.Combine(directory, "publisher.json");
                byte[] publisherBytes;
                if (File.Exists(storedPublisher) && SameSha(await ShaFileAsync(storedPublisher, token), revision.ExpectedPublisherSha256))
                    publisherBytes = File.ReadAllBytes(storedPublisher);
                else
                {
                    await ReceiveAsync(revision.PublisherPath, publisherTemp, revision.ExpectedPublisherSha256, 0, token);
                    publisherBytes = File.ReadAllBytes(publisherTemp);
                }
                var publisher = ParsePublisher(publisherBytes, revision.RevisionId);
                if (repair) Require(SameSha(pointer.catalogSha256, publisher.catalogSha256), "RepairCatalogMustMatchConfirmedPointer");
                long bundleBytes = 0;
                foreach (var row in publisher.bundles) if (!ExistsAtSize(BlobPath(row.fileSha256), row.bytes)) bundleBytes = checked(bundleBytes + row.bytes);
                EnsureSpace(checked(bundleBytes * 2 + publisher.catalogBytes * 2 + publisherBytes.LongLength));
                catalogTemp = NewTemporary();
                string storedCatalog = Path.Combine(directory, "catalog.json");
                byte[] catalogBytes;
                if (File.Exists(storedCatalog) && SameSha(await ShaFileAsync(storedCatalog, token), publisher.catalogSha256))
                    catalogBytes = File.ReadAllBytes(storedCatalog);
                else
                {
                    await ReceiveAsync(revision.CatalogPath, catalogTemp, publisher.catalogSha256, publisher.catalogBytes, token);
                    catalogBytes = File.ReadAllBytes(catalogTemp);
                }
                token.ThrowIfCancellationRequested();
                if (repair) Require(Equal(pointerBytes, File.ReadAllBytes(PointerPath)), "RepairConfirmationChanged");
                // Publisher first, so every Catalog on disk has readable metadata. An interruption
                // here leaves a partial candidate that startup cleanup understands.
                await WriteMetadataAsync(storedPublisher, publisherBytes, repair, token);
                await WriteMetadataAsync(storedCatalog, catalogBytes, repair, token);
                var files = await ReadVerifiedMetadataAsync(revision.ExpectedPublisherSha256, revision.RevisionId, token, revision, true);
                files.RepairConfirmed = repair;
                if (repair) { files.ConfirmedPointerSha256 = Sha(pointerBytes); RequireRepairPointerUnchanged(files); }
                return files;
            }
            finally { try { DeleteTemporary(publisherTemp); DeleteTemporary(catalogTemp); } finally { busy = false; } }
        }

        internal async Task<ManagedRevisionBundleBinding[]> PrepareBundlesAsync(ManagedRevisionFiles files,
            ManagedRevisionBundleBinding[] bindings, bool allowDownload, CancellationToken token)
        {
            Enter();
            try
            {
                await ValidateMetadataAsync(files, token, allowDownload); ValidateBindings(files, bindings);
                if (files.RepairConfirmed) RequireRepairPointerUnchanged(files);
                LastDownloadedBytes = 0; LastReusedBytes = 0; LastCopiedBytes = 0; LastBundleShaChecks = 0;
                if (allowDownload)
                {
                    long missing = 0;
                    foreach (var binding in bindings) if (!ExistsAtSize(BlobPath(binding.Bundle.fileSha256), binding.Bundle.bytes)) missing = checked(missing + binding.Bundle.bytes);
                    EnsureSpace(checked(missing * 2 + new FileInfo(files.CatalogLocalPath).Length + 4096));
                }
                foreach (var binding in bindings)
                {
                    token.ThrowIfCancellationRequested(); var row = binding.Bundle; string path = BlobPath(row.fileSha256);
                    binding.LocalPath = path;
                    if (!allowDownload) { Require(ExistsAtSize(path, row.bytes), "ConfirmedRequiredBundleMissingOrWrongSize: " + row.fileName); continue; }
                    var sameSha = known.Values.SelectMany(f => f.Publisher.bundles).Where(b => SameSha(b.fileSha256, row.fileSha256));
                    Require(sameSha.All(other => other.bytes == row.bytes && other.sdkBundleName == row.sdkBundleName && SameSha(other.sdkHash, row.sdkHash) && other.crc == row.crc), "SameShaDifferentSdkIdentity");
                    if (File.Exists(path))
                    {
                        if (await VerifyBlobAsync(row, true, token))
                        { LastReusedBytes = checked(LastReusedBytes + row.bytes); continue; }
                        Require(files.RepairConfirmed || !await ConfirmedReferencesBlobAsync(row.fileSha256, token), "ConfirmedBundleRequiresRepair: " + row.fileName);
                    }
                    string temporary = NewTemporary();
                    try
                    {
                        string source = string.IsNullOrEmpty(files.Revision.PackagedBundleRoot) ? binding.CanonicalUri :
                            PackagedBundleSource(files.Revision.PackagedBundleRoot, row.fileName);
                        await ReceiveAsync(source, temporary, row.fileSha256, row.bytes, token);
                        LastBundleShaChecks++;
                        token.ThrowIfCancellationRequested();
                        if (files.RepairConfirmed) RequireRepairPointerUnchanged(files);
                        else if (File.Exists(path)) Require(!await ConfirmedReferencesBlobAsync(row.fileSha256, token), "ConfirmedBundleRequiresRepair: " + row.fileName);
                        ManagedFileReplace.ReplaceOrMove(temporary, path);
                        ExcludeFromBackup(path);
                        Require(ExistsAtSize(path, row.bytes), "ImmutableBundlePlacementIncomplete");
                        if (Uri.TryCreate(source, UriKind.Absolute, out var uri) && (uri.Scheme == "http" || uri.Scheme == "https")) LastDownloadedBytes = checked(LastDownloadedBytes + row.bytes);
                        else LastCopiedBytes = checked(LastCopiedBytes + row.bytes);
                    }
                    finally { DeleteTemporary(temporary); }
                }
                files.Bindings = bindings;
                return bindings;
            }
            finally { busy = false; }
        }

        internal async Task VerifyAsync(ManagedRevisionFiles files, bool fullSha, CancellationToken token)
        {
            Enter();
            try { await ValidateMetadataAsync(files, token, fullSha); await VerifyFilesAsync(files, fullSha, token); }
            finally { busy = false; }
        }

        internal async Task<ManagedRevisionCommitResult> CommitConfirmedAsync(ManagedRevisionFiles files, CancellationToken token)
        {
            Enter(); string temporary = null;
            try
            {
                await ValidateMetadataAsync(files, token, true);
                ValidateBindings(files, files.Bindings); await VerifyFilesAsync(files, true, token);
                token.ThrowIfCancellationRequested(); RejectReparse(PointerPath);
                byte[] previous;
                try { previous = File.Exists(PointerPath) ? File.ReadAllBytes(PointerPath) : null; }
                catch (Exception error) { return new ManagedRevisionCommitResult { Outcome = ManagedRevisionCommitOutcome.Uncertain, Error = "ConfirmedPointerUnreadable: " + error }; }
                if (!Equal(previous, confirmedPointer)) return new ManagedRevisionCommitResult { Outcome = ManagedRevisionCommitOutcome.Uncertain, Error = "ConfirmedPointerChangedOutsideSession" };
                var pointer = new Pointer { schemaVersion = 1, target = target, revisionId = files.Revision.RevisionId, publisherSha256 = files.PublisherSha256, catalogSha256 = files.Publisher.catalogSha256 };
                byte[] desired = Encoding.UTF8.GetBytes(JsonUtility.ToJson(pointer));
                temporary = NewTemporary(); WriteImmutable(temporary, desired); token.ThrowIfCancellationRequested();
                if (previous == null) MarkInitialInstallCommitStarted(files.PublisherSha256);
                try
                {
                    if (previous == null) File.Move(temporary, PointerPath); else ManagedFileReplace.Replace(temporary, PointerPath);
                    ExcludeFromBackup(PointerPath);
                    // After replacement starts, cancellation must not skip the exact ACK readback.
                    byte[] actual = File.ReadAllBytes(PointerPath);
                    Require(Equal(actual, desired), "ConfirmedPointerReadbackMismatch");
                    confirmedPointer = actual;
                    RemoveInitialInstallMarker();
                    return new ManagedRevisionCommitResult { Outcome = ManagedRevisionCommitOutcome.Confirmed, Error = string.Empty };
                }
                catch (Exception error)
                {
                    byte[] actual;
                    try { RejectReparse(PointerPath); actual = File.Exists(PointerPath) ? File.ReadAllBytes(PointerPath) : null; }
                    catch { return new ManagedRevisionCommitResult { Outcome = ManagedRevisionCommitOutcome.Uncertain, Error = error.ToString() }; }
                    // Desired bytes after an API error are not promoted to a new ACK. No rewrite/rollback.
                    var outcome = Equal(actual, previous) ? ManagedRevisionCommitOutcome.Unchanged : ManagedRevisionCommitOutcome.Uncertain;
                    return new ManagedRevisionCommitResult { Outcome = outcome, Error = error.ToString() };
                }
            }
            catch (Exception error)
            {
                // A pre-write verification/cancellation failure may re-enter A only when the
                // exact previously observed pointer remains readable. Never manufacture an ACK.
                try
                {
                    RejectReparse(PointerPath);
                    byte[] actual = File.Exists(PointerPath) ? File.ReadAllBytes(PointerPath) : null;
                    return new ManagedRevisionCommitResult { Outcome = Equal(actual, confirmedPointer) ? ManagedRevisionCommitOutcome.Unchanged : ManagedRevisionCommitOutcome.Uncertain, Error = error.ToString() };
                }
                catch { return new ManagedRevisionCommitResult { Outcome = ManagedRevisionCommitOutcome.Uncertain, Error = error.ToString() }; }
            }
            finally
            {
                try { DeleteTemporary(temporary); }
                catch (Exception error) { LastCleanupWarning = "Commit temporary cleanup: " + error.Message; }
                finally { busy = false; }
            }
        }

        // Session calls only before registering a Revision or starting consumers. No playing-time GC.
        internal async Task CleanupApplicationStartupAsync(ManagedRevisionFiles confirmed, IEnumerable<string> preservePublisherSha, CancellationToken token)
        {
            Enter();
            LastCleanupWarning = LastCleanupWarning.StartsWith("Initial install marker cleanup:", StringComparison.Ordinal) ? LastCleanupWarning : string.Empty;
            try
            {
                await ValidateMetadataAsync(confirmed, token); VerifyFilesLight(confirmed, token);
                var metadataKeep = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { confirmed.PublisherSha256 };
                var keep = new HashSet<string>(confirmed.Publisher.bundles.Select(b => b.fileSha256), StringComparer.OrdinalIgnoreCase);
                foreach (string sha in preservePublisherSha ?? Array.Empty<string>())
                {
                    var retained = await ReadMetadataAsync(sha, null, token); VerifyFilesLight(retained, token);
                    metadataKeep.Add(retained.PublisherSha256);
                    foreach (var bundle in retained.Publisher.bundles) keep.Add(bundle.fileSha256);
                }
                string revisions = Path.Combine(root, "revisions"); RejectReparse(revisions);
                Require(!Directory.EnumerateFiles(revisions).Any(), "AmbiguousRevisionMetadataCleanupSkipped");
                var metadata = new List<ManagedRevisionFiles>();
                var orphanMetadata = new List<string>();
                foreach (string directoryPath in Directory.GetDirectories(revisions))
                {
                    token.ThrowIfCancellationRequested(); RejectReparse(directoryPath);
                    string sha = Path.GetFileName(directoryPath);
                    Require(IsSha(sha) && !Directory.EnumerateDirectories(directoryPath).Any() &&
                        Directory.EnumerateFiles(directoryPath).All(file => Path.GetFileName(file) == "catalog.json" || Path.GetFileName(file) == "publisher.json"), "AmbiguousRevisionMetadataCleanupSkipped");
                    // Without a publisher there are no keep edges: an empty directory or a stray Catalog.
                    if (!File.Exists(Path.Combine(directoryPath, "publisher.json"))) { orphanMetadata.Add(directoryPath); continue; }
                    // Publisher presence protects bytes, not readiness. A partial
                    // candidate need not have its Catalog/all bundles yet.
                    metadata.Add(await ReadMetadataAsync(sha, null, token, metadataOnly: true));
                }
                var p = confirmed.Publisher;
                var candidates = metadata.Where(f => f.Publisher.productId == p.productId && f.Publisher.channel == p.channel &&
                    f.Publisher.authorityId == p.authorityId && f.Publisher.compatibilityFamily == p.compatibilityFamily &&
                    f.Publisher.deploymentSequence > p.deploymentSequence).ToArray();
                if (candidates.Length != 0)
                {
                    long highest = candidates.Max(f => f.Publisher.deploymentSequence);
                    var highestCandidates = candidates.Where(f => f.Publisher.deploymentSequence == highest).ToArray();
                    Require(highestCandidates.Length == 1, "AmbiguousHighestPreparedPublisherCleanupSkipped");
                    var retained = highestCandidates[0]; metadataKeep.Add(retained.PublisherSha256);
                    foreach (var bundle in retained.Publisher.bundles) keep.Add(bundle.fileSha256);
                }
                string directory = Path.Combine(root, "blobs", target); RejectReparse(directory);
                string[] inventory = Directory.GetFiles(directory, "*", SearchOption.TopDirectoryOnly);
                Require(inventory.All(p => Path.GetExtension(p) == ".bundle" && IsSha(Path.GetFileNameWithoutExtension(p)) && (File.GetAttributes(p) & FileAttributes.ReparsePoint) == 0), "AmbiguousOwnedBlobInventoryCleanupSkipped");
                foreach (string file in inventory.Where(p => !keep.Contains(Path.GetFileNameWithoutExtension(p))))
                { token.ThrowIfCancellationRequested(); File.Delete(file); await Task.Yield(); }
                string temp = Path.Combine(root, "tmp"); RejectReparse(temp);
                foreach (string file in Directory.GetFiles(temp, "t-*.tmp", SearchOption.TopDirectoryOnly))
                {
                    string name = Path.GetFileNameWithoutExtension(file);
                    if (name.Length != 34 || !name.Substring(2).All(Uri.IsHexDigit)) continue;
                    token.ThrowIfCancellationRequested(); RejectReparse(file); File.Delete(file); await Task.Yield();
                }
                // Delete metadata only after the corresponding unused blobs. Never
                // recurse through arbitrary/reparse paths or clean while playing.
                foreach (var obsolete in metadata.Where(f => !metadataKeep.Contains(f.PublisherSha256)))
                {
                    token.ThrowIfCancellationRequested();
                    // Publisher last: an interrupted metadata GC remains readable on
                    // the next startup. A final empty directory has no keep edges.
                    foreach (string name in new[] { "catalog.json", "publisher.json" })
                    { string file = Path.Combine(obsolete.MetadataDirectory, name); RejectReparse(file); if (File.Exists(file)) File.Delete(file); }
                    Directory.Delete(obsolete.MetadataDirectory, false); known.Remove(obsolete.PublisherSha256);
                    await Task.Yield();
                }
                foreach (string directoryPath in orphanMetadata)
                {
                    token.ThrowIfCancellationRequested();
                    string catalog = Path.Combine(directoryPath, "catalog.json"); RejectReparse(catalog);
                    if (File.Exists(catalog)) File.Delete(catalog);
                    Directory.Delete(directoryPath, false);
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception error) { LastCleanupWarning = string.IsNullOrEmpty(LastCleanupWarning) ? error.Message : LastCleanupWarning + " | " + error.Message; } // Cleanup never cancels an earlier confirmation.
            finally { busy = false; }
        }

        private async Task<ManagedRevisionFiles> ReadMetadataAsync(string publisherSha, string revisionId, CancellationToken token, ManagedAddressableRevision source = null, bool metadataOnly = false)
        {
            string directory = MetadataDirectory(publisherSha); RejectReparse(directory);
            string publisherPath = Path.Combine(directory, "publisher.json"), catalogPath = Path.Combine(directory, "catalog.json");
            RejectReparse(publisherPath); RejectReparse(catalogPath);
            byte[] bytes = File.ReadAllBytes(publisherPath); Require(SameSha(await ShaBytesAsync(bytes, token), publisherSha), "StoredPublisherShaMismatch");
            var publisher = ParsePublisher(bytes, revisionId);
            if (!metadataOnly)
            {
                Require(File.Exists(catalogPath), "StoredCatalogMissing");
                Require(new FileInfo(catalogPath).Length == publisher.catalogBytes, "StoredCatalogLengthMismatch");
            }
            var files = new ManagedRevisionFiles { Revision = source ?? new ManagedAddressableRevision(publisher.revisionId, catalogPath, publisherPath, publisherSha, target), Publisher = publisher,
                PublisherSha256 = publisherSha.ToLowerInvariant(), CatalogLocalPath = catalogPath, MetadataDirectory = directory, Bindings = Array.Empty<ManagedRevisionBundleBinding>() };
            known[files.PublisherSha256] = files;
            return files;
        }
        private ManagedRevisionPublisher ParsePublisher(byte[] bytes, string revisionId)
        {
            var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(Encoding.UTF8.GetString(bytes));
            Require(publisher != null && publisher.schemaVersion == 1 && publisher.target == target && !string.IsNullOrWhiteSpace(publisher.revisionId) &&
                (revisionId == null || publisher.revisionId == revisionId) && IsSha(publisher.catalogSha256) && publisher.catalogBytes > 0 &&
                !string.IsNullOrWhiteSpace(publisher.productId) && !string.IsNullOrWhiteSpace(publisher.channel) && !string.IsNullOrWhiteSpace(publisher.authorityId) &&
                !string.IsNullOrWhiteSpace(publisher.compatibilityFamily) && publisher.deploymentSequence > 0 &&
                !string.IsNullOrWhiteSpace(publisher.catalogFile) && publisher.catalogFile.IndexOfAny(new[] { '/', '\\' }) < 0 && publisher.catalogFile.EndsWith(".json", StringComparison.OrdinalIgnoreCase), "PublisherHeaderMismatch");
            Require(publisher.bundles != null && publisher.bundles.Length > 0 && publisher.bundles.All(row => row != null && IsSha(row.fileSha256) && row.bytes > 0 &&
                !string.IsNullOrWhiteSpace(row.fileName) && row.fileName != "." && row.fileName != ".." && row.fileName.IndexOfAny(new[] { '/', '\\' }) < 0 && !string.IsNullOrWhiteSpace(row.sdkBundleName) &&
                row.sdkHash != null && row.sdkHash.Length == 32 && row.sdkHash.All(Uri.IsHexDigit) && Hash128.Parse(row.sdkHash).isValid), "PublisherBundleInvalid");
            Require(publisher.bundles.Select(r => r.fileName).Distinct(StringComparer.Ordinal).Count() == publisher.bundles.Length &&
                publisher.bundles.Select(r => r.sdkBundleName + "|" + r.sdkHash.ToLowerInvariant()).Distinct(StringComparer.Ordinal).Count() == publisher.bundles.Length, "PublisherBundleIdentityAmbiguous");
            return publisher;
        }
        private async Task<ManagedRevisionFiles> ReadVerifiedMetadataAsync(string publisherSha, string revisionId,
            CancellationToken token, ManagedAddressableRevision source, bool fullSha)
        {
            var files = await ReadMetadataAsync(publisherSha, revisionId, token, source, metadataOnly: true);
            await VerifyCatalogAsync(files, fullSha, token);
            return files;
        }

        private async Task VerifyCatalogAsync(ManagedRevisionFiles files, bool fullSha, CancellationToken token)
        {
            Require(File.Exists(files.CatalogLocalPath), "StoredCatalogMissing");
            Require(new FileInfo(files.CatalogLocalPath).Length == files.Publisher.catalogBytes, "StoredCatalogLengthMismatch");
            if (fullSha)
            {
                LastCatalogShaChecks++;
                Require(SameSha(await ShaFileAsync(files.CatalogLocalPath, token), files.Publisher.catalogSha256), "StoredCatalogShaMismatch");
            }
        }

        private async Task ValidateMetadataAsync(ManagedRevisionFiles files, CancellationToken token, bool fullSha = false)
        {
            Require(files != null && files.Revision != null && IsSha(files.PublisherSha256) && files.MetadataDirectory == MetadataDirectory(files.PublisherSha256) &&
                files.CatalogLocalPath == Path.Combine(files.MetadataDirectory, "catalog.json"), "RevisionFilesOutsideOwnedMetadata");
            var original = await ReadVerifiedMetadataAsync(files.PublisherSha256, files.Revision.RevisionId, token, null, fullSha);
            Require(JsonUtility.ToJson(original.Publisher) == JsonUtility.ToJson(files.Publisher), "RevisionPublisherChangedAfterVerification");
            known[files.PublisherSha256] = files;
        }
        private static void ValidateBindings(ManagedRevisionFiles files, ManagedRevisionBundleBinding[] bindings)
        {
            Require(bindings != null && bindings.Length == files.Publisher.bundles.Length && bindings.All(b => b != null && b.Location != null && !string.IsNullOrWhiteSpace(b.CanonicalUri) && b.Bundle != null), "SdkBundleBindingsIncomplete");
            Require(bindings.Select(b => b.Bundle.fileName).Distinct(StringComparer.Ordinal).Count() == bindings.Length && bindings.All(b =>
                files.Publisher.bundles.Count(row => JsonUtility.ToJson(row) == JsonUtility.ToJson(b.Bundle)) == 1), "SdkBundleBindingsDoNotMatchPublisher");
        }
        private void VerifyFilesLight(ManagedRevisionFiles files, CancellationToken token)
        {
            foreach (var row in files.Publisher.bundles)
            { token.ThrowIfCancellationRequested(); Require(ExistsAtSize(BlobPath(row.fileSha256), row.bytes), "RequiredOwnedBundleMissingOrCorrupt: " + row.fileName); }
        }
        private async Task VerifyFilesAsync(ManagedRevisionFiles files, bool fullSha, CancellationToken token)
        {
            foreach (var row in files.Publisher.bundles)
            { token.ThrowIfCancellationRequested(); Require(await VerifyBlobAsync(row, fullSha, token), "RequiredOwnedBundleMissingOrCorrupt: " + row.fileName); }
        }
        private async Task<bool> VerifyBlobAsync(ManagedRevisionPublisherBundle bundle, bool fullSha, CancellationToken token)
        {
            string path = BlobPath(bundle.fileSha256);
            if (!ExistsAtSize(path, bundle.bytes)) return false;
            if (!fullSha) return true;
            LastBundleShaChecks++; return SameSha(await ShaFileAsync(path, token), bundle.fileSha256);
        }

        private Pointer ReadPointerIfPresent(out byte[] bytes)
        {
            RejectReparse(PointerPath); bytes = File.Exists(PointerPath) ? File.ReadAllBytes(PointerPath) : null;
            if (bytes == null) return null;
            var pointer = JsonUtility.FromJson<Pointer>(Encoding.UTF8.GetString(bytes));
            Require(pointer != null && pointer.schemaVersion == 1 && pointer.target == target && !string.IsNullOrWhiteSpace(pointer.revisionId) && IsSha(pointer.publisherSha256) && IsSha(pointer.catalogSha256), "ConfirmedRevisionPointerMalformed");
            return pointer;
        }
        private async Task<bool> ConfirmedReferencesBlobAsync(string sha, CancellationToken token)
        {
            var pointer = ReadPointerIfPresent(out _);
            if (pointer == null) return false;
            var files = await ReadMetadataAsync(pointer.publisherSha256, pointer.revisionId, token, metadataOnly: true);
            return files.Publisher.bundles.Any(row => SameSha(row.fileSha256, sha));
        }
        internal void RequireRepairPointerUnchanged(ManagedRevisionFiles files)
        {
            var pointer = ReadPointerIfPresent(out byte[] bytes);
            Require(files.RepairConfirmed && pointer != null && SameSha(pointer.publisherSha256, files.PublisherSha256) &&
                SameSha(Sha(bytes), files.ConfirmedPointerSha256), "RepairConfirmationChanged");
        }
        private static bool Equal(byte[] a, byte[] b) => a == null ? b == null : b != null && a.SequenceEqual(b);
        private void Enter() { if (busy) throw new InvalidOperationException("OwnedRevisionStorageBusy"); EnsureDirectories(); busy = true; }
        [Serializable] private sealed class Pointer { public int schemaVersion; public string target, revisionId, publisherSha256, catalogSha256; }
    }
}
