using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace Artress.ManagedAddressables
{
    /// <summary>
    /// Reads the app-included Revision A that the official Player build placed in
    /// StreamingAssets and builds the application scope from it. The channel and sequence
    /// come from the PC that built the Player, so the app accepts only that PC's Revisions.
    /// </summary>
    public static class ManagedPackagedRevisionLoader
    {
        /// <summary>StreamingAssets folder the official Player build writes Revision A into.</summary>
        public const string StreamingRoot = "ArtressManagedRevision";
        internal const string AnchorFile = "packaged_revision.json";

        [Serializable]
        internal sealed class Anchor
        {
            public int schemaVersion;
            public string revisionId, target, publisherSha256, productId, channel, authorityId;
            public string catalogRelativePath, publisherRelativePath, bundleRelativeRoot;
        }

        /// <summary>Reads the packaged anchor. Android reads it from the APK with UnityWebRequest.</summary>
        public static async Task<ManagedRevisionApplication> LoadAsync(CancellationToken cancellationToken = default)
        {
            string root = Application.streamingAssetsPath.TrimEnd('/', '\\') + "/" + StreamingRoot;
            string json = await ReadTextAsync(root + "/" + AnchorFile, cancellationToken);
            return FromAnchorJson(json, root);
        }

        internal static ManagedRevisionApplication FromAnchorJson(string json, string root)
        {
            var anchor = string.IsNullOrWhiteSpace(json) ? null : JsonUtility.FromJson<Anchor>(json);
            if (anchor == null || anchor.schemaVersion != 1 || string.IsNullOrWhiteSpace(anchor.catalogRelativePath) ||
                string.IsNullOrWhiteSpace(anchor.publisherRelativePath) || string.IsNullOrWhiteSpace(anchor.bundleRelativeRoot))
                throw new InvalidDataException("PackagedRevisionAnchorInvalid");
            var packaged = ManagedAddressableRevision.CreatePackaged(anchor.revisionId,
                Address(root, anchor.catalogRelativePath), Address(root, anchor.publisherRelativePath),
                anchor.publisherSha256, anchor.target, Address(root, anchor.bundleRelativeRoot) + "/");
            return new ManagedRevisionApplication(anchor.productId, anchor.channel, anchor.authorityId, packaged);
        }

        // A jar URL stays as Unity gives it. A file path becomes a file URI.
        private static string Address(string root, string relative)
        {
            if (relative.Contains("..") || Path.IsPathRooted(relative)) throw new InvalidDataException("PackagedRevisionAnchorPathInvalid");
            string combined = root + "/" + relative.Replace('\\', '/');
            return Uri.TryCreate(combined, UriKind.Absolute, out var uri) && !uri.IsFile ? combined : new Uri(Path.GetFullPath(combined)).AbsoluteUri.TrimEnd('/');
        }

        private static async Task<string> ReadTextAsync(string path, CancellationToken token)
        {
            if (!path.Contains("://")) return File.ReadAllText(path);
            using (var request = UnityWebRequest.Get(path))
            {
                var operation = request.SendWebRequest();
                while (!operation.isDone)
                {
                    if (token.IsCancellationRequested) { request.Abort(); token.ThrowIfCancellationRequested(); }
                    await Task.Yield();
                }
                if (request.result != UnityWebRequest.Result.Success) throw new IOException("PackagedRevisionAnchorReadFailed: " + request.error);
                return request.downloadHandler.text;
            }
        }
    }

    /// <summary>
    /// Development-only pointer written by the Editor's Publish Revision to Local Host.
    /// It stands in for the game server while there is none. Its publisher SHA comes from
    /// the same host as the files, so it is not a production trust anchor.
    /// </summary>
    [Serializable]
    public sealed class ManagedRevisionLocalHostPointer
    {
        public int schemaVersion = 1;
        public string revisionId, target, productId, channel, authorityId, compatibilityFamily;
        public long deploymentSequence;
        public string catalogUrl, publisherUrl, publisherSha256;

        public static ManagedRevisionLocalHostPointer Parse(string json)
        {
            var pointer = string.IsNullOrWhiteSpace(json) ? null : JsonUtility.FromJson<ManagedRevisionLocalHostPointer>(json);
            if (pointer == null || pointer.schemaVersion != 1 || string.IsNullOrWhiteSpace(pointer.revisionId) ||
                string.IsNullOrWhiteSpace(pointer.catalogUrl) || string.IsNullOrWhiteSpace(pointer.publisherUrl) ||
                string.IsNullOrWhiteSpace(pointer.publisherSha256) || string.IsNullOrWhiteSpace(pointer.target))
                throw new InvalidDataException("LocalHostPointerInvalid");
            return pointer;
        }

        /// <summary>The remote Revision for <c>PrepareAsync</c>. URL rules are the normal Revision rules.</summary>
        public ManagedAddressableRevision ToRevision() =>
            new ManagedAddressableRevision(revisionId, catalogUrl, publisherUrl, publisherSha256, target);
    }
}
