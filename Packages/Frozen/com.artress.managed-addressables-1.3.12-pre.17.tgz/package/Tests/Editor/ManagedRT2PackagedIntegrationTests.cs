using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets.Build;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedRT2PackagedIntegrationTests
    {
        private static string Sha(string path)
        {
            using (var stream = File.OpenRead(path)) using (var hash = SHA256.Create())
                return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        [Test]
        public void ActualVerifiedSdkReceiptCreatesPackagedReleaseWithoutRebuildingContent()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var (bootBuild, revisionBuild) = ManagedBootstrapSplitIntegrationTests.BuildAndCheckProductionArtifacts(f);
                var boot = ManagedBootstrapSplitIntegrationTests.ReadReceipt(bootBuild);
                var revision = ManagedBootstrapSplitIntegrationTests.ReadReceipt(revisionBuild);
                var release = ManagedLocalRelease.Effective(f.Config);
                var archivedBootFiles = boot.bundles.Select(bundle =>
                {
                    var archived = boot.runtimeFiles.Single(file => Path.GetFileName(file.path) == Path.GetFileName(bundle.filePath) && file.sha256 == bundle.sha256);
                    string path = Path.Combine(boot.runtimeDirectory, archived.path);
                    Assert.That(Sha(path), Is.EqualTo(bundle.sha256), "Protect the exact archived SDK Bundle, not the restored stage path.");
                    return path;
                }).ToArray();
                var sourceHashes = revision.bundles.Select(bundle => bundle.filePath).Append(revision.catalogPath)
                    .Append(revisionBuild.splitReceiptPath).Append(bootBuild.splitReceiptPath).Concat(archivedBootFiles).Append(boot.catalogPath)
                    .Distinct(StringComparer.Ordinal).ToDictionary(path => path, Sha, StringComparer.Ordinal);
                int builds = 0;
                Action<AddressableAssetBuildResult> capture = result => builds++;
                BuildScript.buildCompleted += capture;
                try
                {
                    string configBefore = EditorJsonUtility.ToJson(f.Config);
                    var plan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(f.Config, revisionBuild.splitReceiptPath, release, bootBuild.splitReceiptPath);
                    Assert.That(plan.CanApply, Is.True, plan.ToString());
                    Assert.That(EditorJsonUtility.ToJson(f.Config), Is.EqualTo(configBefore), "Preview must preserve the persistent Config.");
                    Assert.That(Directory.Exists(plan.outputDirectory), Is.False);
                    string metadata = ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(f.Config, plan);
                    string sourceRoot = Path.GetDirectoryName(metadata);
                    var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(Path.Combine(sourceRoot, "publisher.json")));
                    Assert.That(publisher.productId, Is.EqualTo(release.productId));
                    Assert.That(publisher.channel, Is.EqualTo(release.channel));
                    Assert.That(publisher.authorityId, Is.EqualTo(release.authorityId));
                    Assert.That(publisher.compatibilityFamily, Is.EqualTo(release.compatibilityFamily));
                    Assert.That(publisher.deploymentSequence, Is.EqualTo(release.deploymentSequence));
                    Assert.That(publisher.catalogSha256, Is.EqualTo(revision.catalogSha256));
                    Assert.That(publisher.bundles.Length, Is.EqualTo(revision.bundles.Count));
                    foreach (var bundle in publisher.bundles)
                    {
                        var sdk = revision.bundles.Single(row => row.bundleName == bundle.sdkBundleName);
                        Assert.That(bundle.sdkHash, Is.EqualTo(sdk.hash));
                        Assert.That(bundle.crc, Is.EqualTo(sdk.crc));
                        Assert.That(bundle.fileSha256, Is.EqualTo(sdk.sha256));
                        Assert.That(Sha(Path.Combine(sourceRoot, "bundles", bundle.fileName)), Is.EqualTo(sdk.sha256));
                    }
                    Assert.That(Sha(Path.Combine(sourceRoot, "catalog.json")), Is.EqualTo(revision.catalogSha256));
                    var link = ManagedLocalRelease.PackagedForActiveTarget(f.Config);
                    Assert.That(Path.IsPathRooted(link.metadataPath), Is.False);
                    Assert.That(Path.GetFullPath(link.metadataPath), Is.EqualTo(Path.GetFullPath(metadata)));
                    Assert.That(link.metadataSha256, Is.EqualTo(Sha(metadata)));
                    Assert.That(EditorJsonUtility.ToJson(f.Config), Does.Not.Contain(link.metadataPath),"The packaged link stays on this PC, not in the shared Config.");
                    Assert.That(Directory.Exists(Path.Combine(plan.outputDirectory, "Proof")), Is.True, "The paired receipt proof stays outside the app payload.");
                }
                finally { BuildScript.buildCompleted -= capture; }
                Assert.That(builds, Is.Zero, "Only the verified SDK receipt is consumed; no content build is permitted.");
                Assert.That(sourceHashes.All(row => Sha(row.Key) == row.Value), Is.True, "SDK source bytes must be preserved.");
            }
        }
    }
}
