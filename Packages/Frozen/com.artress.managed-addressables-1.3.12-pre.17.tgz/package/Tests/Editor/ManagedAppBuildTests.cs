using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // App Build: the sequence rule, the stale Player data guard, the batch arguments, readiness,
    // the language choice, and every real step before the Player build on the split fixture.
    // The Player build itself is replaced here; a real Player needs the runner's build mode.
    public sealed class ManagedAppBuildTests
    {
        private bool hadLanguage;
        private int language;
        private string temporary;

        [SetUp] public void SetUp()
        {
            hadLanguage = EditorPrefs.HasKey(ManagedEditorText.PreferenceKey);
            language = EditorPrefs.GetInt(ManagedEditorText.PreferenceKey, 0);
            ManagedEditorText.Language = ManagedEditorLanguage.Korean;
            temporary = Path.Combine(Path.GetTempPath(), "mab_" + Guid.NewGuid().ToString("N").Substring(0, 8));
            Directory.CreateDirectory(temporary);
        }

        [TearDown] public void TearDown()
        {
            if (hadLanguage) EditorPrefs.SetInt(ManagedEditorText.PreferenceKey, language);
            else EditorPrefs.DeleteKey(ManagedEditorText.PreferenceKey);
            if (Directory.Exists(temporary)) Directory.Delete(temporary, true);
        }

        // ---------- deployment sequence ----------

        [Test] public void DevelopmentBuildTakesTheNumberAfterTheLargestKnownOne()
        {
            Assert.AreEqual(1, ManagedAppBuild.ChooseDeploymentSequence(0, 0, true));
            Assert.AreEqual(8, ManagedAppBuild.ChooseDeploymentSequence(7, 3, true));
            Assert.AreEqual(10, ManagedAppBuild.ChooseDeploymentSequence(2, 9, true));
        }

        [Test] public void ReleaseBuildUsesTheSavedSequenceAndBlocksAnEqualOrLowerOne()
        {
            Assert.AreEqual(5, ManagedAppBuild.ChooseDeploymentSequence(5, 4, false));
            Assert.AreEqual(1, ManagedAppBuild.ChooseDeploymentSequence(1, 0, false));
            StringAssert.Contains("배포 값", Assert.Catch(() => ManagedAppBuild.ChooseDeploymentSequence(0, 0, false)).Message);
            StringAssert.Contains("4", Assert.Catch(() => ManagedAppBuild.ChooseDeploymentSequence(4, 4, false)).Message);
            StringAssert.Contains("4", Assert.Catch(() => ManagedAppBuild.ChooseDeploymentSequence(3, 4, false)).Message);
        }

        // ---------- batch arguments ----------

        [Test] public void CommandLineReadsTheOutputAndTheDevelopmentFlag()
        {
            var parsed = ManagedAppBuild.ParseCommandLine(new[] { "Unity.exe", "-batchmode", "-managedAppOutput", "Builds/a.apk", "-managedAppDevelopment" });
            Assert.AreEqual("Builds/a.apk", parsed.output);
            Assert.IsTrue(parsed.development);
            parsed = ManagedAppBuild.ParseCommandLine(new[] { "Unity.exe", "-MANAGEDAPPOUTPUT", "x.exe" });
            Assert.AreEqual("x.exe", parsed.output);
            Assert.IsFalse(parsed.development, "Without the flag it is a release build.");
            parsed = ManagedAppBuild.ParseCommandLine(new[] { "Unity.exe", "-managedAppOutput" });
            Assert.IsNull(parsed.output, "A flag without a value is no output.");
            Assert.IsNull(ManagedAppBuild.ParseCommandLine(null).output);
        }

        // ---------- previous Player data ----------

        [Test] public void PlayerDataFolderFollowsEachTargetLayout()
        {
            string exe = Path.Combine(temporary, "Game.exe");
            Assert.AreEqual(Path.Combine(temporary, "Game_Data"), ManagedAppBuild.PlayerDataFolder(BuildTarget.StandaloneWindows64, exe));
            Assert.AreEqual(Path.Combine(temporary, "Game_Data"), ManagedAppBuild.PlayerDataFolder(BuildTarget.StandaloneLinux64, Path.Combine(temporary, "Game.x86_64")));
            Assert.AreEqual(Path.Combine(temporary, "Game.app", "Contents", "Resources", "Data"), ManagedAppBuild.PlayerDataFolder(BuildTarget.StandaloneOSX, Path.Combine(temporary, "Game.app")));
            Assert.AreEqual(Path.Combine(temporary, "Xcode", "Data"), ManagedAppBuild.PlayerDataFolder(BuildTarget.iOS, Path.Combine(temporary, "Xcode")));
            Assert.IsNull(ManagedAppBuild.PlayerDataFolder(BuildTarget.Android, Path.Combine(temporary, "a.apk")), "Android is checked in its Gradle project instead.");
            Assert.IsNull(ManagedAppBuild.PlayerDataFolder(BuildTarget.WebGL, temporary));
        }

        [Test] public void OnlyADataUnity3dOlderThanTheBuildIsReported()
        {
            string exe = Path.Combine(temporary, "Game.exe");
            DateTime started = DateTime.UtcNow;
            CollectionAssert.IsEmpty(ManagedAppBuild.StalePlayerData(BuildTarget.StandaloneWindows64, exe, started, temporary), "No data.unity3d, nothing stale.");
            string data = Path.Combine(temporary, "Game_Data", "data.unity3d");
            Directory.CreateDirectory(Path.GetDirectoryName(data));
            File.WriteAllText(data, "old");
            File.SetLastWriteTimeUtc(data, started.AddHours(-1));
            CollectionAssert.AreEqual(new[] { data }, ManagedAppBuild.StalePlayerData(BuildTarget.StandaloneWindows64, exe, started, temporary));
            File.SetLastWriteTimeUtc(data, started.AddSeconds(1));
            CollectionAssert.IsEmpty(ManagedAppBuild.StalePlayerData(BuildTarget.StandaloneWindows64, exe, started, temporary));
            Assert.IsNull(ManagedAppBuild.StalePlayerData(BuildTarget.WebGL, exe, started, temporary), "Unchecked targets say so.");
        }

        [Test] public void AndroidGradlePlayerDataIsClearedForEveryBackendAndNothingElse()
        {
            string prj = Path.Combine(temporary, ManagedAppBuild.AndroidProjectRoot);
            string il2cpp = Path.Combine(prj, "IL2CPP", ManagedAppBuild.AndroidPlayerDataPath);
            string mono = Path.Combine(prj, "Mono2x", ManagedAppBuild.AndroidPlayerDataPath);
            string gradle = Path.Combine(prj, "IL2CPP", "Gradle", "unityLibrary", "build.gradle");
            string sibling = Path.Combine(prj, "IL2CPP", "Gradle", "unityLibrary", "src", "main", "assets", "keep.txt");
            DateTime started = DateTime.UtcNow;
            foreach (string folder in new[] { il2cpp, mono })
            {
                Directory.CreateDirectory(folder);
                File.WriteAllText(Path.Combine(folder, "data.unity3d"), "old compressed build");
                File.SetLastWriteTimeUtc(Path.Combine(folder, "data.unity3d"), started.AddDays(-7));
                File.WriteAllText(Path.Combine(folder, "globalgamemanagers"), "loose file");
            }
            File.WriteAllText(gradle, "gradle");
            File.WriteAllText(sibling, "keep");

            Assert.AreEqual(2, ManagedAppBuild.StalePlayerData(BuildTarget.Android, Path.Combine(temporary, "a.apk"), started, temporary).Count);
            var cleared = ManagedAppBuild.ClearAndroidPlayerData(temporary);
            CollectionAssert.AreEquivalent(new[] { il2cpp, mono }, cleared);
            Assert.IsFalse(Directory.Exists(il2cpp));
            Assert.IsFalse(Directory.Exists(mono));
            Assert.IsTrue(File.Exists(gradle), "The rest of the Gradle project stays.");
            Assert.IsTrue(File.Exists(sibling), "Only bin/Data is cleared.");
            CollectionAssert.IsEmpty(ManagedAppBuild.StalePlayerData(BuildTarget.Android, Path.Combine(temporary, "a.apk"), started, temporary));
            CollectionAssert.IsEmpty(ManagedAppBuild.ClearAndroidPlayerData(temporary), "A second clear finds nothing.");
            CollectionAssert.IsEmpty(ManagedAppBuild.ClearAndroidPlayerData(Path.Combine(temporary, "no-project")));
        }

        // ---------- readiness and language ----------

        [Test] public void LanguageChoiceSwitchesTheMessages()
        {
            Assert.AreEqual("가", ManagedEditorText.L("가", "A"));
            StringAssert.Contains("설정 만들기", ManagedAppBuild.Readiness(null).Single());
            ManagedEditorText.Language = ManagedEditorLanguage.English;
            Assert.AreEqual("A", ManagedEditorText.L("가", "A"));
            StringAssert.Contains("Create Config", ManagedAppBuild.Readiness(null).Single());
            Assert.AreEqual(ManagedEditorLanguage.English, ManagedEditorText.Language, "The choice is kept per user.");
        }

        [Test] public void BuildWithoutAConfigStopsAtReadinessAndWritesNothing()
        {
            string output = Path.Combine(temporary, "none", "Game.exe");
            var result = ManagedAppBuild.Build(null, output, true, (path, development) => { Assert.Fail("The Player step must not run."); return null; });
            Assert.IsFalse(result.Succeeded);
            Assert.AreEqual(1, result.Steps.Count);
            StringAssert.StartsWith("0/6", result.Steps[0]);
            StringAssert.Contains("설정 에셋", result.Error);
            Assert.IsFalse(Directory.Exists(Path.GetDirectoryName(output)));
            StringAssert.Contains("Assets", ManagedAppBuild.Build(null, "Assets/Game.exe", true, (path, development) => null).Error, "Output inside Assets is refused.");
            StringAssert.Contains("출력 경로", ManagedAppBuild.Build(null, " ", true, (path, development) => null).Error);
        }

        [Test] public void ReadinessNamesEachMissingSetupAndWhereToFixIt()
        {
            var scenes = EditorBuildSettings.scenes;
            try
            {
                using (var f = new ManagedBootstrapSplitFixture())
                {
                    EditorBuildSettings.scenes = new EditorBuildSettingsScene[0];
                    var missing = ManagedAppBuild.Readiness(f.Config);
                    Assert.That(missing.Any(line => line.Contains("배포 공유 값") && line.Contains("고급 > 배포 값")), string.Join("\n", missing));
                    Assert.That(missing.Any(line => line.Contains("Channel") && line.Contains("고급 > 배포 값")), string.Join("\n", missing));
                    Assert.That(missing.Any(line => line.Contains("Scene")), string.Join("\n", missing));

                    ManagedBootstrapSplitIntegrationTests.Ready(f);
                    EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(Scene(f), true) };
                    CollectionAssert.IsEmpty(ManagedAppBuild.Readiness(f.Config));

                    // Each missing setup is its own line, naming where to fix it.
                    var roles = f.Config.groupBuildRoles.ToList();
                    f.Config.groupBuildRoles.Clear();
                    missing = ManagedAppBuild.Readiness(f.Config);
                    Assert.AreEqual(1, missing.Count, string.Join("\n", missing));
                    StringAssert.Contains("빌드 역할이 없습니다", missing[0]);
                    StringAssert.Contains("고급 > 빌드 역할", missing[0]);
                    f.Config.groupBuildRoles.AddRange(roles);

                    var keys = f.Config.requiredBootKeys.ToList();
                    f.Config.requiredBootKeys.Clear();
                    missing = ManagedAppBuild.Readiness(f.Config);
                    Assert.AreEqual(1, missing.Count, string.Join("\n", missing));
                    StringAssert.Contains("필수 Boot 키가 없습니다", missing[0]);
                    StringAssert.Contains("고급 > 빌드 역할", missing[0]);
                    f.Config.requiredBootKeys.AddRange(keys);

                    // Ready turns on development http; only a release build is refused for it, before any step.
                    Assert.IsTrue(f.Config.allowDevelopmentHttp);
                    CollectionAssert.IsEmpty(ManagedAppBuild.Readiness(f.Config, true));
                    missing = ManagedAppBuild.Readiness(f.Config, false);
                    Assert.AreEqual(1, missing.Count, string.Join("\n", missing));
                    StringAssert.Contains("Allow Development HTTP", missing[0]);
                    StringAssert.Contains("고급 > 배포 값", missing[0]);
                }
            }
            finally { EditorBuildSettings.scenes = scenes; }
        }

        [Test] public void AppliedBuildRolesMatchTheirDraftInAnyOrder()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                // The draft as Suggest Roles fills it: Group name order, upper-case GUIDs, keys in entry order.
                var draft = f.Roles();
                draft.Reverse();
                foreach (var row in draft) row.groupAssetGuid = row.groupAssetGuid.ToUpperInvariant();
                var keys = new[] { "z.key", ManagedBootstrapSplitFixture.BootKey, " z.key " };
                var plan = ManagedAddressableSynchronizer.CreateBuildRolePlan(f.Config, draft, keys);
                Assert.IsTrue(plan.CanApply, plan.Report.ToString());
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                Assert.IsTrue(ManagedAddressableSynchronizer.SameBuildRoles(f.Config, draft, keys), "The applied roles are not an unapplied draft.");

                draft[0].role = draft[0].role == ManagedGroupBuildRole.Boot ? ManagedGroupBuildRole.Revision : ManagedGroupBuildRole.Boot;
                Assert.IsFalse(ManagedAddressableSynchronizer.SameBuildRoles(f.Config, draft, keys), "A changed role is an unapplied draft.");
                draft[0].role = draft[0].role == ManagedGroupBuildRole.Boot ? ManagedGroupBuildRole.Revision : ManagedGroupBuildRole.Boot;
                Assert.IsFalse(ManagedAddressableSynchronizer.SameBuildRoles(f.Config, draft, new[] { "z.key" }), "A removed key is an unapplied draft.");
            }
        }

        // ---------- every real step before the Player ----------

        [Test] public void AppBuildRunsEveryStepBeforeThePlayerAndRaisesTheSequenceOnlyForDevelopment()
        {
            var scenes = EditorBuildSettings.scenes;
            try
            {
                using (var f = new ManagedBootstrapSplitFixture())
                {
                    ManagedBootstrapSplitIntegrationTests.Ready(f);
                    EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(Scene(f), true) };
                    f.Save();
                    string output = Path.GetFullPath(Path.Combine(f.Output, "player", "Game.exe"));
                    int players = 0;
                    string linked = null;
                    Func<string, bool, string> player = (path, development) =>
                    {
                        players++;
                        Assert.AreEqual(output, path);
                        var saved = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(f.ConfigPath);
                        Assert.IsFalse(EditorUtility.IsDirty(saved), "The Player starts from a clean saved Config.");
                        var link = ManagedLocalRelease.PackagedForActiveTarget(saved);
                        Assert.IsNotNull(link, "The app included A is linked before the Player build.");
                        linked = link.metadataPath;
                        return "player replaced in this test";
                    };

                    var first = ManagedAppBuild.Build(f.Config, output, true, player);
                    Assert.IsTrue(first.Succeeded, first.ToString());
                    Assert.AreEqual(7, first.Steps.Count(line => char.IsDigit(line[0])), first.ToString());
                    Assert.AreEqual(11, first.DeploymentSequence, "Ready saved 10; a development build takes the next one.");
                    Assert.AreEqual(Path.GetFullPath(first.PackagedRevisionPath), Path.GetFullPath(linked));
                    f.Reload();
                    Assert.AreEqual(11, ManagedLocalRelease.Effective(f.Config).deploymentSequence, "The raised number is saved for this PC.");
                    Assert.AreEqual(11, JsonUtility.FromJson<ManagedPackagedRevisionAnchor>(File.ReadAllText(first.PackagedRevisionPath)).deploymentSequence);
                    var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(first.RevisionReceiptPath));
                    Assert.AreEqual(receipt.contentFingerprint, ManagedAddressableBuildExporter.SplitContentFingerprint(f.Config, f.Settings),
                        "The Revision still pairs with the Boot the Player build makes.");

                    var second = ManagedAppBuild.Build(f.Config, output, true, player);
                    Assert.IsTrue(second.Succeeded, second.ToString());
                    Assert.AreEqual(12, second.DeploymentSequence, "Every development build installs over the last one with a larger number.");
                    Assert.AreNotEqual(first.PackagedRevisionPath, second.PackagedRevisionPath);

                    // Release builds use the saved number; 12 is not above the last Revision, so nothing is built.
                    f.Reload();
                    string revisions = Path.GetDirectoryName(Path.GetDirectoryName(second.RevisionReceiptPath));
                    int before = Directory.GetDirectories(revisions).Length;
                    var http = ManagedAppBuild.Build(f.Config, output, false, player);
                    Assert.IsFalse(http.Succeeded);
                    StringAssert.StartsWith("0/6", http.Steps.Last(), "Development http stops a release build before any step.");
                    StringAssert.Contains("Allow Development HTTP", http.Error);
                    f.Config.allowDevelopmentHttp = false;
                    f.Save();
                    var release = ManagedAppBuild.Build(f.Config, output, false, player);
                    Assert.IsFalse(release.Succeeded);
                    StringAssert.StartsWith("2/6", release.Steps.Last());
                    StringAssert.Contains("12", release.Error);
                    Assert.AreEqual(before, Directory.GetDirectories(revisions).Length, "No Revision was built.");
                    Assert.AreEqual(12, ManagedLocalRelease.Effective(f.Config).deploymentSequence, "A release build never changes the saved number.");
                    Assert.AreEqual(2, players);

                    // A development build that fails after raising the number puts the saved number back.
                    // The fixture's remote root is plain http on loopback, so development http goes back on.
                    f.Config.allowDevelopmentHttp = true;
                    f.Save();
                    var failed = ManagedAppBuild.Build(f.Config, output, true, (path, development) => throw new InvalidOperationException("player failed in this test"));
                    Assert.IsFalse(failed.Succeeded);
                    Assert.AreEqual(13, failed.DeploymentSequence);
                    StringAssert.StartsWith("6/6", failed.Steps.Last(line => char.IsDigit(line[0])));
                    StringAssert.Contains("player failed in this test", failed.Error);
                    Assert.That(failed.Steps.Any(line => line.Contains("12로 되돌림")), failed.ToString());
                    f.Reload();
                    Assert.AreEqual(12,ManagedLocalRelease.Effective(f.Config).deploymentSequence, "The failed build's number is not kept.");
                }
            }
            finally { EditorBuildSettings.scenes = scenes; }
        }

        private static string Scene(ManagedBootstrapSplitFixture f)
        {
            // NewScene(Additive) refuses while the test runner's untitled scene is unsaved, and only a saved file is needed here.
            string path = f.Root + "/AppBuild.unity";
            File.WriteAllText(path, "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n");
            AssetDatabase.ImportAsset(path);
            return path;
        }
    }
}
