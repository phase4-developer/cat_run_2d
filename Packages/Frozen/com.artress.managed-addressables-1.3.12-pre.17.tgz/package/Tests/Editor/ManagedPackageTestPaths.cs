using System.IO;
using UnityEditor.PackageManager;

namespace Artress.ManagedAddressables.Editor.Tests
{
    internal static class ManagedPackageTestPaths
    {
        internal static string Resolve(string relative)
        {
            return Path.Combine(PackageInfo.FindForAssembly(typeof(ManagedAddressableProjectConfig).Assembly).resolvedPath, relative);
        }
    }
}
