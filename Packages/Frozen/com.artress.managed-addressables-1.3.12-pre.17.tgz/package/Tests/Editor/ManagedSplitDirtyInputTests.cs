using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedSplitDirtyInputTests
    {
        // A consumer game project stayed blocked after Save Project and an Editor restart, because shaders and
        // dynamic fonts were dirty in memory. Only edits an owner can save may block the build or a Sync.
        [Test]
        public void ImportedEditorStateDoesNotBlockButSavableEditsDo()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                string text = ImportText(f);
                var imported = AssetDatabase.LoadMainAssetAtPath(text);
                Assert.IsNotNull(imported);

                EditorUtility.SetDirty(imported);
                EditorUtility.SetDirty(f.Config);
                Assert.IsTrue(EditorUtility.IsDirty(imported));

                var dirty = ManagedAddressableBuildExporter.DirtyProjectAssets().ToList();
                CollectionAssert.DoesNotContain(dirty, text);
                CollectionAssert.Contains(dirty, f.ConfigPath);

                var sync = ManagedAddressableSynchronizer.UnrelatedDirtyAssets(null, null, new List<AddressableAssetGroup>()).ToList();
                CollectionAssert.DoesNotContain(sync, text);
                CollectionAssert.Contains(sync, f.ConfigPath);
            }
        }

        [Test]
        public void UnappliedImportSettingsBlock()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                string text = ImportText(f);
                var importer = AssetImporter.GetAtPath(text);
                Assert.IsNotNull(importer);
                importer.userData = "unapplied";
                EditorUtility.SetDirty(importer);

                CollectionAssert.Contains(ManagedAddressableBuildExporter.DirtyProjectAssets().ToList(), text);
            }
        }

        // Scene and Prefab Mode edits live on non-persistent scene objects, so the persistent-object scan misses them.
        [Test]
        public void UnsavedOpenSceneBlocks()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                // NewScene(Additive) refuses while the test runner's untitled scene is unsaved, so open a saved file instead.
                string path = f.Root + "/Dirty.unity";
                File.WriteAllText(path, "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n");
                AssetDatabase.ImportAsset(path);
                Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Additive);
                try
                {
                    Assert.IsTrue(scene.IsValid() && scene.isLoaded && !scene.isDirty);
                    CollectionAssert.DoesNotContain(ManagedAddressableBuildExporter.DirtyProjectAssets().ToList(), path);

                    // A script move does not mark the scene dirty in Edit Mode; editor edits do, through MarkSceneDirty.
                    SceneManager.MoveGameObjectToScene(new GameObject("Unsaved"), scene);
                    Assert.IsTrue(EditorSceneManager.MarkSceneDirty(scene));
                    Assert.IsTrue(scene.isDirty);
                    CollectionAssert.Contains(ManagedAddressableBuildExporter.DirtyProjectAssets().ToList(), path);
                }
                finally
                {
                    EditorSceneManager.CloseScene(scene, true);
                }
            }
        }

        private static string ImportText(ManagedBootstrapSplitFixture f)
        {
            string text = f.Root + "/Imported.txt";
            File.WriteAllText(text, "imported");
            AssetDatabase.ImportAsset(text);
            return text;
        }
    }
}
