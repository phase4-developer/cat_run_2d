using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // Opaque byte/file tests. Actual SDK Catalog/Player behavior is independent QA.
    [Platform("Win")]
    public sealed class ManagedRevisionStorageStartupTests
    {
        private ManagedAddressableRevisionStorage store;
        private string root, input;
        private const BindingFlags Hidden = BindingFlags.Instance | BindingFlags.NonPublic;
        private static string Sha(byte[] bytes) { using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        private static object Field(object value, string field) => value.GetType().GetField(field).GetValue(value);
        // Await the fault without blocking Unity's main synchronization context.
        // ThrowsAsync previously required an exact exception type; preserve it.
        private static async Task<T> ThrowsExactlyAsync<T>(Func<Task> action) where T : Exception
        {
            try { await action(); }
            catch (Exception error)
            {
                Assert.That(error, Is.TypeOf<T>());
                return (T)error;
            }
            Assert.Fail("Expected exception " + typeof(T).FullName + ", but the operation completed without an exception.");
            return null;
        }

        private static async Task<object> Call(object value, string method, params object[] args)
        {
            Task task;
            try { task = (Task)value.GetType().GetMethod(method, Hidden).Invoke(value, args); }
            catch (TargetInvocationException error) when (error.InnerException != null) { ExceptionDispatchInfo.Capture(error.InnerException).Throw(); throw; }
            await task; return task.GetType().GetProperty("Result")?.GetValue(task);
        }
        [SetUp] public void SetUp()
        {
            string name = "StartupQA_" + Guid.NewGuid().ToString("N"); store = new ManagedAddressableRevisionStorage(name, 0);
            root = (string)store.GetType().GetProperty("RootDirectory", Hidden).GetValue(store);
            input = Path.Combine(Application.streamingAssetsPath, name); Directory.CreateDirectory(input);
        }
        [TearDown] public void TearDown()
        {
            Assert.That(Path.GetFullPath(root).StartsWith(Path.GetFullPath(Application.persistentDataPath) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase), Is.True);
            Assert.That(Path.GetFullPath(input).StartsWith(Path.GetFullPath(Application.streamingAssetsPath) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase), Is.True);
            if (Directory.Exists(root)) Directory.Delete(root, true);
            if (Directory.Exists(input)) Directory.Delete(input, true);
            if (File.Exists(input + ".meta")) File.Delete(input + ".meta");
        }
        private ManagedAddressableRevision Source(string id = "A")
        {
            string path = Path.Combine(input, id); Directory.CreateDirectory(Path.Combine(path, "bundles"));
            byte[] catalog = Encoding.UTF8.GetBytes("SDK opaque catalog " + id), bundle = Encoding.UTF8.GetBytes("opaque bundle " + id);
            File.WriteAllBytes(Path.Combine(path, "catalog.json"), catalog); File.WriteAllBytes(Path.Combine(path, "bundles/content.bundle"), bundle);
            var pub = new ManagedRevisionPublisher { revisionId = id, target = "StandaloneWindows64", catalogFile = "catalog.json", catalogSha256 = Sha(catalog), catalogBytes = catalog.LongLength,
                productId = "product", channel = "fixture", authorityId = "one-authority", compatibilityFamily = "F", deploymentSequence = 10,
                bundles = new[] { new ManagedRevisionPublisherBundle { fileName = "content.bundle", bytes = bundle.LongLength, fileSha256 = Sha(bundle), sdkBundleName = "opaque", sdkHash = "11111111111111111111111111111111" } } };
            byte[] metadata = Encoding.UTF8.GetBytes(JsonUtility.ToJson(pub)); File.WriteAllBytes(Path.Combine(path, "publisher.json"), metadata);
            return ManagedAddressableRevision.CreatePackaged(id, Path.Combine(path, "catalog.json"), Path.Combine(path, "publisher.json"), Sha(metadata), pub.target, Path.Combine(path, "bundles"));
        }
        private async Task<object> PrepareCatalog(ManagedAddressableRevision source) => await Call(store, "PrepareCatalogAsync", source, CancellationToken.None);
        private async Task PrepareBundles(object files)
        {
            var pub = (ManagedRevisionPublisher)Field(files, "Publisher"); Type type = store.GetType().Assembly.GetType("Artress.ManagedAddressables.ManagedRevisionBundleBinding", true);
            Array rows = Array.CreateInstance(type, pub.bundles.Length);
            for (int i = 0; i < pub.bundles.Length; i++)
            {
                var row = pub.bundles[i]; var location = new ResourceLocationBase(row.fileName, "http://127.0.0.1:1/intentionally-unavailable/" + row.fileName, typeof(AssetBundleProvider).FullName, typeof(IAssetBundleResource));
                object binding = Activator.CreateInstance(type); type.GetField("Location").SetValue(binding, location);
                type.GetField("CanonicalUri").SetValue(binding, location.InternalId); type.GetField("Bundle").SetValue(binding, row); rows.SetValue(binding, i);
            }
            await Call(store, "PrepareBundlesAsync", files, rows, true, CancellationToken.None);
        }

        [Test] public async Task EmptyNamespaceIsFirstInstallButMissingPointerAloneIsNot()
        {
            Assert.That(await Call(store, "ReadConfirmedMetadataAsync", CancellationToken.None), Is.Null);
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.True);
            File.WriteAllText(Path.Combine(root, "tmp/t-01234567890123456789012345678901.tmp"), "interrupted copy");
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.True);
            File.WriteAllText(Path.Combine(root, "not-a-framework-temporary.txt"), "ambiguous residue");
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.False);
        }
        [Test] public async Task TrustedPublisherReadDoesNotCreateCatalogOrConfirmation()
        {
            var source = Source(); var pub = (ManagedRevisionPublisher)await Call(store, "ReadPublisherAsync", source, CancellationToken.None);
            Assert.That(pub.deploymentSequence, Is.EqualTo(10));
            Assert.That(Directory.GetFiles(root, "*", SearchOption.AllDirectories), Is.Empty);
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.True);
        }
        [Test] public async Task PackagedCopiesPreserveOriginalAndIgnoreCatalogHttpForFileAcquisition()
        {
            var source = Source(); string bundlePath = Path.Combine(new Uri(source.PackagedBundleRoot).LocalPath, "content.bundle");
            byte[] beforeCatalog = File.ReadAllBytes(source.CatalogPath), beforeBundle = File.ReadAllBytes(bundlePath);
            object files = await PrepareCatalog(source); await PrepareBundles(files);
            Assert.That((long)store.GetType().GetProperty("LastDownloadedBytes", Hidden).GetValue(store), Is.Zero);
            Assert.That((long)store.GetType().GetProperty("LastCopiedBytes", Hidden).GetValue(store), Is.EqualTo(beforeBundle.LongLength));
            Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.False);
            Assert.That(File.ReadAllBytes(source.CatalogPath), Is.EqualTo(beforeCatalog));
            Assert.That(File.ReadAllBytes(bundlePath), Is.EqualTo(beforeBundle));
            object outcome = await Call(store, "CommitConfirmedAsync", files, CancellationToken.None);
            Assert.That(Field(outcome, "Outcome"), Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            string owned = (string)Field(files, "CatalogLocalPath"); Assert.That(owned.StartsWith(root, StringComparison.OrdinalIgnoreCase), Is.True);
        }
        [Test] public async Task MetadataSelectionDoesNotTurnPayloadLossIntoMissingConfirmation()
        {
            object files = await PrepareCatalog(Source()); await PrepareBundles(files); await Call(store, "CommitConfirmedAsync", files, CancellationToken.None);
            byte[] pointer = File.ReadAllBytes(Path.Combine(root, "confirmed.json")); File.Delete((string)Field(files, "CatalogLocalPath"));
            Assert.That(await Call(store, "ReadConfirmedMetadataAsync", CancellationToken.None), Is.Not.Null);
            await ThrowsExactlyAsync<InvalidDataException>(async () => await Call(store, "ReadConfirmedAsync", CancellationToken.None));
            Assert.That(File.ReadAllBytes(Path.Combine(root, "confirmed.json")), Is.EqualTo(pointer));
        }
        [Test] public async Task InterruptedPreparedAWithoutPointerRemainsAmbiguous()
        {
            object files = await PrepareCatalog(Source());
            Assert.That(await Call(store, "ReadConfirmedMetadataAsync", CancellationToken.None), Is.Null);
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.False);
            await PrepareBundles(files);
            object result = await Call(store, "CommitConfirmedAsync", files, CancellationToken.None);
            Assert.That(Field(result, "Outcome"), Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            string pointer = Path.Combine(root, "confirmed.json"); byte[] confirmed = File.ReadAllBytes(pointer); Assert.That(confirmed.Length, Is.GreaterThan(0));
            File.Delete(pointer); // Exact own fixture stimulus: completed A, only pointer lost.
            Assert.That(await Call(store, "ReadConfirmedMetadataAsync", CancellationToken.None), Is.Null);
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.False);
            Assert.That(File.Exists((string)Field(files, "CatalogLocalPath")), Is.True);
        }
        [Test] public async Task ActualBlobDestinationCopyFailureCannotConfirmAndPreservesSource()
        {
            var source = Source(); object files = await PrepareCatalog(source); var pub = (ManagedRevisionPublisher)Field(files, "Publisher");
            string blocked = Path.Combine(root, "blobs/StandaloneWindows64", pub.bundles[0].fileSha256 + ".bundle"); Directory.CreateDirectory(blocked);
            await ThrowsExactlyAsync<IOException>(async () => await PrepareBundles(files));
            Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.False);
            Assert.That(File.Exists(Path.Combine(new Uri(source.PackagedBundleRoot).LocalPath, "content.bundle")), Is.True);
        }

        private async Task<ManagedRevisionReasonCode> Begin(ManagedAddressableRevision source)
        {
            var publisher = (ManagedRevisionPublisher)await Call(store, "ReadPublisherAsync", source, CancellationToken.None);
            return (ManagedRevisionReasonCode)await Call(store, "BeginInitialInstallAsync", source, publisher, CancellationToken.None);
        }
        private string Marker => Path.Combine(root, "initial-install.json");

        [Serializable] private sealed class MarkerSnapshot
        { public int schemaVersion = 0; public string publisherSha256 = null, phase = null; }

        [TestCase("empty")]
        [TestCase("partial")]
        [TestCase("complete")]
        public async Task UnpublishedMarkerTemporaryCanRestartWithoutTreatingPartialBytesAsTheMarker(string interruption)
        {
            var source = Source(); string temporary = Path.Combine(root, "tmp/t-interrupted-initial-marker.tmp");
            string content = interruption == "empty" ? "" : interruption == "partial" ? "{\"schemaVersion\":" :
                JsonUtility.ToJson(new MarkerSnapshot { schemaVersion = 1, publisherSha256 = source.ExpectedPublisherSha256, phase = "Copying" });
            File.WriteAllText(temporary, content); // Owned synthetic residue at the pre-atomic-move boundary, not a process-kill claim.
            Assert.That(File.Exists(Marker), Is.False);
            store = new ManagedAddressableRevisionStorage(Path.GetFileName(root), 0);
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.True);
            Assert.That(await Begin(source), Is.EqualTo(ManagedRevisionReasonCode.None));
            var marker = JsonUtility.FromJson<MarkerSnapshot>(File.ReadAllText(Marker));
            Assert.That(marker.schemaVersion, Is.EqualTo(1)); Assert.That(marker.publisherSha256, Is.EqualTo(source.ExpectedPublisherSha256));
            Assert.That(marker.phase, Is.EqualTo("Copying")); Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.False);
        }

        [TestCase("tmp/not-owned.tmp")]
        [TestCase("tmp/t-owned.txt")]
        [TestCase("tmp/nested/t-owned.tmp")]
        [TestCase("t-owned.tmp")]
        public async Task MissingPointerWithAnyNonmatchingLeafStillRequiresRecovery(string relative)
        {
            string file = Path.Combine(root, relative); Directory.CreateDirectory(Path.GetDirectoryName(file)); File.WriteAllText(file, "preserve these bytes");
            Assert.That(await Call(store, "IsEmptyForFirstInstallAsync", CancellationToken.None), Is.False);
            await ThrowsExactlyAsync<InvalidDataException>(async () => await Begin(Source()));
            Assert.That(File.ReadAllText(file), Is.EqualTo("preserve these bytes")); Assert.That(File.Exists(Marker), Is.False);
        }

        [Test] public async Task InitialMarkerMoveFailureCannotPublishAPartialMarker()
        {
            var source = Source(); Directory.CreateDirectory(Marker); // Own empty directory makes the actual atomic File.Move fail.
            try { await ThrowsExactlyAsync<IOException>(async () => await Begin(source)); }
            finally { Directory.Delete(Marker, false); }
            Assert.That(File.Exists(Marker), Is.False);
            Assert.That(Directory.GetFiles(root, "*", SearchOption.AllDirectories), Is.Empty);
            store = new ManagedAddressableRevisionStorage(Path.GetFileName(root), 0);
            Assert.That(await Begin(source), Is.EqualTo(ManagedRevisionReasonCode.None));
            Assert.That(JsonUtility.FromJson<MarkerSnapshot>(File.ReadAllText(Marker)).phase, Is.EqualTo("Copying"));
        }

        [Test] public async Task CopyingResidueRetriesOnlyTheSamePackagedAAndAckRemovesTheMarker()
        {
            var source = Source(); Assert.That(await Begin(source), Is.EqualTo(ManagedRevisionReasonCode.None));
            object first = await PrepareCatalog(source); await PrepareBundles(first);
            Assert.That(File.ReadAllText(Marker), Does.Contain("Copying"));
            store = new ManagedAddressableRevisionStorage(Path.GetFileName(root), 0); // Fresh store instance, no in-memory history.
            Assert.That(await Begin(source), Is.EqualTo(ManagedRevisionReasonCode.None));
            Assert.That(Directory.GetFiles(root, "*", SearchOption.AllDirectories), Is.EquivalentTo(new[] { Marker }));
            object retry = await PrepareCatalog(source); await PrepareBundles(retry);
            Assert.That(Field(await Call(store, "CommitConfirmedAsync", retry, CancellationToken.None), "Outcome"), Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            Assert.That(File.Exists(Marker), Is.False);
            Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.True);
        }

        [TestCase("other-revision")]
        [TestCase("foreign-blob")]
        [TestCase("publisher-missing-with-blob")]
        [TestCase("different-app")]
        [TestCase("malformed-marker")]
        public async Task CopyingMarkerCannotAuthorizeUnrelatedOrUntrustedResidue(string mutation)
        {
            var source = Source(); await Begin(source); object files = await PrepareCatalog(source); await PrepareBundles(files);
            if (mutation == "other-revision")
            { string other = Path.Combine(root, "revisions", new string('b', 64)); Directory.CreateDirectory(other); File.WriteAllText(Path.Combine(other, "publisher.json"), "not current A"); }
            if (mutation == "foreign-blob") File.WriteAllText(Path.Combine(root, "blobs/StandaloneWindows64", new string('c', 64) + ".bundle"), "not A");
            if (mutation == "publisher-missing-with-blob") File.Delete(Path.Combine((string)Field(files, "MetadataDirectory"), "publisher.json"));
            if (mutation == "different-app") source = Source("OtherA");
            if (mutation == "malformed-marker") File.WriteAllText(Marker, "{}");
            var before = Directory.GetFiles(root, "*", SearchOption.AllDirectories).OrderBy(p => p).Select(p => p + "|" + Sha(File.ReadAllBytes(p))).ToArray();
            await ThrowsExactlyAsync<InvalidDataException>(async () => await Begin(source));
            Assert.That(Directory.GetFiles(root, "*", SearchOption.AllDirectories).OrderBy(p => p).Select(p => p + "|" + Sha(File.ReadAllBytes(p))).ToArray(), Is.EqualTo(before));
        }

        [Test] public async Task CommitStartedMissingPointerIsATypedBootReasonWithoutDeletingPayload()
        {
            var source = Source(); await Begin(source); object files = await PrepareCatalog(source); await PrepareBundles(files);
            string pointer = Path.Combine(root, "confirmed.json"); Directory.CreateDirectory(pointer); // Actual pointer move failure, after the phase write.
            try
            { Assert.That(Field(await Call(store, "CommitConfirmedAsync", files, CancellationToken.None), "Outcome"), Is.EqualTo(ManagedRevisionCommitOutcome.Unchanged)); }
            finally { Directory.Delete(pointer, false); }
            Assert.That(File.ReadAllText(Marker), Does.Contain("CommitStarted"));
            await AssertCommitStartedBootReason(source);
        }

        [Test] public async Task AckResidueAndLaterPointerLossCannotBeReclassifiedAsFirstInstall()
        {
            var source = Source(); await Begin(source); object files = await PrepareCatalog(source); await PrepareBundles(files);
            Assert.That(Field(await Call(store, "CommitConfirmedAsync", files, CancellationToken.None), "Outcome"), Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            string pointer = Path.Combine(root, "confirmed.json"); byte[] acknowledged = File.ReadAllBytes(pointer);
            // Explicit stale-marker stimulus; then use a REAL delete-sharing failure
            // at the next startup. This is not a power-loss/commit fault-hook test.
            File.WriteAllText(Marker, "{\"schemaVersion\":1,\"publisherSha256\":\"" + source.ExpectedPublisherSha256 + "\",\"phase\":\"CommitStarted\"}");
            using (var held = new FileStream(Marker, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                object read = await Call(store, "ReadConfirmedAsync", CancellationToken.None);
                await Call(store, "CleanupApplicationStartupAsync", read, Array.Empty<string>(), CancellationToken.None);
                Assert.That((string)store.GetType().GetProperty("LastCleanupWarning", Hidden).GetValue(store), Does.Contain("Initial install marker cleanup"));
                Assert.That(File.ReadAllBytes(pointer), Is.EqualTo(acknowledged));
                Assert.That(File.Exists(Marker), Is.True);
            }
            File.Delete(pointer); // Only this fixture's pointer is removed.
            await AssertCommitStartedBootReason(source);
        }

        private async Task AssertCommitStartedBootReason(ManagedAddressableRevision source)
        {
            var before = Directory.GetFiles(root, "*", SearchOption.AllDirectories).OrderBy(p => p).Select(p => p + "|" + Sha(File.ReadAllBytes(p))).ToArray();
            var session = new ManagedAddressableRevisionSession(store); var boot = new ResourceLocationMap("marker-unit-boot", 0);
            Addressables.AddResourceLocator(boot);
            try
            {
                var app = new ManagedRevisionApplication("product", "fixture", "one-authority", source);
                var result = await session.OpenForApplicationAsync(boot, app, new ManagedRevisionApplyCallbacks(
                    token => Task.FromResult(new ManagedRevisionBoundary(0, 0, 0, 0, true, "no Revision was opened")),
                    (revision, token) => throw new InvalidOperationException("CommitStarted must stop before SDK Catalog validation")));
                Assert.That(result.Success, Is.False); Assert.That(result.RecoveryRequired, Is.True);
                Assert.That(result.ReasonCode, Is.EqualTo(ManagedRevisionReasonCode.InitialInstallCommitStartedWithoutPointer));
                Assert.That(session.CanStartConsumers, Is.False);
                Assert.That(Directory.GetFiles(root, "*", SearchOption.AllDirectories).OrderBy(p => p).Select(p => p + "|" + Sha(File.ReadAllBytes(p))).ToArray(), Is.EqualTo(before));
            }
            finally
            {
                await session.CloseAsync(token => Task.FromResult(new ManagedRevisionBoundary(0, 0, 0, 0, true, "test cleanup")));
                Addressables.RemoveResourceLocator(boot);
            }
        }
    }
}
