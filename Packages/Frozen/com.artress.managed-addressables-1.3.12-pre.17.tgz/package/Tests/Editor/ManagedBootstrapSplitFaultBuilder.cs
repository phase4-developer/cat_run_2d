using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // A real SDK IDataBuilder input, not a hook in production code.
    public sealed class ManagedBootstrapSplitFaultBuilder : ScriptableObject, IDataBuilder
    {
        public const string ErrorMarker = "QA_SPLIT_SDK_RESULT_ERROR";
        public const string ExceptionMarker = "QA_SPLIT_SDK_BUILDER_EXCEPTION";
        public bool throwException;
        public static int Calls;
        public static Observation Last;
        public string Name => "Independent BootstrapSplit fault builder";

        [Serializable]
        public sealed class GroupObservation
        {
            public string guid, name;
            public bool includeInBuild;
        }

        [Serializable]
        public sealed class Observation
        {
            public string providerType;
            public bool json, remote, updateDisabled;
            public List<GroupObservation> groups;
        }

        public bool CanBuildData<T>() where T : IDataBuilderResult => typeof(T) == typeof(AddressablesPlayerBuildResult);
        public void ClearCachedData() { } // Never clear shared SDK data in a failure test.

        public TResult BuildData<TResult>(AddressablesDataBuilderInput input) where TResult : IDataBuilderResult
        {
            Calls++;
            var settings = input.AddressableSettings;
            Last = new Observation
            {
                providerType = settings.CatalogProviderType?.FullName,
                json = settings.EnableJsonCatalog,
                remote = settings.BuildRemoteCatalog,
                updateDisabled = settings.DisableCatalogUpdateOnStartup,
                groups = settings.groups.Where(g => g != null).Select(g => new GroupObservation
                {
                    guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(g)),
                    name = g.Name,
                    includeInBuild = g.GetSchema<BundledAssetGroupSchema>()?.IncludeInBuild ?? false
                }).ToList()
            };
            if (throwException) throw new InvalidOperationException(ExceptionMarker);
            return AddressableAssetBuildResult.CreateResult<TResult>(null, 0, ErrorMarker);
        }
    }
}
