using NUnit.Framework;
using System.IO;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedBuildOutputContractTests
    {
        [Test]
        public void BuildExporter_AlwaysBuildsCleanFullSnapshot()
        {
            string source = File.ReadAllText(ManagedPackageTestPaths.Resolve("Editor/ManagedAddressableBuildExporter.Split.cs"));
            StringAssert.Contains("AddressableAssetSettings.CleanPlayerContent", source);
            StringAssert.Contains("AddressableAssetSettings.BuildPlayerContent", source);
            StringAssert.DoesNotContain("ContentUpdateScript.BuildContentUpdate", source);
            StringAssert.DoesNotContain("baseline_manifest.json", source);
            StringAssert.DoesNotContain("addressables_content_state.bin", source);
        }

        [Test]
        public void Preset_UsesProjectIndependentBundleIdentityForEveryBundledGroup()
        {
            string source = File.ReadAllText(ManagedPackageTestPaths.Resolve("Editor/ManagedAddressablePreset.cs"));
            StringAssert.Contains("BuiltInBundleNaming.DefaultGroupGuid", source);
            StringAssert.DoesNotContain("BuiltInBundleNaming.ProjectName", source);
            StringAssert.Contains("MonoScriptBundleNaming.DefaultGroupGuid", source);
            StringAssert.DoesNotContain("MonoScriptBundleNaming.ProjectName", source);
            StringAssert.Contains("ApplyProjectIndependentBundleIdentity", source);
            StringAssert.Contains("BundleNamingStyle.NoHash", source);
            StringAssert.Contains("BundleInternalIdMode.GroupGuid", source);
            StringAssert.DoesNotContain("GroupGuidProjectIdHash", source);
        }

        [Test]
        public void ValidatorAcceptsOfficialSdkIdentityAndRejectsOwnedAddressConflicts()
        {
            ManagedAR2G2IntegrationTests.AssertForeignSdkSchemaAcceptedWithoutMutation();
            ManagedAR2G2IntegrationTests.AssertOwnedAddressConflictStillRejected();
        }

        [Test]
        public void BuildExporter_DoesNotCopyLocalDependencyBundlesIntoRemoteOutput()
        {
            string source = File.ReadAllText(ManagedPackageTestPaths.Resolve("Editor/ManagedAddressableBuildExporter.Split.cs"));
            StringAssert.DoesNotContain("MaterializeManagedDependencyClosure", source);
            StringAssert.DoesNotContain("MaterializeCompleteRemoteSnapshot", source);
        }

        [Test]
        public void RemoteGroups_AreConfiguredAsChangeableContent()
        {
            string source = File.ReadAllText(ManagedPackageTestPaths.Resolve("Editor/ManagedAddressablePreset.cs"));
            StringAssert.Contains("update.StaticContent = !remote", source);
        }

        [Test]
        public void LocalizationSdkCollectionsRemainUnownedAndUnchangedBySync()
        {
            ManagedAR2G2IntegrationTests.AssertOfficialLocalizationCollectionPreservedWithoutPolicyRepair();
        }
    }
}
