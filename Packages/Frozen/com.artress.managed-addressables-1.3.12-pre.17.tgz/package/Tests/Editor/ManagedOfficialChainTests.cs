using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // The guide's steps from an empty project to a Windows Player, on the Revision Host from Tests/Fixtures~.
    // Its Config and content stay in the Host for the Player, so run this case alone and last.
    public sealed class ManagedOfficialChainTests
    {
        private const string Root = "Assets/ManagedChain", Content = Root + "/Content", ScenePath = Root + "/Chain.unity";
        private const string MarkerType = "Artress.ManagedAddressables.HostFixture.ManagedHostMarker, Artress.ManagedAddressables.HostFixture";
        private const string DriverType = "Artress.ManagedAddressables.HostFixture.ManagedChainPlayerDriver, Artress.ManagedAddressables.HostFixture";

        private static string Sha(string path)
        {
            using (var stream = File.OpenRead(path)) using (var hash = SHA256.Create())
                return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        private static void Apply(ManagedAddressableProjectConfig config, ManagedAddressableSyncPlan plan)
        {
            Assert.IsTrue(plan.CanApply, plan.Report.ToString());
            ManagedAddressableSynchronizer.ApplyPlan(config, plan);
            AssetDatabase.SaveAssets();
        }

        private static TextAsset Text(string path, string value)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, value);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
            return AssetDatabase.LoadAssetAtPath<TextAsset>(path);
        }

        private static void MarkerPrefab(string path, string revision, TextAsset dependency)
        {
            var go = new GameObject(Path.GetFileNameWithoutExtension(path));
            try
            {
                var serialized = new SerializedObject(go.AddComponent(Type.GetType(MarkerType)));
                serialized.FindProperty("revision").stringValue = revision;
                serialized.FindProperty("dependency").objectReferenceValue = dependency;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                Assert.IsNotNull(PrefabUtility.SaveAsPrefabAsset(go, path));
            }
            finally { UnityEngine.Object.DestroyImmediate(go); }
        }

        [Test]
        public void GuideStepsBuildAPlayerWithItsPackagedRevision()
        {
            string player = Environment.GetEnvironmentVariable("MANAGED_CHAIN_PLAYER");
            if (string.IsNullOrWhiteSpace(player)) Assert.Ignore("Builds a Windows Player; run through Tests/Fixtures~/Run-RevisionHost.ps1. NOT_RUN.");
            // The local static server the runner starts stands in for the game server.
            string hostUrl = Environment.GetEnvironmentVariable("MANAGED_CHAIN_HOST_URL");
            string hostRoot = Environment.GetEnvironmentVariable("MANAGED_CHAIN_HOST_ROOT");
            string pointerFile = Environment.GetEnvironmentVariable("MANAGED_CHAIN_POINTER_FILE");
            Assert.IsFalse(string.IsNullOrWhiteSpace(hostUrl) || string.IsNullOrWhiteSpace(hostRoot) || string.IsNullOrWhiteSpace(pointerFile),
                "Run-RevisionHost.ps1 sets the local host URL, folder and pointer file.");
            Assert.IsTrue(new Uri(hostUrl).IsLoopback, "The chain host must be this PC.");
            Assert.IsNotNull(Type.GetType(MarkerType), "The Revision Host fixture is required.");
            Assert.IsNotNull(Type.GetType(DriverType), "The Revision Host fixture is required.");
            Assert.IsFalse(File.Exists(ManagedAddressableProjectConfig.DefaultAssetPath), "Use a fresh Revision Host.");
            Assert.AreEqual(BuildTarget.StandaloneWindows64, EditorUserBuildSettings.activeBuildTarget);

            PlayerSettings.companyName = "JJEvolFrameworkQA";
            PlayerSettings.productName = Environment.GetEnvironmentVariable("MANAGED_CHAIN_PRODUCT") ?? "ManagedChain";

            // Scenes are part of the content fingerprint, so they come before any content build.
            Directory.CreateDirectory(Root);
            AssetDatabase.Refresh();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            new GameObject("Chain").AddComponent(Type.GetType(DriverType));
            Assert.IsTrue(EditorSceneManager.SaveScene(scene, ScenePath));
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Guide 1: game folders, then a Config over them.
            var bootText = Text(Content + "/Local/Core/ChainBootText.txt", "BOOT");
            var gameRules = Text(Content + "/Remote/Game/ChainGameRules.txt", "A");
            MarkerPrefab(Content + "/Local/Core/ChainBootPrefab.prefab", "BOOT", bootText);
            MarkerPrefab(Content + "/Remote/Game/ChainGamePrefab.prefab", "A", gameRules);
            Directory.CreateDirectory(Path.GetDirectoryName(ManagedAddressableProjectConfig.DefaultAssetPath));
            AssetDatabase.Refresh();
            var config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.buildOutputRoot = "C";
            AssetDatabase.CreateAsset(config, ManagedAddressableProjectConfig.DefaultAssetPath);
            config.SetContentRoot(Content);
            config.autoRegister = true;
            config.createGroupIfMissing = true;
            config.allowDevelopmentHttp = true;
            AssetDatabase.SaveAssets();

            // Guide 2-3: Preview Registration, Apply, then the remote root (here the local host, plain http in a Development Build).
            Apply(config, ManagedAddressableSynchronizer.CreatePlan(config));
            var settings = AddressableAssetSettingsDefaultObject.Settings;
            Assert.IsNotNull(settings, "The first Sync creates SDK Settings.");
            settings.profileSettings.SetValue(settings.activeProfileId, AddressableAssetSettings.kRemoteLoadPath, hostUrl.TrimEnd('/') + "/chain");
            EditorUtility.SetDirty(settings);
            AssetDatabase.SaveAssets();

            // Guide 4: roles and release values once.
            var suggestion = ManagedAddressableSynchronizer.SuggestBuildRoles(config, null, null);
            Assert.IsEmpty(suggestion.undecidedGroups);
            Apply(config, ManagedAddressableSynchronizer.CreateBuildRolePlan(config, suggestion.roles, suggestion.bootKeys));
            var release = new ManagedRevisionReleaseMetadata { productId = "framework.chain", channel = "qa", authorityId = "framework-qa", compatibilityFamily = "F", deploymentSequence = 1 };
            Apply(config, ManagedAddressableSynchronizer.CreateRevisionReleasePlan(config, release));

            // Guide 5: App Build, with its real Player step: sync, sequence, Revision, Config save,
            // packaged A, then the Player build that makes Boot itself and adds the packaged A.
            AssetDatabase.SaveAssets();
            var app = ManagedAppBuild.Build(player, true);
            Assert.IsTrue(app.Succeeded, app.ToString());
            Assert.AreEqual(2, app.DeploymentSequence, "Saved 1 and no earlier Revision: a development build takes 2.");
            Assert.AreEqual(Path.GetFullPath(player), app.OutputPath);
            string metadata = app.PackagedRevisionPath;
            Assert.AreEqual(2, JsonUtility.FromJson<ManagedPackagedRevisionAnchor>(File.ReadAllText(metadata)).deploymentSequence);

            string data = Path.Combine(Path.GetDirectoryName(player), Path.GetFileNameWithoutExtension(player) + "_Data", "StreamingAssets");
            Assert.IsTrue(Directory.Exists(Path.Combine(data, "aa")), "The Player must contain the Boot content.");
            string staged = Path.Combine(data, ManagedAddressableBuildExporter.PackagedRevisionStreamingRoot);
            string source = Path.GetDirectoryName(metadata);
            Assert.AreEqual(Sha(metadata), Sha(Path.Combine(staged, "packaged_revision.json")));
            foreach (var file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
                Assert.AreEqual(Sha(file), Sha(Path.Combine(staged, file.Substring(source.Length + 1))), "Player copy differs: " + file);

            // Guide 7: edit Revision content only, build B with the next sequence, publish it to the local host.
            // The Player above is not rebuilt; B must reach it through the pointer.
            Text(Content + "/Remote/Game/ChainGameRules.txt", "B");
            MarkerPrefab(Content + "/Remote/Game/ChainGamePrefab.prefab", "B", AssetDatabase.LoadAssetAtPath<TextAsset>(Content + "/Remote/Game/ChainGameRules.txt"));
            AssetDatabase.SaveAssets();
            config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ManagedAddressableProjectConfig.DefaultAssetPath);
            release.deploymentSequence = app.DeploymentSequence + 1;
            Apply(config, ManagedAddressableSynchronizer.CreateRevisionReleasePlan(config, release));
            var bPlan = ManagedAddressableBuildExporter.CreateSplitBuildPlan(config, ManagedGroupBuildRole.Revision);
            Assert.IsTrue(bPlan.CanBuild, bPlan.Report.ToString());
            var b = ManagedAddressableBuildExporter.BuildReviewedSplitContent(config, bPlan);
            Assert.IsTrue(b.success, b.error);
            config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ManagedAddressableProjectConfig.DefaultAssetPath);
            var publish = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, b.splitReceiptPath, hostRoot);
            Assert.IsTrue(publish.CanApply, publish.ToString());
            Assert.IsFalse(publish.alreadyPublished);
            string pointerUrl = ManagedAddressableBuildExporter.ApplyLocalHostPublishPlan(config, publish);
            var pointer = ManagedRevisionLocalHostPointer.Parse(File.ReadAllText(publish.pointerPath));
            Assert.AreEqual(3, pointer.deploymentSequence);
            Assert.AreEqual("qa", pointer.channel);
            Assert.AreNotEqual(JsonUtility.FromJson<ManagedPackagedRevisionAnchor>(File.ReadAllText(metadata)).revisionId, pointer.revisionId);
            Assert.That(pointerUrl, Does.StartWith(hostUrl.TrimEnd('/') + "/chain/split/latest/"));
            // Publishing the same build again changes nothing.
            var again = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, b.splitReceiptPath, hostRoot);
            Assert.IsTrue(again.CanApply && again.alreadyPublished, again.ToString());
            File.WriteAllText(pointerFile, pointerUrl);
        }
    }
}
