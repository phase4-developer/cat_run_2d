using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedAddressableCategoryDiscoveryTests
    {
        private string root;

        [SetUp]
        public void SetUp()
        {
            root = Path.Combine(Path.GetTempPath(), "ArtressManagedAddressablesTests", Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(root))
                Directory.Delete(root, true);
        }

        [Test]
        public void DefaultCategoryUsesReservedFolderPackTogetherPolicy()
        {
            Directory.CreateDirectory(Path.Combine(root, "Remote", "Character"));
            File.WriteAllText(Path.Combine(root, "Remote", "Character", "Character_1.prefab"), string.Empty);

            ManagedCategoryRule rule = ManagedAddressableCategoryDiscovery.Discover(root)
                .Single(value => value.relativePath == "Remote/Character");

            Assert.AreEqual(ManagedGroupStrategy.ReservedFolder, rule.groupStrategy);
            Assert.AreEqual("Remote_Character", rule.groupNamePattern);
            Assert.AreEqual(BundledAssetGroupSchema.BundlePackingMode.PackTogether, rule.bundleMode);
        }

        [Test]
        public void DetectPreservesNestedManualRules()
        {
            Directory.CreateDirectory(Path.Combine(root, "Remote", "Character"));
            List<ManagedCategoryRule> existing = new List<ManagedCategoryRule>
            {
                new ManagedCategoryRule
                {
                    relativePath = "Remote/Character/Boss",
                    delivery = ManagedDeliveryMode.Remote,
                    groupStrategy = ManagedGroupStrategy.SingleGroup,
                    groupNamePattern = "Remote_Character_Boss_Manual",
                    bundleMode = BundledAssetGroupSchema.BundlePackingMode.PackTogether
                }
            };

            List<ManagedCategoryRule> rules = ManagedAddressableCategoryDiscovery.Discover(root, existing);
            ManagedCategoryRule nested = rules.Single(value => value.relativePath == "Remote/Character/Boss");

            Assert.AreEqual("Remote_Character_Boss_Manual", nested.groupNamePattern);
            Assert.AreEqual(ManagedGroupStrategy.SingleGroup, nested.groupStrategy);
        }
    }
}
