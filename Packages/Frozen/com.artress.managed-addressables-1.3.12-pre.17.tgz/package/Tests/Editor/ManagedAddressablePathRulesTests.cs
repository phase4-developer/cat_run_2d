using NUnit.Framework;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedAddressablePathRulesTests
    {
        private ManagedCategoryRule rule;

        [SetUp]
        public void SetUp()
        {
            rule = new ManagedCategoryRule
            {
                relativePath = "Remote/Character",
                delivery = ManagedDeliveryMode.Remote,
                groupStrategy = ManagedGroupStrategy.ReservedFolder,
                groupNamePattern = "Remote_Character",
                bundleMode = BundledAssetGroupSchema.BundlePackingMode.PackTogether
            };
        }

        [Test]
        public void BaseContentUsesCategoryGroupAndOriginalAddressPath()
        {
            ManagedAddressablePathResolution result = ManagedAddressablePathRules.Resolve("Remote/Character/Enemy/Boss.prefab", rule, "Update");

            Assert.IsTrue(result.IsValid);
            Assert.AreEqual("Remote_Character", result.groupName);
            Assert.AreEqual("Enemy/Boss.prefab", result.addressPathAfterCategory);
            Assert.IsFalse(result.isUpdateContent);
        }

        [Test]
        public void UpdateContentUsesBundleKeyGroupAndStripsManagementFoldersFromAddress()
        {
            ManagedAddressablePathResolution result = ManagedAddressablePathRules.Resolve("Remote/Character/Update/101000009/UI/Ana.prefab", rule, "Update");

            Assert.IsTrue(result.IsValid);
            Assert.AreEqual("Remote_Character_101000009", result.groupName);
            Assert.AreEqual("UI/Ana.prefab", result.addressPathAfterCategory);
            Assert.AreEqual("101000009", result.bundleKey);
        }


        [Test]
        public void VersionBundleKeyCreatesOneUpdateGroupAndCharAddress()
        {
            ManagedAddressablePathResolution result = ManagedAddressablePathRules.Resolve("Remote/Character/Update/1.0.1/Char_6.prefab", rule, "Update");

            Assert.IsTrue(result.IsValid);
            Assert.AreEqual("Remote_Character_1.0.1", result.groupName);
            Assert.AreEqual("Char_6.prefab", result.addressPathAfterCategory);
            string address = ManagedAddressNaming.BuildAddress("Character", result.addressPathAfterCategory, "Assets/Game/Addressables/Remote/Character/Update/1.0.1/Char_6.prefab", false, "_", new string[0]);
            Assert.AreEqual("Char_6", address);
        }

        [Test]
        public void FileDirectlyUnderUpdateIsInvalid()
        {
            ManagedAddressablePathResolution result = ManagedAddressablePathRules.Resolve("Remote/Character/Update/Ana.prefab", rule, "Update");

            Assert.IsFalse(result.IsValid);
            StringAssert.Contains("BundleKey", result.error);
        }
    }
}
