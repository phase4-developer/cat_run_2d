using NUnit.Framework;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedGroupStrategyCompatibilityTests
    {
        [Test]
        public void ExistingSerializedValuesRemainStable()
        {
            Assert.AreEqual(0, (int)ManagedGroupStrategy.SingleGroup);
            Assert.AreEqual(1, (int)ManagedGroupStrategy.FirstSubfolder);
            Assert.AreEqual(2, (int)ManagedGroupStrategy.FolderDepth);
            Assert.AreEqual(3, (int)ManagedGroupStrategy.PreserveExistingGroup);
            Assert.AreEqual(4, (int)ManagedGroupStrategy.ReservedFolder);
        }
    }
}
