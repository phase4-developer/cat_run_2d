using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // Independent G2 behavior checks. No production authoring implementation is copied here.
    public sealed class ManagedAR2G2IntegrationTests
    {
        static readonly BindingFlags Static = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;

        internal static IList<string> Owned(ManagedAddressableProjectConfig config)
        {
            var field = typeof(ManagedAddressableProjectConfig).GetField("ownedGroupGuids");
            Assert.IsNotNull(field, "G2 requires an explicit Config group asset GUID list.");
            var value = field.GetValue(config) as IList<string>;
            Assert.IsNotNull(value);
            return value;
        }

        // A fixture's explicitly chosen starting ownership, not an automatic adoption command.
        internal static void ExplicitlyOwnGroupForFixture(ManagedAddressableProjectConfig config, AddressableAssetGroup group)
        {
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
            Assert.IsNotEmpty(guid);
            if (!Owned(config).Contains(guid)) Owned(config).Add(guid);
            EditorUtility.SetDirty(config);
        }

        internal static string CaptureGroup(AddressableAssetGroup group)
        {
            return EditorJsonUtility.ToJson(group) + "\n" + string.Join("\n", group.Schemas.Where(s => s != null)
                .OrderBy(s => AssetDatabase.GetAssetPath(s), StringComparer.Ordinal).Select(s => EditorJsonUtility.ToJson(s)));
        }

        static ManagedAddressableSyncPlan OwnershipPlan(ManagedAddressableProjectConfig config,
            IEnumerable<AddressableAssetGroup> adopt = null, IEnumerable<string> release = null, bool removeMissing = false)
        {
            var method = typeof(ManagedAddressableSynchronizer).GetMethod("CreateOwnershipPlan", Static);
            Assert.IsNotNull(method, "G2 explicit adoption/release/cleanup plan API is required.");
            try { return (ManagedAddressableSyncPlan)method.Invoke(null, new object[] { config, adopt, release, removeMissing }); }
            catch (TargetInvocationException ex) { ExceptionDispatchInfo.Capture(ex.InnerException ?? ex).Throw(); throw; }
        }

        static IEnumerable<string> Warnings(ManagedAddressableSyncPlan plan)
        {
            var property = typeof(ManagedAddressableSyncPlan).GetProperty("Warnings");
            Assert.IsNotNull(property, "Missing ownership references need visible, non-blocking warnings.");
            return (IEnumerable<string>)property.GetValue(plan);
        }

        static Dictionary<string, string> Files(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories)
            .ToDictionary(p => p.Replace('\\', '/'), p => Convert.ToBase64String(File.ReadAllBytes(p)));

        static void SameExcept(Dictionary<string, string> before, Dictionary<string, string> after, string allowed)
        {
            CollectionAssert.AreEquivalent(before.Keys, after.Keys);
            foreach (var pair in before)
                if (pair.Key != allowed.Replace('\\', '/')) Assert.AreEqual(pair.Value, after[pair.Key], pair.Key);
        }

        [Test]
        public void ConfigDoesNotAdoptOrNormalizeOfficialGroups()
        {
            AssertForeignSdkSchemaAcceptedWithoutMutation();
        }

        internal static void AssertForeignSdkSchemaAcceptedWithoutMutation()
        {
            using (var f = new Fixture())
            {
                var official = f.Group("Official Analyze Group");
                var schema = official.GetSchema<BundledAssetGroupSchema>();
                schema.BundleNaming = BundledAssetGroupSchema.BundleNamingStyle.AppendHash;
                schema.InternalBundleIdMode = BundledAssetGroupSchema.BundleInternalIdMode.GroupGuidProjectIdHash;
                schema.BundleMode = BundledAssetGroupSchema.BundlePackingMode.PackSeparately;
                schema.UseAssetBundleCache = true; schema.UseAssetBundleCrc = true; schema.UseAssetBundleCrcForCachedBundles = true;
                string profile = f.Settings.profileSettings.AddProfile("Official Profile", f.Settings.activeProfileId);
                f.Settings.activeProfileId = profile;
                f.Settings.MaxConcurrentWebRequests = 7;
                AssetDatabase.SaveAssets();
                string groupBefore = CaptureGroup(official), profileBefore = JsonUtility.ToJson(f.Settings.profileSettings);
                var before = Files(f.Root); var notifications = new List<string>();
                Action<AddressableAssetSettings, AddressableAssetSettings.ModificationEvent, object> onChange =
                    (sender, change, data) => { if (sender == f.Settings) notifications.Add(change.ToString()); };
                AddressableAssetSettings.OnModificationGlobal += onChange;
                try
                {
                    var plan = ManagedAddressableSynchronizer.CreatePlan(f.Config);
                    Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges));
                    CollectionAssert.AreEquivalent(before, Files(f.Root));
                    ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                    Assert.AreEqual(groupBefore, CaptureGroup(official));
                    Assert.AreEqual(profileBefore, JsonUtility.ToJson(f.Settings.profileSettings));
                    Assert.AreEqual(profile, f.Settings.activeProfileId);
                    Assert.AreEqual(7, f.Settings.MaxConcurrentWebRequests);
                    CollectionAssert.IsEmpty(Owned(f.Config), "Old Config must not adopt by group name or schema similarity.");
                    CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(f.Config));
                    notifications.Clear(); before = Files(f.Root);
                    var repeat = ManagedAddressableSynchronizer.CreatePlan(f.Config);
                    Assert.IsFalse(repeat.HasChanges);
                    ManagedAddressableSynchronizer.ApplyPlan(f.Config, repeat);
                    CollectionAssert.AreEquivalent(before, Files(f.Root)); CollectionAssert.IsEmpty(notifications);
                }
                finally { AddressableAssetSettings.OnModificationGlobal -= onChange; }
            }
        }

        [Test]
        public void AdoptionPreviewThenApplyChangesOnlyExplicitConfigOwnership()
        {
            using (var f = new Fixture())
            {
                var group = f.Group("Official Group To Adopt"); AssetDatabase.SaveAssets();
                string assetGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
                string groupBefore = CaptureGroup(group); var before = Files(f.Root);
                var plan = OwnershipPlan(f.Config, new[] { group });
                Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges)); Assert.IsTrue(plan.HasChanges);
                CollectionAssert.IsEmpty(Owned(f.Config)); CollectionAssert.AreEquivalent(before, Files(f.Root));
                Assert.IsTrue(plan.Changes.Any(c => (c.before ?? "").Contains(assetGuid) || (c.after ?? "").Contains(assetGuid)), "Preview must identify the actual group asset GUID being adopted.");
                var report = ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                Assert.AreEqual(plan.Report.ToString(), report.ToString()); CollectionAssert.AreEqual(new[] { assetGuid }, Owned(f.Config));
                Assert.AreEqual(groupBefore, CaptureGroup(group)); SameExcept(before, Files(f.Root), f.ConfigPath);
                if (assetGuid != group.Guid) CollectionAssert.DoesNotContain(Owned(f.Config), group.Guid, "Internal group.Guid is not the ownership identifier.");
                var noOp = OwnershipPlan(f.Config, new[] { group }); Assert.IsFalse(noOp.HasChanges);
                before = Files(f.Root); ManagedAddressableSynchronizer.ApplyPlan(f.Config, noOp); CollectionAssert.AreEquivalent(before, Files(f.Root));
            }
        }

        [Test]
        public void MissingOwnershipGuidWarnsAndRequiresExplicitCleanup()
        {
            using (var f = new Fixture())
            {
                string missing = Guid.NewGuid().ToString("N"); Assert.IsEmpty(AssetDatabase.GUIDToAssetPath(missing));
                Owned(f.Config).Add(missing); EditorUtility.SetDirty(f.Config); AssetDatabase.SaveAssets();
                var before = Files(f.Root);
                var plan = ManagedAddressableSynchronizer.CreatePlan(f.Config);
                Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges)); Assert.IsTrue(Warnings(plan).Any());
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                CollectionAssert.Contains(Owned(f.Config), missing, "Regular Sync must not silently drop an unresolved GUID.");
                CollectionAssert.AreEquivalent(before, Files(f.Root));
                var cleanup = OwnershipPlan(f.Config, removeMissing: true); Assert.IsTrue(cleanup.CanApply); Assert.IsTrue(cleanup.HasChanges);
                CollectionAssert.Contains(Owned(f.Config), missing); CollectionAssert.AreEquivalent(before, Files(f.Root));
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, cleanup); CollectionAssert.DoesNotContain(Owned(f.Config), missing);
                SameExcept(before, Files(f.Root), f.ConfigPath);
            }
        }

        [Test]
        public void ReviewedAdoptionRejectsChangedExternalSchemaBeforeWritingConfig()
        {
            using (var f = new Fixture())
            {
                var group = f.Group("Official Changed After Review"); AssetDatabase.SaveAssets();
                var reviewed = OwnershipPlan(f.Config, new[] { group });
                group.GetSchema<BundledAssetGroupSchema>().BundleMode = BundledAssetGroupSchema.BundlePackingMode.PackSeparately;
                EditorUtility.SetDirty(group.GetSchema<BundledAssetGroupSchema>()); AssetDatabase.SaveAssets();
                var before = Files(f.Root);
                Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(f.Config, reviewed));
                CollectionAssert.AreEquivalent(before, Files(f.Root)); CollectionAssert.IsEmpty(Owned(f.Config));
                Assert.AreEqual(BundledAssetGroupSchema.BundlePackingMode.PackSeparately, group.GetSchema<BundledAssetGroupSchema>().BundleMode);
            }
        }

        internal static void AssertOwnedAddressConflictStillRejected()
        {
            using (var f = new Fixture())
            {
                var group = f.Group("Explicitly Owned Address Risk"); ExplicitlyOwnGroupForFixture(f.Config, group);
                foreach (string name in new[] { "A", "B" })
                {
                    string path = f.Root + "/" + name + ".txt"; File.WriteAllText(path, name); AssetDatabase.Refresh();
                    f.Settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), group, false, false).SetAddress("owned.duplicate", false);
                }
                AssetDatabase.SaveAssets(); var before = Files(f.Root);
                Assert.IsTrue(ManagedAddressableValidator.Validate(f.Config).Any(error => error.Contains("owned.duplicate")), "Legal SDK schema acceptance must not hide an owned address collision.");
                CollectionAssert.AreEquivalent(before, Files(f.Root));
            }
        }

        internal static void AssertOfficialLocalizationCollectionPreservedWithoutPolicyRepair()
        {
            Type editor = AppDomain.CurrentDomain.GetAssemblies().Select(a => a.GetType("UnityEditor.Localization.LocalizationEditorSettings", false)).FirstOrDefault(t => t != null);
            Type localeType = AppDomain.CurrentDomain.GetAssemblies().Select(a => a.GetType("UnityEngine.Localization.Locale", false)).FirstOrDefault(t => t != null);
            if (editor == null || localeType == null) Assert.Ignore("Optional Unity Localization SDK is not installed; actual collection path is NOT_RUN.");
            using (var f = new Fixture())
            {
                var locale = (Object)localeType.GetMethod("CreateLocale", new[] { typeof(string) }).Invoke(null, new object[] { "en" });
                AssetDatabase.CreateAsset(locale, f.Root + "/English.asset");
                var locales = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(localeType)); locales.Add(locale);
                var create = editor.GetMethods(BindingFlags.Public | BindingFlags.Static).Single(m => m.Name == "CreateStringTableCollection" && m.GetParameters().Length == 3);
                var collection = (Object)create.Invoke(null, new object[] { "G2_" + Guid.NewGuid().ToString("N"), f.Root + "/Tables", locales });
                Assert.IsNotNull(collection); EditorUtility.SetDirty(f.Config); AssetDatabase.SaveAssets();
                var groups = f.Settings.groups.Where(g => g != null).ToDictionary(g => g, CaptureGroup);
                var before = Files(f.Root); var plan = ManagedAddressableSynchronizer.CreatePlan(f.Config);
                Assert.IsTrue(plan.CanApply, string.Join("\n", plan.BlockedChanges)); CollectionAssert.AreEquivalent(before, Files(f.Root));
                var report = ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan); Assert.AreEqual(plan.Report.ToString(), report.ToString());
                foreach (var group in groups) Assert.AreEqual(group.Value, CaptureGroup(group.Key), group.Key.Name);
                CollectionAssert.IsEmpty(Owned(f.Config)); CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(f.Config));
                var notifications = new List<string>();
                Action<AddressableAssetSettings, AddressableAssetSettings.ModificationEvent, object> callback = (sender, change, data) => { if (sender == f.Settings) notifications.Add(change.ToString()); };
                AddressableAssetSettings.OnModificationGlobal += callback;
                try
                {
                    before = Files(f.Root); var repeat = ManagedAddressableSynchronizer.CreatePlan(f.Config); Assert.IsFalse(repeat.HasChanges);
                    ManagedAddressableSynchronizer.ApplyPlan(f.Config, repeat); CollectionAssert.AreEquivalent(before, Files(f.Root)); CollectionAssert.IsEmpty(notifications);
                    foreach (var group in groups) Assert.AreEqual(group.Value, CaptureGroup(group.Key));
                }
                finally { AddressableAssetSettings.OnModificationGlobal -= callback; }
            }
        }

        sealed class Fixture : IDisposable
        {
            static readonly FieldInfo Default = typeof(AddressableAssetSettingsDefaultObject).GetField("s_DefaultSettingsObject", Static);
            readonly AddressableAssetSettings previous;
            public string Root { get; }
            public string ConfigPath => Root + "/Config.asset";
            public AddressableAssetSettings Settings { get; }
            public ManagedAddressableProjectConfig Config { get; }
            public Fixture()
            {
                previous = AddressableAssetSettingsDefaultObject.Settings; ManagedFrameworkHostTests.ImportCallback(previous, false);
                Root = "Assets/ManagedG2Independent_" + Guid.NewGuid().ToString("N"); Directory.CreateDirectory(Root + "/Content"); AssetDatabase.Refresh();
                Settings = AddressableAssetSettings.Create(Root + "/Settings", "Settings", false, true); Default.SetValue(null, Settings); Group("Official Default", true);
                Config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>(); Config.SetContentRoot(Root + "/Content"); Config.backupBeforeApply = false;
                AssetDatabase.CreateAsset(Config, ConfigPath); AssetDatabase.SaveAssets();
            }
            public AddressableAssetGroup Group(string name, bool isDefault = false) => Settings.CreateGroup(name, isDefault, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
            public void Dispose()
            {
                ManagedFrameworkHostTests.ImportCallback(Settings, false); Default.SetValue(null, previous); AssetDatabase.DeleteAsset(Root);
                ManagedFrameworkHostTests.ImportCallback(previous, true);
            }
        }
    }
}
