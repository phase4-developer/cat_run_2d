using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;
using UnityEngine.AddressableAssets.ResourceProviders;
using Object = UnityEngine.Object;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedPre8EditorContractsTests
    {
        private static ManagedRevisionReleaseMetadata Release(long sequence = 20) => new ManagedRevisionReleaseMetadata
        { productId = "qa-product", channel = "qa", authorityId = "qa-authority", compatibilityFamily = "F", deploymentSequence = sequence };
        private static void SaveConfig(ManagedBootstrapSplitFixture f) { EditorUtility.SetDirty(f.Config); AssetDatabase.SaveAssetIfDirty(f.Config); }
        private static void Roles(ManagedBootstrapSplitFixture f) => ManagedAddressableSynchronizer.ApplyPlan(f.Config, f.RolePlan());

        [Test]
        public void OneRolePreviewExplicitlyListsRequiredAdoptionAndChangesConfigOnly()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                f.Config.ownedGroupGuids.Clear(); SaveConfig(f);
                var files = f.Files(); string boot = f.GroupState(f.Boot), revision = f.GroupState(f.Revision);
                var plan = f.RolePlan();
                Assert.IsTrue(plan.CanApply, plan.Report.ToString());
                Assert.AreEqual(2, plan.Changes.Count(c => c.property.Contains("explicit build adoption")));
                Assert.IsTrue(plan.Changes.Any(c => c.property.StartsWith("groupBuildRoles")));
                ManagedBootstrapSplitFixture.Same(files, f.Files());
                Assert.IsFalse(EditorUtility.IsDirty(f.Config));
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                CollectionAssert.AreEquivalent(f.Roles().Select(r => r.groupAssetGuid), f.Config.ownedGroupGuids);
                Assert.AreEqual(boot, f.GroupState(f.Boot)); Assert.AreEqual(revision, f.GroupState(f.Revision));
                f.AssertOriginalEntries(); ManagedBootstrapSplitFixture.Same(files, f.Files(), f.ConfigPath);
                Assert.IsFalse(f.RolePlan().HasChanges);
            }
        }

        [Test]
        public void DisabledAdoptionKeepsExternalGroupAndNamesTheBlockedBuilds()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                f.Config.ownedGroupGuids.Clear(); SaveConfig(f);
                var plan = ManagedAddressableSynchronizer.CreateBuildRolePlan(f.Config, f.Roles(), new[] { ManagedBootstrapSplitFixture.BootKey }, Array.Empty<string>());
                Assert.IsTrue(plan.CanApply); StringAssert.Contains("Adoption disabled", string.Join("\n", plan.Warnings));
                StringAssert.Contains("Boot/Revision", string.Join("\n", plan.Warnings));
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan); Assert.IsEmpty(f.Config.ownedGroupGuids);
                Assert.That(ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, ManagedGroupBuildRole.Boot).ToString(), Does.Contain("Explicit adoption"));
            }
        }

        [Test]
        public void ReadOnlyAdoptionIsBlockedWithoutEditingItsGroupOrSchema()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                f.Config.ownedGroupGuids.Clear(); SaveConfig(f);
                var serialized = new SerializedObject(f.Boot); serialized.FindProperty("m_ReadOnly").boolValue = true; serialized.ApplyModifiedPropertiesWithoutUndo(); AssetDatabase.SaveAssetIfDirty(f.Boot);
                var before = f.Files(); var plan = f.RolePlan();
                Assert.IsFalse(plan.CanApply); Assert.That(plan.Report.ToString(), Does.Contain("ReadOnly"));
                ManagedBootstrapSplitFixture.Same(before, f.Files());
                Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan));
            }
        }

        [Test]
        public void RoleAndReleaseReviewBothRejectForeignSchemaChanges()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var role = f.RolePlan(); var release = ManagedAddressableSynchronizer.CreateRevisionReleasePlan(f.Config, Release());
                var schema = f.Revision.GetSchema<BundledAssetGroupSchema>(); schema.Timeout++; AssetDatabase.SaveAssetIfDirty(schema);
                var before = f.Files();
                Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(f.Config, role));
                Assert.Throws<InvalidOperationException>(() => ManagedAddressableSynchronizer.ApplyPlan(f.Config, release));
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        [TestCase("shared")]
        [TestCase("local")]
        [TestCase("link")]
        public void ContentGenerationExcludesOnlyReleaseFieldsFromLiveAndRawConfig(string field)
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Roles(f); _ = f.Settings.currentHash;
                string content = ManagedAddressableBuildExporter.SplitContentFingerprint(f.Config, f.Settings);
                string strict = ManagedAddressableBuildExporter.SplitFingerprint(f.Config, f.Settings);
                string raw = ManagedAddressableSynchronizer.SplitContentConfigFile(f.ConfigPath);
                if (field == "shared") { var r = Release(); f.Config.revisionShared = new ManagedRevisionSharedRelease { productId = r.productId, authorityId = r.authorityId, compatibilityFamily = r.compatibilityFamily }; SaveConfig(f); }
                else if (field == "local") { var local = ManagedLocalRelease.Read(f.Config); local.channel = "qa"; local.deploymentSequence = 20; ManagedLocalRelease.Write(f.Config, local); }
                else ManagedLocalRelease.SetPackaged(f.Config, EditorUserBuildSettings.activeBuildTarget.ToString(), "P2/reviewed/Payload/packaged_revision.json", new string('a', 64));
                Assert.AreEqual(raw, ManagedAddressableSynchronizer.SplitContentConfigFile(f.ConfigPath), "Raw Config normalization is required as well as JSON.");
                Assert.AreEqual(content, ManagedAddressableBuildExporter.SplitContentFingerprint(f.Config, f.Settings));
                Assert.AreNotEqual(strict, ManagedAddressableBuildExporter.SplitFingerprint(f.Config, f.Settings), "Player stale protection must retain all release/link inputs.");
            }
        }

        // A consumer game project's Player build always rejected its app-included Revision A: the Boot step
        // reads currentHash, which fills the serialized m_currentHash cache that the Revision bake left empty.
        [Test]
        public void SettingsHashCacheDoesNotChangeTheGeneration()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Roles(f);
                var cache = typeof(AddressableAssetSettings).GetField("m_currentHash", BindingFlags.NonPublic | BindingFlags.Instance);
                Assert.IsNotNull(cache, "Addressables renamed its settings hash cache; recheck the fingerprint exclusion.");
                cache.SetValue(f.Settings, default(Hash128));
                string content = ManagedAddressableBuildExporter.SplitContentFingerprint(f.Config, f.Settings);
                string strict = ManagedAddressableBuildExporter.SplitFingerprint(f.Config, f.Settings);
                _ = f.Settings.currentHash;
                Assert.IsTrue(((Hash128)cache.GetValue(f.Settings)).isValid);
                Assert.AreEqual(content, ManagedAddressableBuildExporter.SplitContentFingerprint(f.Config, f.Settings));
                Assert.AreEqual(strict, ManagedAddressableBuildExporter.SplitFingerprint(f.Config, f.Settings));
            }
        }

        [TestCase(true)] [TestCase(false)]
        public void RealConfigAndContentChangesStillChangeContentGeneration(bool configChange)
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Roles(f); string before = ManagedAddressableBuildExporter.SplitContentFingerprint(f.Config, f.Settings);
                if (configChange) { f.Config.preserveExistingAddressesOnSync = !f.Config.preserveExistingAddressesOnSync; SaveConfig(f); }
                else { string path = f.Root + "/Content/Game.txt"; File.AppendAllText(path, "actual content changed"); AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport); }
                Assert.AreNotEqual(before, ManagedAddressableBuildExporter.SplitContentFingerprint(f.Config, f.Settings));
            }
        }

        [Test]
        public void ReleasePreviewWritesOnlyReviewedConfigAndRepeatIsNoOp()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var before = f.Files(); var plan = ManagedAddressableSynchronizer.CreateRevisionReleasePlan(f.Config, Release());
                Assert.IsTrue(plan.CanApply, plan.Report.ToString()); ManagedBootstrapSplitFixture.Same(before, f.Files());
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan); Assert.AreEqual(20, ManagedLocalRelease.Effective(f.Config).deploymentSequence);
                ManagedBootstrapSplitFixture.Same(before, f.Files(), f.ConfigPath);
                Assert.IsFalse(ManagedAddressableSynchronizer.CreateRevisionReleasePlan(f.Config, Release()).HasChanges);
                Assert.IsTrue(ManagedAddressableBuildExporter.ValidateRevisionReleasePrebuild(f.Config).CanBuild);
            }
        }

        [Test]
        public void EditingTheReleaseDraftDoesNotMutateTheReviewedValues()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var draft = Release(); var plan = ManagedAddressableSynchronizer.CreateRevisionReleasePlan(f.Config, draft);
                draft.deploymentSequence = 999;
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan);
                Assert.AreEqual(20, ManagedLocalRelease.Effective(f.Config).deploymentSequence);
            }
        }

        [Test]
        public void EmptyReleaseIsBlockedBeforeControlCenterRevisionBuild()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var before = f.Files(); var report = ManagedAddressableBuildExporter.ValidateRevisionReleasePrebuild(f.Config);
                Assert.IsFalse(report.CanBuild); Assert.That(report.ToString(), Does.Contain("고급 > 배포 값"), "The block names where to fix it.");
                ManagedBootstrapSplitFixture.Same(before, f.Files()); Assert.AreEqual(0, ManagedLocalRelease.Effective(f.Config).deploymentSequence);
            }
        }

        [Test]
        public void LowerSequenceWarnsButNeverAllocatesOrBlocks()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                string platform = EditorUserBuildSettings.activeBuildTarget.ToString(), version = PlayerSettings.bundleVersion;
                string root = Path.Combine(f.Output, platform, version, "split/revision/previous"); Directory.CreateDirectory(root);
                string publisher = Path.GetFullPath(Path.Combine(root, "revision_publisher.json"));
                File.WriteAllText(publisher, JsonUtility.ToJson(new ManagedRevisionPublisher { productId = "qa-product", channel = "qa", authorityId = "qa-authority", compatibilityFamily = "F", deploymentSequence = 30 }));
                string receiptPath = Path.Combine(root, "split_build_receipt.json");
                File.WriteAllText(receiptPath, JsonConvert.SerializeObject(new ManagedSplitBuildReceipt { complete = true, purpose = "Revision", publisherPath = publisher, publisherSha256 = ManagedAddressableBuildExporter.SplitFileHash(publisher) }));
                var plan = ManagedAddressableSynchronizer.CreateRevisionReleasePlan(f.Config, Release(20));
                Assert.IsTrue(plan.CanApply); Assert.That(string.Join("\n", plan.Warnings), Does.Contain("not above"));
                ManagedAddressableSynchronizer.ApplyPlan(f.Config, plan); Assert.AreEqual(20, ManagedLocalRelease.Effective(f.Config).deploymentSequence);
            }
        }

        [Test]
        public void MissingPackagedAHasNoProductionOptOut()
        {
            using (var f = new ManagedBootstrapSplitFixture())
            {
                var before = f.Files();
                var language = ManagedEditorText.Language;
                try
                {
                    ManagedEditorText.Language = ManagedEditorLanguage.Korean;
                    var error = Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.RequirePackagedRevisionLink(f.Config));
                    StringAssert.Contains("앱 포함 A", error.Message); StringAssert.Contains("앱 빌드", error.Message); StringAssert.Contains("앱 포함 A 미리 보기", error.Message);
                    ManagedEditorText.Language = ManagedEditorLanguage.English;
                    error = Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.RequirePackagedRevisionLink(f.Config));
                    StringAssert.Contains("App Build", error.Message); StringAssert.Contains("Preview App Included A", error.Message);
                }
                finally { ManagedEditorText.Language = language; }
                ManagedBootstrapSplitFixture.Same(before, f.Files());
            }
        }

        private static Object[] RecoveryValues(ManagedBootstrapSplitFixture f) => f.Settings.groups.Where(g => g != null)
            .SelectMany(g => g.Schemas.Cast<Object>().Append(g)).Append(f.Settings).Append(f.Config).Where(v => v != null).Distinct().ToArray();
        private static Dictionary<string, string> RecoveryLive(ManagedBootstrapSplitFixture f) => RecoveryValues(f)
            .ToDictionary(AssetDatabase.GetAssetPath, EditorJsonUtility.ToJson, StringComparer.Ordinal);
        private static Dictionary<string, bool> RecoveryDirty(ManagedBootstrapSplitFixture f) => RecoveryValues(f)
            .ToDictionary(AssetDatabase.GetAssetPath, EditorUtility.IsDirty, StringComparer.Ordinal);
        private static void SameLive(ManagedBootstrapSplitFixture f, Dictionary<string, string> live, Dictionary<string, bool> dirty)
        {
            CollectionAssert.AreEquivalent(live.Keys, RecoveryLive(f).Keys);
            foreach (var row in live)
            {
                var value = AssetDatabase.LoadMainAssetAtPath(row.Key);
                Assert.IsNotNull(value, row.Key);
                Assert.AreEqual(row.Value, EditorJsonUtility.ToJson(value), "Exact live JSON: " + row.Key);
                Assert.AreEqual(dirty[row.Key], EditorUtility.IsDirty(value), "Dirty state: " + row.Key);
            }
        }

        private static void AssertManualPendingGuidance(string text)
        {
            int backup = text.IndexOf("① pending 파일 백업", StringComparison.Ordinal);
            int inspect = text.IndexOf("② 설정 직접 확인", StringComparison.Ordinal);
            int remove = text.IndexOf("③ pending 파일 삭제", StringComparison.Ordinal);
            Assert.That(backup, Is.GreaterThanOrEqualTo(0)); Assert.That(inspect, Is.GreaterThan(backup)); Assert.That(remove, Is.GreaterThan(inspect));
            StringAssert.Contains(ManagedAddressableBuildExporter.PendingSplitSettingsPath, text);
            StringAssert.Contains(ManagedAddressableBuildExporter.PendingSplitSettingsPath + ".next", text);
        }

        [TestCase(ManagedGroupBuildRole.Boot, "restore")]
        [TestCase(ManagedGroupBuildRole.Revision, "restore")]
        [TestCase(ManagedGroupBuildRole.Boot, "stale-checkpoint")]
        [TestCase(ManagedGroupBuildRole.Revision, "stale-checkpoint")]
        [TestCase(ManagedGroupBuildRole.Boot, "user-conflict")]
        [TestCase(ManagedGroupBuildRole.Revision, "user-conflict")]
        public void ActualPurposeWritesRequireReviewedPendingRestoration(ManagedGroupBuildRole purpose, string scenario)
        {
            Assert.IsFalse(ManagedAddressableBuildExporter.HasPendingSplitSettings, "Never overwrite an existing owner's pending recovery.");
            using (var f = new ManagedBootstrapSplitFixture())
            {
                Roles(f);
                bool boot = purpose == ManagedGroupBuildRole.Boot;
                var foreign = f.Settings.CreateGroup("E2 unowned user group", false, false, false, null,
                    typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
                string foreignPath = AssetDatabase.GetAssetPath(foreign), foreignGuid = ManagedBootstrapSplitFixture.GuidOf(foreign);
                foreign.IncludeInBuild = boot;
                var foreignSchema = foreign.GetSchema<BundledAssetGroupSchema>(); foreignSchema.Timeout = 37;
                foreignSchema.UseDefaultSchemaSettings = false;
                foreignSchema.BuildPath.SetVariableByName(f.Settings, AddressableAssetSettings.kLocalBuildPath);
                foreignSchema.LoadPath.SetVariableByName(f.Settings, AddressableAssetSettings.kLocalLoadPath);
                Directory.CreateDirectory(f.Root + "/External");
                string externalAsset = f.Root + "/External/Untouched.txt";
                File.WriteAllText(externalAsset, "user-owned external entry"); AssetDatabase.ImportAsset(externalAsset, ImportAssetOptions.ForceSynchronousImport);
                string externalGuid = AssetDatabase.AssetPathToGUID(externalAsset);
                f.Settings.CreateOrMoveEntry(externalGuid, foreign, false, false).SetAddress("external.user.address", false);
                f.Config.groupBuildRoles.Add(new ManagedGroupBuildRoleSetting { groupAssetGuid = foreignGuid, role = ManagedGroupBuildRole.Boot });
                Assert.That(f.Config.ownedGroupGuids, Does.Not.Contain(foreignGuid), "A build role is not modification ownership.");
                string userProfile = f.Settings.profileSettings.AddProfile("E2 user profile", f.Settings.activeProfileId);
                f.Settings.profileSettings.CreateValue("E2.UserUnchanged", "original-default");
                f.Settings.profileSettings.SetValue(userProfile, "E2.UserUnchanged", "user-entered-unchanged");
                // Make the purpose's real Catalog/Include writes observable in both directions.
                f.Settings.CatalogProviderType = boot ? typeof(JsonCatalogProvider) : typeof(BinaryCatalogProvider);
                f.Settings.BuildRemoteCatalog = boot; f.Settings.BundleLocalCatalog = true;
                f.Settings.ContentStateBuildPath = f.Output + "/original-state";
                f.Boot.IncludeInBuild = true; f.Revision.IncludeInBuild = true;
                var revisionSchema = f.Revision.GetSchema<BundledAssetGroupSchema>();
                var originalValues = RecoveryValues(f);
                foreach (var value in originalValues) { EditorUtility.SetDirty(value); AssetDatabase.SaveAssetIfDirty(value); }
                string settingsPath = AssetDatabase.GetAssetPath(f.Settings), changedGroupPath = AssetDatabase.GetAssetPath(boot ? f.Revision : f.Boot);
                string schemaPath = AssetDatabase.GetAssetPath(revisionSchema);
                string bootGuid = ManagedBootstrapSplitFixture.GuidOf(f.Boot), revisionGuid = ManagedBootstrapSplitFixture.GuidOf(f.Revision);
                var before = f.Files(); string effective = ManagedBootstrapSplitSettingsScope.Effective(f.Settings);
                var liveBefore = RecoveryLive(f); var dirtyBefore = RecoveryDirty(f);
                Assert.IsFalse(dirtyBefore.Values.Any(value => value), "Recovery must begin from clean persistent inputs.");
                string foreignBefore = f.GroupState(foreign), profilesBefore = JsonUtility.ToJson(f.Settings.profileSettings);
                bool layoutBefore = ProjectConfigData.GenerateBuildLayout;
                var writeTargets = boot ? new Object[] { f.Boot, f.Revision } : new Object[] { f.Boot, f.Revision, revisionSchema };
                var scope = new ManagedBootstrapSplitSettingsScope(f.Settings, writeTargets);
                try
                {
                    scope.PersistBeforeTemporaryWrites();
                    Assert.IsTrue(File.Exists(ManagedAddressableBuildExporter.PendingSplitSettingsPath));
                    f.Settings.CatalogProviderType = boot ? typeof(BinaryCatalogProvider) : typeof(JsonCatalogProvider);
                    f.Settings.BuildRemoteCatalog = !boot; f.Settings.BundleLocalCatalog = false;
                    f.Settings.ContentStateBuildPath = f.Output + "/temporary-" + purpose;
                    f.Boot.IncludeInBuild = boot; f.Revision.IncludeInBuild = !boot;
                    if (!boot)
                    {
                        // Change only references to existing Profile values, never the user Profile itself.
                        revisionSchema.BuildPath.SetVariableByName(f.Settings, AddressableAssetSettings.kRemoteBuildPath);
                        revisionSchema.LoadPath.SetVariableByName(f.Settings, AddressableAssetSettings.kRemoteLoadPath);
                    }
                    ProjectConfigData.GenerateBuildLayout = !layoutBefore;
                    foreach (var value in writeTargets.Append(f.Settings)) { EditorUtility.SetDirty(value); AssetDatabase.SaveAssetIfDirty(value); }
                    scope.RecordSavedTemporarySettings();
                    var temporary = f.Files();
                    Assert.AreNotEqual(before[settingsPath], temporary[settingsPath], "Settings raw bytes must really change; this is not a no-op probe.");
                    Assert.AreNotEqual(before[changedGroupPath], temporary[changedGroupPath], "The excluded owned Group must really change.");
                    if (!boot) Assert.AreNotEqual(before[schemaPath], temporary[schemaPath], "Revision path schema bytes must really change.");
                    Assert.AreNotEqual(effective, ManagedBootstrapSplitSettingsScope.Effective(f.Settings));
                    var pending = ManagedBootstrapSplitSettingsScope.ReadPendingSettings();
                    Assert.AreEqual(before[settingsPath], Convert.ToBase64String(pending.raw[settingsPath]));
                    Assert.AreNotEqual(pending.observed[settingsPath], pending.temporary[settingsPath]);
                    foreach (var blockedPurpose in new[] { ManagedGroupBuildRole.Boot, ManagedGroupBuildRole.Revision })
                    {
                        var report = ManagedAddressableBuildExporter.ValidateSplitBuild(f.Config, blockedPurpose);
                        Assert.IsFalse(report.CanBuild); StringAssert.Contains("pending_split_settings.json", report.ToString());
                    }
                    var temporaryLive = RecoveryLive(f); var temporaryDirty = RecoveryDirty(f);
                    string pendingBeforePreview = File.ReadAllText(ManagedAddressableBuildExporter.PendingSplitSettingsPath);
                    var preview = ManagedAddressableBuildExporter.CreateInterruptedSplitSettingsRestorePlan();
                    Assert.IsTrue(preview.CanRestore, preview.ToString());
                    foreach (var value in writeTargets.Append(f.Settings)) Assert.IsTrue(preview.Changes.Any(c => c.Contains(AssetDatabase.GetAssetPath(value))));
                    ManagedBootstrapSplitFixture.Same(temporary, f.Files()); SameLive(f, temporaryLive, temporaryDirty);
                    Assert.AreEqual(pendingBeforePreview, File.ReadAllText(ManagedAddressableBuildExporter.PendingSplitSettingsPath));
                    if (scenario == "restore")
                    {
                        string pendingPath = ManagedAddressableBuildExporter.PendingSplitSettingsPath, next = pendingPath + ".next";
                        Assert.IsFalse(File.Exists(next), "Do not overwrite another checkpoint.");
                        File.Move(pendingPath, next);
                        try
                        {
                            var incomplete = ManagedAddressableBuildExporter.CreateInterruptedSplitSettingsRestorePlan();
                            Assert.IsFalse(incomplete.CanRestore); AssertManualPendingGuidance(incomplete.ToString());
                            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.RestoreInterruptedSplitBuildSettings(incomplete));
                            Assert.IsFalse(File.Exists(pendingPath)); Assert.AreEqual(pendingBeforePreview, File.ReadAllText(next));
                            ManagedBootstrapSplitFixture.Same(temporary, f.Files()); SameLive(f, temporaryLive, temporaryDirty);
                        }
                        finally { File.Move(next, pendingPath); } // Fixture-only return to its recorded checkpoint; no production discard.
                    }
                    if (scenario == "user-conflict")
                    {
                        var changedGroup = boot ? f.Revision : f.Boot;
                        var edit = new SerializedObject(changedGroup); edit.FindProperty("m_ReadOnly").boolValue = true; edit.ApplyModifiedPropertiesWithoutUndo(); AssetDatabase.SaveAssetIfDirty(changedGroup);
                        var conflict = ManagedAddressableBuildExporter.CreateInterruptedSplitSettingsRestorePlan();
                        Assert.IsFalse(conflict.CanRestore); StringAssert.Contains(changedGroupPath, conflict.ToString());
                        AssertManualPendingGuidance(conflict.ToString());
                        var changed = f.Files(); var changedLive = RecoveryLive(f); var changedDirty = RecoveryDirty(f);
                        Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.RestoreInterruptedSplitBuildSettings(preview));
                        ManagedBootstrapSplitFixture.Same(changed, f.Files()); SameLive(f, changedLive, changedDirty);
                        Assert.IsTrue(ManagedAddressableBuildExporter.HasPendingSplitSettings);
                        Assert.AreEqual(pendingBeforePreview, File.ReadAllText(ManagedAddressableBuildExporter.PendingSplitSettingsPath));
                    }
                    else
                    {
                        if (scenario == "stale-checkpoint")
                        {
                            f.Settings.ContentStateBuildPath += "/recorded-checkpoint-two";
                            EditorUtility.SetDirty(f.Settings); AssetDatabase.SaveAssetIfDirty(f.Settings); scope.RecordSavedTemporarySettings();
                            string newPending = File.ReadAllText(ManagedAddressableBuildExporter.PendingSplitSettingsPath);
                            Assert.AreNotEqual(pendingBeforePreview, newPending);
                            var changed = f.Files(); var changedLive = RecoveryLive(f); var changedDirty = RecoveryDirty(f);
                            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.RestoreInterruptedSplitBuildSettings(preview));
                            ManagedBootstrapSplitFixture.Same(changed, f.Files()); SameLive(f, changedLive, changedDirty);
                            Assert.AreEqual(newPending, File.ReadAllText(ManagedAddressableBuildExporter.PendingSplitSettingsPath));
                            preview = ManagedAddressableBuildExporter.CreateInterruptedSplitSettingsRestorePlan();
                            Assert.IsTrue(preview.CanRestore, preview.ToString());
                        }
                        ManagedAddressableBuildExporter.RestoreInterruptedSplitBuildSettings(preview);
                        Assert.IsFalse(ManagedAddressableBuildExporter.HasPendingSplitSettings);
                        f.Reload();
                        ManagedBootstrapSplitFixture.Same(before, f.Files());
                        Assert.AreEqual(effective, ManagedBootstrapSplitSettingsScope.Effective(f.Settings));
                        SameLive(f, liveBefore, dirtyBefore);
                        Assert.AreEqual(layoutBefore, ProjectConfigData.GenerateBuildLayout);
                        Assert.AreEqual(bootGuid, ManagedBootstrapSplitFixture.GuidOf(f.Boot)); Assert.AreEqual(revisionGuid, ManagedBootstrapSplitFixture.GuidOf(f.Revision));
                        f.AssertOriginalEntries();
                    }
                    foreign = AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(foreignPath);
                    Assert.AreEqual(foreignGuid, ManagedBootstrapSplitFixture.GuidOf(foreign));
                    Assert.AreEqual(foreignBefore, f.GroupState(foreign));
                    Assert.AreEqual(externalGuid, foreign.entries.Single().guid); Assert.AreEqual("external.user.address", foreign.entries.Single().address);
                    Assert.AreEqual(profilesBefore, JsonUtility.ToJson(f.Settings.profileSettings));
                    Assert.AreEqual("user-entered-unchanged", f.Settings.profileSettings.GetValueByName(userProfile, "E2.UserUnchanged"));
                    Assert.That(f.Config.ownedGroupGuids, Does.Not.Contain(foreignGuid));
                }
                finally
                {
                    // Test-fixture cleanup only. A production conflict is never resolved automatically.
                    if (ManagedAddressableBuildExporter.HasPendingSplitSettings) scope.Restore(new ManagedSplitBuildReceipt());
                }
            }
        }
    }
}
