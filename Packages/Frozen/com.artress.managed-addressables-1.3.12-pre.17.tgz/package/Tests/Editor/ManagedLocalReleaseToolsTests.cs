using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    // PC-local release values, build output cleanup and the development local host publish.
    // Only folders under P3/ and the system temp folder are written; each case removes its own.
    public sealed class ManagedLocalReleaseToolsTests
    {
        private const string Target = "StandaloneWindows64";
        private string asset, output, hostRoot;
        private ManagedAddressableProjectConfig config;

        [SetUp] public void SetUp()
        {
            string id = Guid.NewGuid().ToString("N").Substring(0, 8);
            asset = "Assets/LocalReleaseQA_" + id + ".asset";
            output = "P3/l_" + id;
            Directory.CreateDirectory(output);
            hostRoot = Path.Combine(Path.GetTempPath(), "mlh_" + id);
            Directory.CreateDirectory(hostRoot);
            config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.buildOutputRoot = output;
            AssetDatabase.CreateAsset(config, asset);
            AssetDatabase.SaveAssetIfDirty(config);
        }

        [TearDown] public void TearDown()
        {
            if (config != null) { ManagedLocalRelease.Delete(config); AssetDatabase.DeleteAsset(asset); }
            string expected = Path.GetFullPath("P3").TrimEnd('/', '\\') + Path.DirectorySeparatorChar;
            Assert.That(Path.GetFullPath(output).StartsWith(expected, StringComparison.OrdinalIgnoreCase), Is.True);
            if (Directory.Exists(output)) Directory.Delete(output, true);
            if (Directory.Exists(hostRoot)) Directory.Delete(hostRoot, true);
        }

        private static ManagedRevisionReleaseMetadata Release(long sequence = 3) => new ManagedRevisionReleaseMetadata
            { productId = "product", channel = "pc-a", authorityId = "team", compatibilityFamily = "F", deploymentSequence = sequence };

        private static string Sha(string path) => ManagedAddressableBuildExporter.SplitFileHash(path);

        // ---------- PC-local release file ----------

        [Test] public void ReleaseSplitsSharedValuesIntoConfigAndTheRestIntoThisPcFile()
        {
            string path = ManagedLocalRelease.FilePath(config);
            Assert.That(path, Does.StartWith(ManagedLocalRelease.Folder + "/Release-"));
            Assert.That(path, Does.Contain(AssetDatabase.AssetPathToGUID(asset)));
            Assert.IsFalse(File.Exists(path));
            var empty = ManagedLocalRelease.Effective(config);
            Assert.IsNull(empty.channel); Assert.AreEqual(0, empty.deploymentSequence);

            ManagedLocalRelease.SetRelease(config, Release());
            var effective = ManagedLocalRelease.Effective(config);
            Assert.AreEqual(JsonUtility.ToJson(Release()), JsonUtility.ToJson(effective));
            string configText = File.ReadAllText(asset);
            StringAssert.Contains("productId: product", configText);
            StringAssert.DoesNotContain("pc-a", configText, "channel is this PC's value.");
            var local = JsonConvert.DeserializeObject<ManagedLocalReleaseFile>(File.ReadAllText(path));
            Assert.AreEqual("pc-a", local.channel); Assert.AreEqual(3, local.deploymentSequence);
            Assert.That(File.ReadAllText(path), Does.Not.Contain("product"), "Shared values are not copied to this PC's file.");
        }

        [Test] public void AFileOfAnotherConfigIsRefused()
        {
            ManagedLocalRelease.SetRelease(config, Release());
            string path = ManagedLocalRelease.FilePath(config);
            var local = JsonConvert.DeserializeObject<ManagedLocalReleaseFile>(File.ReadAllText(path));
            local.configAssetGuid = new string('c', 32);
            File.WriteAllText(path, JsonConvert.SerializeObject(local));
            Assert.Throws<InvalidOperationException>(() => ManagedLocalRelease.Effective(config));
        }

        [Test] public void AnUnsavedConfigHasNoPcFileAndCannotWriteOne()
        {
            var transient = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            try
            {
                Assert.IsNull(ManagedLocalRelease.FilePath(transient));
                Assert.IsNull(ManagedLocalRelease.PackagedForActiveTarget(transient));
                Assert.Throws<InvalidOperationException>(() => ManagedLocalRelease.SetRelease(transient, Release()));
            }
            finally { UnityEngine.Object.DestroyImmediate(transient); }
        }

        [Test] public void PackagedLinksAreKeptPerTarget()
        {
            ManagedLocalRelease.SetPackaged(config, "Android", "P3/a/packaged_revision.json", new string('a', 64));
            ManagedLocalRelease.SetPackaged(config, Target, "P3/w/packaged_revision.json", new string('b', 64));
            ManagedLocalRelease.SetPackaged(config, "Android", "P3/a2/packaged_revision.json", new string('c', 64));
            Assert.AreEqual("P3/a2/packaged_revision.json", ManagedLocalRelease.Packaged(config, "Android").metadataPath);
            Assert.AreEqual(new string('b', 64), ManagedLocalRelease.Packaged(config, Target).metadataSha256);
            Assert.AreEqual(2, ManagedLocalRelease.Read(config).packaged.Count);
            Assert.That(ManagedLocalRelease.FingerprintText(config), Does.Contain("P3/a2/packaged_revision.json"));
        }

        [Test] public void RestoreReturnsThePcFileToItsExactBytes()
        {
            Assert.IsNull(ManagedLocalRelease.RawBytes(config));
            ManagedLocalRelease.Restore(config, null);
            ManagedLocalRelease.SetRelease(config, Release());
            byte[] before = ManagedLocalRelease.RawBytes(config);
            ManagedLocalRelease.SetRelease(config, Release(9));
            ManagedLocalRelease.Restore(config, before);
            Assert.AreEqual(before, ManagedLocalRelease.RawBytes(config));
            ManagedLocalRelease.Restore(config, null);
            Assert.IsFalse(File.Exists(ManagedLocalRelease.FilePath(config)));
        }

        [Test] public void AFileLostMidReplaceIsRecoveredFromItsFinishedCopy()
        {
            ManagedLocalRelease.SetPackaged(config, Target, "P3/w/packaged_revision.json", new string('b', 64));
            string path = ManagedLocalRelease.FilePath(config);
            File.Move(path, path + ".tmp");
            Assert.AreEqual("P3/w/packaged_revision.json", ManagedLocalRelease.Packaged(config, Target).metadataPath, "The packaged A link survives.");
            Assert.IsTrue(File.Exists(path)); Assert.IsFalse(File.Exists(path + ".tmp"));

            // With both present the replacement never ran, so the file wins and the copy stays.
            File.WriteAllText(path + ".tmp", "{ not json");
            Assert.AreEqual("P3/w/packaged_revision.json", ManagedLocalRelease.Packaged(config, Target).metadataPath);
            File.Delete(path + ".tmp");

            File.Move(path, path + ".tmp");
            File.WriteAllText(path + ".tmp", "null");
            Assert.Throws<InvalidOperationException>(() => ManagedLocalRelease.Read(config));
            File.Delete(path + ".tmp");
        }

        [Test] public void CleanupKeepsAPackagedALinkedOnlyThroughAFinishedCopy()
        {
            string pLinked = Stamp("packaged", "p1", null, 0);
            string metadata = Path.Combine(pLinked, "Payload", "packaged_revision.json");
            Directory.CreateDirectory(Path.GetDirectoryName(metadata)); File.WriteAllText(metadata, "{}");
            ManagedLocalRelease.SetPackaged(config, Target, Path.Combine(output, Target, "1.0", "split", "packaged", "p1", "Payload", "packaged_revision.json").Replace('\\', '/'), Sha(metadata));
            string path = ManagedLocalRelease.FilePath(config);
            File.Move(path, path + ".tmp");
            var plan = ManagedAddressableBuildExporter.CreateOutputCleanupPlan(config);
            Assert.IsTrue(plan.CanApply, plan.ToString());
            CollectionAssert.Contains(plan.keep.Select(item => item.path).ToList(), pLinked, plan.ToString());
            Assert.IsEmpty(plan.delete, plan.ToString());
        }

        // ---------- build output cleanup ----------

        private string Stamp(string purpose, string name, string fingerprint, int minutesAgo, bool complete = true)
        {
            string stamp = Path.Combine(output, Target, "1.0", "split", purpose, name);
            Directory.CreateDirectory(stamp);
            File.WriteAllText(Path.Combine(stamp, "payload.bin"), new string('x', 100));
            if (fingerprint != null)
            {
                string receipt = Path.Combine(stamp, "split_build_receipt.json");
                File.WriteAllText(receipt, JsonConvert.SerializeObject(new ManagedSplitBuildReceipt { complete = complete, purpose = purpose == "revision" ? "Revision" : "Boot", contentFingerprint = fingerprint }));
                File.SetLastWriteTimeUtc(receipt, DateTime.UtcNow.AddMinutes(-minutesAgo));
            }
            return Path.GetFullPath(stamp);
        }

        [Test] public void CleanupKeepsWhatThisPcNeedsAndDeletesOnlyAfterAReviewedPreview()
        {
            string r1 = Stamp("revision", "r1", "f1", 40), r2 = Stamp("revision", "r2", "f2", 30), r3 = Stamp("revision", "r3", "f3", 20);
            string failed = Stamp("revision", "r4", "f4", 10, complete: false), noReceipt = Stamp("revision", "r5", null, 0);
            foreach (string child in new[] { "Runtime", "ContentState", "Remote" })
            {
                Directory.CreateDirectory(Path.Combine(r3, child));
                File.WriteAllText(Path.Combine(r3, child, "file.bin"), "kept or not");
            }
            string bOld = Stamp("boot", "b1", "f1", 40), bPaired = Stamp("boot", "b2", "f2", 30), bNewest = Stamp("boot", "b3", "f9", 5);
            string pLinked = Stamp("packaged", "p1", null, 0), pLoose = Stamp("packaged", "p2", null, 0);
            string metadata = Path.Combine(pLinked, "Payload", "packaged_revision.json");
            Directory.CreateDirectory(Path.GetDirectoryName(metadata)); File.WriteAllText(metadata, "{}");
            ManagedLocalRelease.SetPackaged(config, Target, Path.Combine(output, Target, "1.0", "split", "packaged", "p1", "Payload", "packaged_revision.json").Replace('\\', '/'), Sha(metadata));

            var plan = ManagedAddressableBuildExporter.CreateOutputCleanupPlan(config, 2);
            Assert.IsTrue(plan.CanApply, plan.ToString());
            var deleted = plan.delete.Select(item => item.path).ToList();
            var kept = plan.keep.Select(item => item.path).ToList();
            CollectionAssert.AreEquivalent(new[] { r1, failed, noReceipt, Path.Combine(r3, "Runtime"), Path.Combine(r3, "ContentState"), bOld, pLoose }, deleted, plan.ToString());
            CollectionAssert.AreEquivalent(new[] { r2, r3, bPaired, bNewest, pLinked }, kept, plan.ToString());
            Assert.IsTrue(Directory.Exists(r1), "Preview deletes nothing.");

            // A new build after Preview makes the plan stale.
            Stamp("revision", "r6", "f6", 1);
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ApplyOutputCleanupPlan(config, plan));
            Assert.IsTrue(Directory.Exists(r1));

            plan = ManagedAddressableBuildExporter.CreateOutputCleanupPlan(config, 2);
            long freed = ManagedAddressableBuildExporter.ApplyOutputCleanupPlan(config, plan);
            Assert.That(freed, Is.GreaterThan(0));
            foreach (var item in plan.delete) Assert.IsFalse(Directory.Exists(item.path), item.path);
            foreach (var item in plan.keep) Assert.IsTrue(Directory.Exists(item.path), item.path);
            Assert.IsTrue(File.Exists(Path.Combine(r3, "Remote", "file.bin")), "Built Revision files stay.");
            Assert.IsTrue(File.Exists(metadata));
        }

        [Test] public void CleanupWithoutOutputHasNothingToDeleteAndRejectsZeroKeep()
        {
            Directory.Delete(output, true);
            var plan = ManagedAddressableBuildExporter.CreateOutputCleanupPlan(config);
            Assert.IsTrue(plan.CanApply, plan.ToString()); Assert.IsEmpty(plan.delete);
            Assert.IsFalse(ManagedAddressableBuildExporter.CreateOutputCleanupPlan(config, 0).CanApply);
        }

        // ---------- local host publish ----------

        private const string StampId = "20261108-00000000000000b2";
        private const string HostUrl = "http://127.0.0.1:18080/qa";

        private string RevisionReceipt(string bundleUrlRoot = null, string channel = "pc-a", long sequence = 3, string revisionId = "rev-b", string target = Target)
        {
            string stamp = Path.Combine(output, Target, "1.0", "split", "revision", StampId);
            string remote = Path.Combine(stamp, "Remote");
            Directory.CreateDirectory(remote);
            string catalog = Path.Combine(remote, "catalog_1.json"), bundle = Path.Combine(remote, "game_abc.bundle"), publisher = Path.Combine(stamp, "revision_publisher.json");
            File.WriteAllText(catalog, "catalog " + revisionId, new UTF8Encoding(false));
            File.WriteAllText(bundle, "bundle " + revisionId, new UTF8Encoding(false));
            File.WriteAllText(publisher, JsonUtility.ToJson(new ManagedRevisionPublisher { revisionId = revisionId, target = target, catalogFile = "catalog_1.json",
                productId = "product", channel = channel, authorityId = "team", compatibilityFamily = "F", deploymentSequence = sequence }), new UTF8Encoding(false));
            string root = bundleUrlRoot ?? HostUrl + "/split/revision/" + StampId;
            var receipt = new ManagedSplitBuildReceipt { complete = true, purpose = "Revision", catalogFormat = "json", stamp = StampId,
                catalogPath = Path.GetFullPath(catalog), catalogSha256 = Sha(catalog), publisherPath = Path.GetFullPath(publisher), publisherSha256 = Sha(publisher),
                bundles = new List<ManagedSplitBundleReceipt> { new ManagedSplitBundleReceipt { bundleName = "game", internalId = root + "/game_abc.bundle", filePath = Path.GetFullPath(bundle), sha256 = Sha(bundle) } } };
            string path = Path.Combine(stamp, "split_build_receipt.json");
            File.WriteAllText(path, JsonConvert.SerializeObject(receipt), new UTF8Encoding(false));
            return Path.GetFullPath(path);
        }

        private string[] HostFiles() => Directory.GetFiles(hostRoot, "*", SearchOption.AllDirectories).OrderBy(p => p, StringComparer.Ordinal).ToArray();

        [Test] public void PublishCopiesTheRevisionWhereItsUrlsPointAndWritesThePointerLast()
        {
            string receipt = RevisionReceipt();
            var plan = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, receipt, hostRoot);
            Assert.IsTrue(plan.CanApply, plan.ToString());
            Assert.IsEmpty(HostFiles(), "Preview writes nothing.");
            Assert.That(plan.ToString(), Does.Contain("not a production trust anchor"));

            string url = ManagedAddressableBuildExporter.ApplyLocalHostPublishPlan(config, plan);
            Assert.AreEqual(HostUrl + "/split/latest/" + Target + "/pc-a.json", url);
            string revisionDir = Path.Combine(hostRoot, "qa", "split", "revision", StampId);
            foreach (string name in new[] { "catalog_1.json", "game_abc.bundle", "revision_publisher.json" })
                Assert.IsTrue(File.Exists(Path.Combine(revisionDir, name)), name);
            Assert.IsFalse(Directory.Exists(revisionDir + ".publishing"));
            var pointer = ManagedRevisionLocalHostPointer.Parse(File.ReadAllText(Path.Combine(hostRoot, "qa", "split", "latest", Target, "pc-a.json")));
            Assert.AreEqual("rev-b", pointer.revisionId); Assert.AreEqual(3, pointer.deploymentSequence); Assert.AreEqual("pc-a", pointer.channel);
            Assert.AreEqual(HostUrl + "/split/revision/" + StampId + "/catalog_1.json", pointer.catalogUrl);
            Assert.AreEqual(Sha(Path.Combine(revisionDir, "revision_publisher.json")), pointer.publisherSha256);

            // The same build again changes nothing.
            var again = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, receipt, hostRoot);
            Assert.IsTrue(again.CanApply && again.alreadyPublished, again.ToString());
            var before = HostFiles().Select(Sha).ToArray();
            ManagedAddressableBuildExporter.ApplyLocalHostPublishPlan(config, again);
            CollectionAssert.AreEqual(before, HostFiles().Select(Sha).ToArray());
        }

        [Test] public void APublishedRevisionIsNeverOverwritten()
        {
            string receipt = RevisionReceipt();
            ManagedAddressableBuildExporter.ApplyLocalHostPublishPlan(config, ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, receipt, hostRoot));
            File.AppendAllText(Path.Combine(hostRoot, "qa", "split", "revision", StampId, "game_abc.bundle"), "edited on the host");
            var plan = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, receipt, hostRoot);
            Assert.IsFalse(plan.CanApply); Assert.That(plan.ToString(), Does.Contain("never overwritten"));
        }

        [Test] public void APointerChangedAfterPreviewStopsTheApplyBeforeAnyCopy()
        {
            var plan = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, RevisionReceipt(), hostRoot);
            Assert.IsTrue(plan.CanApply, plan.ToString());
            Directory.CreateDirectory(Path.GetDirectoryName(plan.pointerPath));
            File.WriteAllText(plan.pointerPath, "{\"schemaVersion\":1}");
            Assert.Throws<InvalidOperationException>(() => ManagedAddressableBuildExporter.ApplyLocalHostPublishPlan(config, plan));
            Assert.IsFalse(Directory.Exists(plan.revisionDirectory));
        }

        [Test] public void ALowerSequenceThanTheCurrentPointerWarns()
        {
            var first = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, RevisionReceipt(), hostRoot);
            ManagedAddressableBuildExporter.ApplyLocalHostPublishPlan(config, first);
            var pointer = ManagedRevisionLocalHostPointer.Parse(File.ReadAllText(first.pointerPath));
            pointer.revisionId = "newer"; pointer.deploymentSequence = 7;
            File.WriteAllText(first.pointerPath, JsonUtility.ToJson(pointer));
            var plan = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, RevisionReceipt(), hostRoot);
            Assert.IsTrue(plan.CanApply, plan.ToString());
            Assert.That(plan.ToString(), Does.Contain("sequence 7"));
        }

        [TestCase("split-root")] [TestCase("wrong-stamp")] [TestCase("bad-channel")] [TestCase("bad-target")] [TestCase("relative-host")] [TestCase("host-in-assets")] [TestCase("remote-host")]
        [TestCase("host-in-output")] [TestCase("host-contains-output")] [TestCase("host-is-project")]
        public void UnsafePublishInputsAreBlockedOrWarned(string kind)
        {
            string host = hostRoot;
            string receipt = kind == "wrong-stamp" ? RevisionReceipt(HostUrl + "/split/revision/other") :
                kind == "bad-channel" ? RevisionReceipt(channel: "pc a") :
                kind == "bad-target" ? RevisionReceipt(target: "..") :
                kind == "remote-host" ? RevisionReceipt("https://cdn.example.invalid/qa/split/revision/" + StampId) : RevisionReceipt();
            if (kind == "split-root")
            {
                var value = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(receipt));
                var copy = JsonConvert.DeserializeObject<ManagedSplitBundleReceipt>(JsonConvert.SerializeObject(value.bundles[0]));
                copy.internalId = HostUrl + "/elsewhere/game_abc.bundle";
                value.bundles.Add(copy);
                File.WriteAllText(receipt, JsonConvert.SerializeObject(value));
            }
            if (kind == "relative-host") host = "relative/host";
            if (kind == "host-in-assets") host = Path.GetFullPath("Assets");
            // Cleanup would read a Revision published under the output root as an unfinished build.
            if (kind == "host-in-output") host = Path.GetFullPath(output);
            if (kind == "host-contains-output") host = Path.GetFullPath("P3");
            if (kind == "host-is-project") host = Path.GetFullPath(".");
            var plan = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, receipt, host);
            if (kind == "remote-host")
            {
                Assert.IsTrue(plan.CanApply, plan.ToString());
                Assert.That(plan.ToString(), Does.Contain("not this PC"));
                return;
            }
            Assert.IsFalse(plan.CanApply, plan.ToString());
            Assert.IsEmpty(HostFiles());
        }
    }
}
