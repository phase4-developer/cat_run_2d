using System;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedShaderFolderRulesTests
    {
        private string root;
        private AddressableAssetSettings settings;
        private AddressableAssetSettings previousSettings;
        private AddressableAssetGroup[] previousGroups;
        private static readonly FieldInfo DefaultSettingsField = typeof(AddressableAssetSettingsDefaultObject).GetField("s_DefaultSettingsObject", BindingFlags.Static | BindingFlags.NonPublic);

        [SetUp]
        public void SetUp()
        {
            previousSettings = AddressableAssetSettingsDefaultObject.Settings;
            previousGroups = previousSettings?.groups.ToArray();
            SetPostprocessor(previousSettings, false);
            root = "Assets/ManagedShaderFolderRulesTests_" + Guid.NewGuid().ToString("N");
            Directory.CreateDirectory(root);
            AssetDatabase.Refresh();
            settings = AddressableAssetSettings.Create(root + "/Settings", "Settings", false, true);
            // The public setter saves the project's DefaultObject and registers a global import callback.
            DefaultSettingsField.SetValue(null, settings);
            Group("Default", true);
        }

        [TearDown]
        public void TearDown()
        {
            try
            {
                SetPostprocessor(settings, false);
                AssetDatabase.DeleteAsset(root);
            }
            finally
            {
                DefaultSettingsField.SetValue(null, previousSettings);
                SetPostprocessor(previousSettings, true);
            }
            if (previousSettings != null)
                CollectionAssert.AreEqual(previousGroups, previousSettings.groups, "Test assets must not alter the project's groups.");
        }

        private static void SetPostprocessor(AddressableAssetSettings target, bool enabled)
        {
            if (target == null)
                return;
            // Addressables 4 imports every group into each registered settings object, including test groups.
            Type processor = typeof(AddressableAssetSettings).Assembly.GetType("UnityEditor.AddressableAssets.Settings.AddressablesAssetPostProcessor", true);
            object callbacks = processor.GetProperty("OnPostProcess", BindingFlags.Static | BindingFlags.Public).GetValue(null);
            MethodInfo register = callbacks.GetType().GetMethod("Register");
            MethodInfo import = typeof(AddressableAssetSettings).GetMethod("OnPostprocessAllAssets", BindingFlags.Instance | BindingFlags.NonPublic);
            Delegate callback = Delegate.CreateDelegate(register.GetParameters()[0].ParameterType, target, import);
            if (enabled)
                register.Invoke(callbacks, new object[] { callback, 0 });
            else
                callbacks.GetType().GetMethod("Unregister").Invoke(callbacks, new object[] { callback });
        }


        [Test]
        public void SyncPacksShadersByFolderAndPreservesExistingAddresses()
        {
            AddressableAssetGroup officialDefault = settings.DefaultGroup;
            string officialDefaultBefore = ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault);
            string first = ShaderAsset("Content/Local/Shader/First");
            string second = ShaderAsset("Content/Local/Shader/Second");
            string font = ShaderAsset("Content/Local/FontShader/Font");
            AddressableAssetEntry original = Register(font, Group("Font Shaders"));
            original.SetAddress("existing-font-address");
            original.SetLabel("existing-label", true, true);
            ManagedAddressableProjectConfig config = Config();
            try
            {
                ManagedAR2G2IntegrationTests.ExplicitlyOwnGroupForFixture(config, original.parentGroup);
                ManagedAddressableSynchronizer.Sync(config, false);
                AddressableAssetGroup shaders = Entry(first).parentGroup;
                AddressableAssetGroup fonts = Entry(font).parentGroup;
                ManagedAddressableSyncReport repeated = ManagedAddressableSynchronizer.Sync(config, false);

                Assert.AreEqual("Shader", shaders.Name);
                Assert.AreSame(shaders, Entry(second).parentGroup);
                Assert.AreEqual(2, shaders.entries.Count);
                Assert.AreEqual("FontShader", fonts.Name);
                Assert.AreNotSame(shaders, fonts);
                Assert.AreEqual("existing-font-address", Entry(font).address);
                CollectionAssert.Contains(Entry(font).labels, "existing-label");
                Assert.AreEqual(BundledAssetGroupSchema.BundlePackingMode.PackTogether, shaders.GetSchema<BundledAssetGroupSchema>().BundleMode);
                Assert.AreEqual(0, repeated.createdGroups + repeated.removedGroups + repeated.addedEntries + repeated.movedEntries + repeated.changedAddresses);
                Assert.AreEqual(officialDefaultBefore, ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault));
                CollectionAssert.DoesNotContain(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(officialDefault)));
                CollectionAssert.Contains(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(shaders)));
                CollectionAssert.Contains(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(fonts)));
                CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config));
            }
            finally { UnityEngine.Object.DestroyImmediate(config); }
        }

        [Test]
        public void SyncLeavesShaderDependenciesOutsideContentRootImplicit()
        {
            string shader = ShaderAsset("Outside/Shared");
            Directory.CreateDirectory(root + "/Content/Local/UI");
            AssetDatabase.Refresh();
            AssetDatabase.CreateAsset(new Material(AssetDatabase.LoadAssetAtPath<Shader>(shader)), root + "/Content/Local/UI/Consumer.mat");
            ManagedAddressableProjectConfig config = Config();
            try
            {
                ManagedAddressableSynchronizer.Sync(config, false);
                ManagedAddressableSynchronizer.Sync(config, false);

                Assert.IsNull(Entry(shader));
                Assert.AreEqual("UI", Entry(root + "/Content/Local/UI/Consumer.mat").parentGroup.Name);
                CollectionAssert.AreEquivalent(new[] { "Default", "UI" }, settings.groups.Select(group => group.Name));
            }
            finally { UnityEngine.Object.DestroyImmediate(config); }
        }

        [Test]
        public void ValidatorPreservesExplicitSdkShaderPackingChoice()
        {
            string shader = ShaderAsset("Content/Local/Shader/Main");
            ManagedAddressableProjectConfig config = Config();
            try
            {
                ManagedAddressableSynchronizer.Sync(config, false);
                Entry(shader).parentGroup.GetSchema<BundledAssetGroupSchema>().BundleMode = BundledAssetGroupSchema.BundlePackingMode.PackSeparately;
                string schemaBefore = EditorJsonUtility.ToJson(Entry(shader).parentGroup.GetSchema<BundledAssetGroupSchema>());
                CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config), "A legal SDK packing choice is not an implicit repair request.");
                Assert.AreEqual(schemaBefore, EditorJsonUtility.ToJson(Entry(shader).parentGroup.GetSchema<BundledAssetGroupSchema>()));
                Assert.AreEqual(BundledAssetGroupSchema.BundlePackingMode.PackSeparately, Entry(shader).parentGroup.GetSchema<BundledAssetGroupSchema>().BundleMode);
            }
            finally { UnityEngine.Object.DestroyImmediate(config); }
        }

        [Test]
        public void ShaderUsesExistingRemoteUpdateFolderRule()
        {
            AddressableAssetGroup officialDefault = settings.DefaultGroup;
            string officialDefaultBefore = ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault);
            string shader = ShaderAsset("Content/Remote/Shader/Update/V2/Main");
            ManagedAddressableProjectConfig config = Config();
            try
            {
                ManagedAddressableSynchronizer.Sync(config, false);
                AddressableAssetGroup group = Entry(shader).parentGroup;

                Assert.AreEqual("Remote_Shader_V2", group.Name);
                Assert.AreEqual(AddressableAssetSettings.kRemoteLoadPath, group.GetSchema<BundledAssetGroupSchema>().LoadPath.GetName(settings));
                Assert.IsFalse(group.GetSchema<ContentUpdateGroupSchema>().StaticContent);
                Assert.AreEqual(officialDefaultBefore, ManagedAR2G2IntegrationTests.CaptureGroup(officialDefault));
                CollectionAssert.DoesNotContain(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(officialDefault)));
                CollectionAssert.Contains(ManagedAR2G2IntegrationTests.Owned(config), AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group)));
                CollectionAssert.IsEmpty(ManagedAddressableValidator.Validate(config));
            }
            finally { UnityEngine.Object.DestroyImmediate(config); }
        }


        private ManagedAddressableProjectConfig Config()
        {
            ManagedAddressableProjectConfig config = ScriptableObject.CreateInstance<ManagedAddressableProjectConfig>();
            config.SetContentRoot(root + "/Content");
            config.backupBeforeApply = false;
            return config;
        }

        private AddressableAssetGroup Group(string name, bool isDefault = false)
        {
            return settings.CreateGroup(name, isDefault, false, false, null, typeof(BundledAssetGroupSchema), typeof(ContentUpdateGroupSchema));
        }

        private AddressableAssetEntry Register(string path, AddressableAssetGroup group)
        {
            return settings.CreateOrMoveEntry(AssetDatabase.AssetPathToGUID(path), group);
        }

        private AddressableAssetEntry Entry(string path)
        {
            return settings.FindAssetEntry(AssetDatabase.AssetPathToGUID(path));
        }

        private string ShaderAsset(string name)
        {
            string path = root + "/" + name + ".shader";
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, "Shader \"Hidden/" + root + "/" + name + "\" { SubShader { Pass {} } Fallback Off }");
            AssetDatabase.Refresh();
            Assert.IsNotNull(AssetDatabase.LoadAssetAtPath<Shader>(path));
            return path;
        }
    }
}
