using NUnit.Framework;
using System.Collections.Generic;

namespace Artress.ManagedAddressables.Editor.Tests
{
    public sealed class ManagedAddressNamingTests
    {
        [Test]
        public void NoIgnore_UsesPathAfterCategory()
        {
            string result = ManagedAddressNaming.BuildAddress("UI", "Tutorial/Guide.prefab", "Assets/Game/Addressables/Local/UI/Tutorial/Guide.prefab", false, "_", new List<string>());
            Assert.AreEqual("Tutorial_Guide", result);
        }

        [Test]
        public void UpdateManagementFoldersAlreadyStripped_ResultUsesFileName()
        {
            string result = ManagedAddressNaming.BuildAddress("Character", "Char_6.prefab", "Assets/Game/Addressables/Remote/Character/Update/1.0.1/Char_6.prefab", false, "_", new List<string>());
            Assert.AreEqual("Char_6", result);
        }

        [Test]
        public void IgnorePrefix_RemovesMatchingSubPath()
        {
            string result = ManagedAddressNaming.BuildAddress("Texture", "UI/Header_LevelPass_2.png", "Assets/Game/Addressables/Remote/Texture/UI/Header_LevelPass_2.png", false, "_", new List<string> { "Texture/UI" });
            Assert.AreEqual("Header_LevelPass_2", result);
        }

        [Test]
        public void IgnoreCategory_UsesFileName()
        {
            string result = ManagedAddressNaming.BuildAddress("Sound", "Hit/Knife_Hermit.prefab", "Assets/Game/Addressables/Local/Sound/Hit/Knife_Hermit.prefab", false, "_", new List<string> { "Sound" });
            Assert.AreEqual("Knife_Hermit", result);
        }

        [Test]
        public void LongestSubPathPrefixWins()
        {
            string result = ManagedAddressNaming.BuildAddress("Sound", "Hit/Weapon/Knife_Hermit.prefab", "Assets/Game/Addressables/Local/Sound/Hit/Weapon/Knife_Hermit.prefab", false, "_", new List<string> { "Sound/Hit", "Sound/Hit/Weapon" });
            Assert.AreEqual("Knife_Hermit", result);
        }

        [Test]
        public void IncludeExtension_IsCompatible()
        {
            string result = ManagedAddressNaming.BuildAddress("Data", "Config/sample.json", "Assets/Game/Addressables/Local/Data/Config/sample.json", true, "_", new List<string>());
            Assert.AreEqual("Config_sample.json", result);
        }
    }
}
