using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.Networking;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace Artress.ManagedAddressables.HostFixture
{
    // A real Player through the production Session.
    // Without arguments: Boot, then whatever Revision the app should be on, offline.
    // With -remotePointer <url>: after that, read the local host pointer, download B, apply it.
    // -expect <A|B> names the Revision content the start must end on.
    public sealed class ManagedChainPlayerDriver : MonoBehaviour
    {
        public const string BootKey = "ChainBootText", GamePrefabKey = "ChainGamePrefab";

        [Serializable]
        private sealed class Result
        {
            public bool success, closed;
            public string error, revisionId, commitOutcome, bootText, gameMarker, gameDependency, persistentDataPath;
            public string remoteRevisionId, remoteCommitOutcome;
            public long remoteDownloadedBytes;
            public int httpRequests, storageRequests, bundleNameChecks;
        }

        private readonly Result result = new Result();
        private readonly HashSet<string> revisionBundles = new HashSet<string>(StringComparer.Ordinal);
        private HashSet<string> bootBundles;
        private ManagedAddressableRevision activeRevision;
        private GameObject instance;
        private AsyncOperationHandle<GameObject> prefab;
        private string expected = "A";
        private bool preparing;

        private static void Require(bool value, string why) { if (!value) throw new InvalidOperationException(why); }
        private static string Arg(string name)
        {
            var args = Environment.GetCommandLineArgs();
            int index = Array.IndexOf(args, name);
            return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
        }
        private static async Task Done(AsyncOperationHandle handle) { while (!handle.IsDone) await Task.Yield(); }

        private async Task LoadGame(bool keep)
        {
            var loaded = Addressables.LoadAssetAsync<GameObject>(GamePrefabKey);
            await Done(loaded);
            try
            {
                Require(loaded.Status == AsyncOperationStatus.Succeeded, "Game prefab failed: " + loaded.OperationException);
                var marker = loaded.Result.GetComponent<ManagedHostMarker>();
                Require(marker != null && marker.revision == expected && marker.dependency != null && marker.dependency.text == expected,
                    "Game prefab is not Revision " + expected + ": " + marker?.revision + "/" + marker?.dependency?.text);
                result.gameMarker = marker.revision;
                result.gameDependency = marker.dependency.text;
                foreach (var bundle in AssetBundle.GetAllLoadedAssetBundles()) if (!bootBundles.Contains(bundle.name)) revisionBundles.Add(bundle.name);
                await RequirePublisherBundleNamesAsync();
                if (keep) { prefab = loaded; instance = Instantiate(loaded.Result); loaded = default; }
            }
            finally { if (loaded.IsValid()) Addressables.Release(loaded); }
        }

        // The deferred apply waits for the previous Revision's bundles by sdkBundleName + ".bundle",
        // exactly or followed by '_' and the suffix a remote Group bundle carries.
        // Without this check a wrong rule would only make that wait see nothing, so the chain proves
        // the rule on the real engine: every bundle the Revision loaded must carry one of those names.
        private async Task RequirePublisherBundleNamesAsync()
        {
            string path = activeRevision?.PublisherPath;
            Require(!string.IsNullOrEmpty(path), "The active Revision has no publisher");
            // A remote Revision keeps its publisher URL. GetText does not pass through
            // Addressables.WebRequestOverride, so the http request count stays the SDK's own.
            bool remote = path.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || path.StartsWith("https://", StringComparison.OrdinalIgnoreCase);
            Require(remote || System.IO.File.Exists(path), "Publisher file is not readable: " + path);
            string text = remote ? await GetText(path) : System.IO.File.ReadAllText(path);
            var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(text);
            Require(publisher?.bundles != null && publisher.bundles.Length > 0, "Publisher lists no bundles");
            var names = new HashSet<string>(publisher.bundles.Select(row => row.sdkBundleName + ".bundle"), StringComparer.Ordinal);
            // Only bundles loaded now: an earlier Revision's names may be gone from this publisher.
            var loaded = AssetBundle.GetAllLoadedAssetBundles().Where(bundle => bundle != null && !bootBundles.Contains(bundle.name))
                .Select(bundle => bundle.name).Distinct(StringComparer.Ordinal).ToArray();
            Require(loaded.Length > 0, "The Revision loaded no bundles");
            var unknown = loaded.Where(name => !names.Any(stem => name == stem || name.Length > stem.Length + 1 && name.StartsWith(stem, StringComparison.Ordinal) && name[stem.Length] == '_')).OrderBy(name => name, StringComparer.Ordinal).ToArray();
            Require(unknown.Length == 0, "Loaded Revision bundles outside sdkBundleName + \".bundle[_suffix]\": " + string.Join(", ", unknown));
            result.bundleNameChecks++;
        }

        private async Task<bool> Validate(ManagedAddressableRevision revision, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            activeRevision = revision;
            await LoadGame(false);
            return true;
        }

        private async Task<ManagedRevisionBoundary> Stop(CancellationToken token)
        {
            if (instance != null) { Destroy(instance); await Task.Yield(); instance = null; }
            if (prefab.IsValid()) Addressables.Release(prefab);
            prefab = default;
            double started = Time.realtimeSinceStartupAsDouble;
            while (AssetBundle.GetAllLoadedAssetBundles().Any(bundle => revisionBundles.Contains(bundle.name)))
            {
                Require(Time.realtimeSinceStartupAsDouble - started < 5, "Revision bundles did not unload");
                await Task.Yield();
            }
            token.ThrowIfCancellationRequested();
            return new ManagedRevisionBoundary(0, 0, 0, 0, true, "Driver released its prefab and the Revision bundles unloaded.");
        }

        private static async Task<string> GetText(string url)
        {
            using (var request = UnityWebRequest.Get(url))
            {
                var operation = request.SendWebRequest();
                while (!operation.isDone) await Task.Yield();
                Require(request.result == UnityWebRequest.Result.Success, "Read failed: " + url + ": " + request.error);
                return request.downloadHandler.text;
            }
        }

        private async Task Run()
        {
            string pointerUrl = Arg("-remotePointer");
            string finalExpected = Arg("-expect") ?? "A";
            Action<UnityWebRequest> previousOverride = Addressables.WebRequestOverride;
            Addressables.WebRequestOverride = request =>
            {
                previousOverride?.Invoke(request);
                if (!request.url.StartsWith("http", StringComparison.OrdinalIgnoreCase)) return;
                // The Revision storage applies the same override to its own downloads (auth headers etc.).
                if (preparing) result.storageRequests++; else result.httpRequests++;
            };
            var initialize = Addressables.InitializeAsync(false);
            await Done(initialize);
            Require(initialize.Status == AsyncOperationStatus.Succeeded, "SDK Boot failed: " + initialize.OperationException);
            IResourceLocator bootLocator = initialize.Result;
            Addressables.Release(initialize);

            var boot = Addressables.LoadAssetAsync<TextAsset>(BootKey);
            await Done(boot);
            Require(boot.Status == AsyncOperationStatus.Succeeded, "Boot text failed: " + boot.OperationException);
            result.bootText = boot.Result.text;
            Require(result.bootText == "BOOT", "Boot text changed");
            bootBundles = new HashSet<string>(AssetBundle.GetAllLoadedAssetBundles().Select(bundle => bundle.name), StringComparer.Ordinal);

            // The public loader reads the anchor the official Player build placed in StreamingAssets.
            var application = await ManagedPackagedRevisionLoader.LoadAsync();
            var session = new ManagedAddressableRevisionSession(new ManagedAddressableRevisionStorage("ManagedChain", 0, 30));
            // Before any remote step the app is on A, or on B when a newer B was confirmed earlier.
            expected = pointerUrl != null ? "A" : finalExpected;
            var opened = await session.OpenForApplicationAsync(bootLocator, application, new ManagedRevisionApplyCallbacks(Stop, Validate));
            Require(opened.Success, "Open failed: " + opened.Error);
            result.commitOutcome = opened.CommitOutcome?.ToString();
            result.revisionId = session.ActiveRevision?.RevisionId;
            if (expected == "A") Require(result.revisionId == application.PackagedRevision.RevisionId, "The packaged Revision is not active");
            activeRevision = session.ActiveRevision;
            await LoadGame(true);

            if (pointerUrl != null)
            {
                var pointer = ManagedRevisionLocalHostPointer.Parse(await GetText(pointerUrl));
                Require(pointer.revisionId != result.revisionId, "The pointer names the Revision already active");
                preparing = true;
                ManagedRevisionResult prepared;
                try { prepared = await session.PrepareAsync(pointer.ToRevision()); }
                finally { preparing = false; }
                Require(prepared.Success, "Prepare failed: " + prepared.Error);
                result.remoteDownloadedBytes = prepared.DownloadedBytes;
                Require(prepared.DownloadedBytes > 0 && result.storageRequests > 0, "Prepare downloaded nothing from the local host");
                expected = finalExpected;
                var applied = await session.ApplyAsync(new ManagedRevisionApplyCallbacks(Stop, Validate));
                Require(applied.Success, "Apply failed: " + applied.Error);
                result.remoteCommitOutcome = applied.CommitOutcome?.ToString();
                result.remoteRevisionId = session.ActiveRevision?.RevisionId;
                Require(result.remoteRevisionId == pointer.revisionId, "The remote Revision is not active");
                activeRevision = session.ActiveRevision;
                int checksBefore = result.bundleNameChecks;
                await LoadGame(true);
                Require(result.bundleNameChecks > checksBefore, "The stored remote Revision's bundle names were not checked");
            }

            var close = await session.CloseAsync(Stop);
            Require(close.Success, "Close failed: " + close.Error);
            result.closed = true;
            Addressables.Release(boot);
            Addressables.WebRequestOverride = previousOverride;
            // Owned storage downloads; the SDK itself only ever reads local files.
            Require(result.httpRequests == 0, "Addressables made an http request");
            Require(result.bundleNameChecks > 0, "No loaded Revision bundle name was checked");
            result.success = true;
        }

        private async void Start()
        {
            try { result.persistentDataPath = Application.persistentDataPath; await Run(); }
            catch (Exception error) { result.error = error.ToString(); }
            string path = Arg("-chainResult");
            if (!string.IsNullOrEmpty(path)) System.IO.File.WriteAllText(path, JsonUtility.ToJson(result, true));
            Application.Quit(result.success ? 0 : 1);
        }
    }
}
