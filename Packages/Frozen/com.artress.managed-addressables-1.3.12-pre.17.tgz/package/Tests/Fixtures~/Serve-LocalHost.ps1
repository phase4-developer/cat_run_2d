# Development-only static file server for the Revision local host. It stands in for the game server.
# Serves GET/HEAD for files under -Root on 127.0.0.1 only. No admin rights, no installs.
# Android device: adb reverse tcp:<Port> tcp:<Port>, then the device's 127.0.0.1:<Port> is this PC.
param(
    [Parameter(Mandatory = $true)][string]$Root,
    [int]$Port = 18080,
    [string]$ReadyFile
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Root = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
if (!(Test-Path -LiteralPath $Root -PathType Container)) { throw "Root not found: $Root" }
$types = @{ '.json' = 'application/json'; '.bundle' = 'application/octet-stream'; '.hash' = 'text/plain'; '.bin' = 'application/octet-stream' }
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Port)
$listener.Start()
if ($ReadyFile) { [IO.File]::WriteAllText($ReadyFile, "http://127.0.0.1:$Port") }
Write-Host "Serving $Root at http://127.0.0.1:$Port (Ctrl+C to stop)"

function Send([IO.Stream]$Stream, [int]$Code, [string]$Reason, [byte[]]$Body, [string]$Type, [bool]$Head) {
    $header = "HTTP/1.1 $Code $Reason`r`nContent-Type: $Type`r`nContent-Length: $($Body.Length)`r`nConnection: close`r`nCache-Control: no-store`r`n`r`n"
    $bytes = [Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($bytes, 0, $bytes.Length)
    if (!$Head -and $Body.Length) { $Stream.Write($Body, 0, $Body.Length) }
}

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $client.ReceiveTimeout = 10000
            $stream = $client.GetStream()
            $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 4096, $true)
            $line = $reader.ReadLine()
            while ($true) { $h = $reader.ReadLine(); if ($null -eq $h -or $h -eq '') { break } }
            $parts = if ($line) { $line.Split(' ') } else { @() }
            if ($parts.Count -lt 2 -or ($parts[0] -ne 'GET' -and $parts[0] -ne 'HEAD')) { Send $stream 405 'Method Not Allowed' @() 'text/plain' $false; continue }
            $head = $parts[0] -eq 'HEAD'
            $path = [Uri]::UnescapeDataString($parts[1].Split('?')[0]).TrimStart('/')
            $segments = $path.Split('/') | Where-Object { $_ -ne '' }
            $bad = @($segments | Where-Object { $_ -eq '.' -or $_ -eq '..' -or $_.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 }).Count -gt 0
            $file = if ($bad -or !$segments) { $null } else { [IO.Path]::GetFullPath((Join-Path $Root ($segments -join '\'))) }
            if (!$file -or !$file.StartsWith($Root, [StringComparison]::OrdinalIgnoreCase) -or !(Test-Path -LiteralPath $file -PathType Leaf)) {
                Write-Host "404 /$path"
                Send $stream 404 'Not Found' @() 'text/plain' $head
                continue
            }
            $type = $types[[IO.Path]::GetExtension($file).ToLowerInvariant()]
            if (!$type) { $type = 'application/octet-stream' }
            Write-Host "200 /$path"
            Send $stream 200 'OK' ([IO.File]::ReadAllBytes($file)) $type $head
        }
        catch { Write-Host "Request failed: $($_.Exception.Message)" }
        finally { $client.Close() }
    }
}
finally { $listener.Stop() }
