using System;
using System.Reflection;
using NUnit.Framework;

namespace Artress.ManagedAddressables.Tests
{
    public sealed class ManagedAddressableRevisionStartupTests
    {
        private static readonly string Sha = new string('a', 64);
        internal static ManagedRevisionApplication App()
        {
            var packaged = ManagedAddressableRevision.CreatePackaged("A", "file:///C:/StreamingAssets/catalog.json",
                "file:///C:/StreamingAssets/publisher.json", Sha, "StandaloneWindows64", "file:///C:/StreamingAssets/bundles");
            return new ManagedRevisionApplication("product", "channel", "authority", packaged);
        }
        private static ManagedRevisionPublisher Publisher(long sequence, string family = "F") => new ManagedRevisionPublisher
        {
            productId = "product", channel = "channel", authorityId = "authority", target = "StandaloneWindows64",
            compatibilityFamily = family, deploymentSequence = sequence
        };
        private static object Call(ManagedRevisionApplication app, string method, params object[] arguments)
            => typeof(ManagedRevisionApplication).GetMethod(method, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(app, arguments);

        [TestCase(30, "F", 20, "F", false)]
        [TestCase(15, "F", 20, "F", true)]
        [TestCase(30, "F", 20, "G", true)]
        [TestCase(15, "F", 20, "G", true)]
        [TestCase(20, "F", 20, "F", false)]
        public void ApplicationChoiceUsesTrustedScopeFamilyAndSequence(long confirmed, string oldFamily,
            long packaged, string newFamily, bool install)
        {
            Assert.That(Call(App(), "SelectPackaged", Publisher(confirmed, oldFamily), Sha,
                Publisher(packaged, newFamily)), Is.EqualTo(install));
        }

        [Test]
        public void SameSequenceDifferentPublisherIsAmbiguous()
        {
            var error = Assert.Throws<TargetInvocationException>(() =>
                Call(App(), "SelectPackaged", Publisher(20), new string('b', 64), Publisher(20)));
            Assert.That(error.InnerException.Message, Is.EqualTo("AmbiguousEqualDeploymentSequence"));
        }

        [TestCase("productId")]
        [TestCase("target")]
        [TestCase("channel")]
        [TestCase("authorityId")]
        [TestCase("compatibilityFamily")]
        public void UnknownOrMismatchedDeploymentScopeCannotSelectPackaged(string field)
        {
            var confirmed = Publisher(10);
            typeof(ManagedRevisionPublisher).GetField(field).SetValue(confirmed,
                field == "compatibilityFamily" ? null : "other");
            var error = Assert.Throws<TargetInvocationException>(() =>
                Call(App(), "SelectPackaged", confirmed, Sha, Publisher(20)));
            Assert.That(error.InnerException.Message, Is.EqualTo("RevisionDeploymentMetadataMissingOrScopeMismatch"));
        }

        [TestCase(0)]
        [TestCase(-1)]
        public void MissingOrInvalidDeploymentSequenceRequiresRecovery(long sequence)
        {
            Assert.Throws<TargetInvocationException>(() =>
                Call(App(), "SelectPackaged", Publisher(sequence), Sha, Publisher(20)));
        }

        [TestCase(25, false)]
        [TestCase(30, false)]
        [TestCase(35, true)]
        public void FallbackToOlderCompatibleBDoesNotRelaxRemoteAdvance(long candidate, bool accepted)
        {
            // B20 can run after packaged A'30 failed; startup still retries A'30.
            Assert.That(Call(App(), "SelectPackaged", Publisher(20), Sha, Publisher(30)), Is.True);
            if (accepted)
                Assert.DoesNotThrow(() => Call(App(), "RequireRemoteCandidate", Publisher(candidate), Publisher(20), Publisher(30)));
            else
                Assert.Throws<TargetInvocationException>(() => Call(App(), "RequireRemoteCandidate",
                    Publisher(candidate), Publisher(20), Publisher(30)));
        }

        [Test]
        public void RemoteCandidateCannotChangeCurrentApplicationFamily()
        {
            Assert.Throws<TargetInvocationException>(() => Call(App(), "RequireRemoteCandidate",
                Publisher(40, "G"), Publisher(20), Publisher(30)));
        }

        [Test]
        public void ApplicationRequiresAnExplicitPackagedSource()
        {
            var remote = new ManagedAddressableRevision("A", "https://example.invalid/catalog.json",
                "https://example.invalid/publisher.json", Sha, "StandaloneWindows64");
            Assert.Throws<ArgumentException>(() => new ManagedRevisionApplication("product", "channel", "authority", remote));
        }

        [TestCase("https://example.invalid/bundles")]
        [TestCase("../bundles")]
        public void PackagedBundleSourceCannotBeRemoteOrRelative(string root)
        {
            Assert.Throws<ArgumentException>(() => ManagedAddressableRevision.CreatePackaged("A",
                "file:///C:/StreamingAssets/catalog.json", "file:///C:/StreamingAssets/publisher.json",
                Sha, "StandaloneWindows64", root));
        }
    }
}
