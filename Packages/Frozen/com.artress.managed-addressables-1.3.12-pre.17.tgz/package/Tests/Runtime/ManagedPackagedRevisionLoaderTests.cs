using System;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace Artress.ManagedAddressables.Tests
{
    // The public anchor loader and the development local host pointer. No file or network access.
    public sealed class ManagedPackagedRevisionLoaderTests
    {
        private static readonly string Sha = new string('a', 64);

        private static string Anchor(int schema = 1, string catalog = "catalog.json") =>
            "{\"schemaVersion\":" + schema + ",\"revisionId\":\"rev-a\",\"target\":\"StandaloneWindows64\",\"publisherSha256\":\"" + Sha +
            "\",\"productId\":\"product\",\"channel\":\"pc-a\",\"authorityId\":\"team\",\"compatibilityFamily\":\"F\",\"deploymentSequence\":3," +
            "\"catalogRelativePath\":\"" + catalog + "\",\"publisherRelativePath\":\"publisher.json\",\"bundleRelativeRoot\":\"bundles\"}";

        [Test]
        public void AFileRootBecomesFileUrisAndTheScopeComesFromTheAnchor()
        {
            string root = Path.Combine(Path.GetTempPath(), "anchor-root", ManagedPackagedRevisionLoader.StreamingRoot);
            var application = ManagedPackagedRevisionLoader.FromAnchorJson(Anchor(), root);
            Assert.AreEqual("product", application.ProductId);
            Assert.AreEqual("pc-a", application.Channel);
            Assert.AreEqual("team", application.AuthorityId);
            var packaged = application.PackagedRevision;
            Assert.AreEqual("rev-a", packaged.RevisionId);
            Assert.AreEqual(Path.GetFullPath(Path.Combine(root, "catalog.json")), packaged.CatalogPath);
            Assert.AreEqual(Path.GetFullPath(Path.Combine(root, "publisher.json")), packaged.PublisherPath);
            Assert.AreEqual(new Uri(Path.GetFullPath(Path.Combine(root, "bundles"))).AbsoluteUri.TrimEnd('/'), packaged.PackagedBundleRoot);
        }

        [Test]
        public void AnAndroidJarRootStaysAJarUrl()
        {
            const string root = "jar:file:///data/app/game/base.apk!/assets/" + ManagedPackagedRevisionLoader.StreamingRoot;
            var packaged = ManagedPackagedRevisionLoader.FromAnchorJson(Anchor(), root).PackagedRevision;
            StringAssert.StartsWith("jar:file:", packaged.CatalogPath);
            StringAssert.EndsWith("/catalog.json", packaged.CatalogPath);
            StringAssert.StartsWith("jar:file:", packaged.PackagedBundleRoot);
        }

        [TestCase("")]
        [TestCase("{}")]
        [TestCase("schema2")]
        [TestCase("escape")]
        public void AnInvalidAnchorIsRefused(string kind)
        {
            string json = kind == "schema2" ? Anchor(2) : kind == "escape" ? Anchor(catalog: "../outside/catalog.json") : kind;
            Assert.Throws<InvalidDataException>(() => ManagedPackagedRevisionLoader.FromAnchorJson(json, Path.GetTempPath()));
        }

        private static ManagedRevisionLocalHostPointer Pointer() => new ManagedRevisionLocalHostPointer
        {
            revisionId = "rev-b", target = "StandaloneWindows64", productId = "product", channel = "pc-a", authorityId = "team",
            compatibilityFamily = "F", deploymentSequence = 4,
            catalogUrl = "https://127.0.0.1/qa/split/revision/s/catalog_1.json", publisherUrl = "https://127.0.0.1/qa/split/revision/s/revision_publisher.json", publisherSha256 = Sha
        };

        [Test]
        public void ThePointerRoundTripsAndBecomesARemoteRevision()
        {
            var parsed = ManagedRevisionLocalHostPointer.Parse(JsonUtility.ToJson(Pointer()));
            Assert.AreEqual(4, parsed.deploymentSequence);
            var revision = parsed.ToRevision();
            Assert.AreEqual("rev-b", revision.RevisionId);
            Assert.AreEqual(Pointer().catalogUrl, revision.CatalogPath);
            Assert.AreEqual(Sha, revision.ExpectedPublisherSha256);
            Assert.IsTrue(revision.HasTrustedPublisher);
            Assert.AreEqual(string.Empty, revision.PackagedBundleRoot, "A pointer never names a packaged Revision.");
        }

        [TestCase("")]
        [TestCase("not json")]
        [TestCase("schema")]
        [TestCase("missing-sha")]
        [TestCase("missing-target")]
        public void AnIncompletePointerIsRefused(string kind)
        {
            var pointer = Pointer();
            if (kind == "schema") pointer.schemaVersion = 2;
            if (kind == "missing-sha") pointer.publisherSha256 = "";
            if (kind == "missing-target") pointer.target = null;
            string json = kind == "" || kind == "not json" ? kind : JsonUtility.ToJson(pointer);
            Assert.Catch<Exception>(() => ManagedRevisionLocalHostPointer.Parse(json));
        }
    }
}
