using System;
using System.IO;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Artress.ManagedAddressables.Tests
{
    // Replacement while another process briefly holds the destination open (Windows indexer,
    // antivirus or a file watcher). Uses a temporary folder only.
    public sealed class ManagedFileReplaceTests
    {
        private string folder;

        [SetUp]
        public void SetUp()
        {
            folder = Path.Combine(Path.GetTempPath(), "managed-file-replace-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(folder);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(folder)) Directory.Delete(folder, true);
        }

        [Test]
        public void ADestinationHeldBrieflyIsStillReplaced()
        {
            string source = Path.Combine(folder, "next.json"), destination = Path.Combine(folder, "current.json");
            File.WriteAllText(source, "new"); File.WriteAllText(destination, "old");
            var holder = new FileStream(destination, FileMode.Open, FileAccess.Read, FileShare.Read);
            var release = Task.Run(async () => { await Task.Delay(120); holder.Dispose(); });
            try { ManagedFileReplace.Replace(source, destination); }
            finally { release.Wait(); holder.Dispose(); }
            Assert.AreEqual("new", File.ReadAllText(destination));
            Assert.IsFalse(File.Exists(source));
        }

        [Test]
        public void ADestinationHeldPastEveryRetryFailsWithBothFilesUnchanged()
        {
            string source = Path.Combine(folder, "next.json"), destination = Path.Combine(folder, "current.json");
            File.WriteAllText(source, "new"); File.WriteAllText(destination, "old");
            using (new FileStream(destination, FileMode.Open, FileAccess.Read, FileShare.Read))
                Assert.That(() => ManagedFileReplace.Replace(source, destination), Throws.InstanceOf<IOException>().Or.InstanceOf<UnauthorizedAccessException>());
            Assert.AreEqual("old", File.ReadAllText(destination));
            Assert.AreEqual("new", File.ReadAllText(source));
        }

        [Test]
        public void AMissingDestinationIsMovedIntoPlace()
        {
            string source = Path.Combine(folder, "next.json"), destination = Path.Combine(folder, "current.json");
            File.WriteAllText(source, "new");
            ManagedFileReplace.ReplaceOrMove(source, destination);
            Assert.AreEqual("new", File.ReadAllText(destination));
            Assert.IsFalse(File.Exists(source));
        }
    }
}
