using System;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine.ResourceManagement.ResourceLocations;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;

namespace Artress.ManagedAddressables.Tests
{
    public sealed class ManagedAddressableRevisionContractTests
    {
        private static ManagedRevisionApplyCallbacks NoCallbacks() => new ManagedRevisionApplyCallbacks(
            token => Task.FromResult(new ManagedRevisionBoundary(0, 0, 0, 0, true, "nothing owned")), (revision, token) => Task.FromResult(true));

        [TestCase(null)]
        [TestCase("")]
        [TestCase(" ")]
        public void RevisionRequiresCallerIdentity(string revisionId)
        {
            Assert.Throws<ArgumentException>(() => new ManagedAddressableRevision(revisionId, "https://example.invalid/A/catalog.json"));
        }

        [TestCase("catalog.json")]
        [TestCase("https://example.invalid/A/catalog.bin")]
        [TestCase("ftp://example.invalid/A/catalog.json")]
        public void RevisionRejectsUnpinnedOrUnsupportedCatalogSource(string path)
        {
            Assert.Throws<ArgumentException>(() => new ManagedAddressableRevision("A", path));
        }

        [Test]
        public void RemoteRevisionPreservesPinnedSourceAndOptionalBuildIdentity()
        {
            var revision = new ManagedAddressableRevision("A", "https://example.invalid/A/catalog.json?revision=A", "expected-build");
            Assert.That(revision.CatalogPath, Is.EqualTo("https://example.invalid/A/catalog.json?revision=A"));
            Assert.That(revision.ExpectedBuildResultHash, Is.EqualTo("expected-build"));
            Assert.That(revision.RevisionId, Is.EqualTo("A"));
        }

        [Test]
        public void DisplayedUrlsDropTheSignatureWhileStoredUrlsKeepIt()
        {
            const string signed = "https://user:secret@cdn.example.invalid/A/catalog.json?sig=SECRET&exp=1";
            Assert.That(ManagedRevisionTransport.Displayed(new Uri(signed)), Is.EqualTo("https://cdn.example.invalid/A/catalog.json"));
            Assert.That(ManagedRevisionTransport.WithoutQuery("Failed " + signed.Replace("user:secret@", "") + " with 403"), Is.EqualTo("Failed https://cdn.example.invalid/A/catalog.json with 403"));
            Assert.That(ManagedRevisionTransport.WithoutQuery("HTTP/1.1 404 Not Found"), Is.EqualTo("HTTP/1.1 404 Not Found"));
            Assert.That(ManagedRevisionTransport.WithoutQuery(null), Is.Null);
            Assert.That(new ManagedAddressableRevision("A", signed).CatalogPath, Is.EqualTo(signed));
        }

        [Test]
        public void PlainHttpFailsUntilTheDevelopmentSettingAllowsIt()
        {
            const string catalog = "http://127.0.0.1:9/A/catalog.json", publisher = "http://127.0.0.1:9/A/publisher.json";
            string sha = new string('a', 64);
            try
            {
                ManagedRevisionTransport.TestOverride = false;
                Assert.Throws<ArgumentException>(() => new ManagedAddressableRevision("A", catalog));
                Assert.Throws<ArgumentException>(() => new ManagedAddressableRevision("A", "https://example.invalid/A/catalog.json", publisher, sha, "StandaloneWindows64"));
                ManagedRevisionTransport.TestOverride = true;
                Assert.That(new ManagedAddressableRevision("A", catalog, publisher, sha, "StandaloneWindows64").CatalogPath, Is.EqualTo(catalog));
            }
            finally { ManagedRevisionTransport.TestOverride = null; }
        }

        [TestCase(1, 0, 0, 0, true, "handles remain")]
        [TestCase(0, 1, 0, 0, true, "instance remains")]
        [TestCase(0, 0, 1, 0, true, "scene remains")]
        [TestCase(0, 0, 0, 1, true, "request remains")]
        [TestCase(0, 0, 0, 0, false, "unload pending")]
        [TestCase(0, 0, 0, 0, true, "")]
        public void CleanupRequiresEveryConsumerAndAnEvidenceBackedUnload(int handles, int instances, int scenes,
            int operations, bool unloaded, string evidence)
        {
            Assert.That(new ManagedRevisionBoundary(handles, instances, scenes, operations, unloaded, evidence).IsReady, Is.False);
        }

        [Test]
        public void CleanupRejectsImpossibleOwnerCounts()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new ManagedRevisionBoundary(-1, 0, 0, 0, true, "invalid"));
        }

        [Test]
        public async Task OwnedOpenRequiresBootObjectInsteadOfDefaultLocatorIds()
        {
            var session = new ManagedAddressableRevisionSession();
            var result = await session.OpenForApplicationAsync((IResourceLocator)null, ManagedAddressableRevisionStartupTests.App(), NoCallbacks());
            Assert.That(result.Error, Does.Contain("BootLocatorNotRegistered"));
            Assert.That(session.State, Is.EqualTo(ManagedRevisionState.Created));
            Assert.That(session.CanStartConsumers, Is.False);
        }

        [Test]
        public async Task PreparationAndActivationCannotSkipBootSelection()
        {
            var session = new ManagedAddressableRevisionSession();
            var prepared = await session.PrepareAsync(new ManagedAddressableRevision("B", "https://example.invalid/B/catalog.json"));
            var applied = await session.ApplyAsync((ManagedRevisionApplyCallbacks)null);
            Assert.That(prepared.Success, Is.False);
            Assert.That(applied.Success, Is.False);
            Assert.That(session.State, Is.EqualTo(ManagedRevisionState.Created));
            Assert.That(session.LastConfirmedRevision, Is.Null);
            Assert.That(session.CanStartConsumers, Is.False);
        }

        [TestCase(null)]
        [TestCase("")]
        [TestCase("0123")]
        [TestCase("gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg")]
        public void OwnedRevisionRequiresAnExactPublisherTrustAnchor(string sha)
        {
            Assert.Throws<ArgumentException>(() => new ManagedAddressableRevision("A", "https://example.invalid/A/catalog.json",
                "https://example.invalid/A/publisher.json", sha, "StandaloneWindows64"));
        }

        [Test]
        public void OwnedRevisionKeepsTrustSeparateFromTheSdkBuildHash()
        {
            var revision = new ManagedAddressableRevision("A", "https://example.invalid/A/catalog.json",
                "https://example.invalid/A/publisher.json", new string('A', 64), "StandaloneWindows64", "sdk-metadata");
            Assert.That(revision.HasTrustedPublisher, Is.True);
            Assert.That(revision.ExpectedPublisherSha256, Is.EqualTo(new string('a', 64)));
            Assert.That(revision.Target, Is.EqualTo("StandaloneWindows64"));
            Assert.That(revision.ExpectedBuildResultHash, Is.EqualTo("sdk-metadata"));
            Assert.That(new ManagedAddressableRevision("no-publisher", "https://example.invalid/catalog.json").HasTrustedPublisher, Is.False);
        }

        [Test]
        public async Task OwnedOpenRejectsAnUnregisteredBootObjectBeforeReadingStorage()
        {
            var session = new ManagedAddressableRevisionSession();
            var unregistered = new ResourceLocationMap("caller-created-not-sdk-boot");
            var result = await session.OpenForApplicationAsync(unregistered, ManagedAddressableRevisionStartupTests.App(), NoCallbacks());
            Assert.That(result.Success, Is.False);
            Assert.That(result.Error, Does.Contain("BootLocatorNotRegistered"));
            Assert.That(session.State, Is.EqualTo(ManagedRevisionState.Created));
            Assert.That(session.LastConfirmedRevision, Is.Null);
        }

        [Test]
        public void OwnedApplyRequiresSeparateCleanupAndValidationCallbacks()
        {
            Assert.Throws<ArgumentNullException>(() => new ManagedRevisionApplyCallbacks(null,
                (revision, token) => Task.FromResult(true)));
            Assert.Throws<ArgumentNullException>(() => new ManagedRevisionApplyCallbacks(
                token => Task.FromResult(new ManagedRevisionBoundary(0, 0, 0, 0, true, "Revision drained; Boot handles retained")), null));
        }

        [Test]
        public void PostAckFailureKeepsBAndCannotEnterPreCommitARecovery()
        {
            // Own implementation state test, not an SDK/fault-hook or power-loss test.
            var session = new ManagedAddressableRevisionSession();
            var a = new ManagedAddressableRevision("A", "https://example.invalid/A/catalog.json");
            var b = new ManagedAddressableRevision("B", "https://example.invalid/B/catalog.json");
            Type leaseType = typeof(ManagedAddressableRevisionSession).GetNestedType("CatalogLease", BindingFlags.NonPublic);
            object oldLease = Activator.CreateInstance(leaseType, true), candidate = Activator.CreateInstance(leaseType, true);
            leaseType.GetField("Revision").SetValue(oldLease, a);
            leaseType.GetField("Revision").SetValue(candidate, b);
            typeof(ManagedAddressableRevisionSession).GetField("active", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(session, oldLease);
            var before = Addressables.ResourceLocators.ToArray();
            var method = typeof(ManagedAddressableRevisionSession).GetMethod("FailAfterConfirmedCommit", BindingFlags.Instance | BindingFlags.NonPublic);
            var result = (ManagedRevisionResult)method.Invoke(session, new[] { candidate, new InvalidOperationException("post-ACK cleanup failure") });
            Assert.That(result.Success, Is.False);
            Assert.That(result.RecoveryRequired, Is.True);
            Assert.That(result.CommitOutcome, Is.EqualTo(ManagedRevisionCommitOutcome.Confirmed));
            Assert.That(result.RecoveredLastConfirmed, Is.False);
            Assert.That(session.LastConfirmedRevision, Is.SameAs(b));
            Assert.That(session.ActiveRevision, Is.SameAs(b));
            Assert.That(session.State, Is.EqualTo(ManagedRevisionState.RecoveryRequired));
            Assert.That(session.CanStartConsumers, Is.False);
            Assert.That(Addressables.ResourceLocators.ToArray(), Is.EqualTo(before));
        }

        [TestCase("none")]
        [TestCase("boot")]
        [TestCase("active")]
        [TestCase("transform")]
        public async Task DeferredApplyCanResumeAOnlyWhenItsOwnedRegistrationIsIntact(string mutation)
        {
            var session = new ManagedAddressableRevisionSession();
            var boot = new ResourceLocationMap("pre8-boot", 0);
            var a = new ResourceLocationMap("pre8-A", 0);
            var b = new ResourceLocationMap("pre8-B", 0);
            var type = typeof(ManagedAddressableRevisionSession);
            var flags = BindingFlags.Instance | BindingFlags.NonPublic;
            var owner = type.GetField("owner", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.That(owner.GetValue(null), Is.Null);
            var priorTransform = Addressables.InternalIdTransformFunc;
            Func<IResourceLocation, string> transform = location => priorTransform == null ? location.InternalId : priorTransform(location);
            Type leaseType = type.GetNestedType("CatalogLease", BindingFlags.NonPublic);
            object active = Activator.CreateInstance(leaseType, true), prepared = Activator.CreateInstance(leaseType, true);
            var revisionA = new ManagedAddressableRevision("A", "https://example.invalid/A/catalog.json");
            var revisionB = new ManagedAddressableRevision("B", "https://example.invalid/B/catalog.json");
            leaseType.GetField("Revision").SetValue(active, revisionA); leaseType.GetField("Locator").SetValue(active, a);
            leaseType.GetField("Revision").SetValue(prepared, revisionB); leaseType.GetField("Locator").SetValue(prepared, b);
            foreach (var pair in new[] { new { Name = "active", Value = active }, new { Name = "prepared", Value = prepared },
                new { Name = "bootLocator", Value = (object)boot }, new { Name = "ownedTransform", Value = (object)transform },
                new { Name = "previousTransform", Value = (object)priorTransform }, new { Name = "ownedFlow", Value = (object)true } })
                type.GetField(pair.Name, flags).SetValue(session, pair.Value);
            type.GetField("<State>k__BackingField", flags).SetValue(session, ManagedRevisionState.Prepared);
            owner.SetValue(null, session); Addressables.InternalIdTransformFunc = transform;
            Addressables.AddResourceLocator(boot); Addressables.AddResourceLocator(a);
            try
            {
                var locators = Addressables.ResourceLocators.ToArray();
                var result = await session.ApplyAsync(new ManagedRevisionApplyCallbacks(
                    token => Task.FromResult(new ManagedRevisionBoundary(1, 0, 0, 0, true, "held Revision handle")),
                    (revision, token) => throw new InvalidOperationException("Validation must not run for a deferred boundary")));
                Assert.That(result.Success, Is.False); Assert.That(result.Deferred, Is.True);
                Assert.That(session.CanStartConsumers, Is.False);
                Assert.That(Addressables.ResourceLocators.ToArray(), Is.EqualTo(locators));
                if (mutation == "boot") Addressables.RemoveResourceLocator(boot);
                if (mutation == "active") Addressables.RemoveResourceLocator(a);
                if (mutation == "transform") Addressables.InternalIdTransformFunc = priorTransform;
                if (mutation != "none")
                {
                    var denied = session.ResumeCurrentRevision();
                    Assert.That(denied.Success, Is.False); Assert.That(denied.RecoveryRequired, Is.True);
                    Assert.That(session.CanStartConsumers, Is.False);
                    Assert.That(session.PreparedRevision, Is.SameAs(revisionB));
                    return;
                }
                Assert.That(session.ResumeCurrentRevision().Success, Is.True);
                Assert.That(session.CanStartConsumers, Is.True);
                Assert.That(session.PreparedRevision, Is.SameAs(revisionB));
                Assert.That(session.ActiveRevision, Is.SameAs(revisionA));
                Assert.That(Addressables.ResourceLocators.ToArray(), Is.EqualTo(locators));
                session.DiscardPrepared();
                Assert.That(session.State, Is.EqualTo(ManagedRevisionState.Ready));
                Assert.That(session.PreparedRevision, Is.Null);
            }
            finally
            {
                Addressables.InternalIdTransformFunc = transform;
                await session.CloseAsync(token => Task.FromResult(new ManagedRevisionBoundary(0, 0, 0, 0, true, "test cleanup")));
                Addressables.RemoveResourceLocator(boot); Addressables.RemoveResourceLocator(a); Addressables.RemoveResourceLocator(b);
                Addressables.InternalIdTransformFunc = priorTransform; owner.SetValue(null, null);
            }
        }

        [Test]
        public void ResumeRejectsAStateThatNeverDeferred()
        {
            var session = new ManagedAddressableRevisionSession();
            var result = session.ResumeCurrentRevision();
            Assert.That(result.Success, Is.False);
            Assert.That(result.Deferred, Is.False);
            Assert.That(session.State, Is.EqualTo(ManagedRevisionState.Created));
        }

        [TestCase(ManagedRevisionState.Applying)]
        [TestCase(ManagedRevisionState.RecoveryRequired)]
        public void ResumeCannotEnableConsumersInAnotherState(ManagedRevisionState state)
        {
            var session = new ManagedAddressableRevisionSession();
            typeof(ManagedAddressableRevisionSession).GetField("<State>k__BackingField", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(session, state);
            Assert.That(session.ResumeCurrentRevision().Success, Is.False);
            Assert.That(session.State, Is.EqualTo(state));
            Assert.That(session.CanStartConsumers, Is.False);
        }

        [Test]
        public void PreviousBundleCheckIncludesRemovedContentAndExcludesShaIdenticalSharedContent()
        {
            Type filesType = typeof(ManagedAddressableRevisionSession).Assembly.GetType("Artress.ManagedAddressables.ManagedRevisionFiles", true);
            object a = Activator.CreateInstance(filesType), b = Activator.CreateInstance(filesType);
            string shared = new string('a', 64);
            filesType.GetField("Publisher").SetValue(a, new ManagedRevisionPublisher { bundles = new[] {
                new ManagedRevisionPublisherBundle { fileSha256 = new string('b', 64), sdkBundleName = "General.Case" },
                new ManagedRevisionPublisherBundle { fileSha256 = shared, sdkBundleName = "SharedMono" },
                new ManagedRevisionPublisherBundle { fileSha256 = new string('c', 64), sdkBundleName = "Removed.Case" } } });
            filesType.GetField("Publisher").SetValue(b, new ManagedRevisionPublisher { bundles = new[] {
                new ManagedRevisionPublisherBundle { fileSha256 = new string('d', 64), sdkBundleName = "General.Case" },
                new ManagedRevisionPublisherBundle { fileSha256 = shared.ToUpperInvariant(), sdkBundleName = "SharedMono" } } });
            var method = typeof(ManagedAddressableRevisionSession).GetMethod("PreviousExclusiveBundleNames", BindingFlags.Static | BindingFlags.NonPublic);
            string[] names = (string[])method.Invoke(null, new[] { a, b });
            Assert.That(names, Is.EqualTo(new[] { "General.Case.bundle", "Removed.Case.bundle" }));
            var constructor = typeof(ManagedRevisionResult).GetConstructor(BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(string[]) }, null);
            var deferred = (ManagedRevisionResult)constructor.Invoke(new object[] { names });
            Assert.That(deferred.Deferred, Is.True);
            Assert.That(deferred.RemainingBundleNames, Is.EqualTo(names));
            names[0] = "caller mutation";
            Assert.That(deferred.RemainingBundleNames[0], Is.EqualTo("General.Case.bundle"));
        }

        [TestCase("534e0e480f0fffed7c9fb04c4520b29d.bundle", true)]
        [TestCase("534e0e480f0fffed7c9fb04c4520b29d.bundle_e5ac21f1d80496ff411af8a3336a11df", true)]
        [TestCase("534e0e480f0fffed7c9fb04c4520b29d.bundle_", false)]
        [TestCase("534e0e480f0fffed7c9fb04c4520b29d.bundles", false)]
        [TestCase("other.bundle_e5ac21f1d80496ff411af8a3336a11df", false)]
        public void ALoadedRemoteBundleMatchesItsStemWithTheSdkSuffix(string loaded, bool expected)
        {
            var method = typeof(ManagedAddressableRevisionSession).GetMethod("IsLoadedNameOf", BindingFlags.Static | BindingFlags.NonPublic);
            Assert.That((bool)method.Invoke(null, new object[] { loaded, "534e0e480f0fffed7c9fb04c4520b29d.bundle" }), Is.EqualTo(expected));
        }

        [Test] public async Task ConfirmedRepairCannotRunBeforeEnteringRecovery()
        {
            var session = new ManagedAddressableRevisionSession();
            var result = await session.RepairConfirmedAsync(new ManagedAddressableRevision("A", "https://example.invalid/A/catalog.json"));
            Assert.That(result.Success, Is.False);
            Assert.That(session.State, Is.EqualTo(ManagedRevisionState.Created));
            Assert.That(session.CanStartConsumers, Is.False);
            Assert.That(result.ReasonCode, Is.EqualTo(ManagedRevisionReasonCode.None));
        }

        [Test]
        public async Task FailedOpenBeforeActiveRevalidatesCatalogShaAndPreservesTheOriginalError()
        {
            if (Application.platform != RuntimePlatform.WindowsEditor && Application.platform != RuntimePlatform.WindowsPlayer)
                Assert.Ignore("Windows diagnostic IO regression; mobile Native is not claimed.");
            string name = "open-fail-" + Guid.NewGuid().ToString("N");
            var storage = new ManagedAddressableRevisionStorage(name, 0, 10);
            string root = (string)typeof(ManagedAddressableRevisionStorage).GetProperty("RootDirectory", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(storage);
            string expectedRoot = Path.GetFullPath(Path.Combine(Application.persistentDataPath, "Artress.ManagedAddressables", name));
            Assert.That(Path.GetFullPath(root), Is.EqualTo(expectedRoot).IgnoreCase);
            string Hash(byte[] bytes) { using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
            try
            {
                byte[] originalCatalog = Encoding.UTF8.GetBytes("{}"), blob = Encoding.UTF8.GetBytes("x");
                var publisher = new ManagedRevisionPublisher { revisionId = "A", target = "StandaloneWindows64", catalogFile = "catalog.json",
                    catalogSha256 = Hash(originalCatalog), catalogBytes = originalCatalog.Length,
                    productId = "product", channel = "test", authorityId = "test-authority", compatibilityFamily = "F", deploymentSequence = 1,
                    bundles = new[] { new ManagedRevisionPublisherBundle { fileName = "fixture.bundle", fileSha256 = Hash(blob), bytes = 1, sdkBundleName = "fixture", sdkHash = new string('1', 32) } } };
                byte[] publisherBytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(publisher)); string publisherSha = Hash(publisherBytes);
                string metadata = Path.Combine(root, "revisions", publisherSha); Directory.CreateDirectory(metadata);
                string publisherPath = Path.Combine(metadata, "publisher.json"), catalogPath = Path.Combine(metadata, "catalog.json");
                File.WriteAllBytes(publisherPath, publisherBytes); File.WriteAllBytes(catalogPath, Encoding.UTF8.GetBytes("!!")); // Same length, different SHA.
                string blobs = Path.Combine(root, "blobs", publisher.target); Directory.CreateDirectory(blobs);
                File.WriteAllBytes(Path.Combine(blobs, Hash(blob) + ".bundle"), blob);
                Type filesType = typeof(ManagedAddressableRevisionSession).Assembly.GetType("Artress.ManagedAddressables.ManagedRevisionFiles");
                object files = Activator.CreateInstance(filesType, true);
                filesType.GetField("Revision").SetValue(files, new ManagedAddressableRevision("A", new Uri(catalogPath).AbsoluteUri,
                    new Uri(publisherPath).AbsoluteUri, publisherSha, publisher.target));
                filesType.GetField("Publisher").SetValue(files, publisher); filesType.GetField("PublisherSha256").SetValue(files, publisherSha);
                filesType.GetField("CatalogLocalPath").SetValue(files, catalogPath); filesType.GetField("MetadataDirectory").SetValue(files, metadata);
                var session = new ManagedAddressableRevisionSession(storage);
                var sdkFailure = new InvalidOperationException("SDK parse failed before active locator registration");
                var method = typeof(ManagedAddressableRevisionSession).GetMethod("RevalidateFailedOpenAsync", BindingFlags.Instance | BindingFlags.NonPublic);
                var error = await (Task<Exception>)method.Invoke(session, new object[] { files, sdkFailure });
                Assert.That(error, Is.TypeOf<AggregateException>());
                Assert.That(((AggregateException)error).InnerExceptions[0], Is.SameAs(sdkFailure));
                Assert.That((int)typeof(ManagedAddressableRevisionStorage).GetProperty("LastCatalogShaChecks", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(storage), Is.GreaterThan(0));
                Assert.That(session.ActiveRevision, Is.Null);
                Assert.That(session.State, Is.EqualTo(ManagedRevisionState.RecoveryRequired));
                Assert.That(session.CanStartConsumers, Is.False);
                Assert.That(File.Exists(Path.Combine(root, "confirmed.json")), Is.False); // Diagnostics never creates/reconfirms a pointer.
            }
            finally
            {
                // Only this freshly generated, checked absolute namespace is removed.
                if (Path.GetFullPath(root).Equals(expectedRoot, StringComparison.OrdinalIgnoreCase) && Directory.Exists(root)) Directory.Delete(root, true);
            }
        }
    }
}
