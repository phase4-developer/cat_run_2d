using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.ResourceManagement.Util;

namespace Artress.ManagedAddressables.Editor
{
    // Bounded purpose-build overlay. It snapshots only the selected Settings and the reviewed
    // owned Group/schema write targets. Interrupted recovery uses one limited pending snapshot.
    internal sealed partial class ManagedBootstrapSplitSettingsScope
    {
        private readonly string settingsPath;
        private readonly Dictionary<string, byte[]> raw = new Dictionary<string, byte[]>(StringComparer.Ordinal);
        private readonly Dictionary<string, string> live = new Dictionary<string, string>(StringComparer.Ordinal);
        private readonly Dictionary<string, string> observedFiles = new Dictionary<string, string>(StringComparer.Ordinal);
        private readonly string providerType;
        private readonly SerializedType bundledProviderBefore;
        private readonly SerializedType bundleProviderBefore;
        private readonly Dictionary<string, Dictionary<string, string>> bundleIds = new Dictionary<string, Dictionary<string, string>>(StringComparer.Ordinal);
        internal readonly string before;

        internal ManagedBootstrapSplitSettingsScope(AddressableAssetSettings settings, IEnumerable<UnityEngine.Object> writeTargets)
        {
            settingsPath = AssetDatabase.GetAssetPath(settings);
            providerType = settings.CatalogProviderType?.AssemblyQualifiedName;
            bundledProviderBefore = settings.BundledAssetProviderType;
            bundleProviderBefore = settings.AssetBundleProviderType;
            before = Effective(settings);
            foreach (var group in settings.groups.Where(g => g != null))
                bundleIds[AssetDatabase.GetAssetPath(group)] = group.entries.ToDictionary(e => e.guid, e => e.BundleFileId);
            foreach (var value in writeTargets.Append(settings).Where(v => v != null).Distinct())
            {
                string path = AssetDatabase.GetAssetPath(value);
                if (!path.StartsWith("Assets/", StringComparison.Ordinal) || !File.Exists(path) || EditorUtility.IsDirty(value))
                    throw new InvalidOperationException("Purpose-build write target must be a clean, persistent Assets asset: " + path);
                raw[path] = File.ReadAllBytes(path);
                live[path] = EditorJsonUtility.ToJson(value);
            }
            // Observe all active input assets, including foreign schemas. Never rewrite them.
            foreach (var value in settings.groups.Where(g => g != null).SelectMany(g => g.Schemas.Cast<UnityEngine.Object>().Append(g)).Append(settings))
            {
                if (value == null) continue;
                string path = AssetDatabase.GetAssetPath(value);
                if (File.Exists(path)) observedFiles[path] = ManagedAddressableBuildExporter.SplitFileHash(path);
                if (File.Exists(path + ".meta")) observedFiles[path + ".meta"] = ManagedAddressableBuildExporter.SplitFileHash(path + ".meta");
            }
        }

        internal void Restore(ManagedSplitBuildReceipt receipt)
        {
            var errors = new List<string>();
            // Schemas/groups before Settings: importing a Group invokes official SDK callbacks.
            // Reapply the original Settings last, without an editor-wide SaveAssets call.
            foreach (var path in raw.Keys.OrderBy(p => p == settingsPath ? 1 : 0).ThenBy(p => p, StringComparer.Ordinal))
            {
                try
                {
                    if (!File.Exists(path) || !File.ReadAllBytes(path).SequenceEqual(raw[path])) File.WriteAllBytes(path, raw[path]);
                    AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
                    var value = AssetDatabase.LoadMainAssetAtPath(path);
                    if (value == null) throw new InvalidOperationException("Input asset could not be reloaded: " + path);
                    EditorJsonUtility.FromJsonOverwrite(live[path], value);
                    EditorUtility.ClearDirty(value);
                }
                catch (Exception error) { errors.Add(path + ": " + error.Message); }
            }
            var restored = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(settingsPath);
            foreach (var pair in bundleIds)
            {
                var group = AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(pair.Key);
                if (group == null) { errors.Add("Group could not be reloaded: " + pair.Key); continue; }
                // BuildPlayerContent clears this nonserialized SDK result property for all Groups.
                // Restore only that transient value, including foreign Groups; no schema/entry edit.
                foreach (var entry in group.entries) if (pair.Value.TryGetValue(entry.guid, out var id)) entry.BundleFileId = id;
            }
            try
            {
                // SerializedType retains a nonserialized cached Type after an overwrite in SDK4.0.1.
                // Supplying the captured provider via the public SDK setter restores its live value.
                if (restored == null || string.IsNullOrEmpty(providerType)) throw new InvalidOperationException("Cannot restore the captured Catalog provider type.");
                restored.CatalogProviderType = Type.GetType(providerType, true);
                RestoreSdkDefaultedProviders(restored);
                receipt.effectiveAfter = Effective(restored);
                receipt.effectiveSettingsRestored = before == receipt.effectiveAfter;
                if (!receipt.effectiveSettingsRestored) errors.Add("Public effective Settings/Include/schema values differ after restore.");
            }
            catch (Exception error) { errors.Add(error.Message); }
            receipt.rawSettingsRestored = observedFiles.All(pair => File.Exists(pair.Key) && ManagedAddressableBuildExporter.SplitFileHash(pair.Key) == pair.Value);
            if (!receipt.rawSettingsRestored) errors.Add("Settings/Group/schema/meta bytes differ after restore, including read-only inputs.");
            if (errors.Count != 0) throw new InvalidOperationException("Purpose-build restoration is uncertain; this build cannot be promoted.\n" + string.Join("\n", errors));
            CompletePendingSettings();
        }

        private void RestoreSdkDefaultedProviders(AddressableAssetSettings settings)
        {
            // SDK4.0.1 OnAfterDeserialize fills empty types; SerializedObject.Apply invokes
            // that callback again, and JSON overwrite can retain a stale cached Type for
            // custom providers. Public setters propagate into every Group schema. Restore
            // the two captured structs (names AND cached Type) without those side effects.
            RestoreProviderStruct(settings, "m_BundledAssetProviderType", bundledProviderBefore, typeof(BundledAssetProvider));
            RestoreProviderStruct(settings, "m_AssetBundleProviderType", bundleProviderBefore, typeof(AssetBundleProvider));
        }

        private static void RestoreProviderStruct(AddressableAssetSettings settings, string name, SerializedType original, Type sdkDefault)
        {
            if (ManagedAddressableBuildExporter.AddressablesVersion != "4.0.1")
                throw new InvalidOperationException("Provider struct restoration requires the verified Addressables 4.0.1 adapter.");
            var field = typeof(AddressableAssetSettings).GetField(name, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly);
            if (field == null || field.FieldType != typeof(SerializedType) || field.IsInitOnly)
                throw new InvalidOperationException("SDK4.0.1 provider struct adapter is unavailable: " + name);
            var current = (SerializedType)field.GetValue(settings);
            // Resolve on a copy: keep the originally captured struct/cache unchanged.
            var originalForValidation = original;
            Type originalType = originalForValidation.Value;
            bool sameNames = (current.AssemblyName ?? "") == (original.AssemblyName ?? "") && (current.ClassName ?? "") == (original.ClassName ?? "");
            bool originallyEmpty = string.IsNullOrEmpty(original.AssemblyName) && string.IsNullOrEmpty(original.ClassName);
            bool exactDefaultBackfill = originallyEmpty && current.AssemblyName == sdkDefault.Assembly.GetName().Name && current.ClassName == sdkDefault.FullName && current.Value == sdkDefault;
            bool knownCacheState = current.Value == originalType || current.Value == sdkDefault;
            if ((!sameNames || !knownCacheState) && !exactDefaultBackfill)
                throw new InvalidOperationException("Unexpected Global provider state after restore; only original names/cache or the observed SDK default backfill is supported: " + name);
            field.SetValue(settings, original);
        }

        internal static string Effective(AddressableAssetSettings settings)
        {
            return JsonConvert.SerializeObject(new
            {
                provider = settings.CatalogProviderType?.AssemblyQualifiedName,
                bundledProvider = ProviderState(settings.BundledAssetProviderType),
                bundleProvider = ProviderState(settings.AssetBundleProviderType),
                json = settings.EnableJsonCatalog,
                remote = settings.BuildRemoteCatalog,
                bundleLocalCatalog = settings.BundleLocalCatalog,
                startup = settings.DisableCatalogUpdateOnStartup,
                playerBuild = settings.BuildAddressablesWithPlayerBuild.ToString(),
                settings.activeProfileId,
                remoteBuild = settings.RemoteCatalogBuildPath.GetValue(settings),
                remoteLoad = settings.RemoteCatalogLoadPath.GetValue(settings),
                shared = settings.SharedBundleSettings.ToString(),
                sharedGuid = ManagedAddressableBuildExporter.SplitGuid(settings.GetSharedBundleGroup()),
                mono = settings.MonoScriptBundleNaming.ToString(), settings.MonoScriptBundleCustomNaming,
                builtin = settings.BuiltInBundleNaming.ToString(), settings.BuiltInBundleCustomNaming,
                settings.UniqueBundleIds,
                groups = settings.groups.Where(g => g != null).OrderBy(ManagedAddressableBuildExporter.SplitGuid, StringComparer.Ordinal).Select(g => new
                {
                    guid = ManagedAddressableBuildExporter.SplitGuid(g), include = g.IncludeInBuild,
                    schemas = g.Schemas.Where(s => s != null).Select(EditorJsonUtility.ToJson).ToArray()
                }).ToArray()
            });
        }

        private static object ProviderState(SerializedType value) => new
        {
            assembly = value.AssemblyName ?? string.Empty,
            type = value.ClassName ?? string.Empty,
            publicType = value.Value?.AssemblyQualifiedName
        };
    }
}
