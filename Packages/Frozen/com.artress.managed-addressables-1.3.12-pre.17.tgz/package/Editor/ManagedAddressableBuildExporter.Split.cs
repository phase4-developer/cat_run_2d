using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Build;
using UnityEditor.AddressableAssets.Build.Layout;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEditor.Build;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.Initialization;
using UnityEngine.AddressableAssets.ResourceProviders;
using UnityEngine.ResourceManagement.ResourceProviders;

namespace Artress.ManagedAddressables.Editor
{
    internal static partial class ManagedAddressableBuildExporter
    {
        public static ManagedSplitBuildPlan CreateSplitBuildPlan(ManagedAddressableProjectConfig config, ManagedGroupBuildRole purpose)
        {
            var plan = new ManagedSplitBuildPlan { purpose = purpose, stamp = DateTime.UtcNow.ToString("yyyyMMdd") + "-" + Guid.NewGuid().ToString("N").Substring(0, 16), report = ValidateSplitBuild(config, purpose) };
            if (config == null) return plan;
            try
            {
                var settings = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration();
                if (settings == null) return plan;
                plan.outputDirectory = Path.Combine(SplitOutputRoot(config), purpose.ToString().ToLowerInvariant(), plan.stamp);
                plan.fingerprint = SplitFingerprint(config, settings);
                plan.contentFingerprint = SplitContentFingerprint(config, settings);
                plan.effectiveFingerprint = ManagedBootstrapSplitSettingsScope.Effective(settings);
                bool boot = purpose == ManagedGroupBuildRole.Boot;
                if (!boot)
                {
                    var release = ManagedLocalRelease.Effective(config);
                    ApplyReleaseMetadata(new ManagedRevisionPublisher(), release);
                    plan.changes.Add("[Publisher] Explicit product=" + release.productId + "; channel=" + release.channel + " (this PC); authority=" + release.authorityId + "; family=" + release.compatibilityFamily + "; deploymentSequence=" + release.deploymentSequence + " (this PC). No sequence is generated.");
                }
                plan.changes.Add("[Global temporary] CatalogProviderType: " + settings.CatalogProviderType?.FullName + " -> " + (boot ? typeof(BinaryCatalogProvider).FullName : typeof(JsonCatalogProvider).FullName));
                plan.changes.Add("[Global temporary] BuildRemoteCatalog: " + settings.BuildRemoteCatalog + " -> " + !boot + "; BundleLocalCatalog -> False; ContentStateBuildPath -> " + Path.Combine(plan.outputDirectory, "ContentState"));
                plan.changes.Add("[Output] Append-only reviewed stamp: " + plan.outputDirectory + "; SDK staging: " + Path.GetFullPath(Addressables.BuildPath));
                plan.changes.Add("[Output] Windows SDK snapshot destinations must be shorter than 260 characters. Actual SDK file paths are checked together before any snapshot copy; shorten the configured output root/project path if this build exceeds the limit.");
                foreach (var role in (config.groupBuildRoles ?? new List<ManagedGroupBuildRoleSetting>()).Where(r => r != null))
                {
                    var group = settings.groups.FirstOrDefault(g => g != null && string.Equals(SplitGuid(g), role.groupAssetGuid, StringComparison.OrdinalIgnoreCase));
                    if (group == null) continue;
                    plan.changes.Add("[Group temporary] " + group.Name + " / " + role.groupAssetGuid + ": IncludeInBuild " + group.IncludeInBuild + " -> " + (role.role == purpose));
                    if (!boot && role.role == purpose && group.HasSchema<BundledAssetGroupSchema>())
                        plan.changes.Add("[Group temporary] " + role.groupAssetGuid + ": BuildPath -> " + Path.Combine(plan.outputDirectory, "Remote") + "; LoadPath -> " + RevisionLoadRoot(group.GetSchema<BundledAssetGroupSchema>(), settings, plan.stamp));
                    if (role.role == purpose && role.useForSharedBundles)
                        plan.changes.Add("[Global temporary] SharedBundleSettings.CustomGroup -> " + role.groupAssetGuid + "; MonoScript/BuiltIn Custom naming -> " + SplitPrefix(role));
                }
                plan.changes.Add("[Global temporary] GenerateBuildLayout -> True. Profile values, cache/CRC/naming style and Entry address/GUID remain unchanged.");
                plan.changes.Add("[Restore] Exact touched Settings/owned Group/schema bytes and public effective provider/Include/path values are required; uncertainty rejects this build. Forced termination/domain reload is not a restoration guarantee; incomplete receipts cannot be packaged.");
                plan.changes.Add("[Player only] Official SDK order1 copies " + settings.ConfigFolder + "/link.xml; the bounded packaging scope restores its captured bytes/meta after the Player build. SDK automatic Addressables rebuild must remain DoNotBuildWithPlayer.");
            }
            catch (Exception e) { plan.report.errors.Add(e.Message); }
            return plan;
        }

        public static ManagedBuildExportResult BuildBootContent(ManagedAddressableProjectConfig config) => BuildSplitContent(config, ManagedGroupBuildRole.Boot, null);
        public static ManagedBuildExportResult BuildRevisionContent(ManagedAddressableProjectConfig config) => BuildSplitContent(config, ManagedGroupBuildRole.Revision, null);
        public static ManagedBuildExportResult BuildReviewedSplitContent(ManagedAddressableProjectConfig config, ManagedSplitBuildPlan plan) => BuildSplitContent(config, plan.purpose, null, plan);

        private static string SplitPrefix(ManagedGroupBuildRoleSetting role) => "jjevol_" + role.groupAssetGuid.ToLowerInvariant() + "_" + role.role.ToString().ToLowerInvariant();
        private static string RevisionLoadRoot(BundledAssetGroupSchema schema, AddressableAssetSettings settings, string stamp) => schema.LoadPath.GetValue(settings).TrimEnd('/') + "/split/revision/" + stamp;
        // SDK4.0.1 ProfileValueReference explicitly supports literals in its serialized Id.
        // Public setters accept only variable references. Keep this serialized adapter version-bound.
        private static ProfileValueReference SplitLiteral(string value)
        {
            var reference = JsonUtility.FromJson<ProfileValueReference>("{\"m_Id\":" + JsonConvert.SerializeObject(value.Replace('\\', '/')) + "}");
            if (reference == null || reference.Id != value.Replace('\\', '/')) throw new InvalidOperationException("SDK literal path adapter failed.");
            return reference;
        }

        private static ManagedBuildExportResult BuildSplitContent(ManagedAddressableProjectConfig config, ManagedGroupBuildRole purpose,
            BuildPlayerContext playerContext, ManagedSplitBuildPlan reviewed = null)
        {
            var export = new ManagedBuildExportResult();
            var receipt = new ManagedSplitBuildReceipt { purpose = purpose.ToString() };
            ManagedBootstrapSplitSettingsScope scope = null;
            bool entered = false;
            bool layoutBefore = ProjectConfigData.GenerateBuildLayout;
            string receiptPath = null;
            try
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating || ManagedAddressableBuildExporter.BuildInProgress || (BuildPipeline.isBuildingPlayer && playerContext == null))
                    throw new InvalidOperationException("Purpose content build cannot run during Play, import, compilation or another build.");
                if (playerContext != null && (purpose != ManagedGroupBuildRole.Boot || playerContext.BuildPlayerOptions.target != EditorUserBuildSettings.activeBuildTarget))
                    throw new InvalidOperationException("Automatic Boot creation is allowed only in the official current-target Player build context.");
                var plan = reviewed ?? CreateSplitBuildPlan(config, purpose);
                if (!plan.CanBuild) throw new InvalidOperationException(plan.Report.ToString());
                var settings = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration();
                if (plan.purpose != purpose || plan.fingerprint != SplitFingerprint(config, settings) || plan.effectiveFingerprint != ManagedBootstrapSplitSettingsScope.Effective(settings))
                    throw new InvalidOperationException("Purpose build plan is stale. Preview again; no temporary settings were written.");
                var recheck = ValidateSplitBuild(config, purpose);
                if (!recheck.CanBuild) throw new InvalidOperationException(recheck.ToString());
                if (Directory.Exists(plan.outputDirectory)) throw new InvalidOperationException("Reviewed output stamp already exists; Preview again. Existing successful output will not be overwritten.");
                Directory.CreateDirectory(plan.outputDirectory);
                receiptPath = Path.Combine(plan.outputDirectory, "split_build_receipt.json");
                export.outputDirectory = plan.outputDirectory;
                export.splitReceiptPath = receiptPath;
                receipt.stamp = plan.stamp; receipt.outputDirectory = plan.outputDirectory;
                receipt.platform = EditorUserBuildSettings.activeBuildTarget.ToString(); receipt.appVersion = PlayerSettings.bundleVersion;
                receipt.unityVersion = Application.unityVersion; receipt.addressablesVersion = ManagedAddressableBuildExporter.AddressablesVersion;
                receipt.configAssetGuid = SplitGuid(config); receipt.settingsAssetGuid = SplitGuid(settings);
                receipt.inputFingerprint = plan.fingerprint; receipt.effectiveInput = plan.effectiveFingerprint;
                receipt.contentFingerprint = plan.contentFingerprint;
                var entries = SplitEntries(config, settings);
                string configPath = AssetDatabase.GetAssetPath(config);
                string settingsPath = AssetDatabase.GetAssetPath(settings);
                var roles = config.groupBuildRoles.Where(r => r != null).ToList();
                var sharedRole = roles.Single(r => r.role == purpose && r.useForSharedBundles);
                var sharedGroup = settings.groups.Single(g => g != null && SplitGuid(g) == sharedRole.groupAssetGuid);
                var writeTargets = new List<UnityEngine.Object>();
                foreach (var group in settings.groups.Where(g => g != null))
                {
                    var role = roles.FirstOrDefault(r => string.Equals(r.groupAssetGuid, SplitGuid(group), StringComparison.OrdinalIgnoreCase));
                    if (role == null || role.role == ManagedGroupBuildRole.Unassigned) continue;
                    if (group.IncludeInBuild != (role.role == purpose)) writeTargets.Add(group);
                    if (purpose == ManagedGroupBuildRole.Revision && role.role == purpose && group.HasSchema<BundledAssetGroupSchema>()) writeTargets.Add(group.GetSchema<BundledAssetGroupSchema>());
                }
                scope = new ManagedBootstrapSplitSettingsScope(settings, writeTargets);
                receipt.effectiveBefore = scope.before;
                scope.PersistBeforeTemporaryWrites();
                WriteSplitJson(receiptPath, receipt);
                // Invalidates any previous stage receipt before Clean/build can replace the SDK files.
                WriteSplitJson(SplitStagePointer(), receipt);
                ManagedAddressableBuildExporter.BuildInProgress = true; entered = true;
                ProjectConfigData.GenerateBuildLayout = true;
                bool boot = purpose == ManagedGroupBuildRole.Boot;
                settings.CatalogProviderType = boot ? typeof(BinaryCatalogProvider) : typeof(JsonCatalogProvider);
                settings.BuildRemoteCatalog = !boot; settings.BundleLocalCatalog = false;
                settings.ContentStateBuildPath = Path.Combine(plan.outputDirectory, "ContentState");
                string remote = Path.Combine(plan.outputDirectory, "Remote");
                foreach (var group in settings.groups.Where(g => g != null))
                {
                    var role = roles.FirstOrDefault(r => string.Equals(r.groupAssetGuid, SplitGuid(group), StringComparison.OrdinalIgnoreCase));
                    if (role == null || role.role == ManagedGroupBuildRole.Unassigned) continue;
                    bool included = role.role == purpose;
                    if (group.IncludeInBuild != included) group.IncludeInBuild = included;
                    var schema = group.GetSchema<BundledAssetGroupSchema>();
                    if (!boot && included && schema != null)
                    {
                        string load = RevisionLoadRoot(schema, settings, plan.stamp);
                        JsonUtility.FromJsonOverwrite(JsonUtility.ToJson(SplitLiteral(remote)), schema.BuildPath);
                        JsonUtility.FromJsonOverwrite(JsonUtility.ToJson(SplitLiteral(load)), schema.LoadPath);
                        if (schema.BuildPath.GetValue(settings).Replace('\\', '/') != remote.Replace('\\', '/') || schema.LoadPath.GetValue(settings) != load)
                            throw new InvalidOperationException("Actual SDK literal path evaluation differs from the reviewed paths: " + SplitGuid(group));
                    }
                }
                if (!boot)
                {
                    settings.RemoteCatalogBuildPath = SplitLiteral(remote);
                    settings.RemoteCatalogLoadPath = SplitLiteral(sharedGroup.GetSchema<BundledAssetGroupSchema>().LoadPath.GetValue(settings));
                }
                settings.SharedBundleSettings = SharedBundleSettings.CustomGroup;
                settings.SharedBundleSettingsCustomGroupIndex = settings.groups.IndexOf(sharedGroup);
                if (SplitGuid(settings.GetSharedBundleGroup()) != sharedRole.groupAssetGuid) throw new InvalidOperationException("Official SDK shared Group selection differs from the reviewed asset GUID.");
                settings.MonoScriptBundleNaming = MonoScriptBundleNaming.Custom; settings.MonoScriptBundleCustomNaming = SplitPrefix(sharedRole);
                settings.BuiltInBundleNaming = BuiltInBundleNaming.Custom; settings.BuiltInBundleCustomNaming = SplitPrefix(sharedRole);
                // All inputs were clean before overlay. Targeted saves persist only reviewed temporary writes.
                foreach (var value in writeTargets.Append(settings).Distinct()) { EditorUtility.SetDirty(value); AssetDatabase.SaveAssetIfDirty(value); }
                scope.RecordSavedTemporarySettings();
                AddressableAssetSettings.CleanPlayerContent(settings.ActivePlayerDataBuilder);
                DateTime started = DateTime.UtcNow;
                AddressableAssetSettings.BuildPlayerContent(out AddressablesPlayerBuildResult built);
                if (built == null || !string.IsNullOrEmpty(built.Error)) throw new InvalidOperationException("Official SDK content build failed: " + (built?.Error ?? "no result"));
                // SDK builders may unload unused editor assets. Reacquire persistent inputs,
                // rather than relying on C# stack references surviving that operation.
                config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(configPath);
                settings = AssetDatabase.LoadAssetAtPath<AddressableAssetSettings>(settingsPath);
                if (config == null || settings == null) throw new InvalidOperationException("Persistent build inputs could not be reloaded after the SDK build.");
                entries = SplitEntries(config, settings);
                receipt.runtimeDirectory = Path.Combine(plan.outputDirectory, "Runtime");
                CopySplitTree(Addressables.BuildPath, receipt.runtimeDirectory);
                receipt.runtimeFiles = SplitInventory(receipt.runtimeDirectory);
                string ext = boot ? ".bin" : ".json";
                string catalogRoot = boot ? receipt.runtimeDirectory : remote;
                var catalogs = Directory.GetFiles(catalogRoot, "catalog*" + ext, SearchOption.TopDirectoryOnly);
                if (catalogs.Length != 1) throw new InvalidOperationException("This build must emit exactly one " + purpose + " " + ext + " Catalog.");
                receipt.catalogPath = catalogs[0]; receipt.catalogFormat = boot ? "binary" : "json"; receipt.catalogSha256 = SplitFileHash(catalogs[0]);
                var catalog = ManagedCatalogSnapshot.ReadSplit(catalogs[0]);
                InspectSplitCatalog(config, settings, purpose, plan, entries, catalog, built, receipt);
                InspectSplitLayout(settings, config, purpose, catalog, started, receipt);
                if (boot)
                {
                    var data = JsonUtility.FromJson<ResourceManagerRuntimeData>(File.ReadAllText(Path.Combine(receipt.runtimeDirectory, "settings.json")));
                    if (data == null || data.CatalogLocations.Count != 1 || data.CatalogLocations.Any(c => c.Dependencies != null && c.Dependencies.Length != 0))
                        throw new InvalidOperationException("Boot default Catalog must have zero remote/cache dependencies in the actual SDK runtime data.");
                }
                export.warnings.AddRange(recheck.Warnings);
                export.warnings.Add("Purpose content only.");
            }
            catch (Exception e) { receipt.error = e.ToString(); export.error = receipt.error; }
            finally
            {
                if (scope != null)
                {
                    try { scope.Restore(receipt); }
                    catch (Exception restore) { receipt.error = (receipt.error ?? "") + "\n" + restore; export.error = receipt.error; }
                }
                ProjectConfigData.GenerateBuildLayout = layoutBefore;
                if (entered) ManagedAddressableBuildExporter.BuildInProgress = false;
                receipt.complete = string.IsNullOrEmpty(receipt.error) && receipt.rawSettingsRestored && receipt.effectiveSettingsRestored;
                export.success = receipt.complete;
                if (receipt.complete && purpose == ManagedGroupBuildRole.Revision)
                {
                    try
                    {
                        WriteRevisionPublisher(receipt, config == null ? null : ManagedLocalRelease.Effective(config));
                        export.warnings.Add("Revision publisher: " + receipt.publisherPath + "; expected SHA-256: " + receipt.publisherSha256 + ". Supply this anchor through the trusted Revision API; the list does not authenticate itself.");
                    }
                    catch (Exception error) { receipt.complete = false; export.success = false; receipt.error = export.error = "Revision publisher failed: " + error; }
                }
                if (receiptPath != null)
                {
                    try { WriteSplitJson(receiptPath, receipt); WriteSplitJson(SplitStagePointer(), receipt); }
                    catch (Exception error) { export.success = false; export.error = (export.error ?? "") + "\nReceipt persistence failed: " + error; }
                }
            }
            return export;
        }

        private static string SplitValue(ManagedCatalogEntrySnapshot entry, string field) => entry.values.TryGetValue(field, out var raw) ? (string)JToken.Parse(raw) : null;
        private static void InspectSplitCatalog(ManagedAddressableProjectConfig config, AddressableAssetSettings settings, ManagedGroupBuildRole purpose,
            ManagedSplitBuildPlan plan, List<ManagedSplitEntry> entries, ManagedCatalogSnapshot catalog, AddressablesPlayerBuildResult built, ManagedSplitBuildReceipt receipt)
        {
            var keys = new HashSet<string>(catalog.entries.SelectMany(e => e.keys), StringComparer.Ordinal);
            receipt.keys = keys.OrderBy(k => k, StringComparer.Ordinal).ToList();
            var included = new HashSet<string>(entries.Where(e => e.role == purpose).SelectMany(e => e.keys), StringComparer.Ordinal);
            var excluded = new HashSet<string>(entries.Where(e => e.role != purpose).SelectMany(e => e.keys).Except(included), StringComparer.Ordinal);
            receipt.commonLabels = included.Intersect(entries.Where(e => e.role != purpose).SelectMany(e => e.keys), StringComparer.Ordinal).OrderBy(k => k, StringComparer.Ordinal).ToList();
            receipt.exclusiveRoleKeys = included.Except(receipt.commonLabels, StringComparer.Ordinal).OrderBy(k => k, StringComparer.Ordinal).ToList();
            foreach (var key in included) if (!keys.Contains(key)) throw new InvalidOperationException("Expected role key is absent from the actual Catalog: " + key);
            foreach (var key in excluded) if (keys.Contains(key)) throw new InvalidOperationException("Opposite-role key leaked into the actual Catalog: " + key);
            if (purpose == ManagedGroupBuildRole.Boot)
            {
                foreach (var key in config.requiredBootKeys) if (!keys.Contains(key)) throw new InvalidOperationException("Actual Boot Catalog is missing required key: " + key);
            }
            else
            {
                foreach (var path in PlayerInputPaths())
                {
                    string resourceKey = path.Contains("/Resources/") ? Path.ChangeExtension(path.Substring(path.LastIndexOf("/Resources/", StringComparison.Ordinal) + 11), null) : path;
                    foreach (var key in new[] { path, AssetDatabase.AssetPathToGUID(path), resourceKey })
                        if (!string.IsNullOrEmpty(key) && keys.Contains(key) && !included.Contains(key)) throw new InvalidOperationException("SDK automatic Scene/Resources key leaked into Revision Catalog: " + key);
                }
            }
            foreach (var entry in catalog.entries.Where(e => e.values.ContainsKey("Data.BundleName")))
            {
                string name = SplitValue(entry, "Data.BundleName");
                var source = built.AssetBundleBuildResults.SingleOrDefault(b => b.InternalBundleName == name);
                if (source == null || !File.Exists(source.FilePath)) throw new InvalidOperationException("Catalog bundle has no physical result from this actual SDK build: " + name);
                var schema = (source.SourceAssetGroup ?? settings.GetSharedBundleGroup()).GetSchema<BundledAssetGroupSchema>();
                string hash = SplitValue(entry, "Data.Hash") ?? "";
                if (hash.All(digit => digit == '0')) hash = ""; // A binary Catalog returns an empty SDK Hash as the zero Hash128.
                uint crc = uint.Parse(SplitValue(entry, "Data.Crc") ?? "0", System.Globalization.CultureInfo.InvariantCulture);
                if (hash != (schema.UseAssetBundleCache ? source.Hash : "") || crc != (schema.UseAssetBundleCrc ? source.Crc : 0)) throw new InvalidOperationException("Catalog cache Hash/CRC differs from the actual SDK result/settings: " + name);
                string id = entry.values["InternalId"];
                if (entry.values.TryGetValue("Data.ClearOtherCachedVersionsWhenLoaded", out var clear) && bool.Parse(clear))
                    throw new InvalidOperationException("Catalog would delete another Revision cache version: " + name);
                bool generated = name.EndsWith("_monoscripts", StringComparison.Ordinal) || name.Contains("unitybuiltinshaders");
                if (generated)
                {
                    var target = config.groupBuildRoles.Single(r => r.role == purpose && r.useForSharedBundles);
                    if (!name.StartsWith(SplitPrefix(target), StringComparison.Ordinal) || (source.SourceAssetGroup != null && SplitGuid(source.SourceAssetGroup) != target.groupAssetGuid))
                        throw new InvalidOperationException("Generated shared bundle placement/name differs from the explicit role target: " + name);
                }
                if (purpose == ManagedGroupBuildRole.Revision && (!IsRevisionUrl(config, id) || !id.Contains("/split/revision/" + plan.stamp + "/") || hash.Length != 32 || !hash.All(Uri.IsHexDigit) || !Hash128.Parse(hash).isValid))
                    throw new InvalidOperationException("Revision bundle requires a pinned HTTPS URL and valid SDK Hash: " + name + " / " + id);
                if (purpose == ManagedGroupBuildRole.Boot && (IsHttp(id) || !id.Contains("Addressables.RuntimePath")))
                    throw new InvalidOperationException("Boot bundle must be physically packaged at the SDK runtime path: " + name + " / " + id);
                if (purpose == ManagedGroupBuildRole.Boot && !receipt.runtimeFiles.Any(f => Path.GetFileName(f.path) == Path.GetFileName(id) && f.sha256 == SplitFileHash(source.FilePath)))
                    throw new InvalidOperationException("Boot bundle physical bytes are absent from SDK staging: " + name);
                receipt.bundles.Add(new ManagedSplitBundleReceipt { groupAssetGuid = SplitGuid(source.SourceAssetGroup), bundleName = name, internalId = id,
                    hash = hash, crc = crc, sourceHash = source.Hash, sourceCrc = source.Crc, filePath = source.FilePath, sha256 = SplitFileHash(source.FilePath) });
            }
            if (receipt.bundles.Count == 0) throw new InvalidOperationException("No physical bundle result could be verified for the purpose Catalog.");
        }

        private static void InspectSplitLayout(AddressableAssetSettings settings, ManagedAddressableProjectConfig config, ManagedGroupBuildRole purpose,
            ManagedCatalogSnapshot catalog, DateTime started, ManagedSplitBuildReceipt receipt)
        {
            string report = ProjectConfigData.BuildReportFilePaths.Where(File.Exists).Where(p => File.GetLastWriteTimeUtc(p) >= started.AddSeconds(-2)).OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
            if (report == null) throw new InvalidOperationException("No fresh SDK Build Layout is available for this build.");
            var layout = BuildLayout.Open(report, true, true);
            if (layout == null) throw new InvalidOperationException("SDK BuildLayout.Open failed.");
            try
            {
                if (!catalog.metadata.TryGetValue("BuildResultHash", out var catalogHash) || catalogHash != layout.BuildResultHash) throw new InvalidOperationException("Build Layout does not belong to this actual Catalog BuildResultHash.");
                var entries = SplitEntries(config, settings);
                var forbidden = new HashSet<string>(entries.Where(e => e.role != purpose).Select(e => e.entry.guid), StringComparer.Ordinal);
                foreach (var group in layout.Groups)
                {
                    var actual = settings.groups.FirstOrDefault(g => g != null && g.Guid == group.Guid);
                    var role = config.groupBuildRoles.FirstOrDefault(r => r != null && string.Equals(r.groupAssetGuid, SplitGuid(actual), StringComparison.OrdinalIgnoreCase));
                    if (actual == null || role == null) throw new InvalidOperationException("Layout contains an unclassified Group: " + group.Guid);
                    // SDK4.0.1 includes excluded Groups as metadata with zero Bundles.
                    // Preserve those rows in the archived Layout; only an actual Bundle
                    // contribution from the opposite role violates physical separation.
                    var bundles = group.Bundles ?? new List<BuildLayout.Bundle>();
                    if (role.role != purpose && bundles.Count > 0) throw new InvalidOperationException("Physical layout contains a different-role Group with " + bundles.Count + " Bundle(s): " + group.Guid);
                    foreach (var bundle in bundles)
                    foreach (var file in bundle.Files)
                    {
                        foreach (var asset in file.Assets) if (forbidden.Contains(asset.Guid)) throw new InvalidOperationException("Opposite-role explicit asset leaked into a physical bundle: " + asset.AssetPath);
                        foreach (var asset in file.OtherAssets)
                        {
                            if (forbidden.Contains(asset.AssetGuid)) receipt.implicitDuplicates.Add(asset.AssetPath + " / " + bundle.InternalName + " (read-only cross-role dependency; identity is separate)");
                        }
                    }
                }
                receipt.layoutPath = Path.Combine(receipt.outputDirectory, "sdk_build_layout.json");
                File.Copy(report, receipt.layoutPath, false); receipt.layoutSha256 = SplitFileHash(receipt.layoutPath);
            }
            finally { layout.Close(); }
        }

        private static string SplitStagePointer() => Path.Combine("Library", "ArtressManagedAddressablesSplit", EditorUserBuildSettings.activeBuildTarget.ToString(), "stage_receipt.json");
        private static void WriteSplitJson(string path, object value) { Directory.CreateDirectory(Path.GetDirectoryName(path)); File.WriteAllText(path, JsonConvert.SerializeObject(value, Formatting.Indented)); }
        private static List<ManagedSplitFileStamp> SplitInventory(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).Select(p => new ManagedSplitFileStamp { path = p.Substring(root.Length).TrimStart('/', '\\').Replace('\\', '/'), sha256 = SplitFileHash(p) }).OrderBy(p => p.path, StringComparer.Ordinal).ToList();
        private static void CopySplitTree(string source, string destination)
        {
            if (!Directory.Exists(source)) throw new DirectoryNotFoundException(source);
            var copies = Directory.GetFiles(source, "*", SearchOption.AllDirectories).Select(path => new
            {
                source = path,
                target = Path.GetFullPath(Path.Combine(destination, path.Substring(source.Length).TrimStart('/', '\\')))
            }).ToArray();
            // Unity's Windows Mono FileStream can fail to open a long snapshot even when
            // File.Copy created it successfully. Validate every actual destination before
            // copying, instead of publishing an archive that its verifier cannot read.
            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                var tooLong = copies.FirstOrDefault(copy => copy.target.Length >= 260);
                if (tooLong != null)
                    throw new InvalidOperationException("Split SDK snapshot destination exceeds the Windows Editor path limit (" + tooLong.target.Length + " characters; maximum 259): " + tooLong.target + ". Shorten buildOutputRoot or the project path and Preview again. No snapshot files were copied.");
            }
            Directory.CreateDirectory(destination);
            foreach (var copy in copies)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(copy.target)); File.Copy(copy.source, copy.target, false);
            }
        }

        public static ManagedSplitBuildReport ValidatePlayerStaging(ManagedAddressableProjectConfig config)
        {
            var report = ValidateSplitBuild(config, ManagedGroupBuildRole.Boot);
            if (!report.CanBuild) return report;
            try
            {
                if (!File.Exists(SplitStagePointer())) throw new InvalidOperationException("No successful Boot receipt exists for the current SDK stage. Build Player Boot content first, or use the official Split Player build hook.");
                var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(SplitStagePointer()));
                var settings = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration();
                if (receipt == null || !receipt.complete || receipt.purpose != "Boot" || receipt.catalogFormat != "binary" || !receipt.rawSettingsRestored || !receipt.effectiveSettingsRestored)
                    throw new InvalidOperationException("Current SDK stage is Revision, incomplete or restore-uncertain; this Player build cannot package it.");
                if (receipt.configAssetGuid != SplitGuid(config) || receipt.settingsAssetGuid != SplitGuid(settings) || receipt.inputFingerprint != SplitFingerprint(config, settings) || receipt.effectiveInput != ManagedBootstrapSplitSettingsScope.Effective(settings) || receipt.platform != EditorUserBuildSettings.activeBuildTarget.ToString() || receipt.appVersion != PlayerSettings.bundleVersion || receipt.unityVersion != Application.unityVersion || receipt.addressablesVersion != ManagedAddressableBuildExporter.AddressablesVersion)
                    throw new InvalidOperationException("Boot receipt is stale for the current Config/roles/SDK Settings/assets/Player inputs/target/version.");
                var actual = SplitInventory(Addressables.BuildPath);
                if (actual.Count != receipt.runtimeFiles.Count || !actual.Zip(receipt.runtimeFiles, (a, b) => a.path == b.path && a.sha256 == b.sha256).All(b => b))
                    throw new InvalidOperationException("Actual SDK BuildPath file set/SHA differs from the verified Boot receipt. Revision/stale output cannot enter this Player.");
                if (!File.Exists(receipt.catalogPath) || SplitFileHash(receipt.catalogPath) != receipt.catalogSha256) throw new InvalidOperationException("Archived Boot Catalog bytes differ from the receipt.");
            }
            catch (Exception e) { report.errors.Add(e.Message); }
            return report;
        }
    }
}
