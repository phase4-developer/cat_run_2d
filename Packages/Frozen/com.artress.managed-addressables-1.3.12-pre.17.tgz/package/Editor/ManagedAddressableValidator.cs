using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;

namespace Artress.ManagedAddressables.Editor
{
    internal static class ManagedAddressableValidator
    {
        public static List<string> Validate(ManagedAddressableProjectConfig config)
        {
            var errors = new List<string>();
            if (config == null) { errors.Add("Managed Addressables 설정 에셋이 없습니다."); return errors; }
            AddressableAssetSettings settings;
            try { settings = ManagedAddressableSynchronizer.ReadSettingsWithoutMigration(); }
            catch (InvalidOperationException error) { errors.Add(error.Message); return errors; }
            if (settings == null) { errors.Add("Addressables Settings가 없습니다."); return errors; }
            if (string.IsNullOrWhiteSpace(config.ContentRootPath) || !Directory.Exists(config.ContentRootPath))
            {
                errors.Add("Content Root를 찾을 수 없습니다: " + config.ContentRootPath);
                return errors;
            }

            // SDK Groups/Profiles/Analyze own their valid schema settings. Names, folder
            // policies, NoHash, packing and cache/CRC preferences are not deployment errors.
            var owned = settings.groups.Where(g => g != null && config.OwnsGroup(g)).ToArray();
            foreach (var duplicate in settings.groups.Where(g => g != null).SelectMany(g => g.entries).Where(e => e != null && !string.IsNullOrEmpty(e.address))
                .GroupBy(e => e.address, StringComparer.Ordinal).Where(g => g.Select(e => e.guid).Distinct().Count() > 1 && g.Any(e => config.OwnsGroup(e.parentGroup))))
                errors.Add("중복 Address: " + duplicate.Key);
            foreach (AddressableAssetEntry entry in owned.SelectMany(g => g.entries).Where(e => e != null))
            {
                string path = entry.AssetPath;
                if (Path.GetFileName(path).Equals("LightingData.asset", StringComparison.OrdinalIgnoreCase))
                    errors.Add("LightingData.asset은 직접 Addressable Entry로 등록할 수 없습니다: " + path);
            }
            return errors;
        }
    }
}
