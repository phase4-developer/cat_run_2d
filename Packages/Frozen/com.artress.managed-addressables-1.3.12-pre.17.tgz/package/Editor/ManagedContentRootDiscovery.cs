using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets;
using UnityEditor.AddressableAssets.Settings;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedFolderCandidate
    {
        public string path;
        public int score;
        public string reason;
    }

    internal static class ManagedContentRootDiscovery
    {
        private static readonly string[] DeliveryFolders = { "Local", "Remote" };

        public static List<ManagedFolderCandidate> FindCandidates()
        {
            Dictionary<string, ManagedFolderCandidate> candidates = new Dictionary<string, ManagedFolderCandidate>(StringComparer.OrdinalIgnoreCase);
            if (!Directory.Exists("Assets"))
                return new List<ManagedFolderCandidate>();

            foreach (string deliveryFolder in DeliveryFolders)
            {
                foreach (string directory in Directory.GetDirectories("Assets", deliveryFolder, SearchOption.AllDirectories))
                {
                    string root = Normalize(Path.GetDirectoryName(directory));
                    if (string.IsNullOrEmpty(root) || IsIgnored(root))
                        continue;

                    if (!candidates.TryGetValue(root, out ManagedFolderCandidate candidate))
                    {
                        candidate = new ManagedFolderCandidate { path = root };
                        candidates.Add(root, candidate);
                    }

                    candidate.score += deliveryFolder.Equals("Remote", StringComparison.OrdinalIgnoreCase) ? 6 : 4;
                }
            }

            AddressableAssetSettings settings = AddressableAssetSettingsDefaultObject.GetSettings(false);
            foreach (ManagedFolderCandidate candidate in candidates.Values)
            {
                int deliveryCount = DeliveryFolders.Count(folder => Directory.Exists(Path.Combine(candidate.path, folder)));
                int categoryCount = DeliveryFolders
                    .Where(folder => Directory.Exists(Path.Combine(candidate.path, folder)))
                    .SelectMany(folder => Directory.GetDirectories(Path.Combine(candidate.path, folder)))
                    .Count();
                int addressableEntryCount = CountAddressableEntries(settings, candidate.path);
                int prefabCount = CountFiles(candidate.path, "*.prefab");
                int sceneCount = CountFiles(candidate.path, "*.unity");
                int atlasCount = CountFiles(candidate.path, "*.spriteatlas*");
                int skeletonCount = CountFiles(candidate.path, "*SkeletonData.asset");

                candidate.score += deliveryCount * 5 + Math.Min(categoryCount, 20);
                candidate.score += Math.Min(addressableEntryCount, 300) * 4;
                candidate.score += Math.Min(prefabCount + sceneCount + atlasCount, 100);

                string folderName = Path.GetFileName(candidate.path);
                if (folderName.IndexOf("Addressable", StringComparison.OrdinalIgnoreCase) >= 0)
                    candidate.score += 40;

                if (addressableEntryCount == 0 && skeletonCount > 0)
                    candidate.score -= Math.Min(skeletonCount, 80);

                candidate.reason = $"Delivery:{deliveryCount}, Categories:{categoryCount}, AddressableEntries:{addressableEntryCount}, Prefabs:{prefabCount}, Scenes:{sceneCount}, Atlases:{atlasCount}, SkeletonData:{skeletonCount}";
            }

            return candidates.Values
                .Where(candidate => candidate.score > 0)
                .OrderByDescending(candidate => candidate.score)
                .ThenBy(candidate => candidate.path, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        public static string ResolveDefaultPath()
        {
            List<ManagedFolderCandidate> candidates = FindCandidates();
            if (candidates.Count > 0)
                return candidates[0].path;
            return "Assets/Addressables";
        }

        private static int CountAddressableEntries(AddressableAssetSettings settings, string root)
        {
            if (settings == null)
                return 0;

            string prefix = Normalize(root) + "/";
            int count = 0;
            foreach (AddressableAssetGroup group in settings.groups)
            {
                if (group == null)
                    continue;

                foreach (AddressableAssetEntry entry in group.entries)
                {
                    string assetPath = Normalize(AssetDatabase.GUIDToAssetPath(entry.guid));
                    if (assetPath.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        count++;
                }
            }
            return count;
        }

        private static int CountFiles(string root, string pattern)
        {
            try
            {
                return Directory.Exists(root) ? Directory.GetFiles(root, pattern, SearchOption.AllDirectories).Length : 0;
            }
            catch
            {
                return 0;
            }
        }

        private static bool IsIgnored(string path)
        {
            string normalized = "/" + Normalize(path) + "/";
            return normalized.IndexOf("/Legacy/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("/Backup/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("/Temp/", StringComparison.OrdinalIgnoreCase) >= 0 ||
                normalized.IndexOf("/Demo/", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string Normalize(string value)
        {
            return (value ?? string.Empty).Replace('\\', '/').Trim('/');
        }
    }
}
