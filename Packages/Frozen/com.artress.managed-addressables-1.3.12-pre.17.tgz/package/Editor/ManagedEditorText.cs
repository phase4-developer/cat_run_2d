using UnityEditor;

namespace Artress.ManagedAddressables.Editor
{
    internal enum ManagedEditorLanguage { Korean = 0, English = 1 }

    // The Control Center and App Build messages follow one per-user language choice.
    // Unity menu paths are compile-time attribute strings, so they stay English.
    internal static class ManagedEditorText
    {
        internal const string PreferenceKey = "Artress.ManagedAddressables.EditorLanguage";

        internal static ManagedEditorLanguage Language
        {
            get => EditorPrefs.GetInt(PreferenceKey, (int)ManagedEditorLanguage.Korean) == (int)ManagedEditorLanguage.English
                ? ManagedEditorLanguage.English : ManagedEditorLanguage.Korean;
            set => EditorPrefs.SetInt(PreferenceKey, (int)value);
        }

        internal static string L(string korean, string english) => Language == ManagedEditorLanguage.English ? english : korean;
    }
}
