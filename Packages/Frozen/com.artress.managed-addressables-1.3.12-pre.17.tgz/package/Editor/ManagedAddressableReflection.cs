using System;
using System.Collections;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    internal static class ManagedAddressableReflection
    {
        private const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        public static bool SetMember(object target, string memberName, object value)
        {
            if (target == null || string.IsNullOrEmpty(memberName))
                return false;

            Type type = target.GetType();
            PropertyInfo property = type.GetProperty(memberName, Flags);
            if (property != null && property.CanWrite)
            {
                property.SetValue(target, ConvertValue(value, property.PropertyType));
                return true;
            }

            FieldInfo field = type.GetField(memberName, Flags);
            if (field != null)
            {
                field.SetValue(target, ConvertValue(value, field.FieldType));
                return true;
            }

            return false;
        }

        public static object GetMember(object target, string memberName)
        {
            if (target == null || string.IsNullOrEmpty(memberName))
                return null;

            Type type = target.GetType();
            PropertyInfo property = type.GetProperty(memberName, Flags);
            if (property != null && property.CanRead)
                return property.GetValue(target);

            FieldInfo field = type.GetField(memberName, Flags);
            return field?.GetValue(target);
        }

        public static bool Invoke(object target, string methodName, params object[] parameters)
        {
            if (target == null)
                return false;

            MethodInfo method = target.GetType().GetMethod(methodName, Flags);
            if (method == null)
                return false;

            method.Invoke(target, parameters);
            return true;
        }

        public static bool SetSerializedProperty(UnityEngine.Object target, string propertyPath, object value)
        {
            SerializedObject serializedObject = new SerializedObject(target);
            SerializedProperty property = serializedObject.FindProperty(propertyPath);
            if (property == null)
                return false;

            switch (property.propertyType)
            {
                case SerializedPropertyType.Boolean:
                    property.boolValue = Convert.ToBoolean(value);
                    break;
                case SerializedPropertyType.Integer:
                case SerializedPropertyType.Enum:
                    property.intValue = Convert.ToInt32(value);
                    break;
                case SerializedPropertyType.String:
                    property.stringValue = value?.ToString() ?? string.Empty;
                    break;
                default:
                    return false;
            }

            serializedObject.ApplyModifiedPropertiesWithoutUndo();
            return true;
        }

        public static int FindPackedModeBuilderIndex(object settings)
        {
            object builders = GetMember(settings, "DataBuilders") ?? GetMember(settings, "m_DataBuilders");
            if (!(builders is IEnumerable enumerable))
                return -1;

            int index = 0;
            foreach (object builder in enumerable)
            {
                UnityEngine.Object builderObject = builder as UnityEngine.Object;
                if (builderObject != null && builderObject.GetType().Name.IndexOf("BuildScriptPackedMode", StringComparison.OrdinalIgnoreCase) >= 0)
                    return index;
                index++;
            }

            return -1;
        }

        private static object ConvertValue(object value, Type destinationType)
        {
            if (value == null)
                return null;

            Type actualDestination = Nullable.GetUnderlyingType(destinationType) ?? destinationType;
            if (actualDestination.IsInstanceOfType(value))
                return value;

            if (actualDestination.IsEnum)
            {
                if (value is string text)
                    return Enum.Parse(actualDestination, text, true);
                return Enum.ToObject(actualDestination, value);
            }

            return Convert.ChangeType(value, actualDestination);
        }
    }
}
