using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;
using static Artress.ManagedAddressables.Editor.ManagedEditorText;

namespace Artress.ManagedAddressables.Editor
{
    // First screen: App Build and its result. Everything else lives in the Advanced sections.
    public sealed partial class ManagedAddressablesWindow : EditorWindow
    {
        private ManagedAddressableProjectConfig config;
        private SerializedObject serializedConfig;
        private Vector2 scroll;
        private bool showAdvanced;
        private readonly bool[] sections = new bool[11];
        private bool showResult = true;
        private float resultPanelHeight = 180f;
        private string resultText = string.Empty;
        private bool buildInProgress;
        private ManagedAddressableSyncPlan reviewedSyncPlan;
        private string reviewedPlanTitle;
        private bool reviewedAddressRebuild;
        private AddressableAssetGroup ownershipCandidate;

        [MenuItem("JJEvol/Addressables/Control Center", priority = 1)]
        public static void Open()
        {
            GetWindow<ManagedAddressablesWindow>("Managed Addressables");
        }

        [MenuItem("JJEvol/Addressables/Build App", priority = 2)]
        private static void BuildAppFromMenu()
        {
            GetWindow<ManagedAddressablesWindow>("Managed Addressables").StartAppBuild();
        }

        [MenuItem("JJEvol/Addressables/Build App", true)]
        private static bool CanBuildAppFromMenu() => CanRunEditorWork();

        private static bool CanRunEditorWork()
        {
            return !EditorApplication.isPlayingOrWillChangePlaymode && !EditorApplication.isCompiling && !EditorApplication.isUpdating && !BuildPipeline.isBuildingPlayer && !ManagedAddressableBuildExporter.BuildInProgress;
        }

        private void OnEnable()
        {
            minSize = new Vector2(560f, 480f);
            resultPanelHeight = Mathf.Clamp(resultPanelHeight, 140f, 280f);
            LoadConfig();
        }

        private void OnFocus() => appBuildStatusTime = 0;

        private void OnGUI()
        {
            EditorGUILayout.Space(8f);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Artress Managed Addressables", EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            var language = (ManagedEditorLanguage)EditorGUILayout.Popup((int)Language, new[] { "한국어", "English" }, GUILayout.Width(90f));
            if (language != Language) { Language = language; appBuildStatusTime = 0; }
            EditorGUILayout.EndHorizontal();

            if (config == null)
            {
                DrawCreateConfig();
                EditorGUILayout.Space(6f);
                DrawResultSection();
                return;
            }

            serializedConfig.Update();
            float footerReserve = showResult ? resultPanelHeight + 72f : 58f;
            float scrollHeight = Mathf.Max(220f, position.height - footerReserve);
            scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.Height(scrollHeight));

            DrawAppBuildSection();
            EditorGUILayout.Space(12f);
            DrawAdvancedSection();

            EditorGUILayout.EndScrollView();
            serializedConfig.ApplyModifiedProperties();
            EditorGUILayout.Space(6f);
            DrawResultSection();
        }

        private void DrawResultSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            showResult = EditorGUILayout.Foldout(showResult, L("결과", "Result"), true);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button(L("복사", "Copy"), GUILayout.Width(72f)))
                EditorGUIUtility.systemCopyBuffer = resultText ?? string.Empty;
            if (GUILayout.Button(L("지우기", "Clear"), GUILayout.Width(72f)))
                resultText = string.Empty;
            EditorGUILayout.EndHorizontal();

            if (showResult)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField(L("높이", "Height"), GUILayout.Width(78f));
                resultPanelHeight = EditorGUILayout.Slider(resultPanelHeight, 140f, 280f);
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.TextArea(resultText ?? string.Empty, GUILayout.Height(resultPanelHeight));
            }

            EditorGUILayout.EndVertical();
        }

        private void DrawCreateConfig()
        {
            EditorGUILayout.HelpBox(L("설정 에셋이 없습니다. 아래 버튼으로 기본 설정을 만들고 폴더 구조를 자동으로 찾습니다.",
                "There is no Project Config. Create the default one below; the folder layout is detected automatically."), MessageType.Warning);
            if (GUILayout.Button(L("설정 만들기", "Create Config"), GUILayout.Height(42f)))
                CreateConfigAndInitialize();
        }

        private void DrawAdvancedSection()
        {
            showAdvanced = EditorGUILayout.Foldout(showAdvanced, L("고급", "Advanced"), true, EditorStyles.foldoutHeader);
            if (!showAdvanced)
                return;

            EditorGUILayout.HelpBox(L("앱 빌드가 한 번에 하는 일을 단계별로 하거나, 처음 설정·규칙을 바꿀 때 씁니다. 미리 보기로 계획을 확인한 뒤 같은 계획을 적용합니다. 기존 Group schema·Profile·Global 수동 설정은 유지합니다.",
                "Use these to run App Build's steps one by one, or to set up and change rules. Each preview shows a plan; apply applies that same plan. Existing Group schema, Profile and global manual settings are kept."), MessageType.Info);
            EditorGUILayout.BeginHorizontal();
            EditorGUI.BeginDisabledGroup(reviewedSyncPlan == null || reviewedAddressRebuild || !reviewedSyncPlan.CanApply);
            if (GUILayout.Button(L("미리 본 계획 적용", "Apply Previewed Plan"), GUILayout.Height(32f), GUILayout.Width(200f)))
                ApplyReviewedPlan();
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.LabelField(L("미리 본 계획: ", "Previewed plan: ") + (reviewedSyncPlan == null || reviewedAddressRebuild ? L("없음", "none") : reviewedPlanTitle), EditorStyles.wordWrappedLabel);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.Space(4f);

            Section(0, L("콘텐츠 등록", "Content registration"), DrawContentSection);
            Section(1, L("주소 규칙", "Address rules"), DrawAddressSection);
            Section(2, L("Category 규칙", "Category rules"), DrawCategorySection);
            Section(3, L("Group 소유", "Group ownership"), DrawOwnershipSection);
            Section(4, L("빌드 역할", "Build roles"), DrawBuildRoleSection);
            Section(5, L("배포 값", "Release values"), DrawReleaseSection);
            Section(6, L("단계별 빌드", "Step-by-step build"), DrawStepBuildSection);
            Section(7, L("산출물 정리", "Output cleanup"), DrawOutputCleanupSection);
            Section(8, L("로컬 호스트 게시 (개발 전용)", "Local host publish (development only)"), DrawLocalHostSection);
            Section(9, L("중단 복구", "Interrupted build recovery"), DrawRecoverySection);
            Section(10, L("기타 설정", "Other settings"), DrawOtherSettingsSection);
        }

        private void Section(int index, string title, Action draw)
        {
            sections[index] = EditorGUILayout.Foldout(sections[index], title, true);
            if (!sections[index]) return;
            EditorGUI.indentLevel++;
            draw();
            EditorGUI.indentLevel--;
            EditorGUILayout.Space(8f);
        }

        private void DrawContentSection()
        {
            DefaultAsset selectedRoot = (DefaultAsset)EditorGUILayout.ObjectField(L("콘텐츠 루트", "Content Root"), config.contentRootFolder, typeof(DefaultAsset), false);
            if (selectedRoot != config.contentRootFolder)
            {
                string path = selectedRoot != null ? AssetDatabase.GetAssetPath(selectedRoot) : string.Empty;
                if (string.IsNullOrEmpty(path) || AssetDatabase.IsValidFolder(path))
                    config.SetContentRoot(path);
            }
            EditorGUILayout.LabelField(L("실제 경로", "Resolved Path"), config.ContentRootPath);

            if (GUILayout.Button(L("루트 자동 찾기", "Auto Detect Root")))
                ShowContentRootMenu();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("등록 미리 보기", "Preview Registration")))
                RunPreview();
            if (GUILayout.Button(L("등록 검사", "Check Registration")))
                RunValidate();
            EditorGUILayout.EndHorizontal();

            EditorGUI.BeginDisabledGroup(buildInProgress || !CanRunEditorWork());
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("빈 Group 미리 보기", "Preview Empty Groups")))
                RunEmptyGroupCleanup(true);
            if (GUILayout.Button(L("빈 Group 삭제", "Delete Empty Groups")))
                RunEmptyGroupCleanup(false);
            EditorGUILayout.EndHorizontal();
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.HelpBox(L("Entry가 없는 그룹만 정리합니다. 기본 그룹, 읽기 전용 그룹, 내장 데이터 그룹과 스키마를 공유하는 그룹은 유지합니다. 폴더 Entry가 있으면 빈 그룹으로 처리하지 않습니다.",
                "Only Groups without Entries are removed. The default Group, read-only Groups, built-in data Groups and Groups sharing a schema stay. A Group with a folder Entry is not empty."), MessageType.None);
        }

        private void DrawAddressSection()
        {
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("updateFolderName"), new GUIContent(L("Update 폴더 이름", "Update Folder Name")));
            EditorGUILayout.HelpBox(L("<Delivery>/<Category>의 일반 파일은 카테고리 기본 Bundle로 묶고, <Delivery>/<Category>/Update/<BundleKey> 하위 파일은 BundleKey별 Bundle로 분리합니다. Update와 BundleKey는 Address 이름 계산에서 제외됩니다.",
                "Files in <Delivery>/<Category> go to the Category's default Bundle; files under <Delivery>/<Category>/Update/<BundleKey> get one Bundle per BundleKey. Update and BundleKey are left out of Addresses."), MessageType.None);
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("pathSeparator"), new GUIContent(L("구분자", "Path Separator")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("ignorePathPrefixes"), new GUIContent(L("제외할 경로 접두어", "Ignored Path Prefixes")), true);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("preserveExistingAddressesOnSync"), new GUIContent(L("등록 때 기존 주소 유지", "Keep Existing On Sync")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("includeExtension"), new GUIContent(L("확장자 포함", "Include Extension")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("ensureUnique"), new GUIContent(L("중복 방지", "Ensure Unique")));
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.HelpBox(L("등록은 기존 Address를 유지하고 새 Entry 또는 빈 Address만 현재 주소 규칙으로 만듭니다. Update/<BundleKey>는 Address에서 제외됩니다. 예: Remote/Character/Update/1.0.1/Char_6.prefab → Char_6",
                "Registration keeps existing Addresses and only names new Entries or empty Addresses by the current rule. Update/<BundleKey> is left out. Example: Remote/Character/Update/1.0.1/Char_6.prefab → Char_6"), MessageType.None);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("주소 재계산 미리 보기", "Preview Address Rebuild")))
                RunAddressRebuildPreview();
            if (GUILayout.Button(L("주소 재계산 적용", "Apply Address Rebuild")))
                RunAddressRebuild();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawCategorySection()
        {
            if (GUILayout.Button(L("새 Category 찾기", "Find New Categories")))
            {
                config.categoryRules = ManagedAddressableCategoryDiscovery.Discover(config.ContentRootPath, config.categoryRules);
                EditorUtility.SetDirty(config);
                serializedConfig.Update();
            }
            EditorGUILayout.HelpBox(L("새 카테고리만 더하고 같은 경로의 기존 Rule은 유지합니다. 기본 Rule은 ReservedFolder + Pack Together입니다. 특수한 카테고리만 Rule을 바꾸세요.",
                "Only new Categories are added; existing Rules for the same path stay. The default Rule is ReservedFolder + Pack Together. Change Rules only for special Categories."), MessageType.None);
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("categoryRules"), new GUIContent(L("Category 규칙", "Category Rules")), true);
        }

        private void DrawOwnershipSection()
        {
            EditorGUILayout.HelpBox(L("기존 Group은 이름이나 폴더 규칙으로 자동 채택하지 않습니다. 업그레이드 전 만든 Group도 여기서 명시 채택해야 등록·정책 수정 대상이 됩니다. 채택·해제·없는 참조 정리는 미리 본 뒤 미리 본 계획 적용으로 적용합니다.",
                "Existing Groups are never adopted by name or folder rule. Groups made before an upgrade must be adopted here to be registered or edited. Preview adoption, release or missing reference cleanup, then use Apply Previewed Plan."), MessageType.Info);
            ownershipCandidate = (AddressableAssetGroup)EditorGUILayout.ObjectField(L("채택할 Group", "Group to adopt"), ownershipCandidate, typeof(AddressableAssetGroup), false);
            EditorGUI.BeginDisabledGroup(ownershipCandidate == null || buildInProgress);
            if (GUILayout.Button(L("Group 채택 미리 보기", "Preview Group Adoption")))
                RunCustomPreview(L("Group 채택", "Group adoption"), () => ManagedAddressableSynchronizer.CreateOwnershipPlan(config, new[] { ownershipCandidate }));
            EditorGUI.EndDisabledGroup();
            foreach (string guid in (config.ownedGroupGuids ?? new List<string>()).ToArray())
            {
                string path = AssetDatabase.GUIDToAssetPath(guid ?? string.Empty);
                AddressableAssetGroup group = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<AddressableAssetGroup>(path);
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField(new GUIContent(group != null ? group.Name : L("없는 Group (참조 유지)", "Missing Group (reference kept)"), guid ?? "<null>"));
                if (GUILayout.Button(L("채택 해제 미리 보기", "Preview Adoption Release"), GUILayout.Width(170f)))
                    RunCustomPreview(L("채택 해제", "Adoption release"), () => ManagedAddressableSynchronizer.CreateOwnershipPlan(config, releaseGroupGuids: new[] { guid }));
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button(L("없는 Group 참조 정리 미리 보기", "Preview Missing Group Cleanup")))
                RunCustomPreview(L("없는 Group 참조 정리", "Missing Group cleanup"), () => ManagedAddressableSynchronizer.CreateOwnershipPlan(config, removeMissing: true));
        }

        private void DrawOtherSettingsSection()
        {
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("buildOutputRoot"), new GUIContent(L("빌드 산출물 폴더", "Build Output Root")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("profileName"), new GUIContent(L("Profile 이름", "Profile Name")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("autoRegister"), new GUIContent(L("자동 등록", "Auto Register")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("createGroupIfMissing"), new GUIContent(L("없는 Group 만들기", "Create Group If Missing")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("backupBeforeApply"), new GUIContent(L("적용 전 백업", "Backup Before Apply")));
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("backupRoot"), new GUIContent(L("백업 폴더", "Backup Root")));
        }

        private void RunCustomPreview(string title, Func<ManagedAddressableSyncPlan> create)
        {
            try
            {
                serializedConfig.ApplyModifiedProperties();
                reviewedSyncPlan = create();
                reviewedPlanTitle = title;
                reviewedAddressRebuild = false;
                resultText = reviewedSyncPlan.Report.ToString();
            }
            catch (Exception error) { reviewedSyncPlan = null; resultText = error.ToString(); }
        }

        private void ApplyReviewedPlan()
        {
            try
            {
                serializedConfig.ApplyModifiedProperties();
                if (reviewedSyncPlan == null || reviewedAddressRebuild) throw new InvalidOperationException(L("먼저 미리 보기를 실행하세요.", "Run a preview first."));
                ManagedAddressableSyncReport report = ManagedAddressableSynchronizer.ApplyPlan(config, reviewedSyncPlan);
                reviewedSyncPlan = null;
                serializedConfig.Update();
                List<string> errors = ManagedAddressableValidator.Validate(config);
                resultText = report + (errors.Count == 0 ? "\n" + L("등록 검사: 통과", "Registration check: PASS") : "\n" + L("등록 검사:\n", "Registration check:\n") + string.Join("\n", errors));
                appBuildStatusTime = 0;
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
        }

        private void RunPreview() => RunCustomPreview(L("등록", "Registration"), () => ManagedAddressableSynchronizer.CreatePlan(config));

        private void RunEmptyGroupCleanup(bool preview)
        {
            try
            {
                if (buildInProgress || !CanRunEditorWork()) return;

                serializedConfig?.ApplyModifiedProperties();
                ManagedAddressableSyncReport report = ManagedAddressableSynchronizer.CleanupEmptyGroups(config, true);
                resultText = L("빈 Group 미리 보기: ", "Empty Group preview: ") + report.removedGroups + "\n" + string.Join("\n", report.messages);
                showResult = true;
                if (preview || report.removedGroups == 0) return;

                if (!EditorUtility.DisplayDialog(L("빈 Group 삭제", "Delete Empty Groups"), resultText + "\n\n" + L("위 빈 그룹을 삭제합니다. 계속할까요?", "Delete the empty Groups above?"), L("삭제", "Delete"), L("취소", "Cancel")))
                    return;

                report = ManagedAddressableSynchronizer.CleanupEmptyGroups(config, false);
                resultText = L("삭제한 빈 Group: ", "Deleted empty Groups: ") + report.removedGroups + "\n" + string.Join("\n", report.messages);
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
            finally
            {
                Repaint();
            }
        }

        private void RunAddressRebuildPreview()
        {
            try
            {
                serializedConfig.ApplyModifiedProperties();
                reviewedSyncPlan = ManagedAddressableSynchronizer.CreatePlan(config, true);
                reviewedPlanTitle = L("주소 재계산", "Address rebuild");
                reviewedAddressRebuild = true;
                resultText = reviewedSyncPlan.Report.ToString();
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
        }

        private void RunAddressRebuild()
        {
            if (!EditorUtility.DisplayDialog(L("주소 재계산", "Address Rebuild"), L("관리 대상의 기존 Address를 모두 다시 계산합니다. Address를 참조하는 코드와 프리팹에 영향이 있을 수 있습니다. 계속할까요?",
                    "Every managed Address is recalculated. Code and Prefabs that reference Addresses may be affected. Continue?"), L("재계산", "Rebuild"), L("취소", "Cancel")))
                return;

            try
            {
                serializedConfig.ApplyModifiedProperties();
                if (reviewedSyncPlan == null || !reviewedAddressRebuild) throw new InvalidOperationException(L("주소 재계산 미리 보기를 먼저 실행하세요.", "Run Preview Address Rebuild first."));
                resultText = ManagedAddressableSynchronizer.ApplyPlan(config, reviewedSyncPlan).ToString();
                reviewedSyncPlan = null;
            }
            catch (Exception ex)
            {
                resultText = ex.ToString();
            }
        }

        private void RunValidate()
        {
            List<string> errors = ManagedAddressableValidator.Validate(config);
            resultText = errors.Count == 0 ? L("등록 검사: 통과", "Registration check: PASS") : string.Join("\n", errors);
        }

        private void LoadConfig()
        {
            reviewedSyncPlan = null;
            config = AssetDatabase.LoadAssetAtPath<ManagedAddressableProjectConfig>(ManagedAddressableProjectConfig.DefaultAssetPath);
            serializedConfig = config != null ? new SerializedObject(config) : null;
            roleDraftConfig = null;
            packagedDraftConfig = null;
            appBuildStatusTime = 0;
        }

        private void CreateConfigAndInitialize()
        {
            List<ManagedFolderCandidate> candidates = ManagedContentRootDiscovery.FindCandidates();
            if (candidates.Count <= 1)
            {
                string rootPath = candidates.Count == 1 ? candidates[0].path : "Assets/Addressables";
                config = CreateConfig(rootPath);
                serializedConfig = new SerializedObject(config);
                EnsureContentFolders(config.ContentRootPath);
                RunPreview();
                return;
            }

            GenericMenu menu = new GenericMenu();
            foreach (ManagedFolderCandidate candidate in candidates)
            {
                string path = candidate.path;
                menu.AddItem(new GUIContent(path + "  (" + candidate.reason + ")"), false, () =>
                {
                    config = CreateConfig(path);
                    serializedConfig = new SerializedObject(config);
                    EnsureContentFolders(config.ContentRootPath);
                    RunPreview();
                    Repaint();
                });
            }
            menu.ShowAsContext();
        }

        private ManagedAddressableProjectConfig CreateConfig(string rootPath)
        {
            string directory = Path.GetDirectoryName(ManagedAddressableProjectConfig.DefaultAssetPath).Replace('\\', '/');
            EnsureAssetFolder(directory);

            ManagedAddressableProjectConfig created = CreateInstance<ManagedAddressableProjectConfig>();
            created.SetContentRoot(rootPath);
            created.categoryRules = ManagedAddressableCategoryDiscovery.Discover(created.ContentRootPath);
            AssetDatabase.CreateAsset(created, ManagedAddressableProjectConfig.DefaultAssetPath);
            AssetDatabase.SaveAssetIfDirty(created);
            return created;
        }

        private void ShowContentRootMenu()
        {
            List<ManagedFolderCandidate> candidates = ManagedContentRootDiscovery.FindCandidates();
            if (candidates.Count == 0)
            {
                config.SetContentRoot("Assets/Addressables");
                EditorUtility.SetDirty(config);
                serializedConfig.Update();
                return;
            }

            GenericMenu menu = new GenericMenu();
            foreach (ManagedFolderCandidate candidate in candidates)
            {
                string path = candidate.path;
                menu.AddItem(new GUIContent(path + "  (" + candidate.reason + ")"), string.Equals(config.ContentRootPath, path, StringComparison.OrdinalIgnoreCase), () =>
                {
                    config.SetContentRoot(path);
                    EditorUtility.SetDirty(config);
                    serializedConfig.Update();
                    Repaint();
                });
            }
            menu.ShowAsContext();
        }

        private static void EnsureContentFolders(string contentRoot)
        {
            if (string.IsNullOrWhiteSpace(contentRoot))
                return;

            Directory.CreateDirectory(contentRoot);
            Directory.CreateDirectory(Path.Combine(contentRoot, "Local"));
            Directory.CreateDirectory(Path.Combine(contentRoot, "Remote"));
            AssetDatabase.Refresh();
        }

        private static void EnsureAssetFolder(string path)
        {
            string[] parts = path.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }
}
