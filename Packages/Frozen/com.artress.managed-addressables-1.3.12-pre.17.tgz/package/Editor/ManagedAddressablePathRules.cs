using System;
using System.Collections.Generic;
using System.Linq;

namespace Artress.ManagedAddressables.Editor
{
    internal readonly struct ManagedAddressablePathResolution
    {
        public readonly string groupName;
        public readonly string addressPathAfterCategory;
        public readonly bool isUpdateContent;
        public readonly string bundleKey;
        public readonly string error;

        public bool IsValid => string.IsNullOrEmpty(error);

        public ManagedAddressablePathResolution(string groupName, string addressPathAfterCategory, bool isUpdateContent, string bundleKey, string error)
        {
            this.groupName = groupName ?? string.Empty;
            this.addressPathAfterCategory = addressPathAfterCategory ?? string.Empty;
            this.isUpdateContent = isUpdateContent;
            this.bundleKey = bundleKey ?? string.Empty;
            this.error = error ?? string.Empty;
        }
    }

    internal static class ManagedAddressablePathRules
    {
        public static ManagedAddressablePathResolution Resolve(string relativePath, ManagedCategoryRule rule, string updateFolderName)
        {
            string normalized = Normalize(relativePath);
            string[] parts = Split(normalized);
            if (parts.Length < 3)
                return new ManagedAddressablePathResolution(string.Empty, string.Empty, false, string.Empty, "Delivery/Category/File 구조가 필요합니다: " + relativePath);

            string deliveryFolder = parts[0];
            string category = parts[1];
            ManagedDeliveryMode delivery = ResolveDelivery(deliveryFolder, rule?.delivery ?? ManagedDeliveryMode.Remote);
            string baseGroupName = ResolveBaseGroupName(rule, delivery, category);
            string[] afterCategory = parts.Skip(2).ToArray();

            if (rule == null || rule.groupStrategy != ManagedGroupStrategy.ReservedFolder)
            {
                string[] ruleParts = Split(rule?.relativePath);
                string[] afterRule = parts.Skip(Math.Min(ruleParts.Length, parts.Length)).ToArray();
                string groupName = ResolveGroupName(rule, delivery, category, afterRule);
                return new ManagedAddressablePathResolution(groupName, string.Join("/", afterCategory), false, string.Empty, string.Empty);
            }

            string reserved = string.IsNullOrWhiteSpace(updateFolderName) ? "Update" : updateFolderName.Trim();
            if (!afterCategory[0].Equals(reserved, StringComparison.OrdinalIgnoreCase))
                return new ManagedAddressablePathResolution(baseGroupName, string.Join("/", afterCategory), false, string.Empty, string.Empty);

            if (afterCategory.Length < 3)
                return new ManagedAddressablePathResolution(baseGroupName, string.Empty, true, string.Empty, reserved + " 바로 아래에는 BundleKey 폴더가 필요합니다: " + relativePath);

            string bundleKey = SanitizeGroupSegment(afterCategory[1]);
            if (string.IsNullOrEmpty(bundleKey))
                return new ManagedAddressablePathResolution(baseGroupName, string.Empty, true, string.Empty, "BundleKey가 비어 있습니다: " + relativePath);

            string addressPath = string.Join("/", afterCategory.Skip(2));
            return new ManagedAddressablePathResolution(baseGroupName + "_" + bundleKey, addressPath, true, bundleKey, string.Empty);
        }

        public static string ResolveBaseGroupName(ManagedCategoryRule rule, ManagedDeliveryMode delivery, string category)
        {
            string fallback = delivery == ManagedDeliveryMode.Local ? category : "Remote_" + category;
            return string.IsNullOrWhiteSpace(rule?.groupNamePattern) ? fallback : rule.groupNamePattern.Trim();
        }

        public static ManagedDeliveryMode ResolveDelivery(string deliveryFolder, ManagedDeliveryMode fallback)
        {
            if (deliveryFolder.Equals("Local", StringComparison.OrdinalIgnoreCase)) return ManagedDeliveryMode.Local;
            if (deliveryFolder.Equals("Remote", StringComparison.OrdinalIgnoreCase)) return ManagedDeliveryMode.Remote;
            return fallback;
        }

        private static string ResolveGroupName(ManagedCategoryRule rule, ManagedDeliveryMode delivery, string category, string[] afterCategory)
        {
            string pattern = ResolveBaseGroupName(rule, delivery, category);
            if (rule == null || rule.groupStrategy == ManagedGroupStrategy.PreserveExistingGroup || rule.groupStrategy == ManagedGroupStrategy.SingleGroup || rule.groupStrategy == ManagedGroupStrategy.ReservedFolder)
                return pattern;

            string[] folderParts = afterCategory.Length > 1 ? afterCategory.Take(afterCategory.Length - 1).ToArray() : Array.Empty<string>();
            int depth = rule.groupStrategy == ManagedGroupStrategy.FirstSubfolder ? 1 : Math.Max(1, rule.folderDepth);
            string firstFolder = folderParts.Length > 0 ? folderParts[0] : "Root";
            string folder = folderParts.Length > 0 ? string.Join("_", folderParts.Take(depth)) : "Root";
            bool hasToken = pattern.Contains("{folder0}") || pattern.Contains("{folder}");
            string resolved = pattern.Replace("{folder0}", firstFolder).Replace("{folder}", folder);
            return hasToken ? resolved : resolved + "_" + folder;
        }

        private static string SanitizeGroupSegment(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            char[] invalid = { '/', '\\', ':', '*', '?', '"', '<', '>', '|', ' ', '\t', '\r', '\n' };
            string sanitized = value.Trim();
            foreach (char character in invalid)
                sanitized = sanitized.Replace(character, '_');
            while (sanitized.Contains("__"))
                sanitized = sanitized.Replace("__", "_");
            return sanitized.Trim('_');
        }

        private static string[] Split(string value)
        {
            return value.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
        }

        private static string Normalize(string value)
        {
            return (value ?? string.Empty).Replace('\\', '/').Trim('/');
        }
    }
}
