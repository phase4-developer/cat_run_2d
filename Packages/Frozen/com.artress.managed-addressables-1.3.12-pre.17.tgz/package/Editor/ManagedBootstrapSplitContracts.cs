using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Artress.ManagedAddressables.Editor
{
    public enum ManagedGroupBuildRole { Unassigned = 0, Boot = 1, Revision = 2 }

    // Values are supplied by the same release authority as remote Revisions. The
    // Editor does not allocate sequence numbers or infer them from IDs/app versions.
    [Serializable]
    public sealed class ManagedRevisionReleaseMetadata
    {
        public string productId, channel, authorityId, compatibilityFamily;
        public long deploymentSequence;
        internal ManagedRevisionReleaseMetadata Copy() => (ManagedRevisionReleaseMetadata)MemberwiseClone();
    }

    [Serializable]
    public sealed class ManagedGroupBuildRoleSetting
    {
        public string groupAssetGuid;
        public ManagedGroupBuildRole role;
        public bool useForSharedBundles;
        internal ManagedGroupBuildRoleSetting Copy() => new ManagedGroupBuildRoleSetting
        { groupAssetGuid = groupAssetGuid, role = role, useForSharedBundles = useForSharedBundles };
    }

    internal sealed class ManagedBuildRoleChange
    {
        private readonly ManagedGroupBuildRoleSetting[] roles;
        internal readonly ReadOnlyCollection<string> keys;
        internal ManagedBuildRoleChange(IEnumerable<ManagedGroupBuildRoleSetting> roles, IEnumerable<string> keys)
        {
            this.roles = roles.Select(r => r.Copy()).ToArray();
            this.keys = keys.ToList().AsReadOnly();
        }
        internal List<ManagedGroupBuildRoleSetting> CopyRoles() => roles.Select(r => r.Copy()).ToList();
    }

    internal sealed class ManagedSplitBuildReport
    {
        internal readonly List<string> errors = new List<string>();
        internal readonly List<string> warnings = new List<string>();
        public bool CanBuild => errors.Count == 0;
        public IReadOnlyList<string> Errors => errors.AsReadOnly();
        public IReadOnlyList<string> Warnings => warnings.AsReadOnly();
        public override string ToString() => string.Join("\n", errors.Select(s => "[Blocked] " + s).Concat(warnings.Select(s => "[Warning] " + s)));
    }

    internal sealed class ManagedSplitBuildPlan
    {
        internal string fingerprint;
        internal string contentFingerprint;
        internal string effectiveFingerprint;
        internal string stamp;
        internal ManagedGroupBuildRole purpose;
        internal string outputDirectory;
        internal readonly List<string> changes = new List<string>();
        internal ManagedSplitBuildReport report;
        public bool CanBuild => report.CanBuild;
        public IReadOnlyList<string> Changes => changes.AsReadOnly();
        public ManagedSplitBuildReport Report => report;
        public override string ToString() => string.Join("\n", changes) + "\n" + report;
    }

    [Serializable]
    internal sealed class ManagedSplitFileStamp
    {
        public string path;
        public string sha256;
    }

    [Serializable]
    internal sealed class ManagedSplitBundleReceipt
    {
        public string groupAssetGuid;
        public string bundleName;
        public string internalId;
        public string hash;
        public uint crc;
        public string sourceHash;
        public uint sourceCrc;
        public string filePath;
        public string sha256;
    }

    [Serializable]
    internal sealed class ManagedSplitBuildReceipt
    {
        public int schemaVersion = 1;
        public string mode = "BootstrapSplit";
        public string purpose;
        public string stamp;
        public string platform;
        public string appVersion;
        public string unityVersion;
        public string addressablesVersion;
        public string configAssetGuid;
        public string settingsAssetGuid;
        public string inputFingerprint;
        public string contentFingerprint;
        public string effectiveInput;
        public string outputDirectory;
        public string runtimeDirectory;
        public string catalogPath;
        public string catalogSha256;
        public string catalogFormat;
        public string publisherPath;
        public string publisherSha256;
        public string layoutPath;
        public string layoutSha256;
        public bool rawSettingsRestored;
        public bool effectiveSettingsRestored;
        public bool complete;
        public string error;
        public string effectiveBefore;
        public string effectiveAfter;
        public List<string> keys = new List<string>();
        public List<string> commonLabels = new List<string>();
        public List<string> exclusiveRoleKeys = new List<string>();
        public List<string> implicitDuplicates = new List<string>();
        public List<ManagedSplitBundleReceipt> bundles = new List<ManagedSplitBundleReceipt>();
        public List<ManagedSplitFileStamp> runtimeFiles = new List<ManagedSplitFileStamp>();
    }
}
