using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    public enum ManagedDeliveryMode
    {
        Local,
        Remote
    }

    public enum ManagedGroupStrategy
    {
        SingleGroup = 0,
        FirstSubfolder = 1,
        FolderDepth = 2,
        PreserveExistingGroup = 3,
        ReservedFolder = 4
    }

    [Serializable]
    public sealed class ManagedCategoryRule
    {
        public string relativePath;
        public ManagedDeliveryMode delivery;
        public ManagedGroupStrategy groupStrategy = ManagedGroupStrategy.ReservedFolder;
        public int folderDepth = 1;
        public string groupNamePattern;
        public BundledAssetGroupSchema.BundlePackingMode bundleMode = BundledAssetGroupSchema.BundlePackingMode.PackTogether;
        public bool enabled = true;
    }

    public sealed class ManagedAddressableProjectConfig : ScriptableObject
    {
        public const string DefaultAssetPath = "Assets/ArtressManagedAddressables/ManagedAddressableProjectConfig.asset";

        [Header("Project")]
        public DefaultAsset contentRootFolder;
        [SerializeField] private string contentRoot = "Assets/Addressables";
        public string buildOutputRoot = "ServerData";
        public string profileName = "Artress Managed";

        [Header("Folder Bundle Rule")]
        public string updateFolderName = "Update";

        [Header("Address Naming")]
        public bool autoRegister = true;
        public bool createGroupIfMissing = true;
        public bool preserveExistingAddressesOnSync = true;
        public bool includeExtension;
        public bool ensureUnique;
        public string pathSeparator = "_";
        public List<string> ignorePathPrefixes = new List<string> { "Texture" };

        [Header("Category Policies")]
        public List<ManagedCategoryRule> categoryRules = new List<ManagedCategoryRule>();

        [Header("Explicit Content Build Roles")]
        public List<ManagedGroupBuildRoleSetting> groupBuildRoles = new List<ManagedGroupBuildRoleSetting>();
        public List<string> requiredBootKeys = new List<string>();

        [Header("Explicit Revision Release (shared)")]
        [Tooltip("팀이 공유하는 Release 값입니다. channel, 순번, 앱 포함 A 연결은 PC마다 UserSettings/ArtressManagedAddressables에 따로 저장합니다.")]
        public ManagedRevisionSharedRelease revisionShared = new ManagedRevisionSharedRelease();
        [Tooltip("Revision URL에 평문 http를 허용합니다. Development Build 전용이며 켠 채로 Release Player를 빌드하면 실패합니다.")]
        public bool allowDevelopmentHttp;

        [Header("Explicit Group Ownership")]
        [Tooltip("명시적으로 채택한 Group asset GUID입니다. 기존 Group은 자동 채택하지 않으며, 삭제된 GUID는 경고와 명시 정리 전까지 보존합니다.")]
        public List<string> ownedGroupGuids = new List<string>();

        internal bool OwnsGroup(AddressableAssetGroup group)
        {
            if (group == null) return false;
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(group));
            return !string.IsNullOrEmpty(guid) && ownedGroupGuids != null && ownedGroupGuids.Exists(value => string.Equals(value, guid, StringComparison.OrdinalIgnoreCase));
        }

        [Header("Advanced")]
        public bool backupBeforeApply = true;
        public string backupRoot = "Library/ArtressManagedAddressablesBackup";

        public string ContentRootPath
        {
            get
            {
                string folderPath = contentRootFolder != null ? AssetDatabase.GetAssetPath(contentRootFolder) : string.Empty;
                if (!string.IsNullOrWhiteSpace(folderPath) && AssetDatabase.IsValidFolder(folderPath))
                    return Normalize(folderPath);
                return Normalize(contentRoot);
            }
        }

        public void SetContentRoot(string assetPath)
        {
            contentRoot = Normalize(assetPath);
            contentRootFolder = AssetDatabase.LoadAssetAtPath<DefaultAsset>(contentRoot);
            EditorUtility.SetDirty(this);
        }

        private void OnEnable()
        {
            ignorePathPrefixes ??= new List<string>();
            categoryRules ??= new List<ManagedCategoryRule>();
            ownedGroupGuids ??= new List<string>();
            groupBuildRoles ??= new List<ManagedGroupBuildRoleSetting>();
            requiredBootKeys ??= new List<string>();
            revisionShared ??= new ManagedRevisionSharedRelease();

            if (contentRootFolder == null && !string.IsNullOrWhiteSpace(contentRoot) && AssetDatabase.IsValidFolder(contentRoot))
                contentRootFolder = AssetDatabase.LoadAssetAtPath<DefaultAsset>(contentRoot);
        }

        private static string Normalize(string value)
        {
            return (value ?? string.Empty).Replace('\\', '/').Trim('/');
        }
    }
}
