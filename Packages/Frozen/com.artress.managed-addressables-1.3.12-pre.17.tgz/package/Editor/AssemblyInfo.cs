using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Artress.ManagedAddressables.Editor.Tests")]
