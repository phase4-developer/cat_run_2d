﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using UnityEngine;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedLocalHostFile
    {
        internal string source, destination, sha256;
        internal long bytes;
    }

    internal sealed class ManagedLocalHostPublishPlan
    {
        internal string receiptPath, receiptSha, hostRoot, revisionDirectory, pointerPath, pointerUrl, pointerJson, previousPointer;
        internal bool alreadyPublished;
        internal readonly List<ManagedLocalHostFile> files = new List<ManagedLocalHostFile>();
        internal readonly List<string> changes = new List<string>();
        internal readonly List<string> warnings = new List<string>();
        internal readonly List<string> errors = new List<string>();
        internal bool CanApply => errors.Count == 0;
        public override string ToString() => string.Join("\n", changes.Concat(warnings.Select(w => "[Warning] " + w)).Concat(errors.Select(e => "[Blocked] " + e)));
    }

    // Development stand-in for the game server: copies one built Revision into a folder a
    // local static server serves, and writes the pointer the app reads to find it.
    // The pointer's SHA comes from the same host, so this never counts as production trust.
    internal static partial class ManagedAddressableBuildExporter
    {
        private const string RevisionSegment = "/split/revision/";

        public static ManagedLocalHostPublishPlan CreateLocalHostPublishPlan(ManagedAddressableProjectConfig config, string receiptPath, string hostRoot)
        {
            var plan = new ManagedLocalHostPublishPlan();
            try
            {
                if (config == null) throw new InvalidOperationException("Select a Project Config.");
                if (string.IsNullOrWhiteSpace(receiptPath) || !File.Exists(receiptPath)) throw new InvalidOperationException("Select a completed Revision split_build_receipt.json.");
                plan.hostRoot = RequireHostRoot(config, hostRoot);
                plan.receiptPath = Path.GetFullPath(receiptPath); plan.receiptSha = SplitFileHash(plan.receiptPath);
                var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(plan.receiptPath));
                if (receipt == null || !receipt.complete || receipt.purpose != "Revision" || receipt.catalogFormat != "json" ||
                    string.IsNullOrEmpty(receipt.publisherPath) || !File.Exists(receipt.publisherPath) || SplitFileHash(receipt.publisherPath) != receipt.publisherSha256 ||
                    !File.Exists(receipt.catalogPath) || SplitFileHash(receipt.catalogPath) != receipt.catalogSha256 || receipt.bundles == null || receipt.bundles.Count == 0)
                    throw new InvalidOperationException("Only a complete Revision build whose catalog and publisher still match its receipt can be published.");
                var publisher = JsonUtility.FromJson<ManagedRevisionPublisher>(File.ReadAllText(receipt.publisherPath));
                ApplyReleaseMetadata(new ManagedRevisionPublisher(), new ManagedRevisionReleaseMetadata { productId = publisher.productId, channel = publisher.channel,
                    authorityId = publisher.authorityId, compatibilityFamily = publisher.compatibilityFamily, deploymentSequence = publisher.deploymentSequence });
                // Both name a path segment of the pointer, so neither may carry '/' or a dot segment.
                foreach (var (label, value) in new[] { ("Channel", publisher.channel), ("Target", publisher.target) })
                    if (string.IsNullOrEmpty(value) || !Regex.IsMatch(value, "^[A-Za-z0-9._-]+$") || value.Trim('.').Length == 0)
                        throw new InvalidOperationException(label + " must use letters, digits, '.', '_' or '-' to name its pointer path: " + value);

                // The catalog already holds the bundle URLs, so the host layout must follow them.
                var roots = receipt.bundles.Select(bundle => bundle.internalId.Substring(0, Math.Max(0, bundle.internalId.LastIndexOf('/')))).Distinct(StringComparer.Ordinal).ToList();
                if (roots.Count != 1 || !Uri.TryCreate(roots[0], UriKind.Absolute, out var revisionUri) || (revisionUri.Scheme != Uri.UriSchemeHttp && revisionUri.Scheme != Uri.UriSchemeHttps) ||
                    !revisionUri.AbsolutePath.EndsWith(RevisionSegment + receipt.stamp, StringComparison.Ordinal))
                    throw new InvalidOperationException("The Revision bundles do not share one pinned " + RevisionSegment + receipt.stamp + " URL root.");
                foreach (var bundle in receipt.bundles)
                    if (Uri.UnescapeDataString(bundle.internalId.Substring(bundle.internalId.LastIndexOf('/') + 1)) != Path.GetFileName(bundle.filePath))
                        throw new InvalidOperationException("The catalog URL file name differs from the built bundle file: " + bundle.internalId);
                if (!revisionUri.IsLoopback) plan.warnings.Add("The Revision URL host is " + revisionUri.Host + ", not this PC. This folder must be what that host serves.");
                string revisionUrl = roots[0];
                string baseUrl = revisionUrl.Substring(0, revisionUrl.Length - (RevisionSegment + receipt.stamp).Length);
                plan.revisionDirectory = HostPath(plan.hostRoot, revisionUri.AbsolutePath);
                plan.pointerUrl = baseUrl + "/split/latest/" + publisher.target + "/" + publisher.channel + ".json";
                plan.pointerPath = HostPath(plan.hostRoot, new Uri(plan.pointerUrl).AbsolutePath);

                plan.files.Add(new ManagedLocalHostFile { source = receipt.catalogPath, sha256 = receipt.catalogSha256 });
                plan.files.Add(new ManagedLocalHostFile { source = receipt.publisherPath, sha256 = receipt.publisherSha256 });
                foreach (var bundle in receipt.bundles) plan.files.Add(new ManagedLocalHostFile { source = bundle.filePath, sha256 = bundle.sha256 });
                foreach (var file in plan.files)
                {
                    if (!File.Exists(file.source) || SplitFileHash(file.source) != file.sha256) throw new InvalidOperationException("Built file changed or is missing: " + file.source);
                    file.bytes = new FileInfo(file.source).Length;
                    file.destination = Path.Combine(plan.revisionDirectory, Path.GetFileName(file.source));
                }
                if (plan.files.Select(file => file.destination).Distinct(StringComparer.OrdinalIgnoreCase).Count() != plan.files.Count)
                    throw new InvalidOperationException("Two Revision files share one file name.");

                if (Directory.Exists(plan.revisionDirectory))
                {
                    var existing = Directory.GetFiles(plan.revisionDirectory).Select(Path.GetFullPath).OrderBy(p => p, StringComparer.OrdinalIgnoreCase).ToList();
                    plan.alreadyPublished = existing.SequenceEqual(plan.files.Select(f => Path.GetFullPath(f.destination)).OrderBy(p => p, StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase) &&
                        plan.files.All(f => SplitFileHash(f.destination) == f.sha256);
                    if (!plan.alreadyPublished) throw new InvalidOperationException("A different Revision is already in " + plan.revisionDirectory + ". Published Revisions are never overwritten.");
                }

                string catalogUrl = revisionUrl + "/" + Uri.EscapeDataString(Path.GetFileName(receipt.catalogPath));
                string publisherUrl = revisionUrl + "/" + Uri.EscapeDataString(Path.GetFileName(receipt.publisherPath));
                plan.pointerJson = JsonUtility.ToJson(new ManagedRevisionLocalHostPointer
                {
                    revisionId = publisher.revisionId, target = publisher.target, productId = publisher.productId, channel = publisher.channel,
                    authorityId = publisher.authorityId, compatibilityFamily = publisher.compatibilityFamily, deploymentSequence = publisher.deploymentSequence,
                    catalogUrl = catalogUrl, publisherUrl = publisherUrl, publisherSha256 = receipt.publisherSha256
                }, true);
                plan.previousPointer = File.Exists(plan.pointerPath) ? File.ReadAllText(plan.pointerPath) : null;
                if (plan.previousPointer != null)
                {
                    try
                    {
                        var previous = ManagedRevisionLocalHostPointer.Parse(plan.previousPointer);
                        if (previous.compatibilityFamily == publisher.compatibilityFamily && previous.deploymentSequence >= publisher.deploymentSequence && previous.revisionId != publisher.revisionId)
                            plan.warnings.Add("The current pointer has sequence " + previous.deploymentSequence + ". Apps that already took it ignore this lower or equal sequence " + publisher.deploymentSequence + ".");
                    }
                    catch (Exception error) { plan.warnings.Add("The current pointer is unreadable and will be replaced: " + error.Message); }
                }

                plan.changes.Add("[Development only] The pointer SHA comes from the same host as the files. This is not a production trust anchor.");
                plan.changes.Add(plan.alreadyPublished ? "[Revision] Already published, unchanged: " + plan.revisionDirectory
                    : "[Revision] Create " + plan.revisionDirectory + " (" + plan.files.Count + " files, " + plan.files.Sum(f => f.bytes) + " bytes)");
                plan.changes.Add("[Pointer] " + (plan.previousPointer == null ? "Create " : "Replace ") + plan.pointerPath + " -> " + publisher.revisionId + " / sequence " + publisher.deploymentSequence);
                plan.changes.Add("[App reads] " + plan.pointerUrl);
            }
            catch (Exception error) { plan.errors.Add(error.Message); }
            return plan;
        }

        public static string ApplyLocalHostPublishPlan(ManagedAddressableProjectConfig config, ManagedLocalHostPublishPlan plan)
        {
            if (plan == null || !plan.CanApply) throw new InvalidOperationException("Preview a publish plan without blocked items first.");
            var fresh = CreateLocalHostPublishPlan(config, plan.receiptPath, plan.hostRoot);
            if (!fresh.CanApply || fresh.receiptSha != plan.receiptSha || fresh.pointerJson != plan.pointerJson || fresh.previousPointer != plan.previousPointer || fresh.alreadyPublished != plan.alreadyPublished)
                throw new InvalidOperationException("The Revision or host folder changed after Preview. Preview again; nothing was copied.\n" + string.Join("\n", fresh.errors));
            if (!plan.alreadyPublished)
            {
                string staging = plan.revisionDirectory + ".publishing";
                if (Directory.Exists(staging)) Directory.Delete(staging, true);
                Directory.CreateDirectory(staging);
                foreach (var file in plan.files)
                {
                    string copy = Path.Combine(staging, Path.GetFileName(file.destination));
                    File.Copy(file.source, copy, false);
                    if (new FileInfo(copy).Length != file.bytes || SplitFileHash(copy) != file.sha256) throw new IOException("Copied file differs from the build: " + copy);
                }
                Directory.CreateDirectory(Path.GetDirectoryName(plan.revisionDirectory));
                Directory.Move(staging, plan.revisionDirectory);
            }
            // Files first, then the pointer, so an app never reads a pointer to missing files.
            Directory.CreateDirectory(Path.GetDirectoryName(plan.pointerPath));
            string temporary = plan.pointerPath + ".tmp";
            File.WriteAllText(temporary, plan.pointerJson, new UTF8Encoding(false));
            ManagedFileReplace.ReplaceOrMove(temporary, plan.pointerPath);
            return plan.pointerUrl;
        }

        private static string RequireHostRoot(ManagedAddressableProjectConfig config, string hostRoot)
        {
            if (string.IsNullOrWhiteSpace(hostRoot) || !Path.IsPathRooted(hostRoot)) throw new InvalidOperationException("Set an absolute local host folder (the folder your static server serves).");
            string root = Path.GetFullPath(hostRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string project = Path.GetFullPath(".").TrimEnd(Path.DirectorySeparatorChar);
            bool Overlaps(string a, string b) => a.Equals(b, StringComparison.OrdinalIgnoreCase) ||
                a.StartsWith(b + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || b.StartsWith(a + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
            if (root.Equals(project, StringComparison.OrdinalIgnoreCase) || project.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("The local host folder cannot be the project folder or contain it: " + root);
            foreach (string reserved in new[] { "Assets", "Packages", "ProjectSettings", "Library", "UserSettings" })
            {
                string path = Path.Combine(project, reserved);
                if (root.Equals(path, StringComparison.OrdinalIgnoreCase) || root.StartsWith(path + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("The local host folder cannot be inside " + reserved + ": " + root);
            }
            // Build Output Cleanup owns everything under the output root and would read a published
            // Revision there as an unfinished build and delete it, leaving the pointer dangling.
            string output = SplitOutputBase(config).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            if (Overlaps(root, output))
                throw new InvalidOperationException("The local host folder cannot be inside the build output root or contain it (" + output + "): " + root);
            if (!Directory.Exists(root)) throw new InvalidOperationException("The local host folder does not exist: " + root);
            if (IsLink(root)) throw new InvalidOperationException("The local host folder cannot be a linked folder: " + root);
            return root;
        }

        private static string HostPath(string hostRoot, string urlPath)
        {
            var parts = Uri.UnescapeDataString(urlPath).Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Any(part => part == "." || part == ".." || part.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0))
                throw new InvalidOperationException("URL path cannot map into the host folder: " + urlPath);
            return Path.GetFullPath(Path.Combine(new[] { hostRoot }.Concat(parts).ToArray()));
        }

        internal static void SetLocalHostRoot(ManagedAddressableProjectConfig config, string hostRoot)
        {
            var local = ManagedLocalRelease.Read(config);
            local.localHostRoot = string.IsNullOrWhiteSpace(hostRoot) ? null : hostRoot.Trim();
            ManagedLocalRelease.Write(config, local);
        }
    }
}
