using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using static Artress.ManagedAddressables.Editor.ManagedEditorText;

namespace Artress.ManagedAddressables.Editor
{
    public sealed partial class ManagedAddressablesWindow
    {
        private double appBuildStatusTime;
        private List<string> appBuildProblems = new List<string>();
        private string appBuildSequenceText = string.Empty;
        private string appBuildOutput;
        private bool appBuildDevelopment;

        private void DrawAppBuildSection()
        {
            RefreshAppBuildStatus();
            BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
            EditorGUILayout.LabelField(L("앱 빌드", "App Build"), EditorStyles.boldLabel);
            EditorGUILayout.LabelField(L("플랫폼", "Platform"), target.ToString());

            EditorGUILayout.BeginHorizontal();
            string location = EditorUserBuildSettings.GetBuildLocation(target);
            string edited = EditorGUILayout.TextField(L("출력 경로", "Output Path"), location);
            if (edited != location) EditorUserBuildSettings.SetBuildLocation(target, edited);
            if (GUILayout.Button(L("선택", "Select"), GUILayout.Width(65f))) ChooseAppOutput(target);
            EditorGUILayout.EndHorizontal();

            bool development = EditorGUILayout.Toggle(L("개발 빌드", "Development Build"), EditorUserBuildSettings.development);
            if (development != EditorUserBuildSettings.development) { EditorUserBuildSettings.development = development; appBuildStatusTime = 0; }
            EditorGUILayout.LabelField(L("배포 순번", "Deployment Sequence"), appBuildSequenceText, EditorStyles.wordWrappedLabel);

            if (appBuildProblems.Count != 0)
                EditorGUILayout.HelpBox(string.Join("\n", appBuildProblems), MessageType.Warning);

            EditorGUI.BeginDisabledGroup(buildInProgress || appBuildProblems.Count != 0 || !CanRunEditorWork());
            if (GUILayout.Button(buildInProgress ? L("빌드 중...", "Building...") : L("앱 빌드", "Build App"), GUILayout.Height(48f)))
                StartAppBuild();
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.HelpBox(L("등록 동기화 → 배포 순번 → Revision 굽기 → Config 저장 → 앱 포함 A → Player 빌드를 한 번에 합니다. 단계를 하나씩 하려면 고급 > 단계별 빌드를 쓰세요.",
                "Runs registration sync → deployment sequence → Revision build → Config save → app included A → Player build at once. Use Advanced > Step-by-step build to run them one by one."), MessageType.None);
        }

        // The readiness check reads this PC's release file and earlier receipts, so it is not done every repaint.
        private void RefreshAppBuildStatus()
        {
            if (EditorApplication.timeSinceStartup - appBuildStatusTime < 2.0) return;
            appBuildStatusTime = EditorApplication.timeSinceStartup;
            appBuildProblems = ManagedAppBuild.Readiness(config, EditorUserBuildSettings.development);
            appBuildSequenceText = DescribeNextSequence(config, EditorUserBuildSettings.development);
        }

        private static string DescribeNextSequence(ManagedAddressableProjectConfig value, bool development)
        {
            try
            {
                var release = ManagedLocalRelease.Effective(value);
                long previous = ManagedAddressableBuildExporter.PreviousDeploymentSequence(value, release);
                if (development)
                    return ManagedAppBuild.ChooseDeploymentSequence(release.deploymentSequence, previous, true) + L(" (개발 빌드는 자동으로 올림)", " (development builds raise it automatically)");
                string text = release.deploymentSequence + L(" (출시 빌드는 고급 > 배포 값의 값을 씀", " (release builds use Advanced > Release values");
                return text + (previous > 0 ? L(", 직전 ", ", previous ") + previous : string.Empty) + ")" +
                    (release.deploymentSequence <= previous || release.deploymentSequence <= 0 ? L(" — 올려야 빌드됨", " — raise it to build") : string.Empty);
            }
            catch (Exception error) { return error.Message; }
        }

        private string ChooseAppOutput(BuildTarget target)
        {
            string current = EditorUserBuildSettings.GetBuildLocation(target);
            string directory = string.IsNullOrEmpty(current) ? Path.GetFullPath("Builds") : Path.GetDirectoryName(current);
            string name = string.IsNullOrEmpty(current) ? PlayerSettings.productName : Path.GetFileNameWithoutExtension(current);
            string title = L("앱 출력 경로", "App output path");
            string chosen;
            switch (target)
            {
                case BuildTarget.iOS: chosen = EditorUtility.SaveFolderPanel(title, directory, name); break;
                case BuildTarget.Android: chosen = EditorUtility.SaveFilePanel(title, directory, name, EditorUserBuildSettings.buildAppBundle ? "aab" : "apk"); break;
                case BuildTarget.StandaloneWindows:
                case BuildTarget.StandaloneWindows64: chosen = EditorUtility.SaveFilePanel(title, directory, name, "exe"); break;
                case BuildTarget.StandaloneOSX: chosen = EditorUtility.SaveFilePanel(title, directory, name, "app"); break;
                case BuildTarget.StandaloneLinux64: chosen = EditorUtility.SaveFilePanel(title, directory, name, "x86_64"); break;
                default: chosen = EditorUtility.SaveFolderPanel(title, directory, name); break;
            }
            if (!string.IsNullOrEmpty(chosen)) EditorUserBuildSettings.SetBuildLocation(target, chosen);
            return chosen;
        }

        private void StartAppBuild()
        {
            if (buildInProgress || !CanRunEditorWork()) return;
            serializedConfig?.ApplyModifiedProperties();
            // App Build uses the saved release values and reloads the drafts when it ends.
            if (HasUnappliedReleaseDraft()) { showResult = true; resultText = UnappliedReleaseDraftMessage(); return; }
            if (HasUnappliedRoleDraft())
            {
                showResult = true;
                resultText = L("빌드 역할 초안이 저장된 값과 다릅니다. 고급 > 빌드 역할에서 빌드 역할 미리 보기 → 미리 본 계획 적용 뒤 앱 빌드를 누르세요.",
                    "The build role draft differs from the saved roles. Use Advanced > Build roles > Preview Build Roles → Apply Previewed Plan, then Build App.");
                return;
            }
            BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
            appBuildOutput = EditorUserBuildSettings.GetBuildLocation(target);
            if (string.IsNullOrWhiteSpace(appBuildOutput)) appBuildOutput = ChooseAppOutput(target);
            if (string.IsNullOrWhiteSpace(appBuildOutput)) return;
            appBuildDevelopment = EditorUserBuildSettings.development;
            buildInProgress = true;
            showResult = true;
            resultText = L("앱 빌드를 시작했습니다...", "App Build started...");
            Repaint();
            // Out of OnGUI, so the long synchronous build does not run inside a layout pass.
            EditorApplication.delayCall += RunAppBuildDeferred;
        }

        private void RunAppBuildDeferred()
        {
            if (this == null) return;
            try
            {
                resultText = ManagedAppBuild.Build(appBuildOutput, appBuildDevelopment).ToString();
            }
            catch (Exception error) { resultText = error.ToString(); }
            finally
            {
                buildInProgress = false;
                LoadConfig();
                Repaint();
            }
        }
    }
}
