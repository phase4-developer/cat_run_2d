using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Artress.ManagedAddressables.Editor
{
    internal static partial class ManagedAddressableSynchronizer
    {
        public static ManagedAddressableSyncPlan CreateRevisionReleasePlan(ManagedAddressableProjectConfig config, ManagedRevisionReleaseMetadata release)
        {
            CheckSyncState(config);
            ValidateSyncPaths(config);
            var settings = ReadSettingsWithoutMigration();
            var next = release?.Copy();
            var blocked = new List<string>();
            var warnings = new List<string>();
            var changes = new List<ManagedAddressableSyncChange>();
            try { ManagedAddressableBuildExporter.ValidateReleaseMetadata(next); }
            catch (Exception error) { blocked.Add(error.Message); }
            if (ManagedLocalRelease.FilePath(config) == null) blocked.Add("Save the Project Config as an asset first. This PC's release values are stored per Config.");
            ManagedRevisionReleaseMetadata current = null;
            try { current = ManagedLocalRelease.Effective(config); }
            catch (Exception error) { blocked.Add(error.Message); }
            if (current != null && next != null)
            {
                string sharedBefore = JsonConvert.SerializeObject(new { current.productId, current.authorityId, current.compatibilityFamily });
                string sharedAfter = JsonConvert.SerializeObject(new { next.productId, next.authorityId, next.compatibilityFamily });
                if (sharedBefore != sharedAfter) changes.Add(new ManagedAddressableSyncChange("Global", "Project Config (shared, Git)", "revisionShared", sharedBefore, sharedAfter));
                string localBefore = JsonConvert.SerializeObject(new { current.channel, current.deploymentSequence });
                string localAfter = JsonConvert.SerializeObject(new { next.channel, next.deploymentSequence });
                if (localBefore != localAfter) changes.Add(new ManagedAddressableSyncChange("Global", "This PC (" + ManagedLocalRelease.FilePath(config) + ")", "channel/deploymentSequence", localBefore, localAfter));
            }
            if (blocked.Count == 0) warnings.AddRange(ManagedAddressableBuildExporter.RevisionSequenceWarnings(config, next));
            warnings.Add("Release metadata only. No Group adoption, SDK setting, packaging link or sequence allocation is performed.");
            return new ManagedAddressableSyncPlan(SyncFingerprint(config, settings), false,
                new List<ManagedAddressableSyncPlan.GroupAddition>(), new List<ManagedAddressableSyncPlan.EntryChange>(),
                changes, blocked, CustomPlanReport(changes, blocked, warnings), warnings,
                releaseMetadata: changes.Count == 0 ? null : next);
        }
    }
}
