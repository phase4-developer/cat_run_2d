using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedOutputCleanupItem
    {
        internal string path, reason;
        internal long bytes;
    }

    internal sealed class ManagedOutputCleanupPlan
    {
        internal string root;
        internal int keepRevisions;
        internal readonly List<ManagedOutputCleanupItem> delete = new List<ManagedOutputCleanupItem>();
        internal readonly List<ManagedOutputCleanupItem> keep = new List<ManagedOutputCleanupItem>();
        internal readonly List<string> errors = new List<string>();
        internal bool CanApply => errors.Count == 0;
        internal long DeleteBytes => delete.Sum(item => item.bytes);
        internal string Signature => string.Join("\n", delete.Select(item => item.path + "|" + item.bytes));
        public override string ToString()
        {
            var lines = new List<string> { "[Root] " + root, "[Keep newest Revisions per target] " + keepRevisions };
            lines.AddRange(delete.Select(item => "[Delete] " + item.path + " / " + Megabytes(item.bytes) + " / " + item.reason));
            lines.AddRange(keep.Select(item => "[Keep] " + item.path + " / " + Megabytes(item.bytes) + " / " + item.reason));
            lines.Add("[Total delete] " + delete.Count + " folders / " + Megabytes(DeleteBytes));
            lines.AddRange(errors.Select(error => "[Blocked] " + error));
            return string.Join("\n", lines);
        }
        private static string Megabytes(long bytes) => (bytes / 1048576.0).ToString("0.0") + " MB";
    }

    // Build output only grows: every Revision, Boot and packaged A gets a new stamp folder.
    // This keeps what this PC still needs and deletes the rest, after a reviewed Preview.
    internal static partial class ManagedAddressableBuildExporter
    {
        internal const int DefaultKeptRevisions = 3;

        public static ManagedOutputCleanupPlan CreateOutputCleanupPlan(ManagedAddressableProjectConfig config, int keepRevisions = DefaultKeptRevisions)
        {
            var plan = new ManagedOutputCleanupPlan { keepRevisions = keepRevisions };
            try
            {
                if (config == null) throw new InvalidOperationException("Select a Project Config.");
                if (keepRevisions < 1) throw new InvalidOperationException("Keep at least one Revision per target.");
                if (BuildInProgress) throw new InvalidOperationException("A content build is running.");
                RequireNoPendingSplitSettings();
                if (File.Exists(PendingPlayerPath)) throw new InvalidOperationException("An interrupted Split Player build is pending. Restore it first.");
                plan.root = SplitOutputBase(config);
                if (!Directory.Exists(plan.root)) return plan;
                RequireNoLink(plan.root);
                var links = AllPackagedLinks();
                foreach (string targetDirectory in Directory.GetDirectories(plan.root))
                {
                    if (IsLink(targetDirectory)) { plan.errors.Add("Linked folder inside the output root: " + targetDirectory); continue; }
                    string target = Path.GetFileName(targetDirectory);
                    var splits = Directory.GetDirectories(targetDirectory).Select(version => Path.Combine(version, "split")).Where(Directory.Exists).ToList();
                    foreach (string split in splits) if (IsLink(split) || IsLink(Path.GetDirectoryName(split))) plan.errors.Add("Linked folder inside the output root: " + split);
                    if (plan.errors.Count > 0) continue;
                    PlanTarget(plan, target, splits, links);
                }
            }
            catch (Exception error) { plan.errors.Add(error.Message); }
            return plan;
        }

        private static void PlanTarget(ManagedOutputCleanupPlan plan, string target, List<string> splits, List<string> links)
        {
            List<string> Stamps(string purpose) => splits.Select(split => Path.Combine(split, purpose)).Where(Directory.Exists)
                .SelectMany(Directory.GetDirectories).ToList();

            foreach (string stamp in Stamps("packaged"))
            {
                string prefix = Path.GetFullPath(stamp).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
                bool linked = links.Any(link => link.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
                Add(plan, stamp, linked, linked ? "Packaged A linked on this PC" : "Packaged A no Config on this PC links");
            }

            var revisions = new List<(string stamp, ManagedSplitBuildReceipt receipt, DateTime written)>();
            foreach (string stamp in Stamps("revision"))
            {
                var receipt = ReadCleanupReceipt(stamp, "Revision");
                if (receipt == null) Add(plan, stamp, false, "Incomplete or failed Revision build");
                else revisions.Add((stamp, receipt, File.GetLastWriteTimeUtc(Path.Combine(stamp, "split_build_receipt.json"))));
            }
            var kept = revisions.OrderByDescending(row => row.written).Take(plan.keepRevisions).ToList();
            foreach (var row in revisions)
            {
                bool keep = kept.Contains(row);
                Add(plan, row.stamp, keep, keep ? "Newest " + plan.keepRevisions + " Revisions for " + target : "Older than the newest " + plan.keepRevisions + " Revisions");
                if (!keep) continue;
                // Nothing reads these after the build: Player packaging uses the packaged A copy,
                // and this route never runs Unity Content Update.
                foreach (string name in new[] { "Runtime", "ContentState" })
                {
                    string child = Path.Combine(row.stamp, name);
                    if (Directory.Exists(child)) Add(plan, child, false, name == "Runtime" ? "SDK output copy unused after a Revision build" : "Content Update state; this route does not use Content Update");
                }
            }

            string stage = StagePointerOutput(target);
            var boots = new List<(string stamp, ManagedSplitBuildReceipt receipt, DateTime written)>();
            foreach (string stamp in Stamps("boot"))
            {
                var receipt = ReadCleanupReceipt(stamp, "Boot");
                if (receipt == null) Add(plan, stamp, false, "Incomplete or failed Boot build");
                else boots.Add((stamp, receipt, File.GetLastWriteTimeUtc(Path.Combine(stamp, "split_build_receipt.json"))));
            }
            var newestBoot = boots.OrderByDescending(row => row.written).FirstOrDefault().stamp;
            var pairedGenerations = new HashSet<string>(kept.Select(row => row.receipt.contentFingerprint).Where(value => !string.IsNullOrEmpty(value)), StringComparer.Ordinal);
            foreach (var row in boots)
            {
                string reason = row.stamp == newestBoot ? "Newest Boot for " + target :
                    stage != null && string.Equals(Path.GetFullPath(row.stamp), stage, StringComparison.OrdinalIgnoreCase) ? "Current SDK stage Boot" :
                    pairedGenerations.Contains(row.receipt.contentFingerprint ?? "") ? "Paired Boot of a kept Revision" : null;
                Add(plan, row.stamp, reason != null, reason ?? "Boot no kept Revision or Player stage needs");
            }
        }

        private static void Add(ManagedOutputCleanupPlan plan, string path, bool keep, string reason)
        {
            var item = new ManagedOutputCleanupItem { path = Path.GetFullPath(path), reason = reason, bytes = FolderBytes(path) };
            (keep ? plan.keep : plan.delete).Add(item);
        }

        private static ManagedSplitBuildReceipt ReadCleanupReceipt(string stamp, string purpose)
        {
            string path = Path.Combine(stamp, "split_build_receipt.json");
            if (!File.Exists(path)) return null;
            try
            {
                var receipt = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(path));
                return receipt != null && receipt.complete && receipt.purpose == purpose ? receipt : null;
            }
            catch { return null; }
        }

        private static string StagePointerOutput(string target)
        {
            string path = Path.Combine("Library", "ArtressManagedAddressablesSplit", target, "stage_receipt.json");
            if (!File.Exists(path)) return null;
            try
            {
                string output = JsonConvert.DeserializeObject<ManagedSplitBuildReceipt>(File.ReadAllText(path))?.outputDirectory;
                return string.IsNullOrEmpty(output) ? null : Path.GetFullPath(output);
            }
            catch { return null; }
        }

        // Every Config's links on this PC, so a second Config sharing the output root keeps its A.
        private static List<string> AllPackagedLinks()
        {
            var result = new List<string>();
            if (!Directory.Exists(ManagedLocalRelease.Folder)) return result;
            // A release file lost mid-replace still links its packaged A through the finished .tmp copy.
            foreach (string temporary in Directory.GetFiles(ManagedLocalRelease.Folder, "Release-*.json.tmp"))
                ManagedLocalRelease.RecoverFinishedWrite(temporary.Substring(0, temporary.Length - ".tmp".Length));
            foreach (string path in Directory.GetFiles(ManagedLocalRelease.Folder, "Release-*.json"))
            {
                var file = JsonConvert.DeserializeObject<ManagedLocalReleaseFile>(File.ReadAllText(path));
                foreach (var link in file?.packaged ?? new List<ManagedPackagedLink>())
                    if (!string.IsNullOrWhiteSpace(link?.metadataPath)) result.Add(Path.GetFullPath(link.metadataPath));
            }
            return result;
        }

        private static long FolderBytes(string path) =>
            Directory.GetFiles(path, "*", SearchOption.AllDirectories).Sum(file => new FileInfo(file).Length);

        private static bool IsLink(string path) => (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0;

        private static void RequireNoLink(string path)
        {
            if (IsLink(path)) throw new InvalidOperationException("Linked folders are not followed or deleted: " + path);
            foreach (string directory in Directory.GetDirectories(path, "*", SearchOption.AllDirectories))
                if (IsLink(directory)) throw new InvalidOperationException("Linked folders are not followed or deleted: " + directory);
        }

        public static long ApplyOutputCleanupPlan(ManagedAddressableProjectConfig config, ManagedOutputCleanupPlan plan)
        {
            if (plan == null || !plan.CanApply) throw new InvalidOperationException("Preview a cleanup plan without blocked items first.");
            var fresh = CreateOutputCleanupPlan(config, plan.keepRevisions);
            if (!fresh.CanApply || fresh.root != plan.root || fresh.Signature != plan.Signature)
                throw new InvalidOperationException("Output changed after Preview. Preview again; nothing was deleted.\n" + string.Join("\n", fresh.errors));
            string prefix = plan.root.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            long freed = 0;
            foreach (var item in plan.delete)
            {
                if (!item.path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Cleanup path is outside the output root: " + item.path);
                if (!Directory.Exists(item.path)) continue;
                RequireNoLink(item.path);
                Directory.Delete(item.path, true);
                freed += item.bytes;
            }
            return freed;
        }
    }
}
