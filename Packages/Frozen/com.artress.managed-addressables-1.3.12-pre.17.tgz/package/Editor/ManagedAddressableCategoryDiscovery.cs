using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor
{
    internal static class ManagedAddressableCategoryDiscovery
    {
        public static List<ManagedCategoryRule> Discover(string contentRoot, IEnumerable<ManagedCategoryRule> existingRules = null)
        {
            List<ManagedCategoryRule> existingList = (existingRules ?? Enumerable.Empty<ManagedCategoryRule>())
                .Where(rule => rule != null && !string.IsNullOrWhiteSpace(rule.relativePath))
                .GroupBy(rule => Normalize(rule.relativePath), StringComparer.OrdinalIgnoreCase)
                .Select(group => group.Last())
                .ToList();

            Dictionary<string, ManagedCategoryRule> existing = existingList
                .ToDictionary(rule => Normalize(rule.relativePath), rule => rule, StringComparer.OrdinalIgnoreCase);

            if (string.IsNullOrWhiteSpace(contentRoot) || !Directory.Exists(contentRoot))
                return existingList.OrderBy(rule => rule.relativePath, StringComparer.OrdinalIgnoreCase).ToList();

            List<ManagedCategoryRule> rules = new List<ManagedCategoryRule>();
            HashSet<string> discoveredPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            AddDeliveryRules(rules, discoveredPaths, existing, contentRoot, "Local", ManagedDeliveryMode.Local);
            AddDeliveryRules(rules, discoveredPaths, existing, contentRoot, "Remote", ManagedDeliveryMode.Remote);

            foreach (ManagedCategoryRule existingRule in existingList)
            {
                if (!discoveredPaths.Contains(Normalize(existingRule.relativePath)))
                    rules.Add(existingRule);
            }

            return rules
                .GroupBy(rule => Normalize(rule.relativePath), StringComparer.OrdinalIgnoreCase)
                .Select(group => group.Last())
                .OrderBy(rule => rule.relativePath, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private static void AddDeliveryRules(List<ManagedCategoryRule> rules, HashSet<string> discoveredPaths, Dictionary<string, ManagedCategoryRule> existing, string root, string folderName, ManagedDeliveryMode delivery)
        {
            string path = Path.Combine(root, folderName);
            if (!Directory.Exists(path))
                return;

            foreach (string directory in Directory.GetDirectories(path))
            {
                string category = Path.GetFileName(directory);
                string relative = folderName + "/" + category;
                string key = Normalize(relative);
                discoveredPaths.Add(key);

                if (existing.TryGetValue(key, out ManagedCategoryRule current))
                {
                    rules.Add(current);
                    continue;
                }

                rules.Add(CreateDefaultRule(relative, category, delivery));
            }
        }

        private static ManagedCategoryRule CreateDefaultRule(string relativePath, string category, ManagedDeliveryMode delivery)
        {
            string groupPrefix = delivery == ManagedDeliveryMode.Local ? string.Empty : "Remote_";
            return new ManagedCategoryRule
            {
                relativePath = relativePath,
                delivery = delivery,
                groupStrategy = ManagedGroupStrategy.ReservedFolder,
                groupNamePattern = groupPrefix + category,
                bundleMode = BundledAssetGroupSchema.BundlePackingMode.PackTogether
            };
        }

        private static string Normalize(string value)
        {
            return (value ?? string.Empty).Replace('\\', '/').Trim('/');
        }
    }
}
