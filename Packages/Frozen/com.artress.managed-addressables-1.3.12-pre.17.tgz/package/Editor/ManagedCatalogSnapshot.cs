using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.ResourceManagement.ResourceProviders;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedCatalogEntrySnapshot
    {
        public string id;
        public SortedDictionary<string, string> values = new SortedDictionary<string, string>(StringComparer.Ordinal);
        public List<string> keys = new List<string>();
    }

    internal sealed class ManagedCatalogSnapshot
    {
        public SortedDictionary<string, string> metadata = new SortedDictionary<string, string>(StringComparer.Ordinal);
        public List<ManagedCatalogEntrySnapshot> entries = new List<ManagedCatalogEntrySnapshot>();

        private static ManagedCatalogSnapshot ReadBinary(string path)
        {
            if (!path.EndsWith(".bin", StringComparison.OrdinalIgnoreCase))
                throw new NotSupportedException("카탈로그 내용 비교는 현재 Binary Catalog(.bin)를 지원합니다.");

            Type serializerType = typeof(BinaryContentCatalogData).GetNestedType("Serializer", BindingFlags.NonPublic);
            if (serializerType == null)
                throw new NotSupportedException("현재 Addressables의 Binary Catalog 읽기 API를 찾을 수 없습니다.");
            object serializer = Activator.CreateInstance(serializerType, true);
            serializerType.GetMethod("WithInternalIdResolvingDisabled").Invoke(serializer, null);
            Type storageType = typeof(IResourceLocation).Assembly.GetType("UnityEngine.ResourceManagement.Util.BinaryStorageBuffer", true);
            Type readerType = storageType.GetNestedType("Reader", BindingFlags.Public | BindingFlags.NonPublic);
            Type adapterType = storageType.GetNestedType("ISerializationAdapter", BindingFlags.Public | BindingFlags.NonPublic);
            Array adapters = Array.CreateInstance(adapterType, 1);
            adapters.SetValue(serializer, 0);
            // Keep the stored paths intact; comparison must not resolve paths or register a runtime catalog.
            using (IDisposable reader = (IDisposable)Activator.CreateInstance(readerType, File.ReadAllBytes(path), 8192, (uint)0, adapters))
            {
                MethodInfo readObject = readerType.GetMethods().Single(method => method.Name == "ReadObject" && method.IsGenericMethodDefinition && method.GetParameters().Length == 3);
                BinaryContentCatalogData catalog = (BinaryContentCatalogData)readObject.MakeGenericMethod(typeof(BinaryContentCatalogData)).Invoke(reader, new object[] { (uint)0, (uint)0, false });
                MethodInfo createLocator = typeof(ContentCatalogData).GetMethod("CreateCustomLocator", BindingFlags.Instance | BindingFlags.NonPublic);
                if (createLocator == null)
                    throw new NotSupportedException("현재 Addressables의 Catalog Locator 읽기 API를 찾을 수 없습니다.");
                IResourceLocator locator = (IResourceLocator)createLocator.Invoke(catalog, new object[] { string.Empty, null });
                ManagedCatalogSnapshot snapshot = new ManagedCatalogSnapshot();
                snapshot.metadata["BuildResultHash"] = catalog.BuildResultHash;
                snapshot.metadata["InstanceProvider"] = JsonUtility.ToJson(catalog.InstanceProviderData);
                snapshot.metadata["SceneProvider"] = JsonUtility.ToJson(catalog.SceneProviderData);
                snapshot.metadata["ResourceProviders"] = JsonConvert.SerializeObject(catalog.ResourceProviderData.Select(provider => JsonUtility.ToJson(provider)).ToArray());

                Dictionary<string, ManagedCatalogEntrySnapshot> locations = new Dictionary<string, ManagedCatalogEntrySnapshot>(StringComparer.Ordinal);
                foreach (object key in locator.Keys)
                {
                    if (!locator.Locate(key, null, out IList<IResourceLocation> resolved))
                        continue;
                    foreach (IResourceLocation location in resolved)
                    {
                        ManagedCatalogEntrySnapshot entry = Capture(location);
                        string signature = entry.id + "|" + JsonConvert.SerializeObject(entry.values);
                        if (!locations.TryGetValue(signature, out ManagedCatalogEntrySnapshot existing))
                            locations.Add(signature, existing = entry);
                        string keyText = Convert.ToString(key, System.Globalization.CultureInfo.InvariantCulture);
                        if (!existing.keys.Contains(keyText))
                            existing.keys.Add(keyText);
                    }
                }
                foreach (ManagedCatalogEntrySnapshot entry in locations.Values)
                {
                    entry.keys.Sort(StringComparer.Ordinal);
                    entry.values["Keys"] = JsonConvert.SerializeObject(entry.keys);
                }
                snapshot.entries = locations.Values.OrderBy(entry => entry.id, StringComparer.Ordinal).ThenBy(entry => JsonConvert.SerializeObject(entry.values), StringComparer.Ordinal).ToList();
                return snapshot;
            }
        }

        internal static ManagedCatalogSnapshot ReadSplit(string path)
        {
            if (path.EndsWith(".bin", StringComparison.OrdinalIgnoreCase))
                return ReadBinary(path);
            if (!path.EndsWith(".json", StringComparison.OrdinalIgnoreCase)) throw new NotSupportedException("Unsupported Catalog format: " + path);
            var catalog = JsonUtility.FromJson<JsonContentCatalogData>(File.ReadAllText(path));
            if (catalog == null) throw new InvalidOperationException("SDK JSON catalog could not be read.");
            var locator = catalog.CreateLocator();
            var result = new ManagedCatalogSnapshot();
            result.metadata["BuildResultHash"] = catalog.BuildResultHash;
            var locations = new Dictionary<string, ManagedCatalogEntrySnapshot>(StringComparer.Ordinal);
            foreach (var key in locator.Keys)
            {
                if (!locator.Locate(key, null, out var resolved)) continue;
                foreach (var location in resolved)
                {
                    var entry = Capture(location);
                    string signature = entry.id + "|" + JsonConvert.SerializeObject(entry.values);
                    if (!locations.TryGetValue(signature, out var existing)) locations.Add(signature, existing = entry);
                    string text = Convert.ToString(key, System.Globalization.CultureInfo.InvariantCulture);
                    if (!existing.keys.Contains(text)) existing.keys.Add(text);
                }
            }
            result.entries = locations.Values.OrderBy(e => e.id, StringComparer.Ordinal).ToList();
            return result;
        }

        private static ManagedCatalogEntrySnapshot Capture(IResourceLocation location)
        {
            ManagedCatalogEntrySnapshot entry = new ManagedCatalogEntrySnapshot { id = Identity(location) };
            entry.values["PrimaryKey"] = location.PrimaryKey;
            entry.values["InternalId"] = location.InternalId;
            entry.values["ProviderId"] = location.ProviderId;
            entry.values["ResourceType"] = location.ResourceType?.AssemblyQualifiedName ?? "<unresolved>";
            entry.values["Dependencies"] = JsonConvert.SerializeObject(location.HasDependencies
                ? location.Dependencies.Select(Identity).OrderBy(value => value, StringComparer.Ordinal).ToArray() : Array.Empty<string>());
            if (location.Data != null)
            {
                JToken data = JToken.FromObject(location.Data);
                if (data is JObject properties)
                {
                    foreach (JProperty property in properties.Properties())
                        entry.values["Data." + property.Name] = property.Value.ToString(Formatting.None);
                }
                else
                    entry.values["Data"] = data.ToString(Formatting.None);
            }
            return entry;
        }

        private static string Identity(IResourceLocation location)
        {
            return location.Data is AssetBundleRequestOptions ? "Bundle|" + location.InternalId : "Asset|" + location.PrimaryKey + "|" + location.ResourceType?.FullName;
        }
    }
}
