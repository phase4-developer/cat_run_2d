using System;
using UnityEditor;
using UnityEngine;
using static Artress.ManagedAddressables.Editor.ManagedEditorText;

namespace Artress.ManagedAddressables.Editor
{
    public sealed partial class ManagedAddressablesWindow
    {
        private ManagedAddressableProjectConfig packagedDraftConfig;
        private ManagedRevisionReleaseMetadata packagedReleaseDraft;
        private string packagedReceiptDraft;
        private string packagedSourceBootReceiptDraft;
        private ManagedPackagedRevisionPlan reviewedPackagedPlan;
        private int cleanupKeepDraft = ManagedAddressableBuildExporter.DefaultKeptRevisions;
        private ManagedOutputCleanupPlan reviewedCleanupPlan;
        private string localHostRootDraft;
        private string localHostReceiptDraft;
        private ManagedLocalHostPublishPlan reviewedLocalHostPlan;

        private static ManagedRevisionReleaseMetadata ReadEffectiveRelease(ManagedAddressableProjectConfig value)
        {
            try { return ManagedLocalRelease.Effective(value); }
            catch { return new ManagedRevisionReleaseMetadata(); }
        }

        private void LoadPackagedDrafts()
        {
            packagedDraftConfig = config;
            packagedReleaseDraft = ReadEffectiveRelease(config);
            packagedReceiptDraft = ManagedAddressableBuildExporter.MostRecentRevisionReceipt(config);
            localHostReceiptDraft = packagedReceiptDraft;
            try { localHostRootDraft = ManagedLocalRelease.Read(config).localHostRoot; }
            catch { localHostRootDraft = null; }
        }

        private void DrawReleaseSection()
        {
            if (packagedDraftConfig != config || packagedReleaseDraft == null) LoadPackagedDrafts();
            EditorGUILayout.HelpBox(L("같은 배포 주체가 원격 Revision과 앱 포함 A에 부여한 값을 입력합니다. 앱 빌드는 개발 빌드일 때만 순번을 자동으로 올리고, 출시 빌드는 여기 저장한 순번을 씁니다. Save 호환성은 제품 출시 검증의 책임입니다.",
                "Enter the values the deployment authority gives the remote Revision and the app included A. App Build raises the sequence itself only for development builds; release builds use the sequence saved here. Save compatibility is the product release check's responsibility."), MessageType.Info);
            EditorGUILayout.LabelField(L("공유 값 (Project Config, Git으로 공유)", "Shared values (Project Config, shared through Git)"), EditorStyles.miniBoldLabel);
            packagedReleaseDraft.productId = EditorGUILayout.TextField("Product ID", packagedReleaseDraft.productId);
            packagedReleaseDraft.authorityId = EditorGUILayout.TextField("Deployment authority", packagedReleaseDraft.authorityId);
            packagedReleaseDraft.compatibilityFamily = EditorGUILayout.TextField("Compatibility family", packagedReleaseDraft.compatibilityFamily);
            EditorGUILayout.LabelField(L("이 PC 값 (", "This PC (") + (ManagedLocalRelease.FilePath(config) ?? L("Config를 먼저 저장", "save the Config first")) + L(", Git 밖)", ", outside Git)"), EditorStyles.miniBoldLabel);
            packagedReleaseDraft.channel = EditorGUILayout.TextField("Channel", packagedReleaseDraft.channel);
            packagedReleaseDraft.deploymentSequence = EditorGUILayout.LongField("Deployment sequence", packagedReleaseDraft.deploymentSequence);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("배포 값 미리 보기", "Preview Release Values")))
                RunCustomPreview(L("배포 값", "Release values"), () => ManagedAddressableSynchronizer.CreateRevisionReleasePlan(config, packagedReleaseDraft));
            if (GUILayout.Button(L("배포 값 다시 읽기", "Reload Release Values"))) packagedReleaseDraft = ReadEffectiveRelease(config);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.HelpBox(L("PC마다 다른 channel을 쓰면 다른 PC의 Revision과 순번이 섞이지 않습니다.",
                "A different channel per PC keeps its Revisions and sequences apart from other PCs."), MessageType.None);
            EditorGUILayout.PropertyField(serializedConfig.FindProperty("allowDevelopmentHttp"), new GUIContent(L("개발용 HTTP 허용", "Allow Development HTTP")));
        }

        private void DrawPackagedRevisionSection()
        {
            if (packagedDraftConfig != config || packagedReleaseDraft == null) LoadPackagedDrafts();
            EditorGUILayout.Space();
            EditorGUILayout.LabelField(L("앱 포함 A", "App included A"), EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(L("검증된 Revision 영수증의 실제 Catalog/Bundle을 바꾸지 않고 앱에 넣습니다. SDK 콘텐츠를 다시 빌드하지 않습니다.",
                "Puts the verified Revision receipt's exact Catalog/Bundles into the app without rebuilding SDK content."), MessageType.None);
            EditorGUILayout.BeginHorizontal();
            packagedReceiptDraft = EditorGUILayout.TextField(L("검증된 Revision 영수증", "Verified Revision receipt"), packagedReceiptDraft);
            if (GUILayout.Button(L("선택", "Select"), GUILayout.Width(65)))
            {
                string selected = EditorUtility.OpenFilePanel("Verified split_build_receipt.json", "", "json");
                if (!string.IsNullOrEmpty(selected)) packagedReceiptDraft = selected;
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            packagedSourceBootReceiptDraft = EditorGUILayout.TextField(L("원래 짝 Boot 영수증", "Original paired Boot receipt"), packagedSourceBootReceiptDraft);
            if (GUILayout.Button(L("선택", "Select"), GUILayout.Width(65)))
            {
                string selected = EditorUtility.OpenFilePanel("Original paired Boot split_build_receipt.json", "", "json");
                if (!string.IsNullOrEmpty(selected)) packagedSourceBootReceiptDraft = selected;
            }
            EditorGUILayout.EndHorizontal();
            EditorGUI.BeginDisabledGroup(buildInProgress);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("앱 포함 A 미리 보기", "Preview App Included A")))
            {
                reviewedPackagedPlan = ManagedAddressableBuildExporter.CreatePackagedRevisionPlan(config, packagedReceiptDraft, packagedReleaseDraft, packagedSourceBootReceiptDraft);
                resultText = reviewedPackagedPlan.ToString();
            }
            if (GUILayout.Button(L("앱 포함 A 적용", "Apply App Included A")))
            {
                try
                {
                    // Edits to the visible draft require a new review too.
                    if (reviewedPackagedPlan == null || JsonUtility.ToJson(packagedReleaseDraft) != JsonUtility.ToJson(reviewedPackagedPlan.release) ||
                        string.IsNullOrWhiteSpace(packagedReceiptDraft) || System.IO.Path.GetFullPath(packagedReceiptDraft) != reviewedPackagedPlan.receiptPath ||
                        (string.IsNullOrWhiteSpace(packagedSourceBootReceiptDraft) ? null : System.IO.Path.GetFullPath(packagedSourceBootReceiptDraft)) != reviewedPackagedPlan.sourceBootReceiptPath)
                        throw new InvalidOperationException(L("앱 포함 A 초안이 바뀌었습니다. 다시 미리 보세요.", "App included A draft changed. Preview again."));
                    resultText = L("앱 포함 A를 만들고 이 PC에 연결했습니다: ", "App included A created and linked on this PC: ") + ManagedAddressableBuildExporter.ApplyPackagedRevisionPlan(config, reviewedPackagedPlan);
                    serializedConfig.Update(); reviewedPackagedPlan = null;
                }
                catch (Exception error) { resultText = error.ToString(); }
                appBuildStatusTime = 0;
            }
            EditorGUILayout.EndHorizontal();
            EditorGUI.EndDisabledGroup();
            ManagedPackagedLink link = null;
            try { link = ManagedLocalRelease.PackagedForActiveTarget(config); } catch (Exception error) { resultText = error.Message; }
            EditorGUILayout.LabelField(L("Player에 들어갈 앱 포함 A (", "Player app included A (") + EditorUserBuildSettings.activeBuildTarget + L(", 이 PC)", ", this PC)"), link?.metadataPath ?? L("(없음)", "(none)"), EditorStyles.wordWrappedLabel);
        }

        private void DrawOutputCleanupSection()
        {
            if (packagedDraftConfig != config || packagedReleaseDraft == null) LoadPackagedDrafts();
            EditorGUILayout.HelpBox(L("빌드마다 새 stamp 폴더가 쌓입니다. 이 PC에서 연결한 앱 포함 A, 플랫폼별 최근 Revision, 현재 Boot와 그 짝 Boot만 남기고 나머지를 지웁니다. 남긴 Revision의 Runtime·ContentState 복사본도 지웁니다. 지운 폴더는 되돌릴 수 없습니다.",
                "Every build adds a stamp folder. Only this PC's linked app included A, the newest Revisions per target, the current Boot and its paired Boot are kept. The kept Revisions' Runtime/ContentState copies are removed too. Deleted folders cannot be restored."), MessageType.Info);
            cleanupKeepDraft = Math.Max(1, EditorGUILayout.IntField(L("플랫폼별로 남길 최근 Revision 수", "Keep newest Revisions per target"), cleanupKeepDraft));
            EditorGUI.BeginDisabledGroup(buildInProgress);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("산출물 정리 미리 보기", "Preview Output Cleanup")))
            {
                reviewedCleanupPlan = ManagedAddressableBuildExporter.CreateOutputCleanupPlan(config, cleanupKeepDraft);
                resultText = reviewedCleanupPlan.ToString();
            }
            if (GUILayout.Button(L("산출물 정리 적용", "Apply Output Cleanup")))
            {
                try
                {
                    if (reviewedCleanupPlan == null || reviewedCleanupPlan.keepRevisions != cleanupKeepDraft) throw new InvalidOperationException(L("정리 초안이 바뀌었습니다. 다시 미리 보세요.", "Cleanup draft changed. Preview again."));
                    long freed = ManagedAddressableBuildExporter.ApplyOutputCleanupPlan(config, reviewedCleanupPlan);
                    resultText = string.Format(L("폴더 {0}개, {1} MB를 지웠습니다.", "Deleted {0} folders, {1} MB."), reviewedCleanupPlan.delete.Count, (freed / 1048576.0).ToString("0.0"));
                    reviewedCleanupPlan = null;
                }
                catch (Exception error) { resultText = error.ToString(); }
            }
            EditorGUILayout.EndHorizontal();
            EditorGUI.EndDisabledGroup();
        }

        private void DrawLocalHostSection()
        {
            if (packagedDraftConfig != config || packagedReleaseDraft == null) LoadPackagedDrafts();
            EditorGUILayout.HelpBox(L("게임 서버 대신 로컬 정적 서버로 원격 갱신을 시험할 때 씁니다. 빌드한 Revision을 서버 폴더로 복사하고, 앱이 읽을 split/latest/<플랫폼>/<channel>.json을 씁니다. 이 파일의 SHA는 같은 서버에서 오므로 운영 신뢰 기준이 아닙니다. Android 실기기는 adb reverse로 기기의 localhost를 이 PC에 연결합니다.",
                "For trying remote updates with a local static server instead of the game server. Copies a built Revision into the server folder and writes split/latest/<target>/<channel>.json for the app. Its SHA comes from the same server, so it is not a production trust anchor. On an Android device, adb reverse connects the device's localhost to this PC."), MessageType.Warning);
            EditorGUILayout.BeginHorizontal();
            localHostRootDraft = EditorGUILayout.TextField(L("로컬 호스트 폴더 (이 PC)", "Local host folder (this PC)"), localHostRootDraft);
            if (GUILayout.Button(L("선택", "Select"), GUILayout.Width(65)))
            {
                string selected = EditorUtility.OpenFolderPanel(L("정적 서버가 제공하는 폴더", "Folder your static server serves"), localHostRootDraft ?? "", "");
                if (!string.IsNullOrEmpty(selected)) localHostRootDraft = selected;
            }
            if (GUILayout.Button(L("저장", "Save"), GUILayout.Width(55)))
            {
                try { ManagedAddressableBuildExporter.SetLocalHostRoot(config, localHostRootDraft); resultText = L("로컬 호스트 폴더를 저장했습니다: ", "Local host folder saved to ") + ManagedLocalRelease.FilePath(config); }
                catch (Exception error) { resultText = error.Message; }
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            localHostReceiptDraft = EditorGUILayout.TextField(L("게시할 Revision 영수증", "Revision receipt to publish"), localHostReceiptDraft);
            if (GUILayout.Button(L("최근 것", "Latest"), GUILayout.Width(65))) localHostReceiptDraft = ManagedAddressableBuildExporter.MostRecentRevisionReceipt(config);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("로컬 호스트 게시 미리 보기", "Preview Local Host Publish")))
            {
                reviewedLocalHostPlan = ManagedAddressableBuildExporter.CreateLocalHostPublishPlan(config, localHostReceiptDraft, localHostRootDraft);
                resultText = reviewedLocalHostPlan.ToString();
            }
            if (GUILayout.Button(L("로컬 호스트 게시 적용", "Apply Local Host Publish")))
            {
                try
                {
                    if (reviewedLocalHostPlan == null || string.IsNullOrWhiteSpace(localHostReceiptDraft) || System.IO.Path.GetFullPath(localHostReceiptDraft) != reviewedLocalHostPlan.receiptPath)
                        throw new InvalidOperationException(L("게시 초안이 바뀌었습니다. 다시 미리 보세요.", "Publish draft changed. Preview again."));
                    resultText = L("게시했습니다. 앱이 읽는 주소: ", "Published. The app reads ") + ManagedAddressableBuildExporter.ApplyLocalHostPublishPlan(config, reviewedLocalHostPlan);
                    reviewedLocalHostPlan = null;
                }
                catch (Exception error) { resultText = error.ToString(); }
            }
            EditorGUILayout.EndHorizontal();
        }
    }
}
