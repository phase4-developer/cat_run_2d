using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using UnityEditor.AddressableAssets.Settings;
using UnityEditor.AddressableAssets.Settings.GroupSchemas;

namespace Artress.ManagedAddressables.Editor
{
    internal sealed class ManagedAddressableSyncChange
    {
        public readonly string scope;
        public readonly string target;
        public readonly string property;
        public readonly string before;
        public readonly string after;

        internal ManagedAddressableSyncChange(string scope, string target, string property, string before, string after)
        {
            this.scope = scope;
            this.target = target;
            this.property = property;
            this.before = before;
            this.after = after;
        }

        public override string ToString() => $"[{scope}] {target} / {property}: {before} -> {after}";
    }

    // This is a single in-memory registration review, not a persisted authoring format.
    internal sealed class ManagedAddressableSyncPlan
    {
        internal sealed class GroupAddition
        {
            internal readonly string name;
            internal readonly ManagedDeliveryMode delivery;
            internal readonly BundledAssetGroupSchema.BundlePackingMode bundleMode;

            internal GroupAddition(string name, ManagedDeliveryMode delivery, BundledAssetGroupSchema.BundlePackingMode bundleMode)
            {
                this.name = name;
                this.delivery = delivery;
                this.bundleMode = bundleMode;
            }
        }

        internal sealed class EntryChange
        {
            internal readonly string guid;
            internal readonly string groupName;
            internal readonly string address;
            internal readonly bool remove;

            internal EntryChange(string guid, string groupName, string address, bool remove = false)
            {
                this.guid = guid;
                this.groupName = groupName;
                this.address = address;
                this.remove = remove;
            }
        }

        internal sealed class GroupPolicyChange
        {
            internal readonly string assetGuid;
            internal GroupPolicyChange(string assetGuid) { this.assetGuid = assetGuid; }
        }

        internal readonly string fingerprint;
        internal readonly bool createSettings;
        internal readonly ReadOnlyCollection<GroupAddition> groups;
        internal readonly ReadOnlyCollection<EntryChange> entries;
        internal readonly ReadOnlyCollection<GroupPolicyChange> policies;
        internal readonly ReadOnlyCollection<string> ownedGroupGuidsAfter;
        internal readonly ManagedBuildRoleChange buildRoles;
        private readonly ManagedRevisionReleaseMetadata releaseMetadata;
        internal bool HasReleaseMetadata => releaseMetadata != null;
        internal ManagedRevisionReleaseMetadata CopyReleaseMetadata() => releaseMetadata?.Copy();
        private readonly ManagedAddressableSyncReport report;

        public ReadOnlyCollection<ManagedAddressableSyncChange> Changes { get; }
        public ReadOnlyCollection<string> BlockedChanges { get; }
        public ReadOnlyCollection<string> Warnings { get; }
        public bool CanApply => BlockedChanges.Count == 0;
        public bool HasChanges => Changes.Count != 0;
        public ManagedAddressableSyncReport Report => report.Copy();

        internal ManagedAddressableSyncPlan(string fingerprint, bool createSettings,
            List<GroupAddition> groups, List<EntryChange> entries, List<ManagedAddressableSyncChange> changes,
            List<string> blockedChanges, ManagedAddressableSyncReport report, List<string> warnings = null,
            List<string> ownedGroupGuidsAfter = null, List<GroupPolicyChange> policies = null, ManagedBuildRoleChange buildRoles = null,
            ManagedRevisionReleaseMetadata releaseMetadata = null)
        {
            this.releaseMetadata = releaseMetadata?.Copy();
            this.buildRoles = buildRoles;
            this.fingerprint = fingerprint;
            this.createSettings = createSettings;
            this.groups = groups.AsReadOnly();
            this.entries = entries.AsReadOnly();
            this.policies = (policies ?? new List<GroupPolicyChange>()).AsReadOnly();
            this.ownedGroupGuidsAfter = ownedGroupGuidsAfter?.AsReadOnly();
            Changes = changes.AsReadOnly();
            BlockedChanges = blockedChanges.AsReadOnly();
            Warnings = (warnings ?? new List<string>()).AsReadOnly();
            this.report = report.Copy();
        }
    }
}

namespace Artress.ManagedAddressables.Editor
{
    internal static partial class ManagedAddressableSynchronizer
    {
        private static void PlanInitialSettings(ManagedAddressableProjectConfig config, List<ManagedAddressableSyncChange> changes)
        {
            changes.Add(new ManagedAddressableSyncChange("Global", "Addressables Settings", "Asset + SDK default groups/builders/templates", "absent", "new SDK Settings"));
            changes.Add(new ManagedAddressableSyncChange("Global", "EditorBuildSettings / SDK DefaultObject", "Default Settings registration", "absent", "new Settings reference"));
            foreach (var pair in new Dictionary<string, string>
            {
                { "BuildRemoteCatalog", "true" }, { "DisableCatalogUpdateOnStartup", "true" }, { "UniqueBundleIds", "true" },
                { "NonRecursiveBuilding", "false" }, { "ContiguousBundles", "true" }, { "OptimizeCatalogSize", "false" },
                { "IgnoreUnsupportedFilesInBuild", "false" }, { "MaxConcurrentWebRequests", "3" }, { "CatalogRequestsTimeout", "0" },
                { "OverridePlayerVersion", "[UnityEditor.PlayerSettings.bundleVersion]" },
                { "BuiltInBundleNaming", "DefaultGroupGuid" }, { "MonoScriptBundleNaming", "DefaultGroupGuid" },
                { "RemoteCatalogBuildPath", ManagedAddressableProfileUtility.RemoteBuildPath }, { "RemoteCatalogLoadPath", ManagedAddressableProfileUtility.RemoteLoadPath },
                { "ActivePlayerDataBuilderIndex", "SDK packed-mode builder (when available)" }, { "BuildAddressablesWithPlayerBuild", "DoNotBuildWithPlayer" }
            }) changes.Add(new ManagedAddressableSyncChange("Global", "new Addressables Settings", pair.Key, "new SDK default", pair.Value));
            string profile = string.IsNullOrWhiteSpace(config.profileName) ? "Artress Managed" : config.profileName.Trim();
            changes.Add(new ManagedAddressableSyncChange("Profile", profile, "Profile + activeProfileId", "absent / new SDK default", "new Managed Profile, active"));
            foreach (var pair in ManagedAddressableProfileUtility.InitialValues(config))
                changes.Add(new ManagedAddressableSyncChange("Profile", profile, pair.Key, "new SDK default / missing variable", pair.Value));
        }

        private static Dictionary<string, string> GroupBaseline(ManagedDeliveryMode delivery, BundledAssetGroupSchema.BundlePackingMode bundleMode)
        {
            bool remote = delivery != ManagedDeliveryMode.Local;
            return new Dictionary<string, string>
            {
                { "BuildPath", remote ? ManagedAddressableProfileUtility.RemoteBuildPath : ManagedAddressableProfileUtility.LocalBuildPath },
                { "LoadPath", remote ? ManagedAddressableProfileUtility.RemoteLoadPath : ManagedAddressableProfileUtility.LocalLoadPath },
                { "Compression", "LZ4" }, { "BundleMode", bundleMode.ToString() }, { "InternalIdNamingMode", "FullPath" },
                { "IncludeAddressInCatalog", "True" }, { "IncludeGUIDInCatalog", "True" }, { "IncludeLabelsInCatalog", "True" },
                { "IncludeInBuild", "True" }, { "UseDefaultSchemaSettings", "False" }, { "UseAssetBundleCache", remote.ToString() }, { "UseAssetBundleCrc", remote.ToString() },
                { "UseAssetBundleCrcForCachedBundles", "False" }, { "AssetBundledCacheClearBehavior", "ClearWhenSpaceIsNeededInCache" }, { "UseUnityWebRequestForLocalBundles", "False" },
                { "ForceUniqueProvider", "False" }, { "Timeout", "0" }, { "RedirectLimit", "-1" }, { "RetryCount", "0" },
                { "ChunkedTransfer", "False" }, { "AssetLoadMode", "RequestedAssetAndDependencies" }, { "BundleNaming", "NoHash" },
                { "InternalBundleIdMode", "GroupGuid" }, { "StaticContent", (!remote).ToString() }
            };
        }

        private static void PlanNewGroup(string name, ManagedDeliveryMode delivery, BundledAssetGroupSchema.BundlePackingMode bundleMode, List<ManagedAddressableSyncChange> changes)
        {
            changes.Add(new ManagedAddressableSyncChange("Group", name, "Group + unique Bundled/ContentUpdate schemas", "absent", "new Group; SDK creates GUID"));
            foreach (var pair in GroupBaseline(delivery, bundleMode))
                changes.Add(new ManagedAddressableSyncChange("Group", name, pair.Key, "absent", pair.Value));
        }

    }
}
