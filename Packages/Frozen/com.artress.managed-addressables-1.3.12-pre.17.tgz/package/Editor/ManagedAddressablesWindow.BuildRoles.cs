using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;
using static Artress.ManagedAddressables.Editor.ManagedEditorText;

namespace Artress.ManagedAddressables.Editor
{
    public sealed partial class ManagedAddressablesWindow
    {
        private ManagedAddressableProjectConfig roleDraftConfig;
        private List<ManagedGroupBuildRoleSetting> roleDraft;
        private string bootKeyDraft;
        private AddressableAssetGroup roleCandidate;
        private readonly HashSet<string> roleAdoptions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private ManagedSplitBuildPlan reviewedSplitBuildPlan;
        private ManagedSplitSettingsRestorePlan reviewedSettingsRestorePlan;

        private void LoadBuildRoleDraft()
        {
            roleDraftConfig = config;
            roleDraft = (config.groupBuildRoles ?? new List<ManagedGroupBuildRoleSetting>()).Where(r => r != null).Select(r => r.Copy()).ToList();
            roleAdoptions.Clear();
            foreach (var row in roleDraft) roleAdoptions.Add(row.groupAssetGuid);
            bootKeyDraft = string.Join("\n", config.requiredBootKeys ?? new List<string>());
        }

        private bool HasUnappliedRoleDraft()
        {
            if (roleDraftConfig != config || roleDraft == null || config == null) return false;
            // Compared in the form the apply saves, so roles just applied in another order still match.
            var keys = (bootKeyDraft ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return !ManagedAddressableSynchronizer.SameBuildRoles(config, roleDraft, keys);
        }

        private void SuggestBuildRoles()
        {
            try
            {
                var keys = (bootKeyDraft ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                var suggestion = ManagedAddressableSynchronizer.SuggestBuildRoles(config, roleDraft, keys);
                var added = suggestion.roles.Where(row => !roleDraft.Any(old => old.groupAssetGuid == row.groupAssetGuid)).ToList();
                roleDraft = suggestion.roles;
                foreach (var row in added) roleAdoptions.Add(row.groupAssetGuid);
                bootKeyDraft = string.Join("\n", suggestion.bootKeys);
                resultText = L("Local 폴더는 Boot, Remote 폴더는 Revision으로 제안했습니다. 초안을 확인한 뒤 빌드 역할 미리 보기를 누르세요.",
                    "Local folders are Boot and Remote folders are Revision. Review the draft, then Preview Build Roles.");
                if (suggestion.undecidedGroups.Count > 0) resultText += "\n" + L("직접 추가할 Group: ", "Add these Groups by hand: ") + string.Join(", ", suggestion.undecidedGroups);
            }
            catch (Exception error) { resultText = error.Message; }
        }

        private void DrawBuildRoleSection()
        {
            if (roleDraftConfig != config || roleDraft == null) LoadBuildRoleDraft();
            EditorGUILayout.HelpBox(L("역할과 수정 권한은 별개입니다. 빌드 역할 미리 보기에서 역할 변경과 필요한 채택을 함께 검토합니다. 신규 채택을 끄면 해당 Group의 임시 Include/경로 변경이 필요한 빌드는 막힙니다. Group/Entry/schema/Profile은 이 계획에서 바꾸지 않습니다. Boot는 Player 빌드가 직접 굽습니다.",
                "Roles and edit rights are separate. Preview Build Roles reviews role changes and the adoptions they need together. Without adoption, builds that need temporary Include/path changes on that Group are blocked. This plan never changes Group/Entry/schema/Profile. The Player build makes Boot itself."), MessageType.Info);
            for (int i = 0; i < roleDraft.Count; i++)
            {
                var row = roleDraft[i];
                EditorGUILayout.BeginHorizontal();
                string path = AssetDatabase.GUIDToAssetPath(row.groupAssetGuid);
                EditorGUILayout.LabelField((string.IsNullOrEmpty(path) ? L("없는 GUID: ", "Missing GUID: ") + row.groupAssetGuid : path), EditorStyles.wordWrappedLabel, GUILayout.MinWidth(180));
                row.role = (ManagedGroupBuildRole)EditorGUILayout.EnumPopup(row.role, GUILayout.Width(105));
                row.useForSharedBundles = GUILayout.Toggle(row.useForSharedBundles, L("공유 Bundle 대상", "Shared target"), GUILayout.Width(120));
                bool remove = GUILayout.Button(L("빼기", "Remove"), GUILayout.Width(65));
                EditorGUILayout.EndHorizontal();
                bool owned = config.ownedGroupGuids?.Any(g => string.Equals(g, row.groupAssetGuid, StringComparison.OrdinalIgnoreCase)) == true;
                if (owned) EditorGUILayout.LabelField(L("명시 채택됨 (해제는 Group 소유에서)", "Explicitly owned (release it in Group ownership)"));
                else
                {
                    bool selected = EditorGUILayout.ToggleLeft(L("Boot/Revision 임시 쓰기를 위해 채택", "Adopt for temporary Boot/Revision writes"), roleAdoptions.Contains(row.groupAssetGuid));
                    if (selected) roleAdoptions.Add(row.groupAssetGuid); else roleAdoptions.Remove(row.groupAssetGuid);
                }
                if (remove) { roleDraft.RemoveAt(i); break; }
            }
            EditorGUILayout.BeginHorizontal();
            roleCandidate = (AddressableAssetGroup)EditorGUILayout.ObjectField(L("역할을 줄 Group", "Explicit role Group"), roleCandidate, typeof(AddressableAssetGroup), false);
            if (GUILayout.Button(L("역할 행 추가", "Add Role Row"), GUILayout.Width(110)) && roleCandidate != null)
            {
                string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(roleCandidate));
                if (!roleDraft.Any(r => r.groupAssetGuid == guid)) { roleDraft.Add(new ManagedGroupBuildRoleSetting { groupAssetGuid = guid }); roleAdoptions.Add(guid); }
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.LabelField(L("필수 Boot 키 (한 줄에 정확한 키 하나)", "Required Boot keys (one exact key per line)"));
            bootKeyDraft = EditorGUILayout.TextArea(bootKeyDraft ?? "", GUILayout.MinHeight(42));
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("빌드 역할 미리 보기", "Preview Build Roles")))
                RunCustomPreview(L("빌드 역할", "Build roles"), () => ManagedAddressableSynchronizer.CreateBuildRolePlan(config, roleDraft, (bootKeyDraft ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries), roleAdoptions));
            if (GUILayout.Button(L("폴더로 역할 제안", "Suggest Roles from Folders"))) SuggestBuildRoles();
            if (GUILayout.Button(L("역할 초안 다시 읽기", "Reload Role Draft"))) LoadBuildRoleDraft();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawStepBuildSection()
        {
            EditorGUILayout.HelpBox(L("앱 빌드가 하는 단계를 하나씩 합니다. Boot/Revision 빌드는 매번 Player Content를 정리하고 Clean Full Snapshot으로 만듭니다. Unity Content Update는 쓰지 않습니다. 이 경로의 Revision 빌드는 배포 순번을 올리지 않고, 이전 값 이하이면 경고만 합니다.",
                "Runs App Build's steps one by one. Boot/Revision builds clear Player Content each time and make a Clean Full Snapshot; Unity Content Update is not used. Revision builds here never raise the deployment sequence and only warn when it is not above the previous one."), MessageType.None);
            EditorGUI.BeginDisabledGroup(buildInProgress);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("Boot 빌드 미리 보기", "Preview Boot Build"))) PreviewSplitBuild(ManagedGroupBuildRole.Boot);
            if (GUILayout.Button(L("Boot 빌드", "Build Boot"))) QueueBuild(ManagedGroupBuildRole.Boot);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(L("Revision 빌드 미리 보기", "Preview Revision Build"))) PreviewSplitBuild(ManagedGroupBuildRole.Revision);
            if (GUILayout.Button(buildInProgress ? L("빌드 중...", "Building...") : L("Revision 빌드", "Build Revision"))) QueueBuild(ManagedGroupBuildRole.Revision);
            EditorGUILayout.EndHorizontal();
            if (GUILayout.Button(L("원격 캐시·CRC 정책 미리 보기", "Preview Remote Cache / CRC Policy")))
                RunCustomPreview(L("원격 캐시·CRC 정책", "Remote cache / CRC policy"), () => ManagedAddressableSynchronizer.CreateRevisionBuildPlan(config));
            EditorGUI.EndDisabledGroup();
            DrawPackagedRevisionSection();
            if (GUILayout.Button(L("Player 스테이징 검사", "Check Player Staging"))) resultText = ManagedAddressableBuildExporter.ValidatePlayerStaging(config).ToString();
        }

        private void DrawRecoverySection()
        {
            EditorGUILayout.HelpBox(L("빌드가 중간에 끊기면 Addressables 설정과 SDK link.xml이 임시 값으로 남을 수 있습니다. 남은 기록이 있으면 모든 빌드가 시작 전에 막힙니다.",
                "An interrupted build can leave Addressables settings and the SDK link.xml at temporary values. While records remain, every build is blocked before it starts."), MessageType.None);
            EditorGUI.BeginDisabledGroup(buildInProgress);
            if (GUILayout.Button(L("중단된 Split 설정 미리 보기", "Preview Interrupted Split Settings")))
            {
                reviewedSettingsRestorePlan = ManagedAddressableBuildExporter.CreateInterruptedSplitSettingsRestorePlan();
                resultText = reviewedSettingsRestorePlan.ToString();
            }
            if (GUILayout.Button(L("중단된 Split 설정 복원", "Restore Interrupted Split Settings")))
            {
                try { ManagedAddressableBuildExporter.RestoreInterruptedSplitBuildSettings(reviewedSettingsRestorePlan); reviewedSettingsRestorePlan = null; resultText = L("Split 설정을 복원하고 원본·적용 값을 확인했습니다.", "Split settings restored and raw/effective verified."); }
                catch (Exception error) { resultText = error.ToString(); }
                appBuildStatusTime = 0;
            }
            if (GUILayout.Button(L("중단된 Player 빌드 정보 복원", "Restore Interrupted Player Build Data")))
            {
                try { ManagedAddressableBuildExporter.RestoreInterruptedPlayerBuildMetadata(); resultText = L("SDK Player 빌드 정보를 복원했습니다.", "Pending SDK Player metadata restoration completed."); }
                catch (Exception error) { resultText = error.ToString(); }
                appBuildStatusTime = 0;
            }
            EditorGUI.EndDisabledGroup();
        }

        private void PreviewSplitBuild(ManagedGroupBuildRole purpose)
        {
            serializedConfig.ApplyModifiedProperties();
            reviewedSplitBuildPlan = ManagedAddressableBuildExporter.CreateSplitBuildPlan(config, purpose);
            if (purpose == ManagedGroupBuildRole.Revision)
            {
                var release = ManagedAddressableBuildExporter.ValidateRevisionReleasePrebuild(config);
                reviewedSplitBuildPlan.report.warnings.AddRange(release.Warnings);
                if (HasUnappliedReleaseDraft()) reviewedSplitBuildPlan.report.errors.Add(UnappliedReleaseDraftMessage());
            }
            resultText = reviewedSplitBuildPlan.ToString();
        }

        private static string UnappliedReleaseDraftMessage() => L(
            "배포 값 초안이 저장된 값(Config 공유 값 + 이 PC 값)과 다릅니다. 고급 > 배포 값에서 배포 값 미리 보기 → 미리 본 계획 적용, 또는 배포 값 다시 읽기 뒤 빌드하세요.",
            "The release value draft differs from the saved values (shared Config values + this PC). Use Advanced > Release values > Preview Release Values → Apply Previewed Plan, or Reload Release Values, then build.");

        private bool HasUnappliedReleaseDraft()
        {
            if (packagedDraftConfig != config || packagedReleaseDraft == null) return false;
            try { return JsonUtility.ToJson(packagedReleaseDraft) != JsonUtility.ToJson(ManagedLocalRelease.Effective(config)); }
            catch { return true; }
        }

        private void QueueBuild(ManagedGroupBuildRole purpose)
        {
            if (buildInProgress) return;

            serializedConfig.ApplyModifiedProperties();
            if (purpose == ManagedGroupBuildRole.Revision)
            {
                var release = ManagedAddressableBuildExporter.ValidateRevisionReleasePrebuild(config);
                if (!release.CanBuild) { resultText = release.ToString(); return; }
                if (HasUnappliedReleaseDraft()) { resultText = UnappliedReleaseDraftMessage(); return; }
            }
            if (reviewedSplitBuildPlan == null || reviewedSplitBuildPlan.purpose != purpose)
            {
                resultText = L("빌드 전에 같은 종류(Boot/Revision)의 빌드 미리 보기를 실행하세요.", "Preview the matching Boot/Revision build plan before building.");
                return;
            }
            buildInProgress = true;
            resultText = L("Addressables 빌드를 시작했습니다...", "Addressable build started...");
            Repaint();

            EditorApplication.delayCall += RunBuildDeferred;
        }

        private void RunBuildDeferred()
        {
            if (this == null) return;

            try
            {
                ManagedBuildExportResult build = ManagedAddressableBuildExporter.BuildReviewedSplitContent(config, reviewedSplitBuildPlan);
                if (build.success && reviewedSplitBuildPlan?.purpose == ManagedGroupBuildRole.Revision)
                    packagedReceiptDraft = build.splitReceiptPath;
                resultText = build.success
                    ? L("Addressables 빌드 완료.\n출력: ", "Addressable build completed.\nOutput: ") + build.outputDirectory + L("\nSplit 영수증: ", "\nSplit receipt: ") + build.splitReceiptPath + (build.warnings.Count > 0 ? L("\n세부:\n", "\nDetails:\n") + string.Join("\n", build.warnings) : string.Empty)
                    : L("Addressables 빌드 실패.\n", "Addressable build failed.\n") + build.error;
            }
            catch (Exception ex)
            {
                resultText = L("Addressables 빌드 실패.\n", "Addressable build failed.\n") + ex;
            }
            finally
            {
                buildInProgress = false;
                reviewedSplitBuildPlan = null;
                appBuildStatusTime = 0;
                Repaint();
            }
        }
    }
}
