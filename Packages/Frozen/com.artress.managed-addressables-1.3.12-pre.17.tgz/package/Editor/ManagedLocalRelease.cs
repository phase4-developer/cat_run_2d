﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using UnityEditor;

namespace Artress.ManagedAddressables.Editor
{
    // Values the whole team shares. They live in the Project Config and travel with Git.
    [Serializable]
    public sealed class ManagedRevisionSharedRelease
    {
        public string productId, authorityId, compatibilityFamily;
        internal ManagedRevisionSharedRelease Copy() => (ManagedRevisionSharedRelease)MemberwiseClone();
    }

    // One app-included Revision A per build target on this PC.
    [Serializable]
    internal sealed class ManagedPackagedLink
    {
        public string target, metadataPath, metadataSha256;
    }

    // Values that belong to one PC. They stay out of Git so each PC builds its own
    // Revisions on its own channel and never reuses another PC's sequence.
    [Serializable]
    internal sealed class ManagedLocalReleaseFile
    {
        public int schemaVersion = 1;
        public string configAssetGuid;
        public string channel;
        public long deploymentSequence;
        public List<ManagedPackagedLink> packaged = new List<ManagedPackagedLink>();
        public string localHostRoot;
    }

    internal static class ManagedLocalRelease
    {
        internal const string Folder = "UserSettings/ArtressManagedAddressables";

        internal static string FilePath(ManagedAddressableProjectConfig config)
        {
            string guid = ConfigGuid(config);
            return string.IsNullOrEmpty(guid) ? null : Path.Combine(Folder, "Release-" + guid + ".json").Replace('\\', '/');
        }

        private static string ConfigGuid(ManagedAddressableProjectConfig config) =>
            config == null ? null : AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(config));

        internal static ManagedLocalReleaseFile Read(ManagedAddressableProjectConfig config)
        {
            string path = FilePath(config);
            if (path != null) RecoverFinishedWrite(path);
            if (path == null || !File.Exists(path)) return new ManagedLocalReleaseFile { configAssetGuid = ConfigGuid(config) };
            var file = JsonConvert.DeserializeObject<ManagedLocalReleaseFile>(File.ReadAllText(path));
            if (file == null || file.schemaVersion != 1 || file.configAssetGuid != ConfigGuid(config))
                throw new InvalidOperationException("This PC's release file does not belong to the selected Project Config: " + path);
            file.packaged ??= new List<ManagedPackagedLink>();
            return file;
        }

        // Write finishes the .tmp copy before replacing. If the replacement removed the file and then
        // failed, the .tmp holds the newest complete values; reading an empty file instead would
        // drop this PC's packaged A links and let Build Output Cleanup delete those builds.
        // With both files present the replacement never happened, so the file stays authoritative.
        internal static void RecoverFinishedWrite(string path)
        {
            string temporary = path + ".tmp";
            if (File.Exists(path) || !File.Exists(temporary)) return;
            if (JsonConvert.DeserializeObject<ManagedLocalReleaseFile>(File.ReadAllText(temporary)) == null)
                throw new InvalidOperationException("This PC's release file is missing and its unfinished copy is unreadable: " + temporary);
            File.Move(temporary, path);
        }

        internal static byte[] RawBytes(ManagedAddressableProjectConfig config)
        {
            string path = FilePath(config);
            return path != null && File.Exists(path) ? File.ReadAllBytes(path) : null;
        }

        internal static void Write(ManagedAddressableProjectConfig config, ManagedLocalReleaseFile file)
        {
            string path = FilePath(config);
            if (path == null) throw new InvalidOperationException("Save the Project Config as an asset before writing this PC's release values.");
            file.configAssetGuid = ConfigGuid(config);
            file.packaged = (file.packaged ?? new List<ManagedPackagedLink>()).Where(link => link != null)
                .OrderBy(link => link.target, StringComparer.Ordinal).ToList();
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string temporary = path + ".tmp";
            File.WriteAllText(temporary, JsonConvert.SerializeObject(file, Formatting.Indented), new UTF8Encoding(false));
            ManagedFileReplace.ReplaceOrMove(temporary, path);
        }

        internal static void Restore(ManagedAddressableProjectConfig config, byte[] bytes)
        {
            string path = FilePath(config);
            if (path == null) return;
            if (bytes == null) { if (File.Exists(path)) File.Delete(path); return; }
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllBytes(path, bytes);
        }

        internal static void Delete(ManagedAddressableProjectConfig config)
        {
            string path = FilePath(config);
            if (path != null && File.Exists(path)) File.Delete(path);
        }

        // Shared Config values plus this PC's channel and sequence. Missing values stay empty
        // so release validation blocks the build instead of guessing.
        internal static ManagedRevisionReleaseMetadata Effective(ManagedAddressableProjectConfig config)
        {
            var shared = config?.revisionShared ?? new ManagedRevisionSharedRelease();
            var local = Read(config);
            return new ManagedRevisionReleaseMetadata
            {
                productId = shared.productId, authorityId = shared.authorityId, compatibilityFamily = shared.compatibilityFamily,
                channel = local.channel, deploymentSequence = local.deploymentSequence
            };
        }

        internal static ManagedPackagedLink Packaged(ManagedAddressableProjectConfig config, string target)
        {
            if (FilePath(config) == null) return null;
            return Read(config).packaged.FirstOrDefault(link => string.Equals(link.target, target, StringComparison.Ordinal));
        }

        internal static ManagedPackagedLink PackagedForActiveTarget(ManagedAddressableProjectConfig config) =>
            Packaged(config, EditorUserBuildSettings.activeBuildTarget.ToString());

        // Writes the shared values to the Config (saved) and the rest to this PC's file.
        internal static void SetRelease(ManagedAddressableProjectConfig config, ManagedRevisionReleaseMetadata release)
        {
            if (release == null) throw new ArgumentNullException(nameof(release));
            var shared = new ManagedRevisionSharedRelease { productId = release.productId, authorityId = release.authorityId, compatibilityFamily = release.compatibilityFamily };
            if (JsonConvert.SerializeObject(shared) != JsonConvert.SerializeObject(config.revisionShared ?? new ManagedRevisionSharedRelease()))
            {
                config.revisionShared = shared;
                EditorUtility.SetDirty(config);
                if (EditorUtility.IsPersistent(config)) AssetDatabase.SaveAssetIfDirty(config);
            }
            var local = Read(config);
            local.channel = release.channel; local.deploymentSequence = release.deploymentSequence;
            Write(config, local);
        }

        internal static void SetPackaged(ManagedAddressableProjectConfig config, string target, string metadataPath, string metadataSha256)
        {
            var local = Read(config);
            local.packaged.RemoveAll(link => link == null || string.Equals(link.target, target, StringComparison.Ordinal));
            local.packaged.Add(new ManagedPackagedLink { target = target, metadataPath = metadataPath, metadataSha256 = metadataSha256 });
            Write(config, local);
        }

        // Inputs that make a reviewed Revision/Player plan stale on this PC. The local host
        // folder only affects publishing and is not part of any build.
        internal static string FingerprintText(ManagedAddressableProjectConfig config)
        {
            if (FilePath(config) == null) return "LocalRelease:none";
            var local = Read(config);
            return "LocalRelease:" + local.channel + "|" + local.deploymentSequence + "|" +
                string.Join(";", local.packaged.Select(link => link.target + "=" + link.metadataPath + "@" + link.metadataSha256));
        }
    }
}
