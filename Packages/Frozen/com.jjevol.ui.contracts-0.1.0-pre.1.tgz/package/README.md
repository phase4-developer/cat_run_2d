# JJEvol UI Contracts

`com.jjevol.ui.contracts@0.1.0-pre.1`은 uGUI 계열(`com.jjevol.ui`, `com.jjevol.ui.addressables`)과 UI Toolkit 계열이 함께 쓰는 UI 시스템 중립 계약이다. uGUI, TextMeshPro, UniTask에 의존하지 않는다. Addressables(`com.unity.addressables` 4.0.1)에는 의존한다. Editor 생성기가 Addressables 그룹에서 ID를 읽기 때문이라, UI Toolkit 게임도 Addressables를 설치한다. 프로젝트는 UI 시스템을 하나만 쓰지만(D-02), 주소 규칙과 ID 생성기는 한 곳에서만 고친다(UI Toolkit 계획 결정 G1).

## 들어 있는 것

| 형식 | 역할 |
|---|---|
| `UIAddress` | 게임 소유 문자열 UI ID와 Addressables 주소 `UIScreen_{id}`, `UIPopup_{id}`, `UIHud_{id}` |
| `UIAddressIdAttribute` | Inspector에서 등록 주소 중 접두가 맞는 ID를 고르게 하는 속성. 그리기는 Editor의 `UIAddressIdDrawer` |
| `UIIdConstants` | `JJEvol/UI/Generate UI ID Constants`. 등록 주소를 읽어 게임 폴더에 `GameScreen`, `GamePopup`, `GameHud` 문자열 상수를 쓴다 |
| `IScreenData`, `IPopupData` | 화면·팝업에 넘기는 데이터 표시 계약 |
| `IUILoadingProgressView` | 전체 화면 로딩의 진행률·문구 표시 계약 |

모든 형식은 namespace `jjevol`이다. 2026-11-11에 `com.jjevol.ui`와 `com.jjevol.ui.addressables`에서 이름·GUID를 그대로 두고 옮겼다.

## 설치와 참조

`com.jjevol.ui`와 `com.jjevol.ui.addressables`가 이 패키지에 의존하므로 manifest에 함께 적는다. Assembly-CSharp는 자동으로 참조한다. 게임이 자체 asmdef를 쓰고 위 형식을 직접 쓰면 그 asmdef에 `JJEvol.UI.Contracts.Runtime`(생성기를 부르는 Editor 코드는 `JJEvol.UI.Contracts.Editor`)를 더한다.

## 검증

Editor 시험 `JJEvol.UI.Contracts.Tests.Editor`(ID 생성기). 결과는 `Docs/Guide/Verification.md`에 적는다.
