# Changelog

## 0.1.0-pre.1 - 2026-11-11

- New package. UI system neutral contracts moved here unchanged so uGUI and UI Toolkit share one copy (UI Toolkit plan decision G1, 2026-11-11): `UIAddress` and `UIAddressIdAttribute` with its Inspector drawer (from ui.addressables), `IUILoadingProgressView` (from ui), `IScreenData` and `IPopupData` (from ui.addressables `UIScreen.cs`/`UIPopup.cs`), and the `JJEvol/UI/Generate UI ID Constants` generator `UIIdConstants` with its tests. Namespace `jjevol`, type names and the GUIDs of moved files are unchanged.
- No uGUI, TextMeshPro or UniTask dependency. The Editor assembly uses Addressables to read registered addresses.
