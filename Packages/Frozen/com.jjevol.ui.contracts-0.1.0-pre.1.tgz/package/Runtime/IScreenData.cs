namespace jjevol
{
    /// <summary>화면에 넘기는 데이터의 표시 계약이다. uGUI와 UI Toolkit 화면이 같이 쓴다.</summary>
    public interface IScreenData
    {
    }
}
