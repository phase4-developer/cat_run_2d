namespace jjevol
{
    /// <summary>팝업에 넘기는 데이터의 표시 계약이다. uGUI와 UI Toolkit 팝업이 같이 쓴다.</summary>
    public interface IPopupData
    {
    }
}
