namespace jjevol
{
    /// <summary>
    /// 전체 화면 로딩의 진행률 표시 계약이다. 전체 화면 로딩 Prefab의 컴포넌트가 구현하면 로딩 세션이 찾아서 값을 전달한다.
    /// </summary>
    public interface IUILoadingProgressView
    {
        /// <param name="progress01">0~1 진행률.</param>
        void SetProgress(float progress01);

        /// <param name="message">표시할 문구. null이면 비운다.</param>
        void SetMessage(string message);
    }
}
