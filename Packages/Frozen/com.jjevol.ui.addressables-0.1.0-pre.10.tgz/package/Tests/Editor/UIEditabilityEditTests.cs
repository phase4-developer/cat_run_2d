using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace jjevol.UI.Tests
{
    /// <summary>Prefab RectTransforms and UIManager Inspector values are the editable sources; code does not overwrite them silently.</summary>
    public sealed class UIEditabilityEditTests
    {
        private GameObject _parent;
        [SetUp]public void SetUp(){_parent=new GameObject("UI parent",typeof(RectTransform));}
        [TearDown]public void TearDown(){if(_parent)Object.DestroyImmediate(_parent);}

        private RectTransform Root(Vector2 anchorMin,Vector2 anchorMax)
        {
            var go=new GameObject("Root",typeof(RectTransform));go.transform.SetParent(_parent.transform,false);
            var rect=(RectTransform)go.transform;
            rect.anchorMin=anchorMin;rect.anchorMax=anchorMax;rect.sizeDelta=new Vector2(-40,-20);
            rect.anchoredPosition=new Vector2(12,-8);rect.localScale=new Vector3(0.9f,0.9f,1);
            return rect;
        }

        [Test]
        public void FullStretchRootIsFittedToItsParent()
        {
            var rect=Root(Vector2.zero,Vector2.one);
            Assert.IsTrue(UIRootLayout.IsFullStretch(rect));
            Assert.IsTrue(UIRootLayout.FitToParentIfStretched(rect));
            Assert.AreEqual(Vector2.zero,rect.sizeDelta);
            Assert.AreEqual(Vector3.zero,rect.localPosition);
            Assert.AreEqual(Vector3.one,rect.localScale);
        }

        // Centered, bottom edge stretched across, left edge stretched up, inset stretch.
        private static readonly Vector4[] NotFullStretch={new(0.5f,0.5f,0.5f,0.5f),new(0,0,1,0),new(0,0,0,1),new(0.1f,0.1f,0.9f,0.9f)};
        [TestCase(0)][TestCase(1)][TestCase(2)][TestCase(3)]
        public void OtherRootsKeepTheirPrefabRectTransform(int anchors)
        {
            var a=NotFullStretch[anchors];
            var rect=Root(new Vector2(a.x,a.y),new Vector2(a.z,a.w));
            rect.sizeDelta=new Vector2(600,400);
            var position=rect.localPosition;
            Assert.IsFalse(UIRootLayout.IsFullStretch(rect));
            Assert.IsFalse(UIRootLayout.FitToParentIfStretched(rect));
            Assert.AreEqual(new Vector2(600,400),rect.sizeDelta,"A fixed-size root must not collapse to size 0.");
            Assert.AreEqual(position,rect.localPosition);
            Assert.AreEqual(new Vector3(0.9f,0.9f,1),rect.localScale);
        }

        [Test]
        public void MissingRootIsIgnored()
        {
            Assert.IsFalse(UIRootLayout.IsFullStretch(null));
            Assert.IsFalse(UIRootLayout.FitToParentIfStretched(null));
        }

        [Test]
        public void ScreenAndPopupManagersUseTheStretchRule()
        {
            foreach(var name in new[]{"UIScreenManager","UIPopupManager"})
            {
                var guids=AssetDatabase.FindAssets(name+" t:MonoScript",new[]{"Packages/com.jjevol.ui.addressables/Runtime"});
                Assert.AreEqual(1,guids.Length,name);
                var text=AssetDatabase.LoadAssetAtPath<MonoScript>(AssetDatabase.GUIDToAssetPath(guids[0])).text;
                StringAssert.Contains("UIRootLayout.FitToParentIfStretched(",text,name);
                StringAssert.DoesNotContain("sizeDelta = Vector2.zero",text,name);
            }
        }

        [Test]
        public void UIManagerExposesBackInputInTheInspector()
        {
            var go=new GameObject("UIManager fixture");
            try
            {
                var so=new SerializedObject(go.AddComponent<UIManager>());
                var action=so.FindProperty("backAction");
                Assert.IsNotNull(action);
                Assert.AreEqual(SerializedPropertyType.ObjectReference,action.propertyType);
                StringAssert.Contains("InputActionReference",action.type);
                Assert.IsNull(action.objectReferenceValue,"Empty by default so the previous Escape/Backspace keys stay in use.");
                var cooldown=so.FindProperty("backInputCooldown");
                Assert.IsNotNull(cooldown);
                Assert.AreEqual(0.3f,cooldown.floatValue,1e-6f);
            }
            finally{Object.DestroyImmediate(go);}
        }

        [Test]
        public void ZeroBackCooldownLeavesBackInputOpen()
        {
            var go=new GameObject("UIManager fixture");
            var previous=UINavigationOptions.IsBackInputBlocked;
            int requests=0;
            // HandleBackButtonAsync reads this first and stops, so the fixture needs no popup or screen manager.
            UINavigationOptions.IsBackInputBlocked=()=>{requests++;return true;};
            try
            {
                var manager=go.AddComponent<UIManager>();
                var so=new SerializedObject(manager);so.FindProperty("backInputCooldown").floatValue=0;so.ApplyModifiedPropertiesWithoutUndo();
                var flags=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
                var request=typeof(UIManager).GetMethod("RequestBack",flags);
                var delay=typeof(UIManager).GetField("mInputDelay",flags);
                request.Invoke(manager,null);
                Assert.IsNull(delay.GetValue(manager),"A zero cooldown must not keep a finished coroutine as the pending delay.");
                request.Invoke(manager,null);
                Assert.IsNull(delay.GetValue(manager));
                Assert.AreEqual(2,requests,"Both Back requests reach HandleBackButtonAsync.");
            }
            finally{UINavigationOptions.IsBackInputBlocked=previous;Object.DestroyImmediate(go);}
        }
    }
}
