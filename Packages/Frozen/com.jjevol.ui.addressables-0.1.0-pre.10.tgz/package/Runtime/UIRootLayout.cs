using UnityEngine;

namespace jjevol
{
    /// <summary>
    /// Layout rule for the root RectTransform of a screen or popup Prefab instantiated by the UI managers.
    /// A full-stretch root (anchorMin 0,0 and anchorMax 1,1) is fitted to its parent. Any other root keeps the
    /// position, size and scale authored in the Prefab.
    /// </summary>
    public static class UIRootLayout
    {
        /// <summary>True when the root stretches to the whole parent (anchorMin 0,0 and anchorMax 1,1).</summary>
        public static bool IsFullStretch(RectTransform root) =>
            root != null && root.anchorMin == Vector2.zero && root.anchorMax == Vector2.one;

        /// <summary>Fits a full-stretch root to its parent (position 0, scale 1, size offsets 0). Returns false and changes nothing otherwise.</summary>
        public static bool FitToParentIfStretched(RectTransform root)
        {
            if (!IsFullStretch(root)) return false;
            root.localPosition = Vector3.zero;
            root.localScale = Vector3.one;
            root.sizeDelta = Vector2.zero;
            return true;
        }
    }
}
