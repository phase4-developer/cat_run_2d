# Changelog

## 0.1.0-pre.10 - 2026-11-19

- New Editor menu `GameObject/UI/JJEvol/Popup Backboard`: with the UIManager's popupRoot selected it adds the backboard `UIPopupManager` looks for, in the README setup (direct child named `Backboard`, full stretch, translucent black `Image` with Raycast Target on, saved inactive, same layer as popupRoot). It refuses a non-RectTransform selection and a popupRoot that already has one, and supports Undo. Editor only; Runtime code and public members are unchanged.

## 0.1.0-pre.9 - 2026-11-19

- `UIPopupManager` now logs one warning when it is created (each `UIManager.Init`) and popupRoot has no direct child named exactly `Backboard`. The message holds popupRoot's hierarchy path. Before, a missing backboard was skipped silently and popups opened with nothing behind them. Behaviour is otherwise unchanged; no public member was added, removed or changed. A game that does not want a backboard can add an empty `Backboard` child to silence it.
- README documents the popup backboard: what `UIPopupManager` does with it and the recommended setup (full stretch, Raycast Target on, saved inactive; look and click behaviour are game-owned).

## 0.1.0-pre.8 - 2026-11-17

Prefab and Inspector values are no longer overwritten silently. No public member was removed or changed.

- Screen and popup Prefab roots: `UIScreenManager` and `UIPopupManager` fit the root (position 0, scale 1, size offsets 0) only when it is full stretch (anchorMin 0,0 and anchorMax 1,1). Any other root keeps the RectTransform authored in the Prefab. Before, every root got size 0, so a fixed-size root collapsed. New public helper `UIRootLayout` (`IsFullStretch`, `FitToParentIfStretched`).
- Back input: new `UIManager` Inspector fields `backAction` (`InputActionReference`) and `backInputCooldown` (default 0.3 s). With an action assigned, only that action requests Back; UIManager enables it once when it first reads it disabled, never re-enables it after the game disables it, and disables only what it enabled. Empty keeps the previous keys (Escape, and Backspace in the Editor). The cooldown replaces the fixed 0.3 s; 0 turns it off.

## 0.1.0-pre.7 - 2026-11-16

- Fixed: `ChangeUIScreenAsync`/`PrevUIScreen` update screen history only after the target screen loads and the request is still current; a failed load keeps the current screen, history and screen data.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.6 - 2026-11-11

- `UIAddress`, `UIAddressIdAttribute` and `UIIdConstants` (with the `[UIAddressId]` drawer and its tests), `IScreenData` and `IPopupData` moved to `com.jjevol.ui.contracts`. Namespace, names, the menu and the GUIDs of moved files are unchanged. A game assembly definition that uses them needs a `JJEvol.UI.Contracts.Runtime` reference; Assembly-CSharp gets it automatically.
- Depends on `com.jjevol.ui.contracts` 0.1.0-pre.1 and `com.jjevol.ui` 0.1.0-pre.3.

## 0.1.0-pre.5 - 2026-11-10

- `GameObject/UI/AddressableImage` and `GameObject/UI/AddressableTexture` are now `GameObject/UI/JJEvol/Addressable Image` and `Addressable Texture`. `JJEvol/UI/Generate UI ID Constants` is unchanged. Framework menus are grouped by feature under one `JJEvol/` root (Editor menus), `Assets/Create/JJEvol/` (asset menus) and `GameObject/UI/JJEvol/` (UI objects). Only the menu path changed; class names, serialized fields and GUIDs are unchanged, so existing assets keep working.
- Tests only. The atlas preview tests count a clone as any `step11_` sprite that is not a saved asset, not by `(Clone)` in its name, which stays 0 on Unity 6.7. A failing count lists the `step11_` sprites in memory. Runtime and Editor code are unchanged by this. It was listed as Unreleased while the version stayed 0.1.0-pre.4 to match the first delivery bundle tgz.

Unity tests for this candidate are NOT_RUN.

## 0.1.0-pre.4 - 2026-11-07

- Breaking: `UIScreenTypes`, `UIPopupTypes` and `UIHudTypes` are removed. Screens, Popups and HUDs use game-owned string IDs. Addresses stay `UIScreen_{id}`, `UIPopup_{id}` and `UIHud_{id}`.
- Added `UIAddress`, `[UIAddressId]` with an Inspector dropdown, and `JJEvol/UI/Generate UI ID Constants`.
- Breaking: `UICommonBtn`, `SoundType`, `IUIInteractable` and `IUIDisable` are removed. Added `UIButtonLock`, `UIButtonSound`, `UIButtonStateVisual` and `UIButtonHoldRepeat` for Unity `Button`.
- `UIPopup` plays its optional `closeSoundKey` instead of a fixed sound.
- `UIEvent.Trigger` takes a string ID in place of the two enum overloads.

## 0.1.0-pre.3 - 2026-11-06

- Added `UIManager.AcquireLoadingAsync` and `UILoadingSession` for owned, reference counted full screen loading.
- Extracted shared image loading, preview mesh and Inspector code. Prefabs still keep only string keys.
- `Show Loading` is now the only loading switch, and loading display no longer blocks the image load.
- Fixed sound exceptions interrupting input, replaced Screen requests, closing Popup reopen, `CloseWait` results and lease leaks on never activated objects.
- Inspector warns about assets that are not Addressable.
- Added `AddressableImage.IsLoadDeferred` and `AddressableTexture.IsLoadDeferred`.

Unity tests for this candidate are NOT_RUN.
