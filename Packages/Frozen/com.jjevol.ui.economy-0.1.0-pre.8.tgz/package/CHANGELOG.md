# Changelog

## 0.1.0-pre.8 - 2026-11-20

- 잔액이 없는 비용 종류(광고·인앱 등)를 게임이 `LocalEconomyUIOptions.UnmeteredCost`로 지정하면 `PriceLabel`·`PriceBtn`이 수량·아이콘을 그리고 항상 충분으로 본다(normalColor, 버튼 잠그지 않음). 섞인 비용은 재화 부분만 확인하고, 연결된 재화 종류는 지정해도 늘 확인한다. 지정하지 않으면 이전과 같다(미지원 종류는 글자를 비움).
- 가격이 비었거나 읽지 못한 경우와 PriceLabel 컴포넌트만 끈 경우 글자 색을 normalColor로 돌린다. 이전에는 마지막 부족 색이 남았다.
- presentation provider가 없을 때 재화가 아닌 종류의 비용은 같은 item ID의 재화 행 이름·아이콘을 쓰지 않는다.
- 중앙 요청 5381a72e3028(MoonVillage).

## 0.1.0-pre.7 - 2026-11-19

- `PriceLabel`·`PriceBtn`·`ResourceLabel`의 수량이 `UIRuntimeOptions.NumberFormat`을 따른다. 설정하지 않으면 지금처럼 N0다. 라벨별 덮어쓰기는 `SetNumberFormat(profile)`(null이면 게임 설정으로 돌아감)과 Inspector 필드(`overrideNumberFormat`, PriceLabel `numberFormat`, ResourceLabel `numberProfile`)다. `ResourceLabel.numberFormat`이 N0이 아닌 .NET 서식이면 그 서식이 게임 프로필보다 먼저다. ResourceLabel의 덮어쓰기는 연결한 `NumberAnimator`에도 넘긴다. `numberFormat`을 빈 문자열로 둔 ResourceLabel은 이제 `ToString("")`(구분자 없음)이 아니라 게임 프로필(기본 N0)로 쓴다. `SetNumberFormat`은 받은 프로필의 복사본을 저장한다.
- `com.jjevol.ui` 0.1.0-pre.4, `com.jjevol.ui.contracts` 0.1.0-pre.2에 의존한다. Runtime·시험 asmdef가 `JJEvol.UI.Contracts.Runtime`을 참조한다.

## 0.1.0-pre.6 - 2026-11-11

- Depends on UI Addressables 0.1.0-pre.6, which brings `com.jjevol.ui.contracts`. No source change.

## 0.1.0-pre.5 - 2026-11-08

- Depends on `com.jjevol.economy@0.1.0-pre.4`. The repository now comes from `com.jjevol.data`; the Runtime and test assemblies reference `JJEvol.Data.Runtime`. No UI source change.

Unity compile and the 29 PlayMode tests passed on Hosts/UiEconomyValidationHost (job ui-economy-1, candidate 68e3857).

## 0.1.0-pre.4 - 2026-11-07

- Breaking: removed the `PriceBtn` `commonButton` field. Assign the Unity `Button` to `button`, or a `UIButtonLock` to `buttonLock` with the `lockedState` to show.

## 0.1.0-pre.3 - 2026-11-06

- Updated internal dependency versions. No source change.

Unity tests for this candidate are NOT_RUN.
