using System;
using UnityEngine;

namespace jjevol
{
    /// <summary>Game-wide settings for the local economy labels. The game sets them once at boot.</summary>
    public static class LocalEconomyUIOptions
    {
        /// <summary>
        /// Cost types that have no balance to check, such as an ad view or a store purchase. The game decides which IDs these are.
        /// A price label shows such a cost with its quantity and icon and always treats it as affordable; with mixed costs only the
        /// wealth part is checked. The bound wealth type is always checked even if this returns true. Null means every cost type
        /// other than the bound wealth type is unsupported, as before. Call UIRuntimeOptions.NotifyLocaleChanged to redraw labels
        /// already shown after changing it at runtime.
        /// </summary>
        public static Func<ConsumeTypeId, bool> UnmeteredCost { get; set; }

        public static bool IsUnmetered(ConsumeTypeId type) => UnmeteredCost?.Invoke(type) ?? false;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetState() => UnmeteredCost = null;
    }
}
